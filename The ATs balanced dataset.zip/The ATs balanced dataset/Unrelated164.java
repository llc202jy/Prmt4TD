get_descriptor_base(unsigned short selector)
{
	sys_descriptor *desc;
	unsigned long base;

	desc = get_descriptor_address(selector);

	base  = desc->base_low;
	base += desc->base_med  << 16;
	base += desc->base_high << 24;

	return base;
}

unsigned int
get_descriptor_limit(unsigned short selector)
{
	sys_descriptor *desc;
	unsigned int limit;

	desc = get_descriptor_address(selector);

	limit  = desc->limit_low;
	limit += (desc->gav_limit & 0x0F) << 16;

	if (desc->gav_limit & 0x80)
	{
		limit <<= 12;
		limit += 0x0FFF;
	}

	return limit;
}

unsigned int
get_descriptor_type(unsigned short selector)
{
	sys_descriptor *desc;
	unsigned short type;

	desc = get_descriptor_address(selector);

	type  = desc->dpl_type;
	type += (desc->gav_limit & 0xF0) << 4;

	return type;
}

unsigned long kstack = (unsigned long)(void *)(0x40000 - 0x4000);

static void
init_tss_desc(unsigned int selector, unsigned long tss_address)
{
	unsigned int i = selector / 8;

	build_gdt_descriptor(i, tss_address, sizeof(TSS) - 1, 0xE9);
}

void
panic(char *msg)
{
	cli();

	kprintf("%s\n", msg);

	for (;;)
		;
}

/*
static void
ktss_setup(TSS *tss, unsigned long stack)
{
	tss->eip  = (unsigned long)(void *)&panic;
	tss->esp  = stack;
	tss->cs   = 0x08;
	tss->ds   = 0x10;
	tss->es   = 0x10;
	tss->fs   = 0x10;
	tss->gs   = 0x10;
	tss->ss   = 0x10;
	tss->ss0  = stack;
	tss->esp0 = stack;
	tss->trap = 0x00;
	tss->iomap = 0x00FF;
	tss->eflags = 0x00000202;
	tss->cr3 = (unsigned long)(void *)pd;
}
*/

struct
{
	unsigned short limit __attribute__ ((packed));
	sys_descriptor *gdt  __attribute__ ((packed));
	
} loadgdt = { (GDT_DESCRIPTOR_COUNT * sizeof(sys_descriptor) - 1), gdt };

void
desc_init(void)
{
//	init_tss_desc(KTSS_SEL, (unsigned long)(void *)&ktss);
	
	memset(&ktss, 0, sizeof(ktss));

	ktss.cs      = 0x08;
	ktss.ss      = 0x10;
	ktss.ds      = 0x10;
	ktss.es      = 0x10;
	ktss.fs      = 0x10;
	ktss.gs      = 0x10;
	ktss.eflags  = 0x202;
	ktss.cr3     = 0;
	ktss.ss0     = 0x10;
	ktss.esp0    = (kernel_stack + STACK_SIZE);
	ktss.iomap   = 104;
	
	build_gdt_descriptor(5, (unsigned int)&ktss, 0xFFFF, 0x89);
	
//	ktss_setup(&ktss, kstack);

	__asm__ ("lgdt (%0)\n" : : "r" ((char *)&loadgdt));
	__asm__ __volatile__ ("ltr %0" : : "m" (0x28) : "memory");
	__asm__ __volatile__ (
		"mov %0, %%ds\n"
		"mov %0, %%es\n"
		"mov %0, %%fs\n"
		"mov %0, %%gs\n"
		"mov %0, %%ss\n"
		: : "r" (0x10)
	);
/*
	__asm__ __volatile__ (
		"ltr %0"
		:
		: "rm" (*(unsigned char *)KTSS_SEL)
		: "memory"
	);
*/
}

#if 0
void
desc_init(void)
{
	unsigned long     boot_tss;
	unsigned long     boot_tss_limit;
	sys_descriptor    desc;
	pseudo_descriptor old_gdt_ptr;
	pseudo_descriptor gdt_ptr, idt_ptr;
	
	/* Get the boot GDT */
	kprintf("Getting the boot GDT.\n");
	__asm__ __volatile__ ("sgdt %0" : "=m" (old_gdt_ptr) : : "memory");

	/* Calculate the start address of the kernel */
	kprintf("Calculating the start address of the kernel.\n");
	memcpy(&desc, (unsigned long *)(old_gdt_ptr.linear + SEL_DKERNEL),
		   sizeof(pseudo_descriptor));
	kernel_base  = desc.base_low;
	kernel_base += desc.base_med  << 16;
	kernel_base += desc.base_high << 24;

	/* Calculate address of boot kernel TSS. */
	kprintf("Calculating the address of the boot kernel TSS.\n");
	memcpy(&desc, (unsigned long *)(old_gdt_ptr.linear + SEL_KERNELTSS),
		   sizeof(pseudo_descriptor));
	
	boot_tss  = desc.base_low;
	boot_tss += desc.base_med  << 16;
	boot_tss += desc.base_high << 24;
	
	boot_tss_limit  = desc.limit_low;
	boot_tss_limit += (desc.gav_limit & 0x0F) << 16;

	if (desc.gav_limit & 0x80)
	{
		boot_tss_limit <<= 12;
		boot_tss_limit += 0x0FFF;
	}

	/* Setup the GDT, LDT, and IDT */
	kprintf("Setting up the GDT, LDT, and IDT.\n");
	build_descriptor(SEL_NULL, 0, 0, 0);
	build_descriptor(SEL_GDT, (unsigned long)&gdt + kernel_base,
					 GDT_DESCRIPTOR_COUNT * sizeof(sys_descriptor), 0x093);
	build_descriptor(SEL_IDT, (unsigned long)&idt + kernel_base,
					 LDT_DESCRIPTOR_COUNT * sizeof(sys_descriptor), 0xC93);
	build_descriptor(SEL_CLINEAR, 0, 0xFFFFFFFF, 0xC9B);
	build_descriptor(SEL_DLINEAR, 0, 0xFFFFFFFF, 0xC93);
	build_descriptor(SEL_CKERNEL, kernel_base, 0xFFFFFFFF - kernel_base,
					 0xC9B);
	build_descriptor(SEL_DKERNEL, kernel_base, 0xFFFFFFFF - kernel_base,
					 0xC93);
	build_descriptor(SEL_KERNELTSS, (unsigned long)&kernel_tss + kernel_base,
					 sizeof(kernel_tss), 0x89);
	build_descriptor(SEL_KERNELLDT, (unsigned long)&ldt + kernel_base,
					 LDT_DESCRIPTOR_COUNT * sizeof(sys_descriptor), 0x093);

	/* Install GDT */
	kprintf("Installing the GDT.\n");
	gdt_ptr.linear = (unsigned long)&gdt + kernel_base;
	gdt_ptr.limit  = GDT_DESCRIPTOR_COUNT * sizeof(sys_descriptor);
	__asm__ __volatile__ ("lgdt %0" : : "m" (gdt_ptr) : "memory");

	/* Install LDT */
	kprintf("Installing the LDT.\n");
	idt_ptr.linear = (unsigned long)&idt + kernel_base;
	idt_ptr.limit  = IDT_DESCRIPTOR_COUNT * sizeof(gate_descriptor);
//	__asm__ __volatile__ ("lidt %0" : : "m" (idt_ptr) : "memory");
	__asm__ (
		"lidt (%0)                 \n"   /* Load the IDT                */
        	"pushfl                    \n"   /* Clear the NT flag           */
	        "andl $0xffffbfff,(%%esp)  \n"
	        "popfl                     \n"
	        :
	        : "r" ((char *)&idt_ptr)
	);

	kprintf("Setting up cr3\n");
	__asm__ __volatile__ ("mov %0, %%cr3" : : "r" ((unsigned long)(void *)pd));
	

	/* Copy kernel TSS */
	kprintf("Copying the kernel TSS.\n");
	memcpy(&kernel_tss, (unsigned long *)boot_tss, boot_tss_limit);
	kernel_tss.cr3 = (unsigned long)(void *)pd;

	/* Install kernel TSS */
	kprintf("Installing the kernel TSS.\n");
	__asm__ __volatile__ (
		"ltr %0"
		:
		: "rm" (*(unsigned char *)SEL_KERNELTSS)
		: "memory"
	);

	kprintf("Done with this function...\n");
//	__asm__ __volatile__ ("ltr %0" : : "rm" (SEL_KERNELTSS) : "memory");
}
#endif /* 0 */