        public void execute() {
           
            if (logger.isDebugEnabled()) {
                logger.debug("Rerouting event ");
*
 * Createdcatch (Exception ex) {
            String s = "unexpected error in creating sbbEntity!";
            log.error(s,ex);
            throw new RuntimeException(s, ex);
        }
    }

    public SbbEntity createRootSbbEnity(SbbID sbbId, ServiceID svcId,
            String convergenceName) {
        try {
            String sbbeId = genId();
            if(log.isDebugEnabled())
                log.debug("Creating root sbb entity with id:" + sbbeId);
            
            SbbEntity sbbe = new SbbEntity( sbbeId, sbbId, convergenceName, svcId);
            sbbe.setParentSbbEntity(sbbeId);
            sbbe.setRootSbbId(sbbeId);
           // Defer the store to cache until the enclosing tx commits.
            if(log.isDebugEnabled())
                log.debug("Putting it in the map");
            putInTxCache(sbbeId, sbbe);
            return sbbe;
        } catch (Exception ex) {
            String s = "unexpected exception in createSbbEntity";
            log.error(s,ex);
            throw new RuntimeException(s, ex); 
        }
    }

    private void putInTxCache(String sbbeID, SbbEntity sbb) {
		SleeContainer.getTransactionManager().putTxLocalData("sbb" + sbbeID, sbb);
    }
   
    
    /**
     * Remove the entity id to entity map. Call this when destroying the
     * sbb entity -- when we no longer need to hold a reference to it.
     * 
     * @param sbbeId
     */
    public void removeFromCache(String sbbeId) {        
    	
    	try {
    		SleeContainer.getTransactionManager().removeTxLocalData("sbb" + sbbeId);
    	} catch (SystemException e) {  
    	    if (log.isDebugEnabled()) {
            	log.debug("Failed to remove sbbentity, " + sbbeId +
            	        "from tx cache");
        	}
    	}
    	
    	
    }

    /**
     * Call this function when you want to get an instantiated SbbEntity from the
     * cache.
     * 
     * @param sbbeId
     * @return
     */
    public SbbEntity getSbbEntity(String sbbeId) {
        if (log.isDebugEnabled())
            log.debug("getSbbEntity : " + sbbeId);
        if ( sbbeId == null) throw new NullPointerException("Null Sbbeid");
       
        /* NB!! We must not use a map to cache sbb entities.
         * There can be multiple active transactions each of which accesses the same sbb entity
         * at any one time in the SLEE.
         * Therefore, by using a map to store the sbb entities one tx can see the transactional
         * state of the other tx before it has committed.
         * I.e. we would have no transaction isolation.
         * Instead, if we want to cache the sbb entity for the lifetime of the tx for
         * performance reasons, we need to store in a *per transaction* cache
         */
        
        //Look for it in the per transaction cache
        SbbEntity sbb = (SbbEntity)SleeContainer.getTransactionManager().getTxLocalData("sbb" + sbbeId);
        
        if (sbb == null) {
        	//Load it from the treecache
            if(log.isDebugEnabled())
        	log.debug("Cannot find sbb in per tx cache - loading from treecache");
        	
        	sbb = new SbbEntity(sbbeId);
        	
        	SleeContainer.getTransactionManager().putTxLocalData("sbb" + sbbeId, sbb);
        } else {
            if(log.isDebugEnabled())
        	log.debug("Found sbb in per tx cache");

        }
        
        return sbb;
    }
      
}/*
 * Created on Jul 8, 2004
 *
 * The Open SLEE project.
 *
 * The source code contained in this file is in in the public domain.          
 * It can be used in any project or product without prior permission, 	      
 * license or royalty payments. There is no claim of correctness and
 * NO WARRANTY OF ANY KIND provided with this code.
 *
 */
package org.mobicents.slee.runtime;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

import javax.slee.ActivityContextInterface;
import javax.slee.Address;
import javax.slee.EventTypeID;
import javax.slee.resource.ResourceAdaptor;

import org.mobicents.slee.container.SleeContainer;
import org.mobicents.slee.resource.ResourceAdaptorEntity;

/** 
 * Slee Event wrapper. This is delivered to the SbbEntity. The sbb entity records
 * any victim Sbbs that have generated runtime exceptions here.
 * 
 * @author F.Moggia
 * @author M. Ranganathan
 */
public class SleeEventImpl implements SleeEvent  {
    
    private ArrayList errorSbbObjects;
    
    private EventTypeID eventID;

    private String activityContextId;
    
    private String resourceAdaptorEntityName;
    
    private ActivityContextInterface aci;
    
    
    

    private Object activity;

    private Object eventObject;
    
    private Address address;
    
    public String toString() {
        return new StringBuffer().append("SleeEventImpl.toString() = { ").
        append("\n eventID = " + eventID).
        append("\n activitycontext  = " + activityContextId).
        append("\n eventObject = " + eventObject).
        append("\n address = " + ( address != null ? address.getAddressString() : null )).
        append("\n activity = " + activity).
        append("}").toString();
        
    }

    
    public boolean hasGarbage() { return errorSbbObjects.size() != 0 ; }
    
    public SleeEventImpl(int eventID, Object event, String activityContextId,  Object activity, Address addr) {
        this.errorSbbObjects = new ArrayList();
        
        this.activityContextId = activityContextId;
        this.eventID = SleeContainer.lookupFromJndi().getEventTypeID(eventID);
        this.eventObject = event;
        this.address = addr;
        
        this.activity = activity;
      
    }
    
    
    public SleeEventImpl(EventTypeID eventTypeId, Object event, String activityContextId, Object activity, Address addr) {
        this.errorSbbObjects = new ArrayList();
        this.activityContextId = activityContextId;
        this.activity = activity;
        this.eventID = eventTypeId;
        this.eventObject = event;
        this.address = addr;
    }

    /*
    public ActivityContext getActivityContext() {
        return activityContext;
    }*/
    
    /*public ActivityContext getActivityContext() {
        return activityContext;
    }*/
    
    
    public Object getActivity(){
        return this.activity;
    }
    public String getActivityContextID() {
        return activityContextId;
    }
    
    
    //public Object getActivity() { return activity; }
   
    public EventTypeID getEventTypeID() {
        return eventID;
    }

    
    public Object getEventObject() {
        return this.eventObject;
    }

    
    public Address getAddress() {
        return this.address;
       
    }
    
    
    


    /* (non-Javadoc)
     * @see org.mobicents.slee.runtime.SleeEvent#getActivityContextInterface()
     */
    public ActivityContext getActivityContext() {
        return SleeContainer.lookupFromJndi().getActivityContextFactory().getActivityContextById(activityContextId);
       
     
    }


    /* (non-Javadoc)
     * @see org.mobicents.slee.runtime.SleeEvent#setActivityContextInterface(javax.slee.ActivityContextInterface)
     */
    public void setActivityContextInterface(ActivityContextInterface aci) {
        this.aci = aci;
        
    }

   
    public  ActivityContextInterface getActivityContextInterface() {
        return this.aci;
    }

}
/*
 * Created on Mar 5, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mobicents.slee.runtime;

/**
 * 
 * This class represents the Invocation State of an sbb object
 * It is used in rollback handling to determine what to do since
 * this depends on whether an sbb object method invocation was happening
 * at the time the exception was thrown
 * 
 * @author Tim
 *
 * 
 */
public class SbbInvocationState {

	private static final int _NOT_INVOKING = 0;
	private static final int _INVOKING_SBB_CREATE = 1;
	private static final int _INVOKING_SBB_POSTCREATE = 2;	
	private static final int _INVOKING_SBB_LOAD = 5;
	private static final int _INVOKING_SBB_STORE = 6;
	private static final int _INVOKING_EVENT_HANDLER = 7;
	
	public static final SbbInvocationState NOT_INVOKING = new SbbInvocationState(_NOT_INVOKING);
	public static final SbbInvocationState INVOKING_SBB_CREATE = new SbbInvocationState(_INVOKING_SBB_CREATE);
	public static final SbbInvocationState INVOKING_SBB_POSTCREATE = new SbbInvocationState(_INVOKING_SBB_POSTCREATE);
	public static final SbbInvocationState INVOKING_SBB_LOAD = new SbbInvocationState(_INVOKING_SBB_LOAD);
	public static final SbbInvocationState INVOKING_SBB_STORE = new SbbInvocationState(_INVOKING_SBB_STORE);
	public static final SbbInvocationState INVOKING_EVENT_HANDLER = new SbbInvocationState(_INVOKING_EVENT_HANDLER);
	
	private int state;
	
	public int getState() { return state; }
	
	private SbbInvocationState(int state) {	this.state = state;	}
	
	public boolean equals(Object other) {
		if (!(other instanceof SbbInvocationState)) return false;
		SbbInvocationState tOther = (SbbInvocationState)other;
		return tOther.state == this.state;
	}
	public int hashCode() { return state; }
}/*
 * Created on Dec 3, 2004
 * 
 * The Open SLEE Project
 * 
 * A SLEE for the People
 * 
 * The source code contained in this file is in in the public domain. It can be
 * used in any project or product without prior permission, license or royalty
 * payments. There is no claim of correctness and NO WARRANTY OF ANY KIND
 * provided with this code.
 */
package org.mobicents.slee.runtime;

public final class SbbObjectState {

    /**
     * 
     * Constructor for the activityContextState
     * 
     * 
     * 
     * @param activityContextState
     *            The integer value for the activityContextState
     *  
     */

    private SbbObjectState(int sbbObjectState) {

        this.sbbObjectState = sbbObjectState;

        sbbObjectStateArray[sbbObjectState] = this;

    }

    /**
     * 
     * This method returns the object value of the activityContextState
     * 
     * 
     * 
     * @return The activityContextState Object
     * 
     * @param activityContextState
     *            The integer value of the activityContextState
     *  
     */

    public static SbbObjectState getObject(int sbbObjectState) {

        if (sbbObjectState >= 0 && sbbObjectState < m_size) {

            return sbbObjectStateArray[sbbObjectState];

        } else {

            throw new IllegalArgumentException(
                    "Invalid activityContextState value");

        }

    }

    /**
     * 
     * This method returns the integer value of the activityContextState
     * 
     * 
     * 
     * @return The integer value of the activityContextState
     *  
     */

    public int getValue() {

        return sbbObjectState;

    }

    /**
     * 
     * 
     * This method returns a string version of this class.
     * 
     * @return The string version of the activityContextState
     *  
     */

    public String toString() {

        String text = "";

        switch (sbbObjectState) {

        case _POOLED:

            text = "Pooled Sbb Object State";

            break;

        case _READY:

            text = "Ready Sbb Object State";

            break;
            
       case _DOES_NOT_EXIST:
           
           text = "Does not Exist Object State";

           break;

        default:

            text = "Error while printing SbbObject State";

            break;

        }

        return text;

    }

    // internal variables
    private int sbbObjectState;

    private static int m_size = 3;

    private static SbbObjectState[] sbbObjectStateArray = new SbbObjectState[m_size];

    private static final int _POOLED = 0;

    public final static SbbObjectState POOLED = new SbbObjectState(_POOLED);

    private static final int _READY = 1;

    public final static SbbObjectState READY = new SbbObjectState(_READY);
    
    private static final int _DOES_NOT_EXIST = 2;
    
    public final static SbbObjectState DOES_NOT_EXIST = new SbbObjectState(_DOES_NOT_EXIST);

}



            }

            if (ep != null) {
                EventExecutor ee = new EventExecutor(ep);
                try {
                    QueuedExecutor queue = getExecutor(ep.activity);
                    queue.execute(ee);
                } catch (InterruptedException e) {
                }
            }
            if (logger.isDebugEnabled()) {
                logger.debug("FINISHED reRouteEvent ");
            }
        }

    }

    /** Creates a new instance of EventRouterImpl */
    public EventRouterImpl(SleeContainer container) {

        //  this.currentEvent = new HashMap();
        /*
         * this.queue = new PooledExecutor(new LinkedQueue());
         * this.queue.setKeepAliveTime(-1); this.queue.createThreads(5);
         */

        this.executors = new ConcurrentHashMap();
        this.container = container;
        this.sbbEntityFactory = container.getSbbEntityFactory();
        this.txMgr = SleeContainer.getTransactionManager();
        activityEndEventID = container.getEventType(new ComponentKey(
                "javax.slee.ActivityEndEvent", "javax.slee", "1.0"));

        //this.queue = new QueuedExecutor ();
        //this.queue.restart();
        // Initialize the executor Pool
        this.executorsCounter = 0;
		this.execs = new QueuedExecutor[EXECUTOR_POOL_SIZE];
		for (int i=0;i<EXECUTOR_POOL_SIZE;i++){
			this.execs[i] = new QueuedExecutor();
		}
		this.etsExecutorsCounter = 0;
		this.etsExecs = new QueuedExecutor[EXECUTOR_ETS_POOL_SIZE];
		for (int i=0;i<EXECUTOR_ETS_POOL_SIZE;i++){
			this.etsExecs[i] = new QueuedExecutor();
			this.etsExecs[i].setThreadFactory(new ETSThreadFactory());
		}

    }

    private static String computeConvergenceName(SleeEvent e,
            ServiceComponent svc) throws Exception {
        SbbDescriptorImpl rootSbb = (SbbDescriptorImpl) svc
                .getRootSbbComponent();
        return rootSbb.computeConvergenceName(e, svc);
    }

    /**
     * Process the initial events of a service. This method possibly creates new
     * Sbbs. The container keeps a factory that creates new Sbbs keyed on the
     * convergence name of the service.
     */
    private void processInitialEvents(ServiceID serviceId, SleeEvent eventObject)
            throws Exception {

        Exception caught = null;
        SbbEntity sbbEntity = null;
        SbbObject sbbObject = null;
        ClassLoader invokerClassLoader = null;
        ClassLoader oldClassLoader = Thread.currentThread()
                .getContextClassLoader();

        txMgr.begin();
        try {
            /*
             * Start of SLEE originated invocation sequence
             * ============================================ 
             * We run a SLEE
             * originated invocation sequence here for every service that this
             * might be an intial event for
             */

            //Look-up the service
            ServiceComponent svc = container.getServiceComponent(serviceId);

            if (svc != null) {

                //do check for initial event types

                /*
                 * Use the initial event select to compute the convergence names
                 * for the service. This is a method that is provided by the
                 * service deployment. The names set is composed by only one
                 * convergence name the error is due an error in the pseudocode
                 */
                String name = computeConvergenceName(eventObject, svc);
                if (logger.isDebugEnabled()) {
                    logger.debug("service = " + serviceId + " Convergence name = "
                        + name);
                }
                Service service = container.getService(serviceId);
                if (name != null) {
                    boolean found = false;
                    try {
                        found = service.containsConvergenceName(name);
                    } catch (ClassCastException e) {
                        e.printStackTrace();
                        throw (new Exception(
                                "Convergence name is invalid class type"));
                    } catch (NullPointerException e) {
                        e.printStackTrace();
                        throw (new Exception("Convergence name is null"));
                    }

                    String sbbEntityId = null;
                    if (!found) {
                        if (logger.isDebugEnabled()) {
                            logger.debug("not found the convergence name ["
                                    + name + "]");
                        }
                        //Create a new root sbb entity

                        SbbID sbbID = (SbbID) svc.getRootSbbComponent().getID();

                        SbbDescriptorImpl descriptor = (SbbDescriptorImpl) this.container
                                .getSbbComponent(sbbID);
                        invokerClassLoader = descriptor.getClassLoader();
                        Thread.currentThread().setContextClassLoader(
                                invokerClassLoader);

                        //Now create the entity
                        sbbEntity = service.addChild(name);
                        sbbEntityId = sbbEntity.getSbbEntityId();
                        ActivityContext ac = null;
                        try {
                            sbbEntity.assignSbbObject(true);
                            sbbObject = sbbEntity.getSbbObject();
                           
                        } catch (Exception ex) {
                            logger.error("Exception trhown ", ex);
                            // ex.getCause().printStackTrace();
                            sbbObject = sbbEntity.getSbbObject();
                            sbbEntity.releaseObject(true);
                            //sbbEntity.getLock().release();
                            sbbEntity = null;
                            throw ex;
                        }

                        try {
                            ac = (ActivityContext) container
                                    .getActivityContextFactory()
                                    .getActivityContextById(
                                            eventObject.getActivityContextID());
                            ac.attachSbbEntity(sbbEntityId);

                            // FRAM
                            // sbbObject.sbbPostCreate();
                            if (logger.isDebugEnabled()) {
                                logger.debug("Ran sbbPostCreate");
                            }

                        } catch (Exception ex) {
                            if (ac != null)
                                ac.detachSbbEntity(sbbEntityId);
                            throw ex;
                        }
                        // FRAM
                        //sbbObject.setState(SbbObjectState.READY);

                        //and store to sychronize the persistent state
                        //TODO: Why we have to release object here?
                        sbbObject.sbbStore();
                        sbbEntity.releaseObject(false);
                        
                        //We've finished with the object so return it to the
                        // pool FIXME - when is this done?
                    } else {
                        if (logger.isDebugEnabled()) {
                            logger.debug("found the convergence name [" + name
                                    + "]");
                        }

                        String rootSbbEntityId = service
                                .getRootSbbEntityId(name);

                        ActivityContext ac = (ActivityContext) container
                                .getActivityContextFactory()
                                .getActivityContextById(
                                        eventObject.getActivityContextID());

                        ac.attachSbbEntity(rootSbbEntityId);

                    }
                } else {
                    logger.warn("Service with id:" + serviceId + " returns a null convergence name. Either the service does not exist or it is not interested in the event.");
                }
            }

        } catch (Exception e) {
            logger.error("Caught an error! ", e);
            caught = e;
        } finally {
            Thread.currentThread().setContextClassLoader(oldClassLoader);
        }

        boolean invokeSbbRolledBack = handleRollback(sbbObject, null, caught,
                invokerClassLoader);

        //If there is no entity associated then the invokeSbbRolledBack is
        // handle in
        //the same tx, otherwise in a new tx (6.10.1)

        if (sbbEntity == null && invokeSbbRolledBack) {
            handleSbbRolledBack(sbbEntity, sbbObject, eventObject,
                    invokerClassLoader, false);
        }

       
        // commit or rollback the tx. if the setRollbackOnly flag is set then this will 
        // trigger rollback action.
        if (logger.isDebugEnabled()) {
                logger.debug("Committing SLEE Originated Invocation Sequence");
        }
        txMgr.commit();

        //We may need to run sbbRolledBack for invocation sequence 1 in another
        // tx
        if (sbbEntity != null && invokeSbbRolledBack) {
            handleSbbRolledBack(sbbEntity, sbbObject, eventObject,
                    invokerClassLoader, false);
        }

        /*if (sbbEntity!=null) {
            if (logger.isDebugEnabled()) {
                logger.debug("release lock for SbbEntity [ SbbEntity  = " + 
                        sbbEntity.getSbbEntityId() + "]");
            }
            sbbEntity.getLock().release();
        }*/
        /*
         * End of SLEE Originated Invocation sequence
         * ==========================================
         */

    }

    /**
     * 
     * @param sbbObject
     *            The sbb object that was being invoked when the exception was
     *            caught - can be null if SLEE wasn't calling an sbb object when
     *            the exception was thrown
     * @param sleeEvent -
     *            the slee event - optional - only specified if it was an event
     *            handler that threw the exception
     * @param e -
     *            the exception caught
     * @param contextClassLoader
     * 
     * @return
     */
    private boolean handleRollback(SbbObject sbbObject, SleeEvent sleeEvent,
            Exception e, ClassLoader contextClassLoader) {
        txMgr.assertIsInTx();

        boolean invokeSbbRolledBack = false;

        if (e != null && e instanceof RuntimeException) {

            //See spec. 9.12.2 for full details of what we do here
            if (logger.isInfoEnabled())
                logger
                    .error(
                            "Caught RuntimeException in invoking SLEE originated invocation",
                            e);
           
            //We only invoke sbbExceptionThrown if there is an sbb Object *and*
            // an
            //sbb object method was being invoked when the exception was thrown
            if (sbbObject != null
                    && !sbbObject.getInvocationState().equals(
                            SbbInvocationState.NOT_INVOKING)) {
                if (logger.isDebugEnabled()) {
                    logger.debug("sbbObject is not null");
                }
                //Invoke sbbExceptionThrown method but only if it was a sbb
                // method that threw the
                //RuntimeException

                ClassLoader oldClassLoader = Thread.currentThread()
                        .getContextClassLoader();
                try {
                    Thread.currentThread().setContextClassLoader(
                            contextClassLoader);

                    try {
                        txMgr.setRollbackOnly();
                    } catch (SystemException ex) {
                        throw new RuntimeException("Unexpected exception ! ",
                                ex);
                    }
                    //Spec. 6.9. event and activity are null if exception was
                    // not thrown at
                    //event handler
                    ActivityContextInterface aci = null;
                    Object eventObject = null;
                    if (sleeEvent != null) {
                        aci = sleeEvent.getActivityContextInterface();

                        eventObject = sleeEvent.getEventObject();
                    }
                    if (logger.isDebugEnabled()) {
                        logger.debug("Calling sbbExceptionThrown");
                    }
                    try {
                        sbbObject.sbbExceptionThrown(e, eventObject, aci);
                        if (logger.isDebugEnabled()) {
                            logger.debug("Called sbbExceptionThrown");
                        }
                    } catch (Exception ex) {

                        // If method throws an exception , just log it.
                        if (logger.isDebugEnabled()) {
                            logger
                                    .debug(
                                            "Threw an exception while invoking sbbExceptionThrown ",
                                            ex);
                        }
                    }

                    //Spec section 6.10.1
                    //The sbbRolledBack method is only invoked on SBB objects
                    // in the Ready state.
                    invokeSbbRolledBack = sbbObject.getState().equals(
                            SbbObjectState.READY);

                    //now we move the object to the does not exist state
                    // (6.9.3)
                    //sbbObject.setState(SbbObjectState.DOES_NOT_EXIST);

                    sbbObject.setState(SbbObjectState.DOES_NOT_EXIST);
                    //Mark tx for rollback
                    if (logger.isDebugEnabled()) {
                        logger.debug("done it");
                    }
                } finally {
                    Thread.currentThread()
                            .setContextClassLoader(oldClassLoader);
                }
            }

        } else {
            if (logger.isDebugEnabled()) {
                logger.debug("Runtime exception was not thrown");
            }
            //See 9.12.2

            //We do this block if either the invocation sequence completed
            // successfully
            //OR only a checked exception was thrown

            if (sbbObject != null
                    && sbbObject.getSbbContext().getRollbackOnly()) {
                if (logger.isDebugEnabled()) {
                    logger.debug("object is set rollbackonly=true");
                    // The SBB signaled that a rollback is needed.
                    // run the rollback method.
                    logger.debug("sbb rolled back context "
                            + sbbObject.getSbbContext());
                }
                // Spec section 6.10.1
                // The sbbRolledBack method is only invoked on SBB objects in
                // the Ready state.
                invokeSbbRolledBack = sbbObject.getState().equals(
                        SbbObjectState.READY);

            }
        }

        if (sbbObject == null && e != null) {
            invokeSbbRolledBack = true;
        }
        if (logger.isDebugEnabled()) {
            logger.debug("InvokeSbbRolledBack?:" + invokeSbbRolledBack);
        }
        return invokeSbbRolledBack;
    }

    /**
     * 
     * @param sbbEntity
     *            The sbb entity - optional - if the invocation sequence does
     *            not have a target sbb entity this is null
     * @param sbbObj
     *            The sbb object - optional this is only specified if the
     *            invocation sequence does not have a target sbb entity
     * @param sleeEvent
     *            The slee event - only specified if the transaction that rolled
     *            back tried to deliver an event
     * @param contextClassLoader
     * @param removeRolledBack
     * 
     *  
     */
    public void handleSbbRolledBack(SbbEntity sbbEntity, SbbObject sbbObj,
            SleeEvent sleeEvent, ClassLoader contextClassLoader,
            boolean removeRolledBack) {
        //Sanity checks
        if ((sbbEntity == null && sbbObj == null)
                || (sbbEntity != null && sbbObj != null)) {
            logger
                    .error("Illegal State! Only one of sbbEntity or SbbObject can be specified");

            return;
        }

        /*
         * Depending on whether exceptions were thrown during the invocation
         * sequence we may need to invoke the sbbRolledBack method This must be
         * done on a different sbb object and a new transaction See Spec. Sec.
         * 9.12.2 for details
         */
        if (logger.isDebugEnabled()) {
            logger.debug("Invoking sbbRolledBack");
        }

        ClassLoader oldClassLoader = Thread.currentThread()
                .getContextClassLoader();
        try {

            //Only start new tx if there's a target sbb entity (6.10.1)
            if (sbbEntity != null) {
                String sbbId = sbbEntity.getSbbEntityId();
                txMgr.begin();
                // we have to refresh the sbb entity by reading it frmo the
                // cache
                sbbEntity = this.sbbEntityFactory.getSbbEntity(sbbId);
            }

            RolledBackContext rollbackContext = new RolledBackContextImpl(
                    sleeEvent == null ? null : sleeEvent.getEventObject(),
                    sleeEvent == null ? null
                            : new ActivityContextInterfaceImpl(container,
                                    sleeEvent.getActivityContextID()),
                    removeRolledBack);

            Thread.currentThread().setContextClassLoader(contextClassLoader);

            if (sbbEntity != null) {
                //We invoke the callback method a *different* sbb object 9.12.2
                //and 6.10.1
                if (logger.isDebugEnabled()) {
                    logger.debug("Invoking sbbRolledBack on different sbb object");
                }
                ObjectPool pool = sbbEntity.getObjectPool();

                //Get rid of old object (if any) first
                if (sbbEntity.getSbbObject() != null) {
                    // This was set to DOES_NOT_EXIST here because
                    // unsetSbbContext
                    // should not be called in this case.
                    sbbEntity.getSbbObject().setState(
                            SbbObjectState.DOES_NOT_EXIST);
                    pool.invalidateObject(sbbEntity.getSbbObject());
                }

                sbbEntity.assignSbbObject(false);
                sbbObj = sbbEntity.getSbbObject();
                sbbObj.sbbLoad();
            }
            if (logger.isDebugEnabled()) {
                logger.debug("Invoking sbbRolledBack");
            }
            //We only invoke this on objects in the ready state 6.10.1
            //E.g. if an exception was thrown from a sbbCreate then there will
            // be no sbb entity
            //and the the sbbobject won't be in the ready state so we invoke it
            if (sbbObj.getState().equals(SbbObjectState.READY))
                sbbObj.sbbRolledBack(rollbackContext);
            if (logger.isDebugEnabled()) {
                logger.debug("Invoked sbbRolledBack");
            }

            if (sbbEntity != null) {
                sbbObj.sbbStore();
            }

            if (sbbEntity != null) {
                try {
                    txMgr.commit();
                } catch (SystemException ex) {
                    ex.printStackTrace();
                    throw new RuntimeException("tx manager System Failure ", ex);
                }
            }
        } catch (Exception e) {
            //If an exception is thrown here we just log it and don't retry
            if (sbbObj != null && sbbEntity != null) {
                sbbObj = sbbEntity.getSbbObject();
                sbbObj.setState(SbbObjectState.DOES_NOT_EXIST);
            }
            logger
                    .error(
                            "Exception thrown in attempting to invoke sbbRolledBack",
                            e);
            sbbObj.sbbExceptionThrown(e, sleeEvent.getEventObject(), sleeEvent
                    .getActivityContextInterface());
        } finally {
            try {
                if (txMgr.isInTx())
                    txMgr.commit();
            } catch (Exception e2) {
                logger.error("Failed to commit transaction", e2);
                throw new RuntimeException("Failed to commit tx ", e2);
            }

            Thread.currentThread().setContextClassLoader(oldClassLoader);
        }
    }

    /**
     * Delivers to SBBs an event off the top of the queue for an activity context 
     * @param ep
     */
    private void routeQueuedEvent(EventPosting ep) {
        if (logger.isDebugEnabled())
            logger.debug("\n\n\nrouteTheEvent : [[["
                    + ep.event.getClass().getName() + " eventType "
                    + ep.eventTypeID);

        //Sanity check - should never be in a tx at this point
        txMgr.assertIsNotInTx();

        SleeEventImpl eventObject = null;
        String activityContextId = null;
        EventTypeID eventTypeID = null;
        //HashSet deliveredSet = new HashSet();

        boolean rb = true;
        try {

        	if(!container.getActivityContextFactory()
                        .containsActivityContext(ep.getActivity())) {
            	// ac does not exist
            	if(container.getSleeState().equals(SleeState.STOPPING)) {
            		return;
            	}
            }
        	
            ActivityContext ac = null;
            ServiceID[] serviceIDs = null;
            ServiceComponent[] services = null;
                        
            txMgr.begin();
            try {
                ac = (ActivityContext) container.getActivityContextFactory()
                        .getActivityContext(ep.getActivity());

                activityContextId = ac.getActivityContextId();
            
                Thread.currentThread().setName(activityContextId + "," + ep.getEventTypeID().toString());
                
                ac = null; //sanity - should not be used outside the tx

                eventObject = new SleeEventImpl(ep.getEventTypeID(), ep
                        .getEvent(), activityContextId, ep.getActivity(), ep
                        .getAddress());

                eventTypeID = eventObject.getEventTypeID();
                if (logger.isDebugEnabled()) {
                    logger.debug("Performing initial event processing.");
                }

                //logger.info(">>>>>>>> fetching number of Active services...");
                serviceIDs = container.getServicesByState(ServiceState.ACTIVE);
                if (logger.isDebugEnabled()) {
                    logger.info("number of Active services = " + serviceIDs.length);
                }
                // Iterate through each service that has the event type as an
                // initial
                // event type.
                services = new ServiceComponent[serviceIDs.length];
                for (int j = 0; j < serviceIDs.length; j++) {
                    services[j] = this.container
                            .getServiceComponent(serviceIDs[j]);
                }
            } catch (Throwable e) {
            	logger.error("Failure while routing event; first phase. Event Posting [" + ep + "]", e);
            } finally {
                txMgr.commit();
            }
            for (int i = 0; i < services.length; i++) {
                // We dont care about the service state etc.
                // FIXME -- should be storing only descriptors in the
                // container.

                SbbDescriptorImpl rootSbb = (SbbDescriptorImpl) services[i]
                        .getRootSbbComponent();
                if (rootSbb == null) {
                    //FIXME! early return not ideal
                    //txMgr.assertIsNotInTx();
                    continue;
                }
                Set iet = rootSbb.getInitialEventTypes();
                if (logger.isDebugEnabled()) {
                    logger.debug("svc name "
                            + services[i].getServiceDescriptor().getID());
                    logger.debug("root.initialEventTypes = " + iet);
                    logger.debug("eventTypeID = " + eventTypeID);
                }
                if (iet.contains(eventTypeID)) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("Initial Event processing.");
                    }
                    /**
                     * Contains SLEE Originated Invocation - Op type.
                     * Invokes life cycle methods, possibly rollback
                     */
                    processInitialEvents(services[i].getServiceID(),
