BOOL WINAPI CreateProcess(
  _In_opt_     LPCTSTR lpApplicationName,
  _Inout_opt_  LPTSTR lpCommandLine,
  _In_opt_     LPSECURITY_ATTRIBUTES lpProcessAttributes,
  _In_opt_     LPSECURITY_ATTRIBUTES lpThreadAttributes,
  _In_         BOOL bInheritHandles,
  _In_         DWORD dwCreationFlags,
  _In_opt_     LPVOID lpEnvironment,
  _In_opt_     LPCTSTR lpCurrentDirectory,
  _In_         LPSTARTUPINFO lpStartupInfo,
  _Out_        LPPROCESS_INFORMATION lpProcessInformation
);
DWORD WINAPI GetPriorityClass(
  _In_  HANDLE hProcess
);
uint32 SetPriority(
  [in]  sint32 Priority
);
BOOL WINAPI GetThreadPriorityBoost(
  _In_   HANDLE hThread,
  _Out_  PBOOL pDisablePriorityBoost
);BOOL WINAPI SetProcessPriorityBoost(
  _In_  HANDLE hProcess,
  _In_  BOOL DisablePriorityBoost
);