        {
            if (handlers[i].getServer()!=server)
                handlers[i].setServer(server);
        }

        // quasi atomic.... so don't go doing this under load on a SMP system.
        _handlers = handlers;

        for (int i=0;old_handlers!=null && i<old_handlers.length;i++)
        {
            if (old_handlers[i]!=null)
            {
                try
                {
                    if (old_handlers[i].isStarted())
                        old_handlers[i].stop();
                }
                catch (Throwable e)
                {
                    mex.add(e);
                }
            }
        }
                
        mex.ifExceptionThrowRuntime();
    }

    /* ------------------------------------------------------------ */
    /* 
     * @see org.mortbay.jetty.EventHandler#handle(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public void handle(String target, HttpServletRequest request, HttpServletResponse response, int dispatch) 
        throws IOException, ServletException
    {
        if (_handlers!=null && isStarted())
        {
            MultiException mex=null;
            
            for (int i=0;i<_handlers.length;i++)
            {
                try
                {
                    _handlers[i].handle(target,request, response, dispatch);
                }
                catch(EofException e)
                {
                    throw e;
                }

package org.mortbay.xml;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
    private JPanel jPanel1 = new JPanel();
    private JButton jButton2 = new JButton();
    private JButton jButton3 = new JButton();
    private JButton jButton4 = new JButton();
    private JButton jButton1 = new JButton();
    private JPanel jPanel2 = new JPanel();
    private JTextField jTextField1 = new JTextField();
    private BorderLayout borderLayout1 = new BorderLayout();
    private BorderLayout borderLayout2 = new BorderLayout();
    private TitledBorder titledBorder1;

    private Test test;
    private JScrollPane jScrollPane1 = new JScrollPane();
    private JTextArea jTextArea1 = new JTextArea();
    private JButton jButton5 = new JButton();
    private JPanel jPanel3 = new JPanel();
    private JButton jButton6 = new JButton();
    private JButton jButton7 = new JButton();

    public Driver(Test t, String title) {
        test = t;
        try {
            jbInit();
            this.setTitle(title);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    private void jbInit() throws Exception {
        titledBorder1 = new TitledBorder("");
        jButton2.setText("- Prov");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton2_actionPerformed(e);
            }
        });
        jButton3.setActionCommand("Rapido");
        jButton3.setText("Rapido");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton3_actionPerformed(e);
            }
        });
        jButton4.setText("- Lsnr");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton4_actionPerformed(e);
            }
        });
        jButton1.setText("+ Prov");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton1_actionPerformed(e);
            }
        });
        this.getContentPane().setLayout(borderLayout1);
        jPanel2.setLayout(borderLayout2);
        jPanel1.setBorder(BorderFactory.createRaisedBevelBorder());
        jPanel2.setBorder(BorderFactory.createRaisedBevelBorder());
        jTextArea1.setBorder(BorderFactory.createLoweredBevelBorder());
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton5_actionPerformed(e);
            }
        });
        jButton5.setText("Local");
        jButton5.setMinimumSize(new Dimension(60, 27));
        jButton5.setActionCommand("Local");
        jButton5.setMaximumSize(new Dimension(60, 27));
        jPanel3.setBorder(BorderFactory.createRaisedBevelBorder());
        jButton6.setMaximumSize(new Dimension(60, 27));
        jButton6.setMinimumSize(new Dimension(60, 27));
        jButton6.setActionCommand("Global");
        jButton6.setText("Global");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton6_actionPerformed(e);
            }
        });
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton7_actionPerformed(e);
            }
        });
        jButton7.setActionCommand("+ Listener");
        jButton7.setText("+ Lsnr");
        jPanel1.add(jButton1, null);
        jPanel1.add(jButton2, null);
        jPanel1.add(jButton3, null);
        jPanel1.add(jButton7, null);
        jPanel1.add(jButton4, null);
        this.getContentPane().add(jPanel3, BorderLayout.NORTH);
        jPanel3.add(jButton6, null);
        jPanel3.add(jButton5, null);
        this.getContentPane().add(jPanel2, BorderLayout.CENTER);
        jPanel2.add(jTextField1,  BorderLayout.SOUTH);
        jPanel2.add(jScrollPane1, BorderLayout.CENTER);
        this.getContentPane().add(jPanel1, BorderLayout.SOUTH);
        jScrollPane1.getViewport().add(jTextArea1, null);

        this.setSize(new Dimension(499, 300));

        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) { test.terminate(); }
        });
    }
