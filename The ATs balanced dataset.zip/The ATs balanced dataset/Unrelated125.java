import org.enhydra.shark.api.client.wfmc.wapi.WMSessionHandle;
import org.enhydra.shark.api.client.wfmodel.WfEventAudit;
import org.enhydra.shark.api.client.wfmodel.WfEventAuditIterator;
import org.enhydra.shark.api.common.SharkConstants;
import org.enhydra.shark.api.internal.eventaudit.AssignmentEventAuditPersistenceObject;
import org.enhydra.shark.api.internal.eventaudit.CreateProcessEventAuditPersistenceObject;
import org.enhydra.shark.api.internal.eventaudit.DataEventAuditPersistenceObject;
import org.enhydra.shark.api.internal.eventaudit.EventAuditManagerInterface;
import org.enhydra.shark.api.internal.eventaudit.EventAuditPersistenceInterface;
import org.enhydra.shark.api.internal.eventaudit.StateEventAuditPersistenceObject;
import org.enhydra.shark.api.internal.scripting.Evaluator;

/**
 * Iterator for event audits of activity or the process. The following names may be used:
 * time_stamp, username, event_type, activity_key, activity_name, process_key, process_name,
 * process_mgr_name, process_mgr_version, package_id, process_definition_id,
 * process_definition_name, activity_definition_id, activity_definition_name
 * and activity_definition_type 
 * that will be applied for all event types.
 * <p>
 * Here are the list of attributes that if specified will be applied to specific event
 * type:
 * <p>
 * WfCreateProcessEventAudit: p_activity_key, p_process_key, p_process_name,
 * p_process_mgr_name, p_process_mgr_version, p_package_id, p_process_definition_id,
 * p_process_definition_name, p_activity_definition_id and p_activity_definition_name
 * <p>
 * WfDataEventAudit: old_data_varId and new_data_varId, where varId is the Id of variable
 * from appropriate process/activity
 * <p>
 * WfStateEventAudit: old_state and new_state
 * <p>
 * WfAssignmentEventAudit: old_res, new_res and is_accepted
 * 
 * @author Sasa Bojanic
 */
public class WfEventAuditIteratorWrapper extends BaseIteratorWrapper implements
                                                                    WfEventAuditIterator {

   protected String procId;

   protected String actId;

   protected WfEventAuditIteratorWrapper(WMSessionHandle shandle, String procId) throws Exception {
      super(shandle);
      this.procId = procId;
   }

   protected WfEventAuditIteratorWrapper(WMSessionHandle shandle,
                                         String procId,
                                         String actId) throws Exception {
      super(shandle);
      this.procId = procId;
      this.actId = actId;
   }

   public WfEventAudit get_next_object() throws Exception {
      long tStamp = SharkUtilities.methodStart(shandle,"WfEventAuditIteratorWrapper.get_next_object");
      try {
         checkSecurity("get_next_object", null);

         return (WfEventAudit) super.getNextObject();
      } finally {
         SharkUtilities.methodEnd(shandle,tStamp,
                                  "WfEventAuditIteratorWrapper.get_next_object",
                                  this);
      }
   }

   public WfEventAudit get_previous_object() throws Exception {
      long tStamp = SharkUtilities.methodStart(shandle,"WfEventAuditIteratorWrapper.get_previous_object");
      try {
         checkSecurity("get_previous_object", null);

         return (WfEventAudit) super.getPreviousObject();
      } finally {
         SharkUtilities.methodEnd(shandle,tStamp,
                                  "WfEventAuditIteratorWrapper.get_previous_object",
                                  this);
      }
   }

   public WfEventAudit[] get_next_n_sequence(int max_number) throws Exception {
      long tStamp = SharkUtilities.methodStart(shandle,"WfEventAuditIteratorWrapper.get_next_n_sequence");
      try {
         checkSecurity("get_next_n_sequence", null);

         WfEventAudit[] ret = null;
         List l = super.getNextNSequence(max_number);
         ret = new WfEventAudit[l.size()];
         l.toArray(ret);
         return ret;
      } finally {
         SharkUtilities.methodEnd(shandle,tStamp,
                                  "WfEventAuditIteratorWrapper.get_next_n_sequence",
                                  this);
      }
   }

   public WfEventAudit[] get_previous_n_sequence(int max_number) throws Exception {
      long tStamp = SharkUtilities.methodStart(shandle,"WfEventAuditIteratorWrapper.get_previous_n_sequence");
      try {
         checkSecurity("get_previous_n_sequence", null);

         WfEventAudit[] ret = null;
         List l = super.getNextNSequence(max_number);
         ret = new WfEventAudit[l.size()];
         l.toArray(ret);
         return ret;
      } finally {
         SharkUtilities.methodEnd(shandle,tStamp,
                                  "WfEventAuditIteratorWrapper.get_previous_n_sequence",
                                  this);
      }
   }

   protected void fillObjectList() throws Exception {
      if (objectList != null)
         return;

      List events = new ArrayList();

      EventAuditManagerInterface eam = SharkEngineManager.getInstance()
         .getDefaultEventAuditManager();
      if (null != eam) {
         List l = new ArrayList();
         if (actId == null) {
            l.addAll(eam.restoreProcessHistory(shandle, procId));
         } else {
            l.addAll(eam.restoreActivityHistory(shandle, procId, actId));
         }
         Evaluator evaluator = SharkEngineManager.getInstance()
            .getScriptingManager()
            .getEvaluator(shandle,queryGrammar);

         boolean eVal = queryExpression != null && queryExpression.trim().length() > 0;

         for (int i = 0; i < l.size(); i++) {
            EventAuditPersistenceInterface po = (EventAuditPersistenceInterface) l.get(i);
            boolean toAdd = true;
            if (eVal) {
               Map context = new HashMap();
               context.put(SharkConstants.EA_TIME_STAMP, new Long(po.getRecordedTime()));
               context.put(SharkConstants.EA_USERNAME, new Long(po.getUsername()));
               context.put(SharkConstants.EA_EVENT_TYPE, po.getType());
               context.put(SharkConstants.EA_ACTIVITY_KEY, po.getActivityId());
               context.put(SharkConstants.EA_ACTIVITY_NAME, po.getActivityName());
               context.put(SharkConstants.EA_PROCESS_KEY, po.getProcessId());
               context.put(SharkConstants.EA_PROCESS_NAME, po.getProcessName());
               context.put(SharkConstants.EA_PROCESS_MGR_NAME,
                           po.getProcessFactoryName());
               context.put(SharkConstants.EA_PROCESS_MGR_VERSION,
                           po.getProcessFactoryVersion());
               context.put(SharkConstants.EA_PACKAGE_ID, po.getPackageId());
               context.put(SharkConstants.EA_PROCESS_DEFINITION_ID,
                           po.getProcessDefinitionId());
               context.put(SharkConstants.EA_PROCESS_DEFINITION_NAME,
                           po.getProcessDefinitionName());
               context.put(SharkConstants.EA_ACTIVITY_DEFINITION_ID,
                           po.getActivityDefinitionId());
               context.put(SharkConstants.EA_ACTIVITY_DEFINITION_NAME,
                           po.getActivityDefinitionName());
               context.put(SharkConstants.EA_ACTIVITY_DEFINITION_TYPE,
                           new Integer(po.getActivityDefinitionType()));

               if (po instanceof CreateProcessEventAuditPersistenceObject) {
                  CreateProcessEventAuditPersistenceObject cpo = (CreateProcessEventAuditPersistenceObject) po;
                  
                  context.put(SharkConstants.CEA_P_ACTIVITY_DEFINITION_ID,
                              cpo.getPActivityDefinitionId());
                  context.put(SharkConstants.CEA_P_ACTIVITY_DEFINITION_NAME,
                              cpo.getPActivityDefinitionName());
               } else if (po instanceof DataEventAuditPersistenceObject) {
                  DataEventAuditPersistenceObject dpo = (DataEventAuditPersistenceObject) po;
                  if (queryExpression.indexOf(SharkConstants.DEA_OLD_DATA_) != -1) {
                     Map od = dpo.getOldData();
                     if (od != null) {
                        Iterator it = od.entrySet().iterator();
                        while (it.hasNext()) {
                           Map.Entry me = (Map.Entry) it.next();

                           String name = SharkConstants.DEA_OLD_DATA_
                                         + me.getKey().toString();
                           Object value = me.getValue();
                           context.put(name, value);
                        }
                     }
                  }
                  if (queryExpression.indexOf(SharkConstants.DEA_NEW_DATA_) != -1) {
                     Map nd = dpo.getNewData();
                     if (nd != null) {
                        Iterator it = nd.entrySet().iterator();
                        while (it.hasNext()) {
                           Map.Entry me = (Map.Entry) it.next();

                           String name = SharkConstants.DEA_NEW_DATA_
                                         + me.getKey().toString();
                           Object value = me.getValue();
                           context.put(name, value);
                        }
                     }
                  }

               } else if (po instanceof StateEventAuditPersistenceObject) {
                  StateEventAuditPersistenceObject spo = (StateEventAuditPersistenceObject) po;
                  context.put(SharkConstants.SEA_OLD_STATE, spo.getOldState());
                  context.put(SharkConstants.SEA_NEW_STATE, spo.getNewState());
               } else if (po instanceof AssignmentEventAuditPersistenceObject) {
                  AssignmentEventAuditPersistenceObject apo = (AssignmentEventAuditPersistenceObject) po;
                  context.put(SharkConstants.AEA_OLD_RES, apo.getOldResourceUsername());
                  context.put(SharkConstants.AEA_NEW_RES, apo.getNewResourceUsername());
                  context.put(SharkConstants.AEA_IS_ACCEPTED,
                              new Boolean(apo.getIsAccepted()));
               }

               toAdd = evaluator.evaluateCondition(shandle,
                                                   po.getProcessId(),
                                                   po.getActivityId(),
                                                   queryExpression,
                                                   context);
            }
            if (toAdd) {
               if (po instanceof CreateProcessEventAuditPersistenceObject) {
                  events.add(SharkEngineManager.getInstance()
                     .getObjectFactory()
                     .createCreateProcessEventAuditWrapper(shandle,
                                                           (CreateProcessEventAuditPersistenceObject) po));
               } else if (po instanceof DataEventAuditPersistenceObject) {
                  events.add(SharkEngineManager.getInstance()
                     .getObjectFactory()
                     .createDataEventAuditWrapper(shandle,
                                                  (DataEventAuditPersistenceObject) po));
               } else if (po instanceof StateEventAuditPersistenceObject) {
                  events.add(SharkEngineManager.getInstance()
                     .getObjectFactory()
                     .createStateEventAuditWrapper(shandle,
                                                   (StateEventAuditPersistenceObject) po));
               } else if (po instanceof AssignmentEventAuditPersistenceObject) {
                  events.add(SharkEngineManager.getInstance()
                     .getObjectFactory()
                     .createAssignmentEventAuditWrapper(shandle,
                                                        (AssignmentEventAuditPersistenceObject) po));
               }
            }
         }

      }

      setObjectList(events);
   }

}
