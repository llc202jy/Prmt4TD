This is a factoring out of the liveness checking; a class that
 * reads in the URL details from its attributes, and configures a liveness
 * page checker from these values.
 */
public abstract class AbstractLivenessPageComponent extends PrimImpl implements HttpAttributes {

    /**
     * the class that contains all the checking code. This is on the side for
     * reuse in other components.
     */
    protected LivenessPageChecker livenessPage;


    protected AbstractLivenessPageComponent() throws RemoteException {
    }


    public LivenessPageChecker getLivenessPage() {
        return livenessPage;
    }

    /**
     * Create and configure the LivenessChecker from the attributes of the component
     * @throws RemoteException network problems
     * @throws SmartFrogException smartfrog problems
     */
    protected void buildLivenessChecker() throws
            RemoteException,
            SmartFrogException {
        livenessPage = new LivenessPageChecker(this);

        String url = sfResolve(ATTR_URL, (String) null, false);

        if (url != null) {
            livenessPage.bindToURL(url);
        } else {
            livenessPage.setHost(sfResolve(ATTR_HOST,
                    livenessPage.getHost(),
                    false));
            livenessPage.setPort(sfResolve(ATTR_PORT,
                    livenessPage.getPort(),
                    false));
            livenessPage.setProtocol(sfResolve(ATTR_PROTOCOL,
                    livenessPage.getProtocol(), false));
            livenessPage.setPath(sfResolve(ATTR_PATH,
                livenessPage.getPath(),
                false));
            livenessPage.setPage(sfResolve(ATTR_PAGE,
                    livenessPage.getPage(),
                    false));
            buildLivenessPageAuthentication();
            buildLivenessPageQueryString();
        }

        Vector mimeTypes = sfResolve(ATTR_MIME_TYPES, (Vector) null, false);
        livenessPage.setMimeTypes(mimeTypes);
        livenessPage.setMinimumResponseCode(sfResolve(ATTR_MINIMUM_RESPONSE_CODE,
                0,true));
        livenessPage.setMaximumResponseCode(sfResolve(ATTR_MAXIMUM_RESPONSE_CODE,
                0, true));
        livenessPage.setFollowRedirects(sfResolve(ATTR_FOLLOW_REDIRECTS,
                livenessPage.getFollowRedirects(), false));
        livenessPage.setFetchErrorText(sfResolve(ATTR_ERROR_TEXT,
                livenessPage.getFetchErrorText(), false));

        //header vector
        Vector<Vector<String>> headers;
        headers= ListUtils.resolveStringTupleList(this,new Reference(ATTR_HEADERS),true);
        livenessPage.setHeaders(headers);

        livenessPage.setConnectTimeout(sfResolve(ATTR_CONNECT_TIMEOUT,0,true));



        //now tell the liveness page it is deployed
        livenessPage.onStart();
        if (url == null) {
            //set the URL if it was not already set
            URL targetURL = livenessPage.getTargetURL();
            sfReplaceAttribute(ATTR_URL, targetURL.toString());
        }
    }
Thread _thread = null;

  long timeToLive = 0;

  static SplashScreen screen = null;

  /**
   * Hides the actually shown slashscreen.
   */
  public static void hideSplashScreen( ) {
    if (screen != null ) {
      if (screen._thread != null) {
	screen.timeToLive = -1;
	try {
	  screen._thread.interrupt();
	} catch ( Throwable t ) {
	}
      }
      screen.dispose();
      screen = null;
    }
  }

  /**
   * Show the splashscreen.
   * Only one splashscreen canbe shown at one time.
   * Creation of another one automatically hides the old one.
   * @param imagfe the image to display.
   * @param millis Milliseconds to show. 
   *        If <= 0, the splashscreen will only be hidden with <i>hideSplashScreen</i>.
   */
  public SplashScreen( Frame parent, Image image, long millis  ) {
    super( parent );
    hideSplashScreen( );
    screen = this;
    _image = image;
    timeToLive = millis;
    ImageCanvas canvas = new ImageCanvas( _image );
    add( canvas, BorderLayout.CENTER );

    Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();
    int imagewidth = _image.getWidth( this );
    int imageheight = _image.getHeight( this );
    
    setLocation( screensize.width/2 - ( imagewidth / 2 ),
		 screensize.height/2 - ( imageheight / 2 ) );
    setSize( imagewidth, imageheight );
    show();
    toFront();

    if (timeToLive > 0 ) {
      _thread = new Thread( this );
      _thread.start();
    }
  }
  
  public void run() {
    try { 

      Thread.currentThread().sleep( timeToLive ); 

    } catch( Exception e ) { 
    }
    _thread = null;
    if (timeToLive > 0) {
      timeToLive = -1;
      dispose();
    }

*/*/
    protected static Prim Deploy(String url, String appName, Prim parent, Compound target,
                              Context context, Reference deployReference, boolean start) throws SmartFrogException, RemoteException {

        //First thing first: system gets initialized
        //Protect system if people use this as entry point
        try {
            org.smartfrog.SFSystem.initSystem();
        } catch (Exception ex) {
            throw SmartFrogException.forward(ex);
        }


        Prim comp = null;
        //To calculate how long it takes to deploy a description
        long beginTime;
        long deployTime = 0;
        long startTime = 0;
        long parseTime;

        beginTime = System.currentTimeMillis();
        if (context == null) {
            context = new ContextImpl();
        }

        // Checks if 'parent' is a processCompound. If parent is a process compound
        // the parentage is made null and it is registered as an attribute, not a
        // child, so it is a root component and starts is own liveness
        if ((parent != null) && (parent instanceof ProcessCompound)) {
            // This component will be a root component
            parent = null;

        } else if ((parent != null) && (parent instanceof Compound) && (appName == null)) {
            //From ProcessCompoundImpl. Creates  name for unnamed components...
//             appName = SmartFrogCoreKeys.SF_UNNAMED + (new Date()).getTime() + "_" +
//                ProcessCompoundImpl.registrationNumber++;

        }
        // This is needed so that the root component is properly named
        // when registering with the ProcessCompound
        if ((parent == null) && (appName != null)) {
            context.put("sfProcessComponentName", appName);
        }

        // The processCompound/Compound is used to do the deployment!
        if ((parent != null) && (parent instanceof Compound)) {
            target = (Compound) parent;
        }

        //select the language first from the context, then from the URL itself
        String language;
        language=(String) context.get(SmartFrogCoreKeys.KEY_LANGUAGE);
        if(language==null) {
            language=url;
        }


        ComponentDescription cd;
        try {
            cd = ComponentDescriptionImpl.sfComponentDescription(url, language, null, deployReference);
            parseTime = System.currentTimeMillis();

        } catch (SmartFrogException sfex) {
            if (sfex instanceof SmartFrogDeploymentException) {
                throw sfex;
            } else {
                throw new SmartFrogDeploymentException(
                        "deploying description '" + url + "' for '" + appName + "'",
                        sfex,
                        comp,
                        context);
            }
        }
      