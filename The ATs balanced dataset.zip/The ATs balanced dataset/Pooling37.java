class Akshay
{
    static void Main()
    {
        // Start the task executing:
        Task<string> task = Task.Factory.StartNew<string>
        (() => DownloadString("http://www.c-sharpcorner.com/"));
        // We can do other work here and it will execute in parallel:
       //RunSomeOtherMethod();
        // When we need the task's return value, we query its Result property:
        // If it's still executing, the current thread will now block (wait)
        // until the task finishes:
        string result = task.Result;
    }
    static string DownloadString(string uri)
    {
        using (var wc = new System.Net.WebClient())
            return wc.DownloadString(uri);
        Console.Read();
    }
} using System;
using System.Threading;
using System.Diagnostics;
public class Akshay
{
      public int id;
      public Akshay(int _id)
      {
          id = _id;
      }
}
class Class1
{
      public int QueueLength;
      public Class1()
      {
          QueueLength = 0;
      }
      public void Produce(Akshay ware)
      {
          ThreadPool.QueueUserWorkItem(
          new WaitCallback(Consume), ware);
          QueueLength++;
      }
      public void Consume(Object obj)
      {
          Console.WriteLine("Thread {0} consumes {1}",
          Thread.CurrentThread.GetHashCode(), //{0}
          ((Akshay)obj).id); //{1}
          Thread.Sleep(100);
          QueueLength--;
      }
      public static void Main(String[] args)
      {
          Class1 obj = new Class1();
          for (int i = 0; i < 100; i++)
          {
               obj.Produce(new Akshay(i));
          }
         Console.WriteLine("Thread {0}",
         Thread.CurrentThread.GetHashCode() ); //{0}
         while (obj.QueueLength != 0)
         {
               Thread.Sleep(1000);
          }
          Console.Read();
     }
}


 {
      private bool WaitForComplete;
      private ManualResetEvent Event;
      public int QueueLength;
      public int id;
      public Akshay(int _id)
      {
           id = _id;
      }
      public void Wait()
      {
          if (QueueLength == 0)
          {
               return;
          }   
          Event = new ManualResetEvent(false);
          WaitForComplete = true;
          Event.WaitOne();
     }
     public void Consume(Object obj)
     {
          Console.WriteLine("Thread {0} consumes {1}",
          Thread.CurrentThread.GetHashCode(), //{0}
          ((Akshay)obj).id); //{1}
          Thread.Sleep(100);
          QueueLength--;
          if (WaitForComplete)
          {
               if (QueueLength == 0)
               {
                    Event.Set();
               }
          };
     }
}