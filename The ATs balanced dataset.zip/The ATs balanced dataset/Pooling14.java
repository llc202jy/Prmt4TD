namespace BehaviorAILibrary.DecisionLayer
{
    public class NeuroBrain : IBrain
    {
        private NeuroTeacher teacher;
        private INeuralNetwork network;
        private PriorityQueue memory = new PriorityQueue();        
        private BotKing king;
        private PoolingStation station;
        private PoolingManager pooling;
        private Estimator estimator;
        private CreationContext creationContext;
       
        public NeuroBrain(BotKing king, NeuroTeacher teacher, PoolingStation station)
        {
            this.king = king;
            this.teacher = teacher;
            this.station = station;
            this.pooling = new PoolingManager(king);
            this.estimator = new Estimator(teacher, memory);
            this.creationContext = new CreationContext(king, teacher, pooling, memory);

            WanderGoal w = new WanderGoal(this.king);
            w.Priority = 10;
            memory.Enqueue(w);
        }

        public virtual void Dispose()
        {

        }

        public void Process()
        {
            Goal currentGoal = memory.Peek();
            GoalStatuses status = currentGoal.Process();
            if (status == GoalStatuses.Completed || status == GoalStatuses.Failed)
            {
                currentGoal.Terminate();
                memory.Dequeue();
            }
        }

        public virtual void Think()
        {
            pooling.Pool(station);
            PrepareData();
            network.FeedForward();

            //FAKE
            if (pooling.MinDistanceToEnemyKing < 10 && pooling.MinDistanceToEnemyKing > 0)
            {
                Type type = estimator.EvaluateGoal(network);
                if (estimator.RequiredToCreate(type))
                    memory.Enqueue(estimator.GetRequiredFactory(network).Create(creationContext));
            }
        }

        private void PrepareData()
        {
            network.SetInput(teacher.GetInputNumber(InputState.DistanceToEnemyCastle), pooling.MinDistanceToEnemyCastle);
            network.SetInput(teacher.GetInputNumber(InputState.DistanceToEnemyKing), pooling.MinDistanceToEnemyKing);
            network.SetInput(teacher.GetInputNumber(InputState.DistanceToPlayerCastle), pooling.MinDistanceToPlayerCastle);
            network.SetInput(teacher.GetInputNumber(InputState.EnemyUnitsCountInsideCastle), pooling.UnitsCountInsideEnemyCastle);
            network.SetInput(teacher.GetInputNumber(InputState.EnemyUnitsCountTogetherWithKing), pooling.UnitsCountTogetherWithEnemyKing);
            network.SetInput(teacher.GetInputNumber(InputState.ResourceCountInVisibleArea), pooling.ResourceCountInVisibleArea);
            network.SetInput(teacher.GetInputNumber(InputState.ResourceCountOnHand), pooling.ResourceCountOnHand);
        }

        public INeuralNetwork NN
        {
            get
            {
                return network;
            }
            set
            {
                network = value;
            }
        }

    }//end NeuroBrain

}//end namespace DecisionLayer