package osid.shared;

/**
    The Group may contain Members (Agents) as well as other Groups.  There are management methods for adding, removing, and getting members and Groups.  There are also methods for testing if a Group or member is contained in a Group, and returning all Members in a Group, all Groups in a Group, or all Groups containing a specific Member. Many methods include an argument that specifies whether to include all subgroups or not.  This allows for more flexible maintenance and interrogation of the structure. Note that there is no specification for persisting the Group or its content -- this detail is left to the implementation. <p>Licensed under the {@link osid.SidLicense MIT O.K.I&#46; SID Definition License}. <p>SID Version: 1.0 rc6
*/
public interface Group
extends Agent
{

    /**
    Update the Description of this Group as stored.
    @param description
    @throws osid.shared.SharedException An exception with one of the following messages defined in osid.shared.SharedException:  {@link osid.shared.SharedException#OPERATION_FAILED OPERATION_FAILED}, {@link osid.shared.SharedException#PERMISSION_DENIED PERMISSION_DENIED}, {@link osid.shared.SharedException#CONFIGURATION_ERROR CONFIGURATION_ERROR}, {@link osid.shared.SharedException#UNIMPLEMENTED UNIMPLEMENTED}, {@link osid.shared.SharedException#NULL_ARGUMENT NULL_ARGUMENT}
    */
    void updateDescription(String description)
    throws osid.shared.SharedException;

    /**
    Get the Description of this Group as stored.
    @return String
    @throws osid.shared.SharedException An exception with one of the following messages defined in osid.shared.SharedException:  {@link osid.shared.SharedException#OPERATION_FAILED OPERATION_FAILED}, {@link osid.shared.SharedException#PERMISSION_DENIED PERMISSION_DENIED}, {@link osid.shared.SharedException#CONFIGURATION_ERROR CONFIGURATION_ERROR}, {@link osid.shared.SharedException#UNIMPLEMENTED UNIMPLEMENTED}
    */
    String getDescription()
    throws osid.shared.SharedException;

    /**
    Get the Unique Id of this Group as stored.
    @return Id
    @throws osid.shared.SharedException An exception with one of the following messages defined in osid.shared.SharedException:  {@link osid.shared.SharedException#OPERATION_FAILED OPERATION_FAILED}, {@link osid.shared.SharedException#PERMISSION_DENIED PERMISSION_DENIED}, {@link osid.shared.SharedException#CONFIGURATION_ERROR CONFIGURATION_ERROR}, {@link osid.shared.SharedException#UNIMPLEMENTED UNIMPLEMENTED}
    */
    Id getId()
    throws osid.shared.SharedException;

    /**
    Get the DisplayName of this Group as stored.
    @return the String
    @throws osid.shared.SharedException An exception with one of the following messages defined in osid.shared.SharedException:  {@link osid.shared.SharedException#OPERATION_FAILED OPERATION_FAILED}, {@link osid.shared.SharedException#PERMISSION_DENIED PERMISSION_DENIED}, {@link osid.shared.SharedException#CONFIGURATION_ERROR CONFIGURATION_ERROR}, {@link osid.shared.SharedException#UNIMPLEMENTED UNIMPLEMENTED}
    */
    public String getDisplayName()
    throws osid.shared.SharedException;

    /**
    Update the Type of this Group as stored.
    @return Type
    @throws osid.shared.SharedException An exception with one of the following messages defined in osid.shared.SharedException:  {@link osid.shared.SharedException#OPERATION_FAILED OPERATION_FAILED}, {@link osid.shared.SharedException#PERMISSION_DENIED PERMISSION_DENIED}, {@link osid.shared.SharedException#CONFIGURATION_ERROR CONFIGURATION_ERROR}, {@link osid.shared.SharedException#UNIMPLEMENTED UNIMPLEMENTED}
    */
    public osid.shared.Type getType()
    throws osid.shared.SharedException;

    /**
    Add an Agent member or a Group to this Group.  The Member or Group will not be added if it already exists in the group.
    @param memberOrGroup
    @throws osid.shared.SharedException An exception with one of the following messages defined in osid.shared.SharedException:  {@link osid.shared.SharedException#OPERATION_FAILED OPERATION_FAILED}, {@link osid.shared.SharedException#PERMISSION_DENIED PERMISSION_DENIED}, {@link osid.shared.SharedException#CONFIGURATION_ERROR CONFIGURATION_ERROR}, {@link osid.shared.SharedException#UNIMPLEMENTED UNIMPLEMENTED}, {@link osid.shared.SharedException#ALREADY_ADDED ALREADY_ADDED}, {@link osid.shared.SharedException#NULL_ARGUMENT NULL_ARGUMENT}
    */
    void add(Agent memberOrGroup)
    throws osid.shared.SharedException;

    /**
    Remove an Agent member or a Group from this Group. If the Member or Group is not in the group no action is taken and no exception is thrown.
    @param memberOrGroup
    @throws osid.shared.SharedException An exception with one of the following messages defined in osid.shared.SharedException:  {@link osid.shared.SharedException#OPERATION_FAILED OPERATION_FAILED}, {@link osid.shared.SharedException#PERMISSION_DENIED PERMISSION_DENIED}, {@link osid.shared.SharedException#CONFIGURATION_ERROR CONFIGURATION_ERROR}, {@link osid.shared.SharedException#UNIMPLEMENTED UNIMPLEMENTED}, {@link osid.shared.SharedException#UNKNOWN_ID UNKNOWN_ID}, {@link osid.shared.SharedException#NULL_ARGUMENT NULL_ARGUMENT}
    */
    void remove(Agent memberOrGroup)
    throws osid.shared.SharedException;

    /**
    Get all the Members of this group and optionally all the Members from all subgroups. Duplicates are not returned.
    @param includeSubgroups
    @return AgentIterator
    @throws osid.shared.SharedException An exception with one of the following messages defined in osid.shared.SharedException:  {@link osid.shared.SharedException#OPERATION_FAILED OPERATION_FAILED}, {@link osid.shared.SharedException#PERMISSION_DENIED PERMISSION_DENIED}, {@link osid.shared.SharedException#CONFIGURATION_ERROR CONFIGURATION_ERROR}, {@link osid.shared.SharedException#UNIMPLEMENTED UNIMPLEMENTED}
    */
    AgentIterator getMembers(boolean includeSubgroups)
    throws osid.shared.SharedException;

    /**
    Get all the Groups in this group and optionally all the subgroups in this group. Note since Groups subclass Agents, we are returning an AgentIterator and there is no GroupIterator.
    @param includeSubgroups
    @return AgentIterator
    @throws osid.shared.SharedException An exception with one of the following messages defined in osid.shared.SharedException:  {@link osid.shared.SharedException#OPERATION_FAILED OPERATION_FAILED}, {@link osid.shared.SharedException#PERMISSION_DENIED PERMISSION_DENIED}, {@link osid.shared.SharedException#CONFIGURATION_ERROR CONFIGURATION_ERROR}, {@link osid.shared.SharedException#UNIMPLEMENTED UNIMPLEMENTED}
    */
