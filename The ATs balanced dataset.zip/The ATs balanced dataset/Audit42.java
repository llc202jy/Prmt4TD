package org.mifos.framework.components.audit.business.service;

import java.util.ArrayList;
import java.util.List;

import org.mifos.framework.business.BusinessObject;
import org.mifos.framework.business.service.BusinessService;
import org.mifos.framework.components.audit.business.AuditLog;
import org.mifos.framework.components.audit.business.AuditLogRecord;
import org.mifos.framework.components.audit.persistence.AuditPersistence;
import org.mifos.framework.components.audit.util.helpers.AuditConstants;
import org.mifos.framework.components.audit.util.helpers.AuditLogView;
import org.mifos.framework.exceptions.PersistenceException;
import org.mifos.framework.exceptions.ServiceException;
import org.mifos.framework.security.util.UserContext;

public class AuditBusinessService extends BusinessService {

	@Override
	public BusinessObject getBusinessObject(UserContext userContext) {
		return null;
	}

	public List<AuditLogView> getAuditLogRecords(Short entityType,
			Integer entityId) throws ServiceException {
		try {
			AuditPersistence auditPersistence = new AuditPersistence();
			List<AuditLog> auditLogRecords = auditPersistence
					.getAuditLogRecords(entityType, entityId);
			List<AuditLogView> auditLogViewList = new ArrayList<AuditLogView>();
			for (AuditLog auditLog : auditLogRecords) {
				for (AuditLogRecord auditLogRecord : auditLog
						.getAuditLogRecords()) {
					AuditLogView auditLogView = new AuditLogView();
					auditLogView.setDate(auditLog.getUpdatedDate().toString());
					auditLogView.setUser(auditLog.getModifierName());
					auditLogView.setField(auditLogRecord.getFieldName());
					if(auditLogRecord.getFieldName().equals(AuditConstants.Audit_PASSWORD)){
						auditLogView.setOldValue(AuditConstants.HIDDEN_PASSWORD);
						auditLogView.setNewValue(AuditConstants.HIDDEN_PASSWORD);
					}
					else{
						auditLogView.setOldValue(auditLogRecord.getOldValue());
						auditLogView.setNewValue(auditLogRecord.getNewValue());
					}
					auditLogViewList.add(auditLogView);
				}
			}
			return auditLogViewList;
		} catch (PersistenceException e) {
			throw new ServiceException(e);
		}

	}

}
package org.mifos.framework.hibernate.helper;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.mifos.framework.components.audit.util.helpers.AuditInterceptor;

public class SessionHolder {

	private final Session session;
	private Transaction transaction=null;
	private AuditInterceptor interceptor = null;
	
	public SessionHolder(Session session) {
		this.session = session;
		if (session == null) {
			throw new NullPointerException("session is required");
		}
		//interceptor = new AuditInterceptor();
	}
	
	public Transaction startTransaction() {
		if (transaction == null) {
			transaction = session.beginTransaction();
		}
		
		return transaction;
	}
	
	public void setTranasction(Transaction transaction) {
		this.transaction=transaction;
	}
	
	public Transaction getTransaction() {
		return transaction;	
	}
	
	public Session getSession() {
		return session;
	}
	
	public void setInterceptor(AuditInterceptor auditInterceptor){
		this.interceptor=auditInterceptor;
	}
	
	public AuditInterceptor getInterceptor(){
		return interceptor;
	}

	public void close() {
	}

package org.mifos.framework.components.audit.business;

import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import org.mifos.application.util.helpers.EntityType;
import org.mifos.framework.business.PersistentObject;
import org.mifos.framework.components.audit.persistence.AuditPersistence;

public class AuditLog extends PersistentObject {

	private final Integer id;

	private final Integer entityId;
	
	private final Short entityType;

	private final String modifierName;

	private final Set<AuditLogRecord> auditLogRecords;
	

	protected AuditLog() {
		id = null;
		entityId = null;
		entityType=null;
		modifierName = null;
		auditLogRecords = null;
	}

	public AuditLog(Integer entityId,Short entityType,String modifierName,
			Date updatedDate, Short updatedBy) {
		this.id = null;
		this.entityId = entityId;
		this.entityType=entityType;
		this.modifierName = modifierName;
		this.updatedDate = updatedDate;
		this.updatedBy = updatedBy;
		this.auditLogRecords = new HashSet<AuditLogRecord>();
	}

	public Set<AuditLogRecord> getAuditLogRecords() {
		return auditLogRecords;
	}

	public Integer getEntityId() {
		return entityId;
	}

	public Integer getId() {
		return id;
	}

	public String getModifierName() {
		return modifierName;
	}
	
	public Short getEntityType() {
		return entityType;
	}

	public EntityType getEntityTypeAsEnum() {
		return EntityType.fromInt(entityType);
	}

	public void addAuditLogRecords(Set<AuditLogRecord> auditLogRecords){
		this.auditLogRecords.addAll(auditLogRecords);	
	}
	
	public void save(){
		new AuditPersistence().save(this);
	}

}

package org.mifos.framework.components.audit.persistence;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.mifos.application.NamedQueryConstants;
import org.mifos.framework.components.audit.business.AuditLog;
import org.mifos.framework.exceptions.PersistenceException;
import org.mifos.framework.hibernate.helper.HibernateUtil;
import org.mifos.framework.persistence.Persistence;

public class AuditPersistence extends Persistence {

	public void save(AuditLog auditLog) {
		Session session = null;
		Transaction txn = null;
		try {
			session = HibernateUtil.openSession();
			txn = session.beginTransaction();
			session.save(auditLog);
			txn.commit();
		} catch (Exception e) {
			txn.rollback();
			throw new RuntimeException(e);
		} finally {
			try {
				HibernateUtil.closeSession(session);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public List<AuditLog> getAuditLogRecords(Short entityType, Integer entityId)
			throws PersistenceException {
		Map<Object, Object> queryParameter = new HashMap<Object, Object>();
		queryParameter.put("entityType", entityType);
		queryParameter.put("entityId", entityId);
		return executeNamedQuery(
				NamedQueryConstants.RETRIEVE_AUDIT_LOG_RECORD, queryParameter);
	}

}

package org.mifos.framework.components.audit.business;

import org.mifos.framework.business.PersistentObject;

public class AuditLogRecord extends PersistentObject {

	private final Integer squenceNo;

	private final String fieldName;

	private final String oldValue;

	private final String newValue;

	@SuppressWarnings("unused") // see .hbm.xml file
	private final AuditLog auditLog;

	protected AuditLogRecord() {
		squenceNo = null;
		fieldName = null;
		oldValue = null;
		newValue = null;
		auditLog = null;
	}

	public AuditLogRecord(String fieldName, String oldValue, String newValue,
			AuditLog auditLog) {
		this.squenceNo = null;
		this.fieldName = fieldName;
		this.oldValue = oldValue;
		this.newValue = newValue;
		this.auditLog = auditLog;
	}

	public String getFieldName() {
		return fieldName;
	}

	public String getNewValue() {
		return newValue;
	}

	public String getOldValue() {
		return oldValue;
	}

	public Integer getSquenceNo() {
		return squenceNo;
	}

}

package org.mifos.framework.components.audit.util.helpers;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.EntityMode;
import org.hibernate.Interceptor;
import org.hibernate.Transaction;
import org.hibernate.type.Type;
import org.mifos.application.util.helpers.EntityType;
import org.mifos.framework.business.BusinessObject;
import org.mifos.framework.components.audit.business.AuditLog;
import org.mifos.framework.components.audit.business.AuditLogRecord;
import org.mifos.framework.security.util.UserContext;

/*
 * For Hibernate 3.2.2 or so, we'd just extend EmptyInterceptor.
 * But that doesn't exist in 3.0 beta4.
 */
public class AuditInterceptor implements Interceptor {

	private AuditLog auditLog;
	private InterceptHelper interceptHelper;
	private UserContext userContext;
	private Boolean flag=false;


	public AuditInterceptor() {
		interceptHelper = new InterceptHelper();
	}

	public  void createInitialValueMap(Object object){
		userContext=((BusinessObject)object).getUserContext();
		interceptHelper.hibernateMeta(object,AuditConstants.TRANSACTIONBEGIN);
	}
	
	public void createChangeValueMap(Object object){
		if(interceptHelper.getEntityName().equals(AuditConfigurtion.getEntityToClassPath(object.getClass().getName())))
			interceptHelper.hibernateMeta(object,AuditConstants.TRANSACTIONEND);
	}
	
	public boolean isAuditLogRequired(){
		if(interceptHelper.isInitialValueMapEmpty())
			return false;
		return true;
	}
	
	public void beforeTransactionCompletion(Transaction tx) {
	}

	public boolean onSave(Object arg0, Serializable arg1, Object[] arg2,
			String[] arg3, Type[] arg4) {
		return false;
	}

	public void onDelete(Object arg0, Serializable arg1, Object[] arg2,
			String[] arg3, Type[] arg4) {
	}

	public void preFlush(Iterator arg0) {
	}

	public void postFlush(Iterator arg0) {
	}

	public Boolean isTransient(Object arg0) {
		return null;
	}

	public int[] findDirty(Object entity, Serializable id,
			Object[] currentState, Object[] previousState,
			String[] propertyNames, Type[] types) {
		return null;
	}

	public Object instantiate(String entityName, EntityMode entityMode,
			Serializable id) {
		return null;
	}

	public String getEntityName(Object arg) {
		return null;
	}

	public Object getEntity(String arg0, Serializable arg1) {
		return null;
	}
		
	public boolean onLoad(Object arg0, Serializable arg1, Object[] arg2,
			String[] arg3, Type[] arg4) {
		return false;
	}

	public void afterTransactionBegin(Transaction tx) {
	}

	public boolean onFlushDirty(Object entity, Serializable id,
			Object[] currentState, Object[] previousState,
			String[] propertyNames, Type[] types) {
		return false;
	}
	
	public void afterTransactionCompletion(Transaction tx) {
		if(tx!=null && tx.wasCommitted() && !tx.wasRolledBack())
			flag=true;
		if (tx==null && flag && ((interceptHelper.getInitialValueMap() != null
				&& interceptHelper.getInitialValueMap().size() > 0) || 
				(interceptHelper.getChangeValueMap() != null
						&& interceptHelper.getChangeValueMap().size() > 0))) {
			auditLog = new AuditLog(interceptHelper.getEntityId(), EntityType
					.getEntityValue(interceptHelper.getEntityName().toUpperCase()),
					userContext.getName(),
					new Date(System.currentTimeMillis()), userContext.getId());
			Set<AuditLogRecord> auditLogRecords = createAuditLogRecord();
			auditLog.addAuditLogRecords(auditLogRecords);
			if (!auditLogRecords.isEmpty()) {
				auditLog.save();
			}
		}
	}
	
	private Set<AuditLogRecord> createAuditLogRecord() {
		Set<AuditLogRecord> auditLogRecords=new HashSet<AuditLogRecord>();
		Set set=interceptHelper.getPropertyNames().keySet();
		Iterator iterator=set.iterator();
		while(iterator.hasNext()){
			AuditLogRecord auditLogRecord=null;
			Object key=iterator.next();
			if((key.toString()).toLowerCase().contains(AuditConstants.VERSIONNO)
					|| (key.toString()).toLowerCase().contains(AuditConstants.CREATEDBY)
					|| (key.toString()).toLowerCase().contains(AuditConstants.CREATEDDATE)
					||(key.toString()).toLowerCase().contains(AuditConstants.UPDATEDBY)
					||(key.toString()).toLowerCase().contains(AuditConstants.UPDATEDDATE)
					||(key.toString()).toLowerCase().contains(AuditConstants.LOOKUPID)){
				continue;
			}
			if (interceptHelper.getInitialValue(key)  != null 
					&& !interceptHelper.getInitialValue(key).toString().trim().equals("")
					&& interceptHelper.getChangeValue(key) == null 
					&& !interceptHelper.getPropertyName(key).toString().equalsIgnoreCase(XMLConstants.DONOTLOGTHISPROPERTY) ) {
				auditLogRecord = new AuditLogRecord(interceptHelper
						.getPropertyName(key).toString().trim(),removeComma(interceptHelper
						.getInitialValue(key).toString()), "-", auditLog);
				auditLogRecords.add(auditLogRecord);
			} else if (interceptHelper.getInitialValue(key) == null
					&& interceptHelper.getChangeValue(key) != null
					&& !interceptHelper.getChangeValue(key).toString().equals("")
					&& !interceptHelper.getPropertyName(key).toString().equalsIgnoreCase(XMLConstants.DONOTLOGTHISPROPERTY)) {
				auditLogRecord = new AuditLogRecord(interceptHelper
						.getPropertyName(key).toString().trim(), "-",
						removeComma(interceptHelper.getChangeValue(key)
								.toString()), auditLog);
				auditLogRecords.add(auditLogRecord);
			} else if (interceptHelper.getChangeValue(key) != null
					&& interceptHelper.getInitialValue(key) != null
					&& !(interceptHelper.getChangeValue(key).toString()).equals(interceptHelper.getInitialValue(key).toString())
					&& (compareSet(interceptHelper.getInitialValue(key).toString(),interceptHelper.getChangeValue(key).toString())==false) 
					&& !interceptHelper.getPropertyName(key).toString().equalsIgnoreCase(XMLConstants.DONOTLOGTHISPROPERTY)) {
				String newValue=null;
				if(interceptHelper.getChangeValue(key).toString().trim().equals("")){
					newValue="-";
				}else{
					newValue=removeComma(interceptHelper.getChangeValue(key).toString());
				}
				String oldValue=null;
				if(interceptHelper.getInitialValue(key).toString().trim().equals("")){
					oldValue="-";
				}else{
					oldValue=removeComma(interceptHelper.getInitialValue(key).toString());
				}
				auditLogRecord=new AuditLogRecord(interceptHelper.getPropertyName(key).toString().trim(),oldValue,newValue,auditLog);
				auditLogRecords.add(auditLogRecord);
			}
		}
		return auditLogRecords;
	}
	

	private boolean compareSet(String initialString,String changeString){
		if(initialString.trim().startsWith(",")){
			initialString=initialString.substring(1,initialString.length()); 
		}
		if(initialString.trim().endsWith(",")){
			initialString=initialString.substring(0,initialString.length()-1); 
		}
		
		if(changeString.trim().startsWith(",")){
			changeString=changeString.substring(1,changeString.length()); 
		}
		if(changeString.trim().endsWith(",")){
			changeString=changeString.substring(0,changeString.length()-1); 
		}
		String[] initialCollectionOfStrings=initialString.split(",");
		String[] changedCollectionOfStrings=changeString.split(",");
		if(initialCollectionOfStrings.length!=changedCollectionOfStrings.length){
			return false;
		}
		int initialCollectionCount=0;
	    int changedCollectionCount=0;
		List<String> initialList = new ArrayList<String>();
		for (int i = 0; i < initialCollectionOfStrings.length; i++) {
			initialList.add(initialCollectionOfStrings[i]);
		}
		List<String> changeList =  new ArrayList<String>();
		for (int i = 0; i < changedCollectionOfStrings.length; i++) {
			changeList.add(changedCollectionOfStrings[i]);
		}
		
	    for (Iterator<String> iter = initialList.iterator(); iter.hasNext();) {
			String  initialValue =  iter.next();
			initialCollectionCount++;
			for (Iterator<String> iterator = changeList.iterator(); iterator.hasNext();) {
				String  changeValue =  iterator.next();
				if(changeValue.equals(initialValue)){
					iterator.remove();
					changedCollectionCount++;
				}
			}
		}
		if(initialCollectionCount==changedCollectionCount){
			return true;
		}
		else{
			return false;
		}
	}
	
	private String removeComma(String string){
		string=string.trim();
		if(string.startsWith(",")){
			string=string.substring(1,string.length()); 
		}
		if(string.endsWith(",")){
			string=string.substring(0,string.length()-1); 
		}
		return string;
	}
	

}
