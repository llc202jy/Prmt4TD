package org.mifos.migration.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{}address1" minOccurs="0"/>
 *         &lt;element ref="{}address2" minOccurs="0"/>
 *         &lt;element ref="{}address3" minOccurs="0"/>
 *         &lt;element ref="{}cityDistrict" minOccurs="0"/>
 *         &lt;element ref="{}state" minOccurs="0"/>
 *         &lt;element ref="{}country" minOccurs="0"/>
 *         &lt;element ref="{}postalCode" minOccurs="0"/>
 *         &lt;element ref="{}telephone" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "address1",
    "address2",
    "address3",
    "cityDistrict",
    "state",
    "country",
    "postalCode",
    "telephone"
})
@XmlRootElement(name = "address")
public class Address {

    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String address1;
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String address2;
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String address3;
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String cityDistrict;
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String state;
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String country;
    protected String postalCode;
    protected String telephone;

    /**
     * Gets the value of the address1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress1() {
        return address1;
    }

    /**
     * Sets the value of the address1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress1(String value) {
        this.address1 = value;
    }

    /**
     * Gets the value of the address2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress2() {
        return address2;
    }

    /**
     * Sets the value of the address2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress2(String value) {
        this.address2 = value;
    }

    /**
     * Gets the value of the address3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress3() {
        return address3;
    }

    /**
     * Sets the value of the address3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress3(String value) {
        this.address3 = value;
    }

    /**
     * Gets the value of the cityDistrict property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCityDistrict() {
        return cityDistrict;
    }

    /**
     * Sets the value of the cityDistrict property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCityDistrict(String value) {
        this.cityDistrict = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
     * Gets the value of the country property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountry() {
        return country;
    }

    /**
     * Sets the value of the country property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountry(String value) {
        this.country = value;
    }

    /**
     * Gets the value of the postalCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostalCode() {
        return postalCode;
    }

    /**
     * Sets the value of the postalCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostalCode(String value) {
        this.postalCode = value;
    }

    /**
     * Gets the value of the telephone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTelephone() {
        return telephone;
    }

    /**
     * Sets the value of the telephone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTelephone(String value) {
        this.telephone = value;
    }

}

package org.mifos.application.holiday.business;

import java.util.Date;

import org.mifos.application.holiday.persistence.HolidayPersistence;
import org.mifos.application.holiday.util.helpers.RepaymentRuleTypes;
import org.mifos.application.holiday.util.resources.HolidayConstants;
import org.mifos.application.util.helpers.YesNoFlag;
import org.mifos.framework.business.BusinessObject;
import org.mifos.framework.exceptions.ApplicationException;
import org.mifos.framework.util.helpers.DateUtils;

public class HolidayBO extends BusinessObject {

	private HolidayPK holidayPK;

	private Date holidayThruDate;

	private String holidayName;

	private Short repaymentRuleId;

	private String repaymentRule;

	private boolean validationEnabled = true;
	
	private Short holidayChangesAppliedFlag;   
	
	public boolean isValidationEnabled() {
		return validationEnabled;
	}

	public void setValidationEnabled(boolean validationEnabled) {
		this.validationEnabled = validationEnabled;
	}

	protected HolidayBO() {
		this.holidayPK = null;
		this.holidayChangesAppliedFlag = YesNoFlag.NO.getValue();
	}

	public HolidayBO(HolidayPK holidayPK, Date holidayThruDate,
			String holidayName, Short localeId, Short repaymentRuleId,
			String repaymentRule) throws ApplicationException {

		this.holidayPK = new HolidayPK();

		if (holidayPK != null) {
			this.holidayPK.setOfficeId(holidayPK.getOfficeId());
			this.holidayPK.setHolidayFromDate(holidayPK.getHolidayFromDate());
		}
		else {
			throw new ApplicationException(
					HolidayConstants.HOLIDAY_CREATION_EXCEPTION);
		}
		this.holidayThruDate = holidayThruDate;
		this.holidayName = holidayName;
		this.repaymentRuleId = repaymentRuleId;
		this.repaymentRule = repaymentRule;
		this.holidayChangesAppliedFlag = YesNoFlag.NO.getValue();
	}

	public HolidayPK getHolidayPK() {
		return this.holidayPK;
	}

	public Short getRepaymentRuleId() {
		return this.repaymentRuleId;
	}

	public Date getHolidayFromDate() {
		return this.holidayPK.getHolidayFromDate();
	}

	public Date getHolidayThruDate() {
		return this.holidayThruDate;
	}

	public String getHolidayName() {
		return this.holidayName;
	}

	public void setHolidayPK(HolidayPK holidayPK) {
		this.holidayPK = holidayPK;
	}

	@SuppressWarnings("unused")
	// see .hbm.xml file
	private void setRepaymentRuleId(Short repaymentRuleId) {
		this.repaymentRuleId = repaymentRuleId;
	}

	@SuppressWarnings("unused")
	// see .hbm.xml file
	private void setHolidayFromDate(Date holidayFromDate) {
		this.holidayPK.setHolidayFromDate(holidayFromDate);
	}

	@SuppressWarnings("unused")
	// see .hbm.xml file
	private void setHolidayThruDate(Date holidayThruDate) {
		this.holidayThruDate = holidayThruDate;
	}

	@SuppressWarnings("unused")
	// see .hbm.xml file
	private void setHolidayName(String holidayName) {
		this.holidayName = holidayName;
	}
	
	public Short getHolidayChangesAppliedFlag() {
		return holidayChangesAppliedFlag;
	}

	public void setHolidayChangesAppliedFlag(Short flag) {
		this.holidayChangesAppliedFlag = flag;
	}

	public void save() throws ApplicationException {
		if (this.getHolidayThruDate() == null) {
			this.setHolidayThruDate(this.getHolidayFromDate());
		}
		
		if(isValidationEnabled()) {
			this.validateFromDateAgainstCurrentDate(this.getHolidayFromDate());
			this.validateFromDateAgainstThruDate(this.getHolidayFromDate(), this.getHolidayThruDate());
		}

		new HolidayPersistence().createOrUpdate(this);
	}

	public void update(HolidayPK holidayPK, Date holidayThruDate,
			String holidayName) throws ApplicationException {
		this.holidayName = holidayName;
		this.holidayPK.setOfficeId(holidayPK.getOfficeId());
		this.holidayPK.setHolidayFromDate(holidayPK.getHolidayFromDate());

		if (this.getHolidayThruDate() == null) {
			this.setHolidayThruDate(this.getHolidayFromDate());
		}

		if(isValidationEnabled()) {
			this.validateFromDateAgainstCurrentDate(this.getHolidayFromDate());
			this.validateFromDateAgainstThruDate(this.getHolidayFromDate(), this.getHolidayThruDate());
		}
		
		if(this.getRepaymentRuleId().equals(RepaymentRuleTypes.SAME_DAY.getValue()))
			this.setHolidayChangesAppliedFlag(YesNoFlag.YES.getValue());
		
		new HolidayPersistence().createOrUpdate(this);
		
		//this block should not be here
		//HolidayUtils.rescheduleLoanRepaymentDates(this);
		//HolidayUtils.rescheduleSavingDates(this);
		// end of block
	}

	protected void validateHolidayState(Short masterTypeId, Short stateId,
			boolean isCustomer) throws ApplicationException {
		Integer records;
		records = new HolidayPersistence().isValidHolidayState(masterTypeId,
				stateId, isCustomer);
		if (records.intValue() != 0) {
			throw new ApplicationException(
					HolidayConstants.EXCEPTION_STATE_ALREADY_EXIST);
		}
	}

	public String getRepaymentRule() {
		return repaymentRule;
	}

	private void validateFromDateAgainstCurrentDate(Date fromDate)
			throws ApplicationException {
		if (DateUtils.getDateWithoutTimeStamp(fromDate.getTime()).compareTo(
				DateUtils.getCurrentDateWithoutTimeStamp()) <= 0) {
			throw new ApplicationException(HolidayConstants.INVALIDFROMDATE);
		}
	}

	private void validateFromDateAgainstThruDate(Date fromDate, Date thruDate)
			throws ApplicationException {
		if (DateUtils.getDateWithoutTimeStamp(fromDate.getTime()).compareTo(
				DateUtils.getDateWithoutTimeStamp(thruDate.getTime())) > 0) {
			throw new ApplicationException(HolidayConstants.INVALIDTHRUDATE);
		}
	}

}
public class CenterMapper {
	public static CenterBO mapCenterToCenterBO(Center center,
			UserContext userContext) {
		org.mifos.framework.business.util.Address address = 
			AddressMapper.mapXMLAddressToMifosAddress(center.getAddress());
		MeetingBO meeting = null;
		Date mfiJoiningDate = mapXMLGregorianCalendarToDate(
			center.getMfiJoiningDate());
		
		RecurrenceType meetingFrequency;
		if (center.getMonthlyMeeting() != null) {
			meeting = MeetingMapper.mapMonthlyMeetingToMeetingBO(
				center.getMonthlyMeeting());
			meetingFrequency = RecurrenceType.MONTHLY;
		}
		else {
			meeting = MeetingMapper.mapWeeklyMeetingToMeetingBO(
				center.getWeeklyMeeting());
			meetingFrequency = RecurrenceType.WEEKLY;
		}

		// TODO: extract Fee handling for reuse
		FeePersistence feePersistence = new FeePersistence();
		List<FeeView> fees = new ArrayList<FeeView>();
		for (FeeAmount feeAmount : center.getFeeAmount()) {
			FeeBO fee = feePersistence.getFee(feeAmount.getFeeId());
			if (fee == null) {
				throw new RuntimeException("Fee lookup failed for id: " + feeAmount.getFeeId());
			}
			CheckForFeeMeetingFrequencyMismatch(fee, meetingFrequency);
			
			FeeView feeView = new FeeView(userContext, fee);
			feeView.setAmount(feeAmount.getAmount().toPlainString());

			fees.add(feeView);
		}

		// TODO: split out CustomField handling for reuse		
		List<CustomFieldView> fields = new ArrayList<CustomFieldView>();
		for (CustomField field : center.getCustomField()) {
			if (field.getFieldId() != null) {
				String value;
				CustomFieldType type;
				if (field.getStringValue() != null) {
					value = field.getStringValue();
					type = CustomFieldType.ALPHA_NUMERIC;
				} else if (field.getNumericValue() != null) {
					value = ""+field.getNumericValue();
					type = CustomFieldType.NUMERIC;
				} else if (field.getDateValue() != null) {
					value = ""+field.getDateValue();
					type = CustomFieldType.DATE;
				} else {
					throw new RuntimeException("No custom field value was specified");
				}
				fields.add(new CustomFieldView(
					field.getFieldId(), value, type)); 
			} else {
				throw new RuntimeException("Custom field lookup by name not yet implemented");
			}
		}

		CenterBO centerBO;
		try {
			centerBO = new CenterBO(userContext, center.getName(), address,
					fields, fees, center.getExternalId(), mfiJoiningDate,
					center.getOfficeId(), meeting, center.getLoanOfficerId());
		}
		catch (CustomerException e) {
			throw new RuntimeException(e);
		}


		return centerBO;
	}

	private static void CheckForFeeMeetingFrequencyMismatch(FeeBO fee, RecurrenceType meetingFrequency) {
		if (fee.isPeriodic() &&
				((fee.getFeeFrequency().getFeeMeetingFrequency().isMonthly() && meetingFrequency != RecurrenceType.MONTHLY) ||
						(fee.getFeeFrequency().getFeeMeetingFrequency().isWeekly() && meetingFrequency != RecurrenceType.WEEKLY))) {
			String feePeriod = "UNKNOWN";
			if (fee.getFeeFrequency().getFeeMeetingFrequency().isMonthly()) {
				feePeriod = "MONTHLY";
			} else if (fee.getFeeFrequency().getFeeMeetingFrequency().isWeekly()) {
				feePeriod = "WEEKLY";
			}
			throw new RuntimeException("Fee period and center meeting frequency " +
					"don't match. Fee frequency is " + feePeriod + 
					" while meeting frequency is " + meetingFrequency.name());
		}
	}
	
	public static Date mapXMLGregorianCalendarToDate(
			XMLGregorianCalendar calendar) {
		if (calendar == null)
			return null;

		return calendar.toGregorianCalendar().getTime();
	}

	public static XMLGregorianCalendar mapDateToXMLGregorianCalendar(Date date) {
		if (date == null)
			return null;

		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		DatatypeFactory datatypeFactory;
		try {
			datatypeFactory = DatatypeFactory.newInstance();
		}
		catch (DatatypeConfigurationException e) {
			throw new RuntimeException(e);
		}

		XMLGregorianCalendar xmlCalendar = datatypeFactory
				.newXMLGregorianCalendar(calendar);
		// we want only the date, so don't use a timezone
		xmlCalendar.setTimezone(DatatypeConstants.FIELD_UNDEFINED);

		return xmlCalendar;
	}
	
	public static XMLGregorianCalendar mapStringToXMLGregorianCalendar(String dateString) {
		DatatypeFactory datatypeFactory;
		try {
			datatypeFactory = DatatypeFactory.newInstance();
		}
		catch (DatatypeConfigurationException e) {
			throw new RuntimeException(e);
		}
		XMLGregorianCalendar xmlCalendar = datatypeFactory
		.newXMLGregorianCalendar(dateString);
		// we want only the date, so don't use a timezone
		xmlCalendar.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
		
		return xmlCalendar;
	}

