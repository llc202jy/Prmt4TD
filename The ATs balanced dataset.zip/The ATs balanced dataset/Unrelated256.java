
   @Override
public boolean computeAndSetState(double simTime, RsPlan plan, RsTransform transform){

      RsObject     [] objectArray;
      RsObject     rsObject;
      RsWall       wall;

      int          iObject, iSegment;

      boolean      oldState;
      int          oldrBin;
      double       vx, vy, minT;
      RsObject     minObject;

      oldState = hot;
      oldrBin  = rBin;

      timeStateComputed = simTime;
      stateChange       = false;

      hot            = false;
      range          = 0;
      rBin           = 0;
      objectDetected = null;

      double       tAngle = transform.getTheta()+sightAngle;
      mappedPos = transform.map(xDetector, yDetector);
      vx = Math.cos(tAngle);
      vy = Math.sin(tAngle);

      objectArray = plan.getObjectArray();
      if(objectArray==null){
         hot = false;
         stateChange=oldState;  // if oldState was true there was a change
         return stateChange;
      }

      segment.x = mappedPos.x;
      segment.y = mappedPos.y;
      segment.v.x=vx*maxRange;
      segment.v.y=vy*maxRange;
      segment.m=maxRange;

      minT      = 2.0;   // max possible value should be one.
      minObject = null;
      for(iObject=0; iObject<objectArray.length; iObject++){
         rsObject = objectArray[iObject];
         if(rsObject instanceof RsWall){
            wall = (RsWall)rsObject;
            for(iSegment=0; iSegment<wall.segmentArray.length; iSegment++){
               if(segSect.process(segment, wall.segmentArray[iSegment])){
                  if(segSect.t1<minT && segSect.t1<=1.0){
                     minT      = segSect.t1;
                     minObject = rsObject;
                  }
               }
            }
         }
      }

      if(minT < 1.0){
         // a detection is within range
         objectDetected = minObject;
         hot = true;
         range=minT*maxRange;
         rBin=(int)Math.floor(nRangeBin*range/maxRange);
         if(rBin>=nRangeBin)
            rBin=nRangeBin-1;
      }

      if(hot){
         stateChange = (!oldState || oldrBin!=rBin);
      }else{
         stateChange = oldState;
      }

      return stateChange;
   }


   @Override
public RsSensorEvent getSensorEvent(double simTime){

      String nameOfObjectDetected = null;
      if(objectDetected != null)
         nameOfObjectDetected = objectDetected.getName();

      return new RsRangeSensorEvent(
       simTime,
       getID(),
       mappedPos.x,
       mappedPos.y,
       vx,
       vy,
       hot,
       range,
       nameOfObjectDetected);
    }

}

