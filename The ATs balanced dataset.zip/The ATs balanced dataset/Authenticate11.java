 Method Summary
 SSOToken 	createSSOToken(javax.servlet.http.HttpServletRequest request)
          Creates a single sign on token from HttpServletRequest
 SSOToken 	createSSOToken(java.security.Principal user, java.lang.String password)
          Deprecated. This method has been deprecated. Please use the regular LDAP authentication mechanism instead. More information on how to use the authentication programming interfaces as well as the code samples can be obtained from the "Authentication Service" chapter of the Access Manager Developer's Guide.
 SSOToken 	createSSOToken(java.lang.String tokenId)
          Creates a single sign on token from the single sign on token ID.
 SSOToken 	createSSOToken(java.lang.String tokenId, java.lang.String clientIP)
          Creates a single sign on token from the single sign on token ID.
 void 	destroyToken(SSOToken token)
          Destroys a single sign on token.
 void 	destroyToken(SSOToken destroyer, SSOToken destroyed)
          Destroys a single sign on token.
static SSOTokenManager 	getInstance()
          Returns the singleton instance of SSOTokenManager.
 java.util.Set 	getValidSessions(SSOToken requester, java.lang.String server)
          Returns a list of single sign on token objects which correspond to valid Sessions accessible to requester.
 boolean 	isValidToken(SSOToken token)
          Returns true if a single sign on token is valid.
 void 	refreshSession(SSOToken token)
          Refresh the Session corresponding to the single sign on token from the Session Server.
 void 	validateToken(SSOToken token)
          Returns true if the single sign on token is valid.
 
Methods inherited from class java.lang.Object
equals, getClass, hashCode, notify, notifyAll, toString, wait, wait, wait
 

Field Detail
debug

public static Debug debug

Method Detail
getInstance

public static SSOTokenManager getInstance()
                                   throws SSOException

    Returns the singleton instance of SSOTokenManager.

    Returns:
        The singleton SSOTokenManager instance 
    Throws:
        SSOException - if unable to get the singleton SSOTokenManager instance.

createSSOToken

public SSOToken createSSOToken(javax.servlet.http.HttpServletRequest request)
                        throws java.lang.UnsupportedOperationException,
                               SSOException

    Creates a single sign on token from HttpServletRequest

    Parameters:
        request - The HttpServletRequest object which contains the session string. 
    Returns:
        single sign on token 
    Throws:
        SSOException - if the single sign on token cannot be created. 
        java.lang.UnsupportedOperationException - if this is an unsupported operation.

createSSOToken

public SSOToken createSSOToken(java.security.Principal user,
                               java.lang.String password)
                        throws java.lang.UnsupportedOperationException,
                               SSOException

    Deprecated. This method has been deprecated. Please use the regular LDAP authentication mechanism instead. More information on how to use the authentication programming interfaces as well as the code samples can be obtained from the "Authentication Service" chapter of the Access Manager Developer's Guide.

    Creates a single sign on token after authenticating the principal with the given password. This method of creating a single sign on token should only be used for command line applications and it is forbidden to use this single sign on token in any other context (e.g. policy, federation, etc.). A token created with this method is only valid within the context of the calling application. Once the process exits the token will be destroyed. If token is created using this constructor then ONLY these methods of single sign on token is supported -

     getAuthType(), 
     getHostName(), 
     getIPAddress(), 
     setProperty(String name, String value), 
     getProperty(String name), 
     isValid(), 
     validate(). 
     

    Parameters:
        user - Principal representing a user or service
        password - The password supplied for the principal 
    Returns:
        single sign on token 
    Throws:
        SSOException - if the single sign on token cannot be created. 
        java.lang.UnsupportedOperationException - if this is an unsupported operation.

createSSOToken

public SSOToken createSSOToken(java.lang.String tokenId)
                        throws java.lang.UnsupportedOperationException,
                               SSOException

    Creates a single sign on token from the single sign on token ID. Note:-If you want to do Client's IP address validation for the single sign on token then use creatSSOToken(String, String) OR createSSOToken(HttpServletRequest).

    Parameters:
        tokenId - Token ID of the single sign on token 
    Returns:
        single sign on token 
    Throws:
        SSOException - if the single sign on token cannot be created. 
        java.lang.UnsupportedOperationException

createSSOToken

public SSOToken createSSOToken(java.lang.String tokenId,
                               java.lang.String clientIP)
                        throws java.lang.UnsupportedOperationException,
                               SSOException

    Creates a single sign on token from the single sign on token ID.

    Parameters:
        tokenId - Token ID of the single sign on token
        clientIP - Client IP address. This must be the IP address of the client/user who is accessing the application. 
    Returns:
        single sign on token 
    Throws:
        SSOException - if the single sign on token cannot be created. 
        java.lang.UnsupportedOperationException

isValidToken

public boolean isValidToken(SSOToken token)

    Returns true if a single sign on token is valid.

    Parameters:
        token - The single sign on token object to be validated. 
    Returns:
        true if the single sign on token is valid.

validateToken

public void validateToken(SSOToken token)
                   throws SSOException

    Returns true if the single sign on token is valid.

    Parameters:
        token - The single sign on token object to be validated. 
    Throws:
        SSOException - if the single sign on token is not valid.

destroyToken

public void destroyToken(SSOToken token)
                  throws SSOException

    Destroys a single sign on token.

    Parameters:
        token - The single sign on token object to be destroyed. 
    Throws:
        SSOException - if there was an error while destroying the token, or the corresponding session reached its maximum session/idle time, or the session was destroyed.

refreshSession

public void refreshSession(SSOToken token)
                    throws SSOException

    Refresh the Session corresponding to the single sign on token from the Session Server. This method should only be used when the client cannot wait the "session cache interval" for updates on any changes made to the session properties in the session server. If the client is remote, calling this method results in an over the wire request to the session server.

    Parameters:
        token - single sign on token 
    Throws:
        SSOException - if the session reached its maximum session time, or the session was destroyed, or there was an error while refreshing the session.

destroyToken

public void destroyToken(SSOToken destroyer,
                         SSOToken destroyed)
                  throws SSOException

    Destroys a single sign on token.

    Parameters:
        destroyer - The single sign on token object used to authorize the operation
        destroyed - The single sign on token object to be destroyed. 
    Throws:
        SSOException - if the there was an error during communication with session service.

getValidSessions

public java.util.Set getValidSessions(SSOToken requester,
                                      java.lang.String server)
                               throws SSOException

    Returns a list of single sign on token objects which correspond to valid Sessions accessible to requester. Single sign on tokens returned are restricted: they can only be used to retrieve properties and destroy sessions they represent.

    Parameters:
        requester - The single sign on token object used to authorize the operation
        server - The server for which the valid sessions are to be retrieved 
    Returns:
        Set The set of single sign on tokens representing valid Sessions. 
    Throws:
        SSOException - if the there was an error during communication with session service.

