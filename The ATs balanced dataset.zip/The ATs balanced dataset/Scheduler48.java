namespace Roboto.NotImpossible.MultiThreaded.Tasks
{
    //---------------------------------------------------------
    public enum  TaskPriority
    {
        Normal,
        Low,
        Hight
    }

    //---------------------------------------------------------
    public static class TaskPriorityExtender
    {
        //---------------------------------------------------------
        public static ThreadPriority ToThreadPriority(this TaskPriority priority)
        {
            switch (priority)
            {
                case TaskPriority.Normal:
                    return ThreadPriority.Normal;
                case TaskPriority.Low:
                    return ThreadPriority.BelowNormal;
                case TaskPriority.Hight:
                    return ThreadPriority.AboveNormal;
                default:
                    throw new ArgumentOutOfRangeException("priority");
            }
        }
    }
}