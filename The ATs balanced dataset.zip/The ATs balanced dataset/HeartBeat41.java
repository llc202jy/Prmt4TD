public final class SMTPIOExceptionTest {

    // timeout the test in case of failure
    @Rule
    public Timeout deadlockTimeout = new Timeout(5000);

    private boolean closed = false;

    private static final int TIMEOUT = 200;	// I/O timeout, in millis

    @Test
    public void test() throws Exception {
        SMTPServer server = null;
        try {
	    SMTPHandler handler = new SMTPHandler() {
		public void rcpt() throws IOException {
		    try {
			// delay long enough to cause timeout
			Thread.sleep(2 * TIMEOUT);
		    } catch (Exception ex) { }
		    super.rcpt();
		}
	    };
            server = new SMTPServer(handler, 26423);
            server.start();
            Thread.sleep(1000);

            final Properties properties = new Properties();
            properties.setProperty("mail.smtp.host", "localhost");
            properties.setProperty("mail.smtp.port", "26423");
            properties.setProperty("mail.smtp.timeout", "" + TIMEOUT);
            final Session session = Session.getInstance(properties);
            //session.setDebug(true);

            final Transport t = session.getTransport("smtp");
	    /*
	     * Use a listener to detect the connection being closed
	     * because if we called isConnected() and the connection
	     * wasn't already closed, it will issue a command that
	     * might detect that the connection was closed, even
	     * though it wasn't closed already.
	     */
	    t.addConnectionListener(new ConnectionAdapter() {
		@Override
		public void closed(ConnectionEvent e) {
		    setClosed(true);
		}
	    });
            try {
		MimeMessage msg = new MimeMessage(session);
		msg.setRecipients(Message.RecipientType.TO, "joe@example.com");
		msg.setSubject("test");
		msg.setText("test");
                t.connect();
		t.sendMessage(msg, msg.getAllRecipients());
	    } catch (MessagingException ex) {
		// expect an exception from sendMessage
		Thread.sleep(100);	// give event thread time to run
		assertTrue(getClosed());
            } finally {
                t.close();
            }
        } catch (final Exception e) {
            e.printStackTrace();
            fail(e.getMessage());
        } finally {
            if (server != null) {
                server.quit();
		server.interrupt();
		// wait long enough for handler to exit
		Thread.sleep(2 * TIMEOUT);
            }
        }
    }

    private synchronized void setClosed(boolean v) {
	closed = v;
    }

    private synchronized boolean getClosed() {
	return closed;
    }
}