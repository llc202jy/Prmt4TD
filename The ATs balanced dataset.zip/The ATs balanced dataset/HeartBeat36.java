**
 * A AdminFaultDetectionHandler provides support necessary for a
 * FaultDetectionHandler. The AdminFaultDetectionHandler can be used to
 * monitor a services which implement the
 * <code>net.jini.admin.Administrable</code> interface (as well as for
 * services that do not implement this interface). 
 * <p>
 * If the service does implement the <code>net.jini.admin.Administrable</code>, the
 * AdminFaultDetectionHandler invokes the 
 * {@link net.jini.admin.Administrable#getAdmin()} method periodically. If this
 * method invocation returns succesfully, the service is assumed to be available. If
 * this method invocation results in a failure,  and all retry attempts have failed, 
 * the AdminFaultDetectionHandler will notify FaultDetectionListener instances of
 * the failure.
 * <p>
 * Additionally, the AdminFaultDetectionHandler will register with Lookup
 * Services for ServiceRegistrar.TRANSITION_MATCH_NOMATCH transitions for the
 * service being monitored. If the service is adminstratively removed from the
 * network, the transition will be noted and FaultDetectionListener instances will 
 * be notified of the failure.
 * <p>
 * If the service does not implement the
 * <code>net.jini.admin.Administrable</code> interface, the
 * AdminFaultDetectionHandler will periodically invoke the 
 * {@link net.jini.admin.Administrable#getAdmin()} method, but will only create
 * the event consumer for Lookup Service TRANSITION_MATCH_NOMATCH transitions.
 * <p>
 * <b><font size="+1">Configuring AdminFaultDetectionHandler</font> </b>
 * <p>
 * This implementation of <code>AdminFaultDetectionHandler</code> supports
 * the following configuration entries; where each configuration entry name is
 * associated with the component name
 * <code>net.assimilator.resources.client.AdminFaultDetectionHandler</code>.
 * <br>
 * <br>
 * <ul>
 * <li><span style="font-weight: bold; font-family: courier
 * new,courier,monospace;">invocationDelay</span> <table cellpadding="2"
 * cellspacing="2" border="0" style="text-align: left; width: 100%;"> <tbody>
 * <tr><td style="vertical-align: top; text-align: right; font-weight:
 * bold;">Type: <br>
 * </td>
 * <td style="vertical-align: top; font-family: monospace;">long</td>
 * </tr>
 * <tr><td style="vertical-align: top; text-align: right; font-weight:
 * bold;">Default: <br>
 * </td>
 * <td style="vertical-align: top;"><code>60*1000 (60 seconds)</code></td>
 * </tr>
 * <tr><td style="vertical-align: top; text-align: right; font-weight:
 * bold;">Description: <br>
 * </td>
 * <td style="vertical-align: top;">The amount of time in milliseconds to wait
 * between {@link net.jini.admin.Administrable#getAdmin()} method invocations</td>
 * </tr>
 * </tbody> </table></li>
 * </ul>
 * <ul>
 * <li><span style="font-weight: bold; font-family: courier
 * new,courier,monospace;">retryCount </span> <table cellpadding="2"
 * cellspacing="2" border="0" style="text-align: left; width: 100%;"> <tbody>
 * <tr><td style="vertical-align: top; text-align: right; font-weight:
 * bold;">Type: <br>
 * </td>
 * <td style="vertical-align: top;"><code>int</code><br>
 * </td>
 * </tr>
 * <tr><td style="vertical-align: top; text-align: right; font-weight:
 * bold;">Default: <br>
 * </td>
 * <td style="vertical-align: top;"><code>3</code></td>
 * </tr>
 * <tr><td style="vertical-align: top; text-align: right; font-weight:
 * bold;">Description: <br>
 * </td>
 * <td style="vertical-align: top;">The number of times to retry connecting to
 * the service when invoking the 
 * {@link net.jini.admin.Administrable#getAdmin()} method. If the service cannot be 
 * reached within the retry count specified the service will be determined to be 
 * unreachable
 * </td>
 * </tr>
 * </tbody> </table></li>
 * </ul>
 * <ul>
 * <li><span style="font-weight: bold; font-family: courier
 * new,courier,monospace;">retryTimeout </span> <table cellpadding="2"
 * cellspacing="2" border="0" style="text-align: left; width: 100%;"> <tbody>
 * <tr><td style="vertical-align: top; text-align: right; font-weight:
 * bold;">Type: <br>
 * </td>
 * <td style="vertical-align: top;"><code>long</code></td>
 * </tr>
 * <tr><td style="vertical-align: top; text-align: right; font-weight:
 * bold;">Default: <br>
 * </td>
 * <td style="vertical-align: top;"><code>1000 (1 second)</code></td>
 * </tr>
 * <tr><td style="vertical-align: top; text-align: right; font-weight:
 * bold;">Description: <br>
 * </td>
 * <td style="vertical-align: top;">How long to wait between retries (in
 * milliseconds). This value will be used between retry attempts, waiting the
 * specified amount of time to retry <br>
 * </td>
 * </tr>
 * </tbody> </table></li>
 * </ul>
 * <br>
 * The amount of time it takes for the AdminFaultDetectionHandler to
 * determine service failure for a service which implements the
 * {@link net.jini.admin.Administrable} interface is calculated as
 * follows :<br>
 * 
 * <pre>
 * ((num_retries + 1) * (connectivity_timeout)) + (retry_delay * num_retries)
 * </pre>
 */
public class AdminFaultDetectionHandler extends AbstractFaultDetectionHandler {
    static final int DEFAULT_INVOCATION_DELAY = 1000 * 60;    
    public static final String INVOCATION_DELAY_KEY = "invocationDelay";
    private long invocationDelay = DEFAULT_INVOCATION_DELAY;    
    /** Component name, used for config and logger */
    private static final String COMPONENT = 
        "net.assimilator.resources.client.AdminFaultDetectionHandler";
    /** A Logger */
    static Logger logger = Logger.getLogger(COMPONENT);

    /**
     * @see net.assimilator.core.FaultDetectionHandler#setConfiguration
     */
    public void setConfiguration(String[] configArgs) {
        if(configArgs == null)
            throw new NullPointerException("configArgs is null");
        try {
            this.configArgs = new String[configArgs.length];
            System.arraycopy(configArgs, 0, this.configArgs, 0, configArgs.length);
            
            this.config = ConfigurationProvider.getInstance(configArgs);
       
            invocationDelay = Config.getLongEntry(config,
                                                COMPONENT,
                                                INVOCATION_DELAY_KEY,
                                                DEFAULT_INVOCATION_DELAY,
                                                0,
                                                Long.MAX_VALUE);            
            retryCount = Config.getIntEntry(config,
                                            COMPONENT,
                                            RETRY_COUNT_KEY,
                                            DEFAULT_RETRY_COUNT,
                                            0,
                                            Integer.MAX_VALUE);
            retryTimeout = Config.getLongEntry(config,
                                               COMPONENT,
                                               RETRY_TIMEOUT_KEY,
                                               DEFAULT_RETRY_TIMEOUT,
                                               0,
                                               Long.MAX_VALUE);
            
            if(logger.isLoggable(Level.FINEST)) {
                StringBuffer buffer = new StringBuffer();
                buffer.append("AdminFaultDetectionHandler Properties : ");
                buffer.append("retry count=" + retryCount + ", ");
                buffer.append("retry timeout=" + retryTimeout);
                logger.finest(buffer.toString());
            }
        } catch(ConfigurationException e) {
            logger.log(Level.SEVERE, "Setting Configuration", e);
        }
    }
    
    /**
     * Get the class which implements the ServiceMonitor
     */
    protected ServiceMonitor getServiceMonitor() throws Exception {
        ServiceMonitor monitor = null;
        if(proxy instanceof Administrable) {
            ((Administrable)proxy).getAdmin();                            
            monitor = new ServiceAdminManager();
        }
        return(monitor);
    }
        
    /**
     * Invoke the service's {@link net.jini.admin.Administrable#getAdmin()} method 
     * periodically
     */
    class ServiceAdminManager extends Thread implements ServiceMonitor {
        boolean keepAlive = true;

        /**
         * Create a ServiceLeaseManager
         * 
         * @param lease The Lease to manage
         */
        ServiceAdminManager() {
            super("ServiceAdminManager:"
                  + proxy.getClass().getName()
                  + ":"
                  + System.currentTimeMillis());
            setDaemon(true);
            start();
        }

        /**
         * Its all over
         */
        public void drop() {            
            if(logger.isLoggable(Level.FINEST))
                logger.finest("Terminating ServiceMonitor Thread");
            keepAlive = false;
            interrupt();
        }

        /**
         * Verify service can be reached. If the service cannot be reached
         * return false
         */
        public boolean verify() {
            if(!keepAlive)
                return (false);
            boolean verified = false;
            try {
                /*
                 * Get the service's admin object. If the service isnt active 
                 * we'll get a RemoteException
                 */
                ((Administrable)proxy).getAdmin();
                verified = true;
            } catch(RemoteException e) {
                if(logger.isLoggable(Level.FINEST))
                    logger.finest("RemoteException reaching service, "+
                                  "service cannot be reached");
                keepAlive = false;
            } catch(Throwable t) {
                final int category = ThrowableConstants.retryable(t);
                if(category==ThrowableConstants.BAD_INVOCATION ||
                    category==ThrowableConstants.BAD_OBJECT) {
                    keepAlive = false;
                    if(logger.isLoggable(Level.FINE))
                        logger.log(Level.FINE,
                                   "Unrecoverable Exception invoking getAdmin()",
                                   t);
                } 
            }
            return (verified);
        }

        public void run() {
            while (!interrupted()) {
                if(!keepAlive) {
                    return;
                }                
                if(logger.isLoggable(Level.FINEST))
                    logger.finest("ServiceAdminManager: Wait for "+
                                  "["+invocationDelay+"] millis "+ 
                                  "to invoke getAdmin() on "+ 
                                  proxy.getClass().getName());
                try {
                    sleep(invocationDelay);
                } catch(InterruptedException ie) {
                    ;
                } catch(IllegalArgumentException iae) {
                    logger.warning("ServiceAdminManager: sleep time is off : "
                                   + invocationDelay);
                }                
                try {
                    if(logger.isLoggable(Level.FINEST))
                        logger.finest("invoke getAdmin() on : "
                                      + proxy.getClass().getName());
                    ((Administrable)proxy).getAdmin();
                } catch(Exception e) {
                    final int category = ThrowableConstants.retryable(e);
                    if(category==ThrowableConstants.BAD_INVOCATION ||
                        category==ThrowableConstants.BAD_OBJECT) {
                        keepAlive = false;
                        if(logger.isLoggable(Level.FINE))
                            logger.log(Level.FINE,
                                       "Unrecoverable Exception invoking getAdmin()",
                                       e);
                    }
                    /*
                     * If we failed to renew the Lease we should try and
                     * re-establish comms to the Service and get another
                     * Lease
                     */
                    if(keepAlive) {
                        if(logger.isLoggable(Level.FINEST))
                            logger.finest("Failed to invoke getAdmin() on : "
                                          + proxy.getClass().getName()
                                          + ", retry ["+retryCount+"] "+ 
                                          "times, waiting ["+retryTimeout+"] "+
                                          "millis between attempts");
                        boolean connected = false;
                        for(int i = 0; i < retryCount; i++) {
                            long t0 = 0;
                            long t1 = 0;
                            try {
                                if(logger.isLoggable(Level.FINEST))
                                    logger.finest("Attempt to invoke getAdmin() "+
                                                  "on : "+proxy.getClass().getName()+
                                                  ", attempt ["+i+"]");                                
                                t0 = System.currentTimeMillis();
                                ((Administrable)proxy).getAdmin();
                                if(logger.isLoggable(Level.FINEST))
                                    logger.finest("Re-established connection to : "+ 
                                                  proxy.getClass().getName());
                                connected = true;
                                break;
                            } catch(Exception e1) {
                                t1 = System.currentTimeMillis();
                                if(logger.isLoggable(Level.FINEST))
                                    logger.finest("Invocation attempt ["+i+"] "+
                                                  "took ["+(t1 - t0)+"] "+ 
                                                  "millis to fail for : "+ 
                                                  proxy.getClass().getName());
                                if(retryTimeout > 0) {
                                    try {
                                        sleep(retryTimeout);
                                    } catch(InterruptedException ie) {
                                        ;
                                    }
                                }
                            }
                        }
                        if(!connected) {
                            if(logger.isLoggable(Level.FINEST)) {
                                if(proxy != null)
                                    logger.finest("Unable to invoke getAdmin() on "+
                                                  "["+proxy.getClass().getName()+ 
                                                  "], notify listeners and exit");
                                else
                                    logger.finest("Unable to invoke getAdmin() "+
                                                  "[null proxy], notify listeners "+
                                                  "and exit");
                            }
                            notifyListeners();
                            break;
                        }
                    } else {
                        notifyListeners();
                        break;
                    }
                }                
            }
            terminate();
        }
    }    
}