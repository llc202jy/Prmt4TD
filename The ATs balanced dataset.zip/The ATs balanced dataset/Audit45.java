public class Auditer {
	/** Query to insert a message */    
	public static final String AUDIT_INSERT_QUERY = "insert into pki_va_audit(audit_date,audit_channel,audit_message) values(?,?,?)";
	/** Maximum size of audit_channel field. */    
	public static final int MAX_AUDIT_CHANNEL_SIZE = 256;
	/** Maximum size of messages audited */    
	public static final int MAX_AUDIT_MESSAGE_SIZE = 2000;
	/** DDL for table required to store messages. */    
	//public static final String DDL =  " CREATE TABLE PKI_VA_AUDIT ( AUDIT_DATE DATE default sysdate, AUDIT_CHANNEL VARCHAR2("+
	//MAX_AUDIT_CHANNEL_SIZE+"), AUDIT_MESSAGE  VARCHAR2("+MAX_AUDIT_MESSAGE_SIZE+") )";
	/** Datasource name to use */    
	public static String DS_NAME = "java:/EpsilonDS";
	
	
	// Nuevas Ago-04
	/** PKI_VA_AUDIT_REQUEST_TABLENAME */    
	public static final String PKI_VA_AUDIT_REQUEST_TABLENAME = "PKI_VA_AUDIT_REQUEST";
	
	/** PKI_VA_AUDIT_RESPONSE_TABLENAME */    
	public static final String PKI_VA_AUDIT_RESPONSE_TABLENAME = "PKI_VA_AUDIT_RESPONSE";
	
	/** PKI_VA_AUDIT_ENTRIES_TABLENAME */    
	public static final String PKI_VA_AUDIT_ENTRIES_TABLENAME = "PKI_VA_AUDIT_ENTRIES";
	
	/** QUERY FOR GETTING NEXT VALUE FROM SEQUENCE */    
	public static final String SEQUENCE_NEXT_VALUE_QUERY = "select SQ_PKI_VA_AUDIT_ENTRIES.nextval from dual";
	
	/** max size of varchar fields */
	public static final int VARCHAR_MAX_SIZE = 4000, BUFF_SIZE=256;
	
	/** Auditer name, often, the class name wich uses it. */    
	protected String name="";
	/** Datasource to get connections from. */    
	protected DataSource ds;
	/** Constructs an Auditer with given name.
	 * @param s Name of the created Auditer
	 */    
	public Auditer(String s) throws AuditingException
	{
		Context ctx=null;
		try{
			if(s.length()>MAX_AUDIT_CHANNEL_SIZE)
				name="..."+s.substring(s.length()-MAX_AUDIT_CHANNEL_SIZE+3,s.length());
			else
				name=s;
			ctx = new InitialContext();
			ds = (DataSource) ctx.lookup(DS_NAME);
		}
		catch (NamingException ne) {
			LogManager.getLogger(this.getClass()).error("Cannot resolve datasource name.",ne);
			throw new AuditingException ( "Cannot resolve datasource name.",ne );
		}
		finally{
			try{if(ctx!=null)ctx.close();}
			catch (NamingException ne){}
		}
	}
	
	/** Audits a message
	 * @param event Message to audit
	 * @param e Exception to store as well
	 */    
	public void audit(String event,Exception e) throws AuditingException
	{
		audit(new java.util.Date(),event,e);
	}
	/** Audits a message
	 * @param event Message to audit
	 */    
	public void audit(String event) throws AuditingException
	{
		audit(new java.util.Date(),event);
	}
	/** Audits a message
	 * @param d Date of the event being audited
	 * @param event Message to audit
	 * @param e Exception to store as well
	 */    
	public void audit(java.util.Date d,String event,Exception e) throws AuditingException
	{
		String message;
		if(event.length()>MAX_AUDIT_MESSAGE_SIZE)
			message = event.substring(0,MAX_AUDIT_MESSAGE_SIZE-6-e.getMessage().length())+"... - "+e.getMessage();
		else
			message = event;
		audit(d,message);
	}    
	
	/** Audits a message
	 * @param d Date of the event being audited
	 * @param event Message to audit
	 */    
	public void audit(java.util.Date d,String event) throws AuditingException
	{
		if(event.length()>MAX_AUDIT_MESSAGE_SIZE) {
			event = event.substring(0,MAX_AUDIT_MESSAGE_SIZE-3)+"...";
		}
		if(ds==null){
			LogManager.getLogger(this.getClass()).info("AUDIT: "+d+" : "+event);
			return;
		}
		Connection conn = null;
		PreparedStatement pStmt = null;
		try {
			conn = ds.getConnection();
			pStmt = conn.prepareStatement(AUDIT_INSERT_QUERY);
			pStmt.setTimestamp(1,new Timestamp(d.getTime()));
			pStmt.setString(2, name);
			pStmt.setString(3, event);
			pStmt.executeUpdate();
		}
		catch (SQLException sqle){
			LogManager.getLogger(this.getClass()).error("Exception inserting audit value: "+AUDIT_INSERT_QUERY, sqle);
			throw new AuditingException ( "Exception inserting audit value.",sqle);
		}
		finally {
			try {
				if (pStmt!=null) pStmt.close();
				if (conn!=null ) conn.close();
			}
			catch (SQLException sqle){}
		}
	}
	
	/** New way of auditing. Audits an AuditOperation
	 * @param oper AuditOperation to be audited
	 */    
	public void audit ( AuditOperation oper ) throws AuditingException
	{
		audit ( oper, new java.util.Date() );
	}
	
	/** New way of auditing. Audits an AuditOperation
	 * @param oper AuditOperation to be audited
	 * @param date operation date
	 */    
	public void audit ( AuditOperation oper, java.util.Date d ) throws AuditingException
	{
		int sequence = auditIncomplete ( oper, d );
		
		auditResponse ( oper, sequence );
	}
	
	/** Audits an AuditOperation, filling just the request fields.
	 * @param oper AuditOperation to be audited
	 */    
	public int auditIncomplete ( AuditOperation oper ) throws AuditingException
	{
		return auditIncomplete ( oper, new java.util.Date() ); 
	}
	
	/** Audits an AuditOperation, filling just the request fields.
	 * @param oper AuditOperation to be audited
	 * @param date operation date
	 */    
	public int auditIncomplete ( AuditOperation oper, java.util.Date d ) throws AuditingException
	{
		Timestamp date = new Timestamp( d.getTime() );
		
		int oper_id = oper.getOperation();
		
		int sequence = getSequence();
		
		sequence= insertEntry ( sequence, oper_id, date );
		
		insertRequest ( sequence, oper );
		
		return sequence;
	}
	
	/** Audits a previous incomplete audited AuditOperation, filling the response fields.
	 * @param oper AuditOperation to be audited
	 * @param entry_id Entry id got from previous incomplete audit
	 */    
	public void auditResponse ( AuditOperation oper, int entry_id ) throws AuditingException
	{
		insertResponse ( entry_id, oper );
	}
	
	private static final int INVALID_SEQ=-1;
	protected int getSequence ( ) throws AuditingException
	{
		int next = INVALID_SEQ;
		
		Connection conn = null;
		Statement stm = null;
		ResultSet rs = null;
		
		try
		{
			conn = ds.getConnection();
			stm = conn.createStatement();
			rs = stm.executeQuery( SEQUENCE_NEXT_VALUE_QUERY );
			
			if ( rs.next() )
			{
				next = rs.getInt(1);
			}
		}
		catch (SQLException sqle){
			next= INVALID_SEQ;
			//LogManager.getLogger(this.getClass()).warn("Exception getting next value from sequence."+sqle.getMessage()+" "+ SEQUENCE_NEXT_VALUE_QUERY);
			//Metodo solo valido para ORACLE 
			// En otros casos posteriormente se obtiene mediante statement.getGeneratedKeys()
			//throw new AuditingException ( "Exception getting next value from sequence.",sqle);
		}
		finally
		{
			try
			{rs.close();}
			catch (Exception e)
			{}
			try
			{stm.close();}
			catch (Exception e)
			{}
			try
			{conn.close();}
			catch (Exception e)
			{}
		}
		
		return next;
		
	}
	
	protected int insertEntry (final int sequence, final int oper_id, final Timestamp date ) throws AuditingException
	{
		int retSequence= sequence;
		StringBuffer querySB = new StringBuffer ( "insert into " );
		querySB.append ( PKI_VA_AUDIT_ENTRIES_TABLENAME );
		if (sequence!=INVALID_SEQ) {
			querySB.append ( " (ENTRY_ID, OPER_ID, OPER_DATE) values (?,?,?)" );
		} else {
			// AUTO_INCREMENT MODE
			querySB.append ( " (OPER_ID, OPER_DATE) values (?,?)" );
		}
		
		Connection conn = null;
		PreparedStatement pStmt = null;
		boolean autoCommitOldMode=true;

		try {
			conn = ds.getConnection();
			autoCommitOldMode= conn.getAutoCommit();
			// Init Transaction
			conn.setAutoCommit(false);
			
			pStmt = conn.prepareStatement(querySB.toString());
			int g=1;
			if (sequence!=INVALID_SEQ) {
				pStmt.setInt(g++,sequence);
			}
			pStmt.setInt(g++,oper_id );
			pStmt.setTimestamp(g++,date);
			pStmt.executeUpdate();
			
			// AUTO_INCREMENT MODE
			if (sequence==INVALID_SEQ) {
				ResultSet rsGK= null;
				try {
					rsGK= pStmt.getGeneratedKeys();
					if (rsGK!=null && rsGK.next()) {
						retSequence= rsGK.getInt(1);
					} else {
						LogManager.getLogger(this.getClass()).error("Exception obtaining audit ENTRY_ID value :"+querySB.toString());
						throw new AuditingException ( "Exception inserting audit value.");
					}
				} catch (SQLException se) {
					// ORACLE Error: Unsupported Feature ( http://www.oracle.com/technology/tech/java/sqlj_jdbc/htdocs/jdbc_faq.htm#02_04 )
					//	at oracle.jdbc.driver.DatabaseError.throwUnsupportedFeatureSqlException(DatabaseError.java:537)
					//	at oracle.jdbc.driver.OracleStatement.getGeneratedKeys(OracleStatement.java:4124)
					//	at org.jboss.resource.adapter.jdbc.WrappedStatement.getGeneratedKeys(WrappedStatement.java:500)
					LogManager.getLogger(this.getClass()).error("Unexpected SQL Error (getGeneratedKeys) ", se);
				} finally {
					if (rsGK!=null) {
						rsGK.close();
					}
				}
				
			}
			conn.commit();
		}
		catch (SQLException sqle){
			try {
				if (conn!=null) {
					conn.rollback();
				}
			} catch (SQLException e) {}
			
			LogManager.getLogger(this.getClass()).error("Exception inserting audit value."+querySB.toString(),sqle);
			throw new AuditingException ( "Exception inserting audit value.",sqle);
		}
		finally {
			try {
				if (pStmt!=null) {
					pStmt.close();
				}
				if (conn!=null) {
					conn.setAutoCommit(autoCommitOldMode);
					conn.close();
				}
			} catch (SQLException sqle){}
		}
		
		return retSequence;
	}
	
	protected void insertRequest (final int entry_id,final AuditOperation oper) throws AuditingException
	{
		insertInTable ( PKI_VA_AUDIT_REQUEST_TABLENAME, entry_id, oper.getRequest() );
	}
	
	protected void insertResponse (final int entry_id,final AuditOperation oper) throws AuditingException
	{
		insertInTable ( PKI_VA_AUDIT_RESPONSE_TABLENAME, entry_id, oper.getResponse() );
	}
	
	protected void insertInTable ( final String tableName, final int entry_id, final Hashtable params ) throws AuditingException
	{
		//LogManager.getLogger(this.getClass()).debug("inserting in table:params::" + params);
		final StringBuffer querySB = new StringBuffer ( "insert into " );
		
		// jcg20050530: OpenVA 
		//querySB.append ( tableName ).append ( " (ENTRY_ID, KEY_ID, VC_VALUE, BO_VALUE) values (?,?,?,EMPTY_BLOB())" );
		querySB.append ( tableName ).append ( " (ENTRY_ID, KEY_ID, VC_VALUE) values (?,?,?)" );
		
		Connection conn = null;
		PreparedStatement pStmt = null;
		try {
			conn = ds.getConnection();
			pStmt = conn.prepareStatement(querySB.toString());
			
			Enumeration keys = params.keys();
			while ( keys.hasMoreElements() )
			{
				Integer key_id = (Integer) keys.nextElement();
				AuditValue value = (AuditValue) params.get ( key_id );
				String vc_value = value.getAsVarchar();
				
				// diriarte: varchar longer than 4000 crashes db
				if ( (vc_value != null ) && (vc_value.length() > VARCHAR_MAX_SIZE) ) {
					vc_value = vc_value.substring(0, VARCHAR_MAX_SIZE - 3) + "...";
				}
				
				byte[] bo_value = value.getAsBlob();
				
				pStmt.setInt(1,entry_id);
				pStmt.setInt(2,key_id.intValue() );
				pStmt.setString(3,vc_value);
				pStmt.executeUpdate();
				
				if ( bo_value != null )
				{
					// jcg20050530: OpenVA
					final StringBuffer updSB= new StringBuffer("UPDATE ").append(tableName);
					updSB.append(" SET BO_VALUE = ? ");
					updSB.append ( " where ENTRY_ID = " ).append ( entry_id )
					.append ( " and KEY_ID = ").append (key_id.intValue());
					
					PreparedStatement ps=null;
					InputStream bfis= null; 
					try {
						ps= conn.prepareStatement( updSB.toString());

						// Insert the binary[] into the Blob
						bfis= new BufferedInputStream(new ByteArrayInputStream(bo_value), BUFF_SIZE);
						ps.setBinaryStream( 1, bfis, bo_value.length );
						
						LogManager.getLogger(this.getClass()).trace("Updating Blob size="+bo_value.length);
						// Execute the UPDATE
						int count = ps.executeUpdate();
						//LogManager.getLogger(this.getClass()).trace("Blob in "+tableName+" updated, entry_id="+entry_id+", key_id="+key_id.intValue());

					} catch (Exception e) {
						throw e;
					} finally {
						if (bfis!=null) bfis.close();
						if (ps!=null) ps.close();
					}
					
				} // end if bo_value != null
			} // end while
		}
		/*catch (IOException ioe){
		 LogManager.getLogger(this.getClass()).error("Exception inserting BLOB audit value.",ioe);
		 throw new AuditingException ( "Exception inserting BLOB audit value.",ioe);
		 }*/
		catch (Exception sqle){
			LogManager.getLogger(this.getClass()).error("Exception inserting audit value.",sqle);
			throw new AuditingException ( "Exception inserting audit value.",sqle);
		}
		finally {
			try {
				if (pStmt!=null) pStmt.close();
				if (conn!=null) conn.close();
			} catch (SQLException sqle){}
		}
	}
	
}

package pkiva.exceptions;

/**
* Class: AuditingException:
*
* Exception raised when there's an error in audit.
*/

public class AuditingException extends BaseException{
	/**
 	* AuditingException class constructor
 	*/
    public AuditingException(){
		super();
	}
    
	/**
 	* AuditingException class constructor
 	* @param message describes excepcion's cause
 	*/
    public AuditingException(String message){
		super(message);
	}
    
	/**
 	* AuditingException class constructor
 	* @param message describes excepcion's cause
 	* @param cause the cause (which is saved for later retrieval by the Throwable.getCause() method). (A null value is permitted, and indicates that the cause is nonexistent or unknown.)
 	*/
    public AuditingException(String message, Throwable cause){
		super(message, cause);
	}
    
	/**
 	* AuditingException class constructor
 	* @param cause the cause (which is saved for later retrieval by the Throwable.getCause() method). (A null value is permitted, and indicates that the cause is nonexistent or unknown.)
 	*/
    public AuditingException(Throwable cause){
		super(cause);
	}
    
}

public class CertificateParserBean implements SessionBean {
    private SessionContext context;
    
    /**
     * @throws CreateException
     */    
    public void ejbCreate() throws CreateException  { }
    /**
     * @param theContext
     */    
    public void setSessionContext(SessionContext theContext) {
        this.context = theContext;
    }
    /** Gets the data associated to a given path inside a Certificate.
     * @param cert The certificate to process, in encoded form.
     * @param path The path to resolve inside certificate.
     * @throws RemoteException It is an ejb method...
     * @throws CertificateException If given certificate is invalid or unparseable.
     * @return The object indexed by given path, or null if nothing apropiate is found.
     */
    public Object getData(byte[] cert, String path) throws RemoteException,CertificateException{
        try{
            //return new pkiva.parsing.Certificate(cert).getValue(path);
            // Changes auditing Aug-04
            pkiva.parsing.Certificate parsingCert = new pkiva.parsing.Certificate(cert);
            Object obj = parsingCert.getValue(path);

            infoAndAudit ( CertUtils.getCertFromEncoded(cert), path, obj );

            return obj;
        }
        catch(AuditingException ae){
            throw new RemoteException("Internal Error getting Data from certificate", ae);
        }
        catch(IOException ioe){
            throw new CertificateException("Invalid encoded certificate.");
        }
    }

    /** Gets the data associated to a given path inside a Certificate.
     * @param cert The certificate to process.
     * @param path The path to resolve inside certificate.
     * @throws RemoteException It is an ejb method...
     * @throws CertificateException If given certificate is invalid or unparseable.
     * @return The object indexed by given path, or null if nothing apropiate is found.
     */    
    public Object getData(X509Certificate cert, String path) throws RemoteException,CertificateException{
        try{
            //return new pkiva.parsing.Certificate(cert).getValue(path);
            // Changes auditing Aug-04
            pkiva.parsing.Certificate parsingCert = new pkiva.parsing.Certificate(cert);
            Object obj = parsingCert.getValue(path);

            infoAndAudit ( cert, path, obj );

            return obj;
        }
        catch(AuditingException ae){
            throw new RemoteException("Internal Error getting Data from certificate", ae);
        }
        catch(CertificateEncodingException cee){
            throw new CertificateException("Invalid encoded certificate.");
        }
        catch(IOException ioe){
            throw new CertificateException("Invalid encoded certificate.");
        }
    }

  protected void infoAndAudit ( X509Certificate cert, String path, Object result ) throws AuditingException
  {
    String sn = CertUtils.getSerialNumberAsHexa (  cert );
    String ca = cert.getIssuerDN().getName();
    StringBuffer sb = new StringBuffer ( "Get field '" );
    sb.append ( path ).append ( "' from Certificate SN [" ).append (sn).
      append ("] CA [").append ( ca ).append ( "]:" ).append ( result );
    String msg = sb.toString();
    pkiva.log.LogManager.getLogger(this.getClass()).info(msg);

    // Changes auditing Aug-04
    //pkiva.log.AuditManager.getAuditer(this.getClass()).audit(msg);
    CertDataExtraction auditOperation = new CertDataExtraction();
    auditOperation.setCert(cert);
    auditOperation.setDataPath(path);
    auditOperation.setDataItem(result.toString());
    pkiva.log.AuditManager.getAuditer(this.getClass()).audit(auditOperation);

  }

    /** Gets the data associated to a given path inside a Certificate.
     * @param cert The certificate to process, in DERObject form.
     * @param path The path to resolve inside certificate.
     * @throws RemoteException It is an ejb method...
     * @throws CertificateException If given certificate is invalid or unparseable.
     * @return The object indexed by given path, or null if nothing apropiate is found.
     */    
    public Object getData(DERObject cert, String path) throws RemoteException,CertificateException{
        try{
            return new pkiva.parsing.Certificate(cert).getValue(path);
        }
        catch(IOException ioe){
            throw new CertificateException("Invalid encoded certificate.");
        }
    }
    
    public void ejbActivate()  { }
    public void ejbPassivate()  { }
    public void ejbRemove()   { }
}

  public CertValidation ( )
  {
    super ( AuditOperation.CERTIFICATE_VALIDATION );
  }

  // Request Keys
  public void setCert ( X509Certificate cert ) throws AuditingException 
  {
    if ( cert != null )
    {
      try
      {
        setIssuer ( cert.getIssuerDN().getName() );
        setSubject ( cert.getSubjectDN().getName() );
        setSerialNumber ( CertUtils.getSerialNumberAsHexa (  cert ) );
        setFingerPrint ( CertUtils.getFingerPrintAsHexa ( cert ) );
      }
      catch ( Exception e)
      {
        throw new AuditingException ( "Exception auditing certificate data", e);
      }
    }
  }

  public void setIssuer ( String s )
  {
    addToRequest ( AuditKeys.CERT_ISSUER , AuditValue.newAsVarchar( s ) );
  }

  public void setSubject ( String s )
  {
    addToRequest ( AuditKeys.CERT_SUBJECT , AuditValue.newAsVarchar( s ) );
  }

  public void setSerialNumber ( String s )
  {
    addToRequest ( AuditKeys.CERT_SERIAL_NUMBER , AuditValue.newAsVarchar( s ) );
  }

  public void setFingerPrint ( String s )
  {
    addToRequest ( AuditKeys.CERT_FINGERPRINT , AuditValue.newAsVarchar( s ) );
  }

  public void setPolicies ( String s )
  {
    addToRequest ( AuditKeys.POLICIES , AuditValue.newAsVarchar( s ) );
  }

  public void setVCRequest ( String s )
  {
    addToRequest ( AuditKeys.VALIDATION_CHANNEL , AuditValue.newAsVarchar( s ) );
  }

  // Response Keys
  public void setState ( String s )
  {
    addToResponse ( AuditKeys.VALIDATION_STATE , AuditValue.newAsVarchar( s ) );
  }

  public void setVCResponse ( String s )
  {
    addToResponse ( AuditKeys.VALIDATION_CHANNEL , AuditValue.newAsVarchar( s ) );
  }

  public void setRevocationObject ( byte[] b )
  {
    addToResponse ( AuditKeys.REVOCATION_OBJECT , AuditValue.newAsBlob( b ) );
  }

  public void setPolicyTree ( String s )
  {
    addToResponse ( AuditKeys.POLICY_TREE , AuditValue.newAsVarchar( s ) );
  }

  public void setTrustAnchor ( TrustAnchor ta ) throws AuditingException
  {
    try
    {
      X509Certificate taCert = ta.getTrustedCert();
      if ( taCert != null)
      {
        setTrustAnchorSubject ( taCert.getSubjectDN().getName() );
        setTrustAnchorSN ( CertUtils.getSerialNumberAsHexa (  taCert ) );
        setTrustAnchorFingerPrint ( CertUtils.getFingerPrintAsHexa ( taCert ) );
      }
      else
        setTrustAnchorSubject ( ta.getCAName() );
    }
    catch ( Exception e)
    {
      throw new AuditingException ( "Exception auditing certificate data", e);
    }

  }

  public void setTrustAnchorSubject ( String s )
  {
    addToResponse ( AuditKeys.TRUST_ANCHOR_SUBJECT , AuditValue.newAsVarchar( s ) );
  }

  public void setTrustAnchorSN ( String s )
  {
    addToResponse ( AuditKeys.TRUST_ANCHOR_SERIAL_NUMBER , AuditValue.newAsVarchar( s ) );
  }

  public void setTrustAnchorFingerPrint ( String s )
  {
    addToResponse ( AuditKeys.TRUST_ANCHOR_FINGERPRINT , AuditValue.newAsVarchar( s ) );
  }



}

