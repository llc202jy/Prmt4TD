public class _EventChannelStub extends ObjectImpl
	implements EventChannel
{

	private String ids[] = {
		"IDL:omg.org/CosEventChannelAdmin/EventChannel:1.0"
	};
	public static final Class _opsClass;
	static Class class$org$omg$CosEventChannelAdmin$EventChannelOperations; /* synthetic field */

	static
	{
		_opsClass = class$org$omg$CosEventChannelAdmin$EventChannelOperations == null ? (class$org$omg$CosEventChannelAdmin$EventChannelOperations = class$("Org.omg.CosEventChannelAdmin.EventChannelOperations")) : class$org$omg$CosEventChannelAdmin$EventChannelOperations;
	//    0    0:getstatic       #40  <Field java.lang.Class Org.omg.CosEventChannelAdmin._EventChannelStub.class$org$omg$CosEventChannelAdmin$EventChannelOperations>
	//    1    3:ifnull          12
	//    2    6:getstatic       #40  <Field java.lang.Class Org.omg.CosEventChannelAdmin._EventChannelStub.class$org$omg$CosEventChannelAdmin$EventChannelOperations>
	//    3    9:goto            21
	//    4   12:ldc1            #7   <String "Org.omg.CosEventChannelAdmin.EventChannelOperations">
	//    5   14:invokestatic    #39  <Method java.lang.Class Org.omg.CosEventChannelAdmin._EventChannelStub.class$(java.lang.String)>
	//    6   17:dup
	//    7   18:putstatic       #40  <Field java.lang.Class Org.omg.CosEventChannelAdmin._EventChannelStub.class$org$omg$CosEventChannelAdmin$EventChannelOperations>
	//    8   21:putstatic       #32  <Field java.lang.Class Org.omg.CosEventChannelAdmin._EventChannelStub._opsClass>
	//*   9   24:return
	}

	public _EventChannelStub() {
		//    0    0:aload_0
		//    1    1:invokespecial   #25  <Method void ObjectImpl()>
		//    2    4:aload_0
		//    3    5:iconst_1
		//    4    6:anewarray       java.lang.String[]
		//    5    9:dup
		//    6   10:iconst_0
		//    7   11:ldc1            #1   <String "IDL:omg.org/CosEventChannelAdmin/EventChannel:1.0">
		//    8   13:aastore
		//    9   14:putfield        #47  <Field java.lang.String[] Org.omg.CosEventChannelAdmin._EventChannelStub.ids>
		//   10   17:return
	}

	static Class class$(String s) {
		try {
			return Class.forName(s);
			//    0    0:aload_0
			//    1    1:invokestatic    #42  <Method java.lang.Class java.lang.Class.forName(java.lang.String)>
			//    2    4:areturn
		} catch (ClassNotFoundException classnotfoundexception)
		//*   3    5:astore_1
		{
			throw new NoClassDefFoundError(classnotfoundexception.getMessage());
			//    4    6:new             #10  <Class java.lang.NoClassDefFoundError>
			//    5    9:dup
			//    6   10:aload_1
			//    7   11:invokevirtual   #46  <Method java.lang.String java.lang.Throwable.getMessage()>
			//    8   14:invokespecial   #26  <Method void NoClassDefFoundError(java.lang.String)>
			//    9   17:athrow
		}
	}

	public String[] _ids() {
		return ids;
		//    0    0:aload_0
		//    1    1:getfield        #47  <Field java.lang.String[] Org.omg.CosEventChannelAdmin._EventChannelStub.ids>
		//    2    4:areturn
	}

	public void destroy() {
		do {
			if (_is_local())
				break;
			//    0    0:aload_0
			//    1    1:invokevirtual   #31  <Method boolean Org.omg.CORBA.portable.ObjectImpl._is_local()>
			//    2    4:ifne            87
			Org.omg.CORBA.portable.InputStream inputstream = null;
			//    3    7:aconst_null
			//    4    8:astore_1
			try {
				Org.omg.CORBA.portable.OutputStream outputstream = _request("destroy", true);
				//    5    9:aload_0
				//    6   10:ldc1            #3   <String "destroy">
				//    7   12:iconst_1
				//    8   13:invokevirtual   #35  <Method Org.omg.CORBA.portable.OutputStream Org.omg.CORBA.portable.ObjectImpl._request(java.lang.String, boolean)>
				//    9   16:astore          4
				inputstream = _invoke(outputstream);
				//   10   18:aload_0
				//   11   19:aload           4
				//   12   21:invokevirtual   #30  <Method Org.omg.CORBA.portable.InputStream Org.omg.CORBA.portable.ObjectImpl._invoke(Org.omg.CORBA.portable.OutputStream)>
				//   13   24:astore_1
				//*  14   25:jsr             79
				return;
				//   15   28:return
			} catch (RemarshalException _ex) {
			}
			//   16   29:pop
			//*  17   30:goto            67
			catch (ApplicationException applicationexception)
			//*  18   33:astore          4
			{
				String s = applicationexception.getId();
				//   19   35:aload           4
				//   20   37:invokevirtual   #45  <Method java.lang.String Org.omg.CORBA.portable.ApplicationException.getId()>
				//   21   40:astore          5
				throw new RuntimeException("Unexpected exception " + s);
				//   22   42:new             #11  <Class java.lang.RuntimeException>
				//   23   45:dup
				//   24   46:new             #13  <Class java.lang.StringBuffer>
				//   25   49:dup
				//   26   50:ldc1            #2   <String "Unexpected exception ">
				//   27   52:invokespecial   #28  <Method void StringBuffer(java.lang.String)>
				//   28   55:aload           5
				//   29   57:invokevirtual   #38  <Method java.lang.StringBuffer java.lang.StringBuffer.append(java.lang.String)>
				//   30   60:invokevirtual   #51  <Method java.lang.String java.lang.StringBuffer.toString()>
				//   31   63:invokespecial   #27  <Method void RuntimeException(java.lang.String)>
				//   32   66:athrow
			} finally
			//*  33   67:jsr             79
			//*  34   70:goto            0
			//*  35   73:astore_2
			//*  36   74:jsr             79
			//*  37   77:aload_2
			//*  38   78:athrow
			//*  39   79:astore_3
			{
				_releaseReply(inputstream);
				//   40   80:aload_0
				//   41   81:aload_1
				//   42   82:invokevirtual   #34  <Method void Org.omg.CORBA.portable.ObjectImpl._releaseReply(Org.omg.CORBA.portable.InputStream)>
			}
			//   43   85:ret             3
		} while (true);
		ServantObject servantobject = _servant_preinvoke("destroy", _opsClass);
		//   44   87:aload_0
		//   45   88:ldc1            #3   <String "destroy">
		//   46   90:getstatic       #32  <Field java.lang.Class Org.omg.CosEventChannelAdmin._EventChannelStub._opsClass>
		//   47   93:invokevirtual   #37  <Method Org.omg.CORBA.portable.ServantObject Org.omg.CORBA.portable.ObjectImpl._servant_preinvoke(java.lang.String, java.lang.Class)>
		//   48   96:astore_1
		if (servantobject == null)

			//*  49   97:aload_1
			//*  50   98:ifnonnull       111
			throw new UNKNOWN("local invocations not supported!");
		//   51  101:new             #15  <Class Org.omg.CORBA.UNKNOWN>
		//   52  104:dup
		//   53  105:ldc1            #6   <String "local invocations not supported!">
		//   54  107:invokespecial   #29  <Method void UNKNOWN(java.lang.String)>
		//   55  110:athrow
		EventChannelOperations eventchanneloperations = (EventChannelOperations) servantobject.servant;
		//   56  111:aload_1
		//   57  112:getfield        #50  <Field java.lang.Object Org.omg.CORBA.portable.ServantObject.servant>
		//   58  115:checkcast       #22  <Class Org.omg.CosEventChannelAdmin.EventChannelOperations>
		//   59  118:astore_2
		try {
			eventchanneloperations.destroy();
			//   60  119:aload_2
			//   61  120:invokeinterface #41  <Method void Org.omg.CosEventChannelAdmin.EventChannelOperations.destroy()>
		} finally
		//*  62  125:jsr             137
		//*  63  128:goto            146
		//*  64  131:astore_3
		//*  65  132:jsr             137
		//*  66  135:aload_3
		//*  67  136:athrow
		//*  68  137:astore          4
		{
			_servant_postinvoke(servantobject);
			//   69  139:aload_0
			//   70  140:aload_1
			//   71  141:invokevirtual   #36  <Method void Org.omg.CORBA.portable.ObjectImpl._servant_postinvoke(Org.omg.CORBA.portable.ServantObject)>
		}
		//   72  144:ret             4
		//   73  146:return
	}

