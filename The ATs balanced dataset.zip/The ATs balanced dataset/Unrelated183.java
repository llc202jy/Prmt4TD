package org.mortbay.jetty;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.mortbay.component.LifeCycle;

/** Session ID Manager.
 * Manages session IDs across multiple contexts.
 * @author gregw
 *
 */
/* ------------------------------------------------------------ */
/**
 * @author gregw
 *
 */
public interface SessionIdManager extends LifeCycle
{
    /**
     * @param id The session ID without any cluster node extension
     * @return True if the session ID is in use by at least one context.
     */
    public boolean idInUse(String id);
    
    /**
     * Add a session to the list of known sessions for a given ID.
     * @param session The session
     */
    public void addSession(HttpSession session);
    
    /**
     * Remove session from the list of known sessions for a given ID.
     * @param session
     */
    public void removeSession(HttpSession session);
    
    /**
     * Call {@link HttpSession#invalidate()} on all known sessions for the given id.
     * @param id The session ID without any cluster node extension
     */
    public void invalidateAll(String id);
    
    /**
     * @param request
     * @param created
     * @return
     */
    public String newSessionId(HttpServletRequest request,long created);
    
    public String getWorkerName();
    
    
    /* ------------------------------------------------------------ */
    /** Get a cluster ID from a node ID.
     * Strip node identifier from a located session ID.
     * @param nodeId
     * @return
     */
    public String getClusterId(String nodeId);
    
    /* ------------------------------------------------------------ */
    /** Get a node ID from a cluster ID and a request
     * @param clusterId The ID of the session
     * @param request The request that for the session (or null)
     * @return The session ID qualified with the node ID.
     */
    public String getNodeId(String clusterId,HttpServletRequest request);
public class Driver extends JFrame {
    private JPanel jPanel1 = new JPanel();
    private JButton jButton2 = new JButton();
    private JButton jButton3 = new JButton();
    private JButton jButton4 = new JButton();
    private JButton jButton1 = new JButton();
    private JPanel jPanel2 = new JPanel();
    private JTextField jTextField1 = new JTextField();
    private BorderLayout borderLayout1 = new BorderLayout();
    private BorderLayout borderLayout2 = new BorderLayout();
    private TitledBorder titledBorder1;

    private Test test;
    private JScrollPane jScrollPane1 = new JScrollPane();
    private JTextArea jTextArea1 = new JTextArea();
    private JButton jButton5 = new JButton();
    private JPanel jPanel3 = new JPanel();
    private JButton jButton6 = new JButton();
    private JButton jButton7 = new JButton();

    public Driver(Test t, String title) {
        test = t;
        try {
            jbInit();
            this.setTitle(title);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    private void jbInit() throws Exception {
        titledBorder1 = new TitledBorder("");
        jButton2.setText("- Prov");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton2_actionPerformed(e);
            }
        });
        jButton3.setActionCommand("Rapido");
        jButton3.setText("Rapido");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton3_actionPerformed(e);
            }
        });
        jButton4.setText("- Lsnr");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton4_actionPerformed(e);
            }
        });
        jButton1.setText("+ Prov");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton1_actionPerformed(e);
            }
        });
        this.getContentPane().setLayout(borderLayout1);
        jPanel2.setLayout(borderLayout2);
        jPanel1.setBorder(BorderFactory.createRaisedBevelBorder());
        jPanel2.setBorder(BorderFactory.createRaisedBevelBorder());
        jTextArea1.setBorder(BorderFactory.createLoweredBevelBorder());
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton5_actionPerformed(e);
            }
        });
        jButton5.setText("Local");
        jButton5.setMinimumSize(new Dimension(60, 27));
        jButton5.setActionCommand("Local");
        jButton5.setMaximumSize(new Dimension(60, 27));
        jPanel3.setBorder(BorderFactory.createRaisedBevelBorder());
        jButton6.setMaximumSize(new Dimension(60, 27));
        jButton6.setMinimumSize(new Dimension(60, 27));
        jButton6.setActionCommand("Global");
        jButton6.setText("Global");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton6_actionPerformed(e);
            }
        });
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton7_actionPerformed(e);
            }
        });
        jButton7.setActionCommand("+ Listener");
        jButton7.setText("+ Lsnr");
        jPanel1.add(jButton1, null);
        jPanel1.add(jButton2, null);
        jPanel1.add(jButton3, null);
        jPanel1.add(jButton7, null);
        jPanel1.add(jButton4, null);
        this.getContentPane().add(jPanel3, BorderLayout.NORTH);
        jPanel3.add(jButton6, null);
        jPanel3.add(jButton5, null);
        this.getContentPane().add(jPanel2, BorderLayout.CENTER);
        jPanel2.add(jTextField1,  BorderLayout.SOUTH);
        jPanel2.add(jScrollPane1, BorderLayout.CENTER);
        this.getContentPane().add(jPanel1, BorderLayout.SOUTH);
        jScrollPane1.getViewport().add(jTextArea1, null);

        this.setSize(new Dimension(499, 300));

        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) { test.terminate(); }
        });
    }
