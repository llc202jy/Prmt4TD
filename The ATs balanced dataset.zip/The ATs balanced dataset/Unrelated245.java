package com.user;

import java.util.*;
import java.awt.EventQueue;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import com.Connection;
import com.ConversationManager;
import com.ConnectDialog;
import com.BuddyListPanel;
import com.user.Presence;


/*
	BuddyList construct
	
	HY - 
	inside is an inner class, Buddy, which
	are self-explanatory, but the reason I made them inline
	is because 1) I'm too lazy to put it in another file
	2) these two classes don't deserve another file
	because they aren't used outside of BuddyList
	anyways.
	
	In a data-view perspective, BuddyList represents the data
	section of the whole BuddyList implementation, and
	BuddyListPanel represents the "view" part.
	
	The BuddyList carries a LinkedList of groups, and a LinkedList
	of buddies. Buddies can be assigned groups, but not the other
	around (the Group class has no knowledge whatsoever of
	who's in that particular Group). 
	
	

*/

public class BuddyList
{
	/* singleton */
	private static BuddyList instance = null;	//self-instantiation
	
	/*
		LinkedList of Buddies
	*/
	
	private Map buddies = null;	//256 is a good number of buddies for now
	
	/*
		LinkedList of Groups
	*/
	
	private Map groups = null;
	
	/*
	
		BuddyList constructor
	*/
	
	private boolean buddyListLoaded = false;
	
	private BuddyList()
	{
		buddies = new LinkedHashMap(256);
		groups = new LinkedHashMap(256);
	}
	
	public static void initBuddyList()
	{
		instance = new BuddyList();	
		
	}
	
	/*
		send Buddy List request
		
		called right after successful authentication, this
		asks the server to send the client the stored
		buddy list
	*/
	
	public static void requestBuddyList(Connection conn) throws Exception
	{
		if (conn == null)
			throw new Exception("BuddyList.requestBuddyList(): invalid Connection parameter!");
			
		/*
			the request looks like this:
			
			<service type="buddylist">
				<request />
			</service>
		*/
			
		//construct xml
		conn.sendXML(
			"<service type=\"buddylist\"><request /></service>"
			{
				if (e == null)
					return null;
					
				String tip = super.getToolTipText(e);
					
				return tip;
			}	
			
		};

	private void buildMenu()
	{
		if (menuLoaded == true)
			return;
		
		menuBar = new JMenuBar();
		menuBar.setBackground(uiColor);
		
		actionsMenu = new JMenu("Actions");	
