
 * @author Georges Stephan
 */
public class AuthenticationPopUp extends JDialog {
	private boolean userCanceled=false;
	private String username;
	private String password;
	private String title;
	// Swing
	private Icon icon;
	private JLabel titleLabel = new JLabel("Database Login");
	private JPanel jPanelOuter = new JPanel(new BorderLayout(5,5));
	private JPanel jPanelUser = new JPanel(new BorderLayout(5,5));
	private JPanel jPanelPass = new JPanel(new BorderLayout(5,5));
	private JPanel jPanelInner = new JPanel(new BorderLayout(5,5));
	private JButton jButtonOK = new JButton("OK");
	private JButton jButtonCancel = new JButton("Cancel");
	private JMenuTextField jTextField1 = new JMenuTextField();
	private JPasswordField jPasswordField = new JPasswordField();
	private JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

	public AuthenticationPopUp(String title) {
		this.title=title;
		try {
			init();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public AuthenticationPopUp(String title,String username) {
		this.title=title;
		this.username=username;
		try {
			init();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
	
	
	public AuthenticationPopUp(String title,Icon icon) {
		this.title=title;
		this.icon=icon;
		try {
			init();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public AuthenticationPopUp(String title,String username,Icon icon) {
		this.title=title;
		this.username=username;
		this.icon=icon;
		try {
			init();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
	
	public String getUsername() {
		return this.username;
	}
	
	public String getPassword() {
		return this.password;
	}
	
	public char[] getPasswordAsCharArray() {
		return jPasswordField.getPassword();
	}
	
	private void jButtonOK_ActionPerformed(ActionEvent e) {
		username = jTextField1.getText().trim();
		password = String.valueOf(jPasswordField.getPassword());
		this.dispose();
	}
	
	private void jButtonCancel_ActionPerformed(ActionEvent e) {
		this.username=null;
		this.password=null;
		this.dispose();
		setUserCanceled(true);
	}
	
	
	private void init() throws Exception {
		if(title!=null && icon!=null) {
			titleLabel = new JLabel(title,icon,JLabel.CENTER);
		} else if(title!=null) {
			titleLabel = new JLabel(title,JLabel.CENTER);
		}
		
		jButtonOK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jButtonOK_ActionPerformed(e);
			}
		});
		jButtonCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jButtonCancel_ActionPerformed(e);
			}
		});
		jPasswordField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jButtonOK_ActionPerformed(e);
			}
		
		});
		
		jPanelUser.add(new JLabel("Login :"),BorderLayout.NORTH);
		jPanelUser.add(jTextField1,BorderLayout.SOUTH);
		
		jPanelPass.add(new JLabel("Password :"),BorderLayout.NORTH);
		jPanelPass.add(jPasswordField,BorderLayout.SOUTH);

		jPanelInner.add(jPanelUser,BorderLayout.NORTH);
		jPanelInner.add(jPanelPass,BorderLayout.SOUTH);
		
		buttonsPanel.add(jButtonOK);
		buttonsPanel.add(jButtonCancel);
		jPanelOuter.add(titleLabel,BorderLayout.NORTH);
		jPanelOuter.add(jPanelInner,BorderLayout.CENTER);
		jPanelOuter.add(buttonsPanel,BorderLayout.SOUTH);
		jButtonCancel.setToolTipText("Cancel login to the database.");
		buttonsPanel.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));

		if(username!=null) {
			// A username was defined
			titleLabel.setText(title);
			jTextField1.setText(username);
			jPasswordField.requestFocus();
		}
		
		getContentPane().setLayout(new BorderLayout());
		jPanelOuter.setBorder(BorderFactory.createEmptyBorder(4,4,4,4));
		getContentPane().add(jPanelOuter,BorderLayout.NORTH);
		getContentPane().add(buttonsPanel,BorderLayout.SOUTH);
		setTitle("Access");
		setModal(true);
		setResizable(false);
		setPreferredSize(new Dimension(400,250));
		pack();
		UIUtils.centerWindowOnScreen(this);		
		this.setVisible(true);
	}	

	public boolean isUserCanceled() {
		return userCanceled;
	}
	
	public void setUserCanceled(boolean userCanceled) {
		this.userCanceled = userCanceled;
	}
	
	public static void main(String[] args) {
		new AuthenticationPopUp("Tata");
		new AuthenticationPopUp("Tata","Georges",null);
//		new AuthenticationPopUp("Tata",null);
	}
}