package com.ibm.awb.misc;

import java.net.URL;
import java.io.File;

import java.io.IOException;

/**
 * The <tt>URIPattern</tt> class represents a URI pattern.
 *
 * @version     1.00    $Date: 2000/07/14 06:01:26 $
 * @author      ONO Kouichi
 */
public class URIPattern {
  private static final char CHAR_COLON = ':';
  private static final char PROTOCOL_TERMINATOR = CHAR_COLON;
  private static final char CHAR_SLASH = '/';
  private static final String STRING_SLASH = String.valueOf(CHAR_SLASH);
  private static final char DIRECTORY_DELIMITER = CHAR_SLASH;
  private static final String HOSTNAME_LEADER = STRING_SLASH+STRING_SLASH;
  private static final char PORT_LEADER = CHAR_COLON;
  private static final String FILE_LEADER = STRING_SLASH;

  private static final char CHAR_ASTERISK       = '*';
  private static final char CHAR_HYPHEN         = '-';
  private static final char CHAR_DOT            = '.';
  private static final String STRING_ASTERISK   = String.valueOf(CHAR_ASTERISK);
  private static final String STRING_HYPHEN     = String.valueOf(CHAR_HYPHEN);
  private static final String STRING_DOT        = String.valueOf(CHAR_DOT);
  private static final String WILDCARD_HOST     = STRING_ASTERISK;
  private static final String WILDCARD_PORT     = STRING_ASTERISK;
  private static final String WILDCARD_PROTOCOL = STRING_ASTERISK;
  private static final int USE_DEFAULT_PORT     = -1;
  private static final String WILDCARD_ANYDIR   = STRING_HYPHEN;
  private static final String WILDCARD_SUBDIR   = STRING_ASTERISK;
  private static final String DOMAIN_DELIMITER  = STRING_DOT;

  private static final String GREATER_THAN_OR_EQUAL     = ">=";
  private static final String LESS_THAN_OR_EQUAL        = "<=";
  private static final String GREATER_THAN              = ">";
  private static final String LESS_THAN                 = "<";
  private static final String BETWEEN_PORTS             = "-";

  private static final String PROTOCOL_FILE             = "file";

  private String _pattern  = null;
  private String _protocol = null;
  private String _host     = null;
  private String _port     = null;
  private PortPattern _ppat = null;
  private String _file     = null;

  public URIPattern(String pattern) throws MalformedURIPatternException {
    _pattern = pattern;
    final int idxProtocol = pattern.indexOf(PROTOCOL_TERMINATOR);
    if(idxProtocol==-1) {
      throw new MalformedURIPatternException("Protocol does not specified : \""+pattern+"\".");
    }
    _protocol = pattern.substring(0,idxProtocol);
    final String body = pattern.substring(idxProtocol+1);
    if(body.startsWith(HOSTNAME_LEADER)) {
      final String rest = body.substring(2);
      String hostpart = null;
      final int idxFile = rest.indexOf(FILE_LEADER);
      if(idxFile==-1) {
	hostpart = rest;
	_file = "";
      } else {
	hostpart = rest.substring(0,idxFile);
	_file = rest.substring(idxFile);
      }
      final int idxPort = hostpart.indexOf(PORT_LEADER);
      if(idxPort==-1) {
	_host = hostpart;
	_port = null;
      } else {
	_host = hostpart.substring(0,idxPort);
	_port = hostpart.substring(idxPort+1);
      }
    } else if(body.startsWith(FILE_LEADER)) {
      // no hostpart specifed
      _host = "";
      _port = null;
      _file = body;
    } else {
      throw new MalformedURIPatternException("Hostname does not specified : \""+pattern+"\".");
    }
    if(_file==null || _file.equals("")) {
      _file = FILE_LEADER;
    }
    try {
      _ppat = new PortPattern(_port);
    }
    catch(IllegalArgumentException excpt) {
      throw new MalformedURIPatternException(excpt.toString());
    }
  }

  public URIPattern(URL url) throws MalformedURIPatternException {
    _pattern = url.toString();
    _protocol = url.getProtocol();
    _host = url.getHost();
    final int port = url.getPort();
    _port = String.valueOf(port);
    try {
      _ppat = new PortPattern(port);
    }
    catch(IllegalArgumentException excpt) {
      throw new MalformedURIPatternException(excpt.toString());
    }
    _file = url.getFile();
  }

  public boolean isMatch(URL url) {
    if(url==null) {
      // nowhere
      return false;
    }

    // check protocol
    final String protocol = url.getProtocol();
    if(!isMatchProtocol(_protocol,protocol)) {
      return false;
    }

    final String filename = url.getFile();

    if(protocol.equalsIgnoreCase(PROTOCOL_FILE)) {
      // check file name
      final String canonFileA = canonicalFilename(_file);
      final String canonFileB = canonicalFilename(filename);
      if(canonFileA==null || canonFileB==null) {
	return false;
      }
//      return fileA.compareTo(fileB); // JDK 1.2
      return isMatchFile(canonFileA, canonFileB);
    } else { // ATP or HTTP
      // check host name
      final String host = url.getHost();
      if(_host==null || host==null) {
	return false;
      }
      if(!isMatchHost(_host, host)) {
	return false;
      }
      // check port number
      final int port = url.getPort();
      if(!isMatchPort(_ppat, port)) {
	return false;
      }
      // check file name
      return isMatchFile(_file, filename, STRING_SLASH);
    }
  }

  public final static String canonicalFilename(String filename) {
    if(filename==null) {
      return null;
    }
    final int len = filename.length();
    if(len<1) {
      return null;
    }
    String fn = filename;
    boolean usewild = false;
    final String dir = filename.substring(len-1);
    if(len>1) {
      final String sep = filename.substring(len-2,len-1);
      if((sep.equals(STRING_SLASH) || sep.equals(File.separator)) &&
	 (dir.equals(WILDCARD_ANYDIR) || dir.equals(WILDCARD_SUBDIR))) {
	usewild = true;
	fn = filename.substring(0, len-1);
      }
    }
    final File file = new File(fn);
    if(file==null) {
      return null;
    }
    String canonFile = file.getPath();
    try {
      canonFile = file.getCanonicalPath();
    }
    catch(IOException excpt) {
      return null;
    }
    if(usewild==true) {
      if(!canonFile.endsWith(File.separator)) {
	canonFile += File.separator;
      }
      canonFile += dir;
    }
    return canonFile;
  }

  final static private boolean isMatchHost(String pattern, String host) {
    if(pattern.equals(WILDCARD_HOST)) {
      return true;
    }

    final String anyDir = WILDCARD_HOST+DOMAIN_DELIMITER;
    if(pattern.startsWith(anyDir)) {
      final String domain = pattern.substring(2);
      return host.endsWith(domain);
    } else {
      return host.equalsIgnoreCase(pattern);
    }
  }

  final static private boolean isMatchProtocol(String pattern, String protocol) {
    if(pattern.equals(WILDCARD_PROTOCOL)) {
      return true;
    }
    return pattern.equalsIgnoreCase(protocol);
  }

  final static boolean isMatchFile(String pattern, String path) {
    return isMatchFile(pattern, path, File.separator);
  }

  final static boolean isMatchFile(String pattern, String path, String separator) {
    if(pattern==null || path==null || separator==null) {
      return false;
    }
    if(pattern.equals(separator)) {
      return true;
    }

    final String anyDir = separator+WILDCARD_ANYDIR;
    if(pattern.equals(anyDir)) {
      return true;
    }

    final String subDir = separator+WILDCARD_SUBDIR;

    if(pattern.endsWith(anyDir)) {
      final String pat = pattern.substring(0, pattern.length()-1);
      String p = path;
      final int idx = path.lastIndexOf(separator);
      if(idx>=0) {
	p = path.substring(0, idx+1);
      }
      return p.startsWith(pat);
    } else if(pattern.endsWith(subDir)) {
      final String pat = pattern.substring(0, pattern.length()-1);
      String p = path;
      final int idx = path.lastIndexOf(separator);
      if(idx>=0) {
	p = path.substring(0, idx+1);
      }
      return p.equals(pat);
    } else {
      return path.equals(pattern);
    }
  }

  final static boolean isMatchPort(PortPattern pattern, int port) {
    if(pattern==null) {
      return false;
    }

    return pattern.isMatch(port);
  }

  public String getPattern() {
    return _pattern;
  }

  public String getProtocol() {
    return _protocol;
  }

  public String getHost() {
    return _host;
  }

  public String getPort() {
    return _port;
  }

  public PortPattern getPortPattern() {
    return _ppat;
  }

  public String getFile() {
    return _file;
  }

  public boolean equals(Object obj) {
    if(obj instanceof URIPattern) {
      URIPattern uripat = (URIPattern)obj;
      return equals(uripat);
    }
    return false;
  }

  public boolean equals(URIPattern uripat) {
    return equals(uripat._protocol, uripat._host, uripat._ppat, uripat._file);
  }

  public boolean equals(String protocol, String host, PortPattern ppat, String file) {
    if(protocol==null || _protocol==null) {
      return false;
    }
    if(!protocol.equals(_protocol)) {
      return false;
    }
    if(protocol.equals(PROTOCOL_FILE)) {
      if(file==null || _file==null) {
	return false;
      }
      if(!file.equals(_file)) {
	return false;
      }
      return true;
    } else {
      if(host==null || _host==null) {
	return false;
      }
      if(!host.equals(_host)) {
	return false;
      }
      if(ppat!=null && !ppat.equals(_ppat)) {
	return false;
      }
      if(file!=null && !file.equals(_file)) {
	return false;
      }
      return true;
    }
  }

  public String toString() {
    String hostpart = HOSTNAME_LEADER+_host;
    if(_port!=null) {
      hostpart = hostpart+PORT_LEADER+_port;
    }
    return _protocol+PROTOCOL_TERMINATOR+hostpart+_file;
  }

  public static void main(String[] arg) {
    URIPattern uripat = null;
    int i;
    for(i=0; i<arg.length; i++) {
      try {
	uripat = new URIPattern(arg[i]);
      }
      catch(MalformedURIPatternException excpt) {
	excpt.printStackTrace();
      }
      System.out.println(uripat.toString());
    }
  }
}
package com.ibm.net.protocol.atp;

import com.ibm.maf.*;
//import com.ibm.maf.atp.*;
import com.ibm.awb.misc.*;

import java.rmi.*;

import java.net.URLConnection;
import java.net.URL;
import java.net.MalformedURLException;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Properties;

/**
 * An instance of this class creates a communication link between an
 * application and an atp server.
 *
 * @version     1.10	$Date: 2000/07/14 06:01:29 $
 * @author      Mitsuru Oshima
 */

public class URLConnectionForATP extends URLConnection {

    protected static boolean verbose = false;

    static AgentProfile agent_profile = null;
    /*
     *
     */
    static {
	Resource res = Resource.getResourceFor("aglets");
	verbose = res.getBoolean("aglets.verbose", false);

	short one = (short)1;

	agent_profile = new AgentProfile(one, // Java
					 one, // Aglets
					 "Aglets",
					 one, // major,
					 one, // minor,
					 one, // serialization,
					 null);
    }

    /*
     *
     */
    private InputStream _inputStream = null;

//    MAFAgentSystem_ATP agentsystem;
    MAFAgentSystem agentsystem;
    Properties request_properties = new Properties();

    /**
     * Create a new instance of this class.
     * @param url a destination URL to which the application connects.
     * The protocol is "atp".
     */                                          
    public URLConnectionForATP(URL url) throws IOException {
	super( url );
    }

    /**
     * Make a comminucation link with the destination.
     *
     * @exception IOException if can not make a communication link.
     */                                          
    synchronized public void connect() throws IOException {
	if (connected) {
	    return;
	}
	agentsystem = MAFAgentSystem.getMAFAgentSystem(url.toString());
//		MAFAgentSystem_ATPClient.getMAFAgentSystem_ATP(url.toString());
	if (agentsystem == null) {
	    throw new IOException("ConnectionFailed");
	}
	connected = true;
    }

    /*
     * Sets request parameters
     */
    public void setRequestProperty(String key, String value) {
	if (connected) {
	    throw new IllegalAccessError("Already connected");
	}
	request_properties.put(key, value);
    }

    public String getRequestProperty(String key) {
	return request_properties.getProperty(key);
    }

    /**
     * Get an input stream of the communication link.
     * @return an input stream.
     * @exception IOException if the communication link has a problem.
     */
    synchronized public InputStream getInputStream() throws IOException {
	if (_inputStream != null) {
	    return _inputStream;
	}
	connect();
	if(!connected) {
	    return null;
	}
	
	try {
	    byte result[][] = agentsystem.fetch_class(null,
						      url.toString(),
						      agent_profile);

	    if (result != null && result.length == 1) {
		headers.put("content-length",
			    String.valueOf(result[0].length));
		return new ByteArrayInputStream(result[0]);
	    } else {
		throw new IOException(url.toString());
	    }
	} catch (Exception ex) {
	    ex.printStackTrace();
	    throw new IOException(ex.getClass().getName() + ":" +
				  ex.getMessage());
	}
    }

    /*
     * Header field
     */
    private Properties headers = new Properties();

    public String getHeaderField(String key) {
	return headers.getProperty(key.toLowerCase());
    }

    public String getHeaderField(String key, String defValue) {
	String ret = getHeaderField(key);
	return ret == null ? defValue : ret;
    }
}

**
 * Class ServerPrefsDialog represents the dialog for
 * server preferences dialog,
 * e.g. aglets.public.root, aglets.public.aliases.
 *
 * @version     1.00    98/05/27
 * @author      Hideki Tai
 */

final class ServerPrefsDialog extends TahitiDialog implements ActionListener, ItemListener {

    private TextField _pubRoot;
    private List _aliases;
    private TextField _alias_1;
    private TextField _alias_2;

    private Button _alias_add;
    private Button _alias_remove;
    private Button _alias_modify;

    static private final String ALIASES_SEP = " -> ";

    /*
     * Singleton instance reference.
     */
    private static ServerPrefsDialog _instance = null;

    /*
     * Singletion method to get the instnace
     */
    static ServerPrefsDialog getInstance(MainWindow parent) {
	if (_instance == null) {
	    _instance = new ServerPrefsDialog(parent);
	} else {
	    _instance.updateValues();
	}
	return _instance;
    }

    private ServerPrefsDialog(MainWindow parent) {
	super(parent, "Server Preferences", true);

	makePanel();

	addButton("OK", this);
	addButton("Cancel", this);
	addButton("Restore Defaults", this);
    }


    /*
     * Layouts all components.
     */
    protected void makePanel() {
	GridBagPanel p = new GridBagPanel();
	add("Center", p);

	GridBagConstraints cns = new GridBagConstraints();
	cns.fill = GridBagConstraints.BOTH;
	cns.weightx = 1.0;
	cns.weighty = 1.0;
	cns. ipadx = cns.ipady = 5;
	cns.insets = new Insets(5,5,5,5);
	p.setConstraints(cns);

	BorderPanel pubRootPanel = new BorderPanel("Root Path");
	p.add(pubRootPanel, GridBagConstraints.REMAINDER);

	setupPubRootPanel(pubRootPanel);

	updateValues();
    }

    private void setupPubRootPanel(BorderPanel p) {
	GridBagConstraints cns = new GridBagConstraints();

	cns.fill = GridBagPanel.NONE;
	cns.anchor = GridBagConstraints.WEST;
	cns.insets = p.topInsets();
	p.add(new Label("Public Root:"), cns);

	_pubRoot = new TextField(40);
	cns.fill = GridBagConstraints.HORIZONTAL;
	cns.anchor = GridBagConstraints.WEST;
	cns.gridwidth = GridBagConstraints.REMAINDER;
	cns.weightx = 1.0;
	p.add(_pubRoot, cns);

	BorderPanel aliasesPanel = new BorderPanel("Aliases");
	cns = new GridBagConstraints();
	cns.fill = GridBagPanel.BOTH;
	cns.gridwidth = 2;
	cns.weighty = 1.0;
	cns.insets = new Insets(5,5,5,5);
	p.add(aliasesPanel, cns);

	{
	    GridBagConstraints cns2 = new GridBagConstraints();
	    cns2.anchor = GridBagConstraints.WEST;
	    cns2.fill = GridBagConstraints.BOTH;
	    cns2.weightx = 1.0;
	    cns2.weighty = 1.0;
	    cns2.insets = aliasesPanel.topInsets();
	    cns2.insets.bottom = aliasesPanel.bottomInsets().bottom;
	    aliasesPanel.setConstraints(cns2);
	    GridBagPanel p1 = new GridBagPanel();
	    aliasesPanel.add(p1);

	    cns2 = new GridBagConstraints();
	    cns2.anchor = GridBagConstraints.WEST;
	    cns2.fill = GridBagConstraints.HORIZONTAL;
	    cns2.weightx = 1.0;
	    cns2.weighty = 1.0;
	    p1.setConstraints(cns2);

	    _aliases = new List(5);
	    _aliases.addActionListener(this);
	    _aliases.addItemListener(this);
	    p1.add(_aliases, GridBagConstraints.REMAINDER, 0.1);

	    _alias_1 = new TextField(20);
	    _alias_2 = new TextField(20);
	    {
		GridBagPanel pp = new GridBagPanel();
		GridBagConstraints cns3 = new GridBagConstraints();
		cns3.fill = GridBagConstraints.HORIZONTAL;
		cns3.weightx = 1.0;
		cns3.weighty = 0.0;
		pp.setConstraints(cns3);
		pp.add(new Label("/"));
		pp.add(_alias_1);

		pp.add(new Label("->"), new GridBagConstraints());

		pp.add(_alias_2);
		p1.add(pp);
//		p1.add(pp, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL);
	    }

	    _alias_add = new Button("Add");
	    _alias_remove = new Button("Remove");
	    _alias_modify = new Button("Modify");
	    _alias_add.addActionListener(this);
	    _alias_remove.addActionListener(this);
	    _alias_modify.addActionListener(this);
	    {
		Panel pp = new Panel(new FlowLayout(FlowLayout.RIGHT));
		pp.add(_alias_add);
		pp.add(_alias_remove);
		pp.add(_alias_modify);
		p1.add(pp, GridBagConstraints.REMAINDER);
	    }
	}
    }

    private void updateValues() {
	Resource aglets_res = Resource.getResourceFor("aglets");
	String public_root = aglets_res.getString("aglets.public.root", "");
	String public_root_aliases[] =
	    aglets_res.getStringArray("aglets.public.aliases", ",");

	_pubRoot.setText(public_root);
	_aliases.removeAll();
	for (int i = 0; i < public_root_aliases.length; i++) {
	    if (public_root_aliases[i] != null
		&& public_root_aliases[i].length() > 0) {
		int idx = public_root_aliases[i].indexOf(ALIASES_SEP);
		if (idx < 0) {
		    System.out.println("Illegal resource setting in aglets.properties: "
				       + public_root_aliases[i]);
		} else {
		    _aliases.add(public_root_aliases[i]);
		}
	    }
	}
    }

    private void commitValues() {
	Resource aglets_res = Resource.getResourceFor("aglets");
	String public_root = _pubRoot.getText();
	if (!public_root.endsWith(File.separator)) {
	    public_root = public_root + File.separator;
	}
	aglets_res.setResource("aglets.public.root", public_root);

	StringBuffer sb = new StringBuffer();
	String items[] = _aliases.getItems();
	if (items != null && items.length > 0) {
	    sb.append(items[0]);
	    for (int i = 1; i < items.length; i++) {
		sb.append("," + items[i]);
	    }
	}

	aglets_res.setResource("aglets.public.aliases", sb.toString());

	String aglet_path = aglets_res.getString("aglets.class.path");
	if (aglet_path == null)
	    aglet_path = "";
	aglet_path = aglet_path.trim();
	if (aglet_path.length() > 0 &&
	    aglet_path.charAt(aglet_path.length() - 1) != ',') {
	    aglet_path = aglet_path + ",";
	}
	aglet_path = aglet_path + public_root;
	aglets_res.setResource("aglets.class.path", aglet_path);
    }

    public void actionPerformed(java.awt.event.ActionEvent ev) {
	String cmd = ev.getActionCommand();
	if ("Add".equals(cmd)) {
	    String ali_name = _alias_1.getText();
	    String ali_path = _alias_2.getText();
	    if (ali_name.startsWith("/")==false) {
		ali_name = "/" + ali_name;
	    }
	    try {
		String entry = getAliasEntry(ali_name, ali_path);
		String items[] = _aliases.getItems();
		int i = 0;
		while (i < items.length) {
		    if (entry.equals(items[i])) {
			break;
		    }
		    i++;
		}
		if (i >= items.length) {
		    _aliases.add(entry);
		}
	    } catch (NullPointerException ex) {
		// No text was set in the TextTield (_alias_1, _alias_2)
	    }
	} else if ("Remove".equals(cmd)) {
	    int idx = _aliases.getSelectedIndex();
	    if (idx >= 0) {
		_aliases.delItem(idx);
	    }
	} else if ("Modify".equals(cmd)) {
	    int idx = _aliases.getSelectedIndex();
	    String ali_name = _alias_1.getText();
	    String ali_path = _alias_2.getText();
	    if (idx >= 0) {
		try {
		    String entry = getAliasEntry(ali_name, ali_path);
		    _aliases.replaceItem(entry, idx);
		} catch (NullPointerException ex) {
		    // No text was set in the TextTield (_alias_1, _alias_2)
		}
	    }
	} else if ("OK".equals(cmd)) {
	    commitValues();
	    dispose();
	} else if ("Cancel".equals(cmd)) {
	    dispose();
	} else if ("Restore Defaults".equals(cmd)) {
	    updateValues();
	}
    }

    private String getAliasEntry(String ali_name, String ali_path)
	throws NullPointerException
    {
	if (ali_name.length() == 0 || ali_path.length() ==0) {
	    throw new NullPointerException();
	}
	if (!ali_name.endsWith("/")) {
	    ali_name = ali_name + "/";
	}
	if (!ali_path.endsWith(File.separator)) {
	    ali_path = ali_path + File.separator;
	}
	return ali_name + ALIASES_SEP + ali_path;
    }

    public void itemStateChanged(java.awt.event.ItemEvent ev) {
	if (ev.getItemSelectable() == _aliases
	    && ev.getStateChange() == ItemEvent.SELECTED) {
	    int item = ((Integer)ev.getItem()).intValue();
	    String alias = _aliases.getItem(item);
	    int idx = alias.indexOf(ALIASES_SEP);
	    String ali_name = alias.substring(0, idx);
	    if (ali_name.startsWith("/")) {
		ali_name = ali_name.substring(1);
	    }
	    String ali_path = alias.substring(idx + ALIASES_SEP.length());
	    _alias_1.setText(ali_name);
	    _alias_2.setText(ali_path);
	}
    }
}
public class AgletEventListener implements CloneListener, MobilityListener, 
										   PersistencyListener {
	Vector vector = new Vector();

	public AgletEventListener() {}
	/**
	 * Constructs an AgletEventlistener object with specified two clone
	 * listener objects.
	 */
	public AgletEventListener(CloneListener l1, CloneListener l2) {
		vector.addElement(l1);
		vector.addElement(l2);
	}
	/**
	 * Constructs an AgletEventlistener object with specified two mobility
	 * listener objects.
	 */
	public AgletEventListener(MobilityListener l1, MobilityListener l2) {
		vector.addElement(l1);
		vector.addElement(l2);
	}
	/**
	 * Constructs an AgletEventlistener object with specified two persistency
	 * listener objects.
	 */
	public AgletEventListener(PersistencyListener l1, 
							  PersistencyListener l2) {
		vector.addElement(l1);
		vector.addElement(l2);
	}
	/**
	 * Adds the specified clone listener object
	 */
	public void addCloneListener(CloneListener listener) {
		if (vector.contains(listener)) {
			return;
		} 
		vector.addElement(listener);
	}
	/**
	 * Adds the specified mobility listener object
	 */
	public void addMobilityListener(MobilityListener listener) {
		if (vector.contains(listener)) {
			return;
		} 
		vector.addElement(listener);
	}
	/**
	 * Adds the specified persistency listener object
	 */
	public void addPersistencyListener(PersistencyListener listener) {
		if (vector.contains(listener)) {
			return;
		} 
		vector.addElement(listener);
	}
	/**
	 * Calls the onActivation methods on the listers with the specified
	 * persistency event.
	 */
	public void onActivation(PersistencyEvent ev) {
		Enumeration e = vector.elements();

		while (e.hasMoreElements()) {
			((PersistencyListener)e.nextElement()).onActivation(ev);
		} 
	}
	/**
	 * Calls the onArrival methods on the listers with the specified
	 * mobility event.
	 */
	public void onArrival(MobilityEvent ev) {
		Enumeration e = vector.elements();

		while (e.hasMoreElements()) {
			((MobilityListener)e.nextElement()).onArrival(ev);
		} 
	}
	/**
	 * Calls the onClone methods on the listers with the specified
	 * Clone event.
	 */
	public void onClone(CloneEvent ev) {
		Enumeration e = vector.elements();

		while (e.hasMoreElements()) {
			((CloneListener)e.nextElement()).onClone(ev);
		} 
	}
	/**
	 * Calls the onCloned methods on the listers with the specified
	 * Clone event.
	 */
	public void onCloned(CloneEvent ev) {
		Enumeration e = vector.elements();

		while (e.hasMoreElements()) {
			((CloneListener)e.nextElement()).onCloned(ev);
		} 
	}
	/**
	 * Calls the onCloning methods on the listers with the specified
	 * Clone event.
	 */
	public void onCloning(CloneEvent ev) {
		Enumeration e = vector.elements();

		while (e.hasMoreElements()) {
			((CloneListener)e.nextElement()).onCloning(ev);
		} 
	}
	/**
	 * Calls the onDeactivating methods on the listers with the specified
	 * persistency event.
	 */
	public void onDeactivating(PersistencyEvent ev) {
		Enumeration e = vector.elements();

		while (e.hasMoreElements()) {
			((PersistencyListener)e.nextElement()).onDeactivating(ev);
		} 
	}
	/**
	 * Calls the onDispatching methods on the listers with the specified
	 * mobility event.
	 */
	public void onDispatching(MobilityEvent ev) {
		Enumeration e = vector.elements();

		while (e.hasMoreElements()) {
			((MobilityListener)e.nextElement()).onDispatching(ev);
		} 
	}
	/**
	 * Calls the onReverting methods on the listers with the specified
	 * mobility event.
	 */
	public void onReverting(MobilityEvent ev) {
		Enumeration e = vector.elements();

		while (e.hasMoreElements()) {
			((MobilityListener)e.nextElement()).onReverting(ev);
		} 
	}
	/**
	 * Removes the specified clone listener object
	 */
	public void removeCloneListener(CloneListener listener) {
		vector.removeElement(listener);
	}
	/**
	 * Removes the specified mobility listener object
	 */
	public void removeMobilityListener(MobilityListener listener) {
		vector.removeElement(listener);
	}
	/**
	 * Removes the specified persistency listener object
	 */
	public void removePersistencyListener(PersistencyListener listener) {
		vector.removeElement(listener);
	}
	/**
	 * Returns the number of listeners
	 */
	public int size() {
		return vector.size();
	}
import com.ibm.aglet.*;
import com.ibm.aglet.util.*;
import com.ibm.agletx.util.SimpleItinerary;
import java.net.URL;
import java.io.IOException;
import java.util.Date;


/**
 * Create a notifier by calling the static method <tt>create</tt>.
 * The notifier will get dispatched automatically. The notifier
 * performs successive checks (at its destination) within a specified
 * time duration.
 * Upon every successfull check (one the encounters a change in a
 * local state), it notifies its master.
 * The notifier can be defined (see <pre> create </pre>) to complete
 * its job after the first successive check (although its time duration
 * has not been reached yet).
 * If a notifier cannot be dispatched or it encounters an error
 * during a check, it notifies its master and disposed itself.
 * 
 * @version     1.01    97/10/1
 * @author      Danny B. Lange
 * @author      Yariv Aridor
 */

public abstract class Notifier extends Aglet {

	// Type of notification messages

	public final static int NOTIFICATION = 0;
	public final static int EXPIRY = 1;
	public final static int EXCEPTION = 2;


	// -- minimum time interval (in  hours) above which the notifier
	// -- is deactivated between two successive checks.
	private static final double MIN_TIME_OF_DEACTIVATION = 1.0 / 120.0;

	private String origin = null;

	// --  the master identifier
	private AgletID _master = null;

	// --  URL of the remote host to visit
	private String _destination;

	// --  Interval between checks (in hours)
	private double _interval = 1.0 / 60.0;

	// --  Duration of stay (in hours)
	private double _duration = 1.0;

	// --  Starting time
	private long _startingTime = 0;

	// --  Should stay after successfull check? .
	private boolean _stay = false;

	/**
	 * The protected variable that carries any messages that should go
	 * along with the notification back to the subscriber.
	 */
	protected Object MESSAGE = null;

	/**
	 * The protected variable that carries any arguments for the
	 * checks that this notifier performs.
	 */
	protected Object ARGUMENT = null;

	// --  Checks for time limit.
	// 
	private boolean checkTimeout() {
		return (_startingTime + (long)(_duration * 3600000)) 
			   > (new Date()).getTime();
	}
	/**
	 * Creates a notifier.
	 * @param url the URL of the aglet class.
	 * @param source the name of the aglet class.
	 * @param context the aglet context in which the notifier should be created.
	 * @param master the master aglet.
	 * @param destination the URL of the destination.
	 * @param interval the time in hours between to checks.
	 * @param duration the life time of the notifier.
	 * @param stay whether the notifier should remain after a notification.
	 * @param argument the <pre> argument </pre> object.
	 * @return an aglet proxy for the notifier.
	 * @exception AgletException if the creation fails.
	 */
	static public AgletProxy create(URL url, String source, 
									AgletContext context, Aglet master, 
									URL destination, double interval, 
									double duration, boolean stay, 
									Object argument) throws IOException, 
									AgletException {
		Arguments args = new Arguments();

		args.setArg("destination", destination.toString());
		args.setArg("interval", interval);
		args.setArg("duration", duration);
		args.setArg("stay", stay);
		args.setArg("agrument", argument);
		args.setArg("receiver", master.getAgletID());

		try {
			return context.createAglet(url, source, args);
		} catch (InstantiationException ex) {
			throw new AgletException(ex.getClass().getName() + ':' 
									 + ex.getMessage());
		} catch (ClassNotFoundException ex) {
			throw new AgletException(ex.getClass().getName() + ':' 
									 + ex.getMessage());
		} 
	}
	/**
	 * This method should be overridden to specify the check method for
	 * this notifier.
	 * @return boolean result of the check.
	 * @exception AgletException if fails to complete.
	 */
	abstract protected boolean doCheck() throws Exception;
	private void gotoSleep(double hours) throws AgletException {
		if (hours > MIN_TIME_OF_DEACTIVATION) {
			try {
				deactivate((int)(hours * 60));
			} catch (IOException ae) {
				throw new AgletException("deactivation has been failed!!");
			} 
		} else {
			waitInHours(hours);		// -- busy wait
		}
	}
	public boolean handleMessage(Message msg) {
		try {
			if (msg.sameKind("start")) {
				start();
			} else {
				return false;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} 
		return false;
	}
	// --  Abstract methods
	// 

	/**
	 * This method should be overridden to specify any intialization before
	 * the checks performed by this notifier.
	 * @exception AgletException if fails to complete.
	 */
	abstract protected void initializeCheck() throws Exception;
	private String makeExceptionMessage(String phase, Throwable ex) {
		String host = getAgletContext().getHostingURL().toString();

		return new String(host + ":" + "<" + ex.getClass().getName() + "::" 
						  + ex.getMessage() + ">;" 
						  + ((phase != null) ? "DURING " + phase 
							 : "Internal"));
	}
	// -- defines initialization before the checks begin.
	// 
	private void observeInit() throws Exception {
		try {
			initializeCheck();
		} catch (Throwable ex) {
			throw new Exception(makeExceptionMessage("initializeCheck", ex));
		} 
		startTimer();
	}
	// -- Performs repeated checks.
	// 
	private void observeRun() throws Exception {

		try {
			while (checkTimeout()) {
				boolean b = false;

				try {
					b = doCheck();
				} catch (Throwable ex) {
					throw new Exception(makeExceptionMessage("doCheck", ex));
				} 
				if (b) {
					sendRemoteMessage(NOTIFICATION, MESSAGE);
					if (!_stay) {
						break;
					} 
				} 
				gotoSleep(_interval);
			} 
			sendRemoteMessage(EXPIRY, 
							  new String("Stay/Duration-time has expired"));
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			throw new Exception(makeExceptionMessage(null, ex));
		} 
	}
	/**
	 * Initializes the notifier. Called only the first time this
	 * notifier is created. The initialization argument includes
	 * the needed parameters for the checks as defined
	 * in <pre> create </pre>.
	 * @param object the initialization argument, usually a subclass of {@link Object}
	 * @exception AgletException if the initialization fails.
	 */
	public synchronized void onCreation(Object object) {
		Arguments obj = (Arguments)object;

		_master = (AgletID)(obj.getArg("receiver"));
		_destination = (String)(obj.getArg("destination"));
		_interval = ((Double)(obj.getArg("interval"))).doubleValue();
		_duration = ((Double)(obj.getArg("duration"))).doubleValue();
		_stay = ((Boolean)(obj.getArg("stay"))).booleanValue();
		ARGUMENT = obj.getArg("agrument");

		origin = getAgletContext().getHostingURL().toString();

		try {
			SimpleItinerary itin = new SimpleItinerary(this);

			itin.go(_destination, new Message("start", null));
		} catch (AgletException ex) {
			ex.printStackTrace();
			dispose();
		} catch (IOException ex) {
			ex.printStackTrace();
			dispose();
		} 
	}
	// -- Notifies the master.
	// 
	private void sendRemoteMessage(int type, Object data) 
			throws IOException, AgletException {
		Arguments args = new Arguments();

		args.setArg("message", data);
		args.setArg("date", new Date());
		args.setArg("type", type);

		// Messenger.create(getAgletContext(), new URL(origin), _master, new Message("notification", args));
		// AgletProxy ap = getAgletContext().getAgletProxy(new URL(origin), _master);
		// ap.sendMessage(new Message("notification", args));
		URL org = new URL(origin);

		Messenger.create(getAgletContext(), org, org, _master, 
						 new Message("notification", args));
	}
	private void start() {
		try {
			observeInit();
			observeRun();
		} catch (Exception ex) {
			ex.printStackTrace();
			try {
				sendRemoteMessage(EXCEPTION, ex.getMessage());
			} catch (Exception ex1) {
				ex1.printStackTrace();
			} 
		} 
		dispose();
	}
	// --  Defines the start time of checks.
	// 
	private void startTimer() {
		_startingTime = (new Date()).getTime();
	}
	private synchronized void waitInHours(double h) {
		try {
			wait((int)(h * 3600));
		} catch (InterruptedException ex) {}
	}
}
package examples.mdispatcher;

/*
 * @(#)HelloAglet.java
 * 
 * 03L7246 (c) Copyright IBM Corp. 1996, 1998
 * 
 * The program is provided "as is" without any warranty express or
 * implied, including the warranty of non-infringement and the implied
 * warranties of merchantibility and fitness for a particular purpose.
 * IBM will not be liable for any damages suffered by you as a result
 * of using the Program. In no event will IBM be liable for any
 * special, indirect or consequential damages or lost profits even if
 * IBM has been advised of the possibility of their occurrence. IBM
 * will not be liable for any third party claims against you.
 */

import com.ibm.aglet.*;
import com.ibm.aglet.event.*;
import com.ibm.aglet.util.*;

import com.ibm.agletx.util.SimpleItinerary;

import java.lang.InterruptedException;
import java.io.Externalizable;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.IOException;
import java.net.*;
import java.awt.*;
import java.util.Enumeration;
import java.awt.event.*;

/*
 * MyDialog class is the window to be opened when the dialog required.
 * This is NOT a subclass of Dialog.
 */
class MyDialog extends Frame implements ActionListener, WindowListener {

	/*
	 * The aglet a user interacts with.
	 */
	private HelloAglet aglet = null;

	/*
	 * UI Components
	 */
	private AddressChooser dest = new AddressChooser();
	private TextField msg = new TextField(15);
	private Button go = new Button("GO!");
	private Button close = new Button("CLOSE");

	/*
	 * Constructs the dialog window
	 * @param aglet The aglet the user interacts with.
	 */
	MyDialog(HelloAglet aglet) {
		this.aglet = aglet;
		layoutComponents();

		addWindowListener(this);
		dest.addActionListener(this);
		msg.addActionListener(this);
		go.addActionListener(this);
		close.addActionListener(this);
	}
	/**
	 * Handles the action event
	 * @param ae the event to be handled
	 */
	public void actionPerformed(ActionEvent ae) {
		if ("GO!".equals(ae.getActionCommand())) {
			aglet.message = msg.getText();
			aglet.goDestination(dest.getAddress());
		} else if ("CLOSE".equals(ae.getActionCommand())) {
			setVisible(false);
		} 
	}
	/*
	 * Layouts all components
	 */
	private void layoutComponents() {
		msg.setText(aglet.message);

		// Layouts components
		GridBagLayout grid = new GridBagLayout();
		GridBagConstraints cns = new GridBagConstraints();

		setLayout(grid);

		cns.weightx = 0.5;
		cns.ipadx = cns.ipady = 5;
		cns.fill = GridBagConstraints.HORIZONTAL;
		cns.insets = new Insets(5, 5, 5, 5);

		cns.weightx = 1.0;
		cns.gridwidth = GridBagConstraints.REMAINDER;
		grid.setConstraints(dest, cns);
		add(dest);

		cns.gridwidth = GridBagConstraints.REMAINDER;
		cns.fill = GridBagConstraints.BOTH;
		cns.weightx = 1.0;
		cns.weighty = 1.0;
		cns.gridheight = 2;
		grid.setConstraints(msg, cns);
		add(msg);

		cns.weighty = 0.0;
		cns.fill = GridBagConstraints.NONE;
		cns.gridheight = 1;

		Panel p = new Panel();

		grid.setConstraints(p, cns);
		add(p);
		p.setLayout(new FlowLayout());
		p.add(go);
		p.add(close);
	}
	public void windowActivated(WindowEvent we) {}
	public void windowClosed(WindowEvent we) {}
	/**
	 * Handles the window event
	 * @param ae the event to be handled
	 */
	public void windowClosing(WindowEvent we) {
		dispose();
	}
	public void windowDeactivated(WindowEvent we) {}
	public void windowDeiconified(WindowEvent we) {}
	public void windowIconified(WindowEvent we) {}
	public void windowOpened(WindowEvent we) {}
}
package examples.finder;

/*
 * @(#)HostList.java
 * 
 * 03L7246 (c) Copyright IBM Corp. 1996, 1998
 * 
 * The program is provided "as is" without any warranty express or
 * implied, including the warranty of non-infringement and the implied
 * warranties of merchantibility and fitness for a particular purpose.
 * IBM will not be liable for any damages suffered by you as a result
 * of using the Program. In no event will IBM be liable for any
 * special, indirect or consequential damages or lost profits even if
 * IBM has been advised of the possibility of their occurrence. IBM
 * will not be liable for any third party claims against you.
 */

import com.ibm.aglet.*;
import com.ibm.aglet.event.*;

import java.net.URL;
import java.util.Hashtable;
import java.util.Enumeration;

/**
 * The HostList keeps a list of aglet server names.
 * When it moves to another server, it automatically disappears.
 * 
 * @version     1.00    $Date: 2002/03/16 00:42:03 $
 * @author      Yoshiaki Mima
 * @see examples.finder.HostCollector
 */

public class HostList extends Aglet implements PersistencyListener, 
		MobilityListener {
	Hashtable hostList;

	public void appendList(Hashtable list) {
		for (Enumeration e = list.keys(); e.hasMoreElements(); ) {
			Object key = e.nextElement();

			if (list.get(key) instanceof String) {
				if (hostList.get(key) == null) {
					System.out.println("new: " + key);
					hostList.put(key, "new");
				} else {

					// System.out.println("key: " + key + " value: " + hostList.get(key));
				} 
			} 
		} 
	}
	public boolean handleMessage(Message msg) {
		if (msg.sameKind("dialog")) {
			try {
				int i = 0;

				System.out.println("HostList -- begin");
				for (Enumeration e = hostList.keys(); e.hasMoreElements(); ) {
					System.out.println(i++ + ": " + e.nextElement());
				} 
				System.out.println("HostList -- end");
			} catch (Exception ex) {
				ex.printStackTrace();
			} 
			return true;
		} else if (msg.sameKind("register")) {
			if (msg.getArg() instanceof String) {
				hostList.put(msg.getArg(), "running");
			} 
			return true;
		} else if (msg.sameKind("append")) {
			if (msg.getArg() instanceof Hashtable) {
				appendList((Hashtable)msg.getArg());
			} 
			return true;
		} else if (msg.sameKind("getlist")) {
			msg.sendReply(hostList);
			return true;
		} else if (msg.sameKind("shutdown")) {
			try {
				deactivate(0);
			} catch (Exception e) {}
			return true;
		} else if (msg.sameKind("dispose")) {
			dispose();
			return true;
		} else {}
		return true;
	}
	public void onActivation(PersistencyEvent event) {
		AgletContext ac = getAgletContext();
		AgletProxy proxy = getProxy();
		AgletProxy ap;

		// check if another HostList registration
		ap = (AgletProxy)ac.getProperty("hostlist");
		if ((ap != null) && (ap.isValid())) {
			try {
				ap.sendMessage(new Message("append", hostList));
			} catch (Exception e) {
				System.out.println(e);
			} 
			dispose();
		} else {
			ac.setProperty("hostlist", proxy);
		} 
	}
	public void onArrival(MobilityEvent event) {
		dispose();
	}
	public void onCreation(Object init) {
		AgletContext ac = getAgletContext();
		AgletProxy proxy = getProxy();
		AgletProxy ap;

		addMobilityListener(this);
		addPersistencyListener(this);

		// check if another HostList registration
		ap = (AgletProxy)ac.getProperty("hostlist");
		if ((ap != null) && (ap.isValid())) {
			if (init instanceof Hashtable) {
				try {
					ap.sendMessage(new Message("append", init));
				} catch (Exception e) {
					System.out.println(e);
				} 
			} 
			dispose();
		} else {
			ac.setProperty("hostlist", proxy);

			if (init instanceof Hashtable) {
				hostList = (Hashtable)((Hashtable)init).clone();
			} else {
				hostList = new Hashtable();
			} 
			hostList.put(ac.getHostingURL().toString(), "running");
		} 
	}
	public void onDeactivating(PersistencyEvent event) {

		// unregistration
		getAgletContext().setProperty("hostlist", null);
	}
	public void onDispatching(MobilityEvent event) {}
	public void onRetraction(MobilityEvent event) {}
	public void onReverting(MobilityEvent event) {}
	}
	/*
	 * index page
	 */
	void indexPage() {
		StringBuffer b = new StringBuffer();

		b.append("<HTML>");
		b.append("<HEAD>");
		b.append(META_TAG);
		b.append("<TITLE>");
		b.append("CGI TEST");
		b.append("</TITLE>");
		b.append("</HEAD>");
		b.append("<BODY>");
		b.append("<H1> Welcome to WebServerAglet! </H1>");
		b.append("<a href=next.html> List Proxies </a> <BR>");
		b.append("<FORM METHOD=GET ACTION=go>");
		b.append("<INPUT NAME=location VALUE=\"atp://your.host\">");
		b.append("<INPUT TYPE=submit VALUE=GO!> <BR>");
		b.append("<P><FONT color=#FF0000>note:</FONT> Check box ");
		b.append("for \"Accept HTTP Request as a message\"<BR>");
		b.append("in \"Network Preference\" of target server <B>must be checked</B>.");
		b.append("</BODY>");
		b.append("</HTML>");
		indexPage = b.toString();
	}
	public void onCreation(Object init) {

		// 
		// this is just a convension.
		// 
		getAgletContext().setProperty("name.test", getAgletID());

		// 
		// Creating pages in advance.
		// 
		indexPage();

		// 
		// Accepts http requests concurrently.
		// 
		getMessageManager().setPriority("index.html", 
										MessageManager.NOT_QUEUED);
		getMessageManager().setPriority("next.html", 
										MessageManager.NOT_QUEUED);
	}
}
