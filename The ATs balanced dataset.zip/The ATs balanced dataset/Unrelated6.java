package thera.framework;

import thera.formats.DynamicFormat;
import thera.formats.TableColumn;
import thera.utils.Verify;

import extern.XElement;
/**
 * Abstract base class for format decorators.<p>
 * Implements <code>DynamicFormat</code> to
 * allow decorating also within dynamic formats.
 * @author Ivo Maixner
 */
public abstract class FormatDecorator
	extends Format
	implements DynamicFormat, TableColumn
{
	protected Format decorated;
/**
 * No args constructor is called by the externalizer.
 */
public FormatDecorator()
{
}
/**
 * Parametrized constructor to be called from user code.
 */
public FormatDecorator(String name, Format decorated)
{
	super(name);
	this.decorated = decorated;
}
/**
 * Overriden to create the <code>Data</code> that correspond to this format.<p>
 * Returns the <code>Data</code> coresponding to the decorated 
 * <code>Format</code>.
 * @return thera.framework.Data
 */
public Data createDataImpl()
{
	return getDecorated().createData();
}
/**
 * Insert the method's description here.
 * @return java.lang.Object
 */
public String formatDB()
{
	if (decorated instanceof TableColumn)
		return ((TableColumn) decorated).formatDB();
	return decorated.format().toString();
}
/**
 * Returns the decorated <code>Format</code>.
 * @return Format
 */
public Format getDecorated()
{
	verifyNotNull(decorated, "Decorated not defined");
	return decorated;
}
/**
 * Initializes this instance from a given XElement,
 * adds support for the decorated.<p>
 */
public void initializeFrom(XElement element)
{
	super.initializeFrom(element);
	if (1 != element.getChildrenCount())
		throw new TheraRuntimeException("Must have exactly one decorated", this);
	XElement child = element.getChildAt(0);
	decorated = (Format) getExternalizer().createObject(child.getName());
	decorated.initializeFrom(child);
}
/**
 * Overriden to support dynamic formats, ie. formats that reference
 * <a href="thera.framework.Data">Data</a> dynamically.<p>
 * Sets the data name base of the decorated <code>Format</code> 
 * to the given value.
 * @param param String
 */ 
public void setDatanameBase(String base, boolean includeItself)
{
	Format deco = getDecorated();
	if (deco instanceof DynamicFormat)
		 ((DynamicFormat) deco).setDatanameBase(base, includeItself);
	if (decorated instanceof TableColumn)
		 ((TableColumn) decorated).unformatDB(data);
	throw new TheraRuntimeException(
		"Child must be based on TableColumn, but was: " + Verify.getHint(decorated), 
		this); 
}
}
/**
 * Searches the current configuration for an <code>Operation</code>
 * of a given <code>name</code>. If found, instantiates it and its
 * container <code>Context</code> and links the container <code>Context</code>
 * into the context tree hierarchy.
 * @return Operation
 * @param name java.lang.String
 * @param current Context the Context from which is the Operation being invoked
 */
public Operation readOperation(String name, Context current)
{
	Verify.notNull(name, "Operation not defined", this);
	if ("".equals(name))
		return null;
	XElement elem = root.getDescendantByAttribute("name", name);
	if (null == elem)
		return null;
	String className = getClassNameForTagType(elem.getName());
	try
	{
		if (!Operation.class.isAssignableFrom(Class.forName(className)))
			throw new TheraRuntimeException(
				"An element named <"
					+ name
					+ "> found, but is not an operation, is: "
					+ className, 
				this); 
	} catch (ClassNotFoundException cnfe)
	{
	}
	Context ctx, lastCtx = null, operCtx = null;
	String parentFullName;
	do {
		elem = elem.getParent();
		Externalizable obj = createObject(elem.getName());
		obj.initializeFrom(elem);
		ctx = (Context) obj;
		if (null == operCtx)
			operCtx = ctx;
		if (null != lastCtx)
			lastCtx.setParent(ctx);
		lastCtx = ctx;
		parentFullName = getNamePath(elem.getParent());
		ctx = getRootContext().getStaticContext(parentFullName);
		if (null != ctx)
		{
			lastCtx.setParent(ctx);
			break;
		}
		if (null != current)
		{
			Context found = matchToCurrentCtx(current, parentFullName);
			if (null != found)
			{
				lastCtx.setParent(found);
				break;
			}
		}
	} while (true);
	return operCtx.getOperation(name);
}
/**
 * Loads the configuration from a file and creates 
 * static <code>Context</code>s.
 */
public void setUp()
{
	inst = this;
	XElement elem = root.getChild("context");
	Externalizable obj = createObject(elem.getName());
	obj.initializeFrom(elem);
	ctxRoot = (Context) obj;
}
}
