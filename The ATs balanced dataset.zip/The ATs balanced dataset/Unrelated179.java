
  public static void main(String[] args) {
    if (System.getSecurityManager() == null) {
      System.setSecurityManager(new RMISecurityManager());
    }
    InetAddress localhost = null;
    try {
      localhost = InetAddress.getLocalHost();
      System.err.println("Host name : "+localhost.getHostName());
    } catch (Exception ex) {
      ex.printStackTrace();
    }
    String name;
    if (localhost != null) {
      name = "//"+localhost.getHostName()+"/RemoteEngine";
    } else {
      name = "//localhost/RemoteEngine";
    }
    
    try {
      Compute engine = new RemoteEngine(name);
      Naming.rebind(name, engine);
      System.out.println("RemoteEngine bound in RMI registry");
    } catch (Exception e) {
      System.err.println("RemoteEngine exception: " + 
			 e.getMessage());
      // try to bootstrap a new registry
      try {
	System.err.println("Attempting to start rmi registry...");
	java.rmi.registry.LocateRegistry.createRegistry(1099);
	Compute engine = new RemoteEngine(name);
	Naming.rebind(name, engine);
	System.out.println("RemoteEngine bound in RMI registry");
      } catch (Exception ex) {
	ex.printStackTrace();
      }
    }
  }
}import java.rmi.Remote;
import java.rmi.RemoteException;


public interface Compute extends Remote {
  

  Object executeTask(Task t) throws RemoteException;

public class RemoteExperimentSubTask implements Task {

  /* Info on the task */
  private TaskStatusInfo m_result = new TaskStatusInfo();
  
  /* The (sub) experiment to execute */
  private Experiment m_experiment;
  
  public RemoteExperimentSubTask() {
    m_result.setStatusMessage("Not running.");
    m_result.setExecutionStatus(TaskStatusInfo.TO_BE_RUN);
  }
  public void setExperiment(Experiment task) {
    m_experiment = task;
  }
  
  public Experiment getExperiment() {
    return m_experiment;
  }
  
  public void execute() {
    //      FastVector result = new FastVector();
    m_result = new TaskStatusInfo();
    m_result.setStatusMessage("Running...");
    String goodResult = "(sub)experiment completed successfully";
    String subTaskType;
    if (m_experiment.getRunLower() != m_experiment.getRunUpper()) {
      subTaskType = "(dataset "
	+ ((File)m_experiment.getDatasets().elementAt(0)).getName();
    } else {
      subTaskType = "(exp run # "+
	m_experiment.getRunLower();
    }
    try {	
      System.err.println("Initializing " + subTaskType + ")...");
      m_experiment.initialize();
      System.err.println("Iterating " + subTaskType + ")...");
      m_experiment.runExperiment();
      System.err.println("Postprocessing " + subTaskType + ")...");
      m_experiment.postProcess();
    } catch (Exception ex) {
      ex.printStackTrace();
      String badResult =  "(sub)experiment " + subTaskType 
	+ ") failed : "+ex.toString();
      m_result.setExecutionStatus(TaskStatusInfo.FAILED);
      //	m_result.addElement(new Integer(RemoteExperiment.FAILED));
      //	m_result.addElement(badResult);
      m_result.setStatusMessage(badResult);
      m_result.setTaskResult("Failed");
      //      return m_result;
      return;
    }            
    //      m_result.addElement(new Integer(RemoteExperiment.FINISHED));
    //      m_result.addElement(goodResult);
    m_result.setExecutionStatus(TaskStatusInfo.FINISHED);
    m_result.setStatusMessage(goodResult+" "+subTaskType+").");
    m_result.setTaskResult("No errors");
    //    return m_result;
  }

  public TaskStatusInfo getTaskStatus() {
    return m_result;
  }
}
  Object checkStatus(Object taskId) throws Exception;
}