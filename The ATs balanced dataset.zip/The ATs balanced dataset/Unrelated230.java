/*
 * Copyright ? 2008, Sun Microsystems, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *    * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 *    * Neither the name of Sun Microsystems, Inc. nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */



package com.sun.honeycomb.hadb;

import com.sun.hadb.adminapi.HADBException;
import com.sun.hadb.adminapi.MAConnection;
import com.sun.hadb.adminapi.MAConnectionFactory;
import com.sun.hadb.adminapi.ManagementDomain;
import com.sun.hadb.adminapi.MemberNotInThisDomainException;

import com.sun.honeycomb.common.ConfigPropertyNames;
import com.sun.honeycomb.common.InternalException;

import com.sun.honeycomb.config.ClusterProperties;

import com.sun.honeycomb.cm.ManagedService;
import com.sun.honeycomb.cm.ManagedServiceException;
import com.sun.honeycomb.cm.ServiceManager;
import com.sun.honeycomb.cm.node_mgr.Node;
import com.sun.honeycomb.cm.node_mgr.NodeMgrService;

import com.sun.honeycomb.diskmonitor.DiskProxy;
import com.sun.honeycomb.disks.Disk;

import com.sun.honeycomb.util.Exec;
import com.sun.honeycomb.common.StringUtil;

import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.InputStreamReader;
import java.io.IOException;

import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.Set;
import java.util.HashSet;

import java.util.logging.Level;
import java.util.logging.Logger;


public class HadbService
    implements HADBServiceInterface {

    private static final Logger LOG =
        Logger.getLogger(HadbService.class.getName());

    private static final String HADB_INSTALL_DIR = "/config/hadb_install";
    private static final String HADB_RAMDISK_DIR = "/opt/SUNWhadb";
    private static final String HADB_45_CFG_PATH = HADB_INSTALL_DIR+"/4.5.0-11";
    private static final String HADB_45_OPT_PATH = HADB_RAMDISK_DIR+"/4.5.0-11";
    private static final String HADB_INSTALL_SYMLINK = HADB_INSTALL_DIR+"/4";
    private static final String HADB_RAMDISK_SYMLINK = HADB_RAMDISK_DIR+"/4";
    private static final String MA_PATH = HADB_INSTALL_SYMLINK+"/bin/ma";

    private static final String MA_CFG = "/config/SUNWhadb/mgt.cfg";
    private static final String MA_CFG_CONFIGPATH = "ma.server.dbconfigpath";
    private static final String MA_USER = "internal";
    private static final String MA_WAITS_PROPERTY = "honeycomb.hadb.ma_waits";
    private static final String MA_MOVING_DISKS_MARKER_PATH = 
    	                                      "/config/SUNWhadb/diskmove";

    // Poll delay waiting for the HADB disk to become available
    // should be longer than the bad disk timeout
    private static final long MA_START_TIMEOUT = 60000; // 1 minute

    // Delay between retries of connect to MA
    private static final long MA_START_RETRY_DELAY = 5000; // 5s

    // Poll delay in loop waiting for the DiskMonitor to get ready
    private static final long DISKMONITOR_POLL_DELAY = 15000; // 15s

    // Poll delay waiting for the HADB disk to become available
    private static final long DISKWAIT_POLL_DELAY = 15000; // 15s

    // If the HADB disk doesn't become available within this time of
    // the first disk coming online, give up.
    private static final long DISKWAIT_TIMEOUT = 5 * 60 * 1000; // 5 minutes

    // If the HADB disk stays bad for this long, declare an error.
    private static final long BADDISK_TIMEOUT =1 * 60 * 1000; // 1 minute

    // If MAs are being started sequentially, this is the poll loop delay.
    private static final long SEQ_START_POLL_INTERVAL = 1000;

    // If MA is running, sleep for this long and re-check.
    private static final long MA_CHECK_INTERVAL = 5000;
    
    // Once we have started MA for the first time, sleep for this long
    // in order to give MA to get settled
    private static final long MA_POST_START_WAIT = 20 * 1000; // 20 secs

    // After "kill SIGINT" of the MA process, wait for it to exit for this
    // much time before destroying the process.
    private static final long MA_EXIT_TIMEOUT = 10000; // 10s
    
    private boolean running;
    private boolean should_start;
    private Process maProcess;
    private String hadbDir;
    private int hadbDriveNum;
    private boolean isMaRunning;
    private int myId;