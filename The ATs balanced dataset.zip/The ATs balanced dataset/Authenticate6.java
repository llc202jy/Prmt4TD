SignedOnUserLoginContext
{
      com.sun.security.auth.module.Krb5LoginModule required useTicketCache=true doNotPrompt=true;
};
      // create a LoginContext based on the entry in the login.conf file
      LoginContext lc = new LoginContext("SignedOnUserLoginContext");

      // login (effectively populating the Subject)
      lc.login();

      // get the Subject that represents the signed-on user
      Subject signedOnUserSubject = lc.getSubject();public class ServiceTicketGenerator implements PrivilegedExceptionAction
{
	public Object run() throws Exception
	{
		try
		{
			// GSSAPI is generic, but if you give it the following Object ID,
			// it will create Kerberos 5 service tickets
			Oid kerberos5Oid = new Oid("1.2.840.113554.1.2.2");

			// create a GSSManager, which will do the work
			GSSManager gssManager = GSSManager.getInstance();

			// tell the GSSManager the Kerberos name of the client and service (substitute your appropriate names here)
			GSSName clientName = gssManager.createName("client@DOMAIN.COM", GSSName.NT_USER_NAME);
			GSSName serviceName = gssManager.createName("service/server.domain.com@DOMAIN.COM", null);

			// get the client's credentials. note that this run() method was called by Subject.doAs(),
			// so the client's credentials (Kerberos TGT or Ticket-Granting Ticket) are already available in the Subject
			GSSCredential clientCredentials = gssManager.createCredential(clientName, 8*60*60, kerberos5Oid, GSSCredential.INITIATE_ONLY);

			// create a security context between the client and the service
			GSSContext gssContext = gssManager.createContext(serviceName, kerberos5Oid, clientCredentials, GSSContext.DEFAULT_LIFETIME);

			// initialize the security context
			// this operation will cause a Kerberos request of Active Directory,
			// to create a service ticket for the client to use the service
			byte[] serviceTicket = gssContext.initSecContext(new byte[0], 0, 0);
			gssContext.dispose();

			// return the Kerberos service ticket as an array of encrypted bytes
			return serviceTicket;
		}
		catch (Exception ex)
		{
			throw new PrivilegedActionException(ex);
		}
	}

}public class ServiceTicketDecoder implements PrivilegedExceptionAction
{
	protected byte[] serviceTicket;

	public ServiceTicketDecoder(byte[] serviceTicket)
	{
		// the run() method does not support any arguments, so we pass the service ticket in via the constructor
		this.serviceTicket = serviceTicket;
	}

	public Object run() throws Exception
	{
		try
		{
			// GSSAPI is generic, but if you give it the following Object ID,
			// it will decode Kerberos 5 service tickets
			Oid kerberos5Oid = new Oid("1.2.840.113554.1.2.2");

			// create a GSSManager, which will do the work
			GSSManager gssManager = GSSManager.getInstance();

			// tell the GSSManager the Kerberos name of the service (substitute your appropriate names here)
			GSSName serviceName = gssManager.createName("service/server.domain.com@DOMAIN.COM", GSSName.NT_USER_NAME);

			// get the service's credentials. note that this run() method was called by Subject.doAs(),
			// so the service's credentials (Service Principal Name and password) are already available in the Subject
			GSSCredential serviceCredentials = gssManager.createCredential(serviceName, GSSCredential.INDEFINITE_LIFETIME, kerberos5Oid, GSSCredential.ACCEPT_ONLY);

			// create a security context for decrypting the service ticket
			GSSContext gssContext = gssManager.createContext(serviceCredentials);

			// decrypt the service ticket
			gssContext.acceptSecContext(this.serviceTicket, 0, this.serviceTicket.length);

			// get the client name from the decrypted service ticket
			// note that Active Directory created the service ticket, so we can trust it
			String clientName = gssContext.getSrcName().toString();

			// clean up the context
			gssContext.dispose();

			// return the authenticated client name
			return clientName;
		}
		catch (Exception ex)
		{
			throw new PrivilegedActionException(ex);
		}
	}

}