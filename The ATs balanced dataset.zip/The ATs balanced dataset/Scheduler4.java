namespace BrainTechLLC
{
    public static class Threading
    {
        public static Thread CreateAndRunThread(this ThreadStart ts)
        {
            Thread t = CreateThread(ts); 
            t.Start(); 
            return t;
        }

        public static Thread CreateAndRunThread(this ThreadStart ts, bool isBackground)
        {
            Thread t = CreateThread(ts); 
            t.IsBackground = isBackground; 
            t.Start(); 
            return t;
        }


#if SILVERLIGHT
        public static Thread CreateThread(this ThreadStart ts)
        {
            Thread t = new Thread(ts);
            return t;            
        }

#else
        public static Thread CreateThread(this ThreadStart ts)
        {
            return ts.CreateThread(true, ThreadPriority.Normal, ApartmentState.MTA);            
        }

        public static Thread CreateThread(this ThreadStart ts, bool isBackground, ThreadPriority priority, ApartmentState apartmentState)
        {
            Thread t = new Thread(ts);

#if NO_SILVERLIGHT
            t.TrySetApartmentState(apartmentState);
            t.Priority = priority;
#endif

            t.IsBackground = isBackground;
            return t;
        }
#endif
    }
}