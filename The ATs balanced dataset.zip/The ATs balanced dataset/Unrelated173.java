
   public void posit(Object fact, Object keys[]) {
      posit(rules, keys, 0, new Object[] { fact, keys });
   }
   
         if (keys[offset] != null) { // fixed key, linear recursion
            synchronized(rules) { // get next path node
               Hashtable table = (Hashtable)rules.get(keys[offset]);
               if (table == null) { // if no node, make one!
                  table = new Hashtable();
                  rules.put(keys[offset], table);
               }
            }
            rules = (Hashtable)rules.get(keys[offset]);
            if (offset == keys.length - 1) { // boundary condition
               Vector vector = (Vector)rules.get(keys[keys.length - 1]);
               if (vector == null) {
                  vector = new Vector();
                  rules.put(keys[keys.length - 1], vector);
               }
               vector.add(rule);
            } else add(rules, rule, keys, offset + 1); // continue recursing
         } else {  // wildcard, n-ary recursion
            Enumeration wildKeys = rules.keys();
            while(wildKeys.hasMoreElements())
               add((Hashtable)rules.get(wildKeys.nextElement()),
                  rule, keys, offset + 1);
         }
      } catch(ClassCastException x) {} // invalid key path, ignore
   }
   /**package gnu.cajo.utils.extra;

import gnu.cajo.invoke.Invoke;
import gnu.cajo.invoke.Remote;

/*
 * Dynamic Server Item Functionality Redirector
 * Copyright (c) 2005 John Catherino
 * The cajo project: https://cajo.dev.java.net
 *
 * For issues or suggestions mailto:cajo@dev.java.net
 *
 * This file DynamicObject.java is part of the cajo library.
 *
       public boolean equals(Object o) {
         return o instanceof RSSF &&
               ((RSSF)o).port == port;
      }
      public int hashCode() { return getClass().hashCode() + port; }
   }
   private static final class RCSF
      implements RMIClientSocketFactory, Serializable {
      private static final long serialVersionUID = 0x6060842L; // ;-) B-52s
      private int port;
      private String host;
      private RCSF() {}
      private RCSF(String localAddr) {
          host = localAddr;
          port = rssf.port;
      }
      public Socket createSocket(String host, int port) throws IOException {
         Socket s;
         s = RMISocketFactory.getDefaultSocketFactory().
            createSocket(this.host, this.port != 0 ? this.port : port);
         s.setKeepAlive(true);
         return s;
      }
      public boolean equals(Object o) {
         return o instanceof RCSF &&
               ((RCSF)o).port == port;
      }
      public int hashCode() { return getClass().hashCode() + port; }
   }
   private static Object proxy;
   private static Registry registry;
   /**
    * A global reference to the remote client socket factory.  This is the
    * factory remote VMs will use to communicate with local items.
    */
   public static final RCSF rcsf = new RCSF();
   /**
    * A global reference to the remote server socket factory.  This is the
    * factory the local items use to communicate with remote VMs.
    */
   public static final RSSF rssf = new RSSF();
   static { // provide a default configuration; anonymous port & local name:
      try { // equivalent of a Remote.config(null, 0, null, 0);
         rssf.host = InetAddress.getLocalHost().getHostName();
         rcsf.host = rssf.host;
         rssf.port = 0;
         rcsf.port = 0;
         System.setProperty("java.rmi.server.useLocalHostname", "true");
         System.setProperty("java.rmi.server.hostname", rcsf.host);
      } catch(Exception x) {}
   }
      protected static void remove(
      Hashtable rules, Object rule, Object keys[], int offset) {
      try {
         if (keys[offset] != null) { // fixed key, linear recursion
            rules = (Hashtable)rules.get(keys[offset]);
            if (offset == keys.length - 1) { // boundary condition
               Vector vector = (Vector)rules.get(keys[keys.length - 1]);
               vector.remove(rule);
            } else remove(rules, rule, keys, offset + 1); // continue
         } else {  // wildcard, n-ary recursion
            Enumeration wildKeys = rules.keys();
            while(wildKeys.hasMoreElements())
               remove((Hashtable)rules.get(wildKeys.nextElement()),
                  rule, keys, offset + 1);
         }
      } catch(ClassCastException x) {} // invalid key path, ignore
   }
   /**
    * This method is used to register a rule instance with the ontology.
    * The rule engine will store the rule reference, to have its
    * <tt>posit</tt> method invoked, as the state of the fact of interest
    * changes. It is worth mentioning, a single rule instance is often used
    * to monitor multiple types of facts. It simply invokes the static
    * add method, to begin the recursive ontology traversal to add the rule.
    * @param rule The rule to be notified when the fact state changes. It is
    * typically a reference to an object in a remote JVM, but it can be to
    * a local object, or even a proxy object.
    * @param keys The chain of keys leading to the element of interest
    * in the fact base. If the path does not exist, it will be created
    * implicitly.
    */
   public void add(Object rule, Object keys[]) {
      add(rules, rule, keys, 0);
   }
   /**
    * This method is used to unregister a rule instance for a type of 
    * fact. The rule engine will delete the rule reference from its
    * ontology. It simply invokes the static remove method, to begin the
    * recursive ontology traversal to delete the rule.
    * @param rule The rule to be removed from the engine. It is typically a
    * reference to an object in a remote JVM, but it can be to a local
    * object, or even a proxy object.
    * @param keys The chain of keys leading to the element of interest
    * in the ontology. If the key sequence does not exist in the ontology,
    * the invocation will be ignored silently.
    */
   public void remove(Object rule, Object keys[]) {
      remove(rules, rule, keys, 0);
   }*
 * Th cajo library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public Licence for more details.
 *
 * You should have received a copy of the GNU Lesser General Public Licence
 * along with this library. If not, see http://www.gnu.org/licenses/lgpl.html
 */

/**
 * This is a dynamic server object dispatcher. Its purpose it to provide a
 * client with a single remote object reference, whose functionality can be
 * changed by the server at runtime. A server would remote this object
 * wrapper, then use its changeObject method to redefine the functionality
 * of the client's reference dynamically. <i><u>Note</u>:</i> the wrapped
 * object can be of any type, and it need not even implement the
 * gnu.cajo.invoke.Invoke interface.<p>
 *
 * While being only 5 lines of Java source code, its capability is
 * elegantly sophisticated.
 *
 * @version 1.0, 03-Nov-05 Initial release
 * @author John Catherino
 */
public final class DynamicObject implements Invoke {
   private transient Object object;
   /**
    * The constructor assigns the initial server object reference.
    * @param object The initial encapsulated server functionality to be
    * remoted through this object.
    */
    */
   public void changeObject(Object object) { this.object = object; }