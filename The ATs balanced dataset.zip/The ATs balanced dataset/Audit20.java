public class ActivityElementDAOImpl extends SqlMapClientTemplate implements ActivityElementDAO {

	/**
     * Logger
     */
    private static final Logger log = Red5LoggerFactory.getLogger(ActivityElementDAOImpl.class,"visu");
	
	@SuppressWarnings("unchecked")
	public List<ActivityElement> getActivityElements(Integer id_activity) throws SQLException
	{
		log.debug("getActivityElements {} ",id_activity);
		return  (List<ActivityElement>)getSqlMapClient().queryForList("activities_elements.getActivityElements",id_activity );
	}

	@SuppressWarnings("unchecked")
	public List<ActivityElement> getSessionActivitiesElements(Integer id_session) throws SQLException 
	{
		log.debug("getSessionActivitiesElements ", id_session );
		return  (List<ActivityElement>)getSqlMapClient().queryForList("activities_elements.getSessionActivitiesElements", id_session );
	}
	
	public ActivityElement insert(ActivityElement activityElement) throws SQLException 
	{
		log.debug("insert activityElement  {}", activityElement );
		Integer key = (Integer)getSqlMapClient().insert("activities_elements.insert", activityElement);
		activityElement.setId_element(key);
		return activityElement;
	}

	public ActivityElement update(ActivityElement activityElement) throws SQLException 
	{
		log.debug("update activityElement  {}", activityElement);
		getSqlMapClient().update("activities_elements.update", activityElement);
		return activityElement;
	}
	
	public Integer delete(ActivityElement activityElement) throws SQLException 
	{
		log.debug("delete activityElement id  {}", activityElement);
		getSqlMapClient().delete("activities_elements.delete", activityElement);
		return activityElement.getId_element();
	}
	
	public void deleteByIdActivity(Integer idActivity) throws SQLException 
	{
		log.debug("delete activityElement by id activity {}", idActivity);
		getSqlMapClient().delete("activities_elements.deleteByIdActivity", idActivity);
	}
}