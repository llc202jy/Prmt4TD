public class Alpha
{
    int counter = 0;
    private int sleepTime;
    private static Random rand = new Random();

    public Alpha()
    {
        sleepTime = rand.Next(10001);
    }

    public void Process1()
    {
            Console.WriteLine(string.Format(
                "Process 1 RUNNING (run#: {0})", counter));
            Console.WriteLine();


            Thread current = Thread.CurrentThread;
            Console.WriteLine("{0} going to sleep", current.Name, sleepTime);
            Console.WriteLine();
            Thread.Sleep(sleepTime);
            Console.WriteLine("{0} done sleeping", current.Name);
            Console.WriteLine();    
    }

    public void Process2()
    {
            Console.WriteLine();
            Console.WriteLine(string.Format(
                "Process 2 RUNNING (run#: {0})", counter));
            Console.WriteLine();

            Thread current = Thread.CurrentThread;
            Console.WriteLine("{0} going to sleep", current.Name, sleepTime);
            Console.WriteLine();
            Thread.Sleep(sleepTime);
            Console.WriteLine("{0} done sleeping", current.Name);
            Console.WriteLine();
    }

    public void Process3()
    {
          Console.WriteLine(string.Format(
              "Process 3 RUNNING (run#: {0})",counter));
          Console.WriteLine();

          Thread current = Thread.CurrentThread;
          Console.WriteLine("{0} going to sleep", current.Name, sleepTime);
          Console.WriteLine();
          Thread.Sleep(sleepTime);
          Console.WriteLine("{0} done sleeping", current.Name);
    }

    public void Process4()
    {
          Console.WriteLine(string.Format(
              "Process 4 RUNNING (run#: {0})", x));
          Console.WriteLine();

          Thread current = Thread.CurrentThread;
          Console.WriteLine("{0} going to sleep", current.Name, sleepTime);
          Console.WriteLine();
          Thread.Sleep(sleepTime);
          Console.WriteLine();
          Console.WriteLine("{0} done sleeping", current.Name);
          Console.WriteLine();  
    }
};

public class StepOne
{
    public static void Main()
    {
        Alpha oAlpha = new Alpha();

        Thread bThread = new Thread(new ThreadStart(oAlpha.Process1));
        bThread.Name = "Process 1";
        Thread cThread = new Thread(new ThreadStart(oAlpha.Process2));
        cThread.Name = "Process 2";
        Thread dThread = new Thread(new ThreadStart(oAlpha.Process3));
        dThread.Name = "Process 3";
        Thread eThread = new Thread(new ThreadStart(oAlpha.Process4));
        eThread.Name = "Process 4";

        for (int a = 0; a <= 250; a++)
        {
            bThread.Start();
            while (!bThread.IsAlive) ;
            bThread.Join();
            Console.WriteLine();

            cThread.Start();
            while (!cThread.IsAlive) ;
            cThread.Join();
            Console.WriteLine();

            dThread.Start();
            while (!dThread.IsAlive) ;
            dThread.Join();
            Console.WriteLine();

            eThread.Start();
            while (!eThread.IsAlive) ;
            eThread.Join();
            Console.WriteLine();
        }
    }