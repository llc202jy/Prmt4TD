    private String historyView;
    
    private String editExView;
    
    /**
     * Returns the command class associated with this view resolver
     * @return Command class for this resolver 
     */
    public String getAddEditCommandClass() {
        return addEditCommandClass;
    }
    public void setAddEditCommandClass(String addEditCommandClass) {
        this.addEditCommandClass = addEditCommandClass;
    }
    
    /**
     * Returns the template used for newView and editView
     * @return Existing template file name
     */
    public String getAddEditTemplate() {
        return addEditTemplate;
    }
    public void setAddEditTemplate(String addEditTemplate) {
        this.addEditTemplate = addEditTemplate;
    }
    
    /**
     * Returns the name of the command used for viewing. Can be null.
     * @return Name of the view command / url
     */     
    public String getViewView() {
        return viewView;
    }
    public void setViewView(String viewView) {
        this.viewView = viewView;
    }
    
    /**
     * Returns the name of the command used for creating new objects. Can be null.
     * @return Name of the new command / url
     */     
    public String getNewView() {
        return newView;
    }
    public void setNewView(String newView) {
        this.newView = newView;
    }
    
    /**
     * Returns the name of the command used for deleting. Can be null.
     * @return Name of the delete command / url
     */     
    public String getDeleteView() {
        return deleteView;
    }
    public void setDeleteView(String deleteView) {
        this.deleteView = deleteView;
    }
    
    /**
     * Returns the name of the command used for listing. Can be null.
     * @return Name of the list command / url
     */    
    public String getListView() {
        return listView;
    }
    public void setListView(String listView) {
        this.listView = listView;
    }
    
    /**
     * Returns the name of the command used for printing. Can be null.
     * @return Name of the print command / url
     */
    public String getPrintView() {
        return printView;
    }
    public void setPrintView(String printView) {
        this.printView = printView;
    }
    
    /**
     * Returns the command used for history viewing. Can be null.
     * @return Name of history command / url
     */
    public String getHistoryView() {
        return historyView;
    }
    public void setHistoryView(String historyView) {
        this.historyView = historyView;
    }
    
    /**
     * Returns the command used for editing. Can be null.
     * @return Name of edit command / url
     */
    public String getEditView() {
        return editView;
    }
    public void setEditView(String editView) {
        this.editView = editView;
    }
    
    /**
     * Returns the name of a custom command for "ex" editing. Can be null.
     * @return Name of the "ex" editing command / url
     */     
    public String getEditExView() {
        return editExView;
    }
    public void setEditExView(String editExView) {
        this.editExView = editExView;
    }
}
package com.kylietech.oaj.web.mvc;

import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

import net.javalib.theme.*;
import net.javalib.util.i18n.*;

import org.springframework.beans.factory.*;
import org.springframework.beans.propertyeditors.*;
import org.springframework.validation.*;
import org.springframework.web.bind.*;
import org.springframework.web.servlet.mvc.*;

import com.kylietech.oaj.auth.*;
import com.kylietech.oaj.common.util.*;
import com.kylietech.oaj.web.editor.*;
import com.kylietech.oaj.web.util.*;

/**
 * @author Sherif Omar
 * 
 * OAForm.java
 *  
 */
public abstract class OAForm extends SimpleFormController implements BeanNameAware {
    
    private String beanName;
    
	protected OAViewResolver viewResolver;    
    
    protected void initBinder(HttpServletRequest request,
            ServletRequestDataBinder binder) throws ServletException {
    	registerDateEditor(binder, null);
    }
    
    protected void registerGenericIdTypeEditor(ServletRequestDataBinder binder, Class clazz) {
    	binder.registerCustomEditor(clazz, null, new GenericIdTypeEditor(clazz));
    }
    
    protected void registerNullableGenericIdTypeEditor(ServletRequestDataBinder binder, Class clazz) {
    	binder.registerCustomEditor(clazz, null, new GenericIdTypeEditor(clazz, true));
    }   
    
    protected void registerDateEditor(ServletRequestDataBinder binder, String filter) {
    	binder.registerCustomEditor(Date.class, filter, new CustomDateEditor(Lang.getShortDateFormat(), false));
    }    
    
    protected void registerNullableDateEditor(ServletRequestDataBinder binder, String filter) {
    	binder.registerCustomEditor(Date.class, filter, new CustomDateEditor(Lang.getShortDateFormat(), true));
    }
    
    protected void registerNullableCodeEditor(ServletRequestDataBinder binder, Class clazz, String filter) {
    	binder.registerCustomEditor(clazz, filter, new GenericCodeTypeEditor(clazz, true));    	
     }
    
    protected void registerCodeEditor(ServletRequestDataBinder binder, Class clazz, String filter) {
    	binder.registerCustomEditor(clazz, filter, new GenericCodeTypeEditor(clazz, false));    	
     }        
    
    protected void registerNullableNumberEditor(ServletRequestDataBinder binder, Class clazz, String filter) {
    	binder.registerCustomEditor(clazz, filter, new CustomNumberEditor(clazz, Lang.getNumberFormat(), true));    	
     } 
    
    protected void registerNumberEditor(ServletRequestDataBinder binder, Class clazz, String filter) {
    	binder.registerCustomEditor(clazz, filter, new CustomNumberEditor(clazz, Lang.getNumberFormat(), false));    	
     }      
    
    protected void getModel(Map model, HttpServletRequest request, Object command) throws Exception {
        model.put("OA_form", this);
        model.put("OAFieldUtil", new FieldUtil()); 
        model.put("OADomainUtil", new OADomainUtil());
        model.put("OADomainLiteUtil", new OADomainLiteUtil());
		model.put("OAViewResolverUtil", new OAViewResolverUtil());	        
        
        model.put("_lang", new Lang());
        model.put("_auth", new Auth());
        model.put("_theme", new OATheme(request));
        model.put("_request", request);
        model.put("_viewResolver", getViewResolver());
        model.put("_consts", new OAFormConsts());
        model.put("_title", getTitle(request, command));
        model.put("m_hasMenu", new Boolean(hasMenu(request)));
        
        model.put("m_disableEditing", new Boolean(disableEditing(request, command)));
        model.put("m_isViewing", new Boolean(isViewing(request)));
    }

    protected Map referenceData(HttpServletRequest request, Object command, Errors errors) throws Exception {
        Map model = new HashMap();
        getModel(model, request, command);

        return model;
    }    
    
    public boolean isViewing(HttpServletRequest request) {
        return RequestUtils.getIntParameter(request, OAFormConsts.GET_VIEW, 0) > 0;
    }    

    public abstract String getTitle(HttpServletRequest request, Object command);
    
    public boolean hasMenu(HttpServletRequest request) {
        return true;
    }
    
    protected boolean disableEditing(HttpServletRequest request, Object command) {
    	return isViewing(request);
    }
    
    public OAViewResolver getViewResolver() {
        return viewResolver;
    }

    public void setViewResolver(OAViewResolver resolver) throws ClassNotFoundException {
        viewResolver = resolver;
    }
    
    /**
     * Returns the BeanNameAware set name of this form. All forms are singletons. 
     * @return Bean name.
     */
	public String getBeanName() {
		return beanName;
	}
	
	/**
	 * This should never be called directly - it's the implementation of BeanNameAware
	 */
	public void setBeanName(String beanName) {
		this.beanName = beanName;
	}
	
	public String getBeanNameAsAction() {
		return beanName.replace("/","");
	}

	public String getCustomActionTemplate(Object obj) {
        return null;
    }    

    public Object getNewDummyBackingObject() {
        return new DummyBackingObject();
    }
    
    public Class getDummyBackingObjectClass(){
        return DummyBackingObject.class;
    }
    
    class DummyBackingObject {
    }      


}
