public class _SupplierAdminStub extends ObjectImpl
	implements SupplierAdmin
{

	private String ids[] = {
		"IDL:omg.org/CosEventChannelAdmin/SupplierAdmin:1.0"
	};
	public static final Class _opsClass;
	static Class class$org$omg$CosEventChannelAdmin$SupplierAdminOperations; /* synthetic field */

	static
	{
		_opsClass = class$org$omg$CosEventChannelAdmin$SupplierAdminOperations == null ? (class$org$omg$CosEventChannelAdmin$SupplierAdminOperations = class$("Org.omg.CosEventChannelAdmin.SupplierAdminOperations")) : class$org$omg$CosEventChannelAdmin$SupplierAdminOperations;
	//    0    0:getstatic       #39  <Field java.lang.Class Org.omg.CosEventChannelAdmin._SupplierAdminStub.class$org$omg$CosEventChannelAdmin$SupplierAdminOperations>
	//    1    3:ifnull          12
	//    2    6:getstatic       #39  <Field java.lang.Class Org.omg.CosEventChannelAdmin._SupplierAdminStub.class$org$omg$CosEventChannelAdmin$SupplierAdminOperations>
	//    3    9:goto            21
	//    4   12:ldc1            #6   <String "Org.omg.CosEventChannelAdmin.SupplierAdminOperations">
	//    5   14:invokestatic    #38  <Method java.lang.Class Org.omg.CosEventChannelAdmin._SupplierAdminStub.class$(java.lang.String)>
	//    6   17:dup
	//    7   18:putstatic       #39  <Field java.lang.Class Org.omg.CosEventChannelAdmin._SupplierAdminStub.class$org$omg$CosEventChannelAdmin$SupplierAdminOperations>
	//    8   21:putstatic       #31  <Field java.lang.Class Org.omg.CosEventChannelAdmin._SupplierAdminStub._opsClass>
	//*   9   24:return
	}

	public _SupplierAdminStub() {
		//    0    0:aload_0
		//    1    1:invokespecial   #24  <Method void ObjectImpl()>
		//    2    4:aload_0
		//    3    5:iconst_1
		//    4    6:anewarray       java.lang.String[]
		//    5    9:dup
		//    6   10:iconst_0
		//    7   11:ldc1            #1   <String "IDL:omg.org/CosEventChannelAdmin/SupplierAdmin:1.0">
		//    8   13:aastore
		//    9   14:putfield        #43  <Field java.lang.String[] Org.omg.CosEventChannelAdmin._SupplierAdminStub.ids>
		//   10   17:return
	}

	static Class class$(String s) {
		try {
			return Class.forName(s);
			//    0    0:aload_0
			//    1    1:invokestatic    #40  <Method java.lang.Class java.lang.Class.forName(java.lang.String)>
			//    2    4:areturn
		} catch (ClassNotFoundException classnotfoundexception)
		//*   3    5:astore_1
		{
			throw new NoClassDefFoundError(classnotfoundexception.getMessage());
			//    4    6:new             #9   <Class java.lang.NoClassDefFoundError>
			//    5    9:dup
			//    6   10:aload_1
			//    7   11:invokevirtual   #42  <Method java.lang.String java.lang.Throwable.getMessage()>
			//    8   14:invokespecial   #25  <Method void NoClassDefFoundError(java.lang.String)>
			//    9   17:athrow
		}
	}

	public String[] _ids() {
		return ids;
		//    0    0:aload_0
		//    1    1:getfield        #43  <Field java.lang.String[] Org.omg.CosEventChannelAdmin._SupplierAdminStub.ids>
		//    2    4:areturn
	}

	public void finalize() {
		_release();
		//    0    0:aload_0
		//    1    1:invokevirtual   #32  <Method void Org.omg.CORBA.portable.ObjectImpl._release()>
		//    2    4:return
	}

	public ProxyPullConsumer obtain_pull_consumer() {
		do {
			if (_is_local())
				break;
			//    0    0:aload_0
			//    1    1:invokevirtual   #30  <Method boolean Org.omg.CORBA.portable.ObjectImpl._is_local()>
			//    2    4:ifne            98
			Org.omg.CORBA.portable.InputStream inputstream = null;
			//    3    7:aconst_null
			//    4    8:astore_1
			try {
				Org.omg.CORBA.portable.OutputStream outputstream = _request("obtain_pull_consumer", true);
				//    5    9:aload_0
				//    6   10:ldc1            #4   <String "obtain_pull_consumer">
				//    7   12:iconst_1
				//    8   13:invokevirtual   #34  <Method Org.omg.CORBA.portable.OutputStream Org.omg.CORBA.portable.ObjectImpl._request(java.lang.String, boolean)>
				//    9   16:astore          5
				inputstream = _invoke(outputstream);
				//   10   18:aload_0
				//   11   19:aload           5
				//   12   21:invokevirtual   #29  <Method Org.omg.CORBA.portable.InputStream Org.omg.CORBA.portable.ObjectImpl._invoke(Org.omg.CORBA.portable.OutputStream)>
				//   13   24:astore_1
				ProxyPullConsumer proxypullconsumer2 = ProxyPullConsumerHelper.read(inputstream);
				//   14   25:aload_1
				//   15   26:invokestatic    #46  <Method Org.omg.CosEventChannelAdmin.ProxyPullConsumer Org.omg.CosEventChannelAdmin.ProxyPullConsumerHelper.read(Org.omg.CORBA.portable.InputStream)>
				//   16   29:astore          6
				ProxyPullConsumer proxypullconsumer = proxypullconsumer2;
				//   17   31:aload           6
				//   18   33:astore_2
				//*  19   34:jsr             89
				return proxypullconsumer;
				//   20   37:aload_2
				//   21   38:areturn
			} catch (RemarshalException _ex) {
			}
			//   22   39:pop
			//*  23   40:goto            77
			catch (ApplicationException applicationexception)
			//*  24   43:astore          5
			{
				String s = applicationexception.getId();
				//   25   45:aload           5
				//   26   47:invokevirtual   #41  <Method java.lang.String Org.omg.CORBA.portable.ApplicationException.getId()>
				//   27   50:astore          6
				throw new RuntimeException("Unexpected exception " + s);
				//   28   52:new             #10  <Class java.lang.RuntimeException>
				//   29   55:dup
				//   30   56:new             #12  <Class java.lang.StringBuffer>
				//   31   59:dup
				//   32   60:ldc1            #2   <String "Unexpected exception ">
				//   33   62:invokespecial   #27  <Method void StringBuffer(java.lang.String)>
				//   34   65:aload           6
				//   35   67:invokevirtual   #37  <Method java.lang.StringBuffer java.lang.StringBuffer.append(java.lang.String)>
				//   36   70:invokevirtual   #49  <Method java.lang.String java.lang.StringBuffer.toString()>
				//   37   73:invokespecial   #26  <Method void RuntimeException(java.lang.String)>
				//   38   76:athrow
			} finally
			//*  39   77:jsr             89
			//*  40   80:goto            0
			//*  41   83:astore_3
			//*  42   84:jsr             89
			//*  43   87:aload_3
			//*  44   88:athrow
			//*  45   89:astore          4
		