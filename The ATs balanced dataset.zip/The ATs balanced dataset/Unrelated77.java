mport org.sparrowcontainer.core.bean.BeanFactory;
import org.sparrowcontainer.core.logging.Logger;
import org.sparrowcontainer.jdbc.ConnectionManager;

/**
 * Statement.java
 * Create on 2004?~12??11??
 * @author Leo
 * @author     <a href="mailto:leo@sparrowcontainer.org">Leo Chan</a>
 * @version    Revision: 0.1 Alpha 
 */
public class Statement implements java.sql.Statement,ProxyjConstant {
    
    private java.sql.Statement[] realStatement=null;
    
    private java.sql.Connection[] realConn=null ;
    
    private CNode cnode=null;
    
    private boolean isQuery=false;
    
    public java.sql.Statement[] returnRealStatement(){
        return realStatement;
    }
    
    public java.sql.Connection[] returnRealConn(){
        return realConn;
    }
    
    public CNode returnCNode(){
        return cnode;
    }
    
    public void assignCNode(CNode cnode){
        this.cnode=cnode;
    }
    
    public void makeQuery(){
        isQuery=true;
    }
    
    public void initAA(){
        realConn=new java.sql.Connection[2];
        realStatement=new java.sql.Statement[2];
        if(cnode.getDbnodes1().getStatus()==STATE_READY){
            realConn[0]=ConnectionManager.getConnection(cnode.getDbnodes1().getPoolName());
            //realStatement[0]=realConn[0].prepareStatement();
            Logger.logDebug(this, " realConn[0] "+ realConn[0]);
        }  
        if(cnode.getDbnodes2().getStatus()==STATE_READY){
            realConn[1]=ConnectionManager.getConnection(cnode.getDbnodes2().getPoolName());
            Logger.logDebug(this, " realConn[1] "+ realConn[0]);
            //realStatement[0]=realConn[0].prepareStatement();
        }                        
    }
    
    public void initAS(){
        realConn=new java.sql.Connection[2];
        realStatement=new java.sql.Statement[2];
        if(cnode.getDbnodes1().getStatus()==STATE_READY){
            realConn[0]=ConnectionManager.getConnection(cnode.getDbnodes1().getPoolName());
            //realStatement[0]=realConn[0].prepareStatement();
            Logger.logDebug(this, " realConn[0] "+ realConn[0]);
        }  
        if(cnode.getDbnodes2().getStatus()==STATE_READY){
            realConn[1]=ConnectionManager.getConnection(cnode.getDbnodes2().getPoolName());
            Logger.logDebug(this, " realConn[1] "+ realConn[0]);
            //realStatement[0]=realConn[0].prepareStatement();
        }                        
    }
    
    public void createStatement()
	throws SQLException{
	    if(realConn[0]!=null){           
	        realStatement[0]=realConn[0].createStatement();
	    }  
	    if(realConn[1]!=null){              
	        realStatement[1]=realConn[1].createStatement();
	    }    
	}
	
	public void createStatement(int resultSetType, int resultSetConcurrency)
		throws SQLException{
	    if(realConn[0]!=null){           
	        realStatement[0]=realConn[0].createStatement(resultSetType, resultSetConcurrency);
	    }  
	    if(realConn[1]!=null){              
	        realStatement[1]=realConn[1].createStatement(resultSetType, resultSetConcurrency);
	    }    
	}
	
	public void createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability)
		throws SQLException{
	    if(realConn[0]!=null){           
	        realStatement[0]=realConn[0].createStatement(resultSetType,resultSetConcurrency,resultSetHoldability);
	    }  
	    if(realConn[1]!=null){              
	        realStatement[1]=realConn[1].createStatement(resultSetType,resultSetConcurrency,resultSetHoldability);
	    }    
	}
    
    /* (non-Javadoc)
     * @see java.sql.Statement#getFetchDirection()
     */
    public int getFetchDirection() throws SQLException {
        // TODO Auto-generated method stub
        return 0;
    }

    /* (non-Javadoc)
     * @see java.sql.Statement#getFetchSize()
     */
    public int getFetchSize() throws SQLException {
        // TODO Auto-generated method stub
        return 0;
    }

    /* (non-Javadoc)
     * @see java.sql.Statement#getMaxFieldSize()
     */
    public int getMaxFieldSize() throws SQLException {
        // TODO Auto-generated method stub
        return 0;
    }

    /* (non-Javadoc)
     * @see java.sql.Statement#getMaxRows()
     */
    public int getMaxRows() throws SQLException {
        // TODO Auto-generated method stub
        return 0;
    }

    /* (non-Javadoc)
     * @see java.sql.Statement#getQueryTimeout()
     */
    public int getQueryTimeout() throws SQLException {
        // TODO Auto-generated method stub
        return 0;
    }

    /* (non-Javadoc)
     * @see java.sql.Statement#getResultSetConcurrency()
     */
    public int getResultSetConcurrency() throws SQLException {
        // TODO Auto-generated method stub
        return 0;
    }

    /* (non-Javadoc)
     * @see java.sql.Statement#getResultSetHoldability()
     */
    public int getResultSetHoldability() throws SQLException {
        // TODO Auto-generated method stub
        return 0;
    }

    /* (non-Javadoc)
     * @see java.sql.Statement#getResultSetType()
     */
    public int getResultSetType() throws SQLException {
        // TODO Auto-generated method stub
        return 0;
    }

    /* (non-Javadoc)
     * @see java.sql.Statement#getUpdateCount()
     */
    public int getUpdateCount() throws SQLException {
        // TODO Auto-generated method stub
        return 0;
    }

    /* (non-Javadoc)
     * @see java.sql.Statement#cancel()
     */
    public void cancel() throws SQLException {
        // TODO Auto-generated method stub

    }

    /* (non-Javadoc)
     * @see java.sql.Statement#clearBatch()
     */
    public void clearBatch() throws SQLException {
        // TODO Auto-generated method stub

    }

    /* (non-Javadoc)
     * @see java.sql.Statement#clearWarnings()
     */
    public void clearWarnings() throws SQLException {
        // TODO Auto-generated method stub

    }

    /* (non-Javadoc)
     * @see java.sql.Statement#close()
     */
    public void close() throws SQLException {
        // Logger.logDebug(this,"#########CLOSING#########");
         if((cnode.getSelectMode()==1 
                 && cnode.getDbnodes1().getStatus()==STATE_READY)||
                 isQuery ||
                 (cnode.getSelectMode()==2 &&
                         cnode.getDbnodes1().getStatus()==STATE_READY &&
                         cnode.getDbnodes1().getWaitOnReturn())
         ){
              
 	        if(realStatement[0]!=null ){           
 	            realStatement[0].close();
 	        }
 	        if(realConn[0]!=null){           
 	            realConn[0].close();
 	        }
     	}    
         if((cnode.getSelectMode()==1 
                 && cnode.getDbnodes1().getStatus()==STATE_FAILED)||
                 (cnode.getSelectMode()==2 
                         && cnode.getDbnodes2().getStatus()==STATE_FAILED)
         	){
             if(realStatement[0]!=null ){           
 	            realStatement[0].close();
 	        }
             if(realConn[0]!=null){           
 	            realConn[0].close();
 	        }  
             if(realStatement[1]!=null ){           
 	            realStatement[1].close();
 	        }
 	        if(realConn[1]!=null){           
 	            realConn[1].close();
 	        }  
 	       
 	        
 	        
     	}  
         if((cnode.getSelectMode()==2 
                 && cnode.getDbnodes2().getStatus()==STATE_READY)||
                 isQuery  ||
                 (cnode.getSelectMode()==1 &&
                         cnode.getDbnodes2().getStatus()==STATE_READY &&
                         cnode.getDbnodes2().getWaitOnReturn())
             ){
 	         
 	        if(realStatement[1]!=null ){           
 	            realStatement[1].close();
 	        }
 	        if(realConn[1]!=null){           
 	            realConn[1].close();
 	        } 
         }    
         isQuery=false;
         Logger.logDebug(this, "return "+this.getClass().getName());
         BeanFactory.returnBean(this, Statement.class.getName(), cnode.getNodeName());
     }

    /* (non-Javadoc)
     * @see java.sql.Statement#getMoreResults()
     */
    public boolean getMoreResults() throws SQLException {
        // TODO Auto-generated method stub
        return false;
    }

    /* (non-Javadoc)
     * @see java.sql.Statement#executeBatch()
     */
    public int[] executeBatch() throws SQLException {
        if(realStatement[0]!=null){   
            if(cnode.getSelectMode()==1){
                if(cnode.getDbnodes1().getStatus()==STATE_READY && 
                        cnode.getDbnodes2().getStatus()==STATE_READY ){
                    realStatement[1].executeBatch();
                    return realStatement[0].executeBatch();
                }else if(cnode.getDbnodes1().getStatus()==STATE_READY && 
                        cnode.getDbnodes2().getStatus()!=STATE_READY ){
                    //add callback later
                    return realStatement[0].executeBatch();
                }else if(cnode.getDbnodes1().getStatus()!=STATE_READY && 
                        cnode.getDbnodes2().getStatus()==STATE_READY ){
                   	//add callback later
                    return realStatement[1].executeBatch();
                }else{
                	//add callback later
                }
            }
        }  
        if(realStatement[1]!=null){   
            if(cnode.getSelectMode()==2){
                if(cnode.getDbnodes2().getStatus()==STATE_READY && 
                        cnode.getDbnodes1().getStatus()==STATE_READY ){
                    realStatement[0].executeBatch();
                    return realStatement[1].executeBatch();
                }else if(cnode.getDbnodes2().getStatus()==STATE_READY && 
                        cnode.getDbnodes1().getStatus()!=STATE_READY ){
                    //add callback later
                    return realStatement[1].executeBatch();
                }else if(cnode.getDbnodes2().getStatus()!=STATE_READY && 
                        cnode.getDbnodes1().getStatus()==STATE_READY ){
                   	//add callback later
                    return realStatement[0].executeBatch();
                }else{
                	//add callback later
                }
            }
        } 
        return null;
    }

    /* (non-Javadoc)
     * @see java.sql.Statement#setFetchDirection(int)
     */
    public void setFetchDirection(int direction) throws SQLException {
        // TODO Auto-generated method stub

    }

    /* (non-Javadoc)
     * @see java.sql.Statement#setFetchSize(int)
     */
    public void setFetchSize(int rows) throws SQLException {
        // TODO Auto-generated method stub

    }

    /* (non-Javadoc)
     * @see java.sql.Statement#setMaxFieldSize(int)
     */
    public void setMaxFieldSize(int max) throws SQLException {
        if(realConn[0]!=null){           
            realStatement[0].setMaxFieldSize(max);
        }  
        if(realConn[1]!=null){              
            realStatement[1].setMaxFieldSize(max);
        }

    }

    /* (non-Javadoc)
     * @see java.sql.Statement#setMaxRows(int)
     */
    public void setMaxRows(int max) throws SQLException {
        if(realConn[0]!=null){           
            realStatement[0].setMaxRows(max);
        }  
        if(realConn[1]!=null){              
            realStatement[1].setMaxRows(max);
        }

    }

    /* (non-Javadoc)
     * @see java.sql.Statement#setQueryTimeout(int)
     */
    public void setQueryTimeout(int seconds) throws SQLException {
        if(realConn[0]!=null){           
            realStatement[0].setQueryTimeout(seconds);
        }  
        if(realConn[1]!=null){              
            realStatement[1].setQueryTimeout(seconds);
        }

    }

    /* (non-Javadoc)
     * @see java.sql.Statement#getMoreResults(int)
     */
    public boolean getMoreResults(int current) throws SQLException {
        // TODO Auto-generated method stub
        return false;
    }

public boolean getMoreResults(int current) throws SQLException {
        // TODO Auto-generated method stub
        return false;
    }

    /* (non-Javadoc)
     * @see java.sql.Statement#setEscapeProcessing(boolean)
     */
    public void setEscapeProcessing(boolean enable) throws SQLException {
        // TODO Auto-generated method stub

    }

    /* (non-Javadoc)
     * @see java.sql.Statement#executeUpdate(java.lang.String)
     */
    public int executeUpdate(String sql) throws SQLException {
        if(realStatement[0]!=null){   
            if(cnode.getSelectMode()==1){
                if(cnode.getDbnodes1().getStatus()==STATE_READY && 
                        cnode.getDbnodes2().getStatus()==STATE_READY ){
                    realStatement[1].executeUpdate(sql);
                    return realStatement[0].executeUpdate(sql);
                }else if(cnode.getDbnodes1().getStatus()==STATE_READY && 
                        cnode.getDbnodes2().getStatus()!=STATE_READY ){
                    //add callback later
                    return realStatement[0].executeUpdate(sql);
                }else if(cnode.getDbnodes1().getStatus()!=STATE_READY && 
                        cnode.getDbnodes2().getStatus()==STATE_READY ){
                   	//add callback later
                    return realStatement[1].executeUpdate(sql);
                }else{
                	//add callback later
                }
            }
        }  
        if(realStatement[1]!=null){   
            if(cnode.getSelectMode()==2){
                if(cnode.getDbnodes2().getStatus()==STATE_READY && 
                        cnode.getDbnodes1().getStatus()==STATE_READY ){
                    realStatement[0].executeUpdate(sql);
                    return realStatement[1].executeUpdate(sql);
                }else if(cnode.getDbnodes2().getStatus()==STATE_READY && 
                        cnode.getDbnodes1().getStatus()!=STATE_READY ){
                    //add callback later
                    return realStatement[1].executeUpdate(sql);
                }else if(cnode.getDbnodes2().getStatus()!=STATE_READY && 
                        cnode.getDbnodes1().getStatus()==STATE_READY ){
                   	//add callback later
                    return realStatement[0].executeUpdate(sql);
                }else{
                	//add callback later
                }
            }
        } 
        return 0;
    }

    /* (non-Javadoc)
     * @see java.sql.Statement#addBatch(java.lang.String)
     */
    public void addBatch(String sql) throws SQLException {
        if(realConn[0]!=null){           
            realStatement[0].addBatch(sql);
        }  
        if(realConn[1]!=null){              
            realStatement[1].addBatch(sql);
        } 

    }
