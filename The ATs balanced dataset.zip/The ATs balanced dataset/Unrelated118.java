
package com.sun.identity.qatest.cli;

import com.sun.identity.qatest.common.cli.CLIExitCodes;
import com.sun.identity.qatest.common.cli.FederationManagerCLI;
import com.sun.identity.qatest.common.TestCommon;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.logging.Level;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.Reporter;

/**
 * <code>AddRealmAttributesTest</code> is used to execute tests involving the 
 * add-realm-attributes sub-command of ssoadm.  This class allows the user to 
 * execute "ssoadm add-realm-attributes" with a variety or arguments (e.g with 
 * short or long options, with a locale argument, with a list of attributes 
 * or a datafile containing attributes, etc.) and a variety of input values.  
 * The properties file <code>AddRealmAttributesTest.properties</code> contains 
 * the input values which are read by this class.
 *
 * This class automates the following test cases:
 * CLI_add-realm-attributes01, CLI_add-realm-attributes02, 
 * CLI_add-realm-attributes03, CLI_add-realm-attributes04,
 * CLI_add-realm-attributes05, CLI_add-realm-attributes06
 */

public class AddRealmAttributesTest extends TestCommon implements CLIExitCodes {
    
    private String locTestName;
    private ResourceBundle rb;
    private String setupRealms;
    private String realm;
    private String serviceName;
    private String attributeValues;
    private boolean useDatafileOption;
    private boolean useVerboseOption;
    private boolean useDebugOption;
    private boolean useLongOptions;
    private String expectedMessage;
    private String expectedExitCode;
    private String description;
    private FederationManagerCLI cli;
    
    /** 
     * Creates a new instance of AddRealmAttributesTest 
     */
    public AddRealmAttributesTest() {
        super("AddRealmAttributesTest");
    }
    
    /**
     * This method is intended to provide initial setup.
     * Creates any realms specified in the setup-realms property in the 
     * AddRealmAttributesTest.properties file.
     */
    @Parameters({"testName"})
    @BeforeClass(groups={"ldapv3", "ldapv3_sec", "s1ds", "s1ds_sec", "ad", 
      "ad_sec", "amsdk", "amsdk_sec", "jdbc", "jdbc_sec"})
    public void setup(String testName) 
    throws Exception {
        Object[] params = {testName};
        entering("setup", params);
        try {
            locTestName = testName;
            rb = ResourceBundle.getBundle("cli" + fileseparator + 
                    "AddRealmAttributesTest");
            setupRealms = (String)rb.getString(locTestName + 
                    "-create-setup-realms");
            useVerboseOption = ((String)rb.getString(locTestName + 
                    "-use-verbose-option")).equals("true");
            useDebugOption = ((String)rb.getString(locTestName + 
                    "-use-debug-option")).equals("true");
            useLongOptions = ((String)rb.getString(locTestName + 
                    "-use-long-options")).equals("true");
                
            log(Level.FINEST, "setup", "use-verbose-option: " + 
                    useVerboseOption);
            log(Level.FINEST, "setup", "use-debug-option: " + useDebugOption);
            log(Level.FINEST, "setup", "use-long-options: " + useLongOptions);
            log(Level.FINEST, "setup", "create-setup-realms: " + setupRealms);

            Reporter.log("UseDebugOption: " + useDebugOption);
            Reporter.log("UseVerboseOption: " + useVerboseOption);
            Reporter.log("UseLongOptions: " + useLongOptions);
            Reporter.log("SetupRealms: " + setupRealms);

            cli = new FederationManagerCLI(useDebugOption, useVerboseOption, 
                    useLongOptions);
            
            log(Level.FINE, "setup", "Creating the following realms: " + 
                    setupRealms);
            
            if (!cli.createRealms(setupRealms)) {
                log(Level.SEVERE, "setup", 
                        "All the realms failed to be created.");
                assert false;
            }
 
            exiting("setup");
        } catch (Exception e) {
            log(Level.SEVERE, "setup", e.getMessage(), null);
            e.printStackTrace();
            throw e;
        } 
    }
    
    /**
     * This method is used to execute tests involving 
     * "ssoadm add-realm-attributes" using input data from the 
     * AddRealmAttributesTest.properties file.
     */
    @Test(groups={"ldapv3", "ldapv3_sec", "s1ds", "s1ds_sec", "ad", "ad_sec", 
      "amsdk", "amsdk_sec", "jdbc", "jdbc_sec"})
    public void testRealmAddAttributeValues() 
    throws Exception {
        entering("testRealmAddAttributeValues", null);
        boolean stringsFound = false;
        boolean attributesFound = false;
        boolean errorFound = false;
        int commandStatus = -1;
        
        try {
            description = (String) rb.getString(locTestName + "-description");
            expectedMessage = (String) rb.getString(locTestName + 
                    "-message-to-find");
            expectedExitCode = (String) rb.getString(locTestName + 
                    "-expected-exit-code");
            realm = (String) rb.getString(locTestName + 
                    "-add-realm-attributes-realm");
            serviceName = (String) rb.getString(locTestName + 
                    "-add-realm-attributes-servicename");
            attributeValues = (String) rb.getString(locTestName + 
                    "-add-realm-attributes-attribute-list");
            useDatafileOption = ((String) rb.getString(locTestName + 
                    "-add-realm-attributes-use-datafile-option")).
                    equals("true");

            log(Level.FINEST, "testRealmAddAttributeValues", "description: " + 
                    description);
            log(Level.FINEST, "testRealmAddAttributeValues", 
                    "use-debug-option: " + useDebugOption);
            log(Level.FINEST, "testRealmAddAttributeValues", 
                    "use-verbose-option: " + useVerboseOption);
            log(Level.FINEST, "testRealmAddAttributeValues", 
                    "use-long-options: " + useLongOptions);
            log(Level.FINEST, "testRealmAddAttributeValues", "message-to-find: "
                    + expectedMessage);
            log(Level.FINEST, "testRealmAddAttributeValues", 
                    "expected-exit-code: " + expectedExitCode);
            log(Level.FINEST, "testRealmAddAttributeValues", 
                    "add-realm-attributes-realm: " + realm);
            log(Level.FINEST, "testRealmAddAttributeValues", 
                    "add-realm-attributes-servicename: " + serviceName);
            log(Level.FINEST, "testRealmAddAttributeValues", 
                    "add-realm-attributes-attribute-list: " + attributeValues);
            log(Level.FINEST, "testRealmAddAttributeValues", 
                    "add-realm-attributes-use-datafile-option: " + 
                    useDatafileOption);

            Reporter.log("TestName: " + locTestName);
            Reporter.log("Description: " + description);
            Reporter.log("UseDebugOption: " + useDebugOption);
            Reporter.log("UseVerboseOption: " + useVerboseOption);
            Reporter.log("UseLongOptions: " + useLongOptions);
            Reporter.log("ExpectedMessage: " + expectedMessage);
            Reporter.log("ExpectedExitCode: " + expectedExitCode);
            Reporter.log("Realm: " + realm);
            Reporter.log("ServiceName: " + serviceName);
            Reporter.log("AttributeList: " + attributeValues);
            Reporter.log("UseDatafileOption: " + useDatafileOption);
            
            String msg = (String) rb.getString(locTestName + 
                    "-message-to-find");  
            if (expectedExitCode.equals(new Integer(SUCCESS_STATUS).
                    toString())) {
                Object[] params = {realm}; 
                if (msg.equals("")) {           
                    if (!useVerboseOption) {
                        String successString = 
                                (String) rb.getString("success-message");
                        expectedMessage = 
                                MessageFormat.format(successString, params);
                    } else {
                        String verboseSuccessString = 
                                (String) rb.getString(
                                "verbose-success-message");
                        expectedMessage = 
                                MessageFormat.format(verboseSuccessString,
                                params);
                    }
                } else {
                    expectedMessage = 
                            MessageFormat.format(msg, params);
                }
            } else if (expectedExitCode.equals(
                    new Integer(INVALID_OPTION_STATUS).toString())) {
                expectedMessage = (String) rb.getString("usage");
            } else {
                expectedMessage = msg;                
            }

            commandStatus = cli.addRealmAttributes(realm, serviceName, 
                    attributeValues, useDatafileOption);
            cli.logCommand("testRealmAddAttributeValues");
            cli.resetArgList();
            
            if (expectedExitCode.equals(new Integer(SUCCESS_STATUS).
                    toString())) {
                stringsFound = cli.findStringsInOutput(expectedMessage, ";"); 
                FederationManagerCLI searchCLI = 
                        new FederationManagerCLI(useDebugOption, 
                        useVerboseOption, useLongOptions);
                attributesFound = searchCLI.findRealmAttributes(realm, 
                        serviceName, attributeValues);
                searchCLI.logCommand("testRealmAddAttributeValues");
            } else if (expectedExitCode.equals(
                    new Integer(INVALID_OPTION_STATUS).toString())) {
                String argString = cli.getAllArgs().replaceFirst(
                        cli.getCliPath() + fileseparator + "ssoadm", "ssoadm ");
                Object[] params = {argString};
                String errorMessage = 
                        (String) rb.getString("invalid-usage-message");
                String usageError = MessageFormat.format(errorMessage, params);
                stringsFound = cli.findStringsInOutput(expectedMessage, ";");                
                errorFound = cli.findStringsInError(usageError, ";");
            } else {
                errorFound = cli.findStringsInError(expectedMessage, ";");
            }
            cli.resetArgList();
                   
            log(Level.FINEST, "testRealmAddAttributeValues", "Exit status: " + 
                    commandStatus);
            if (expectedExitCode.equals(
                    new Integer(SUCCESS_STATUS).toString())) {
                log(Level.FINEST, "testRealmAddAttributeValues", 
                        "Output Messages Found: " + stringsFound);
                log(Level.FINEST, "testRealmAddAttributeValues", 
                        "Attributes Found: " + attributesFound);
                assert (commandStatus == 
                    new Integer(expectedExitCode).intValue()) && stringsFound &&
                        attributesFound;
            } else {
                log(Level.FINEST, "testRealmAddAttributeValues", 
                        "Error Messages Found: " + errorFound);
                if (expectedExitCode.equals(
                        new Integer(INVALID_OPTION_STATUS).toString())) {
                    log(Level.FINEST, "testRealmAddAttributeValues", 
                            "Output Messages Found: " + stringsFound); 
                    assert (commandStatus == 
                            new Integer(expectedExitCode).intValue()) && 
                            stringsFound && errorFound;                    
                } else {
                    assert (commandStatus == 
                            new Integer(expectedExitCode).intValue()) && 
                            errorFound;
                }
            }   
            exiting("testRealmAddAttributeValues");
        } catch (Exception e) {
            log(Level.SEVERE, "testRealmAddAttributeValues", e.getMessage(), 
                    null);
            e.printStackTrace();
            throw e;
        } 
    }
    
    /**
     * This method remove any realms and identities that were created during 
     * the setup and testRealmAddAttributeValues methods using 
     * "ssoadm delete-realm".
     */
    @AfterClass(groups={"ldapv3", "ldapv3_sec", "s1ds", "s1ds_sec", "ad", 
      "ad_sec", "amsdk", "amsdk_sec", "jdbc", "jdbc_sec"})
    public void cleanup() 
    throws Exception {
        int exitStatus = -1;

        entering("cleanup", null);
        try {            
            log(Level.FINEST, "cleanup", "useDebugOption: " + useDebugOption);
            log(Level.FINEST, "cleanup", "useVerboseOption: " + 
                    useVerboseOption);
            log(Level.FINEST, "cleanup", "useLongOptions: " + useLongOptions);
            
            Reporter.log("UseDebugOption: " + useDebugOption);
            Reporter.log("UseVerboseOption: " + useVerboseOption);
            Reporter.log("UseLongOptions: " + useLongOptions);
            

            if (!setupRealms.equals("")) {
                String[] realms = setupRealms.split(";");
                for (int i=realms.length-1; i >= 0; i--) {
                    log(Level.FINE, "cleanup", "Removing realm " + 
                        realms[i]);
                    Reporter.log("SetupRealmToDelete: " + realms[i]);
                    exitStatus = cli.deleteRealm(realms[i], true); 
                    cli.logCommand("cleanup");
                    cli.resetArgList();
                    if (exitStatus != SUCCESS_STATUS) {
                        log(Level.SEVERE, "cleanup", "The removal of realm " + 
                                realms[i] + " failed with exit status " + 
                                exitStatus);
                        assert false;
                    }import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.identity.plugin.session.SessionManager;
import com.sun.identity.plugin.session.SessionException;
import com.sun.identity.saml2.profile.SPSSOFederate;
import com.sun.identity.shared.debug.Debug;

public final class ECPFilter implements Filter {

    public static Debug debug = Debug.getInstance("ECPFilter");

    /**
     * Redirects request to configuration page if the product is not yet 
     * configured.
     *
     * @param request Servlet Request.
     * @param response Servlet Response.
     * @param filterChain Filter Chain.
     * @throws IOException if configuration file cannot be read.
     * @throws ServletException if there are errors in the servlet space.
     */
    public void doFilter(
        ServletRequest request, 
        ServletResponse response, 
        FilterChain filterChain
    ) throws IOException, ServletException 
    {
        HttpServletRequest  httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response ;

        if (!SPSSOFederate.isFromECP(httpRequest)) {
            filterChain.doFilter(httpRequest, httpResponse);
            if (debug.messageEnabled()) {
                debug.message("ECPFilter.doFilter: not from ECP. request = " +
                    httpRequest.getRequestURL());
            }  
            return;
        }
        if (debug.messageEnabled()) {
            debug.message("ECPFilter.doFilter: from ECP. request = " +
                httpRequest.getRequestURL());
        }  

        Object session = null;

        try {
            session = SessionManager.getProvider().getSession(httpRequest);
        } catch (SessionException se) {
            if (debug.messageEnabled()) {
                debug.message("ECPFilter.doFilter:", se);
            }
        }

        try {
            if (session != null) {
                if (debug.messageEnabled()) {
                    debug.message("ECPFilter.doFilter: session found");
                }  


                filterChain.doFilter(httpRequest, httpResponse);
            } else {
                String resource = "/SPECP?metaAlias=/sp&RelayState=" +
                    httpRequest.getRequestURL();
                if (debug.messageEnabled()) {
                    debug.message(
                        "ECPFilter.doFilter: Forwarding to :" + resource);
                }  
                RequestDispatcher dispatcher = 
                    request.getRequestDispatcher(resource);
                dispatcher.forward(request, response);

            }
        } catch(Exception ex) {
            throw new ServletException("ECPFilter.doFilter", ex);
        }
    }

    /**
     * Initializes the filter.
     *
     * @param filterConfig Filter Configuration.
     */
    public void init(FilterConfig filterConfig) {
    }

    public void destroy() {
    }
}
String LAST_FAILED_END ="</LastInvalidAt>";
    private static final String LOCKEDOUT_AT_BEGIN ="<LockedoutAt>";
    private static final String LOCKEDOUT_AT_END ="</LockedoutAt>";
    private static final String ACTUAL_LOCKOUT_DURATION_BEGIN =
        "<ActualLockoutDuration>";
    private static final String ACTUAL_LOCKOUT_DURATION_END =
        "</ActualLockoutDuration>";
    private static final String END_XML="</InvalidPassword>";
    
    private boolean failureLockoutMode = false;
    private boolean memoryLocking = false;
    private boolean storeInvalidAttemptsInDS = true;
    private long failureLockoutTime = 300;
    private int failureLockoutCount = 5;
    private String lockoutNotification = null;
    private int lockoutUserWarning = 3;
    private int userWarningCount = 0;
    private long failureLockoutDuration = 0;
    private int failureLockoutMultiplier = 1;
    private String lockoutAttrValue=null;
    private String lockoutAttrName=null;
    private String bundleName = null;
    private String invalidAttemptsDataAttrName =
        DEFAULT_INVALID_ATTEMPTS_XML_ATTR;
    private boolean needToSetInvalidAttemptsObjectClass = true;
    static Debug debug = Debug.getInstance("amAccountLockout");
    private AMAuthCallBackImpl callbackImpl = null;
    static Map loginFailHash = Collections.synchronizedMap(new HashMap());
    
    
    /**
     * Using this constructor the caller passes the account lockout
     * attribute values for the service and the resource bundle name
     * from with the localized account locking messages will be picked
     * up.
     *
     * @param     private static Debug debug = Debug.getInstance("amProfile");

    private static final String bundleName = "amCommonUtils";

    public static ResourceBundle _bundle = ResourceBundle.getBundle(bundleName);

    /**
     * Non-default construtor used to create a new ISResourceBundle object This
     * constructor takes a Map of key-value pairs (both Strings) and uses that
     * Map to construct an ISResourceBundle object
     * 
     * @param keyValues
     *            Map of key-value pairs.
     */
    protected ISResourceBundle(Map keyValues) {
        super();
        if (keyValues == null) {
            throw new NullPointerException();
        }
        rbArray = new String[keyValues.size()][2];
        Iterator it = keyValues.keySet().iterator();
        int count = 0;
        while (it.hasNext()) {
            String key = (String) it.next();
            String value;
            Set values = (Set) keyValues.get(key);
            if (values.size() != 0) {
                value = (String) values.iterator().next();
                rbArray[count][0] = convertUnicode(key);
                rbArray[count][1] = convertUnicode(value);
                count++;
            }
        }

    }

    /**
     * Returns a ResourceBundle. This method tries to find a ResourceBundle
     * given locale using <code> java.util.ResourceManager </code> first. But if
     * it doesn't find the ResourceBundle in the local file system, then look
     * for it in the directory (data store). In the directory, it follows the
     * same protocol as the default ResourceManager. It looks for the specific
     * locale first (language and country) and if not found than language
     * locale, and if that is not found then the default locale.
     * 
     * @param token
     *            Single sign-on token of the user
     * @param rbName
     *            Name of the ResourceBundle
     * @param locale
     *            Specific locale of ResourceBundle
     * @return ResourceBundle with the key-value pairs.
     * @throws SSOException
     */
    public static ResourceBundle getResourceBundle(SSOToken token,
            String rbName, Locale locale) throws SSOException {
        if (locale == null) {
            return getResourceBundle(token, rbName, (String) null);
        }
        String language = locale.getLanguage();
        String country = locale.getCountry();
        String loc = null;
        if (language != null && language.length() > 0) {
            loc = language;
        }
        if (country != null && country.length() > 0 && loc != null) {
            loc = loc + "_" + country;
        }
        return getResourceBundle(token, rbName, loc);
    }

    /**
     * Returns a ResourceBundle. This method tries to find a ResourceBundle
     * given locale using <code> java.util.ResourceManager </code> first. But if
     * it doesn't find the ResourceBundle in the local file system, then look
     * for it in the directory (data store). In the directory, it follows the
     * same protocol as the default ResourceManager. It looks for the specific
     * locale first (language and country) and if not found than language
     * locale, and if that is not found then the default locale.
     * 
     * @param token
     *            Single sign-on token of the user
     * @param rbName
     *            Name of the ResourceBundle
     * @param locale
     *            String identifying the language and country (for example:
     *            en_US). If this is null, then the default ResourceBundle is
     *            returned.
     * @return ISResourceBundle
     * @throws SSOException
     *             If user does not have read access to read the ResourceBundles
     *             from directory.
     */
    public static ResourceBundle getResourceBundle(SSOToken token,
            String rbName, String locale) throws SSOException {
        try {
            return getResourceBundleFromDisk(rbName, locale);
        } catch (MissingResourceException me) {
            return getResourceBundleFromDirectory(token, rbName, locale);
        }
    }

    /**
     * Deletes the specified ResourceBundle from the directory.
     * 
     * @param token
     *            Single sign-on token of user
     * @param rbName
     *            Name of ResourceBundle
     * @param locale
     *            String defining the locale. If null, then all the locales of
     *            this ResourceBundle, including the default one, are deleted.
     * @throws SMSException
     *             If there is an error trying to modify the datastore
     * @throws SSOException
     *             If this user's token has expired.
     */
    public static void deleteResourceBundle(SSOToken token, String rbName,
            String locale) throws SMSException, SSOException {
        if (rbName == null) {
            return;
        }
        ServiceConfigManager scm = new ServiceConfigManager(token,
                LOCALE_SERVICE, VERSION);
        ServiceConfig globalConfig = scm.getGlobalConfig(null);

     *        storing invalid attempts data.
     * @param bundleName a String, name of the resource bundle.
     */
    public ISAccountLockout(boolean failureLockoutMode,
 
                } 
            }            
            exiting("cleanup");
        } catch (Exception e) {
            log(Level.SEVERE, "cleanup", e.getMessage(), null);
            e.printStackTrace();
            throw e;
        } 
    }
}
