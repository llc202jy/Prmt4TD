public interface PoolListener extends EventListener
{
	/**
	 * Invoked when the PreLoadablePool's state is changed
	 * poolStateUpdate is usually as a result of the pool being started/stopped
	 * or by the pool reaching its capacity or completing its work.
	 * Note that poolStateUpdate events may be issued by arbitary threads
	 *
	 * @param event the generated PoolEvent
	 */
	public void poolStateUpdate(PoolEvent event) ;

	/**
	 * Invoked when a PreLoadablePool has been updated.
	 * Updates are usually generated as a result of removing an item from the pool
	 * or populating the pool with new items.
	 * Note that poolStateUpdate events may be issued by arbitary threads
	 *
	 * @param event the generated PoolEvent
	 */
	public void poolUpdate(PoolEvent event) ;
}
public class PoolState
{
	private final String theStateName ;

	private static ArrayList<PoolState> thePoolStates = new ArrayList<PoolState>() ;

	public static final PoolState CAPACITY_REACHED = new PoolState("Capacity Reached") ;
	public static final PoolState LOAD_LIST_COMPLETED = new PoolState("Load List Completed") ;
	public static final PoolState POOLING = new PoolState("Pooling") ;
	public static final PoolState POOL_STARTED = new PoolState("Started") ;
	public static final PoolState POOL_STOPPED = new PoolState("Stopped") ;

	private PoolState(String stateName)
	{
		this.theStateName = stateName ;
		thePoolStates.add(this) ;
	}

	public String toString()
	{
		return("PoolState: " + this.theStateName) ;
	}

	public String getStateName()
	{
		return(this.theStateName) ;
	}

	public static int getCount()
	{
		return(thePoolStates.size()) ;
	}

	public static final Iterator<PoolState> iterator()
	{
		Collection<PoolState> unmodCollection = Collections.unmodifiableCollection(thePoolStates) ;
		return(unmodCollection.iterator()) ;
	}
}