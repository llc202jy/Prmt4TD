/*
 * $Id: TahitiDaemonClient.java,v 1.2 2001/08/01 03:46:59 kbd4hire Exp $
 * 
 * @(#)TahitiDaemonClient.java 
 *
 * @author     Lary Spector
 * @created    July 22, 2001
 *
 * TahitiDaemonClient is a java application used to communicate with
 * and control a running TahitiDaemon.
 *
 * TahitiDaemon implements a Tahiti service which listens on
 * a configurable control port for commands. 
 */

import java.io.*;
import java.net.*;

public class TahitiDaemonClient {

    private static boolean _verbose = false;
    private static boolean _dont_connect = false;
    private static int _control_port_num = 5545;
    private static String hostname;
    private static boolean _banner_version_OK = false;
    private static int _socket_timeout = 10000; // 10 seconds

    /*
     * Banner and version Strings
     */
    private static String _banner_string = "TahitiDaemon";
    private static String _version_string = "1.0";

    private static String helpMsg = 
        "help                    Display this message. \n" 
        + "quit                    Disconnect from the server and quit. \n"
        + "shutdown                Shutdown the server and quit. \n" 
        + "reboot                  Reboot the server and quit. \n" 
        + "list                    List all aglets in the server. \n" 
        + "msg on|off              Turns message printing on/off, default is off. \n" 
        + "debug on|off            Debug output on/off, default is off. \n" 
        + "create [codeBase] name  Create new aglet. \n" 
        + "<aglet> dispatch URL    Dispatch the aglet to the URL. \n" 
        + "<aglet> clone           Clone the aglet. \n" 
        + "<aglet> dispose         Dispose the aglet. \n" 
        + "<aglet> dialog          Request a dialog to interact with.\n" 
        + "<aglet> property        Display properties of the aglet.\n" 
        + "Note: <aglet> is a left most string listed in the result of list command. ";
    
/*
 * Main method
 * Args: -help -verbose -controlport -host
 */

    public static void main(String[] args) throws IOException {

        String prompt = ">";
        Socket clientSocket = null;
        PrintWriter out = null;
        BufferedReader in = null;

        parseArgs(args);
        
        // bail out if the user only asked for help.
        if (_dont_connect)
            System.exit(1);

        try {
            clientSocket = new Socket(hostname, _control_port_num);
            out = new PrintWriter(clientSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            clientSocket.setSoTimeout(_socket_timeout);
        } catch (UnknownHostException e) {
            System.err.println("\nUnknown host: " + hostname);
            System.exit(1);
        } catch (IOException e) {
            System.err.println("\nCouldn't get I/O for the connection to: " + hostname);
            System.exit(1);
        }

        BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
        String fromServer = "start";
        String fromUser;
        
        Thread.currentThread().setPriority(1);
        
        // Try reading from the Daemon
            try {
                fromServer = in.readLine();
            }
            catch (IOException ex) {
                System.err.println("\nFailure reading from: " + hostname + ":" + _control_port_num);
                if (_verbose) {
                    ex.printStackTrace();
                }
                System.exit(1);
            }
        
        /*
         * Handshake with the Daemon, check banner and version
         */
        try {
        if (fromServer != null) {
            if (_verbose) {
                System.out.println("Server banner: " + fromServer);
            }
            if (fromServer.equals(_banner_string)) {
                if (_verbose) {
                    System.out.println("Banner check OK.");
                }
                if ((fromServer = in.readLine()) != null) {
                    if (_verbose) {
                        System.out.println("Server version: " + fromServer);
                    }
                    if (fromServer.equals(_version_string)) {
                        if (_verbose) {
                            System.out.println("Version check OK.");
                        }
                        _banner_version_OK = true;
                        } else {
                            System.out.println("Version mismatch.");
                            System.out.println("Client version is: " + _version_string);
                            System.out.println("Server version is: " + fromServer);
                        }
                    }            
                } else {
                    System.out.println("Banner check failed.");
                    System.out.println("Client banner is: " + _banner_string);
                    System.out.println("Server banner is: " + fromServer);
                }
                    }
                }            
        catch (IOException ex) {
            System.err.println("\nFailure reading from: " + hostname + ":" + _control_port_num);
            if (_verbose) {
                ex.printStackTrace();
            }
            System.exit(1);
        }
        
        /* 
         * If the banner and version strings are OK,
         * start handling commands.
         */
        if (_banner_version_OK) {
            try {
                // read the connection info
                if ((fromServer = in.readLine()) != null) {
                    // display it if verbose
                if (_verbose) {
                    System.out.println("Server: " + fromServer);
                }
                    } 
            }
            catch (IOException ex) {
                System.err.println("\nFailure reading from: " + hostname + ":" + _control_port_num);
                if (_verbose) {
                    ex.printStackTrace();
                }
                System.exit(1);
            }
            while (true) {
                try {
                    // Display the Prompt
                    System.out.print(prompt + " ");
                    System.out.flush();

                    // Handle client side input
                    fromUser = stdIn.readLine();
                    if (fromUser != null) {
                        if (_verbose)
                            System.out.println("Client: " + fromUser);
                        
                        // Special cases for help and quit
                    if ("help".equalsIgnoreCase(fromUser)) {
                        System.out.println (helpMsg);
                        System.out.flush();
                    }
                    if ("quit".equalsIgnoreCase(fromUser)) {
                        System.out.println ("Closing client connection");
                        System.out.flush();
                        break;
                        }
                        // Send command to server
                        out.println(fromUser);
                    }
                    
                    // Read reply from the server
                    fromServer = in.readLine();
                    // Special cases for shutdown and reboot
                    if (_verbose) {
                        System.out.println("Server: " + fromServer);
                    }
                    if (fromServer.equals("shutting down")) {
                        System.out.println("Server shutting down, closing client connection.");
                        break;
                    } else if (fromServer.equals("rebooting")) {
                        System.out.println("Server rebooting, closing client connection.");
                        break;
                    } else { //handle everything else.
                        System.out.println(fromServer);
                        while (!((fromServer = in.readLine()).equals("done."))) {
                            System.out.println(fromServer);
                        }
                    }
                } 
                catch (IOException ex) {
                    System.err.println("\nFailure reading from: " + hostname + ":" + _control_port_num);
                    if (_verbose) {
                    ex.printStackTrace();
                } 
                    break;
                }
                catch (Throwable ex) {
                    if (_verbose) {
                        ex.printStackTrace();
                    }
                    break;
                } 
            } 
        }
        
        out.close();
        in.close();
        stdIn.close();
        clientSocket.close();
        System.exit(1);
    }

    private static void usage() {
        System.err.println("\nTahitiDaemonClient [-verbose] [-host <hostname>] [-controlport <port>] [-help]\n");
        System.err.println("Connects to a Tahiti Daemon and provides an interface to control it.\n");
        System.err.println("options:");
        System.err.println("    -verbose         verbose output");
        System.err.println("    -host <hostname>, default is localhost");
        System.err.println("    -controlport <port number>, default is port " + _control_port_num);
        System.err.println("    -timeout <timeout>, in milliseconds, 0 (zero) is infinite, default is " + _socket_timeout);
        System.err.println("    -help            prints this message");
        
        // signal that the program
        // should not continue the connection process.
        _dont_connect=true;
    }


    private static void parseArgs(String[] args) {
	
        if (_verbose)
            System.out.println ("Parsing Args...\n");
	if (args.length <= 0)
            return;
        for (int i = 0; i < args.length; i++) {
            if (args[i].equalsIgnoreCase("-help")) {
                usage();
                break;
            }
            else if (args[i].equalsIgnoreCase("-verbose")) {
                _verbose = true;
            } 
            else if (args[i].equalsIgnoreCase("-controlport")) {
                if (i + 1 >= args.length) {
                    usage();
                    break;
                } 
                i++;
                try {
                    _control_port_num = Integer.parseInt(args[i]);
                } catch (NumberFormatException ex) {
                    System.err.println("\nError! controlport <" + args[i] + "> is invalid, it  must be an integer ");
                    _dont_connect=true;
                    break;
                } 
            } 
            else if (args[i].equalsIgnoreCase("-timeout")) {
                if (i + 1 >= args.length) {
                    usage();
                    break;
                } 
                i++;
                try {
                    _socket_timeout = Integer.parseInt(args[i]);
                } catch (NumberFormatException ex) {
                    System.err.println("\nError! timeout <" + args[i] + "> is invalid, it  must be an integer ");
                    _dont_connect=true;
                    break;
                } 
            } 
            else if (args[i].equalsIgnoreCase("-host")) {
                if (i + 1 >= args.length) {
                    System.err.println("\nError! hostname was not specified after -host argument");
                    usage();
                    break;
                } 
                i++;
                hostname = args[i];
            }
            else {
                System.err.println("\nUnknown argument: " + args[i] + "\n");
                usage();
                break;
            }
        } 
    }
}
private transient TextField address;
	private transient AddressBook addressbook = null;

	private Button button = new Button("AddressBook");
	private GridBagLayout layout = new GridBagLayout();
	private ActionListener actionListener;
	private String command = "address";

	/**
	 * Constructs a new AddressChooser with the default number of colums.
	 * The default nubmer is 10.
	 */
	public AddressChooser() {
		this(10);
	}
	/**
	 * Constructs a new AddressChooser with the specified number of colums.
	 * @param columns the number of columns
	 */
	public AddressChooser(int columns) {
		setLayout(layout);
		GridBagConstraints cns = new GridBagConstraints();

		cns.gridwidth = 1;
		cns.fill = GridBagConstraints.NONE;
		addCmp(button, cns);

		addCmp(new Label("Address:"), cns);

		cns.fill = GridBagConstraints.HORIZONTAL;
		cns.gridwidth = GridBagConstraints.REMAINDER;
		cns.weightx = 1.0;
		address = new TextField(columns);
		addCmp(address, cns);

		button.setActionCommand("toggle");

		button.addActionListener(this);
		address.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ev) {
		String cmd = ev.getActionCommand();

		if ("toggle".equals(cmd)) {
			if (addressbook == null) {
				Component c = button.getParent();

				while (c instanceof Frame == false) {
					c = c.getParent();
				} 
				addressbook = new AddressBook((Frame)c, this);

				// to get around a bugs of AWTMotif.
				addressbook.setSize(200, 200);
				addressbook.pack();
			} 
			if (addressbook.isVisible() == false) {
				addressbook.popup(button);
			} else {
				addressbook.setVisible(false);
			} 

			// Open AddressBook
		} else if (address == ev.getSource()) {
			logger.debug("selected = " + address.getText());

			ActionEvent e = new ActionEvent(this, 
											ActionEvent.ACTION_PERFORMED, 
											command);

			processEvent(e);
		} 
	}
	/**
	 * Adds the specified action listener to receive action events
	 * from this chooser.
	 * @param l the action listener
	 */
	public void addActionListener(ActionListener l) {
		actionListener = AWTEventMulticaster.add(actionListener, l);
	}
	private void addCmp(Component c, GridBagConstraints cns) {
		layout.setConstraints(c, cns);
		add(c);
	}
	/* package */
	void addressSelected(String newAddress) {
		address.setText(newAddress);
		processActionEvent(new ActionEvent(this, 
										   ActionEvent.ACTION_PERFORMED, 
										   command));
	}
	/**
	 * Get the address which is currently chosen by this chooser.
	 */
	public String getAddress() {
		return address.getText();
	}
	public boolean handleEvent(Event ev) {
		if (ev.id == Event.LOST_FOCUS && isVisible() == false 
				&& addressbook != null) {
			addressbook.setVisible(false);
		} 
		if (ev.id == Event.GOT_FOCUS || ev.id == Event.LOST_FOCUS 
				|| ev.id == Event.MOUSE_ENTER) {
			if (addressbook != null && addressbook.isVisible()) {
				addressbook.adjust();
				addressbook.toFront();
			} 
			return true;
		} else {
			return super.handleEvent(ev);
		}
	}
	private void processActionEvent(ActionEvent ev) {
		if (actionListener != null) {
			actionListener.actionPerformed(ev);
		} 
	}
	/**
	 * Removes the specified action listener so it no longer receives
	 * action events from this chooser.
	 * @param l the action listener
	 */
	public void removeActionListener(ActionListener l) {
		actionListener = AWTEventMulticaster.remove(actionListener, l);
	}
	synchronized public void removeNotify() {
		if (addressbook != null) {
			addressbook.dispose();
			addressbook = null;
		} 
		super.removeNotify();
	}
	/**
	 * Sets the command name of the action event fired by this chooser.
	 * By default this will be set to the "address".
	 */
	public void setActionCommand(String cmd) {
		command = cmd;
	}
	/**
	 * Set the specified string as to the address book.
	 */
	public void setAddress(String addr) {
		address.setText(addr);
	}
}
import com.ibm.aglet.*;
import com.ibm.aglet.event.*;
import com.ibm.aglet.util.*;
import com.ibm.agletx.util.*;

import java.lang.InterruptedException;
import java.io.Externalizable;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.IOException;
import java.net.*;
import java.awt.*;

import java.util.Enumeration;

/*
 * MyDialog class is the window to be opened when the dialog required.
 * This is NOT a subclass of Dialog.
 */
class MyDialog extends Frame {

	/*
	 * The aglet a user interacts with.
	 */
	private OpenURL aglet = null;

	/*
	 * UI Components
	 */
	private AddressChooser dest = new AddressChooser();
	private TextField msg = new TextField(15);
	private Button go = new Button("GO!");
	private Button open = new Button("Open!");
	private Button close = new Button("CLOSE");

	/*
	 * Constructs the dialog window
	 * @param aglet The aglet the user interacts with.
	 */
	MyDialog(OpenURL aglet) {
		this.aglet = aglet;
		layoutComponents();
	}
	/**
	 * Handles the action
	 * @param ev the event to be handled
	 * @param arg the extra argument
	 */
	public boolean action(Event ev, Object obj) {
		if (ev.target == open) {
			try {
				aglet.getAgletContext().showDocument(new URL(msg.getText()));
			} catch (IOException ex) {
				ex.printStackTrace();
			} 
		} 
		if (ev.target == go) {
			aglet.url = msg.getText();
			aglet.goDestination(dest.getAddress());
		} else if (ev.target == close) {
			setVisible(false);
		} else {
			return false;
		} 
		return true;
	}
	/**
	 * Handles the events
	 * @param ev the event to be handled
	 */
	public boolean handleEvent(Event ev) {
		if (ev.id == Event.WINDOW_DESTROY) {
			setVisible(false);
			return true;
		} 
		return super.handleEvent(ev);
	}
	/*
	 * Layouts all components
	 */
	private void layoutComponents() {
		msg.setText(aglet.url);

		// Layouts components
		GridBagLayout grid = new GridBagLayout();
		GridBagConstraints cns = new GridBagConstraints();

		setLayout(grid);

		cns.weightx = 0.5;
		cns.ipadx = cns.ipady = 5;
		cns.fill = GridBagConstraints.HORIZONTAL;
		cns.insets = new Insets(5, 5, 5, 5);

		cns.weightx = 1.0;
		cns.gridwidth = GridBagConstraints.REMAINDER;
		grid.setConstraints(dest, cns);
		add(dest);

		cns.gridwidth = GridBagConstraints.REMAINDER;
		cns.fill = GridBagConstraints.BOTH;
		cns.weightx = 1.0;
		cns.weighty = 1.0;
		cns.gridheight = 2;
		grid.setConstraints(msg, cns);
		add(msg);

		cns.weighty = 0.0;
		cns.fill = GridBagConstraints.NONE;
		cns.gridheight = 1;

		Panel p = new Panel();

		grid.setConstraints(p, cns);
		add(p);
		p.setLayout(new FlowLayout());
		p.add(go);
		p.add(open);
		p.add(close);
	}
}
import com.ibm.aglet.*;
import com.ibm.aglet.event.*;
import com.ibm.aglet.util.*;
import com.ibm.agletx.util.*;

import java.lang.InterruptedException;
import java.io.Externalizable;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.IOException;
import java.net.*;
import java.awt.*;

import java.util.Enumeration;

/**
 * <tt> OpenURL </tt> is an mobile aglet that goes to a remote host
 * to open the docuemnt specified by URL.
 * 
 * @version     1.00	$Date: 2002/03/16 00:42:07 $
 * @author	Mitsuru Oshima
 */
public class OpenURL extends Aglet {

	/*
	 * UI to interact with a User
	 * this will be automatically disposed when the aglet is disposed
	 */
	transient Frame my_dialog = null;

	/*
	 * 
	 */
	String url = "http://w3.trl.ibm.com";

	/*
	 * 
	 */
	String home = null;

	/*
	 * Itinerary
	 */
	SimpleItinerary itinerary = null;

	/*
	 * 
	 */
	public void atHome(Message msg) {
		setText("I'm back.");
		waitMessage(2 * 1000);
		dispose();
	}
	/**
	 * Creates the dialog window. This has the reference to the instance
	 * of the Dialog to avoid opening multiple dialog windows.
	 */
	public void dialog(Message msg) {
		if (my_dialog == null) {
			my_dialog = new MyDialog(this);
			my_dialog.pack();
			my_dialog.setSize(my_dialog.getPreferredSize());
		} 
		my_dialog.show();
	}
	public void go(Message msg) {
		try {
			itinerary = new SimpleItinerary(this);
			itinerary.go((String)msg.getArg("destination"), 
						 new Message("openURL", msg.getArg("url")));
		} catch (Exception ex) {
			ex.printStackTrace();
			dispose();
		} 
	}
	/**
	 * Dispatch the aglet to the destination.
	 * @param destination a url which specifies the destination
	 * @exception when the aglet is in the invalid state
	 */
	public synchronized void goDestination(String dest) {
		try {
			AgletProxy p = (AgletProxy)clone();
			Message m = new Message("go");

			m.setArg("url", url);
			m.setArg("destination", dest);
			p.sendMessage(m);
		} catch (Exception ex) {
			ex.printStackTrace();
		} 
	}
	/*
	 * Handles the message
	 * @param msg the message sent
	 */
	public boolean handleMessage(Message msg) {
		if (msg.sameKind("go")) {
			go(msg);
		} 
		if (msg.sameKind("atHome")) {
			atHome(msg);
		} else if (msg.sameKind("openURL")) {
			openURL(msg);
		} else if (msg.sameKind("dialog")) {
			dialog(msg);
		} else {
			return false;
		} 
		return true;
	}
	/*
	 * Initializes the aglet. Only called the very first time this
	 * aglet is created.
	 */
	public void onCreation(Object init) {
		dialog(null);
		home = getAgletContext().getHostingURL().toString();
	}
	/*
	 * open URL
	 */
	public void openURL(Message msg) {
		try {
			getAgletContext().showDocument(new URL(url));
			itinerary.go(home, "atHome");
		} catch (Exception ex) {
			ex.printStackTrace();
		} 
	}
}
import com.ibm.aglet.*;
import com.ibm.aglet.event.*;
import com.ibm.aglet.util.*;

import com.ibm.agletx.util.SimpleItinerary;

import java.lang.InterruptedException;
import java.io.Externalizable;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.IOException;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Enumeration;

/**
 * <tt> HelloAglet </tt> is a mobile aglet that goes to a remote host
 * to say "Hello World" and then returns home and dies.
 * <p>1. Shows a dialog box to specify the destination server.
 * invoke handleMessage() methods.
 * <p>2. (Execution of "startTrip" message) Moves to the destination server
 * and send "sayHello" message.
 * to itself.
 * <p>3. (Execution of "sayHello" message) Display a string for 5 secs
 * and go back to the origin. Send "atHome" message to itself.
 * <p>4. (Execution of "atHome" message) Display a string "I'm back"
 * for 2 secs and destroy itself.
 * 
 * @version     1.00    $Date: 2002/03/16 00:42:04 $
 * @author      Danny B. Lange
 * @author      Mitsuru Oshima
 */
public class HelloAglet extends Aglet {

	/*
	 * UI to interact with a user
	 * this will be automatically disposed when the aglet is disposed
	 */
	transient Frame my_dialog = null;		// not serialized

	/*
	 * message
	 */
	String message = null;

	/*
	 * home address represented as a string
	 */
	String home = null;

	/*
	 * Itinerary
	 */
	SimpleItinerary itinerary = null;

	/*
	 * Reports arrival home and disappears
	 */
	public void atHome(Message msg) {
		setText("I'm back.");		// greetings
		waitMessage(2 * 1000);		// show message, 2 seconds
		dispose();					// dispose it self
	}
	protected void createGUI() {
		my_dialog = new MyDialog(this);

		my_dialog.pack();
		my_dialog.setSize(my_dialog.getPreferredSize());
		my_dialog.setVisible(true);
	}
	/**
	 * Creates and shows the dialog window.
	 * This aglet keeps the reference to the instance
	 * of the Dialog to avoid opening multiple dialog windows.
	 */
	public void dialog(Message msg) {

		// check and create a dialog box
		if (my_dialog == null) {
			my_dialog = new MyDialog(this);
			my_dialog.pack();
			my_dialog.setSize(my_dialog.getPreferredSize());
		} 

		// show the dialog box
		my_dialog.setVisible(true);
	}
	/*
	 * Handles the message
	 * @param msg the message sent
	 */
	public boolean handleMessage(Message msg) {
		if (msg.sameKind("atHome")) {
			atHome(msg);
		} else if (msg.sameKind("startTrip")) {
			startTrip(msg);
		} else if (msg.sameKind("sayHello")) {
			sayHello(msg);
		} else if (msg.sameKind("dialog")) {
			dialog(msg);
		} else {
			return false;
		} 
		return true;
	}
	/*
	 * Initializes the aglet.
	 * Only called the very first time this aglet is created.
	 */
	public void onCreation(Object init) {
		setMessage("Hello World!");		// default message

		// Create GUI to control this Aglet
		createGUI();
		itinerary = new SimpleItinerary(this);

		// Initialize the variable.
		home = getAgletContext().getHostingURL().toString();
	}
	/*
	 * Say hello!
	 */
	public void sayHello(Message msg) {
		setText(message);			// greetings
		waitMessage(5 * 1000);		// show message, 5 seconds

		// try back home
		try {
			setText("I'll go back to.. " + home);
			waitMessage(1000);		// 1 second

			// Go back home and Send "atHome" message to owner this
			itinerary.go(home, "atHome");
		} catch (Exception ex) {
			ex.printStackTrace();
		} 
	}
	/*
	 * Set the message
	 * @param message the message to send
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * Strats the trip of this aglet to the destination.
	 */
	public synchronized void startTrip(Message msg) {

		// get the address for trip
		String destination = (String)msg.getArg();

		// Go to the destination and Send "sayHello" message to owner(this)
		try {
			itinerary.go(destination, "sayHello");
		} catch (Exception ex) {
			ex.printStackTrace();
		} 
	}
}
import com.ibm.aglet.*;
import com.ibm.aglet.event.*;
import com.ibm.aglet.util.*;

import com.ibm.agletx.util.SimpleItinerary;

import java.lang.InterruptedException;
import java.io.Externalizable;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.IOException;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Enumeration;

/*
 * MyDialog class is the window to be opened when the dialog required.
 * This is NOT a subclass of Dialog.
 */
class MyDialog extends Frame implements WindowListener, ActionListener {

	/*
	 * The aglet a user interacts with.
	 */
	private HelloAglet aglet = null;

	/*
	 * UI Components
	 */
	private AddressChooser dest = new AddressChooser();
	private TextField msg = new TextField(18);
	private Button go = new Button("GO!");
	private Button send = new Button("Send CLONE!");
	private Button close = new Button("CLOSE");

	/*
	 * Constructs the dialog window
	 * @param aglet The aglet the user interacts with.
	 */
	MyDialog(HelloAglet aglet) {
		this.aglet = aglet;
		layoutComponents();

		addWindowListener(this);
		go.addActionListener(this);
		send.addActionListener(this);
		close.addActionListener(this);
	}
	/**
	 * Handles the action event
	 * @param ae the event to be handled
	 */
	public void actionPerformed(ActionEvent ae) {

		// execute "GO!" command
		if ("GO!".equals(ae.getActionCommand())) {
			aglet.setMessage(msg.getText());
			try {
				AgletProxy p = aglet.getProxy();

				p.sendOnewayMessage(new Message("startTrip", 
												dest.getAddress()));
			} catch (Exception e) {
				e.printStackTrace();
			} 
		} 

		// execute "Send CLONE!" command
		else if ("Send CLONE!".equals(ae.getActionCommand())) {
			aglet.message = msg.getText();
			try {
				AgletProxy p = (AgletProxy)aglet.clone();

				p.sendOnewayMessage(new Message("startTrip", 
												dest.getAddress()));
			} catch (Exception e) {
				e.printStackTrace();
			} 
		} 

		// execute "CLOSE" command
		else if ("CLOSE".equals(ae.getActionCommand())) {
			setVisible(false);
		} 
	}
	/*
	 * Layouts all components
	 */
	private void layoutComponents() {
		msg.setText(aglet.message);

		// Layouts components
		GridBagLayout grid = new GridBagLayout();
		GridBagConstraints cns = new GridBagConstraints();

		setLayout(grid);

		cns.weightx = 0.5;
		cns.ipadx = cns.ipady = 5;
		cns.fill = GridBagConstraints.HORIZONTAL;
		cns.insets = new Insets(5, 5, 5, 5);

		cns.weightx = 1.0;
		cns.gridwidth = GridBagConstraints.REMAINDER;
		grid.setConstraints(dest, cns);
		add(dest);

		cns.gridwidth = GridBagConstraints.REMAINDER;
		cns.fill = GridBagConstraints.BOTH;
		cns.weightx = 1.0;
		cns.weighty = 1.0;
		cns.gridheight = 2;
		grid.setConstraints(msg, cns);
		add(msg);

		cns.weighty = 0.0;
		cns.fill = GridBagConstraints.NONE;
		cns.gridheight = 1;

		Panel p = new Panel();

		grid.setConstraints(p, cns);
		add(p);
		p.setLayout(new FlowLayout());
		p.add(go);
		p.add(send);
		p.add(close);
	}
	public void windowActivated(WindowEvent we) {}
	public void windowClosed(WindowEvent we) {}
	/**
	 * Handles the window event
	 * @param we the event to be handled
	 */

	public void windowClosing(WindowEvent we) {
		dispose();
	}
	public void windowDeactivated(WindowEvent we) {}
	public void windowDeiconified(WindowEvent we) {}
	public void windowIconified(WindowEvent we) {}
	public void windowOpened(WindowEvent we) {}
}

package org.aglets.log.console;

import org.aglets.log.LogCategory;

/**
 * Logging object that writes all messages to stdout.
 *
 * @version    $Revision: 1.1.1.1 $ $Date: 2002/03/16 00:42:02 $ $Author: kbd4hire $
 * @since
 * @author     Robert Bergstrom
 * @created    July 16, 2001
 */
public class ConsoleCategory implements LogCategory {
    
    private String m_name = null;

    /**
     *  Check whether this category is enabled for the <code>DEBUG</code>
     *  priority. <p>
     *
     *  This function is intended to lessen the computational cost of disabled
     *  log debug statements. <p>
     *
     *  For some <code>cat</code> Category object, when you write, <pre>
     *
     *  cat.debug("This is entry number: " + i );</pre> <p>
     *
     *  You incur the cost constructing the message, concatenatiion in this
     *  case, regardless of whether the message is logged or not. <p>
     *
     *  If you are worried about speed, then you should write <pre>
     *
     *  if(cat.isDebugEnabled()) { cat.debug("This is entry number: " + i ); }
     *  </pre><p>
     *
     *  This way you will not incur the cost of parameter construction if
     *  debugging is disabled for <code>cat</code> . On the other hand, if the
     *  <code>cat</code> is debug enabled, you will incur the cost of evaluating
     *  whether the category is debug enabled twice. Once in <code>
     *  isDebugEnabled</code> and once in the <code>debug</code> . This is an
     *  insignificant overhead since evaluating a category takes about 1%% of
     *  the time it takes to actually log.
     *
     * @return    boolean - <code>true</code> if this category is debug enabled,
     *      <code>false</code> otherwise.
     * @since
     */
    public boolean isDebugEnabled() {
        return true;
    }


    /**
     *  Logs a message at fatal priority.
     *
     * @param  msg  Message to be logged.
     * @since       1.0
     */
    public void fatal(Object msg) {
        System.out.println(msg.toString());
    }


    /**
     *  Logs a message at error priority.
     *
     * @param  msg  Message to be logged.
     * @since       1.0
     */
    public void error(Object msg) {
        System.out.println(msg.toString());
    }


    /**
     *  Logs a message at error priority and passes an exception for logging.
     *
     * @param  msg  Message to be logged.
     * @param  exc  Description of Parameter
     * @since       1.0
     */
    public void error(Object msg, Exception exc) {
        System.out.println(msg.toString() + "\n");
        exc.printStackTrace();
    }


    /**
     *  Logs a message at warn priority.
     *
     * @param  msg  Message to be logged.
     * @since       1.0
     */
    public void warn(Object msg) {
        System.out.println(msg.toString());
    }


    /**
     *  Logs a mesasge at info priority.
     *
     * @param  msg  Message to be logged.
     * @since       1.0
     */
    public void info(Object msg) {
        System.out.println(msg.toString());
    }


    /**
     *  Logs a message at debug priority.
     *
     * @param  msg  Message to be logged.
     * @since       1.0
     */
    public void debug(Object msg) {
        System.out.println(msg.toString());
    }

    /**
     * Constructor
     * @param name Name of category used as a prefix to the log messages.
     */
    public ConsoleCategory( String name ) {
        m_name = name;
    }
}

package org.aglets.log.quiet;

import org.aglets.log.LogCategory;

/**
 *  Logging category that does absolutely nothing.  This will
 * probably be the default setup.
 *
 * @version    $Revision: 1.1.1.1 $ $Date: 2002/03/16 00:42:02 $ $Author: kbd4hire $
 * @since
 * @author     Robert Bergstrom
 * @created    July 16, 2001
 */
public class QuietCategory implements LogCategory {

    /**
     *  Check whether this category is enabled for the <code>DEBUG</code>
     *  priority. <p>
     * This version always returns true.
     */
    public boolean isDebugEnabled() {
        return true;
    }


    /**
     *  Logs a message at fatal priority.
     *
     * @param  msg  Message to be logged.
     * @since       1.0
     */
    public void fatal(Object msg) {
        
    }


    /**
     *  Logs a message at error priority.
     *
     * @param  msg  Message to be logged.
     * @since       1.0
     */
    public void error(Object msg) {
        
    }


    /**
     *  Logs a message at error priority and passes an exception for logging.
     *
     * @param  msg  Message to be logged.
     * @param  exc  Description of Parameter
     * @since       1.0
     */
    public void error(Object msg, Exception exc) {
        
    }


    /**
     *  Logs a message at warn priority.
     *
     * @param  msg  Message to be logged.
     * @since       1.0
     */
    public void warn(Object msg) {
        
    }


    /**
     *  Logs a mesasge at info priority.
     *
     * @param  msg  Message to be logged.
     * @since       1.0
     */
    public void info(Object msg) {
        
    }


    /**
     *  Logs a message at debug priority.
     *
     * @param  msg  Message to be logged.
     * @since       1.0
     */
    public void debug(Object msg) {
        
    }

    /**
     * Constructor
     * @param name Name of category used as a prefix to the log messages.
     */
    public QuietCategory( String name ) {
        
    }
}

package examples.simplemasterslave;

/*
 * @(#)CommandWindow.java
 * 
 * 03L7246 (c) Copyright IBM Corp. 1996, 1998
 * 
 * The program is provided "as is" without any warranty express or
 * implied, including the warranty of non-infringement and the implied
 * warranties of merchantibility and fitness for a particular purpose.
 * IBM will not be liable for any damages suffered by you as a result
 * of using the Program. In no event will IBM be liable for any
 * special, indirect or consequential damages or lost profits even if
 * IBM has been advised of the possibility of their occurrence. IBM
 * will not be liable for any third party claims against you.
 */

import com.ibm.aglet.*;
import com.ibm.aglet.event.*;
import com.ibm.aglet.util.*;

import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;
import java.util.*;

class CommandWindow extends Frame implements ActionListener {
	AgletProxy ap = null;
	AddressChooser ac = null;
	java.awt.List list = null;
	Button addbutton = null, removebutton = null, gobutton = null;

	CommandWindow(AgletProxy ap) {
		super("Simple Master_Slave Pattern Sample");
		this.ap = ap;
		setUp();
	}
	// handle action event
	public void actionPerformed(ActionEvent ae) {
		try {
			if ("go".equals(ae.getActionCommand())) {
				ap.sendMessage(new Message("go"));
			} else if ("add".equals(ae.getActionCommand())) {
				ap.sendMessage(new Message("add", new URL(ac.getAddress())));
				update();
			} else if ("remove".equals(ae.getActionCommand())) {
				int i = list.getSelectedIndex();

				if (i >= 0) {
					ap.sendMessage(new Message("remove", i));
					list.remove(i);
				} 
			} 
		} catch (Exception e) {
			System.out.println("Error:" + e.getMessage());
		} 
	}
	public void setUp() {

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				setVisible(false);
			} 
		});

		GridBagLayout gridbag = new GridBagLayout();
		GridBagConstraints c = new GridBagConstraints();

		setLayout(gridbag);
		c.fill = GridBagConstraints.BOTH;

		ac = new AddressChooser(15);
		c.weightx = 1.0;
		gridbag.setConstraints(ac, c);
		add(ac);

		addbutton = new Button("add");
		addbutton.addActionListener(this);

		removebutton = new Button("remove");
		removebutton.addActionListener(this);

		gobutton = new Button("go");
		gobutton.addActionListener(this);

		Panel bp = new Panel(new GridLayout(1, 3));

		bp.add(addbutton);
		bp.add(removebutton);
		bp.add(gobutton);

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.weightx = 0.0;
		gridbag.setConstraints(bp, c);
		add(bp);

		list = new java.awt.List(10, false);
		c.weighty = 1.0;
		gridbag.setConstraints(list, c);
		add(list);

		setSize(500, 200);
	}
	private void update() {
		list.removeAll();
		try {
			Vector addrs = (Vector)ap.sendMessage(new Message("getlist"));
			int size = addrs.size();

			for (int i = 0; i < size; i++) {
				list.add((addrs.elementAt(i)).toString());
			}
		} catch (Exception e) {
			System.out.println("Error:" + e.getMessage());
		} 
	}
}
ackage examples.mdispatcher;

/*
 * @(#)HelloAglet.java
 * 
 * 03L7246 (c) Copyright IBM Corp. 1996, 1998
 * 
 * The program is provided "as is" without any warranty express or
 * implied, including the warranty of non-infringement and the implied
 * warranties of merchantibility and fitness for a particular purpose.
 * IBM will not be liable for any damages suffered by you as a result
 * of using the Program. In no event will IBM be liable for any
 * special, indirect or consequential damages or lost profits even if
 * IBM has been advised of the possibility of their occurrence. IBM
 * will not be liable for any third party claims against you.
 */

import com.ibm.aglet.*;
import com.ibm.aglet.event.*;
import com.ibm.aglet.util.*;

import com.ibm.agletx.util.SimpleItinerary;

import java.lang.InterruptedException;
import java.io.Externalizable;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.IOException;
import java.net.*;
import java.awt.*;
import java.util.Enumeration;
import java.awt.event.*;

/**
 * <tt> HelloAglet </tt> is a revised version of examples.hello.HelloAglet,
 * which uses MethodDispatcher class to handle incoming messages.
 * 
 * @version     1.00	$Date: 2002/03/16 00:42:06 $
 * @author	Danny B. Lange
 * @author	Mitsuru Oshima
 * @see examples.hello.HelloAglet
 * @see examples.examples.MethodDispatcher
 */
public class HelloAglet extends Aglet {

	/*
	 * UI to interact with a User
	 * this will be automatically disposed when the aglet is disposed
	 */
	transient Frame my_dialog = null;

	/*
	 * Default message
	 */
	String message = "Hello World!";

	/*
	 * 
	 */
	String home = null;

	/*
	 * Itinerary
	 */
	SimpleItinerary itinerary = null;

	/*
	 * MethodDispatcher
	 */
	MethodDispatcher mdispatcher = null;

	/*
	 * 
	 */
	public void atHome(Message msg) {
		setText("I'm back.");
		waitMessage(2 * 1000);
		dispose();
	}
	/**
	 * Creates the dialog window. This has the reference to the instance
	 * of the Dialog to avoid opening multiple dialog windows.
	 */
	public void dialog(Message msg) {
		if (my_dialog == null) {
			my_dialog = new MyDialog(this);
			my_dialog.pack();
			my_dialog.setSize(my_dialog.getPreferredSize());
		} 
		my_dialog.show();
	}
	/*
	 * Go to the destination and say hello!
	 */
	public void go(Message msg) {
		URL dest = (URL)msg.getArg();

		try {
			itinerary.go(dest.toString(), "sayHello");
		} catch (Exception ex) {
			ex.printStackTrace();
		} 
	}
	/**
	 * Dispatch the aglet to the destination.
	 * @param destination a url which specifies the destination
	 * @exception when the aglet is in the invalid state
	 */
	public synchronized void goDestination(String destination) {
		try {
			itinerary.go(destination, "sayHello");
		} catch (Exception ex) {
			ex.printStackTrace();
		} 
	}
	/*
	 * Handles the message
	 * @param msg the message sent
	 */
	public boolean handleMessage(Message msg) {
		return mdispatcher.handleMessage(msg);
	}
	/*
	 * Initializes the aglet. Only called the very first time this
	 * aglet is created.
	 */
	public void onCreation(Object init) {
		itinerary = new SimpleItinerary(this);
		mdispatcher = new MethodDispatcher(this);

		// Remember the URL as a string.
		home = getAgletContext().getHostingURL().toString();
	}
	/*
	 * Say hello!
	 */
	public void sayHello(Message msg) {

		// greetings
		setText(message);

		waitMessage(5 * 1000);

		try {
			setText("I'll go back to.. " + home);
			waitMessage(1000);
			itinerary.go(home, "atHome");
		} catch (Exception ex) {
			ex.printStackTrace();
		} 
	}
}
import com.ibm.aglet.*;
import com.ibm.awb.misc.Encoding;
import java.io.*;
import java.net.URL;
import java.util.Enumeration;

/**
 * WebServerAglet is an aglet which behaves like WebServer.
 * Please enable the HTTP messaging feature in the configuration panel
 * Options -> Network Cofiguration -> Others.
 * If the aglet is successfully created, please try
 * <pre>
 * http://aglet.server:434/aglets/default/test/index.html
 * </pre>
 * in your web browser. The port number have to be same number on which
 * the aglet server is running. (434 by default)
 * 
 * @version     1.00	$Date: 2002/03/16 00:42:05 $
 * @author	Mitsuru Oshima
 */
public class WebServerAglet extends Aglet {
	static private final Encoding ENCODING = Encoding.getDefault();
	static private final String ENCODING_JAVA = ENCODING.getJavaEncoding();
	static private final String CHARSET_PAGE = ENCODING.getHTMLCharset();
	static private String META_TAG = null;
	static {
		META_TAG = "<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html;";
		if (CHARSET_PAGE != null) {
			META_TAG += " charset=" + CHARSET_PAGE;
		} 
		META_TAG += "\">";
	} 

	String indexPage = null;

	// 
	// If it's http request.
	// 
	boolean handleHttpRequest(Message m, PrintWriter p) {
		System.out.println(m);
		if (m.sameKind("index.html") || m.sameKind("")) {
			p.println(indexPage);
			p.flush();
		} else if (m.sameKind("next.html")) {
			p.println("<HTML>");
			p.println("<HEAD>");
			p.println(META_TAG);
			p.println("<TITLE>");
			p.println("NEXT");
			p.println("</TITLE>");
			p.println("</HEAD>");
			p.println("<BODY>");
			p.println("<H1> Here is a list of proxies in <TT>" 
					  + getAgletContext().getHostingURL() + "</TT></H1>");
			Enumeration e = getAgletContext().getAgletProxies(ACTIVE 
					| INACTIVE);

			p.println("<PRE>");
			while (e.hasMoreElements()) {
				AgletProxy proxy = (AgletProxy)e.nextElement();

				try {
					p.println(proxy.getAgletInfo().toString());
				} catch (Exception ex) {
					ex.printStackTrace(p);
				} 
			} 
			p.println("</PRE>");
			p.println("</BODY>");
			p.println("</HTML>");
			p.flush();
			m.sendReply("text/html");
		} else if (m.sameKind("go")) {
			System.out.println((String)m.getArg("location"));
			String l = (String)m.getArg("location");

			if (l.startsWith("atp:")) {
				l = l.substring(4);
				if (l.indexOf(':') < 0) {
					p.println("<HTML>");
					p.println("<HEAD>");
					p.println(META_TAG);
					p.println("<TITLE>");
					p.println("ILLEGAL INPUT");
					p.println("</TITLE>");
					p.println("</HEAD>");
					p.println("<BODY>");
					p.println("<H1>");
					p.println("Please specify port number. default = 434");
					p.println("</H1>");
					p.println("</BODY>");
					p.println("</HTML>");
					p.flush();
					m.sendReply("text/html");
					return true;
				} 
			} 

			try {
				p.println("<HTML>");
				p.println("<HEAD>");
				p.println(META_TAG);
				p.println("<TITLE>");
				p.println("MOVING TO");
				p.println("</TITLE>");
				p.println("</HEAD>");
				p.println("<BODY>");
				p.println("<H1> Moving to...! </H1>");
				String contextName = getAgletContext().getName();

				if (contextName.equals("")) {
					contextName = "default";
				} 

				p.println("<a href= \"http:" + l + "/aglets/" + contextName 
						  + "/" + getAgletID() 
						  + "/index.html\" TARGET=_top> atp:" + l + " </a>");
				p.println("Click above link to trace me! <BR>");
				p.println("</BODY>");
				p.println("</HTML>");
				p.flush();
				m.sendReply("text/html");

				dispatch(new java.net.URL("atp:" + l));

			} catch (IOException ex) {
				ex.printStackTrace();
			} catch (RequestRefusedException ex) {
				ex.printStackTrace();
			} 
		} else {
			return false;
		}
		return true;
	}
	public boolean handleMessage(Message m) {

		// 
		// This is just a temporary solution.
		// 
		Object o = m.getArg("cgi-response");
		PrintStream p = null;

		if (o != null && o instanceof OutputStream) {
			OutputStream os = (OutputStream)o;
			OutputStreamWriter osw = null;

			try {
				osw = new OutputStreamWriter(os, ENCODING_JAVA);
			} catch (UnsupportedEncodingException excpt) {
				osw = new OutputStreamWriter(os);
			} 
			PrintWriter pw = new PrintWriter(osw);

			return handleHttpRequest(m, pw);
		} 
		return true;
