public class SimPlacementTask extends SimTask {

   public SimPlacementTask(SimClient _client, RsPlacementRequest _request){
      super();
      client     = _client;
      request    = _request;
      originator = client.connection;
   }

   public void process() {

      RsObject     [] objectArray;
      RsObject     o;
      RsPlacement  test;
      RsPlacement  placement=null;
      objectArray = client.session.getPlan().getObjectArray();
      if(objectArray!=null){
         for(int iObject = 0; iObject<objectArray.length; iObject++){
            o = (RsObject)objectArray[iObject];
            if(o instanceof RsPlacement){
               test = (RsPlacement)o;
               if(request.name==null || request.name.equals(test.getName())){
                   // it's a match
                   placement=test;
                   break;
               }
            }
         }
      }


      // TO DO:  test for collision with walls, other bodies

      if(placement!=null){
         client.body.setPlacement(true);
         client.body.motion = new RsMotionNull(startTime, placement.orientation, placement.x, placement.y);
         client.session.placeClient(client);

         // since the placement entails a movement of the simulacrum,
         // we need to reprocess the sensors.   later on, AFTER we send
         // the placement event, we will send sensor events for ALL sensors
         // whether they experienced a state change or not.   This provides
         // a way for the client to "calibrate" itself to an initial condition
         // after the placement.    It is not unreasonable because a placement
         // is a highly artificial event that doesn't reflect something we
         // expect to happen to the robot in real life.

         client.body.processSensors(startTime, client.session.getPlan(), client.body.motion.transform);


         // The RsBodyContact sensors get special treatment because, at this point
         // in the simulators development, they don't implement a
         // computeAndSetState method (which would be invoked by processSensors above)
         RsBodyPart        [] bodyPart = client.body.getBodyPartArray();
         RsBodyContactSensor  contact;
         RsSensorEvent        sEvent;

         for(int j=0; j<bodyPart.length; j++){
            if(bodyPart[j] instanceof RsBodyContactSensor){
               contact = (RsBodyContactSensor)bodyPart[j];
               if(contact.getHot()){
                  contact.setHot(false);
                  // this is a state change, issue the event
                  sEvent = contact.getSensorEvent(startTime);
                  client.handlerRegistry.processTransaction(sEvent);
               }
            }