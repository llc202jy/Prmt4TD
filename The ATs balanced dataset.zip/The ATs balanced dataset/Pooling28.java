public abstract class ConcurrentQueryWithThreadPooling extends ConcurrentQuery {
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
mport org.apache.log4j.Logger;
ublic interface ConcurrentQueryInterface {
public abstract class ConcurrentQueryWithThreadPooling extends ConcurrentQuery {private static Logger logger = Logger.getLogger(ConcurrentQueryWithThreadPooling.class);private ExecutorService executor;protected ConcurrentQueryWithThreadPooling() {}public ConcurrentQueryWithThreadPooling(int maxConcurrent, String jdbcURL, String jdbcUser, String jdbcPasswd) throws SQLException {super(maxConcurrent, jdbcURL, jdbcUser, jdbcPasswd);executor = Executors.newFixedThreadPool(getMaxConcurrentQueries());}public void shutdown() {executor.shutdown();try {executor.awaitTermination(0, TimeUnit.MILLISECONDS);} catch (InterruptedException e) {}}}class QueryRunnerThreadPoolAsRunnable implements Runnable, QueryRunnerInterface {

    private static Logger logger = Logger.getLogger(QueryRunnerThreadPoolAsRunnable.class);

    private String query = null;
    private Connection connection = null;
    private ResultSet resultSet = null;
    private Future<?> future = null;
    private SQLException sqlException = null;

    public QueryRunnerThreadPoolAsRunnable(Connection connection, String query, ExecutorService executor) {
        super();
        this.connection = connection;
        this.query = query;
        future = executor.submit(this);
    }

    public void run() {

        Statement statement = null;

        try {
            statement = connection.createStatement();
            if (statement.execute(query)) {
                resultSet = statement.getResultSet();
                connection.close();
            }
        } catch (SQLException e) {
            sqlException = e;
        }
        logger.debug("net.sourceforge.concurrentQuery.query (" + query + ") is done!");

    }
    public boolean isRunning() {
        return !future.isDone();
    }

    public String getQuery() {
        return query;
    }

    public ResultSet getResultSet() {
        return resultSet;
    }

    public Connection getConnection() {
        return connection;
    }

    public SQLException getSQLException() {
        return sqlException;
    }

}
	public static enum ConcurrentQueryType {
		REGULAR_THREADING,
		RUNNABLE_THREADPOOL,
		CALLABLE_THREADPOOL;
		
		public static ConcurrentQueryType fromInt(int i) {
			ConcurrentQueryType returnValue = null;
			switch (i) {
			case 1:
				returnValue = ConcurrentQueryType.REGULAR_THREADING;
				break;
			case 2:
				returnValue = ConcurrentQueryType.RUNNABLE_THREADPOOL;
				break;
			case 3:
				returnValue = ConcurrentQueryType.CALLABLE_THREADPOOL;
				break;
			default:
				returnValue = ConcurrentQueryType.REGULAR_THREADING;
				break;
			}
			return returnValue;
		}
	}
public class ConcurrentQueryWithCallableThreadPooling extends ConcurrentQueryWithThreadPooling {

    private static Logger logger = Logger.getLogger(ConcurrentQueryWithThreadPooling.class);
    
    private ExecutorService executor;

    private ConcurrentQueryWithCallableThreadPooling() {}

    public ConcurrentQueryWithCallableThreadPooling(int maxConcurrent, String jdbcURL, String jdbcUser, String jdbcPasswd) throws SQLException {

        super(maxConcurrent, jdbcURL, jdbcUser, jdbcPasswd);
        executor = Executors.newFixedThreadPool(getMaxConcurrentQueries());
    }


    public void shutdown() {
        executor.shutdown();
        try {
            executor.awaitTermination(0, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {

        }
    }

    public QueryRunnerInterface newQueryRunner(Connection connection, String query) {
        //return new QueryRunnerThreadPoolAsRunnable(connection, query, executor);
        return new QueryRunnerThreadPoolAsCallable(connection, query, executor);

    }
        try {
            executor.awaitTermination(0, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {

        }
    }



}