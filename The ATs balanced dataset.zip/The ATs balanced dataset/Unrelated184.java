#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

#include <common.h>
#include <radsql.h>

#include <libpq-fe.h>

static int rad_postgres_reconnect(int type, struct sql_connection *conn);
static void rad_postgres_disconnect(struct sql_connection *conn, int drop);

/* ************************************************************************* */
/* Interface routines */
static int
rad_postgres_reconnect(int type, struct sql_connection *conn)
{
        PGconn  *pgconn;
        char *dbname;
        char portbuf[16];
        char *portstr;
        
        switch (type) {
        case SQL_AUTH:
                dbname = conn->cfg->auth_db;
                break;
        case SQL_ACCT:
                dbname = conn->cfg->acct_db;
                break;
        }

        if (conn->cfg->port == 0)
                portstr = NULL;
        else {
                portstr = portbuf;
                snprintf(portbuf, sizeof(portbuf), "%d", conn->cfg->port);
        }
                
        pgconn = PQsetdbLogin(conn->cfg->server, portstr, NULL, NULL,
                              dbname,
                              conn->cfg->login, conn->cfg->password);
        
        if (PQstatus(pgconn) == CONNECTION_BAD) {
                grad_log(L_ERR,
                         _("PQconnectStart failed: %s"), 
                         PQerrorMessage(pgconn));
                PQfinish(pgconn);
                return -1;
        }

        conn->data = pgconn;
        conn->connected = 1;
        return 0;
}

static void 
rad_postgres_disconnect(struct sql_connection *conn,
			int drop /* currently unused */)
{
        if (!conn->data)
                return;
        PQfinish(conn->data);
        conn->data = NULL;
        conn->connected = 0;
}

static int
rad_postgres_query(struct sql_connection *conn, char *query, int *return_count)
{
        PGresult       *res;
        ExecStatusType stat;
        int            rc;

        if (!conn || !conn->data)
                return -1;

        GRAD_DEBUG1(1, "query: %s", query);
        
        res = PQexec((PGconn*)conn->data, query);
        if (res == NULL) {
                grad_log(L_ERR,
                         "PQexec: %s",
                         PQerrorMessage((PGconn*)conn->data));
		if (PQstatus((PGconn*)conn->data) == CONNECTION_BAD)
			rad_postgres_disconnect(conn, 0);
                return -1;
        }
        
        stat = PQresultStatus(res);

        GRAD_DEBUG1(1, "status: %s", PQresStatus(stat));

	switch (stat) {
	case PGRES_COMMAND_OK:
                if (return_count)
                        *return_count = atoi(PQcmdTuples(res));
                rc = 0;
		break;

	case PGRES_TUPLES_OK:
		/* Oleg Gawriloff writes:

		   "Sometimes Acct-Start does not reach radiusd, whereas
		    subsequent Acct-Alive or Acct-Stop does. In this case
		    radiusd runs acct_alive_query or acct_stop_query which
		    try to update non-existing data. So, we chose to use
		    a stored procedure in these queries, such that updates
		    the record if it already exists or inserts a new record
		    otherwise. The procedure, however, returns
		    PGRES_TUPLES_OK, instead of PGRES_COMMAND_OK which
		    makes radius to bail out..."
		    
		    hence the need for this code: */
		
		if (return_count) {
			if (PQntuples(res) > 0 && PQnfields(res) > 0) 
				*return_count = atoi(PQgetvalue(res, 0, 0));
			else
				*return_count = 0;
		}
		rc = 0;
		break;

	default:
                grad_log(L_ERR,
                         _("PQexec returned %s"),
                         PQresStatus(stat));
                if (stat == PGRES_FATAL_ERROR 
                    && PQstatus((PGconn*)conn->data) == CONNECTION_BAD) 
			rad_postgres_disconnect(conn, 0);
                rc = -1;
        }
        PQclear(res);
        return rc;
}

static char *
rad_postgres_getpwd(struct sql_connection *conn, char *query)
{
        PGresult       *res;
        ExecStatusType stat;
        char           *return_passwd = NULL;
        
        if (!conn || !conn->data)
                return NULL;

        GRAD_DEBUG1(1, "query: %s", query);
        
        res = PQexec((PGconn*)conn->data, query);
        if (res == NULL) {
                grad_log(L_ERR,
                         "PQexec: %s",
                         PQerrorMessage((PGconn*)conn->data));
		if (PQstatus((PGconn*)conn->data) == CONNECTION_BAD)
			rad_postgres_disconnect(conn, 0);
                return NULL;
        }
        
        stat = PQresultStatus(res);

        GRAD_DEBUG1(1, "status: %s", PQresStatus(stat));

        if (stat == PGRES_TUPLES_OK) {
                int ntuples = PQntuples(res);
                if (ntuples > 1 && PQnfields(res)) {
                        grad_log(L_NOTICE,
			         ngettext("query returned %d tuple: %s",
				  	  "query returned %d tuples: %s",
					  ntuples),
                                 ntuples, query);
                } else if (ntuples == 1) {
                        return_passwd = grad_estrdup(PQgetvalue(res, 0, 0));
                }
        } else {
                grad_log(L_ERR,
                         _("PQexec returned %s"),
                         PQresStatus(stat));
                if (stat == PGRES_FATAL_ERROR
                    && PQstatus((PGconn*)conn->data) == CONNECTION_BAD)
			rad_postgres_disconnect(conn, 0);
        }
        PQclear(res);
        return return_passwd;
}

typedef struct {
        PGresult       *res;
        int            nfields;
        int            ntuples;
        int            curtuple;
} EXEC_DATA;

static int
rad_postgres_n_columns(struct sql_connection *conn, void *data, size_t *np)
{
        EXEC_DATA *edata = (EXEC_DATA*)data;
        if (!data)
                return -1;
	*np = edata->nfields;
	return 0;
}

static int
rad_postgres_n_tuples(struct sql_connection *conn, void *data, size_t *np)
{
        EXEC_DATA *edata = (EXEC_DATA*)data;
        if (!data)
                return -1;
	*np = edata->ntuples;
	return 0;
}

static void *
rad_postgres_exec(struct sql_connection *conn, char *query)
{
        PGresult       *res;
        ExecStatusType stat;
        EXEC_DATA      *data;
        
        if (!conn || !conn->data)
                return NULL;

        GRAD_DEBUG1(1, "query: %s", query);
        
        res = PQexec((PGconn*)conn->data, query);
        if (res == NULL) {
                grad_log(L_ERR,
                         "PQexec: %s",
                         PQerrorMessage((PGconn*)conn->data));
		if (PQstatus((PGconn*)conn->data) == CONNECTION_BAD)
			rad_postgres_disconnect(conn, 0);
                return NULL;
        }
        
        stat = PQresultStatus(res);

        GRAD_DEBUG1(1, "status: %s", PQresStatus(stat));

        if (stat != PGRES_TUPLES_OK) {
                PQclear(res);
                if (stat == PGRES_FATAL_ERROR) {
			grad_log(L_ERR,
			         _("PQexec returned %s"),
			         PQresStatus(stat));
			if (PQstatus((PGconn*)conn->data) == CONNECTION_BAD)
				rad_postgres_disconnect(conn, 0);
		}
                return NULL;
        }

        data = grad_emalloc(sizeof(*data));
        data->res = res;
        data->ntuples = PQntuples(res);
        data->curtuple = -1;
        data->nfields = PQnfields(res);
        return (void*)data;
}

static char *
rad_postgres_column(void *data, size_t ncol)
{
        EXEC_DATA *edata = (EXEC_DATA*)data;
        if (!data)
                return NULL;
        if (ncol >= edata->nfields) {
                return NULL;
        }                                                       
        return PQgetvalue(edata->res, edata->curtuple, ncol);
}

/*ARGSUSED*/
static int
rad_postgres_next_tuple(struct sql_connection *conn, void *data)
{
        EXEC_DATA *edata = (EXEC_DATA*)data;
        if (!data)
                return 1;

        if (edata->curtuple+1 >= edata->ntuples)
                return 1;
        edata->curtuple++;
        return 0;
}

/*ARGSUSED*/
static void
rad_postgres_free(struct sql_connection *conn, void *data)
{
        EXEC_DATA *edata = (EXEC_DATA*)data;

        if (!data)
                return;
        
        PQclear(edata->res);
        grad_free(edata);
}

DECL_SQL_DISPATCH_TAB(postgres) = {
        "postgres",     
        5432,
        rad_postgres_reconnect,
        rad_postgres_disconnect,
        rad_postgres_query,
        rad_postgres_getpwd,
        rad_postgres_exec,
        rad_postgres_column,
        rad_postgres_next_tuple,
        rad_postgres_free,
	rad_postgres_n_tuples,
	rad_postgres_n_columns,
};
#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <ctype.h>
#include <unistd.h>
#include <stdlib.h>
#include <netdb.h>
#include <radlib.h>
#include <radius/argcv.h>

enum ascend_filter_type {
	ascend_filter_generic,      /* 0 */
	ascend_filter_ip,           /* 1 */
	ascend_filter_ipx           /* 2 */
};

/* Maximum compare length for Generic filters. */
#define ASCEND_MAX_CMP_LENGTH 6

enum ascend_filter_cmp_op {
	ascend_cmp_none,
	ascend_cmp_lt,
	ascend_cmp_eq,
	ascend_cmp_gt,
	ascend_cmp_ne
};

/* The format of an IP filter attribute value. Fields are in netorder */
typedef struct {
	grad_uint32_t    src_ip;       /* The source IP address.  */
	grad_uint32_t    dst_ip;       /* The destination IP address.  */
	u_char   src_masklen;  /* The source netmask length */
	u_char   dst_masklen;  /* The destination netmask length */
	u_char   proto;        /* The IP protocol number */
	u_char   established;  /* True if the filter matches only packets
				  with established state of a TCP
				  connection. */
	u_short  src_port;     /* The source port number */
	u_short  dst_port;     /* The destination port number */
	u_char   src_cmp;      /* Comparison operator for source port */
	u_char   dst_cmp;      /* Comparison operator for dest port */
} ASCEND_FILTER_IP;

/* IPX stuff. Not used at the moment */
#define IPX_NODE_ADDR_LEN 6

typedef grad_uint32_t   IPXADDR;
typedef char    IPXNODE[IPX_NODE_ADDR_LEN];
typedef u_short IPXSOCKET;

typedef struct {
	IPXADDR   src_addr;    /* Source IPX Net address */ 
	IPXNODE   src_node;    /* Source IPX Node address */
	IPXSOCKET src_socket;  /* Source IPX socket address */
	IPXADDR   dst_addr;    /* Destination Net address */   
	IPXNODE   dst_node;    /* Destination Node address */  
	IPXSOCKET dst_socket;  /* Destination socket address */
	u_char    src_cmp;     /* Comparison operator for source socket */
	u_char    dst_cmp;     /* Comparison operator for dest socket */
} ASCEND_FILTER_IPX;

/* generic filter */
typedef struct {
	u_short   offset;      /* Offset in the packet to start comparison
				  from */
	u_short   len;         /* Number of bytes to compare */
	u_short   more;        /* If true, the next filter is also to be
				  applied to the packet */
	u_char    mask[ASCEND_MAX_CMP_LENGTH];
                               /* A bitmask specifying the bits to compare */
	        
	u_char    value[ASCEND_MAX_CMP_LENGTH];
                               /* A value to compare against the masked
				  bits in the packet */
	u_char    neq;         /* True if comparison op is != */
} ASCEND_FILTER_GENERIC;

typedef struct {
	u_char type;           /* Filter type from ascend_filter_type */ 
	u_char forward;        /* True if the matching packet is to be
				  forwarded. */
	u_char input;          /* True if this is an input filter */
	u_char unused;
	union {                /* A filter itself: */
		ASCEND_FILTER_IP  ip;
		ASCEND_FILTER_IPX ipx;
		ASCEND_FILTER_GENERIC generic;
		u_char fill[26];
	} v;
} ASCEND_FILTER;


struct ascend_parse_buf {
	int tokc;        /* Number of tokens */
	char **tokv;     /* List of tokens */
	int tokn;        /* Index of the current token */
	ASCEND_FILTER *flt; /* Pointer to filter structure to be filled */
	char **errmsg;   /* Error message */
};

/* Error printing */
static void
ascend_errprint(struct ascend_parse_buf *pb, const char *msg, const char *arg)
{
	if (arg)
		grad_astrcat(pb->errmsg, msg, ": ", arg);
	else
		grad_astrcat(pb->errmsg, msg);
}

static void
ascend_errprints(struct ascend_parse_buf *pb, const char *fmt, const char *arg)
{
	size_t size = strlen(fmt) + strlen(arg) + 1;
	*pb->errmsg = malloc(size);
	if (*pb->errmsg)
		sprintf(*pb->errmsg, fmt, arg);
}

/* generic (more or less) calls */
#define _moreinput(pb) ((pb)->tokn < (pb)->tokc)

static char *
_get_token(struct ascend_parse_buf *pb, int require)
{
	if (!_moreinput(pb)) {
		if (require) {
			ascend_errprint(pb, _("Unexpected end of string"),
					NULL);
			return NULL;
		}
		return NULL;
	}
	return pb->tokv[pb->tokn++];
}

static char *
_lookahead(struct ascend_parse_buf *pb)
{
	if (_moreinput(pb))
		return pb->tokv[pb->tokn];
	return NULL;
}

static int
_get_type(struct ascend_parse_buf *pb)
{
	char *tok = _get_token(pb, 1);
	if (!tok)
		return 1;
	if (strcmp(tok, "ip") == 0)
		pb->flt->type = ascend_filter_ip;
	else if (strcmp(tok, "ipx") == 0)
		pb->flt->type = ascend_filter_ip;
	else if (strcmp(tok, "generic") == 0)
		pb->flt->type = ascend_filter_generic;
	else {
		ascend_errprint(pb, _("Unknown filter type"), tok);
		return 1;
	}
	return 0;
}

static int
_get_dir(struct ascend_parse_buf *pb)
{
	char *tok;
	if ((tok = _get_token(pb, 1)) == NULL)
		return 1;
	if (strcmp(tok, "in") == 0)
		pb->flt->input = 1;
	else if (strcmp(tok, "out") == 0)
		pb->flt->input = 0;
	else {
		ascend_errprint(pb, _("Invalid direction"), NULL);
		return 1;
	}
	return 0;
}

static int
_get_action(struct ascend_parse_buf *pb)
{
	char *tok;
	if ((tok = _get_token(pb, 1)) == NULL)
		return 1;
	if (strcmp(tok, "forward") == 0)
		pb->flt->forward = 1;
	else if (strcmp(tok, "drop") == 0)
		pb->flt->forward = 0;
	else {
		ascend_errprint(pb, _("Unknown action"), tok);
		return 1;
	}
	return 0;
}

/* ************************************************************************* */
/* GENERIC filter parsing */

static int
_get_hex_string(struct ascend_parse_buf *pb, u_char *buf)
{
	u_char tmp[2*ASCEND_MAX_CMP_LENGTH], *p;
	char *tok = _get_token(pb, 1);
	int len, rc, i;
	
	if (!tok)
		return -1;

	len = strlen(tok);
	if (len > 2*ASCEND_MAX_CMP_LENGTH) {
		ascend_errprint(pb, _("Octet string too long"), NULL);
		return -1;
	}

	rc = len / 2;
	if (len % 2)
		rc++;

	memset(tmp, 0, sizeof tmp);

	for (p = tmp; len; len--, p++, tok++) {
		if (*tok >= 0 && *tok <= 9)
			*p = *tok - '0';
		else if (isxdigit(*tok)) {
			if (*tok > 'Z')
				*p = *tok - 'a' + 10;
			else
				*p = *tok - 'A' + 10;
		} else {
			ascend_errprints(pb,
					 _("Invalid hex character (near %s)"),
					 tok);
			return -1;
		}
	}

	for (i = 0; i < 2*ASCEND_MAX_CMP_LENGTH; i++)
		*buf++ = (tmp[i] << 4) | tmp[i+1];
	return rc;
}

/* Generic filter is:

  "generic" dir action offset mask ["=="|"!="] value [ "more" ]
  where dir    is {"in"|"out"}
        action is {"forward"|"drop"}
	offset is number
	mask and value are hex strings */
   
static int
_ascend_parse_generic(struct ascend_parse_buf *pb)
{
	char *p;
	int num;
	char *tok = _get_token(pb, 1);
	int len;
	
	if (!tok)
		return 1;
	num = strtoul(tok, &p, 0);
	if (*p) {
		ascend_errprint(pb, _("Invalid offset"), tok);
		return 1;
	}
	pb->flt->v.generic.offset = ntohs(num);
	if ((len = _get_hex_string(pb, pb->flt->v.generic.mask)) < 0)
		return 1;
	pb->flt->v.generic.len = htons(len);

	tok = _lookahead(pb);
	if (!tok) 
		return 1;

	if (strcmp(tok, "==") == 0) {
		pb->flt->v.generic.neq = 0;
		_get_token(pb, 1);
	} else if (strcmp(tok, "!=") == 0) {
		pb->flt->v.generic.neq = 1;
		_get_token(pb, 1);
	}
	
	if ((num = _get_hex_string(pb, pb->flt->v.generic.value)) < 0)
		return 1;
	if (num != len) {
		ascend_errprint(pb, _("Value and mask are not of same size"),
				NULL);
		return 1;
	}
	
	tok = _get_token(pb, 0);
	if (!tok)
		return 0;

	if (strcmp(tok, "more") == 0)
		pb->flt->v.generic.more = 1;
	else {
		ascend_errprints(pb,
				 _("Expected `more', but found `%s'"),
				 tok);
		return 1;
	}
	return 0;
}

/* ************************************************************************* */
/* IP filter parsing */
static int
_get_protocol(struct ascend_parse_buf *pb)
{
	char *tok = _get_token(pb, 1);
	char *p;
	int num;
	
	num = strtoul(tok, &p, 0);
	if (*p == 0) 
		pb->flt->v.ip.proto = num;
	else {
		/* Try /etc/protocols */
		struct protoent *p = getprotobyname(tok);
		if (!p) {
			ascend_errprint(pb, _("Unknown protocol"), tok);
			return 1;
		}
		pb->flt->v.ip.proto = p->p_proto;
	}
	return 0;
}

#define ASCEND_DIR_NONE -1
#define ASCEND_DIR_SRC 0
#define ASCEND_DIR_DST 1

static int
_get_direction_type(struct ascend_parse_buf *pb, char *suffix, int lookahead)
{
	char *tok = lookahead ? _lookahead(pb) : _get_token(pb, 1);

	if (!tok && lookahead) 
		return ASCEND_DIR_NONE;
	if (tok && strlen(tok) > 3 && strcmp(tok+3, suffix) == 0) {
		if (strncmp(tok, "dst", 3) == 0)
			return ASCEND_DIR_DST;
		else if (strncmp(tok, "src", 3) == 0)
			return ASCEND_DIR_SRC;
	}
	if (!lookahead)
		ascend_errprints(pb,
				 _("Expected `{src|dst}port', but found `%s'"),
				 tok);
	return ASCEND_DIR_NONE;
}

static int
_get_ip(struct ascend_parse_buf *pb)
{
	int dir = _get_direction_type(pb, "ip", 0);
	char *tok;
	grad_uint32_t ip, mask;
	
	if (dir == ASCEND_DIR_NONE)
		return ASCEND_DIR_NONE;
	tok = _get_token(pb, 1);
	if (!tok)
		return ASCEND_DIR_NONE;
	ip = grad_ip_strtoip(tok); /*FIXME: no error checking */

	if (_moreinput(pb) && _lookahead(pb)[0] == '/') {
		char *p;
		
		_get_token(pb, 1);
		tok = _get_token(pb, 1);
		if (!tok)
			return ASCEND_DIR_NONE;
		mask = strtoul(tok, &p, 0);
		if (*p || mask > 32) {
			ascend_errprint(pb, _("Invalid netmask length"), tok);
			return ASCEND_DIR_NONE;
		}
	} else
		mask = 32;

	ip = htonl(ip);
	switch (dir) {
	case ASCEND_DIR_SRC:
		pb->flt->v.ip.src_ip = ip;
		pb->flt->v.ip.src_masklen = mask;
		break;
		
	case ASCEND_DIR_DST:
		pb->flt->v.ip.dst_ip = ip;
		pb->flt->v.ip.dst_masklen = mask;
		break;
	}
	return dir;
}

/* FIXME: if second {src|dst}ip is misspelled, the function returns
   success, supposing it was a portspec */
static int
_ascend_parse_ip_clause(struct ascend_parse_buf *pb)
{
	int n;

	if (_get_direction_type(pb, "ip", 1) == ASCEND_DIR_NONE) 
		return 0;
	n = _get_ip(pb);
	if (n == ASCEND_DIR_NONE)
		return 1;
	if (_get_direction_type(pb, "ip", 1) != ASCEND_DIR_NONE) {
		int n1 = _get_ip(pb);
		if (n1 == n) {
			ascend_errprint(pb,
					_("Duplicate IP specification"), NULL);
			return 1;
		}
	}
	return 0;
}

static int
_get_op(struct ascend_parse_buf *pb)
{
	char *s = _get_token(pb, 1);
	if (!s)
		return ascend_cmp_none;
	switch (s[0]) {
	case '>':
		return ascend_cmp_gt;
	case '<':
		return ascend_cmp_lt;
	case '=':
		return ascend_cmp_eq;
	case '!':
		if (s[1] == '=')
			return ascend_cmp_ne;
	}
	ascend_errprint(pb, _("Invalid operation"), s);
	return ascend_cmp_none;
}

static int
_get_port(struct ascend_parse_buf *pb)
{
	int dir = _get_direction_type(pb, "port", 0);
	char *tok;
	char *p;
	int num;
	int op;
	
	if (dir == ASCEND_DIR_NONE)
		return ASCEND_DIR_NONE;

	if ((op = _get_op(pb)) == ascend_cmp_none)
		return ASCEND_DIR_NONE;

	tok = _get_token(pb, 1);
	if (!tok)
		return ASCEND_DIR_NONE;
	
	num = strtoul(tok, &p, 0);
	if (*p == 0) 
		num = htons(num);
	else {
		struct servent *sp;
		struct protoent *pp = getprotobynumber(pb->flt->v.ip.proto);

		if (!pp) {
			/* Shouldn't happen */
			ascend_errprint(pb,
				      _("Cannot map back the protocol number"),
				      NULL);
			return ASCEND_DIR_NONE;
		}
		sp = getservbyname(tok, pp->p_name);
		if (!sp) {
			ascend_errprint(pb, _("Unknown service"), tok);
			return 1;
		}
		num = sp->s_port;
	}

	switch (dir) {
	case ASCEND_DIR_SRC:
		pb->flt->v.ip.src_port = num;
		pb->flt->v.ip.src_cmp = op;
		break;
		
	case ASCEND_DIR_DST:
		pb->flt->v.ip.dst_port = num;
		pb->flt->v.ip.dst_cmp = op;
		break;
	}

	return dir;
}

/* Return value:
   0 - No port specification found
   1 - Port specification is found and processed
   -1 - Parse error pb->errmsg *might* contain diagnostics */
static int
_ascend_parse_port_clause(struct ascend_parse_buf *pb)
{
	int n;
	
	if (_get_direction_type(pb, "port", 1) == ASCEND_DIR_NONE)
		return 0;
	
	n = _get_port(pb);

	if (n == ASCEND_DIR_NONE)
		return -1;
	if (_get_direction_type(pb, "port", 1) != ASCEND_DIR_NONE) {
		int n1 = _get_port(pb);
		if (n1 == ASCEND_DIR_NONE)
			return -1;
		if (n1 == n) {
			ascend_errprint(pb,
					_("Duplicate port specification"),
					NULL);
			return -1;
		}
	}
	return 1;
}

/* IP filter specification is

   "ip" dir action [ "dstip" IP "/" NUM] [ "srcip" IP "/" NUM ]
   	        [ PROTO [ "dstport" cmp PORT ] [ "srcport" cmp PORT ]
                [ "est" ] ]

   where dir    is {"in"|"out"}
         action is {"forward"|"drop"}
	 cmp    is {">"|"<"|"="|"!="}
	 IP     is IP address in dotted-quad
	 NUM    is the decimal number, 0 <= NUM <= 32.
	 PROTO  is either the protocol number or its name from /etc/protocols
	 PORT   is either the port number or its name from /etc/services */

static int
_ascend_parse_ip(struct ascend_parse_buf *pb)
{
	if (!_moreinput(pb))
		return 0;
	
	if (_ascend_parse_ip_clause(pb))
		return 1;
	
	if (_moreinput(pb)) {
		if (_get_protocol(pb))
			return 1;
		if (_moreinput(pb)) {
			char *tok;
			int have_port = _ascend_parse_port_clause(pb);
			if (have_port == -1)
				return 1;
			tok = _get_token(pb, 0);
			if (!tok)
				return 0;
			if (strcmp(tok, "est") == 0)
				pb->flt->v.ip.established = 1;
			else {
				ascend_errprints(pb,
					 have_port ?
					 _("Expected `est' but found `%s'") :
					 _("Expected `{src|dst}port' or `est', but found `%s'"),
					 tok);
				return 1;
			}
		}
	}
	return 0;
}

static int
_ascend_parse_ipx(struct ascend_parse_buf *pb)
{
	ascend_errprint(pb, "IPX filters are not yet supported", NULL);
	return 1;
}
 
static int
_ascend_parse(struct ascend_parse_buf *pb)
{
	memset(pb->flt, 0, sizeof(pb->flt[0]));
	
	if (_get_type(pb)
	    || _get_dir(pb)
	    || _get_action(pb))
		return 1;
	switch (pb->flt->type) {
	case ascend_filter_generic:
		return _ascend_parse_generic(pb);
	case ascend_filter_ip:
		return _ascend_parse_ip(pb);
	case ascend_filter_ipx:
		return _ascend_parse_ipx(pb);
	}
	return 1;
}

/* Parse a single ascend filter specification.
   Return 0 and fill flt[0] if the specification is correct.
   Return !0 and return diagnostics in errp otherwise.
   NOTE: errp is malloced and should be freed using usual free() */
static int
_ascend_parse_filter(const char *input, ASCEND_FILTER *flt, char **errp)
{
	struct ascend_parse_buf pb;
	int rc;

	*errp = NULL;
	if (grad_argcv_get(input, "/", NULL, &pb.tokc, &pb.tokv)) {
		grad_argcv_free(pb.tokc, pb.tokv);
		ascend_errprint(&pb, _("Failed to tokenize"), NULL);
		return 1;
	}

	pb.tokn = 0;
	pb.flt = flt;
	pb.errmsg = errp;
	rc = _ascend_parse(&pb);
	grad_argcv_free(pb.tokc, pb.tokv);
	if (rc && !*errp) 
		ascend_errprint(&pb, _("Malformed attribute value"), NULL);
	return rc;
}

int
grad_ascend_parse_filter(grad_avp_t *pair, char **errp)
{
	ASCEND_FILTER flt;
	
	if (_ascend_parse_filter(pair->avp_strvalue, &flt, errp)) 
		return 1;
	grad_free(pair->avp_strvalue);
	pair->avp_strlength = sizeof(flt);
	pair->avp_strvalue = grad_emalloc(pair->avp_strlength);
	memcpy(pair->avp_strvalue, &flt, sizeof(flt));
	return 0;
}
