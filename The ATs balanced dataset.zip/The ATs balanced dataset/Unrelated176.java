import java.net.URLClassLoader;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import java.net.URLStreamHandlerFactory;
import java.security.AccessControlException;
import java.security.CodeSource;
import java.security.Permission;
import java.security.PermissionCollection;
import java.security.Policy;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.jar.JarFile;
import java.util.jar.JarInputStream;
import java.util.jar.Manifest;


/**
 * Subclass implementation of <b>java.net.URLClassLoader</b> that knows how
 * to load classes from disk directories, as well as local and remote JAR
 * files.  It also implements the <code>Reloader</code> interface, to provide
 * automatic reloading support to the associated loader.
 * <p>
 * In all cases, URLs must conform to the contract specified by
 * <code>URLClassLoader</code> - any URL that ends with a "/" character is
 * assumed to represent a directory; all other URLs are assumed to be the
 * address of a JAR file.
 * <p>
 * <strong>IMPLEMENTATION NOTE</strong> - Local repositories are searched in
 * the order they are added via the initial constructor and/or any subsequent
 * calls to <code>addRepository()</code>.
 * <p>
 * <strong>IMPLEMENTATION NOTE</strong> - At present, there are no dependencies
 * from this class to any other Catalina class, so that it could be used
 * independently.
 *
 * @author Craig R. McClanahan
 * @author Remy Maucherat
 * @version $Revision: 1.1 $ $Date: 2004/05/31 10:55:16 $
 */

public class StandardClassLoader
    extends URLClassLoader {


    // ----------------------------------------------------------- Constructors


    /**
     * Construct a new ClassLoader with no defined repositories and no
     * parent ClassLoader.
     */
    public StandardClassLoader() {

        super(new URL[0]);
        this.parent = getParent();
        this.system = getSystemClassLoader();
        securityManager = System.getSecurityManager();
    }


    /**
     * Construct a new ClassLoader with no defined repositories and no
     * parent ClassLoader, but with a stream handler factory.
     *
     * @param factory the URLStreamHandlerFactory to use when creating URLs
     */
    public StandardClassLoader(URLStreamHandlerFactory factory) {

        super(new URL[0], null, factory);
        this.factory = factory;

    }


    /**
     * Construct a new ClassLoader with no defined repositories and the
     * specified parent ClassLoader.
     *
     * @param parent The parent ClassLoader
     */
    public StandardClassLoader(ClassLoader parent) {

        super((new URL[0]), parent);
        this.parent = parent;
        this.system = getSystemClassLoader();
        securityManager = System.getSecurityManager();

    }


    /**
     * Construct a new ClassLoader with no defined repositories and the
     * specified parent ClassLoader.
     *
     * @param parent The parent ClassLoader
     * @param factory the URLStreamHandlerFactory to use when creating URLs
     */
    public StandardClassLoader(ClassLoader parent,
                               URLStreamHandlerFactory factory) {

        super((new URL[0]), parent, factory);
        this.factory = factory;

    }
package com.explosion.boot;

/*
 * =============================================================================
 * 
 * Copyright 2004 Stephen Cowx
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 * 
 * =============================================================================
 */

import java.io.File;
import java.io.FilenameFilter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegExpFileNameFilter implements FilenameFilter
{

    private Pattern pattern;

    private boolean caseSensitive = false;

    public RegExpFileNameFilter(String fileNamePattern, boolean caseSensitive) 
    {
        this.caseSensitive = caseSensitive;
        if (caseSensitive)
            pattern = Pattern.compile(fileNamePattern);
        else
            pattern = Pattern.compile(fileNamePattern.toUpperCase());
    }

    public boolean accept(File parent, String filename)
    {
        Matcher m = null;
        if (caseSensitive)
            m = pattern.matcher(filename);
        else
            m = pattern.matcher(filename.toUpperCase());
        return m.find();package com.explosion.boot;

/*
 * =============================================================================
 * 
 * Copyright 2004 Stephen Cowx
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 * 
 * =============================================================================
 */

import java.io.File;
import java.io.FilenameFilter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegExpFileNameFilter implements FilenameFilter
{

    private Pattern pattern;

    private boolean caseSensitive = false;

    public RegExpFileNameFilter(String fileNamePattern, boolean caseSensitive) 
    {
        this.caseSensitive = caseSensitive;
        if (caseSensitive)
            pattern = Pattern.compile(fileNamePattern);
        else
            pattern = Pattern.compile(fileNamePattern.toUpperCase());
    }

    public boolean accept(File parent, String filename)
    {
        Matcher m = null;
        if (caseSensitive)
            m = pattern.matcher(filename);
        else
            m = pattern.matcher(filename.toUpperCase());
        return m.find();
    }
	
	

    /**
     * Construct a new ClassLoader with the specified repositories and
     * no parent ClassLoader.
     *
     * @param repositories The initial set of repositories
     */
    public StandardClassLoader(String repositories[]) {

        super(convert(repositories));
        this.parent = getParent();
        this.system = getSystemClassLoader();
        securityManager = System.getSecurityManager();
        if (repositories != null) {
            for (int i = 0; i < repositories.length; i++)
                addRepositoryInternal(repositories[i]);
        }

    }


    /**
     * Construct a new ClassLoader with the specified repositories and
     * parent ClassLoader.
     *
     * @param repositories The initial set of repositories
     * @param parent The parent ClassLoader
     */
    public StandardClassLoader(String repositories[], ClassLoader parent) {

        super(convert(repositories), parent);
        this.parent = parent;
        this.system = getSystemClassLoader();
        securityManager = System.getSecurityManager();
        if (repositories != null) {
            for (int i = 0; i < repositories.length; i++)
                addRepositoryInternal(repositories[i]);
        }

    }


    /**
     * Construct a new ClassLoader with the specified repositories and
     * parent ClassLoader.
     *
     * @param repositories The initial set of repositories
     * @param parent The parent ClassLoader
     */
    public StandardClassLoader(URL repositories[], ClassLoader parent) {

        super(repositories, parent);
        this.parent = parent;
        this.system = getSystemClassLoader();
        securityManager = System.getSecurityManager();
        if (repositories != null) {
            for (int i = 0; i < repositories.length; i++)
                addRepositoryInternal(repositories[i].toString());
        }

    }


    // ----------------------------------------------------- Instance Variables

    
    /**
     * The set of optional packages (formerly standard extensions) that
     * are available in the repositories associated with this class loader.
     * Each object in this list is of type
     * <code>org.apache.catalina.loader.Extension</code>.
     */
    protected ArrayList available = new ArrayList();


    /**
     * The debugging detail level of this component.
     */
    protected int debug = 0;


    /**
     * Should this class loader delegate to the parent class loader
     * <strong>before</strong> searching its own repositories (i.e. the
     * usual Java2 delegation model)?  If set to <code>false</code>,
     * this class loader will search its own repositories first, and
     * delegate to the parent only if the class or resource is not
     * found locally.
     */
    protected boolean delegate = false;


    /**
     * The list of local repositories, in the order they should be searched
     * for locally loaded classes or resources.
     */
    protected String repositories[] = new String[0];


    /**
     * The set of optional packages (formerly standard extensions) that
     * are required in the repositories associated with this class loader.
     * Each object in this list is of type
     * <code>org.apache.catalina.loader.Extension</code>.
     */
    protected ArrayList required = new ArrayList();


    public int getDebug() {

        return (this.debug);

    }


    /**
     * Set the debugging detail level for this component.
     *
     * @param debug The new debugging detail level
     */
    public void setDebug(int debug) {

        this.debug = debug;

    }


    /**
     * Return the "delegate first" flag for this class loader.
     */
    public boolean getDelegate() {

        return (this.delegate);

    }


    /**
     * Set the "delegate first" flag for this class loader.
     *
     * @param delegate The new "delegate first" flag
     */
    public void setDelegate(boolean delegate) {

        this.delegate = delegate;

    }


    /**
     * If there is a Java SecurityManager create a read FilePermission
     * or JndiPermission for the file directory path.
     *
     * @param path file directory path
     */
    public void setPermissions(String path) {
        if( securityManager != null ) {
            if( path.startsWith("jndi:") || path.startsWith("jar:jndi:") ) {
                log("Asked for Jndi permission to be set.  This request is being ignored");
                //permissionList.add(new JndiPermission(path + "*"));
            } else {
                permissionList.add(new FilePermission(path + "-","read"));
            }
        }
    }


	/*
 * =============================================================================
 * 
 * Copyright 2004 Stephen Cowx
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 * 
 * =============================================================================
 */

import java.util.Date;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
public class ExpToolBarSegment
{
  public static final int ALWAYS_FIRST_SEGMENT = 0;
  public static final int ALWAYS_LAST_SEGMENT = 1;
  public static final int ANY_POSITION = 2;

  private int startIndex = 0;
  private int numberOfElements = 0;
  private Vector toolBarElements;
  private ExpToolBar toolBar;
  private int relativePositionOfSegmentOnToolBar = 0;
  private boolean hasSeparator = false;

  protected ExpToolBarSegment(int startIndex, ExpToolBar toolBar, Vector toolBarElements, int relativePositionOfSegmentOnToolBar)
  {
    this.startIndex = startIndex;
    this.toolBar = toolBar;
    this.toolBarElements = toolBarElements;
    this.relativePositionOfSegmentOnToolBar = relativePositionOfSegmentOnToolBar;
  }

  public int getStartIndex()
  {
    return startIndex;
  }

  public int getRelativePositionOfSegmentOnMenu()
  {
    return relativePositionOfSegmentOnToolBar;
  }

  /**
   * This method adds an Item to a menu segment.  Using a null item will insert a separator
   */
  public void addElement(JButton item)
  {
    int numberAdded = 0;

    if (toolBarElements.size() == 0)
    {
      /* Just add the menu item */
      if (item == null)
        toolBarElements.addElement("Separator");
      else
        toolBarElements.addElement(item);

      numberOfElements++;
      numberAdded++;
    }
    else
    {
      if (item != null)
        toolBarElements.insertElementAt(item, startIndex + numberOfElements);
      else
        toolBarElements.insertElementAt("Separator", startIndex + numberOfElements);

      numberOfElements++;
      numberAdded++;
    }

    // notify the parent
    ((ExpToolBar) toolBar).updateStartPositions(this, numberAdded);
  }

  public void removeElement(JButton item) throws Exception
  {
    int numberRemoved = 0;

    if (numberOfElements != 0)
    {
      toolBarElements.remove(item);
      numberOfElements--;
      numberRemoved--;
    }
    else
      throw new ToolBarException("Unable to remove element from ExpToolBarSegment because there are no elements in the segment.");

    // notify the parent
    ((ExpToolBar) toolBar).updateStartPositions(this, numberRemoved);
  }

  public int getSegmentSize()
  {
    return numberOfElements;
  }

  public void modifyStartPos(int number)
  {
    this.startIndex += number;
  }

}