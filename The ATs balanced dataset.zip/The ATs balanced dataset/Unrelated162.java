 on Jul 8, 2004
 *  private void stopAllProfileTableActivities() {
        SleeProfileManager sleeProfileManager=SleeProfileManager.getInstance();
        HashMap profileTableActivities=sleeProfileManager.getProfileTableActivities();
        logger.debug("Stopping profile table activities !");
        Iterator it=profileTableActivities.keySet().iterator();
        while(it.hasNext()){
            String profileTableName=(String)it.next();
            logger.debug("Stopping following profile table activity : "+profileTableName);
	        SleeContainer sleeContainer = SleeContainer.lookupFromJndi();
	        int eventID = sleeContainer.getEventLookupFacility().getEventID(
	                new ComponentKey("javax.slee.ActivityEndEvent",
	                        "javax.slee", "1.0"));
	
	        ProfileTableActivityImpl profileTableActivity = 
	            (ProfileTableActivityImpl)profileTableActivities.get(profileTableName);
	        sleeContainer.getSleeEndpoint().scheduleActivityEndedEvent(
	                profileTableActivity);
        }
    }


 * The Open SLEE project
 *
 * The source code contained in this file is in in the public domain.          
 * It can be used in any project or product without prior permission, 	      
 * license or royalty payments. There is no claim of correctness and
 * NO WARRANTY OF ANY KIND provided with this code.
 *
 */
package org.mobicents.slee.runtime;

import java.util.Collection;


/** 
 * Activity context factory implementation interface.
 * 
 * @author F.Moggia
 * rivate void rememberActiveResourceAdaptorsBeforeStop() throws Exception {
        /* FIXME: Unfinished method, needed for SLEE shutdwn
        HashSet activeResourceAdaptorsBeforeStop = new HashSet();
        activeResourceAdaptorsBeforeStop.clear();
        activeResourceAdaptorsBeforeStop.addAll( sleeContainer.getResourceAdaptorEntities() );
    */
        
    }  if (isFullSleeStop) {
	            startupTime = System.currentTimeMillis() - startupTime;
	            long startupSec = startupTime/1000;
	            long startupMillis = startupTime % 1000;
	            timerSt = "in " + startupSec + "s:" + startupMillis + "ms ";
            }
            logger.info("[[[[[[[[[ MOBICENTS Started " + timerSt + "]]]]]]]]]");
            
        } else if (newState.equals(SleeState.STOPPED)) {
            logger.info("[[[[[[[[[[ MOBICENTS Stopped (SLEE). ]]]]]]]]]");
        }
    }
    
    public void setFullSleeStop(boolean b) {
        isFullSleeStop = b;
    }
    
    /**
     * Indicates whether Mobicents SLEE is simply marked as STOPPED or all its services actually stopped.
     * The distinction is important due to the way MBean service dependencies are handled on mobicents.sar undeploy vs. 
     * externally calling SleeManagementMBean.stop()
     */
    public boolean isFullSleeStop() {
        return isFullSleeStop;
    }   

}

 */
public interface ActivityContextFactory {
	
	/**
	 * Verifies that exists an activity context for the specified activity object.
	 * @param activity the activity object
	 * @return true if there is an activity context for this activity object; false otherwise
	 */
	public boolean containsActivityContext(Object activity);
	
	/** Get an activity context or create one if one does not
	 * exist
	 * @param activity -- activity for which to create the activity context
	 * @return created activity context.
	 */
    public ActivityContext getActivityContext(Object activity);
    
    /** Remove an activity context from the hash table given the
     * activity.
     * @param activity
     */
    
    public void removeActivityContext(String activityContextId);
    
   
    /** Get an activity context given it's key.
     * Does not create one if it is not already there
     * @author Tim
     *
     */
    public ActivityContext getActivityContextById(String key);
    
    public String getActivityContextId(Object activity);

    public Object getActivityFromKey(String key);
    
    /**
     * @return Collection of all registered SLEE activities
     */
    public Collection getAllActivityContexts();
    
}
public class SbbEntityFactory {
	
	/* NB!! We must not a map to cache sbb entities.
     * There can be multiple active transactions each of which accesses the same sbb entity
     * at any one time in the SLEE.
     * Therefore, by using a map to store the sbb entities one tx can see the transactional
     * state of the other tx before it has committed.
     * I.e. we would have no transaction isolation.
     * Instead, if we want to cache the sbb entity for the lifetime of the tx for
     * performance reasons, we need to store in a *per transaction* cache
     */
    
    private SleeContainer serviceContainer;
    
    private static Logger log = Logger.getLogger(SbbEntityFactory.class);

    public SbbEntityFactory(SleeContainer container) {
        this.serviceContainer = container;
    }

    private String genId()
    {
    	//Use a GUID for the sbb entity id - a counter won't work in a cluster
    	VMID vmid = new VMID();
    	return vmid.toString();
    }
    
    public SbbEntity createSbbEntity(SbbID sbbId, ServiceID svcId,
            String parentSbbEntityId, String convergenceName) {
        try {        	        	
            String sbbeId = genId();
            if(log.isDebugEnabled())
            log.debug("createSbbEntity: Creating non-root sbb entity with id:" + sbbeId);
            
            SbbEntity sbbe = new SbbEntity( sbbeId, sbbId, convergenceName, svcId);
            sbbe.setParentSbbEntity(parentSbbEntityId);
            sbbe.setRootSbbId(this.serviceContainer.getService(svcId)
                    .getRootSbbEntityId(convergenceName));
            
            // storing in cache is deferred until successful commit.
            if(log.isDebugEnabled())
            log.debug("Putting it in the map");
            putInTxCache(sbbeId, sbbe);
            return sbbe;
        } 


    /**
     * Changes the SLEE container state and emits JMX notifications
     * @param newState
     */
    protected void changeSleeState(SleeState newState) {
        SleeState oldState = sleeContainer.getSleeState();
        sleeContainer.setSleeState(newState);
        notificationBroadcaster.sendNotification(new SleeStateChangeNotification(this, newState, oldState, sleeStateChangeSequenceNumber++));

        if (newState.equals(SleeState.RUNNING)) {
            String timerSt = "";
          package gnu.cajo.utils.extra;  import gnu.cajo.invoke.Invoke; import gnu.cajo.invoke.Remote;  /*  * Service Method Availability Test  * Copyright (c) 2007 John Catherino  * The cajo project: https://cajo.dev.java.net  *  * For issues or suggestions mailto:cajo@dev.java.net  *  * This file Implements.java is part of the cajo library.  *  * The cajo library is free software; you can redistribute it and/or modify  * it under the terms of the GNU Lesser General Public Licence as published  * by the Free Software Foundation, at version 3 of the licence, or (at your  * option) any later version.  *  * Th cajo library is distributed in the hope that it will be useful,  * but WITHOUT ANY WARRANTY; without even the implied warranty of  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the  * GNU Lesser General Public Licence for more details.  *  * You should have received a copy of the GNU Lesser General Public Licence  * along with this library. If not, see http://www.gnu.org/licenses/lgpl.html  */  /**  * This class takes any service object, and allows its methods to be tested  * for <u>existence</u>, <i>without</i> having to invoke them. This is  * particularly important to enable <a href=http://en.wikipedia.org/wiki/Liskov_substitution_principle>  * Type Substitution</a>. In other words; a client could check if a service  * object implemented its <a href=http://weblogs.java.net/blog/cajo/archive/2006/12/dynamic_client.html>  * specific</a> interface.<p>  * When a service is remoted, wrapped in this object; clients can invoke the  * methods they <i>assume</i> this object implements. Instead of the normal  * method return; it will return a boolean. True will indicate that the  * service supports the method, otherwise it will return false. No side  * effects to the wrapped object will be incurred by this service. In  * fact; the service object will be completely unaware of the testing.<p>  * One <i>suggested</i> protocol: A service object could provide a public  * <tt>getImplements();</tt> method, which would return a remote reference to  * the service object, wrapped by an <tt>Implements</tt> instance. A new  * reference needn't be created for each call, and in fact, the reference can  * even be instantiated lazily, i.e. if needed.<p>  * As a template:<p>  * <pre><tt> private Remote myImplements;  * public RemoteInvoke getImplements() throws java.rmi.RemoteException {  *    return myImplements == null ?  *       myImplements = new Remote(new Implements(this)) : myImplements;  * }</tt></pre>  *  * @version 1.0, 03-Apr-07  * @author John Catherino  */ public final class Implements implements Invoke {    private final Object service;    /**     * The constructor takes any service object, and allows it to be remotely     * tested for method <i>existence,</i> without having to <U>invoke</u> it.     * @param  service The service object to make remotely testable for method     * callability.     */    public Implements(Object service) { this.service = service; }    /**     * Instead of actually invoking the method on the target object, this     * object will test for the existence of the method on the target object,     * either and return true or false.     * @param  method The method to check for existence     * @param args The signature of the particular method would accept, the     * arguments can be null, or subclasses of the expected arguments.     * Typically these are represented by class, but they also can be passed     * in by instance.     * @return Instead of the method's normal return, if any, it will be true     * if the service supports this method and signature, otherwise false.     */    public Object invoke(String method, Object args) {       if (args instanceof Object[]) {          if (((Object[])args).length == 0) try {             service.getClass().getMethod(method, null);             return Boolean.TRUE;          } catch(NoSuchMethodException x) { return Boolean.FALSE; }          if (args instanceof Class[])             return Remote.findBestMethod(service, method, (Class[])args)                != null ? Boolean.TRUE : Boolean.FALSE;          Object[] o_args = (Object[])args;          Class[]  c_args = new Class[o_args.length];          for(int i = 0; i < o_args.length; i++)             c_args[i] = o_args[i] != null ? o_args[i].getClass() : null;          return Remote.findBestMethod(service, method, c_args) != null             ? Boolean.TRUE : Boolean.FALSE;       } else if (args != null) {          Class[] c_arg = args instanceof Class ?             new Class[] { (Class)args } : new Class[]{ args.getClass() };          return Remote.             findBestMethod(service, method, c_arg) != null ?                Boolean.TRUE : Boolean.FALSE;       } else try {          service.getClass().getMethod(method, null);          return Boolean.TRUE;       } catch(NoSuchMethodException x) { return Boolean.FALSE; }    }

package gnu.cajo.utils.extra;

import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;
import gnu.cajo.invoke.Remote;

/*package gnu.cajo.utils.extra;
package gnu.cajo.utils.extra;

import gnu.cajo.invoke.Remote;

/*
 * Asynchronous Method Invocation Class
 * Copyright (C) 2006 John Catherino
 * The cajo project: https://cajo.dev.java.net
 *
 * For issues or suggestions mailto:cajo@dev.java.net
 *
 * This file AsyncMethod.java is part of the cajo library.
 *
 * The cajo library is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public Licence as published
 * by the Free Software Foundation, at version 3 of the licence, or (at your
 * option) any later version.
 *
 * Th cajo library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public Licence for more details.
 *
 * You should have received a copy of the GNU Lesser General Public Licence
 * along with this library. If not, see http://www.gnu.org/licenses/lgpl.html
 */

/**
 * This class is used to asynchronously invoke methods on objects. Each time
 * the invoke method is called, it spawns a one-use thread, to perform the
 * method invocation. From the perspective of the caller, the method returns
 * immediately. When the invocation is completed, it will callback the
 * provided listening object; invoking a method of the identical name as the
 * one invoked on the called object; passing a single object argument, which
 * is either the resulting data of the invocation, if any, or the exception
 * resulting from the invocation. Canonically the callback object should
 * therfore define up to three methods; each having the name of the method
 * called. One method accepting no arguments, one receiving the expected
 * result object, and one accepting an Exception argument. The callback can
 * be null, in which case the asynchronous invocation result will be
 * silently discarded.<p>
 * This class can be used in either of two fundamentally different ways:<ul>
 * <li>An instance can be constructed for a given called object, and its
 * corresponding callback object, for repeated use.
 * <li>The static invoke method can be used for infrequent combinations of
 * called objects and callbacks.</ul>
 * This class is intended for method invocations which require a
 * <i>significant</i> amount of time to complete. It can also be remoted,
 * which would open some considerably interesting possibilities. It could
 * even be passed <u>between</u> virtual machines, that is <i>really</i>
 * something to think about.
 *
 * @version 1.0, 22-Jan-06 Initial release
 * @author John Catherino
 */
public final class AsyncMethod implements gnu.cajo.invoke.Invoke {
   private static final long serialVersionUID = 1L;
   /**
    * This is the reference to the object, usually remote, on which to
    * invoke asynchronously. It works on local objects as well.
    */
   public final Object item;
   /**
    * This is the reference to the object, local or remote, which to call
    * back asynchronously, when the invocation has completed. (if non-null)
    */
   public final Object callback;
   /**
    * The constructor takes any object, and allows its methods to be
    * invoked asynchronously; then calls back the listening object, with the
    * result of the invocation.
    * @param  item The object to make asynchronously callable.  It may be an
    * any arbitrary object, of any type, local or remote.
    * @param  callback The object to asynchronously call back, on the
    * completion of the asynchronous method call.  It may be any arbitrary
    * object, of any type, local or remote. If the argument is null, the
    * asynchronous invocations result will silently be silently discarded.
    */
   public AsyncMethod(Object item, Object callback) {
      this.item = item;
      this.callback = callback;
   }
   /**
    * This method invokes the method specified, with the argument(s)
    * specified, if any, asynchronously.
    * @param  method The name of the method of the member object to be
    * invoked asynchronously.
    * @param  args The argument, or arguments, to be provided to the method.
    * The paramater can be null, if the method takes none, or it can be
    * an array of objects, if the method takes several. In actuality,
    * this method simply invokes the static invoke method of this class,
    * providing its local item and callback objects, to centralise the
    * asynchronous invocation processing.
    * @return null No return is provided, it is required to fulfill the
    * Invoke interface.
    */
   public Object invoke(String method, Object args) {
      invoke(item, method, args, callback);
      return null;
   }
   /**
    * This method invokes the method specified, on the object specified,
    * with the argument(s) specified, if any, asynchronously. It then calls
    * the callback object specified, if any.
    * @param item The object on which to invoke the method asynchronously.
    * It may be any arbitrary object, of any type, local or remote.
    * @param method The name of the method on the called object to be
    * invoked asynchronously.
    * @param args The argument, or arguments, to be provided to the method.
    * The paramater can be null, if the method takes none, or it can be
    * an array of objects, when the method takes several.
    * @param callback The object to asynchronously call back, on the
    * completion of the asynchronous method call.  It may be any arbitrary
    * object, of any type, local or remote. If the argument is null, the
    * invocation result will be silently discarded.
    */
   public static void invoke(final Object item, final String method,
      final Object args, final Object callback) {
      new Thread() {
         public void run() {
            Object result;
            try { result = Remote.invoke(item, method, args); }
            catch(Exception x) { result = x; }
            if (callback != null)
               try { Remote.invoke(callback, method, result); }
               catch(Exception x) { x.printStackTrace(); }
         }
      }.start();


import java.io.*;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

/*
 * Serialized Object Encrypter
 * Copyright (c) 2004 John Catherino
 * The cajo project: https://cajo.dev.java.net
 *
 * For issues or suggestions mailto:cajo@dev.java.net
 *
 * This file CryptObject.java is part of the cajo library.
 *
 * The cajo library is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public Licence as published
 * by the Free Software Foundation, at version 3 of the licence, or (at your
 * option) any later version.
 *
 * Th cajo library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public Licence for more details.
 *
 * You should have received a copy of the GNU Lesser General Public Licence
 * along with this library. If not, see http://www.gnu.org/licenses/lgpl.html
 */

/**
 * This class is used to hash a wrapped object.  Primarily it is intended to
 * simply and automatically convert a serialized object representation in to,
 * and out of plaintext, for transmission over the network.<p>
 *
 * The underlying paradigm is that rather than incurring the extensive
 * computational overhead of running encrypted streams between clients and
 * servers, it much more efficient to encrypt only those specific objects
 * containing sensitive information. In fact, this approach is even stronger
 * than conventional encrypted streams, because each object could employ a
 * different key, and <b>even</b> different cryptographical algorithms!<p>
 *
 * Ideally, the client and the server would both have the derived class in
 * their local codebases, as it will otherwise need to be sent over the
 * wire from a codebase server, severely compromising security.<p>
 *
 * Special thanks to Jeff Genender at
 * http://www.savoirtech.com/roller/page/jgenender/20040806#cipher_text_for_storage
 * for the idea, and the admonition, to improve HashProxy security.<p>
 *
 * <i>Note:</i> since this class uses the javax.crypto packages, it may not
 * function on some J2ME devices.
 *
 * @version 1.1, 07-Aug-04 Fixed security hole with the static key/cipher.
 * @author John Catherino
 */
public class CryptObject extends gnu.cajo.utils.ZippedProxy {
   private final void writeObject(ObjectOutputStream out) throws IOException {
      try{
         Cipher cipher = Cipher.getInstance(CIPHER);
         cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(KEY, CIPHER));
         payload = cipher.doFinal(payload);
      } catch (Exception e){ throw new IOException(e.toString()); }
      out.defaultWriteObject();
   }
   private final void readObject(ObjectInputStream in)
      throws IOException, ClassNotFoundException {
      in.defaultReadObject();
      try{
         Cipher cipher = Cipher.getInstance(CIPHER);
         cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(KEY, CIPHER));
         payload = cipher.doFinal(payload);
      } catch (Exception e){ throw new IOException(e.toString()); }
   }
   /**
    * The cryptographic algorithm used to secure the object. In this case
    * triple DES. To use a different algorithm, subclass and assign it a
    * new identifier, but <b>only</b> in a static initializer block!
    */
   protected static String CIPHER;
   /**
    * A 24 byte array of data to create the secret key used to encrypt and
    * decrypt the object. It should be completely randomly chosen values.
    * The key is declared static, to prevent it from being sent along with
    * the encrypted object, over the network. Don't overwrite the key here,
    * subclass and assign it a unique value, but <b>only</b> in a static
    * initializer block!
    */
   protected static byte[] KEY;
   static { // base class static initializer block:
      CIPHER = "DESede"; // not really necessary to override
      KEY = new byte[] { // definitely necessary to override
         (byte)0x76, (byte)0x6F, (byte)0xBA, (byte)0x39, (byte)0x31, (byte)0x2F,
         (byte)0x0D, (byte)0x4A, (byte)0xA3, (byte)0x90, (byte)0x55, (byte)0xFE,
         (byte)0x55, (byte)0x65, (byte)0x61, (byte)0x13, (byte)0x34, (byte)0x82,
         (byte)0x12, (byte)0x17, (byte)0xAC, (byte)0x77, (byte)0x39, (byte)0x19
      };
   }
   /**
    * The constructor simply invokes the superclass ZippedProxy constructor.
    * @param proxy The object, to be hashed at the server, and unhashed at
    * the client. It is for any object needing secure transmission between
    * remote Virtual Machines.
    */
   public CryptObject(Object object) { super(object); }

 * cajo object oriented rule engine
 * Copyright (C) 2006 John Catherino
 * The cajo project: https://cajo.dev.java.net
 *
 * For issues or suggestions mailto:cajo@dev.java.net
 *
 * This file RuleEngine.java is part of the cajo library.
 *
 * The cajo library is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public Licence as published
 * by the Free Software Foundation, at version 3 of the licence, or (at your
 * option) any later version.
 *
 * Th cajo library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public Licence for more details.
 *
 * You should have received a copy of the GNU Lesser General Public Licence
 * along with this library. If not, see http://www.gnu.org/licenses/lgpl.html
 */

/**
 * This class is a cajo-based reformulation of rule-based reasoning systems,
 * for declarative programming. This engine does not suffer from the large
 * memory requirements associated with the Rete Algorithm, as it offloads
 * each rule's state and inference to distributed JVMs. The engine is also
 * serialisable; to allow it to scale, as well as providing both modularity,
 * and redundancy.<p>
 * A rule engine can be likened to a database, with some important
 * differences. In database parlance, what is known as the schema is called
 * an ontology in a rule engine. Unlike a database, multiple facts are
 * deposited in any given slot, a database is somewhat less dynamic in its
 * change of existing data. Data in a database are called facts in a Rule
 * engine. A database supports queries on its stored data, this is not
 * possible for the rule engine, as it sends its facts to registered
 * listeners. Unlike the Java language, an ontology logically, and therefor
 * must, support multiple inheretance.<p>
 * Since only the RuleEngine ontology is stored at the server host, and
 * not the fact base; this makes the creation of extremely large distributed
 * rule bases both possible, and very simple. The applciation specific
 * knowledge bases are offloaded to the clients as well.<p>
 * The application of both fuzzy facts, and fuzzy predicates is not only
 * easily supported, but is in fact very <i>highly</i> recommended.<p>
 * <i><u>Note</u>:</i> to compile this class, it is best to set the java
 * compiler's <tt>-source</tt> switch to <tt>1.2</tt>.
 *
 * @version 1.0, 11-May-06
 * @author John Catherino
 */
public class RuleEngine implements java.io.Serializable {
   /**
    * This is a good base class for building rules. It minimises load
    * on the rule engine, and properly manages asynchronous change without
    * synchronisation, or deadlock problems. It is highly recommended to
    * extend this class for your rules. The collection of registered rules
    * constitute the <i>knowledge base</i> of the rule engine.
    */
   public static class Rule implements java.io.Serializable {
      /**
       * The rule specific local fact base on which to infer. It allows
       * a rule to encompass many different aspects of an ontology.
       */
      protected Hashtable facts = new Hashtable();
      /**
       * This flag indicates that asynchronous modification has been
       * made to the fact base. <i><u>Very Important</u>:</i>
       * The <i>first</i> instruction of the infer method should be to
       * set it false.
       */
      protected boolean change;
      /**
       * The local reasoning thread. It is lazily instantiated, and can
       * be shut down by calling its interrupt method, if necessary.
       * It's job is to call the infer method whenever there is a
       * change (addidion, removal, modification) to the local fact
       * base.
       */
      protected transient Thread thread;
      /**
       * This method is completely rule-specific. It is called when there
       * has been a change to the local fact base. It should first
       * reset the change flag, which is done simply by calling super(),
       * then evaluate its state to make decisions. It is possible for the
       * fact base to be actively changing, while this method is executing.
       * This can be detected by monitoring the state of the change flag.
       */
      protected void infer() { change = false; }
      /**
       * This method extracts the Hashtable corresponding to the provided
       * key series. If a path to the Hashtable does not exist, it will be
       * created automatically. It is called by the posit method, but it
       * is also a handy utility for the infer method, to check the status
       * of interesting data elements.
       * @param keys The ordered sequence of candidate keys leading to the
       * fact storage position in the fact base.
       * @return The hashtable indexed one key before the final in the
       * array. The fact of interest is located in this table, at the
       * final key value.
       */
      protected synchronized Hashtable select(Object keys[]) {
         Hashtable element = (Hashtable)facts.get(keys[0]);
         for (int i = 1; i < keys.length - 1; i++) {
            Object temp = element.get(keys[i]);
            if (temp == null)  { // if no path, make one!
               temp = new Hashtable();
               element.put(keys[i], temp);
            }
            element = (Hashtable)temp;
         }
         return element;
      }
      /**
       * This method is invoked by the rule engine to make a change,
       * addition or modification, to the local fact base. It will
       * notify the local processing thread, creating it if necessary, and
       * return. Its run time is designed to be as short as possible, and
       * should not be overridden, unless it is absolutely critical.
       * @param fact A datum of interest, which has been changed at the
       * rule engine.
       * @param keys The ordered sequence of candidate keys leading to the
       * fact storage position in the fact base.
       */
      public synchronized void posit(Object fact, Object keys[]) {
         select(keys).put(keys[keys.length - 1], fact);
         change = true;
         if (thread == null) {
            thread = new Thread(new Runnable() {
               public void run() {
                  try {
                     while (true) {
                        infer();
                        synchronized(Rule.this) {
                           while(!change) Rule.this.wait();
                        }
                     }
                  } catch(InterruptedException x) {}
               }
            });
            thread.start();
         } else notify();
      }
   }
   /**
    * This field represents the set of listening rules registered in the
    * engine's ontology. The element stored under each key can be either a
    * Vector, indicating a collection of listening rules, or another
    * Hashtable, indicating an additional dimension to the knowledge base.
    * This allows for an n-ary dimensional organisation of rules references,
    * structured about keys. Rules are generally assumed to be references to
    * objects in remote JVMs, but that can be local object references, if
    * necessary. Multiple rules can be assigned to the same dimension, just
    * as the same rule can be assigned to multiple dimension.
    */
   protected final Hashtable rules = new Hashtable();
   /**
    * This method is called by the public assert method. It will
    * recursively traverse through the ontology, invoking one or more
    * assertions based on the key sequence provided.<p>
    * @param rules The ontology on which to operate.
    * @param keys The chain of keys leading to the element(s) of interest
    * in the ontology. If any key value is null, it is considered a wild
    * card, resulting in all of the keys at that dimension being used.
    * @param offset The index into the provided key sequence.
    * @param data A two element array containing the fact and the key
    * sequence array. It will be provided to each listening rule as the
    * arguments to its posit method.
    */
   protected static void posit(
      Hashtable rules, Object keys[], int offset, Object data) {
      try {
         if (keys[offset] != null) { // fixed key, linear recursion
            if (offset == keys.length - 1) { // boundary condition
               Object listeners[] =
                  ((Vector)rules.get(keys[offset])).toArray();
               for (int i = 0; i < listeners.length; i++) try {
                  Remote.invoke(listeners[i], "posit", data);
               } catch(Exception x) {
                  ((Vector)rules.get(listeners[i])).remove(listeners[i]);
               }
            } else posit((Hashtable)rules.get(keys[offset]),
               keys, offset + 1, data); // continue recursing
         } else {  // wildcard, n-ary recursion
            Enumeration wildKeys = rules.keys();
            while(wildKeys.hasMoreElements())
               posit((Hashtable)rules.get(wildKeys.nextElement()),
                  keys, offset + 1, data);
         }
      } catch(ClassCastException x) {} // invalid key path, ignore
   }
   /**
    * This method is called by the public add method. It will
    * recursively traverse through the ontology, invoking one or more
    * rule locations based on the key sequence provided.<p>
    * @param rules The ontology on which to operate.
    * @param keys The chain of keys leading to the element(s) of interest
    * in the ontology. If any key value is null, it is considered a wild
    * card, resulting in all of the keys at that dimension being used.
    * @param offset The index into the provided key sequence.
    */
   protected static void add(
      Hashtable rules, Object rule, Object keys[], int offset) {
      try {
         if (keys[offset] != null) { // fixed key, linear recursion
            synchronized(rules) { // get next path node
               Hashtable table = (Hashtable)rules.get(keys[offset]);
               if (table == null) { // if no node, make one!
                  table = new Hashtable();
                  rules.put(keys[offset], table);
               }
            }
            rules = (Hashtable)rules.get(keys[offset]);
            if (offset == keys.length - 1) { // boundary condition
               Vector vector = (Vector)rules.get(keys[keys.length - 1]);
               if (vector == null) {
                  vector = new Vector();
                  rules.put(keys[keys.length - 1], vector);
               }
               vector.add(rule);
            } else add(rules, rule, keys, offset + 1); // continue recursing
         } else {  // wildcard, n-ary recursion
            Enumeration wildKeys = rules.keys();
            while(wildKeys.hasMoreElements())
               add((Hashtable)rules.get(wildKeys.nextElement()),
                  rule, keys, offset + 1);
         }
      } catch(ClassCastException x) {} // invalid key path, ignore
   }
   /**
    * This method is called by the public remove method. It will
    * recursively traverse through the ontology, removing one or more
    * rule locations based on the key sequence provided.<p>
    * @param rules The ontology on which to operate.
    * @param keys The chain of keys leading to the element(s) of interest
    * in the ontology. If any key value is null, it is considered a wild
    * card, resulting in all of the keys at that dimension being used.
    * @param offset The index into the provided key sequence.
    */
   protected static void remove(
      Hashtable rules, Object rule, Object keys[], int offset) {
      try {
         if (keys[offset] != null) { // fixed key, linear recursion
            rules = (Hashtable)rules.get(keys[offset]);
            if (offset == keys.length - 1) { // boundary condition
               Vector vector = (Vector)rules.get(keys[keys.length - 1]);
               vector.remove(rule);
            } else remove(rules, rule, keys, offset + 1); // continue
         } else {  // wildcard, n-ary recursion
            Enumeration wildKeys = rules.keys();
            while(wildKeys.hasMoreElements())
               remove((Hashtable)rules.get(wildKeys.nextElement()),
                  rule, keys, offset + 1);
         }
      } catch(ClassCastException x) {} // invalid key path, ignore
   }
   /**
    * This constructor performs no function, as the operation of the rule
    * engine is completely runtime dependent.
    */
   public RuleEngine() {}
   /**
    * This method is used to assert, or modify, a fact. The engine will
    * search its ontology for suitable listeners, and notify them.
    * Each rule will be notified serially, by invoking its public
    * <tt>posit</tt> method, with the fact object, and the collection of
    * keys. If a rule instance determines all of its criteria necessary for
    * firing has been met, then it is the responsibility of that rule to
    * carry it out. It simply invokes the static posit method to begin
    * a recursive ontology traversal.<p>
    * <i><u>Note</u>:</i> Rule <tt>posit</tt> invocations are expected to
    * return as quickly as possible to ensure maximum performance of the
    * engine. Typically rule objects will save the fact argument in a queue,
    * notify a waiting local thread, and return. A rule generally will
    * register for multiple fact types, therefore its posit method most
    * likely <i>will</i> be invoked reentrantly. Also, if the invocation
    * of the rule results in an Exception, it will be removed from the
    * collection of listeners for that element.
    * @param fact The fact that is being asserted or changed.
    * @param keys The chain of keys leading to the element of interest
    * in the ontology. If the key sequence does not exist in the ontology,
    * the invocation will be ignored silently.
    */
   public void posit(Object fact, Object keys[]) {
      posit(rules, keys, 0, new Object[] { fact, keys });
   }
   /**
    * This method is used to register a rule instance with the ontology.
    * The rule engine will store the rule reference, to have its
    * <tt>posit</tt> method invoked, as the state of the fact of interest
    * changes. It is worth mentioning, a single rule instance is often used
    * to monitor multiple types of facts. It simply invokes the static
    * add method, to begin the recursive ontology traversal to add the rule.
    * @param rule The rule to be notified when the fact state changes. It is
    * typically a reference to an object in a remote JVM, but it can be to
    * a local object, or even a proxy object.
    * @param keys The chain of keys leading to the element of interest
    * in the fact base. If the path does not exist, it will be created
    * implicitly.
    */
   public void add(Object rule, Object keys[]) {
      add(rules, rule, keys, 0);
   }
   /**
    * This method is used to unregister a rule instance for a type of 
    * fact. The rule engine will delete the rule reference from its
    * ontology. It simply invokes the static remove method, to begin the
    * recursive ontology traversal to delete the rule.
    * @param rule The rule to be removed from the engine. It is typically a
    * reference to an object in a remote JVM, but it can be to a local
    * object, or even a proxy object.
    * @param keys The chain of keys leading to the element of interest
    * in the ontology. If the key sequence does not exist in the ontology,
    * the invocation will be ignored silently.
    */
   public void remove(Object rule, Object keys[]) {
      remove(rules, rule, keys, 0);
   }
}
