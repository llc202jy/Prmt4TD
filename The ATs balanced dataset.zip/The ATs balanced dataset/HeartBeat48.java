hort kcq_CheckSystemHealthQM1(t_kinTsk *Tsk)
/* Do some checks, to see if we are still connected to important places.
  If not, take corrective actions. Returns 0=nothing done (so keep aware), else, Stp has changed */
{
  // Nothing to do as QM1, kc_CheckSystemHealth at kincore_boot will do the common surveillance for any node
  return 0;
}

/* Task methods */
int kcore_qm1_Init(pt_kinTsk Tsk, t_kinPktHd *Pkt)
/* Init task that manages init sequence when I'm the only QM in the system (first one) */
{
  bzero(&Tsk->lb,sizeof(Tsk->lb));
  return k_kintsk_stRun;
}

int kcore_qm1_Proc(pt_kinTsk Tsk)
/* Main task body that manages init sequence when I'm the only QM in the system (first one) */
{
  t_kinconCB       *cc;

  switch (Tsk->lb.b.wa)
    {
    // Very first time, become QM1
    case 0:
      kcq_BecomeQM1(Tsk);
      Tsk->lb.b.wa=10;
      Tsk->lb.b.wb=0;
      return k_kintsk_stRun;

    // Just wait till I have a connection to BM
    case 10:
      cc=kincon_GetConType(k_core_NodeBM);   // Do we have a connection to a BM?
      if (cc)                    // Yes, we are lucky!
         {
         Tsk->lb.b.wa=20;        // Do next step: query BM...
         //return k_kintsk_stRun;  // Keep runnning; by now, just step onto next case:
         }
      else                       // Wait. Set a timer to interrupt, but wait longer and longer as failure persists
         {
         Tsk->lb.b.wb++;
         if (Tsk->lb.b.wb<10)
            kintsk_SetGenWD(Tsk->tID,2,1);
         else if (Tsk->lb.b.wb<50)
            kintsk_SetGenWD(Tsk->tID,5,1);
         else
            kintsk_SetGenWD(Tsk->tID,20,1);
         break;
         }

    // Do some requests to BM
    case 20:
      Tsk->lb.b.wa=30;
    // Request object universe, as I'm QM1 and there's no OL into the whole system
    case 30:
      kintsk_SetGenWD(Tsk->tID,3,2); // Tick to detect no response in 3 seconds (usually happens if connected right now: too early to request anything)
      if (kcq_RequestObjectUniverse(Tsk)==0)
         Tsk->lb.b.wa++;
      // If sending request failed, we will retry next time (Step was not changed)
      break;
    case 31:
      break;                     // Just wait forever, Event will change this going to Stp=32
      // Here I should start a timer to detect absence of answer in a reasonable time...
    case 32:                     // Something failed (perhaps there's no universe data)
      break;                     // Just remain here forever, by now, till I know what to do (Abort?)
    case 33:
      Tsk->lb.b.wa=40;           // Received Universe definition

    // Received (and processed) Universe Definition. Now request object definitions
    case 40:
      Tsk->lb.b.wb=0;            // Used as index
      Tsk->lb.b.wc=0;            // Used as pending answers
      Tsk->lb.b.wa++;            // Go to next step
    case 41:
      if (kcq_RequestObjectDefinitions(Tsk)==0)
         Tsk->lb.b.wa=50;        // Finished
      else
         return k_kintsk_stWaitW;// Keep waiting for some room more to write
      break;
    case 42:                     // Get here if received an error while still sending requests
      Tsk->lb.b.wa=51;           // Normal error processor
    // Waiting for object definitions
    case 50:
      if (Tsk->lb.b.wc>0)        // Still waiting for some answers
         break;
      Tsk->lb.b.wa=60;           // Finished, got all definitions
      return k_kintsk_stRun;
    case 51:                     // Get here if an error receiving
      Tsk->lb.b.wa=50;           // I don't know how to handle it, so just ignore... and get the rest.
      if (Tsk->lb.b.wc>0)
         Tsk->lb.b.wc--;         // Believe it is an answer from a request I sent
      return k_kintsk_stRun;
    // Received Object Definitions
    case 60:
      // As I'm QM1, there's no OIL (Object Instances List), have to generate one if there's some IM available
      kc_GenerateODIL();        // Currently, this is into kincore_boot
      /*
      /// _HaveToDetermineIfComesHereOrIntoKinCoreBoot_
      // If I'm the only QM running on system, I have to generate a list of object instances, based on available IMs
      // If there's already another QM, it should have the current list, but may also be booting
      if (kc_RequestObjectBrokerList(Tsk)==0)
         Tsk->lb.b.wa=70;       // Wait for answers
      else
         Tsk->lb.b.wa=100;      // Build an Object Instances List
      return k_kintsk_stRun;
    // Waiting for object instances list
    case 70:
      if (Tsk->lb.b.wc>0)       // Still waiting for some answers (one per known QM)
         break;
      Tsk->lb.b.wa=70;          // Finished, got all definitions
      return k_kintsk_stRun;
    case 71:                    // Get here if an error receiving
      Tsk->lb.b.wa=70;          // I don't know how to handle it, so just ignore... and get the rest.
      if (Tsk->lb.b.wc>0)
         Tsk->lb.b.wc--;        // Believe it is an answer from a request I sent
      return k_kintsk_stRun;
    case 71:                    // Get here if no Object Instances List is available at some QM
      if (Tsk->lb.b.wc>0)       // Still some QM to answer
         Tsk->lb.b.wa=70;       // I don't know how to handle it, so just ignore... and get the rest.
      else                      // No valid answers, will generate one list on my own
         Tsk->lb.b.wa=100;      // I don't know how to handle it, so just ignore... and get the rest.
      return k_kintsk_stRun;
    // Received all the Object Instances. All is done
    case 80:
      */
      Tsk->lb.b.wa=1000;        // Start monitor mode
      return k_kintsk_stRun;    // Finished
      /*
      /// _HaveToDetermineIfComesHereOrIntoKinCoreBoot_

    // Build Object Instances List
    case 100:
      kc_BuildObjectInstanceList(Tsk);
      Tsk->lb.b.wa=80;
      return k_kintsk_stRun;    // Finished
      */

    // Monitor mode: just start timer and keep an eye on some system sanity
    case 1000:
      kintsk_SetGenWD(Tsk->tID,5,1000);
      Tsk->lb.b.wa++;
      break;
    case 1001:
      break;                    // Stay here!
    case 1002:                  // Timer woke me up, let's check system's health
      if (kcq_CheckSystemHealthQM1(Tsk)==0)
         Tsk->lb.b.wa=1000;     // Back to watchdog timer
      return k_kintsk_stRun;

    case 2000:  // Reinit
      break;                    // Do nothing by now, but should init like Stp==0 but with care

    case 65535: // Ooops!
      break;
    default:    // Keep Stp rolling to catch up next execution line
      Tsk->lb.b.wa++;
    }
  return k_kintsk_stSleep;       // By default, just sleep waiting for some event...
}

int kcore_qm1_Event(pt_kinTsk Tsk, Word eType, Word pSz, void *Param)
/* Event manager for task that manages init sequence when I'm the only QM in the system (first one) */
{
  t_kinPktHd       *Pkt;

  switch (eType)
    {
    case k_kintskEv_rPkt:   // Diverted packet
      if ( !Param || (pSz<sizeof(t_kinPktHd)) )
         break;
      Pkt=(t_kinPktHd *)Param;
      if (pSz<Pkt->Sz)
         break;
      Log(k_dallog_Debug,"kincore_qm1_Event: received packet 0x%04x",Pkt->Op);
      switch (Pkt->Op)
        {
        case k_PktHdOp_storLA:   // Storage Load Ack, probably answer to a Universe definition request
          kcq_storLA(Tsk,Pkt);
          return k_kintsk_stRun; // Wake up the task
          break;
        }
      break;
    case k_kintskEv_wdTO:
      // Probably a user timer
      if (Param && (pSz>=sizeof(u32)) )
         {
         switch (*((u32 *)Param))
           {
           case 1:      // Tick, just run task
             return k_kintsk_stRun; // Wake up task
           case 2:      // Timeout waiting for Universe definition
             if (Tsk->lb.b.wa==31)
                Tsk->lb.b.wa=30;    // Retry
             return k_kintsk_stRun; // Wake up task
           case 1000:
             Tsk->lb.b.wa++;     // Advance execution
             return k_kintsk_stRun; // And wake up task
             break;
           }
         }
      break;
    }
  return k_kintsk_stSame;        // Default is to leave things the same
}

int kincore_qm1_Init(Word pSz, void *Param)
/* Initializes this module. Param is t_kincore_qm1_InitP */
{
  // Basically, it creates a task that manages some QM internal variables and tables
  // and gets universe information from a BM, when it becomes available
  // This task should live forever, to keep things updated, but if it dies, parent
  // will receive notification
  t_kincore_qm1_InitP *ep;
  t_kinTsk         *Tsk;
  t_kinTskCtlProcs  Met;
  static u32        itID = 0;

  if ( !Param || (pSz<sizeof(t_kincore_qm1_InitP)) )
     return -1;
  ep=(t_kincore_qm1_InitP *)Param;
  bzero(&Met,sizeof(Met));
  if (itID)                      // Already initialized, this is a reinit process
     Tsk=kintsk_GetTsk(itID);
  else
     Tsk=NULL;
  if (!Tsk)
     {
     Met.Init=kcore_qm1_Init;
     Met.Proc=kcore_qm1_Proc;
     Met.Event=kcore_qm1_Event;
     Tsk=kintsk_CreateAut(&Met,64,ep->ptID);
     }
  if (Tsk)
     {
     strcpy(&Tsk->Name[0],"core_qm1");
     if (itID)
        Tsk->lb.b.wa=2000;       // Reinit
     itID=Tsk->tID;
     return 0;
     }
  else
     return -2;
}
