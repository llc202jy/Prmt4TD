namespace CCNetConfig.Updater {
  public partial class MainForm : Form {
    ApplicationUpdater au = null;
    private delegate void GenericDelegate ( );
    private delegate void UpdateLabel ( string text );
    private delegate void UpdateProgressBar ( int value );
    private delegate void ExceptionMessageDelegate ( Exception ex );
    /// <summary>
    /// Initializes a new instance of the <see cref="MainForm"/> class.
    /// </summary>
    public MainForm ( ) {
      InitializeComponent ( );
      this.progressBar1.Maximum = 100;
      this.progressBar1.Minimum = 0;
      this.progressBar1.Value = 0;

      au = new ApplicationUpdater ( );
      au.Version = new Version ( Application.ProductVersion );
      if ( !string.IsNullOrEmpty ( Program.CallingApplication ) )
        au.OwnerApplication = new FileInfo ( Program.CallingApplication );

      au.UpdateAvailable += new EventHandler<UpdatesAvailableEventArgs> ( au_UpdateAvailable );
      au.UpdateException += new EventHandler<ExceptionEventArgs> ( au_UpdateException );
      au.DownloadProgressChanged += new EventHandler<DownloadProgressEventArgs> ( au_DownloadProgressChanged );
      au.UpdateScriptCreated += new EventHandler ( au_UpdateScriptCreated );
      au.UpdateException += new EventHandler<ExceptionEventArgs> ( au_UpdateException );
    }

    /// <summary>
    /// Raises the <see cref="E:System.Windows.Forms.Form.Load"></see> event.
    /// </summary>
    /// <param name="e">An <see cref="T:System.EventArgs"></see> that contains the event data.</param>
    protected override void OnLoad ( EventArgs e ) {
      base.OnLoad ( e );
      au.CheckForUpdate ( Program.UpdateCheckType );
    }

    /// <summary>
    /// Handles the UpdateScriptCreated event of the au control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
    void au_UpdateScriptCreated ( object sender, EventArgs e ) {
      if ( au.ScriptFile.Exists )
        System.Diagnostics.Process.Start ( au.ScriptFile.FullName );
      else
        MessageBox.Show ( string.Format ( "Error running update script.\n\nCould not find file {0}", au.ScriptFile.FullName ), "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1 );
      if ( this.InvokeRequired )
        this.Invoke ( new GenericDelegate ( this.Close ), new object[ ] { } );
      else
        this.Close ( );

    }

    /// <summary>
    /// Handles the DownloadProgressChanged event of the au control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="CCNetConfig.Updater.Core.DownloadProgressEventArgs"/> instance containing the event data.</param>
    void au_DownloadProgressChanged ( object sender, DownloadProgressEventArgs e ) {
      string fileName = e.UpdateFile.Location.ToString ( );
      fileName = fileName.Substring ( fileName.LastIndexOf ( "/" ) );
      if ( this.InvokeRequired ) {
        this.Invoke ( new UpdateLabel ( this.UpdateStatusLabel ), new object[ ] { string.Format ( "Downloading {0} : {1}%", fileName, e.Percentage.ToString ( ) ) } );
        this.Invoke ( new UpdateProgressBar ( this.UpdateStatusProgressBar ), new object[ ] { e.Percentage } );
      } else {
        this.UpdateStatusLabel ( string.Format ( "Downloading {0} : {1}%", fileName, e.Percentage.ToString ( ) ) );
        this.UpdateStatusProgressBar ( e.Percentage );
      }
    }


    /// <summary>
    /// Handles the UpdateException event of the au control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="CCNetConfig.Updater.Core.ExceptionEventArgs"/> instance containing the event data.</param>
    void au_UpdateException ( object sender, ExceptionEventArgs e ) {
      //Console.WriteLine ( e.Exception.ToString () );
      if ( this.InvokeRequired )
        this.Invoke ( new ExceptionMessageDelegate ( this.ShowExceptionMessage ), new object[ ] { e.Exception } );
      else
        ShowExceptionMessage ( e.Exception );
    }

    /// <summary>
    /// Shows the exception message.
    /// </summary>
    /// <param name="ex">The ex.</param>
    private void ShowExceptionMessage ( Exception ex ) {
      MessageBox.Show ( this, ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error );

    }

    /// <summary>
    /// Handles the UpdateAvailable event of the au control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
    void au_UpdateAvailable ( object sender, UpdatesAvailableEventArgs e ) {
      Version ver = au.UpdateInfoList.GetLatestVersion ( );
      Thread t = new Thread ( new ParameterizedThreadStart ( GetUpdates ) );
      t.Start ( ver );
    }

void GetUpdates ( object version ) {
      if ( version.GetType ( ) == typeof ( Version ) )
        au.GetUpdates ( version as Version );
    }

    /// <summary>
    /// Updates the status label.
    /// </summary>
    /// <param name="text">The text.</param>
    private void UpdateStatusLabel ( string text ) {
      this.lblStatus.Text = text;
    }

    /// <summary>
    /// Updates the status progress bar.
    /// </summary>
    /// <param name="val">The val.</param>
    private void UpdateStatusProgressBar ( int val ) {
      this.progressBar1.Value = val;
    }
  }
}
namespace CCNetConfig.Updater {
  /// <summary>
  /// The main form for the updater
  /// </summary>
  partial class MainForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose ( bool disposing ) {
      if ( disposing && ( components != null ) ) {
        components.Dispose ();
      }
      base.Dispose ( disposing );
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent () {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager ( typeof ( MainForm ) );
      this.progressBar1 = new System.Windows.Forms.ProgressBar ();
      this.lblStatus = new System.Windows.Forms.Label ();
      this.cancelButton = new System.Windows.Forms.Button ();
      this.SuspendLayout ();
      // 
      // progressBar1
      // 
      this.progressBar1.Location = new System.Drawing.Point ( 12, 25 );
      this.progressBar1.Name = "progressBar1";
      this.progressBar1.Size = new System.Drawing.Size ( 519, 37 );
      this.progressBar1.TabIndex = 0;
      // 
      // lblStatus
      // 
      this.lblStatus.AutoSize = true;
      this.lblStatus.Location = new System.Drawing.Point ( 12, 6 );
      this.lblStatus.Name = "lblStatus";
      this.lblStatus.Size = new System.Drawing.Size ( 124, 13 );
      this.lblStatus.TabIndex = 1;
      this.lblStatus.Text = "Initializing, Please Wait...";
      // 
      // CancelButton
      // 
      this.cancelButton.Location = new System.Drawing.Point ( 402, 68 );
      this.cancelButton.Name = "CancelButton";
      this.cancelButton.Size = new System.Drawing.Size ( 129, 34 );
      this.cancelButton.TabIndex = 2;
      this.cancelButton.Text = "&Cancel";
      this.cancelButton.UseVisualStyleBackColor = true;
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF ( 6F, 13F );
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size ( 543, 110 );
      this.Controls.Add ( this.cancelButton );
      this.Controls.Add ( this.lblStatus );
      this.Controls.Add ( this.progressBar1 );
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Icon = ( (System.Drawing.Icon)( resources.GetObject ( "$this.Icon" ) ) );
      this.MaximizeBox = false;
      this.Name = "MainForm";
      this.ShowInTaskbar = false;
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.ResumeLayout ( false );
      this.PerformLayout ();

    }

    #endregion

    private System.Windows.Forms.ProgressBar progressBar1;
    private System.Windows.Forms.Label lblStatus;
    private System.Windows.Forms.Button cancelButton;
  }
}
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using CCNetConfig.Core.Enums;

namespace CCNetConfig.Core.Configuration {
  /// <summary>
  /// The update settings for CCNetConfig
  /// </summary>
  [XmlRoot ( "UpdateSettings" )]
  public class UpdateSettings {
    private bool _checkOnStartup = true;
    private UpdateCheckType _checkType = UpdateCheckType.ReleaseBuilds;
    private UpdateProxySettings _proxySettings = null;
    private bool _showOnlyLatestVersion = true;
    private string _launchArgumentsFormat = "/mode={0} /version={2} /app={1}";
    private string _updaterApplication = "CCNetConfig.Updater.exe";
    /// <summary>
    /// Initializes a new instance of the <see cref="UpdateSettings"/> class.
    /// </summary>
    public UpdateSettings () {
      _proxySettings = new UpdateProxySettings ();
    }
    /// <summary>
    /// Gets or sets the updater application.
    /// </summary>
    /// <value>The updater application.</value>
    [ XmlElement( "UpdaterApplication" ) ]
    public string UpdaterApplication { get { return this._updaterApplication; } set { this._updaterApplication = value; } }

    /// <summary>
    /// Gets or sets the launch arguments format.
    /// </summary>
    /// <value>The launch arguments format.</value>
    [ XmlElement( "LaunchArgumentsFormat" ) ]
    public string LaunchArgumentsFormat { get { return this._launchArgumentsFormat; } set { this._launchArgumentsFormat = value; } }
    /// <summary>
    /// Gets or sets a value indicating whether [check on startup].
    /// </summary>
    /// <value><c>true</c> if [check on startup]; otherwise, <c>false</c>.</value>
    [XmlElement ( "CheckOnStartup" )]
    public bool CheckOnStartup { get { return this._checkOnStartup; } set { this._checkOnStartup = value; } }

    /// <summary>
    /// Gets or sets the type of the update check.
    /// </summary>
    /// <value>The type of the update check.</value>
    [XmlElement ( "CheckType" )]
    public UpdateCheckType UpdateCheckType { get { return this._checkType; } set { this._checkType = value; } }

    /// <summary>
    /// Gets or sets the proxy settings.
    /// </summary>
    /// <value>The proxy settings.</value>
    [XmlElement ( "ProxySettings" )]
    public UpdateProxySettings ProxySettings {
      get { return this._proxySettings; }
      set { this._proxySettings = value; }
    }

    /// <summary>
    /// Gets or sets a value indicating whether to only show the latest version information in the update dialog.
    /// </summary>
    /// <value>
    /// 	<c>true</c> if [show only latest version]; otherwise, <c>false</c>.
    /// </value>
    [XmlElement ( "ShowOnlyLatestVersion" )]
    public bool ShowOnlyLatestVersion { get { return this._showOnlyLatestVersion; } set { this._showOnlyLatestVersion = value; } }
  }
}
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.ComponentModel;

namespace CCNetConfig.Core.Configuration {
  /// <summary>
  /// Represents the settings for CCNetConfig
  /// </summary>
  [XmlRoot ( "CCNetConfig.Settings" )]
  public class CCNetConfigSettings {
    private ComponentSettingsList _components = null;
    private UpdateSettings _updateSettings = null;
    private BackupSettings _backupSettings = null;

    private string _externalViewer = string.Empty;
    private string _externalViewerArguments = string.Empty;
    private bool _minimizeToTray = false;
    private bool _minimizeOnClose = false;
    private bool _watchForChanges = false;
    private bool _sortProjects = false;

    /// <summary>
    /// Initializes a new instance of the <see cref="CCNetConfigSettings"/> class.
    /// </summary>
    public CCNetConfigSettings () {
      _components = new ComponentSettingsList ();
      _updateSettings = new UpdateSettings ();
      _backupSettings = new BackupSettings ();
      _externalViewer = Properties.Resources.DefaultExternalViewer;
      _externalViewerArguments = Properties.Resources.DefaultExternalViewerArguments;
    }

    /// <summary>
    /// Gets or sets the components.
    /// </summary>
    /// <value>The components.</value>
    [XmlArray ( "Components" ), XmlArrayItem ( "Component" )]
    public ComponentSettingsList Components { get { return this._components; } set { this._components = value; } }

    /// <summary>
    /// Gets or sets the update settings.
    /// </summary>
    /// <value>The update settings.</value>
    [XmlElement ( "UpdateSettings" )]
    public UpdateSettings UpdateSettings { get { return this._updateSettings; } set { this._updateSettings = value; } }

    /// <summary>
    /// Gets or sets the backup settings.
    /// </summary>
    /// <value>The backup settings.</value>
    [XmlElement ( "BackupSettings" )]
    public BackupSettings BackupSettings { get { return this._backupSettings; } set { this._backupSettings = value; } }

    /// <summary>
    /// Gets or sets the external viewer.
    /// </summary>
    /// <value>The external viewer.</value>
    [XmlElement ( "ExternalViewer" )]
    public string ExternalViewer { get { return this._externalViewer; } set { this._externalViewer = string.IsNullOrEmpty(value) ? Properties.Resources.DefaultExternalViewer : value; } }

    /// <summary>
    /// Gets or sets the external viewer arguments.
    /// </summary>
    /// <value>The external viewer arguments.</value>
    [XmlElement ( "ExternalViewerArguments" )]
    public string ExternalViewerArguments { get { return this._externalViewerArguments; } set { this._externalViewerArguments = string.IsNullOrEmpty(value) ? Properties.Resources.DefaultExternalViewerArguments : value; } }

    /// <summary>
    /// Gets or sets a value indicating whether [minimize to tray].
    /// </summary>
    /// <value><c>true</c> if [minimize to tray]; otherwise, <c>false</c>.</value>
    [XmlElement ( "MinimizeToTray" )]
    public bool MinimizeToTray { get { return this._minimizeToTray; } set { this._minimizeToTray = value; } }

    /// <summary>
    /// Gets or sets a value indicating whether [minimize to tray on close].
    /// </summary>
    /// <value>
    /// 	<c>true</c> if [minimize to tray on close]; otherwise, <c>false</c>.
    /// </value>
    [XmlElement ( "MinimizeToTrayOnClose" )]
    public bool MinimizeToTrayOnClose { get { return this._minimizeOnClose; } set { this._minimizeOnClose = value; } }

    /// <summary>
    /// Gets or sets a value indicating whether [watch for file changes].
    /// </summary>
    /// <value>
    /// 	<c>true</c> if [watch for file changes]; otherwise, <c>false</c>.
    /// </value>
    [XmlElement ( "WatchForFileChanges" )]
    public bool WatchForFileChanges { get { return this._watchForChanges; } set { this._watchForChanges = value; } }

    /// <summary>
    /// Gets or sets a value indicating whether to sort the project.
    /// </summary>
    /// <value>
    /// 	<see langword="true"/> if projects should be sorted; otherwise, <see langword="false"/>.
    /// </value>
    [XmlElement ( "SortProjects" )]
    public bool SortProject { get { return this._sortProjects; } set { this._sortProjects = value; } }
  }
}
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.Net;

namespace CCNetConfig.Core.Configuration {
  /// <summary>
  /// Proxy Information used when connecting to check for updates.
  /// </summary>
  [ XmlRoot( "ProxyInfo" ) ]
  public class UpdateProxySettings {
    private bool _useProxy = false;
    private string _host = string.Empty;
    private int _port = 8080;
    private string _user = string.Empty;
    private string _password = string.Empty;
    
    /// <summary>
    /// Initializes a new instance of the <see cref="UpdateProxySettings"/> class.
    /// </summary>
    public UpdateProxySettings () {

    }

    /// <summary>
    /// Gets or sets a value indicating whether [use proxy].
    /// </summary>
    /// <value><c>true</c> if [use proxy]; otherwise, <c>false</c>.</value>
    [ XmlAttribute( "UseProxy" ) ]
    public bool UseProxy { get { return this._useProxy; } set { this._useProxy = value; } }

    /// <summary>
    /// Gets or sets the proxy port.
    /// </summary>
    /// <value>The proxy port.</value>
    [ XmlElement( "ProxyPort" ) ]
    public int ProxyPort { get { return this._port; } set { this._port = value; } }
    /// <summary>
    /// Gets or sets the proxy server.
    /// </summary>
    /// <value>The proxy server.</value>
    [ XmlElement( "ProxyServer" ) ]
    public string ProxyServer { get { return this._host; } set { this._host = value; } }

    /// <summary>
    /// Gets or sets the username.
    /// </summary>
    /// <value>The username.</value>
    [ XmlElement( "Username" ) ]
    public string Username { get { return this._user; } set { this._user = value; } }

    /// <summary>
    /// Gets or sets the password encoded.
    /// </summary>
    /// <value>The password encoded.</value>
    [ XmlElement( "Password" ) ]
    public string PasswordEncoded { get { return Util.Encode ( this._password ); } set { this._password = Util.Decode(value); } }
    
    /// <summary>
    /// Gets or sets the password.
    /// </summary>
    /// <value>The password.</value>
    [ XmlIgnore ]
    public string Password { get { return this._password; } set { this._password = value; } }

    /// <summary>
    /// Creates the proxy.
    /// </summary>
    /// <returns>The proxy client.</returns>
    public IWebProxy CreateProxy () {
      if ( !UseProxy )
        return null;

      WebProxy proxy = new WebProxy ( this._host,this._port );
      proxy.BypassProxyOnLocal = true;
      proxy.Credentials = new NetworkCredential ( this.Username, this.Password );
      return proxy;
    }
  }
}
