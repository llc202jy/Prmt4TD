using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace FR.Threading {
   /// <summary>
   /// Generic pool class
   /// </summary>
   /// <typeparam name="T">The type of items to be stored in the pool</typeparam>
   public class ResourcePool<T> : IDisposable where T : class {
      /// <summary>
      /// Creates a new pool
      /// </summary>
      /// <param name="factory">The factory method to create new items to be stored in the pool</param>
      public ResourcePool(Func<ResourcePool<T>, T> factory) {
         if (factory == null)
            throw new ArgumentNullException("factory");
         _factoryMethod = factory;
      }

      private readonly Func<ResourcePool<T>, T> _factoryMethod;
      private ConcurrentQueue<PoolItem<T>> _freeItems = new ConcurrentQueue<PoolItem<T>>();
      private ConcurrentQueue<AutoResetEvent> _waitLocks = new ConcurrentQueue<AutoResetEvent>();

      private ConcurrentDictionary<AutoResetEvent, PoolItem<T>> _syncContext =
          new ConcurrentDictionary<AutoResetEvent, PoolItem<T>>();

      public Action<T> CleanupPoolItem { get; set; }

      /// <summary>
      /// Gets the current count of items in the pool
      /// </summary>
      public int Count { get; private set; }

      public void Dispose() {
         lock (this) {
            if (Count != _freeItems.Count)
               throw new InvalidOperationException(
                  "Cannot dispose the resource pool while one or more pooled items are in use");

            foreach (var poolItem in _freeItems) {
               Action<T> cleanMethod = CleanupPoolItem;
               if (cleanMethod != null)
                  CleanupPoolItem(poolItem.Resource);
            }

            Count = 0;
            _freeItems = null;
            _waitLocks = null;
            _syncContext = null;
         }
      }

      /// <summary>
      /// Gets a free resource from the pool. If no free items available this method tries to 
      /// create a new item. If no new item could be created this method waits until another thread
      /// frees one resource.
      /// </summary>
      /// <returns>A resource item</returns>
      public PoolItem<T> GetItem() {
         PoolItem<T> item;

         // try to get an item
         if (!TryGetItem(out item)) {
            AutoResetEvent waitLock = null;

            lock (this) {
               // try to get an entry in exclusive mode
               if (!TryGetItem(out item)) {
                  // no item available, create a wait lock and enqueue it
                  waitLock = new AutoResetEvent(false);
                  _waitLocks.Enqueue(waitLock);
               }
            }

            if (waitLock != null) {
               // wait until a new item is available
               waitLock.WaitOne();
               _syncContext.TryRemove(waitLock, out item);
               waitLock.Dispose();
            }
         }

         return item;
      }

      private bool TryGetItem(out PoolItem<T> item) {
         // try to get an already pooled resource
         if (_freeItems.TryDequeue(out item))
            return true;

         lock (this) {
            // try to create a new resource
            T resource = _factoryMethod(this);
            if (resource == null && Count == 0)
               throw new InvalidOperationException("Pool empty and no item created");

            if (resource != null) {
               // a new resource was created and can be returned
               Count++;
               item = new PoolItem<T>(this, resource);
            }
            else {
               // no items available to return at the moment
               item = null;
            }

            return item != null;
         }
      }

      /// <summary>
      /// Called from <see cref="PoolItem{T}"/> to free previously taked resources
      /// </summary>
      /// <param name="resource">The resource to send back into the pool.</param>
      internal void SendBackToPool(T resource) {
         lock (this) {
            PoolItem<T> item = new PoolItem<T>(this, resource);
            AutoResetEvent waitLock;

            if (_waitLocks.TryDequeue(out waitLock)) {
               _syncContext.TryAdd(waitLock, item);
               waitLock.Set();
            }
            else {
               _freeItems.Enqueue(item);
            }
         }
      }
   }
}


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FR.Threading {
   /// <summary>
   /// Represents an item in the <see cref="ResourcePool{T}"/>
   /// </summary>
   /// <typeparam name="T">The type of the resource to be hold</typeparam>
   public sealed class PoolItem<T> : IDisposable where T : class {
      internal PoolItem(ResourcePool<T> pool, T resource) {
         _pool = pool;
         _resource = resource;
      }

      private T _resource;
      private readonly ResourcePool<T> _pool;

      public static implicit operator T(PoolItem<T> item) {
         return item.Resource;
      }

      /// <summary>
      /// Gets the resource hold by this resource pool item
      /// </summary>
      public T Resource { get { return _resource; } }

      /// <summary>
      /// Disposes this instance of an resource pool item and sends the resource back into pool
      /// </summary>
      public void Dispose() {
         _pool.SendBackToPool(_resource);
         _resource = null;
      }
   }
}
using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using FR.Threading;
using NUnit.Framework;

namespace FR.Core.Test.Threading {
   [TestFixture]
   public class ResourcePoolUnitTest {
      class TestResource {
         public bool IsFree { get; set; }
      }

      const int MaxPoolSize = 3;

      [Test]
      public void GetItem_SingleThread_ReturnsItem() {
         ResourcePool<TestResource> pool = new ResourcePool<TestResource>(CreateResource);

         using (var item = pool.GetItem()) {
            Assert.IsNotNull(item);
         }
      }

      [Test]
      public void GetItem_More_Than_MaxPoolSize() {
         ResourcePool<TestResource> pool = new ResourcePool<TestResource>(CreateResource);

         for (int i = 0; i < 20; i++) {
            using (var item = pool.GetItem()) {
            }
         }

         Assert.AreEqual(1, pool.Count);
      }

      [Test]
      public void GetItem_Resource_Returned_After_Waiting() {
         ResourcePool<TestResource> pool = new ResourcePool<TestResource>(CreateResource);

         List<PoolItem<TestResource>> poolItems = new List<PoolItem<TestResource>>();
         for (int i = 0; i < MaxPoolSize; i++) {
            poolItems.Add(pool.GetItem());
         }

         AutoResetEvent outerWaitLock = new AutoResetEvent(false);

         WaitCallback asyncCall = (o) => {
            outerWaitLock.Set();
            PoolItem<TestResource> item = pool.GetItem();
            Assert.IsNotNull(item);
            Assert.IsNotNull(item.Resource);
            outerWaitLock.Set();
         };
         ThreadPool.QueueUserWorkItem(asyncCall);
         
         outerWaitLock.WaitOne();
         outerWaitLock.Reset();
         poolItems.ForEach(item => item.Dispose());

         outerWaitLock.WaitOne();
      }

      [Test]
      public void GetItem_MultiThreaded_ReturnsItem() {
         ResourcePool<TestResource> pool = new ResourcePool<TestResource>(CreateResource);

         Action work =
             () => {
                using (var item = pool.GetItem()) {
                   TestResource resource = item.Resource;
                   Assert.IsTrue(resource.IsFree);
                   resource.IsFree = false;
                   long ticks = DateTime.Now.Millisecond;
                   int sleepTime = (int)(ticks % 200);
                   Thread.Sleep(sleepTime);
                   resource.IsFree = true;
                }
             };

         const int loopCount = 50;
         const int itemCount = 5;

         for (int i = 0; i < loopCount; i++) {
            List<AutoResetEvent> locks = new List<AutoResetEvent>();

            for (int j = 0; j < itemCount; j++) {
               //Debug.WriteLine("Loop {0} Item {1}", i, j);
               ThreadPool.QueueUserWorkItem((o) => work());
            }
         }
      }

      [Test]
      public void Dispose_WhileInUse_ThrowsException() {
         ResourcePool<TestResource> pool = new ResourcePool<TestResource>(CreateResource);
         PoolItem<TestResource> item = pool.GetItem();

         Assert.Throws<InvalidOperationException>(
            () => pool.Dispose(),
            "Cannot dispose the resource pool while one or more pooled items are in use");
      }

      private static TestResource CreateResource(ResourcePool<TestResource> pool) {
         return pool.Count < MaxPoolSize ? new TestResource { IsFree = true } : null;
      }
   }
}