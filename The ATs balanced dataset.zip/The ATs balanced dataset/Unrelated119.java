
    // Flush as much pending output as possible
    if(pending != 0) {
      strm.flush_pending();
      if(strm.avail_out == 0) {
	//System.out.println("  avail_out==0");
	// Since avail_out is 0, deflate will be called again with
	// more output space, but possibly with both pending and
	// avail_in equal to zero. There won't be anything to do,
	// but this is not an error situation so make sure we
	// return OK instead of BUF_ERROR at next call of deflate:
	last_flush = -1;
	return Z_OK;
      }

      // Make sure there is something to do and avoid duplicate consecutive
      // flushes. For repeated and useless calls with Z_FINISH, we keep
      // returning Z_STREAM_END instead of Z_BUFF_ERROR.
    }
    else if(strm.avail_in==0 && flush <= old_flush &&
	    flush != Z_FINISH) {
      strm.msg=z_errmsg[Z_NEED_DICT-(Z_BUF_ERROR)];
      return Z_BUF_ERROR;
    }

    // User must not provide more input after the first FINISH:
    if(status == FINISH_STATE && strm.avail_in != 0) {
      strm.msg=z_errmsg[Z_NEED_DICT-(Z_BUF_ERROR)];
      return Z_BUF_ERROR;
    }

    // Start a new block or continue the current one.
    if(strm.avail_in!=0 || lookahead!=0 ||
       (flush != Z_NO_FLUSH && status != FINISH_STATE)) {
      int bstate=-1;
      switch(config_table[level].func){
      case STORED: 
	bstate = deflate_stored(flush);
	break;
      case FAST: 
	bstate = deflate_fast(flush);
	break;
      case SLOW: 
	bstate = deflate_slow(flush);
	break;
      default:
      }

      if (bstate==FinishStarted || bstate==FinishDone) {
	status = FINISH_STATE;
      }
      if (bstate==NeedMore || bstate==FinishStarted) {
	if(strm.avail_out == 0) {
	  last_flush = -1; // avoid BUF_ERROR next call, see above
	}
	return Z_OK;
	// If flush != Z_NO_FLUSH && avail_out == 0, the next call
	// of deflate should use the same flush parameter to make sure
	// that the flush is complete. So we don't have to output an
	// empty block here, this will be done at next call. This also
	// ensures that for a very small output buffer, we emit at most
	// one empty block.
      }

      if (bstate==BlockDone) {
	if(flush == Z_PARTIAL_FLUSH) {
	  _tr_align();
	} 
	else { // FULL_FLUSH or SYNC_FLUSH
	  _tr_stored_block(0, 0, false);
	  // For a full flush, this empty block will be recognized
	  // as a special marker by inflate_sync().
	  if(flush == Z_FULL_FLUSH) {
	    //state.head[s.hash_size-1]=0;
	    for(int i=0; i<hash_size/*-1*/; i++)  // forget history
	      head[i]=0;
	  }
	}
	strm.flush_pending();
	if(strm.avail_out == 0) {
	  last_flush = -1; // avoid BUF_ERROR at next call, see above
	  return Z_OK;
	}
      }
    }

    if(flush!=Z_FINISH) return Z_OK;
    if(noheader!=0) return Z_STREAM_END;

    // Write the zlib trailer (adler32)
    putShortMSB((int)(strm.adler>>>16));
    putShortMSB((int)(strm.adler&0xffff));
    strm.flush_pending();

    // If avail_out is zero, the application will call deflate again
    // to flush the rest.
    noheader = -1; // write the trailer only once!
    return pending != 0 ? Z_OK : Z_STREAM_END;
  }
}
    last_flush = Z_NO_FLUSH;

    tr_init();
    lm_init();
    return Z_OK;
  }

  int deflateEnd(){
    if(status!=INIT_STATE && status!=BUSY_STATE && status!=FINISH_STATE){
      return Z_STREAM_ERROR;
    }
    // Deallocate in reverse order of allocations:
    pending_buf=null;
    head=null;
    prev=null;
    window=null;
    // free
    // dstate=null;
    return status == BUSY_STATE ? Z_DATA_ERROR : Z_OK;
  }

  int deflateParams(ZStream strm, int _level, int _strategy){
    int err=Z_OK;

    if(_level == Z_DEFAULT_COMPRESSION){
      _level = 6;
    }
    if(_level < 0 || _level > 9 || 
       _strategy < 0 || _strategy > Z_HUFFMAN_ONLY) {
      return Z_STREAM_ERROR;
    }

    if(config_table[level].func!=config_table[_level].func &&
       strm.total_in != 0) {
      // Flush the last buffer:
      err = strm.deflate(Z_PARTIAL_FLUSH);
    }

    if(level != _level) {
      level = _level;
      max_lazy_match   = config_table[level].max_lazy;
      good_match       = config_table[level].good_length;
      nice_match       = config_table[level].nice_length;
      max_chain_length = config_table[level].max_chain;
    }
    strategy = _strategy;
    return err;
  }

  int deflateSetDictionary (ZStream strm, byte[] dictionary, int dictLength){
    int length = dictLength;
    int index=0;

    if(dictionary == null || status != INIT_STATE)
      return Z_STREAM_ERROR;

    strm.adler=strm._adler.adler32(strm.adler, dictionary, 0, dictLength);

    if(length < MIN_MATCH) return Z_OK;
    if(length > w_size-MIN_LOOKAHEAD){
      length = w_size-MIN_LOOKAHEAD;
      index=dictLength-length; // use the tail of the dictionary
    }
    System.arraycopy(dictionary, index, window, 0, length);
    strstart = length;
    block_start = length;

    // Insert all strings in the hash table (except for the last two bytes).
    // s->lookahead stays null, so s->ins_h will be recomputed at the next
    // call of fill_window.

    ins_h = window[0]&0xff;
    ins_h=(((ins_h)<<hash_shift)^(window[1]&0xff))&hash_mask;

    for(int n=0; n<=length-MIN_MATCH; n++){
      ins_h=(((ins_h)<<hash_shift)^(window[(n)+(MIN_MATCH-1)]&0xff))&hash_mask;
      prev[n&w_mask]=head[ins_h];
      head[ins_h]=(short)n;
    }
    return Z_OK;
  }

  int deflate(ZStream strm, int flush){
    int old_flush;

    if(flush>Z_FINISH || flush<0){
      return Z_STREAM_ERROR;
    }

    if(strm.next_out == null ||
       (strm.next_in == null && strm.avail_in != 0) ||
       (status == FINISH_STATE && flush != Z_FINISH)) {
      strm.msg=z_errmsg[Z_NEED_DICT-(Z_STREAM_ERROR)];
      return Z_STREAM_ERROR;
    }
    if(strm.avail_out == 0){
      strm.msg=z_errmsg[Z_NEED_DICT-(Z_BUF_ERROR)];
      return Z_BUF_ERROR;
    }

    this.strm = strm; // just in case
    old_flush = last_flush;
    last_flush = flush;

    // Write the zlib header
    if(status == INIT_STATE) {
      int header = (Z_DEFLATED+((w_bits-8)<<4))<<8;
      int level_flags=((level-1)&0xff)>>1;

      if(level_flags>3) level_flags=3;
      header |= (level_flags<<6);
      if(strstart!=0) header |= PRESET_DICT;
      header+=31-(header % 31);

      status=BUSY_STATE;
      putShortMSB(header);


      // Save the adler32 of the preset dictionary:
      if(strstart!=0){
        putShortMSB((int)(strm.adler>>>16));
        putShortMSB((int)(strm.adler&0xffff));
      }
      strm.adler=strm._adler.adler32(0, null, 0, 0);
    }

      if(len>best_len) {
	match_start = cur_match;
	best_len = len;
	if (len >= nice_match) break;
	scan_end1  = window[scan+best_len-1];
	scan_end   = window[scan+best_len];
      }

    } while ((cur_match = (prev[cur_match & wmask]&0xffff)) > limit
	     && --chain_length != 0);

    if (best_len <= lookahead) return best_len;
    return lookahead;
  }
    
  int deflateInit(ZStream strm, int level, int bits){
    return deflateInit2(strm, level, Z_DEFLATED, bits, DEF_MEM_LEVEL,
			Z_DEFAULT_STRATEGY);
  }
  int deflateInit(ZStream strm, int level){
    return deflateInit(strm, level, MAX_WBITS);
  }
  int deflateInit2(ZStream strm, int level, int method,  int windowBits,
		   int memLevel, int strategy){
    int noheader = 0;
    //    byte[] my_version=ZLIB_VERSION;

    //
    //  if (version == null || version[0] != my_version[0]
    //  || stream_size != sizeof(z_stream)) {
    //  return Z_VERSION_ERROR;
    //  }

    strm.msg = null;

    if (level == Z_DEFAULT_COMPRESSION) level = 6;

    if (windowBits < 0) { // undocumented feature: suppress zlib header
      noheader = 1;
      windowBits = -windowBits;
    }

    if (memLevel < 1 || memLevel > MAX_MEM_LEVEL || 
	method != Z_DEFLATED ||
	windowBits < 9 || windowBits > 15 || level < 0 || level > 9 ||
        strategy < 0 || strategy > Z_HUFFMAN_ONLY) {
      return Z_STREAM_ERROR;
    }

    strm.dstate = (Deflate)this;

    this.noheader = noheader;
    w_bits = windowBits;
    w_size = 1 << w_bits;
    w_mask = w_size - 1;

    hash_bits = memLevel + 7;
    hash_size = 1 << hash_bits;
    hash_mask = hash_size - 1;
    hash_shift = ((hash_bits+MIN_MATCH-1)/MIN_MATCH);

    window = new byte[w_size*2];
    prev = new short[w_size];
    head = new short[hash_size];

    lit_bufsize = 1 << (memLevel + 6); // 16K elements by default

    // We overlay pending_buf and d_buf+l_buf. This works since the average
    // output size for (length,distance) codes is <= 24 bits.
    pending_buf = new byte[lit_bufsize*4];
    pending_buf_size = lit_bufsize*4;

    d_buf = lit_bufsize/2;
    l_buf = (1+2)*lit_bufsize;

    this.level = level;

//System.out.println("level="+level);

    this.strategy = strategy;
    this.method = (byte)method;

    return deflateReset(strm);
  }

  int deflateReset(ZStream strm){
    strm.total_in = strm.total_out = 0;
    strm.msg = null; //
    strm.data_type = Z_UNKNOWN;

    pending = 0;
    pending_out = 0;

    if(noheader < 0) {
      noheader = 0; // was set to -1 by deflate(..., Z_FINISH);
    }
    status = (noheader!=0) ? BUSY_STATE : INIT_STATE;
    strm.adler=strm._adler.adler32(0, null, 0, 0);

    if(match_available!=0) {
      bflush=_tr_tally(0, window[strstart-1]&0xff);
      match_available = 0;
    }
    flush_block_only(flush == Z_FINISH);

    if(strm.avail_out==0){
      if(flush == Z_FINISH) return FinishStarted;
      else return NeedMore;
    }

    return flush == Z_FINISH ? FinishDone : BlockDone;
  }

  int longest_match(int cur_match){
    int chain_length = max_chain_length; // max hash chain length
    int scan = strstart;                 // current string
    int match;                           // matched string
    int len;                             // length of current match
    int best_len = prev_length;          // best match length so far
    int limit = strstart>(w_size-MIN_LOOKAHEAD) ?
      strstart-(w_size-MIN_LOOKAHEAD) : 0;
    int nice_match=this.nice_match;

    // Stop when cur_match becomes <= limit. To simplify the code,
    // we prevent matches with the string of window index 0.

    int wmask = w_mask;

    int strend = strstart + MAX_MATCH;
    byte scan_end1 = window[scan+best_len-1];
    byte scan_end = window[scan+best_len];

    // The code is optimized for HASH_BITS >= 8 and MAX_MATCH-2 multiple of 16.
    // It is easy to get rid of this optimization if necessary.

    // Do not waste too much time if we already have a good match:
    if (prev_length >= good_match) {
      chain_length >>= 2;
    }

    // Do not look for matches beyond the end of the input. This is necessary
    // to make deflate deterministic.
    if (nice_match > lookahead) nice_match = lookahead;

    do {
      match = cur_match;

      // Skip to next match if the match length cannot increase
      // or if the match length is less than 2:
      if (window[match+best_len]   != scan_end  ||
	  window[match+best_len-1] != scan_end1 ||
	  window[match]       != window[scan]     ||
	  window[++match]     != window[scan+1])      continue;

      // The check at best_len-1 can be removed because it will be made
      // again later. (This heuristic is not always a win.)
      // It is not necessary to compare scan[2] and match[2] since they
      // are always equal when the other bytes match, given that
      // the hash keys are equal and that HASH_BITS >= 8.
      scan += 2; match++;

      // We check for insufficient lookahead only every 8th comparison;
      // the 256th check will be made at strstart+258.
      do {
      } while (window[++scan] == window[++match] &&
	       window[++scan] == window[++match] &&
	       window[++scan] == window[++match] &&
	       window[++scan] == window[++match] &&
	       window[++scan] == window[++match] &&
	       window[++scan] == window[++match] &&
	       window[++scan] == window[++match] &&
	       window[++scan] == window[++match] &&
	       scan < strend);

      len = MAX_MATCH - (int)(strend - scan);
      scan = strend - MAX_MATCH;
	if (bflush){
	  flush_block_only(false);
	  if(strm.avail_out==0) return NeedMore;
	}
      } else if (match_available!=0) {

	// If there was no match at the previous position, output a
	// single literal. If there was a match but the current match
	// is longer, truncate the previous match to a single literal.

	bflush=_tr_tally(0, window[strstart-1]&0xff);

	if (bflush) {
	  flush_block_only(false);
	}
	strstart++;
	lookahead--;
	if(strm.avail_out == 0) return NeedMore;
      } else {
	// There is no previous match to compare with, wait for
	// the next step to decide.

	match_available = 1;
	strstart++;
	lookahead--;
      }
    }


	//          check_match(strstart-1, prev_match, prev_length);

	bflush=_tr_tally(strstart-1-prev_match, prev_length - MIN_MATCH);

	// Insert in hash table all strings up to the end of the match.
	// strstart-1 and strstart are already inserted. If there is not
	// enough lookahead, the last two strings are not inserted in
	// the hash table.
	lookahead -= prev_length-1;
	prev_length -= 2;
	do{
	  if(++strstart <= max_insert) {
	    ins_h=(((ins_h)<<hash_shift)^(window[(strstart)+(MIN_MATCH-1)]&0xff))&hash_mask;
	    //prev[strstart&w_mask]=hash_head=head[ins_h];
	    hash_head=(head[ins_h]&0xffff);
	    prev[strstart&w_mask]=head[ins_h];
	    head[ins_h]=(short)strstart;
	  }
	}
	while(--prev_length != 0);
	match_available = 0;
	match_length = MIN_MATCH-1;
	strstart++;

StaticTree stat_desc;  // the corresponding static tree

  // Compute the optimal bit lengths for a tree and update the total bit length
  // for the current block.
  // IN assertion: the fields freq and dad are set, heap[heap_max] and
  //    above are the tree nodes sorted by increasing frequency.
  // OUT assertions: the field len is set to the optimal bit length, the
  //     array bl_count contains the frequencies for each bit length.
  //     The length opt_len is updated; static_len is also updated if stree is
  //     not null.
  void gen_bitlen(Deflate s){
    short[] tree = dyn_tree;
    short[] stree = stat_desc.static_tree;
    int[] extra = stat_desc.extra_bits;
    int base = stat_desc.extra_base;
    int max_length = stat_desc.max_length;
    int h;              // heap index
    int n, m;           // iterate over the tree elements
    int bits;           // bit length
    int xbits;          // extra bits
    short f;            // frequency
    int overflow = 0;   // number of elements with bit length too large

    for (bits = 0; bits <= MAX_BITS; bits++) s.bl_count[bits] = 0;

    // In a first pass, compute the optimal bit lengths (which may
    // overflow in the case of the bit length tree).
    tree[s.heap[s.heap_max]*2+1] = 0; // root of the heap

    for(h=s.heap_max+1; h<HEAP_SIZE; h++){
      n = s.heap[h];
      bits = tree[tree[n*2+1]*2+1] + 1;
      if (bits > max_length){ bits = max_length; overflow++; }
      tree[n*2+1] = (short)bits;
      // We overwrite tree[n*2+1] which is no longer needed

      if (n > max_code) continue;  // not a leaf node

      s.bl_count[bits]++;
      xbits = 0;
      if (n >= base) xbits = extra[n-base];
      f = tree[n*2];
      s.opt_len += f * (bits + xbits);
      if (stree!=null) s.static_len += f * (stree[n*2+1] + xbits);
    }
    if (overflow == 0) return;

    // This happens for example on obj2 and pic of the Calgary corpus
    // Find the first bit length which could increase:
    do {
      bits = max_length-1;
      while(s.bl_count[bits]==0) bits--;
      s.bl_count[bits]--;      // move one leaf down the tree
      s.bl_count[bits+1]+=2;   // move one overflow item as its brother
      s.bl_count[max_length]--;
      // The brother of the overflow item also moves one step up,
      // but this does not affect bl_count[max_length]
      overflow -= 2;
    }
    while (overflow > 0);

    for (bits = max_length; bits != 0; bits--) {
      n = s.bl_count[bits];
      while (n != 0) {
	m = s.heap[--h];
	if (m > max_code) continue;
	if (tree[m*2+1] != bits) {
	  s.opt_len += ((long)bits - (long)tree[m*2+1])*(long)tree[m*2];
	  tree[m*2+1] = (short)bits;
	}
	n--;
      }
    }
  }

  // Construct one Huffman tree and assigns the code bit strings and lengths.
  // Update the total bit length for the current block.
  // IN assertion: the field freq is set for all tree elements.
  // OUT assertions: the fields len and code are set to the optimal bit length
  //     and corresponding code. The length opt_len is updated; static_len is
  //     also updated if stree is not null. The field max_code is set.
  void build_tree(Deflate s){
    short[] tree=dyn_tree;
    short[] stree=stat_desc.static_tree;
    int elems=stat_desc.elems;
    int n, m;          // iterate over heap elements
    int max_code=-1;   // largest code with non zero frequency
    int node;          // new node being created

    // Construct the initial heap, with least frequent element in
    // heap[1]. The sons of heap[n] are heap[2*n] and heap[2*n+1].
    // heap[0] is not used.
    s.heap_len = 0;
    s.heap_max = HEAP_SIZE;

    for(n=0; n<elems; n++) {
      if(tree[n*2] != 0) {
	s.heap[++s.heap_len] = max_code = n;
	s.depth[n] = 0;
      }
      else{
	tree[n*2+1] = 0;
      }
    }

    // The pkzip format requires that at least one distance code exists,
    // and that at least one bit should be sent even if there is only one
    // possible code. So to avoid special checks later on we force at least
    // two codes of non zero frequency.
    while (s.heap_len < 2) {
      node = s.heap[++s.heap_len] = (max_code < 2 ? ++max_code : 0);
      tree[node*2] = 1;
      s.depth[node] = 0;
      s.opt_len--; if (stree!=null) s.static_len -= stree[node*2+1];
      // node is 0 or 1 so it does not have extra bits
    }
    this.max_code = max_code;

    // The elements heap[heap_len/2+1 .. heap_len] are leaves of the tree,
    // establish sub-heaps of increasing lengths:

    for(n=s.heap_len/2;n>=1; n--)
      s.pqdownheap(tree, n);

    // Construct the Huffman tree by repeatedly combining the least two
    // frequent nodes.

    node=elems;                 // next internal node of the tree
    do{
      // n = node of least frequency
      n=s.heap[1];
      s.heap[1]=s.heap[s.heap_len--];
      s.pqdownheap(tree, 1);
      m=s.heap[1];                // m = node of next least frequency

      s.heap[--s.heap_max] = n; // keep the nodes sorted by frequency
      s.heap[--s.heap_max] = m;

      // Create a new node father of n and m
      tree[node*2] = (short)(tree[n*2] + tree[m*2]);
      s.depth[node] = (byte)(Math.max(s.depth[n],s.depth[m])+1);
      tree[n*2+1] = tree[m*2+1] = (short)node;

      // and insert the new node in the heap
      s.heap[1] = node++;
      s.pqdownheap(tree, 1);
    }
    while(s.heap_len>=2);

    s.heap[--s.heap_max] = s.heap[1];

    // At this point, the fields freq and dad are set. We can now
    // generate the bit lengths.

    gen_bitlen(s);

    // The field len is now set, we can generate the bit codes
    gen_codes(tree, max_code, s.bl_count);
  }

  // Generate the codes for a given tree and bit counts (which need not be
  // optimal).
  // IN assertion: the array bl_count contains the bit length statistics for
  // the given tree and the field len is set for all tree elements.
  // OUT assertion: the field code is set for all tree elements of non
  //     zero code length.
  static void gen_codes(short[] tree, // the tree to decorate
			int max_code, // largest code with non zero frequency
			short[] bl_count // number of codes at each bit length
			){
    short[] next_code=new short[MAX_BITS+1]; // next code value for each bit length
    short code = 0;            // running code value
    int bits;                  // bit index
    int n;                     // code index

    // The distribution counts are first used to generate the code values
    // without bit reversal.
    for (bits = 1; bits <= MAX_BITS; bits++) {
      next_code[bits] = code = (short)((code + bl_count[bits-1]) << 1);
    }

    // Check that the bit counts in bl_count are consistent. The last code
    // must be all ones.
    //Assert (code + bl_count[MAX_BITS]-1 == (1<<MAX_BITS)-1,
    //        "inconsistent bit counts");
    //Tracev((stderr,"\ngen_codes: max_code %d ", max_code));

    for (n = 0;  n <= max_code; n++) {
      int len = tree[n*2+1];
      if (len == 0) continue;
      // Now reverse the bits
      tree[n*2] = (short)(bi_reverse(next_code[len]++, len));
    }
  }

  // Reverse the first len bits of a code, using straightforward code (a faster
  // method would use a table)
  // IN assertion: 1 <= len <= 15
  static int bi_reverse(int code, // the value to invert
			int len   // its bit length
			){
    int res = 0;
    do{
      res|=code&1;
      code>>>=1;
      res<<=1;
    } 
    while(--len>0);
    return res>>>1;
  }
}

  {
    if (!handshakeDone)
      {
        startHandshake();
      }
    Alert alert = session.currentAlert;
    if (alert != null && alert.getLevel() == Alert.Level.FATAL)
      {
        throw new AlertException(alert, false);
      }
    if (handshakeIn.available() > 0 && !clientMode)
      {
        handshakeDone = false;
        startHandshake();
      }
  }

// Own methods.
  // -------------------------------------------------------------------------

  private static final byte[] SENDER_CLIENT =
    new byte[] { 0x43, 0x4C, 0x4E, 0x54 };
  private static final byte[] SENDER_SERVER =
    new byte[] { 0x53, 0x52, 0x56, 0x52 };

  private void changeCipherSpec () throws IOException
  {
    RecordOutputStream out =
      new RecordOutputStream (socketOut, ContentType.CHANGE_CIPHER_SPEC, session.params);
    out.write (1);
  }

  private void readChangeCipherSpec () throws IOException
  {
    RecordInputStream in =
      new RecordInputStream (recordInput, ContentType.CHANGE_CIPHER_SPEC);
    if (in.read() != 1)
      {
        throw new SSLProtocolException ("bad change cipher spec message");
      }
  }

  /**
   * Initializes the application data streams and starts the record layer
   * threads.
   */
  private synchronized void setupIO() throws IOException
  {
    if (recordInput != null)
      {
        return;
      }
    if (underlyingSocket != null)
      {
        socketIn = underlyingSocket.getInputStream();
        socketOut = underlyingSocket.getOutputStream();
      }
    else
      {
        socketIn = super.getInputStream();
        socketOut = super.getOutputStream();
      }
//     recordLayer = new ThreadGroup("record_layer");
//     recordInput = new RecordInput(in, session, recordLayer);
//     recordOutput = new RecordOutput(out, session, recordLayer);
//     recordInput.setRecordOutput(recordOutput);
//     recordLayer.setDaemon(true);
//     recordInput.start();
//     recordOutput.start();
    recordInput = new RecordInput (socketIn, session);
    applicationIn = new SSLSocketInputStream(
      new RecordInputStream (recordInput, ContentType.APPLICATION_DATA), this);
    applicationOut = new SSLSocketOutputStream(
      new RecordOutputStream (socketOut, ContentType.APPLICATION_DATA, session.params), this);
    handshakeIn = new SSLSocketInputStream(
      new RecordInputStream (recordInput, ContentType.HANDSHAKE), this, false);
    handshakeOut = new BufferedOutputStream (new SSLSocketOutputStream(
      new RecordOutputStream (socketOut, ContentType.HANDSHAKE, session.params), this, false), 8096);
  }

  private void handshakeCompleted ()
  {
    handshakeDone = true;
    HandshakeCompletedEvent event = new HandshakeCompletedEvent (this, session);
    for (Iterator it = handshakeListeners.iterator (); it.hasNext (); )
      {
        try
          {
            ((HandshakeCompletedListener) it.next ()).handshakeCompleted (event);
          }
        catch (Throwable t) { }
      }
    if (createSessions)
      {
        synchronized (session)
          {
            sessionContext.addSession (session.sessionId, session);
            session.access ();
          }
      }
  }

  void setEnabledCipherSuites(List suites)
  {
    session.enabledSuites = suites;
  }

  void setEnabledProtocols(SortedSet protocols)
  {
    session.enabledProtocols = protocols;
  }

  void setSRPTrustManager(SRPTrustManager srpTrustManager)
  {
    session.srpTrustManager = srpTrustManager;
  }

  void setTrustManager(X509TrustManager trustManager)
  {
    session.trustManager = trustManager;
  }

  void setKeyManager(X509KeyManager keyManager)
  {
    session.keyManager = keyManager;
  }

  void setRandom(SecureRandom random)
  {
    session.random = random;
  }

  void sendAlert (Alert alert) throws IOException
  {    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_FALSE@throw new UnsupportedOperationException("1.4 methods not enabled");
  }

  public boolean getReuseAddress() throws SocketException
  {
    @HAVE_1_4_TRUE@if (underlyingSocket != null)
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    return underlyingSocket.getReuseAddress();
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_TRUE@else
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    return super.getReuseAddress();
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_FALSE@throw new UnsupportedOperationException("1.4 methods not enabled");
  }

  public void shutdownInput() throws IOException
  {
    @HAVE_1_4_TRUE@if (underlyingSocket != null)
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    underlyingSocket.shutdownInput();
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_TRUE@else
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    super.shutdownInput();
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_FALSE@throw new UnsupportedOperationException("1.4 methods not enabled");
  }

  public void shutdownOutput() throws IOException
  {
    @HAVE_1_4_TRUE@if (underlyingSocket != null)
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    underlyingSocket.shutdownOutput();
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_TRUE@else
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    super.shutdownOutput();
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_FALSE@throw new UnsupportedOperationException("1.4 methods not enabled");
  }

  public boolean isConnected()
  {
    @HAVE_CLASSPATH_TRUE@if (underlyingSocket != null)
    @HAVE_CLASSPATH_TRUE@  {
    @HAVE_CLASSPATH_TRUE@    return underlyingSocket.isConnected();
    @HAVE_CLASSPATH_TRUE@  }
    @HAVE_CLASSPATH_TRUE@else
    @HAVE_CLASSPATH_TRUE@  {
    @HAVE_CLASSPATH_TRUE@    return super.isConnected();
    @HAVE_CLASSPATH_TRUE@  }
    @HAVE_CLASSPATH_FALSE@throw new UnsupportedOperationException("1.4 methods not enabled");
  }

  public boolean isInputShutdown()
  {
    @HAVE_1_4_TRUE@if (underlyingSocket != null)
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    return underlyingSocket.isInputShutdown();
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_TRUE@else
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    return super.isInputShutdown();
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_FALSE@throw new UnsupportedOperationException("1.4 methods not enabled");
  }

  public boolean isOutputShutdown()
  {
    @HAVE_1_4_TRUE@if (underlyingSocket != null)
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    return underlyingSocket.isOutputShutdown();
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_TRUE@else
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    return super.isOutputShutdown();
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_FALSE@throw new UnsupportedOperationException("1.4 methods not enabled");
  }

  protected void finalize()
  {
    if (session.currentAlert == null)
      {
        try
          {
            close();
          }
        catch (Exception ignore) { }
      }
  }

// Package methods.
  // -------------------------------------------------------------------------

  void setSessionContext(SessionContext sessionContext)
  {
    this.sessionContext = sessionContext;

    RecordOutputStream out =
      new RecordOutputStream (socketOut, ContentType.ALERT, session.params);
    out.write (alert.getEncoded ());
  }

  /**
   * Gets the most-recently-received alert message.
   *
   * @return The alert message.
   */
  Alert checkAlert()
  {
    return session.currentAlert;
  }

  synchronized void checkHandshakeDone() throws IOException
