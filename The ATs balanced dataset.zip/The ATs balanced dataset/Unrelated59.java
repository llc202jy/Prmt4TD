	synchronized void transaction_finished(TransactionCoordinator tc) {
		Vector executed = new Vector();
		Enumeration enum;
		boolean do_notify = false;
		synchronized (queue) {
			enum = queue.elements();
			while (enum.hasMoreElements()) {
				Request r = (Request) enum.nextElement();
				if (r.current == tc) {
					r.state = LockSetFactoryImpl.ROLLBACK;
					executed.addElement(r);
				}
			}
			if (executed.size() > 0) {
				enum = executed.elements();
				while (enum.hasMoreElements()) {
					queue.removeElement(enum.nextElement());
				}
				do_notify = true;
			}
			if (locks.remove(tc) != null) {
				do_notify = attempt_lock_from_queue() ? true : do_notify;
			}
			if (do_notify) {
				queue.notifyAll();
			}package Org.omg.CosEventChannelAdmin;

// Decompiled by Jad v1.5.7d. Copyright 2000 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/SiliconValley/Bridge/8617/jad.html
// Decompiler options: packimports(3) annotate_fullnamesfieldsfirst nonlb space
// Source File Name:   ProxyPushSupplierPOATie.java

import Org.omg.CORBA.ORB;
import Org.omg.CosEventComm.PushConsumer;
import Org.omg.CosEventComm.PushSupplierOperations;
import Org.omg.PortableServer.POA;
import Org.omg.PortableServer.Servant;

// Referenced classes of package Org.omg.CosEventChannelAdmin:
//			ProxyPushSupplierPOA, AlreadyConnected, ProxyPushSupplierHelper, ProxyPushSupplierOperations,
//			TypeError, ProxyPushSupplier

public class ProxyPushSupplierPOATie extends ProxyPushSupplierPOA
{

	private ProxyPushSupplierOperations _delegate;
	private POA _poa;

	public ProxyPushSupplierPOATie(ProxyPushSupplierOperations proxypushsupplieroperations) {
		//    0    0:aload_0
		//    1    1:invokespecial   #9   <Method void ProxyPushSupplierPOA()>
		_delegate = proxypushsupplieroperations;
		//    2    4:aload_0
		//    3    5:aload_1
		//    4    6:putfield        #10  <Field Org.omg.CosEventChannelAdmin.ProxyPushSupplierOperations Org.omg.CosEventChannelAdmin.ProxyPushSupplierPOATie._delegate>
		//    5    9:return
	}

	public ProxyPushSupplierPOATie(ProxyPushSupplierOperations proxypushsupplieroperations, POA poa) {
		//    0    0:aload_0
		//    1    1:invokespecial   #9   <Method void ProxyPushSupplierPOA()>
		_delegate = proxypushsupplieroperations;
		//    2    4:aload_0
		//    3    5:aload_1
		//    4    6:putfield        #10  <Field Org.omg.CosEventChannelAdmin.ProxyPushSupplierOperations Org.omg.CosEventChannelAdmin.ProxyPushSupplierPOATie._delegate>
		_poa = poa;
		//    5    9:aload_0
		//    6   10:aload_2
		//    7   11:putfield        #11  <Field Org.omg.PortableServer.POA Org.omg.CosEventChannelAdmin.ProxyPushSupplierPOATie._poa>
		//    8   14:return
	}

	public ProxyPushSupplierOperations _delegate() {
		return _delegate;
		//    0    0:aload_0
		//    1    1:getfield        #10  <Field Org.omg.CosEventChannelAdmin.ProxyPushSupplierOperations Org.omg.CosEventChannelAdmin.ProxyPushSupplierPOATie._delegate>
		//    2    4:areturn
	}

	public void _delegate(ProxyPushSupplierOperations proxypushsupplieroperations) {
		_delegate = proxypushsupplieroperations;
		//    0    0:aload_0
		//    1    1:aload_1
		//    2    2:putfield        #10  <Field Org.omg.CosEventChannelAdmin.ProxyPushSupplierOperations Org.omg.CosEventChannelAdmin.ProxyPushSupplierPOATie._delegate>
		//    3    5:return
	}

	public ProxyPushSupplier _this() {
		return ProxyPushSupplierHelper.narrow(_this_object());
		//    0    0:aload_0
		//    1    1:invokevirtual   #12  <Method Org.omg.CORBA.Object Org.omg.PortableServer.Servant._this_object()>
		//    2    4:invokestatic    #16  <Method Org.omg.CosEventChannelAdmin.ProxyPushSupplier Org.omg.CosEventChannelAdmin.ProxyPushSupplierHelper.narrow(Org.omg.CORBA.Object)>
		//    3    7:areturn
	}

	public ProxyPushSupplier _this(ORB orb) {
		return ProxyPushSupplierHelper.narrow(_this_object(orb));
		//    0    0:aload_0
		//    1    1:aload_1
		//    2    2:invokevirtual   #13  <Method Org.omg.CORBA.Object Org.omg.PortableServer.Servant._this_object(Org.omg.CORBA.ORB)>
		//    3    5:invokestatic    #16  <Method Org.omg.CosEventChannelAdmin.ProxyPushSupplier Org.omg.CosEventChannelAdmin.ProxyPushSupplierHelper.narrow(Org.omg.CORBA.Object)>
		//    4    8:areturn
	}

	public void connect_push_consumer(PushConsumer pushconsumer) throws AlreadyConnected, TypeError {
		_delegate.connect_push_consumer(pushconsumer);
		//    0    0:aload_0
		//    1    1:getfield        #10  <Field Org.omg.CosEventChannelAdmin.ProxyPushSupplierOperations Org.omg.CosEventChannelAdmin.ProxyPushSupplierPOATie._delegate>
		//    2    4:aload_1
		//    3    5:invokeinterface #14  <Method void Org.omg.CosEventChannelAdmin.ProxyPushSupplierOperations.connect_push_consumer(Org.omg.CosEventComm.PushConsumer)>
		//    4   10:return
	}

	public void disconnect_push_supplier() {
		_delegate.disconnect_push_supplier();
		//    0    0:aload_0
		//    1    1:getfield        #10  <Field Org.omg.CosEventChannelAdmin.ProxyPushSupplierOperations Org.omg.CosEventChannelAdmin.ProxyPushSupplierPOATie._delegate>
		//    2    4:invokeinterface #15  <Method void Org.omg.CosEventComm.PushSupplierOperations.disconnect_push_supplier()>
		//    3    9:return
	}

		}
		if (related.size() > 0) {
			enum = related.elements();
			while (enum.hasMoreElements()) {
				TransactionalLockSet ls = (TransactionalLockSet) enum.nextElement();
				ls.get_coordinator(tc.get_coordinator()).drop_locks();
			}
		}
	}
}
	private void check_active() {
		if (!is_active) {
			throw new Org.omg.CORBA.OBJECT_NOT_EXIST();
		}
	}

	private void check_status(TransactionCoordinator tc) {
		Status status = tc.get_state();
		if (status.equals(Status.StatusActive)) {
			return;
		} else
			if (status.equals(Status.StatusPrepared) || status.equals(Status.StatusCommitted) || status.equals(Status.StatusUnknown) || status.equals(Status.StatusNoTransaction) || status.equals(Status.StatusPreparing) || status.equals(Status.StatusCommitting)) {
				throw new Org.omg.CORBA.INVALID_TRANSACTION();
			} else
				if (status.equals(Status.StatusRollingBack) || status.equals(Status.StatusMarkedRollback) || status.equals(Status.StatusRolledBack)) {
					throw new Org.omg.CORBA.TRANSACTION_ROLLEDBACK();
				}
	}


	private synchronized boolean attempt_lock_from_queue() {
		boolean rc = false;
		boolean do_recursive = false;
		Vector executed = new Vector();
		Enumeration enum = queue.elements();
		while (enum.hasMoreElements()) {
			Request r = (Request) enum.nextElement();
			synchronized (r.current) {
				try {
					check_status(r.current);
				} catch (Org.omg.CORBA.INVALID_TRANSACTION e) {
					r.state = LockSetFactoryImpl.NO_TRANS;
					executed.addElement(r);
					rc = true;
					continue;
				} catch (Org.omg.CORBA.TRANSACTION_ROLLEDBACK e) {
					r.state = LockSetFactoryImpl.ROLLBACK;
					executed.addElement(r);
					rc = true;
					continue;
				}
				switch (r.to_do) {
					case Request.LOCK :
						if (!attempt_lock(r.current, r.set_mode)) {
							continue;
						}
						r.state = LockSetFactoryImpl.SATISFIED;
						break;
					case Request.CHANGE :
						try {
							if (!attempt_change(r.current, r.set_mode, r.reset_mode)) {
								continue;
							}
							r.state = LockSetFactoryImpl.SATISFIED;
							do_recursive = true;
						} catch (LockNotHeld e) {
							r.state = LockSetFactoryImpl.REJECT;
						}
						break;
				}
				executed.addElement(r);
				rc = true;
			}
		};
		enum = executed.elements();
		while (enum.hasMoreElements()) {
			queue.removeElement(enum.nextElement());
		}
		if (do_recursive) {
			attempt_lock_from_queue();
		}
		return executed.size() > 0;
	}

