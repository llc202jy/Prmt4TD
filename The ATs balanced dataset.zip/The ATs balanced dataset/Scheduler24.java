namespace NCindy.Packet
{
    public class PriorityPacket : DelegatePacket, IComparable<PriorityPacket>
    {
        private static long SEQUENCE = 0;

        private readonly int priority;
        private readonly long createSequence;

        public PriorityPacket(IPacket packet, int priority)
            : base(packet)
        {
            this.priority = priority;
            this.createSequence = System.Threading.Interlocked.Increment(ref SEQUENCE);
        }

        public int CompareTo(Object obj)
        {
            PriorityPacket packet = (PriorityPacket)obj;
            int sp = packet.priority;
            return priority < sp ? -1 : (priority > sp ? 1
                    : (int)(createSequence - packet.createSequence));
        }

        public override String ToString()
        {
            return base.ToString() + " [priority] " + priority;
        }

        #region IComparable<PriorityPacket> Members

        /// <summary>
        /// Compare object's priority first, if the priority of
        /// two object are equal then compare the create time.
        /// </summary>
        /// <param name="other"></param>
        /// <returns>
        /// Less than zero      - This object is less than the other parameter.
        /// Zero                - This object is equal to other. 
        /// Greater than zero   - This object is greater than other.  
        ///</returns>
        public int CompareTo(PriorityPacket other)
        {
            int op = other.priority;

            if (this.priority < op)
            {
                return -1;
            }
            else if (priority > op)
            {
                return 1;
            }
            else
            {
                return (int)(createSequence - other.createSequence);
            }
        }

        #endregion
    }
}