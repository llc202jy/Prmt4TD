        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) { test.terminate(); }
        });
    }

    void jButton1_actionPerformed(ActionEvent e) {
        test.addProvider(jTextField1.getText());
        jTextField1.setText("");
    }

    void jButton2_actionPerformed(ActionEvent e) {
        test.removeProvider(jTextField1.getText());
        jTextField1.setText("");
    }

    void jButton3_actionPerformed(ActionEvent e) {
        test.rapidStates(jTextField1.getText());
        jTextField1.setText("");
    }

    void jButton4_actionPerformed(ActionEvent e) {
        test.removeListener(jTextField1.getText());
        jTextField1.setText("");
    }
 */
    public ConnectionServer() {

        super();

        listenSocket      = null;
        connectionFactory = null;
        open              = false;
    }



    /**
     * Constructor - creates a listening socket on the default ip address
     * returned for the given host name (should be this host). Initially the
     * default connection factory is assumed.
     */
    public ConnectionServer(String threadName, String hostName) throws IOException {
        super(threadName);
        constructServer(hostName, 0);
    }


    /**
     *
     * Constructor - creates a listening socket on the default ip address
     * returned for the given host name (should be this host), using the
     * given port. Initially the default connection factory is assumed.
     */
    public ConnectionServer(String threadName, String hostName, int port) throws IOException {
        super(threadName);
        constructServer(hostName, port);
    }


    /**
     * Constructor - creates a listening socket on the default ip address
     * returned for the given host name (should be this host), using the
     * given port. Initially the default connection factory is assumed.
     */
    public ConnectionServer(String threadName, InetAddress addr, int port) throws IOException {
        super(threadName);
        constructServer(addr, port);
    }

    /**
     * Constructor helper - creates a listening socket on the default ip address
     * returned for the given host name (should be this host), using the
     * given port. Initially the default connection factory is assumed.
     */
    private void constructServer(String hostName, int port) throws IOException {
        constructServer(InetAddress.getByName(hostName), port);
    }

    /**
     * Constructor helper - creates a listening socket on the default ip address
     * returned for the given InetAddress (should be this host), using the
     * given port. Initially the default connection factory is assumed.
     */

    private void constructServer(InetAddress inetAddress, int port) throws IOException {

        connectionFactory = new DefaultConnectionFactory();

        try {

            if( log.isDebugEnabled() ) {
                log.debug("Binding blocking connection server to port: " + port);
            }
            
            listenSocket = ServerSocketChannel.open();
            listenSocket.configureBlocking(true);
            listenSocket.socket().bind(new InetSocketAddress(inetAddress, port));

        } catch(IOException ioex) {
            
            if( log.isDebugEnabled() ) {
                log.debug("Failed to create server socket: ", ioex);
            }

           listenSocket = null;
           open  = false;
           throw ioex;

        }

        open = true;

    }



    /**
     * set the connection factory to the one specified as a parameter
     */
    public void setConnectionFactory(ConnectionFactory connectionFactory) {
        this.connectionFactory = connectionFactory;
    }



    /**
     * return the address being used by this ConnectionServer.
     */
    public ConnectionAddress getAddress() {

        if( listenSocket == null )
            return null;
        else
            return new ConnectionAddress( listenSocket.socket().getInetAddress(),
                                          listenSocket.socket().getLocalPort() );
    }


    public void shutdown() {
        open = false;
        try {
            listenSocket.close();
        } catch( IOException ioex ) {}
    }


    /**
     * blocking connection accept loop - creates a connection endpoint
     * in response to connection requests.
     */
    public void run() {

        while( open ) {

            try {
                SocketChannel channel = listenSocket.accept();
                connectionFactory.createConnection(channel);
            } catch(Exception ex) {
                if( open ) {
                    if( log.isInfoEnabled() )
                        log.info(ex);
                }
            }

        }

    }


    /**
     * returns an string representing the status of this thread
     */
    public String getThreadStatusString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append(super.getName()).append(" ............................ ").setLength(30);
        buffer.append(super.isAlive() ? ".. is Alive " : ".. is Dead ");
        buffer.append(open ? ".. running ....." : ".. terminated ..");
        buffer.append( " address = " ).append(getAddress().toString());
        return buffer.toString();
  }
}

