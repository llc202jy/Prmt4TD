import org.esfinge.business.factory.BusinessFactory;
import org.esfinge.business.interf.ComboService;
import org.esfinge.exception.ApplicationException;


/**
 * <!-- begin-xdoclet-definition --> 
 * @ejb.bean name="Combo"	
 *           description="A session bean named Combo"
 *           display-name="Combo"
 *           jndi-name="Combo"
 *           type="Stateless" 
 *           transaction-type="Container"
 * 
 * <!-- end-xdoclet-definition --> 
 */

public class ComboBean implements javax.ejb.SessionBean {

	
	private ComboService comboBusiness;
	private SessionContext context;
	
	public void setSessionContext(SessionContext context) throws EJBException, RemoteException {
		this.context = context;		
	}
	
	/** 
	 * <!-- begin-xdoclet-definition --> 
	 * @ejb.create-method view-type="remote"
	 * <!-- end-xdoclet-definition --> 
	 */
	public void ejbCreate() {
		try {
			Class.forName("org.esfinge.init.SystemInit");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		comboBusiness = BusinessFactory.getFactory().getComboService();
	}

	/** 
	 * <!-- begin-xdoclet-definition --> 
	 * @throws ApplicationException 
	 * @ejb.interface-method view-type="remote"
	 * <!-- end-xdoclet-definition --> 
	 */
	public List getComboInfo(String comboName, Map parameters) throws ApplicationException {
		return comboBusiness.getComboInfo(comboName,parameters);
	}
	
	/** 
	 * <!-- begin-xdoclet-definition --> 
	 * @throws ApplicationException 
	 * @ejb.interface-method view-type="remote"
	 * <!-- end-xdoclet-definition --> 
	 */
	public List[] getComboInfo(String[] comboNames, Map parameters) throws ApplicationException {
		return comboBusiness.getComboInfo(comboNames,parameters);
	}

	public void ejbRemove() throws EJBException, RemoteException {
	}

	public void ejbActivate() throws EJBException, RemoteException {
	}

	public void ejbPassivate() throws EJBException, RemoteException {
	}
}

	public Serializable save(String entityName, Object object) throws HibernateException {
		return session.save(entityName, object);
	}

	public void saveOrUpdate(Object object) throws HibernateException {
		session.saveOrUpdate(object);
	}

	public void saveOrUpdate(String entityName, Object object) throws HibernateException {
		session.saveOrUpdate(entityName, object);
	}

	public void setCacheMode(CacheMode cacheMode) {
		session.setCacheMode(cacheMode);
	}

	public void setFlushMode(FlushMode flushMode) {
		session.setFlushMode(flushMode);
	}

	public void setReadOnly(Object entity, boolean readOnly) {
		session.setReadOnly(entity, readOnly);
	}

	public void update(Object object) throws HibernateException {
		session.update(object);
	}

	public void update(String entityName, Object object) throws HibernateException {
		session.update(entityName, object);
	}
	
}

	public void reconnect(Connection connection) throws HibernateException {
		session.reconnect(connection);
	}

	public void refresh(Object object, LockMode lockMode) throws HibernateException {
		session.refresh(object, lockMode);
	}

	public void refresh(Object object) throws HibernateException {
		session.refresh(object);
	}

	public void replicate(Object object, ReplicationMode replicationMode) throws HibernateException {
		session.replicate(object, replicationMode);
	}

	public void replicate(String entityName, Object object, ReplicationMode replicationMode) throws HibernateException {
		session.replicate(entityName, object, replicationMode);
	}

	public Serializable save(Object object) throws HibernateException {
		return session.save(object);
	}

	public void lock(String entityName, Object object, LockMode lockMode) throws HibernateException {
		session.lock(entityName, object, lockMode);
	}

	public Object merge(Object object) throws HibernateException {
		return session.merge(object);
	}

	public Object merge(String entityName, Object object) throws HibernateException {
		return session.merge(entityName, object);
	}

	public void persist(Object object) throws HibernateException {
		session.persist(object);
	}

	public void persist(String entityName, Object object) throws HibernateException {
		session.persist(entityName, object);
	}

	public void reconnect() throws HibernateException {
		session.reconnect();
	}

		public void ejbRemove() throws EJBException, RemoteException {
			// TODO Auto-generated method stub
			
		}

		public void ejbActivate() throws EJBException, RemoteException {
			// TODO Auto-generated method stub
			
		}

		public void ejbPassivate() throws EJBException, RemoteException {
			// TODO Auto-generated method stub
			
		}
		
		
public List search(Object obj) throws ApplicationException{
			try {
				return crudBusiness.search(obj);
			} catch (ApplicationException e) {
				if(e.isRollbackTransaction())
					context.setRollbackOnly();
				throw e;
			} 
		}
		
		/** 
		 * <!-- begin-xdoclet-definition --> 
		 * @ejb.interface-method view-type="remote"
		 * @ejb.transaction type = "Required"
		 * <!-- end-xdoclet-definition --> 
		 */
		public Object executeGenericAction(Object obj, String actionName) throws ApplicationException{
			try {
				return crudBusiness.executeGenericAction(obj,actionName);
			} catch (ApplicationException e) {
				if(e.isRollbackTransaction())
					context.setRollbackOnly();
				throw e;
			}
		}
