public class ActivityContext {

	/**
	 * Comment for <code>serialVersionUID</code>
	 */
	private static final long serialVersionUID = 487857681918072300L;

	private static final String tcache = TransactionManagerImpl.RUNTIME_CACHE;

	// this is the distributed data structure which keeps a distributed cache
	// copy of an ActivityContext
	// the following section has the actual AC attributes that represent an AC
	// instance and are stored in the cache map
	private transient CacheableMap activityContextCacheMap;

	// BEGINnig of section for cacheable data structures

	// Set of timers that are attached to this ActivityContext
	private transient CacheableSet attachedTimers;

	// this should contain the sbb entity identities that are
	// attached to me.
	// a unique ordered list (aka Set). This map is ordered
	// from highest priority to lowest priority, with consideration of SbbEs
	// realations - child/parents
	// this is ensured by
	private transient Map acSbbAttachmentSet = null;

	private static final String SBB_ATTACHMENT_SET = "acSbbAttachmentSet";

	// the state of the activity context. One of {ACTIVE, ENDING, INVALID}
	// private ActivityContextState acState;

	private static final String AC_STATE = "acState";

	// named AC bindings. Used by AC Naming facility
	// private HashSet namingBinding;

	private transient CacheableSet namingBinding;

	// This stores the Activity Context specific data.
	// this stores the data that is shared between activities of the activity
	// context.

	CacheableMap dataAttributes;

	// set of SBBs that received an event during a given event delivery
	// transaction
	// private HashSet deliveredSbbSet;

	private static final String DELIVERED_SBB_SET = "acDeliveredSbbSet";

	// END of cacheable data structures

	SleeTransactionManager txManager;

	// The activity for which this activity context was generated.
	// this is not serialized to the cache
	private Object activity;

	private static transient Logger logger = Logger
			.getLogger(ActivityContext.class);

	// An identifier by which this AC can be mapped to an event.
	private String activityContextId;

	// The SLEE container.
	private transient SleeContainer sleeContainer;

	private transient SbbEntityFactory sbbEntityFactory;

	private transient SbbEntityComparator sbbEntityComparator;

	/**
	 * flags whether the AC is marked for removal. It can no longer be used past
	 * that point. AC is marked for removal after ActivityEnd event has been
	 * delivered.
	 */
	private boolean isMarkedForRemoval = false;

	
	/**
	 * This map contains mappings between acId and Long Objects. Long object represnt  timestamp of last access time to ac. 
	 * Cash is not a good place to hold this data - it is modified frequently  across tx causing rollbacks because of version errors. Values are first inserted when ac is created.
	 * There is posibility not to update or create this mapping by specifying <b>false</b> value to ActivityContext.createActivityContext(Object,boolean).
	 * This entry should be always updates if ac is used within core.
	 * Mapping are removed upon call of ActivityCOntext.markForRemoval function. However as this is static ap and we are
	 * acting in multithreaded env we cant be sure if this operation wasnt followed by some update (however tests didnt reveal this situation when trash is left),
	 * thus here is used WeakHashMap in which entries fade durign time. This is not a problem since ac should be accessed frequently, and if not we consider them old.
	 */
	private static Map timeStamps = new WeakHashMap<String, Long>(500);
 
	private void printNode() {
		if (logger.isDebugEnabled()) {
			logger.debug("ActivityContext.printNode() { \n"
					+ "activityContextId = " + this.getActivityContextId()
					+ "\nsbbAttachmentSet = "
					+ this.getSbbAttachmentSetForDebug()
					+ "\ngetDeliveredSet() = " + this.getDeliveredSetForDebug()
					+ "\nnamingBinding  = " + this.getNamingBinding()
					+ "\nattachedTimers = " + this.getAttachedTimers()
					+ "\nstate = " + this.getState() + "\ndata. = "
					+ this.getData() + "}");
		}
	}

	private ActivityContext(String activityContextId, Object activity,
			boolean refreshAccessTime) throws SystemException {

		assert (activity != null) : "activity cannot be null, for activity context ID "
				+ activityContextId;
		assert (activityContextId != null) : "activity Id cannot be null";

		this.activity = activity;

		this.activityContextId = activityContextId;

		this.txManager = SleeContainer.getTransactionManager();

		this.sleeContainer = SleeContainer.lookupFromJndi();
		sbbEntityFactory = sleeContainer.getSbbEntityFactory();
		sbbEntityComparator = new SbbEntityComparator(sbbEntityFactory);
		// init cacheable structures
		init(refreshAccessTime);
	}

	/**
	 * Cereates new activity or reads state from cache
	 * 
	 * @param activityId -
	 *            activity ID
	 * @param activity -
	 *            activity to mask behind this ac
	 * @param refreshAccessTime -
	 *            flag indicatign wheather creation time of this copy should be new
	 *            timestamp of access to ac
	 * @return ac
	 * @throws Exception
	 */
	public static ActivityContext createActivityContext(String activityId,
			Object activity, boolean refreshAccessTime) throws Exception {
		if (logger.isDebugEnabled()) {
			logger
					.debug("ActivityContext.createActivityContext(): Creating activity context for "
							+ activity);
		}
		ActivityContext ac = new ActivityContext(activityId, activity,
				refreshAccessTime);

		if (logger.isDebugEnabled()) {
			ac.printNode();
		}

		return ac;
	}

	/**
	 * Associate this object instance with an underlying distributed cache
	 * structure
	 * 
	 */
	private void init(boolean refreshAccessTime) {
		txManager.mandateTransaction();

		activityContextCacheMap = new CacheableMap(tcache + "-"
				+ getNodeNameInCache());

		final String ATTACHED_TIMERS = "acAttachedTimers";
		attachedTimers = new CacheableSet(tcache + "-" + getNodeNameInCache()
				+ ":" + ATTACHED_TIMERS);

		final String DATA_ATTRIBUTES = "acDataAttributes";
		dataAttributes = new CacheableMap(tcache + "-" + getNodeNameInCache()
				+ ":" + DATA_ATTRIBUTES);

		final String NAMING_BINDING = "acNamingBinding";
		namingBinding = new CacheableSet(tcache + "-" + getNodeNameInCache()
				+ ":" + NAMING_BINDING);
		// acSbbAttachmentSet = new
		// CacheableTreeMap(tcache,SBB_ATTACHMENT_SET+":"+this.activityContextId,false,new
		// SbbEntityComparator(SleeContainer.lookupFromJndi().getSbbEntityFactory()));
		acSbbAttachmentSet = new CacheableMap(tcache + "-" + SBB_ATTACHMENT_SET
				+ ":" + this.activityContextId);

		Object o = activityContextCacheMap.get(AC_STATE);

		
		// if the AC is just being created, there would not be a cached copy
		if (o == null) {
			activityContextCacheMap.put(AC_STATE, ActivityContextState.ACTIVE);
			activityContextCacheMap.put(DELIVERED_SBB_SET, new HashSet());

		}
		if (refreshAccessTime) {

			this.updateLastAccessTime();

		}
	}

	/**
	 * return the node name under which this AC is cached.
	 * 
	 */
	public String getNodeNameInCache() {
		assert (this.activityContextId != null) : "activityContextId cannot be null!";
		return "activitycontext:" + this.activityContextId;
	}

	private String makeSbbEntityKeyForAttachmentSet(SbbEntity sbbe) {
		String sbbEntityId = sbbe.getSbbEntityId();
		return (sbbe.getPriority() + 150) + "_" + sbbEntityId;
	}

	/**
	 * attach an sbb entity to this AC.
	 * 
	 * @param sbbEntity --
	 *            sbb entity to attach.
	 * @return true if the SBB Entity is attached successfully, otherwise when
	 *         the SBB Entitiy has already been attached before, return false
	 * @throws javax.slee.TransactionRequiredLocalException
	 * @throws javax.slee.TransactionRolledbackLocalException
	 * @throws javax.slee.SLEEException
	 */

	public synchronized boolean attachSbbEntity(String sbbEntityId)
			throws javax.slee.TransactionRequiredLocalException {

		txManager.mandateTransaction();
		if (logger.isDebugEnabled()) {
			logger.debug("ActivityContext.attach() : " + sbbEntityId
					+ " activityContextId = " + this.activityContextId);
		}

		// WE NEED SbbE
		SbbEntity sbbe = this.sbbEntityFactory
				.getSbbEntity((String) sbbEntityId);
		String key = makeSbbEntityKeyForAttachmentSet(sbbe);

		if (!getSbbAttachmentSet().containsKey(key)) {

			getSbbAttachmentSet().put(key, sbbEntityId);
			sbbe.afterACAttach(this.activityContextId);
			if (logger.isDebugEnabled()) {
				logger
						.debug("After Attach to Activity Context : Attachment Set = "
								+ this.getSbbAttachmentSet());
			}
			return true;
		} else {
			// we have a case of multiple consequent attachment attempts,
			// without detachment between them
			return false;
		}
	}

	/**
	 * 
	 * Ensures that the underlying distributed cache is aware that an entry has
	 * been modified in the activityContextCacheMap. Some of the more
	 * sophisticated dcache systems are able to detect this automatically.
	 * 
	 * @param attribute
	 *            key
	 */
	private void updateCacheEntry(String attributeKey) {
		Object o = activityContextCacheMap.get(attributeKey);
		activityContextCacheMap.put(attributeKey, o);
	}

	/**
	 * Detach the sbb entity
	 * 
	 * @param sbbEntityId
	 */
	public synchronized void detachSbbEntity(String sbbEntityId) {
		SbbEntity sbbE = this.sbbEntityFactory.getSbbEntity(sbbEntityId);

		Map sbbAttachmentSet = getSbbAttachmentSet();

		if (sbbAttachmentSet
				.containsKey(makeSbbEntityKeyForAttachmentSet(sbbE))) {

			sbbAttachmentSet.remove(makeSbbEntityKeyForAttachmentSet(sbbE));

			if (logger.isDebugEnabled()) {
				try {
					logger.info("Detaching SbbEntity[ID:" + sbbEntityId
							+ "] \n" + " from ActivityContext[ID:"
							+ this.activityContextId + "]\n"
							+ " Remaining SbbEntities: "
							+ sbbAttachmentSet.keySet() + "\n"
							+ " Transaction[ID:" + txManager.getTransaction()
							+ "]");
				} catch (SystemException e) {
					logger.warn("Failed to obtain transaction", e);
				}
			}
		}
		// dataching an SBB from an activity context should not cause
		// reclamation of the activity // this.checkForImplicitEnd();
		this.sleeContainer.getSbbEntityFactory().getSbbEntity(sbbEntityId)
				.afterACDetach(this.activityContextId);

		if (getAcState() != ActivityContextState.ENDING) {
			scheduleCheckForNullActivityImplicitEnd();
		}
	}

	/**
	 * get an ordered copy of the set of SBBs attached to this ac. The ordering
	 * is by SBB priority.
	 * 
	 * @return list of SbbEIDs
	 * 
	 */
	public synchronized List getSortedCopyOfSbbAttachmentSet() {
		Map sbbSet = new TreeMap(sbbEntityComparator);
		Map sbbAttachmentSet = getSbbAttachmentSet();
		if (logger.isDebugEnabled()) {
			try {
				logger.info("ActivityContext[ID:" + activityContextId + "],\n"
						+ "  SbbAttachmentSet: " + sbbAttachmentSet.keySet()
						+ ",\n  Transaction[ID:" + txManager.getTransaction()
						+ "]");
			} catch (SystemException e) {
				logger.warn("Failed to obtain transaction", e);
			}
		}

		sbbSet.putAll(sbbAttachmentSet);
		return new LinkedList(sbbSet.values());
	}

	/**
	 * get activity attached to this ac.
	 * 
	 * @return
	 */
	public Object getActivity() {
		return this.activity;
	}

	/**
	 * set the activity for this Acivity
	 * 
	 * @param activity
	 */
	public void setActivity(Object activity) {
		this.activity = activity;
	}

	/**
	 * set the current state of the activity context
	 * 
	 * @param acState
	 */
	public synchronized void setState(ActivityContextState activityContextState) {
		if (logger.isDebugEnabled()) {
			logger.debug("ActivityContext.setState( " + activityContextState
					+ " )");
		}

		if (!this.getState().equals(activityContextState)) {
			this.setAcState(activityContextState);
		}

	}

	/**
	 * test if the activity context is ending.
	 * 
	 * @return true if ending.
	 */
	public synchronized boolean isEnding() {
		if (logger.isDebugEnabled())
			logger.debug("ActivityContext.isEnding(): state = "
					+ this.getState());
		this.getState();

		return this.getAcState().equals(ActivityContextState.ENDING);
	}

	/**
	 * test if the AC is invalid
	 * 
	 * @return
	 */
	public boolean isInvalid() {
		return (this.isMarkedForRemoval || this.getState().equals(
				ActivityContextState.INVALID));
	}

	/**
	 * get the state of the AC
	 * 
	 * @return the state.
	 */
	public synchronized ActivityContextState getState() {
		return getAcState();
	}

	/**
	 * Set a shared data item for the ACI
	 * 
	 * @param key --
	 *            name of the shared data item.
	 * @param newValue --
	 *            value of the shared data item.
	 */
	public synchronized void setDataAttribute(String key, Object newValue) {
		if (logger.isDebugEnabled()) {
			logger.debug("ActivityContext.setDataAttribute(): " + key
					+ " value " + newValue);
		}
		dataAttributes.put(key, newValue);
	}

	/**
	 * Get the shared data for the ACI.
	 * 
	 * @param name --
	 *            name we want to look up
	 * @return the shared data for the ACI
	 * 
	 */
	public synchronized Object getDataAttribute(String key) {
		if (logger.isDebugEnabled()) {
			logger.debug("ActivityContext.getDataAttribute(): " + key);
		}
		return dataAttributes.get(key);
	}

	private Object getData() {
		if (logger.isDebugEnabled()) {
			logger.debug("ActivityContext.getData()");
		}
		return dataAttributes;
	}

	public Map getDataAttributesCopy() {
		// Is this safe?
		return new HashMap((Map) getData());

	}

	/**
	 * return true if the AC is removable.
	 * 
	 * @return
	 */
	public synchronized boolean isRemovable() {
		if (logger.isDebugEnabled()) {
			logger.debug("isRemovable(): attachmentSet = "
					+ this.getSbbAttachmentSet() + " state = "
					+ this.getState());
		}
		return (getSbbAttachmentSet().size() == 0 && this.getState().equals(
				ActivityContextState.INVALID));
	}

	/**
	 * This is called by the event router to release all the name bindings after
	 * the activity end event is delivered to the sbb.
	 * 
	 */
	public synchronized void removeNamingBindings() {

		Iterator iterator = this.getNamingBinding().iterator();
		ActivityContextNamingFacilityImpl acf = (ActivityContextNamingFacilityImpl) this.sleeContainer
				.getActivityContextNamingFacility();
		while (iterator.hasNext()) {
			String name = (String) iterator.next();

			try {

				acf.unbindWithoutCheck(name);

				// iterator.remove();
			} catch (Exception e) {
				logger.warn("Failed to unbind name: " + name
						+ " from activity context Id:" + activityContextId, e);
			}
		}

	}

	// Spec Sec 7.3.4.1 Step 10. "The SLEE notifies the SLEE Facilities that
	// have references to the Activity Context that the Activ-ity
	// End Event has been delivered on the Activity Context.
	public synchronized void removeFromTimers() {
		TimerFacilityImpl timerFacility = null;
		try {
			timerFacility = (TimerFacilityImpl) SleeContainer
					.getTimerFacility();
		} catch (NamingException ex) {
			logger.error("cannot retieve timer facility", ex);
			return;
		}
		// Iterate through the attached timers, telling the timer facility to
		// remove them
		Iterator iter = new HashSet(getAttachedTimers()).iterator();

		while (iter.hasNext()) {
			TimerID timerID = (TimerID) iter.next();
			timerFacility.cancelTimer(timerID);
		}
	}

	/**
	 * add a naming binding to this activity context.
	 * 
	 * @param aciName -
	 *            new name binding to be added.
	 * 
	 */
	public synchronized void addNameBinding(String aciName) {
		this.getNamingBinding().add(aciName);
	}

	private Set getNamingBinding() {
		return namingBinding;
	}

	/**
	 * Fetches set of names given to this ac
	 * 
	 * @return Set containing String objects that are names of this ac
	 */
	public Set getNamingBindingCopy() {
		return new HashSet(getNamingBinding());

	}

	private Set getDeliveredSet() {
		Set ds = (Set) activityContextCacheMap.get(DELIVERED_SBB_SET);
		return ds;
	}

	/**
	 * Add the given name to the set of activity context names that we are bound
	 * to. The AC Naming facility implicitly ends the activity after all names
	 * are unbound.
	 * 
	 * @param aciName --
	 *            name to which we are bound.
	 * 
	 */
	public synchronized void removeNameBinding(String aciName) {
		if (getNamingBinding().contains(aciName)) {
			this.getNamingBinding().remove(aciName);
			if (getAcState() != ActivityContextState.ENDING) {
				scheduleCheckForNullActivityImplicitEnd();
			}
		}

	}

	/**
	 * attach the given timer to the current activity context.
	 * 
	 * @param timerID --
	 *            timer id to attach.
	 * 
	 */
	public synchronized void attachTimer(TimerID timerID) {
		if (logger.isDebugEnabled())
			logger.debug("attachTimer(" + timerID + ")");

		if (!getAttachedTimers().contains(timerID)) {
			this.getAttachedTimers().add(timerID);
		}
	}

	/**
	 * 
	 * If the activity is a null activity it implicitly ends when there are no
	 * sbbs or facilities (timer or naming) attached to it at the end of an
	 * ongoing transaction.
	 * 
	 * <pre>
	 *      
	 *       From JSLEE 1.0 Spec #7.10.5.1
	 *       7.10.5.1 Implicitly ending a NullActivity object
	 *      	The condition that implicitly ends a NullActivity object is as follows:
	 *      	  No SBB entities are attached to the Activity Context of the NullActivity object, and
	 *      	  No SLEE Facilities reference the Activity Context of the NullActivity object, and
	 *      	  No events remain to be delivered on the Activity Context of the NullActivity object.
	 *      
	 *      	All methods that may change the attachments or references of an Activity Context are mandatory transactional.
	 *      	Hence, if an SBB method invocation changes an Activity Contexts attachments and references, it
	 *      	must do so within a transaction. Therefore, when the transaction commits, the SLEE only has to examine
	 *      	the NullActivity objects whose Activity Contexts were enrolled in the transaction to determine which
	 *      	NullActivity objects should end.
	 * </pre>
	 */
	private void checkForNullActivityImplicitEnd() {
		if (logger.isDebugEnabled()) {
			logger.debug("Checking for implicit end of null activity");
		}

		// clear the tx local flag. it has no meaning outside of the current tx
		activityContextCacheMap.remove(txLocalNullAciCheckKey);

		if (!this.isEnding() && !this.isInvalid()) {
			if (this.getSbbAttachmentSet().size() == 0
					&& this.getAttachedTimers().size() == 0
					&& this.getNamingBinding().size() == 0) {
				// No sbbs or facilities attached
				if (logger.isDebugEnabled()) {
					logger.debug("scheduling activity end event");
				}

				this.sleeContainer.getSleeEndpoint()
						.scheduleActivityEndedEvent(this.getActivity());

			}
		}
	}

	/**
	 * unique key used to flag that an implicit null aci end check action has
	 * been scheduled on tx commit
	 */
	private static final String txLocalNullAciCheckKey = "tx-local-flag-NullActivityImplicitEndCheckAction";

	/**
	 * 
	 * Register a tx syncronization
	 * 
	 */
	private void scheduleCheckForNullActivityImplicitEnd() {
		if (!(this.getActivity() instanceof NullActivityImpl))
			return;

		// the implicit check should be scheduled only once
		if (activityContextCacheMap.get(txLocalNullAciCheckKey) != null)
			return;

		if (logger.isDebugEnabled()) {
			logger
					.debug("Scheduling checking for implicit NullActivity end at the end of the ongoing transaction");
		}
		;

		TransactionalAction implicitEndCheck = new TransactionalAction() {
			public void execute() {
				checkForNullActivityImplicitEnd();
			}
		};

		// raise the flag to ensure that the check is not scheduled more than
		// once
		activityContextCacheMap.put(txLocalNullAciCheckKey, Boolean.TRUE);

		txManager.addPrepareCommitAction(implicitEndCheck);
	}

	/**
	 * Add the sbb entity id to our delivered set
	 * 
	 * @param sbbEid --
	 *            sbb entity id to add to the set.
	 * 
	 */

	public synchronized void addToDeliveredSet(String sbbEid) {
		this.getDeliveredSet().add(sbbEid);
		updateCacheEntry(DELIVERED_SBB_SET);
	}

	

	/**
	 * Mark this AC for garbage collection. It can no longer be used past this
	 * point.
	 * 
	 */
	public void markForRemove() {
		activityContextCacheMap.remove();
		attachedTimers.remove();
		namingBinding.remove();
		dataAttributes.remove();
		isMarkedForRemoval = true;
		// Beyond here we dont stamp this one
		ActivityContext.timeStamps.remove(this.activityContextId);


	}

	/**
	 * return true if the delviered set contains a given SbbEntity ID.
	 * 
	 * @param sbbEntityId
	 * @return
	 */

	public synchronized boolean deliveredSetContains(String sbbEntityId) {
		return this.getDeliveredSet().contains(sbbEntityId);
	}

	public synchronized String getDeliveredSetForDebug() {
		return this.getDeliveredSet().toString();
	}

	public synchronized void clearDeliveredSet() {
		Set ds = (Set) activityContextCacheMap.get(DELIVERED_SBB_SET);
		ds.clear();
		activityContextCacheMap.put(DELIVERED_SBB_SET, ds);
	}

	public synchronized boolean removeFromDeliveredSet(String sbbEntityId) {
		Set ds = getDeliveredSet();
		boolean retval = ds.contains(sbbEntityId);
		if (retval) {
			ds.remove(sbbEntityId);
			updateCacheEntry(DELIVERED_SBB_SET);
		}
		return retval;
	}

	/**
	 * Return a string containing the sbb entity ids attached.
	 * 
	 * @return
	 */
	public synchronized String getSbbAttachmentSetForDebug() {
		return this.getSbbAttachmentSet().values().toString();
	}

	/**
	 * @return Returns the activityContextId.
	 */
	public String getActivityContextId() {
		return activityContextId;
	}

	/**
	 * Detach timer and check for activity end
	 * 
	 * @param timerID
	 * @param checkForActivityEnd
	 */
	public synchronized void detachTimer(TimerID timerID,
			boolean checkForActivityEnd) {

		if (logger.isDebugEnabled())
			logger.debug("detachTimer ( timerID= " + timerID
					+ ", checkForAcEnd =" + checkForActivityEnd + ")");

		if (this.getAttachedTimers().contains(timerID)) {
			this.getAttachedTimers().remove(timerID);
			if (checkForActivityEnd)
				scheduleCheckForNullActivityImplicitEnd();
		}

	}

	private Set getAttachedTimers() {
		return attachedTimers;
	}

	/**
	 * Fetches set of attached timers.
	 * 
	 * @return Set containing TimerID objects representing timers attached to
	 *         this ac.
	 */
	public Set getAttachedTimersCopy() {
		return new HashSet(getAttachedTimers());
	}

	private Map getSbbAttachmentSet() {
		// List sbbAttachmentSet =
		// (List)activityContextCacheMap.get(SBB_ATTACHMENT_SET);
		return acSbbAttachmentSet;
	}

	private void setAcState(ActivityContextState acState) {
		activityContextCacheMap.put(AC_STATE, acState);
	}

	private ActivityContextState getAcState() {
		ActivityContextState acState = (ActivityContextState) activityContextCacheMap
				.get(AC_STATE);
		return (acState != null) ? acState : ActivityContextState.ACTIVE;
	}

	private class SbbEntityComparator implements Comparator {
		SbbEntityFactory sbbEntityFactory;

		SbbEntityComparator(SbbEntityFactory sbbEntityFactory) {
			this.sbbEntityFactory = sbbEntityFactory;
		}

		private Stack priorityOfSbb(SbbEntity sbbe) {
			Stack stack = new Stack();

			String sbbeId = null;
			do { // Ralf Siedow: changed to !equals and removed "root"; see
				// below
				sbbeId = sbbe.getSbbEntityId();
				/*
				 * CHECKME is this correct? the spec says "while sbbe is not
				 * SBBE[0]" with SBBE[0] being "the SLEE as the logical parent
				 * SBB entity of all root SBB entities."
				 */
				stack.push(sbbe);
				sbbe = sbbEntityFactory.getSbbEntity(sbbe.getParentSbbId());
			} while (!sbbeId.equals(sbbe.getRootSbbId())); // Ralf Siedow:
			// changed
			// to dowhile
			return stack;

		}

		public int compare(Object priority1_sbbeId1, Object priority2_sbbeId2) {

			// In case we are looking for this entry - this will save some
			// CPU cycles, cache readings etc.
			if (priority1_sbbeId1.equals(priority2_sbbeId2))
				return 0;
			String sbbeId1, sbbeId2;
			String split[] = null;
			split = ((String) priority1_sbbeId1).split("_");
			sbbeId1 = split[1];
			split = ((String) priority2_sbbeId2).split("_");
			sbbeId2 = split[1];
			SbbEntity sbbe1 = this.sbbEntityFactory.getSbbEntity(sbbeId1);
			SbbEntity sbbe2 = this.sbbEntityFactory.getSbbEntity(sbbeId2);

			return higherPrioritySbb(sbbe1, sbbe2);
		}

		private int higherPrioritySbb(SbbEntity sbbe1, SbbEntity sbbe2) {
			logger.debug("higherPrioritySbb " + sbbe1.getSbbId() + " "
					+ sbbe2.getSbbId());

			Stack stack1 = priorityOfSbb(sbbe1);
			Stack stack2 = priorityOfSbb(sbbe2);
			while (true) {
				SbbEntity sbb1a = (SbbEntity) stack1.pop();
				SbbEntity sbb2a = (SbbEntity) stack2.pop();
				if (sbb1a == sbb2a) {
					// sbb entities have the same ancestor.
					if (stack1.isEmpty()) {

						return -1;

					} else if (stack2.isEmpty()) {

						return 1;

					}
				} else {

					if (sbb1a.getPriority() > sbb2a.getPriority()) {

						return -1;

					} else if (sbb1a.getPriority() < sbb2a.getPriority()) {

						return 1;

					} else {

						return sbb1a.getSbbEntityId().compareTo(
								sbb2a.getSbbEntityId());
						// does it matter?
						// We need predicatble order to get TreeMap opeartional
						// and not returning some silly null values
						// So this will ensure that if SbbE are on the same leve
						// (childs) in SbbETree, and have the same priority
						// They will be stored alphabeticaly.
					}

				}
			}
		}
	}

	/**
	 * Returns time stamp of last access to this ac. If timestamp is found it return its value, if not "0"- it means that ac was accessed not during last few cycles,
	 * thus its value has faded.
	 * @return
	 */
	public long getLastAccessTime() {


		Long l = (Long) ActivityContext.timeStamps.get(this.activityContextId);
		if (l != null)
			return l.longValue();
		else
			return 0;
	}

	void updateLastAccessTime() {

		if (this.isMarkedForRemoval)
			return;
		long currentAccessTime = System.currentTimeMillis();
		long lastAccessTime = getLastAccessTime();
		if (lastAccessTime == 0) {
			Long l = new Long(currentAccessTime);
			ActivityContext.timeStamps.put(this.activityContextId, l);


		} else {
			if (currentAccessTime <= lastAccessTime
					|| (currentAccessTime - lastAccessTime) < 60000) {
				//discard it, passed value is less than stored one, or its not old enough
				return;
			} else {

				
				Long l = new Long(currentAccessTime);
				ActivityContext.timeStamps.put(this.activityContextId, l);

			}
		}

	}


	public String toString() {
		return getClass().getName() + "[" + activityContextId + "]";
	}

 * Up to 32 tasks can be loaded, at any given time, for scheduling.  Once
 * loaded, tasks can be scheduled to run in any, or all, of three ways;
 * Synchronous, Triggered, or Asynchronous. The class implements three
 * methods to flag a loaded task as such.  The following is a description of
 * the scheduling algorithm:
 * <p>
 * When a task is flagged as asynchronous, it will be run only when no
 * tasks are flagged as synchronous, or triggered, at the start of its
 * slice.  Its asynchronous flag is not cleared when it is run, meaning until
 * stopped, it will be run again automatically, as scheduling permits.
 * Scheduling among multiple asynchronous flags is round-robbin, to ensure
 * each an opportunity to run.  This provides a method for scheduling
 * low-priority tasks.  Typically an asynchronous task will break its
 * functionality into distinct pieces, and use a switch() type mechanism to
 * execute only one piece per timeslice.
 * <p>
 * When a task is flagged as triggered, will run before any tasks flagged
 * asynchronous, but only when no tasks are flagged as synchronous, at the
 * start of its slice.  The trigger flag is cleared when the task is run,
 * meaning that unless re-flagged as triggered, it will not run again
 * through the trigger scheduling algorithm. This provides an event-driven
 * mode of execution, but at a lower priority than the synchronous mode.
 * <p>
 * When a task is flagged as synchronous, it will run before any triggered,
 * or asynchronous flagged tasks are allowed to run.  Its synchronous flag
 * is also cleared when the task is run. Since the scheduling is not
 * preemptive, any currently running task is allowed to complete. This flag
 * provides the highest responsiveness to a synchronizing event.
 * <p>
 * The stop method is used to prevent the execution of any flagged task.
 * General notes:<ul>
 * <li>
 * Since scheduling is not preemptive, developers must agressively minimize
 * asynchronous task's run time length, to decrease the latency of event
 * responsiveness.  This becomes especially important when tasks are elevated
 * in priority.
 * <li>
 * Non-preemptive scheduling eliminates all synchronization concerns for
 * objects shared between scheduled tasks.
 * <li>
 * As a general rule: try to use asynchronous scheduling initially.  Then, as
 * the design runtime load increases, selected tasks can be boosted in
 * proiority to achieve the desired responsiveness.
 * </ul><p>
 * <i>Note:</i>  This class supports serialisation.  It will restart the
 * scheduling task automatically on deserialisation.  However, in order for
 * serialisation to succeed, all of the loaded tasks must also be
 * serialisable.
 *
 * @version 1.0, 01-Nov-99 Initial release
 * @author John Catherino
 *
 */

public final class Scheduler implements Serializable {
   private static final String
      INDEX_INVALID = "task table index invalid";
   private transient Thread thread;
   private int syncFlags, soonFlags, wakeFlags;
   private Object list[] = new Object[32];
   private void readObject(ObjectInputStream in)
      throws IOException, ClassNotFoundException {
      in.defaultReadObject();
      setEnabled(true);
   }
   private final Runnable kernel = new Runnable() {
      public void run() {
         try {
            int next = 0;
            while (!thread.isInterrupted()) {
               int slot = 0;
               synchronized(Scheduler.this) {
                  if (syncFlags != 0) {
                     int mask = 1;
                     while((syncFlags & mask) == 0) {
                        slot++;
                        mask <<= 1;
                     }
                     syncFlags ^= mask;
                  } else if (soonFlags != 0) {
                     int mask = 1;
                     while((soonFlags & mask) == 0) {
                        slot++;
                        mask <<= 1;
                     }
                     soonFlags ^= mask;
                  } else if (wakeFlags != 0) {
                     for (int i = 0; i < 32; i++) {
                        if (++next == 32) next = 0;
                        if ((1 << next & wakeFlags) != 0) {
                           slot = next;
                           break;
                        }
                     }
                  } else {
                     Scheduler.this.wait();
                     continue;
                  }
               }
               try { Remote.invoke(list[slot], "slice", null); }
               catch(Exception x) { drop(slot); }
           }
         } catch(InterruptedException x) {}
      }
   };
   /**
    * Nothing is performed in the constructor, since no tasks can be
    * scheduled for execution until they have been loaded.
    */
   public Scheduler() {}
   /**
    * This method will start, or suspend, the scheduler.  The scheduler will
    * be started automatically when the first task is flagged for execution.
    * The method is idempotent; therefore enabling an already enabled
    * scheduler will cause no effect, just as disabling a currently disabled
    * scheduler.
    * @param enabled The flag to indicate if this is a startup, or suspend
    * operation.
    * @return true if successfully started or stopped, false if not for
    * logical reasons, i.e. already stopped/started, no tasks running.
    */
   public synchronized boolean setEnabled(boolean enabled) {
      if (enabled) {
         if (syncFlags != 0 | soonFlags != 0 | wakeFlags != 0) {
            if (thread == null) {
               thread = new Thread(kernel);
               thread.start();
               return true;
            } else notify();
         }
      } else {
         if (thread != null) {
            thread.interrupt();
            thread = null;
            return true;
         }
      }
      return false;
   }
   /**
    * This method accepts a task to be scheduled.  If the task is accepted,
    * it is placed in the table, but will not be executed, until it is
    * flagged for operation. If the execution of the task slice results in
    * an exception, the task will be automatically dropped from the queue.
    * @param task The task to attempt to schedule, it may be either local,
    * remote, or even a proxy, when enabled.
    * @return the index of the task in the table.  The task table index is
    * used in the scheduling methods.
    * @throws IllegalArgumentException If the task table is full.
    */
   public synchronized int load(Object task) {
      for (int slot = 0; slot < 32; slot++) {
	     if (list[slot] == null) {
	        list[slot] = task;
            return slot;
         }
      }
      throw new IllegalArgumentException("task table currently full");
   }
   /**
    * This method sets the synchronous execution flag for a task. The flag
    * will be cleared automatically, when the scheduler calls this task.
    * @param task The index of the task in the table
    * @return false if the task was already flagged, or not in the queue,
    * else true if successfully flagged.
    * @throws IllegalArgumentException If the task table index is invalid.
    */
   public synchronized boolean sync(int task) {
      if (task >= 0 && task < 32) {
         int mask = 1 << task;
         if ((syncFlags & mask) == 0) {
            syncFlags |= mask;
            setEnabled(true);
            return true;
         } else return false;
      } else throw new IllegalArgumentException(INDEX_INVALID);
   }
   /**
    * This method sets the triggered execution flag for a task.  It will be
    * cleared just before passing execution on to the task.
    * @param  task The index of the task in the table
    * @return true if successfully flagged, false if already flagged
    * @throws IllegalArgumentException If the task table index is invalid.
    */
   public synchronized boolean soon(int task) {
      if (task >= 0 && task < 32) {
         int mask = 1 << task;
         if ((soonFlags & mask) == 0) {
            soonFlags |= mask;
            setEnabled(true);
            return true;
         } else return false;
      } else throw new IllegalArgumentException(INDEX_INVALID);
   }
   /**
    * This method sets the asynchronous execution flag for a task. It will
    * <u>not</u> be cleared when passing execution on to the task. The flag
    * will retain its state, until disabled through the stop method.
    * @param  task The index of the task to be scheduled for continuous
    * asynchronous execution.
    * @return true if successfully flagged, false if already flagged.
    * @throws IllegalArgumentException If the task table index is invalid.
    */
   public synchronized boolean wake(int task) {
      if (task >= 0 && task < 32) {
         int mask = 1 << task;
         if ((wakeFlags & mask) == 0) {
            wakeFlags |= mask;
            setEnabled(true);
            return true;
         } else return false;
      } else throw new IllegalArgumentException(INDEX_INVALID);
   }
   /**
    * This method clears all scheduling flags for indicated task.  The task
    * will reamain in the table however. <i>Note:</i> to remove a task, use
    * the drop method instead, it automatically calls stop, before removing
    * the task from the table.
    * @param task The index of the task in the table
    * @throws IllegalArgumentException If the task table index is invalid.
    */
   public synchronized void stop(int task) {
      if (task >= 0 && task < 32) {
         int mask = ~(1 << task);
         syncFlags &= mask;
         soonFlags &= mask;
         wakeFlags &= mask;
      } else throw new IllegalArgumentException(INDEX_INVALID);
   }
   /**
    * This method clears all scheduling flags for the indicated task, and
    * also removes it from the table.
    * @param task The index of the task to stop and remove from the table.
    * @throws IllegalArgumentException If the task table index is invalid.
    */
   public synchronized void drop(int task) {
      if (task >= 0 && task < 32) {
         stop(task);
         list[task] = null;
      } else throw new IllegalArgumentException(INDEX_INVALID);
   }
   /**
    * The purpose of this function is to reduce event-driven task latency by
    * allowing asynchronous tasks to voluntarily exit prematurely.  To
    * improve responsiveness, asynchronous tasks could check this method,
    * before going on to another functionally distinct section of its task
    * execution. It is normally checked when the async task has some periodic
    * extra work, if the method returns false, the extra work could be
    * processed in its current slice.
    * @return true if synchronous or triggered tasks have been flagged for
    * execution, false if it is OK for the task to continue running a little
    * longer.
    */
   public boolean pending() {
      return syncFlags != 0 | soonFlags != 0;
   }
