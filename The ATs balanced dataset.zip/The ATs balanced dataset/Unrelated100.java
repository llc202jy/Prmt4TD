* Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package edu.my.util.cmn;
/**
 * This class aggregates a <code>SecurityManager</code> object and delegates all requests to the aggregated <code>SecurityManager</code> instance.
 * it is intended to provide a default implementation. subclasses can override only methods in interest. 
 * @author  Ben Yu
 * @version 1.0, 09/09/02
 */
 
import java.security.*;
import java.io.FileDescriptor;
import java.io.File;
import java.io.FilePermission;
import java.awt.AWTPermission;
import java.util.PropertyPermission;
import java.lang.RuntimePermission;
import java.net.SocketPermission;
import java.net.NetPermission;
import java.util.Hashtable;
import java.net.InetAddress;
import java.lang.reflect.Member;
import java.lang.reflect.*;
import java.net.URL;


public class DelegateSecurityManager extends SecurityManager{

 public void checkAccept(String host, int port){
 	sm.checkAccept(host, port);
 }
          
 public void checkAccess(Thread t){
 	sm.checkAccess(t); 
 }
          
 public void checkAccess(ThreadGroup g){
 	sm.checkAccess(g);
 }
          
 public void checkAwtEventQueueAccess(){
 	sm.checkAwtEventQueueAccess();
 }
 public void checkConnect(String host, int port){
 	sm.checkConnect(host, port);
 }
          
 public void checkConnect(String host, int port, Object context){
 	sm.checkConnect(host, port, context);
 }
          
 public void checkCreateClassLoader(){
 	sm.checkCreateClassLoader();
 }
          
 public void checkDelete(String file){
 	sm.checkDelete(file);
 }
          
 public void checkExec(String cmd){
 	sm.checkExec(cmd);
 }
          
 public void checkExit(int status){
 	sm.checkExit(status);
 }
          
 public void checkLink(String lib){
 	sm.checkLink(lib);
 }
          
 public void checkListen(int port){
 	sm.checkListen(port);
 }
          
 public void checkMemberAccess(Class clazz, int which){
 	sm.checkMemberAccess(clazz, which);
 }
          
 public void checkMulticast(InetAddress maddr){
 	sm.checkMulticast(maddr);
 }
          
 public void checkPackageAccess(String pkg){
 	sm.checkPackageAccess(pkg);
 }
          
 public void checkPackageDefinition(String pkg){
 	sm.checkPackageDefinition(pkg);
 }
          
 public void checkPermission(Permission perm){
 	sm.checkPermission(perm);
 }
          
 public void checkPermission(Permission perm, Object context){
 	sm.checkPermission(perm, context);
 }
          
 public void checkPrintJobAccess(){
 	sm.checkPrintJobAccess();
 }
          
 public void checkPropertiesAccess(){
 	sm.checkPropertiesAccess();
 }
          
 public void checkPropertyAccess(String key){
 	sm.checkPropertyAccess(key);
 }
          
 public void checkRead(FileDescriptor fd){
 	sm.checkRead(fd);
 }
          
 public void checkRead(String file){
 	sm.checkRead(file);
 }
          
 public void checkRead(String file, Object context){
 	sm.checkRead(file, context);
 }
          
 public void checkSecurityAccess(String target){
 	sm.checkSecurityAccess(target);
 }
          
 public void checkSetFactory(){
 	sm.checkSetFactory();
 }
          
 public void checkSystemClipboardAccess(){
 	sm.checkSystemClipboardAccess();
 }
          
 public boolean checkTopLevelWindow(Object window){
 	return sm.checkTopLevelWindow(window);
 }
          
 public void checkWrite(FileDescriptor fd){
 	sm.checkWrite(fd);
 }
          
 public void checkWrite(String file){
 	sm.checkWrite(file);
 }
   
 public Object getSecurityContext(){
 	return sm.getSecurityContext();
 }
          
 public ThreadGroup getThreadGroup(){
 	return sm.getThreadGroup();
 }
 private final SecurityManager sm;
 
    /**
     * Creates a new DelegateSecurityManager object with the specified SecurityManager object aggregated.
     * @param sm the SecurityManager instance to be aggregated. should not be null.     
     */
 protected DelegateSecurityManager(SecurityManager sm){
 	this.sm = sm;
 }
}
package edu.my.util.worker;

final class WeakWorkerHome implements WorkerHome{
	public final void releaseWorker(final WorkerEngine worker){
		final WorkerHome home = (WorkerHome)weakHome.get();
		if(home != null) home.releaseWorker(worker);
		else worker.close();
	}
	public final void forgetWorker(final WorkerEngine worker){
		final WorkerHome home = (WorkerHome)weakHome.get();
		if(home != null) home.forgetWorker(worker);			
	}
	private final java.lang.ref.WeakReference weakHome;
	private WeakWorkerHome(final WorkerHome home){
		this.weakHome = new java.lang.ref.WeakReference(home);
	}
	public static WorkerHome decorate(final WorkerHome home){
		return new WeakWorkerHome(home);
	}
}