			Map subjectFields = fields.getSubjectFields();
				if ( subjectFields != null && subjectFields.size() > 0 ) {
					Element subjectFieldsNode = createChild(fieldsNode,"subject");
					
					for( Iterator it = subjectFields.keySet().iterator(); it.hasNext(); ) {
						String oidName = (String)it.next();
						Object oidValue= (String)subjectFields.get(oidName);
						
						if ( oidValue != null ) {
							Element fieldNode;
							
							fieldNode = createDataChild(subjectFieldsNode, "oid",oidValue);
							fieldNode.setAttribute("name", oidName);
						}
					}
				}				
			}
				

			createTextChild( response , "signature" , sign(serialize(doc).getBytes()) );
			
			return doc;
			
		} catch( InternalValidatorException ive ) {
			throw ive;
		} catch( Exception e ) {
			throw new InternalValidatorException(e);
		}
	}
	
	
	public String toString() {
		StringBuffer sb = new StringBuffer(80);
		
		sb.append( "value = " );
		sb.append( valueToString(value) );
		if ( codeError != null ) {
			sb.append( " codeError = " );
			sb.append( codeError );
		}
		
		sb.append( " status = " );
		sb.append( statusToString(status) );
		if ( statusReason != 0 ) {
			sb.append( " statusReason = " );
			sb.append( statusReason );
		}
		
		return sb.toString();
	}
	
	public String toXMLString() throws InternalValidatorException {
		return serialize( toXML() );
	}
}

			createTextChild(response,"value", valueToString(value));
			if ( codeError != null ) {
				createTextChild(response,"codeError", codeError);
			}
			
			createTextChild(response,"status", statusToString(status));
			if ( statusReason != 0 ) {
				StringBuffer msgStatusReason = new StringBuffer(256);
				
				msgStatusReason.append( statusReason );
				msgStatusReason.append( ':' );
				msgStatusReason.append( PKIVAProperties.getProperty( "error." + statusReason , "Error " + statusReason ) );
				
				createTextChild(response,"statusReason", msgStatusReason.toString());
			}

			if ( fields != null ) {
				Element fieldsNode = createChild( response , "fields" );
				
				createTextChild(fieldsNode, "serialNumber", fields.getSerialNumber() );
				createTextChild(fieldsNode, "keyUsage", fields.getKeyUsageAsString() );
				createTextChild(fieldsNode, "policy", fields.getPolicy() );
				
				Map issuerFields = fields.getIssuerFields();
				if ( issuerFields != null && issuerFields.size() > 0 ) {
					Element issuerFieldsNode = createChild(fieldsNode,"issuer");
					
					for( Iterator it = issuerFields.keySet().iterator(); it.hasNext(); ) {
						String oidName = (String)it.next();
						Object oidValue= (String)issuerFields.get(oidName);
						
						if ( oidValue != null ) {
							Element fieldNode;
							
							fieldNode = createDataChild(issuerFieldsNode, "oid", oidValue);
							fieldNode.setAttribute("name", oidName);
						}
					}
				}
				
	
package pkiva.webservices;


import java.util.Iterator;
import java.util.List;

import java.rmi.RemoteException;

import java.security.Security;
import java.security.cert.X509Certificate;

import pkiva.CertificateFields;
import pkiva.Validator;
import pkiva.utils.Log;
import pkiva.utils.PKIVAProperties;
import pkiva.webservices.Request;
import pkiva.webservices.Response;
import pkiva.webservices.exception.InternalValidatorException;
import pkiva.webservices.exception.ValidatorException;


/**
 * @author rnavalon
 */
public class ValidateWSImpl implements ValidateWS {

	static {
        int idx;
        
        idx = Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
        if ( idx != -1 ) {
            Log.info("Added BouncyCastle security provider (" + idx + ")");
        }
	}
	
	private void doValidate( Request request ) throws ValidatorException {
		Validator validator;
		
		validator = new Validator();
		
		switch( request.getOption() ) {
		case Request.RAWX509CERTIFICATE:
			Log.info("Validate RAWX509CERTIFICATE");
			validator.checkValidCertificate( request.getCertificate() );
			break;
			
		case Request.PKCS7SIGNATURE:
			Log.info("Validate PKCS7SIGNATURE");
			validator.checkValidSignature( request.getRawSignedDocument() );
			break;
			
		case Request.SIGNEDDETACHEDDOC:
			Log.info("Validate SIGNEDDETACHEDDOC");
			validator.checkValidSignature( request.getRawSignature() , request.getRawDocument());
			break;
			
			default:
				throw new InternalValidatorException("Unknonw option type");
		}
	}
	
	private void doFields( Request request , Response response , CertificateFields fields ) throws ValidatorException {
		
		if ( request.isFields() ) {
			response.setFields( fields );
		}
	}
	
	/*
	 * @see pkiva.ValidateWS#validate(java.lang.String)
	 */
	public String validate(String xmlIn ) throws RemoteException {
        long start , end;
		Response response;
		Request request;
		
        
        start = System.currentTimeMillis();
        try {
            
            Log.info("Received request: " + xmlIn );
            response = new Response();
            
            try {
                
                request = new Request(xmlIn.trim());
                
                try {
                    if ( request.getOption() == Request.UNDEFINED ) {
                        
                        throw new InternalValidatorException("Unrecognized token");
                        
                    } else {
                        
                        Log.info( "Executing request (Type = " + request.getOption() + ")" );

                        response.setValue( Response.SUCCESS );
                        
                        try {
                            CertificateFields fields;
                            X509Certificate cert;
                            
                            cert = request.getCertificate();
                            Log.debug("Certificate in request:\r\n" + cert );
                            
                            fields = new CertificateFields( request.getCertificate() );
                            Log.debug("Certificate fields:\r\n" + fields );
                            
                            Log.info("Executing validate action");
                            doValidate(request);
                            
                            Log.info("Setting response fields");
                            doFields(request,response, fields);
                            
                            Log.info("Certificate is valid");
                            response.setStatus( Response.VALID );
                            
                        } catch( ValidatorException ve ) {
                            response.setStatus( Response.INVALID );
                            response.setStatusReason( ve.getErrCode() );
                            response.setStatusReasonDescription( ve.getMessage() );
                            Log.warning( "Error validating certificate" , ve );
                            
                        } catch( Exception e ) {
                            response.setStatusReason( ValidatorException.INTERNAL_ERROR );
                            response.setStatusReasonDescription( e.getMessage() );
                            Log.critical( "Unknown error validating certificate" , e );
                        }
                    }
                    
                } catch( InternalValidatorException ive ) {
                    response.setValue( Response.FAILURE );
                    response.setCodeError( ive.getErrDescription() );
                    Log.warning( "Error parsing request" , ive );
                }
                
            } catch( InternalValidatorException ive ) {
                response.setValue( Response.REFUSED );
                response.setCodeError( ive.getErrDescription() );
                Log.warning( "Error reading input parameters" , ive );
            }
            
            try {
                String xmlOut = response.toXMLString();
                
                Log.info("Sending response: " + xmlOut );
                return xmlOut;
                
            } catch( Exception e ) {
                Log.error( "Error sending response" , e );
                throw new RemoteException( "Unable to send response" , e );   
            }
            
        } finally {
            end = System.currentTimeMillis();
            Log.info( "Elapsed time: " + (end - start) + " ms." );
        }
	}
}
package pkiva.webservices;

import org.w3c.dom.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import java.io.ByteArrayInputStream;

import java.security.cert.CertStore;
import java.security.cert.CertificateFactory;
import java.security.cert.CertSelector;
import java.security.cert.X509Certificate;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.SignerInformationStore;
import org.bouncycastle.cms.SignerInformation;

import pkiva.webservices.exception.InternalValidatorException;




/**
 * @author rnavalon
 */
public class Request {

	public static final int UNDEFINED			= -1;
	public static final int RAWX509CERTIFICATE	= 1;
	public static final int PKCS7SIGNATURE		= 2;
	public static final int SIGNEDDETACHEDDOC	= 3;
	
	
	private Element request;
	
	
	
	private Element child( Element parent , String childName ) throws InternalValidatorException {
		NodeList children;
		
		children = parent.getElementsByTagName(childName);
		
		if ( children == null || children.getLength() == 0 ) {
			return null;
		}
		
		if ( children.getLength() != 1 ) {
			throw new InternalValidatorException( "Only one " + childName + " node is allowed" );
		}
		
		return (Element)children.item(0);
	}
	
	private Element[] children( Element parent ) throws InternalValidatorException {
		Element[] childNodes = null;
		NodeList nodes;
		List alist = new ArrayList();
		
		nodes = parent.getChildNodes();
		
		for( int n = 0; n < nodes.getLength(); n++ ) {
			if ( nodes.item(n).getNodeType() == Node.ELEMENT_NODE ) {
				alist.add( nodes.item(n) );
			}
		}
		
		if ( alist.size() != 0 ) {
			childNodes = new Element[alist.size()];
			
			int n;
			Iterator it;
			for( it = alist.iterator() , n = 0; it.hasNext(); n++ ) {
				childNodes[n] = (Element)it.next();
			}
		}
		
		return childNodes;
	}
	
	private String textValue( Element element ) {
		String value = null;
		Node childNode;
		
		childNode = element.getFirstChild();
		if ( childNode.getNodeType() == Node.TEXT_NODE || childNode.getNodeType() == Node.CDATA_SECTION_NODE ) {
			value = childNode.getNodeValue();
		}
		
		return value;
	}
	
	private byte[] rawValue( Element element ) {
		byte[] raw = null;
		String text;
		
		if ( (text = textValue(element)) != null ) {
			raw = Base64.decode( text.trim().getBytes() );
		}
		
		return raw;
	}
	
	private X509Certificate certificateFromRaw( byte[] raw ) throws InternalValidatorException {
		X509Certificate cert = null;
		
		try {
			CertificateFactory cf;
			ByteArrayInputStream bais;
					
			cf = CertificateFactory.getInstance("X.509");
					
			bais = new ByteArrayInputStream( raw );
			cert = (X509Certificate)cf.generateCertificate( bais );
			bais.close();
			
		} catch( Exception e ) {
			throw new InternalValidatorException( e );
		}
		
		return cert;
	}
	
	private X509Certificate certificateFromPKCS7( byte[] pkcs7 ) throws InternalValidatorException {
		X509Certificate cert = null;
		
		try {
			CMSSignedData signedData = new CMSSignedData (pkcs7);
			CertStore     certs      = signedData.getCertificatesAndCRLs("Collection", "BC");
			CertSelector  certSelector = null;
        
			SignerInformationStore  signers = signedData.getSignerInfos();
			Collection              c       = signers.getSigners();
			Iterator                it      = c.iterator();

			SignerInformation signer = (SignerInformation)it.next();
			certSelector = signer.getSID();
			Collection certCollection = certs.getCertificates(certSelector);
			
			if ( ( certCollection != null ) && ( !certCollection.isEmpty()) )
				cert = (X509Certificate)certCollection.toArray(new X509Certificate[0])[0];

		} catch( Exception e ) {
			throw new InternalValidatorException( e );
		}
		
		return cert;
	}
	
	
	
	
	public Request( String xmlIn ) throws InternalValidatorException {
		try {
			DocumentBuilderFactory dbf;
			DocumentBuilder db;
			Document doc;
		
			dbf = DocumentBuilderFactory.newInstance();
			db  = dbf.newDocumentBuilder();
		
			ByteArrayInputStream bais = new ByteArrayInputStream( xmlIn.getBytes() );
			doc = db.parse( bais );
			bais.close();
			
			this.request = doc.getDocumentElement();
			
		} catch( Exception e ) {
			throw new InternalValidatorException( e );
		}
	}
	
	
	public int getOption() throws InternalValidatorException {
		Element elementId;
		String elementIdValue;
		
		elementId = child(request, "elementId");
		elementIdValue = textValue( elementId );
		
		if ( elementIdValue.equals("RawX509Certificate") ) {
			return RAWX509CERTIFICATE;
		} else if ( elementIdValue.equals("PKCS7Signature") ) {
			return PKCS7SIGNATURE;
		} else if ( elementIdValue.equals("SignedDetDoc") ) {
			return SIGNEDDETACHEDDOC;
		} else if ( elementIdValue == null ) {
			throw new InternalValidatorException( "Expected elementId node" );
		} else {
			return UNDEFINED;
		}
	}
	
	public byte[] getRawCertificate() throws InternalValidatorException {
		byte[] raw = null;
		Element elementContent;
		Element certificate;
		
		elementContent = child(request, "elementContent");
		certificate = child(elementContent, "certificate");
		
		if ( certificate != null ) {
			raw = rawValue(certificate);
		}
		
		return raw;
	}
	
	public byte[] getRawSignedDocument() throws InternalValidatorException {
		byte[] raw = null;
		Element elementContent;
		Element signedDoc;
		
		elementContent = child(request, "elementContent");
		signedDoc = child(elementContent, "signedDoc");
		if ( signedDoc != null ) {
			raw = rawValue( signedDoc );
		}
		
		return raw;
	}
	
	public byte[] getRawSignature() throws InternalValidatorException {
		byte[] raw = null;
		Element elementContent;
		Element signature;
		
		elementContent = child(request, "elementContent");
		signature = child(elementContent, "signature");
		
		if ( signature != null ) {
			raw = rawValue( signature );
		}
		
		return raw;
	}

	public byte[] getRawDocument() throws InternalValidatorException {
		byte[] raw = null;
		Element elementContent;
		Element doc;
		
		elementContent = child(request, "elementContent");
		doc = child(elementContent, "doc");
		
		if ( doc != null ) {
			raw = rawValue( doc );
		}
		
		return raw;
	}
	
	public boolean isFields() throws InternalValidatorException {
		Element fields;
		
		fields = child(request, "fields");
		
		return fields != null;
	}
	
	
	public X509Certificate getCertificate() throws InternalValidatorException {
		switch( getOption() ) {
		case RAWX509CERTIFICATE:
			return certificateFromRaw( getRawCertificate() );
			
		case PKCS7SIGNATURE:
			return certificateFromPKCS7( getRawSignedDocument() );
			
		case SIGNEDDETACHEDDOC:
			return certificateFromPKCS7( getRawSignature() );
			
			default:
				throw new InternalValidatorException("Option not supported");
		}
	}
}
package pkiva.validation.crl;

import java.util.*;
import java.security.cert.*;
import pkiva.validation.io.*;
import pkiva.exceptions.*;
import pkiva.providers.TimeProvider;
import pkiva.services.ServiceLocator;

/**
 * Class: CRLWrapper
 *
 */
/* diriarte 20040311 - Eliminada la optimizacion de trabajar offline. */

public class CRLWrapper
{
  
  private IssuingDistributionPoint idp;
  private X509CRL crl;
    private Date fetchDate;

    // diriarte 20050421, posibility not to use Threshold
    //private static final int THRESHOLD = 15 * 24 * 60; // days -> minutes
    private static final int THRESHOLD = -1; // days -> minutes

  /**
   * CRLWrapper class constructor
   * @param
   */
  public CRLWrapper( IssuingDistributionPoint dp) throws CRLFetchingException
  {
      this.idp = dp;
      this.crl = null;
      this.fetchDate = null;

    // once we have dp, let's fetch crl
    update();
  }
  
  public X509CRL getCRL( ) throws CRLFetchingException
  {
    // if we are requested for a CRL, we'd better provide it up-to-date
    checkUpdate( );
    
    return this.crl;
  }
  
  /*public X509CRL getCRL( boolean checkUpdate )
  {
    if ( checkUpdate )
      checkUpdate( );
   
    // even if checkUpdate is false we shouldn't return a null crl
    else if ( this.crl == null )
      update();
   
    return this.crl;
  }*/
  
  public boolean match( IssuingDistributionPoint dp )
  {
    return this.idp.equals( dp );
  }
  
  public boolean match( CRLSelector sel ) throws CRLFetchingException
  {
	  // diriarte: 20051114, we are not working up-to-date here
    //checkUpdate();
    
    // if crl is null, we've got a problem
    if ( crl == null )
    {
      if (pkiva.log.LogManager.isWarnEnabled(this.getClass()))
          pkiva.log.LogManager.getLogger(this.getClass()).warn("Can't match after update.CRL is NULL");
      return false;
    }
    
    if ( sel == null )
    {
      if (pkiva.log.LogManager.isWarnEnabled(this.getClass()))
          pkiva.log.LogManager.getLogger(this.getClass()).warn("Can't match after update.Selector is NULL");
      return false;
    }
    
    return sel.match( this.crl );
  }
  
  public String toString()
  {
    StringBuffer out = new StringBuffer( this.getClass().getName() );
    out.append( " [" ).append( this.idp.toString() ).append( "]" );
    
    return out.toString();
  }

  /** Getter for property idp.
   * @return Value of property idp.
   *
   */
  public pkiva.validation.crl.IssuingDistributionPoint getIdp()
  {
    return idp;
  }
  
  /*public boolean match( CRLSelector sel, boolean workOffline )
  {
   
    // checkear si viene date en el sel, en ese caso hay que actualizar siempre
   
    // check if we are requested not to update crl
    // we must update if crl is null
    if ( ( !workOffline ) || ( crl == null ) )
      checkUpdate();
   
    // if crl is null, we've got a problem
    if ( ( crl == null ) || ( sel == null ) )
      return false;
   
    return sel.match( this.crl );
  }*/
  
  private void checkUpdate() throws CRLFetchingException
  {
    if ( needsUpdate() )
    {
      if (pkiva.log.LogManager.isDebugEnabled(this.getClass()))
          pkiva.log.LogManager.getLogger(this.getClass()).debug("I Need Update::" + this);
      update();
    }
    else if (pkiva.log.LogManager.isDebugEnabled(this.getClass()))
      pkiva.log.LogManager.getLogger(this.getClass()).debug("I'm up-to-date::" + this);

  }
  
  private void update( ) throws CRLFetchingException
  {
    try
    {
      if (pkiva.log.LogManager.isDebugEnabled(this.getClass()))
          pkiva.log.LogManager.getLogger(this.getClass()).debug("Updating::" + this);
      
      synchronized ( this )
      {
        // si es de tipo URI vamos a buscar el CRL
        // *** We'll asume IDPs from certificate will be URIs ***
        if ( ( IssuingDistributionPoint.URI_DPTYPE.equals ( this.idp.getDPType () ) )
              || ( IssuingDistributionPoint.UNKNOWN_DPTYPE.equals ( this.idp.getDPType () ) ) )
        {
          this.crl = FetcherManager.instance().getCRL( this.idp.getLocation(), this.idp.getAttributes() );
          if (pkiva.log.LogManager.isDebugEnabled(this.getClass()))
              pkiva.log.LogManager.getLogger(this.getClass()).debug("CRL:" + this.crl);
          if ( needsUpdate(false) )
          {
            if (pkiva.log.LogManager.isWarnEnabled(this.getClass()))
                pkiva.log.LogManager.getLogger(this.getClass()).warn("We've got a expired CRL after fetching. Must discard");
            this.crl = null;
          } // end if ( needsUpdate() )
        } // end if ( IssuingDistributionPoint.URI_DPTYPE ...
        else if ( IssuingDistributionPoint.INCOMPLETE_DPTYPE.equals ( this.idp.getDPType () ) )
        {
          if (pkiva.log.LogManager.isWarnEnabled(this.getClass()))
              pkiva.log.LogManager.getLogger(this.getClass()).warn("Found INCOMPLETE IssuingDistributionPoint. Should not fetch: " + this.idp.getLocation());
        }
        else
        {
          if (pkiva.log.LogManager.isWarnEnabled(this.getClass()))
              pkiva.log.LogManager.getLogger(this.getClass()).warn("Can't Fetch IssuingDistributionPoint with type:" + this.idp.getDPType ());
        }
      } // end synchronized

        if (this.crl != null) {
            this.fetchDate = TimeProvider.getCurrentTime().getTime();
            if (pkiva.log.LogManager.isDebugEnabled(this.getClass()))
                pkiva.log.LogManager.getLogger(this.getClass()).debug("Updating fetchDate for CRL: " + this.idp.getLocation());
        }
    }
    catch ( FetchingException fe )
    {
      throw new CRLFetchingException("Couldn't fetch::" + this, fe );
    }
  }
  
  private boolean needsUpdate( )
  {
    return needsUpdate ( true );
  }
  
 
