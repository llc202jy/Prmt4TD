* 
 */
public class InitialEventSelectorImpl implements javax.slee.InitialEventSelector{
    private EventTypeID eventTypeID;
    private String eventName;
    private Object event;
    private Object activity;
    private Address address;
    private String customName;

    int[] select;
    private boolean isSelectMethod = false;
    private boolean isActivityContextSelected= false;
    private boolean isAddressProfileSelected= false;
    private boolean isAddressSelected= false;
    private boolean isEventSelected= false;
    private boolean isEventTypeSelected= false;
    
    
    private boolean isInitialEvent= false;
    
    
    private String selectMethodName;
    

    
    
    
    public InitialEventSelectorImpl(EventTypeID type, Object event, Object activity,  int[] select, String methodName, Address address) {
        eventTypeID = type;
        this.event = event;
        this.address = address;
        if ( activity instanceof SleeActivityHandle ) {
            SleeActivityHandle sah = (SleeActivityHandle) activity;
            this.activity = sah.getActivity();
        } else this.activity = activity;
        
        for(int i=0; i<select.length;i++){
            switch(select[i]){ 
            	case SbbEventEntry.ACTIVITY_CONTEXT_INITIAL_EVENT_SELECT: this.isActivityContextSelected = true;break;
            	case SbbEventEntry.ADDRESS_INITIAL_EVENT_SELECT:this.isAddressSelected=true;break;
            	case SbbEventEntry.ADDRESS_PROFILE_INITIAL_EVENT_SELECT:this.isAddressProfileSelected=true;break;
            	case SbbEventEntry.EVENT_INITIAL_EVENT_SELECT:this.isEventSelected=true;break;
            	case SbbEventEntry.EVENT_TYPE_INITIAL_EVENT_SELECT:this.isEventTypeSelected=true;break;
           
         
            
            }
    /**
     * @param isAddressProfileSelected The isAddressProfileSelected to set.
     */
    public void setAddressProfileSelected(boolean isAddressProfileSelected) {
        this.isAddressProfileSelected = isAddressProfileSelected;
    }
    /**
     * @param isAddressSelected The isAddressSelected to set.
     */
    public void setAddressSelected(boolean isAddressSelected) {
        this.isAddressSelected = isAddressSelected;
    }
    /**
     * @param isEventTypeSelected The isEventTypeSelected to set.
     */
    public void setEventTypeSelected(boolean isEventTypeSelected) {
        this.isEventTypeSelected = isEventTypeSelected;
    }
    /**
     * @return Returns the isSelectMethod.
     */
    public boolean isSelectMethod() {
        return isSelectMethod;
    }
    /**
     * @param isSelectMethod The isSelectMethod to set.
     */
    public void setSelectMethod(boolean isSelectMethod) {
        this.isSelectMethod = isSelectMethod;
    }
    /**
     * @return Returns the selectMethodName.
     */
    public String getSelectMethodName() {
        return selectMethodName;
    }
    /**
     * @param selectMethodName The selectMethodName to set.
     */
    public void setSelectMethodName(String selectMethodName) {
        this.selectMethodName = selectMethodName;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#getEventName()
     */
    public String getEventName() {
        return eventName;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#getEvent()
     */
    public Object getEvent() {
        return event;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#getActivity()
     */
    public Object getActivity() {
        return activity;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#getAddress()
     */
    public Address getAddress() {
        
        return address;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#setAddress(javax.slee.Address)
     */
    public void setAddress(Address address) {
        
        this.address = address;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#getCustomName()
     */
    public String getCustomName() {
        
        return customName;
    }

    public void setCustomName(String customName) {
        this.customName = customName;
    }
    
    public void setActivityContextSelected(boolean isActivityContextSelected) {
        this.isActivityContextSelected = isActivityContextSelected;
    }
    
    public void setEventSelected(boolean isEventSelected) {
        this.isEventSelected = isEventSelected;
    }
    
    public boolean isInitialEvent() {
        return isInitialEvent;
    }
    
    public void setInitialEvent(boolean isInitialEvent) {
        this.isInitialEvent = isInitialEvent;
    }
}
*
 * Created on Jul 14, 2004
 *
 * The source code contained in this file is in in the public domain.          
 * It can be used in any project, or product without prior permission, 	      
 * license or royalty payments. There is no claim of correctness and
 * NO WARRANTY OF ANY KIND provided with this code.
 */
package org.mobicents.slee.container;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import javax.slee.ChildRelation;
import javax.slee.CreateException;
import javax.slee.SLEEException;
import javax.slee.SbbID;
import javax.slee.SbbLocalObject;
import javax.slee.TransactionRequiredLocalException;
import javax.transaction.SystemException;

import org.jboss.logging.Logger;
import org.mobicents.slee.runtime.SbbEntity;
import org.mobicents.slee.runtime.SbbLocalObjectConcrete;
import org.mobicents.slee.runtime.SbbLocalObjectImpl;

/**
 * 
 * Implements the ChildRelation interface
 * 
 * @author F.Moggia
 * @author M. Ranganathan
 * @author Ralf Siedow
 * 
 *  
 */
public class ChildRelationImpl implements ChildRelation {

    volatile private static Logger logger;

    private HashSet children;

    private SbbEntity parentEntity;

    volatile private SleeContainer container;

    private SbbID sbbid;

    private byte defaultPriority;

    static {
        logger = Logger.getLogger(ChildRelationImpl.class);
    }


         
    private void checkTransaction() throws TransactionRequiredLocalException {
        SleeContainer.getTransactionManager().mandateTransaction();
    }

    private HashSet getLocalObjects() {
        HashSet localObjects = new HashSet();
        for (Iterator it = this.children.iterator(); it.hasNext();) {
            String sbbEntityId = (String) it.next();
            localObjects.add( this.createSbbLocalObject(sbbEntityId));
            //.add(new SbbLocalObjectImpl(this.container, sbbEntityId));
        }
        return localObjects;
    }

    /*
     * JAIN SLEE 1.0 Specification, Final Release Page 62 The iterator method
     * and the Iterator objects returned by this method. Chapter 6 The SBB
     * Abstract Class
     * 
     * The SLEE must implement the methods of the Iterator objects returned by
     * the iterator method by following the contract defined by the
     * java.util.Iterator interface. o The next method of the Iterator object
     * returns an object that implements the SBB local interface of the child
     * SBB of the child relation. Java typecast can be used to narrow the
     * returned object reference to the SBB local interface of the child SBB. o
     * The remove method of the Iterator object removes the SBB entity that is
     * represented by the last SBB local object returned by the next method of
     * the Iterator object from the child relation. Removing an SBB entity from
     * a child relation by invoking this remove method initiates a cascading
     * removal of the SBB entity tree rooted by the SBB entity, similar to
     * invoking the remove method on an SBB local object that represents the SBB
     * entity. The behavior of the Iterator object is unspecified if the
     * underlying child relation is modified while the iteration is in progress
     * in any way other than by calling this remove method.
     */
    class ChildRelationIterator implements Iterator {
        private HashSet sbbEntities;

        private Iterator myIterator;

        private String nextEntity;

        private SbbLocalObject nextSbbLocalObject;

        public ChildRelationIterator(SleeContainer container, HashSet entities) {
            this.sbbEntities = entities;
            this.myIterator = this.sbbEntities.iterator();

        }
      
        /*
         * public ChildRelationIterator(HashSet entities) { this.sbbEntities =
         * new HashSet(); for (Iterator it = entities.iterator(); it.hasNext(); ) {
         * SbbEntity sbbe = (SbbEntity) it.next(); SbbLocalObjectImpl
         * sbbLocalObject = (SbbLocalObjectImpl) sbbe.getSbbLocalObject(); if (!
         * sbbLocalObject.isRemoved()) this.sbbEntities.add(sbbe); }
         * 
         * this.myIterator = this.sbbEntities.iterator(); }
         */
        
        public void remove() {
            myIterator.remove();
            nextSbbLocalObject.remove();
            //TODO -- add an action here to actually remove the entity from the
            // child relation.
            
            // container.removeSbbEntityTree(nextEntity);
        }

        /*
         * (non-Javadoc)
         * 
         * @see java.util.Iterator#hasNext()
         */
        public boolean hasNext() {
            return myIterator.hasNext();
        }

        /*
         * (non-Javadoc)
         * 
         * @see java.util.Iterator#next()
         */
        public Object next() {
            nextEntity = (String) myIterator.next();
            this.nextSbbLocalObject = createSbbLocalObject(nextEntity);
            return nextSbbLocalObject;
        }

    }

    public ChildRelationImpl(SbbID sbbid, byte defaultPriority,
             SbbEntity sbbe, HashSet children) {
    	if ( logger.isDebugEnabled()) {
    	    logger.debug("Creating child relation. children = " + children);
    	}

        if (sbbid == null)
            throw new NullPointerException(" null sbb id");
        if ( children == null )
            throw new NullPointerException ("Internal Error! null children passed in");
        this.parentEntity = sbbe;
        this.container = SleeContainer.lookupFromJndi();
        this.sbbid = sbbid;
        this.defaultPriority = defaultPriority;
        this.children = children;
    }

    public Iterator iterator() {
        return new ChildRelationIterator(this.container,children);
    }

    /**
     * The contains method. This method returns true if the SBB entity
     * represented by the SBB local object specified by the input argument is a
     * member of this child relation. If the method argument is not an SBB local
     * object, is an invalid SBB local object, or is an SBB local object whose
     * underlying SBB entity is not a member of this child relation, then this
     * method returns false.
     *  
     */
    public boolean contains(Object object) {
        if (!(object instanceof SbbLocalObject))
            return false;
        SbbLocalObjectImpl sbblocal = (SbbLocalObjectImpl) object;
        String sbbEntityId = sbblocal.getSbbEntityId();
        return this.children.contains(sbbEntityId);
    }

    /*
     * (non-Javadoc)
     * 
     * @see javax.slee.ChildRelation#create()
     */
    public SbbLocalObject create() throws CreateException,
            TransactionRequiredLocalException, SLEEException {
        SleeContainer.getTransactionManager().mandateTransaction();

        if (logger.isDebugEnabled())
            logger.debug("ChildRelation.create() : Creating Sbb Entity: " + sbbid);

        SbbEntity sbbEntity = this.container.getSbbEntityFactory().createSbbEntity(this.sbbid, 
                this.parentEntity.getService().getServiceID(), this.parentEntity.getSbbEntityId(),
                this.parentEntity.getServiceConvergenceName());
      
       
		//TODO: shuold be remove
        sbbEntity.setPriority(this.defaultPriority);
        //sbbEntity.setRootSbbId(this.parentEntity.getRootSbbId());
        //sbbEntity.setParentSbbEntity(this.parentEntity.getSbbEntityId());

        
        
        /*
         * Exception handling here must follow Sec. 9.12.1 of spec
         * This is a non-slee originated method invocation
         * 
         * If a non-SLEE originated method invocation returns by throwing a checked exception, then the following
		 *	occurs:
		 *	 The state of the transaction is unaffected
		 *	 The checked exception is propagated to the caller.
		 *	It is expected that the caller will have the appropriate logic to handle the exception.
		 *	If a non-SLEE originated method invocation returns by throwing a RuntimeException, then:
		 *	 The transaction is marked for rollback.
		 *	 The SBB object that was invoked is discarded, i.e. is moved to the Does Not Exist state.
		 *	 A javax.slee.TransactionRolledBackLocalException is propagated to the caller.
		 *	The transaction will eventually be rolled back when the highest level SLEE originated invocation re-turns
		 *	as described in Section 9.12.2.
		 *	The sbbRolledBack method is not invoked for an SBB originated method transaction because the
		 *	transa ction is only marked for rollback and will only be rolled back when the highest level SLEE
		 *	originated invocation returns. The sbbRolledBack method is only invoked on the SBB entity in-voked
		 *	by the highest level SLEE originated invocation.
		 *	If the RuntimeException propagates to the highest level (i.e. the SLEE originated method invocation
		 *	returns by throwing a RuntimeException) the SLEE originated method invocation exception handling
		 *	mechanism is init iated.		
		*/
        
        try {            
        	//All checked exceptions (i.e. CreateException) are propagated to the caller
            if(sbbEntity.getSbbObject() == null){
                sbbEntity.assignSbbObject(true);
            }
        	        	        	
        	
            //sbbEntity.getSbbObject().sbbCreate();
            //sbbEntity.getSbbObject().setState(SbbObjectState.READY);
            //sbbEntity.getSbbObject().sbbPostCreate();
        } catch ( CreateException e) {
            //          All RuntimeExceptions are dealt with here
            if ( logger.isDebugEnabled())
                logger.error("Caught CreateException in creating child entity", e);
            /*try {
                SleeContainer.getTransactionManager().setRollbackOnly();
            } catch (SystemException e1) {
            	logger.error("Failed to set rollbackonly", e);
            }*/
            sbbEntity.trashObject();
            // Propagate exception to caller.
            throw e;
        } catch ( Exception e) {
        	//All RuntimeExceptions are dealt with here
            logger.error("Caught RuntimeException in creating child entity", e);
            try {
                SleeContainer.getTransactionManager().setRollbackOnly();
            } catch (SystemException e1) {
            	logger.error("Failed to set rollbackonly", e);
            }
            sbbEntity.trashObject();
        } 
        
        children.add(sbbEntity.getSbbEntityId()); // Ralf Siedow: added this
        logger.debug("Children is: " + children);
        logger.debug("sbbEntity is: " + sbbEntity);
        return sbbEntity.createSbbLocalObject();
    }

   
    
    private SbbLocalObject createSbbLocalObject(String sbbeId) {
        SbbEntity sbbEntity = container.getSbbEntityFactory().getSbbEntity(sbbeId);
        return sbbEntity.createSbbLocalObject();
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.util.Collection#size()
     */
    public int size() {

        return this.children.size();
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.util.Collection#clear()
     */
    public void clear() {
        checkTransaction();
        for ( Iterator it = this.iterator(); it.hasNext() ; ) {
            it.next();
            it.remove();
        }
        

    }

    /*
     * (non-Javadoc)
     * 
     * @see java.util.Collection#isEmpty()
     */
    public boolean isEmpty() {
        checkTransaction();
        return this.children.isEmpty();
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.util.Collection#toArray()
     */
    public Object[] toArray() {

        checkTransaction();

        return this.getLocalObjects().toArray();
    }

    /**
     * This operation is not supported ( see page 62 ) of the spec. The add
     * methods add and addAll. Any attempts to add to the child relation using
     * these methods result in a java.lang. UnsupportedOperationException. For
     * example, the SLEE must throw the UnsupportedOperationException when these
     * methods are invoked with arguments that add to the collection. o An
     * invocation of an add method that has no effect on the collection, such as
     * invoking the addAll method with an empty collection may or may not throw
     * an UnsupportedOperationException . The create method of the ChildRelation
     * interface should be used to create a child SBB entity. This causes the
     * SLEE to automatically add an SBB local object that represents the newly
     * created SBB entity to the collection.
     */
    public boolean add(Object object) {
        if (object == null)
            throw new NullPointerException("null arg! ");
        else
            throw new UnsupportedOperationException("Operation not supported !");
    }

    /**
     * Spec page 62 The remove methods: clear, remove, removeAll, and retainAll.
     * o These methods may remove SBB entities from the child relation. The
     * input argument specifies which SBB entities will be removed from the
     * child relation or retained in the child relation by specifying the SBB
     * local object or collection of SBB local objects that represent the SBB
     * entities to be removed or retained. o Removing an SBB entity from a child
     * relation initiates a cascading removal of the SBB entity tree rooted by
     * the SBB entity, similar to invoking the remove method on an SBB local
     * object that represents the SBB entity.
     *  
     */
    public boolean remove(Object object) {
        checkTransaction();
        logger.debug("removing " + object);
        if (object == null)
            throw new NullPointerException("Null arg for remove ");
        if (!(object instanceof SbbLocalObject))
            return false;
        String target = ((SbbLocalObjectImpl)object).getSbbEntityId();
        boolean retval = this.children.remove(target);
        if (retval) {
            logger.debug("removing entity tree !");
            ((SbbLocalObjectImpl) object).remove();
            retval = false;
        }
        return retval;
    }

    /**
     * This operation is not supported ( see page 62 ) of the spec. The add
     * methods add and addAll. Any attempts to add to the child relation using
     * these methods result in a java.lang. UnsupportedOperationException. For
     * example, the SLEE must throw the UnsupportedOperationException when these
     * methods are invoked with arguments that add to the collection. o An
     * invocation of an add method that has no effect on the collection, such as
     * invoking the addAll method with an empty collection may or may not throw
     * an UnsupportedOperationException . The create method of the ChildRelation
     * interface should be used to create a child SBB entity. This causes the
     * SLEE to automatically add an SBB local object that represents the newly
     * created SBB entity to the collection.
     */
    public boolean addAll(Collection c) {
        if (c == null)
            throw new NullPointerException("Null arg!");
        else
            throw new UnsupportedOperationException("Operation not supported !");
    }

    /**
     * This method returns true if all SBB entities represented by the SBB local
     * objects in the collection specified by the input argument are members of
     * this child relation. If the collection contains an object that is not an
     * SBB local object, an SBB local object that is invalid, or an SBB local
     * object whose underlying SBB entity is not a member of this child
     * relation, then this method returns false.
     */
    public boolean containsAll(Collection c) {
        if (c == null)
            throw new NullPointerException("null collection!");
        HashSet localInterfaces = getLocalObjects();
        logger.debug("containsAll : collection = " + c + " sbbLocalObject = " + localInterfaces);
        boolean retval  = true;
        for ( Iterator it = c.iterator(); it.hasNext(); ) {
            SbbLocalObjectConcrete sbbLocalInterface = ( SbbLocalObjectConcrete) it.next();
            logger.debug("Checking membership for : "  + sbbLocalInterface.getSbbEntityId());
            if ( ! children.contains(sbbLocalInterface.getSbbEntityId())) {
                retval = false;
                break;
            }
        }
        
        return retval;
    }

    /**
     * Removing an SBB entity from a child relation initiates a cascading
     * removal of the SBB entity tree rooted by the SBB entity, similar to
     * invoking the remove method on an SBB local object that represents the SBB
     * entity.
     *  
     */
    public boolean removeAll(Collection c) {
        boolean flag = true;
        if (c == null)
            throw new NullPointerException(" null collection ! ");
        for ( Iterator it = c.iterator(); it.hasNext();	) {
           flag &= this.remove( it.next());
            
        }
        return flag;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.util.Collection#retainAll(java.util.Collection)
     */
    public boolean retainAll(Collection c) {
        boolean flag = false;
        if (c == null)
            throw new NullPointerException(" null arg! ");
        //Iterator it = this.iterator();
        for ( Iterator it = this.iterator(); it.hasNext();) {
            if ( ! c.contains(it.next())) {
                flag = true;
                it.remove();
            }
            
        }
        return flag;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.util.Collection#toArray(java.lang.Object[])
     */
    public Object[] toArray(Object[] a) {
        if (a == null)
            throw new NullPointerException("null arg!");
        HashSet localObjects = this.getLocalObjects();
        return localObjects.toArray(a);
    }

    /**
     * Mark all the entities that are part of this child relation as being in a
     * rolledback state so that if any transactional method is invoked on the
     * associated entity, you will get an exception
     */
    /*
     * public void markRolledBack() { for ( Iterator it =
     * this.children.iterator(); it.hasNext();) { SbbEntity sbbEntity =
     * (SbbEntity) it.next(); sbbEntity.markRolledBack(); }
     *  }
     */
          
    /**
     * return an iterator containing the child entities.
     * 
     * @return
     */
    public Iterator getChildEntities() {
        return this.children.iterator();
    }
    
    /**
     * Remove an entity ( this is for cascading removal only )
     *
     */
     public void removeSbbEntity(String sbbeId) {
         this.children.remove(sbbeId);
     }
     
     public HashSet getSbbEntitySet(){
         return this.children;
     }
     
//     public void setSbbEntitySet(HashSet set){ // Ralf Siedow: removed and forced setting of children in constructor
//         this.children = set;
//     }

}/*
 * ***************************************************
 *                                                 *
 *  Mobicents: The Open Source JSLEE Platform      *
 *                                                 *
 *  Distributable under LGPL license.              *
 *  See terms of license at gnu.org.               *
 *                                                 *
 ***************************************************
 *
 * Created on Dec 6, 2004 RemoteSleeServiceImpl.java
 */
package org.mobicents.slee.connector.server;

import org.mobicents.slee.container.SleeContainer;
import org.mobicents.slee.resource.EventLookup;
import org.mobicents.slee.runtime.ActivityContext;
import org.mobicents.slee.runtime.ActivityContextFactory;
import org.mobicents.slee.runtime.SleeInternalEndpoint;
import org.mobicents.slee.runtime.facilities.NullActivityFactoryImpl;
import org.mobicents.slee.runtime.facilities.NullActivityImpl;
import org.mobicents.slee.runtime.transaction.SleeTransactionManager;

import java.util.ArrayList;
import java.util.Iterator;
import javax.slee.Address;
import javax.slee.EventTypeID;
import javax.slee.InvalidStateException;
import javax.slee.connection.ExternalActivityHandle;
import javax.slee.nullactivity.NullActivity;
import javax.slee.nullactivity.NullActivityFactory;

import org.jboss.logging.Logger;

import EDU.oswego.cs.dl.util.concurrent.ThreadedExecutor;

/**
 * 
 * Implementation of the RemoteSleeService.
 * 
 * An instance of this class receives invocations via HA-RMI from the outside
 * world.
 * 
 * @author Tim
 */
public class RemoteSleeServiceImpl implements RemoteSleeService {
	private NullActivityFactory naf;

	private ActivityContextFactory acf;

	private SleeInternalEndpoint endpoint;

	private EventLookup eventLookup;

	private static Logger log = Logger.getLogger(RemoteSleeServiceImpl.class);

	class DeferredFireEventAction implements
			Runnable {
		ArrayList eventList;

		public DeferredFireEventAction(ArrayList alist) {
			this.eventList = new ArrayList(alist);
		}




		public void run() {
			log.debug("afterCompletion called -- fireEventQueue Again!");
			Iterator iter = eventList.iterator();
			while (iter.hasNext()) {
				EventInvocation ei = (EventInvocation) iter.next();
				fireEvent(ei.event, ei.eventTypeId, ei.externalActivityHandle,
						ei.address);
			}
		}

	}

	public RemoteSleeServiceImpl(NullActivityFactory naf,
			SleeInternalEndpoint endpoint, EventLookup eventLookup,
			ActivityContextFactory acf) {
		log.debug("Creating RemoteSleeServiceImpl");
		this.naf = naf;
		this.endpoint = endpoint;
		this.eventLookup = eventLookup;
		this.acf = acf;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.mobicents.slee.connector.server.RemoteSleeService#createActivityHandle()
	 */
	public ExternalActivityHandle createActivityHandle() {

		log.debug("createActivityHandle() called current " );
		SleeTransactionManager txmgr = SleeContainer.getTransactionManager();
		boolean b = false;
		try {
			b  = txmgr.requireTransaction();
			NullActivityImpl na = (NullActivityImpl) (((NullActivityFactoryImpl) naf)
					.createNullActivityNoTx());
			ActivityContext ac = acf.getActivityContext(na);

			return new ActivityHandleImpl(ac.getActivityContextId());
		} catch (Exception ex) {
			try {
				if (b)
				txmgr.setRollbackOnly();
			} catch (Exception e) {
				log.error("createActivityHandle(): exception occured", ex);
			}
			return null;
		} finally {
			try {
				if(b)
					txmgr.commit();
			} catch (Exception ex) {
				log.error("createActivityHandle(): exception occured", ex);
			}

		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.mobicents.slee.connector.server.RemoteSleeService#fireEvent(java.lang.Object,
	 *      javax.slee.EventTypeID,
	 *      org.mobicents.slee.connector.server.ActivityHandleImpl,
	 *      javax.slee.Address)
	 */
	public void fireEvent(Object event, EventTypeID eventType,
			ExternalActivityHandle activityHandle, Address address) {
		if (event == null)
			throw new NullPointerException("event is null");
		if (eventType == null)
			throw new NullPointerException("eventType is null");
		SleeTransactionManager txmgr = SleeContainer.getTransactionManager();
		boolean b = false;
		try {
			log.debug("fireEvent() called " + txmgr.isInTx());
			if(!txmgr.isInTx())
				txmgr.begin();

			// fire an event on the slee endpoint using the right null activity
			NullActivityImpl na = null;
			if (activityHandle != null) {

				ActivityHandleImpl handle = (ActivityHandleImpl) activityHandle;
				ActivityContext ac = acf.getActivityContextById(handle
						.getKey());
				if (ac == null) {
					log.error("Invalid activity handle!");
					return;
				}
				na = (NullActivityImpl) ac.getActivity();

	 * @deprecated Use getResourceAdaptorEntities
	 */
	public HashMap getResourceAdaptorEnitities() {
		return resourceAdaptorEntities;
	}

	public ResourceAdaptorID getResourceAdaptorID(String entityName)
			throws java.lang.NullPointerException,
			UnrecognizedResourceAdaptorEntityException, ManagementException {

		if (entityName == null)
			throw new NullPointerException("null entity name");

		ResourceAdaptorEntity resourceAdaptorEntity = (ResourceAdaptorEntity) resourceAdaptorEntities
				.get(entityName);
		if (resourceAdaptorEntity == null)
			throw new UnrecognizedResourceAdaptorEntityException("Entity "
					+ entityName + " not found");

		return resourceAdaptorEntity.getInstalledResourceAdaptor().getKey();
	}

	

	} finally {
			try {
				if (b)
					getTransactionManager().commit();

			} catch (SystemException ex) {
				throw new RuntimeException("tx maanger failed ", ex);
			}

		}
	}

	public static boolean isSecurityEnabled() {

		return isSecurityEnabled;
	}

}

			endpoint.enqueueEvent(eventType, event, na, address);
			log.debug("Queued event");
		} catch (Exception ex) {
			try {
				if ( txmgr.isInTx())
					txmgr.setRollbackOnly();
			} catch (Exception e) {
				log.error("Exception committing tx", e);
			}
			log.error("Exception in fireEvent!", ex);
		} finally {
			try {
				if ( txmgr.isInTx())
					txmgr.commit();
			} catch (Exception e) {
				log.error("Exception committing tx", e);
			}
		}
	}

	public void fireEventQueue(ArrayList queue) {
		if (queue == null)
			throw new NullPointerException("queue is null");
		try {
			log.debug("fireEventQueue() called");
			DeferredFireEventAction daf = new DeferredFireEventAction(queue);
			// The following needs to run in its own tx because 
			// it has to start transactions.
			new ThreadedExecutor().execute(daf);
			
		} catch (Exception ex) {
			throw new RuntimeException("Unexpected error", ex);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.mobicents.slee.connector.server.RemoteSleeService#getEventTypeID(java.lang.String,
	 *      java.lang.String, java.lang.String)
	 */
	public EventTypeID getEventTypeID(String name, String vendor, String version) {
		if (name == null)
			throw new NullPointerException("name is null");
		if (vendor == null)
			throw new NullPointerException("vendor is null");
		if (version == null)
			throw new NullPointerException("version is null");

		log.debug("getEventTypeID() called");
		int eventId = eventLookup.getEventID(name, vendor, version);
		log.debug("eventId is:" + eventId);
		if (eventId == -1) {
			/*
			 * The SLEE spec. does not define what to return if the event type
			 * is not found but we're going to return null
			 */
			return null;
		}
		EventTypeID eventTypeID = eventLookup.getEventTypeID(eventId);
		log.debug("Event type id is:" + eventTypeID);
		return eventTypeID;
	}
}package org.mobicents.util;

import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import java.util.HashMap;
import java.io.InputStream;
import java.net.URL;

// Generic resource-lookup-based DTD resolver
public abstract class DTDResolver implements EntityResolver {
    private final HashMap resources = new HashMap();

    /**
     * Register a local resource as a substitute for an external entity reference..
     * @param publicID the public identitify of the external entity.
     * @param resourceURL the URL of the resource
     */
    protected void registerDTDURL(String publicID, URL resourceURL) {
        resources.put(publicID, resourceURL);
    }

    protected void registerDTDResource(String publicId, String resourcePath) {
        registerDTDURL(publicId, getClass().getClassLoader().getResource(resourcePath));
    }

    /**
     * Attempt to resolve an external identity.
     * @param publicId the public identifier of the external entity being referenced.
     * @param systemId the system identifier of the external entity being referenced.
     * @return an InputSource object describing the new input source, or null to request
     *        that the parser open a regular URI connection to the system identifier.
     */
    public InputSource resolveEntity(String publicId, String systemId) {
        URL resourceURL = (URL)resources.get(publicId);
        if (resourceURL != null) {
            InputStream resourceStream = null;
            try {
                resourceStream = resourceURL.openStream();
                InputSource is = new InputSource(resourceStream);
                is.setPublicId(publicId);
                is.setSystemId(resourceURL.toExternalForm());
                return is;
            }
            catch (Exception e) {
                try { if(resourceStream != null) resourceStream.close(); } catch (Exception e2) {}
            }
        }
        return null;
    }
}package org.mobicents.util;

import java.net.URL;

import java.io.IOException;
import java.io.InputStream;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

import org.w3c.dom.Document;
import org.w3c.dom.Attr;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Element;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.mobicents.util.XMLException;
 
public final class XMLParser {
    /**
     * Parse an XML document.  Equivalent to <tt>getDocument(url, null)</tt>.
     * @param url the url of the document to parse.
     * @return a parsed document tree.
     * @exception IllegalArgumentException if the supplied url is null.
     * @exception IOException if an IO exception or parse error occurs with the URL.
     */
    public static Document getDocument(URL url) throws IllegalArgumentException, IOException {
	return getDocument(url, null);
    }

    /**
     * Parse an XML document using a given resolver for DTDs.
     * @param url the url of the document to parse.
     * @param resolver the entity resolver to use.  If null, no specific resolver
     *        is used.
     * @return a parsed document tree.
     * @exception IllegalArgumentException if the supplied url is null.
     * @exception IOException if an IO exception occurs with the URL.
     */
    public static Document getDocument(URL url, EntityResolver resolver) throws IllegalArgumentException, IOException {
	return getDocument(url, resolver, false);
    }

    private static class ParseErrorHandler implements ErrorHandler {
	public void error(SAXParseException e) throws SAXException {
	    throw e;
	}

	public void fatalError(SAXParseException e) throws SAXException {
	    throw e;
	}

	public void warning(SAXParseException e) throws SAXException {
	    System.err.println("Warning: " + e);
	}
    }
	 * @param componentId
	 * @return
	 */
	public boolean isInstalled(ComponentID componentId) {
		boolean b = getTransactionManager().requireTransaction();

		try {
			if (componentId instanceof SbbID) {
				return this.getDeploymentCacheManager().getSbbComponents()
						.containsKey(componentId);
			} else if (componentId instanceof ServiceID) {
				return this.getDeploymentCacheManager().getServiceComponents()
						.containsKey(componentId);
			} else if (componentId instanceof EventTypeID) {
				return this.eventTypeIDs.containsKey(componentId);			
			} else if (componentId instanceof ProfileSpecificationID) {
				return this.getDeploymentCacheManager().getProfileComponents()
						.containsKey(componentId);
			}
			else
				return false;
		} catch (SystemException ex) {
			throw new RuntimeException("tx manager failed! ", ex);
		} finally {
			try {
				if (b)
					getTransactionManager().commit();
			} catch (SystemException ex) {
				throw new RuntimeException("tx maanger failed ", ex);
			}
		}

	}

	private void removeReferredComponents(DeployableUnitDescriptorImpl dudesc) {

		// We return true if theres a component of the Deployable Unit that is
		// referenced by another component. We do not need to check about
		// service components.

		ComponentID[] cid = dudesc.getComponents();
		for (int i = 0; i < cid.length; i++) {
			this.removeReferredComponent(cid[i]);
		}

	}

	/**
	 * Uninstall a deployable unit and clean up all the files generated for it.
	 * This is a terrible mess.
	 * 
	 * @param deployableUnitID
	 */
	public void removeDeployableUnit(DeployableUnitID deployableUnitID)
			throws Exception {

		boolean b = getTransactionManager().requireTransaction();

		try {
			if (logger.isDebugEnabled()) {
				logger.debug("removeDeployableUnit " + deployableUnitID);
				logger.debug("referring components map "
						+ this.getDeploymentCacheManager()
								.getReferringComponents());
				logger.debug("serviceToDUMap = "
						+ this.getDeploymentCacheManager()
								.getComponentIDToDeployableUnitIDMap());
			}

			DeployableUnitDescriptorImpl deployableUnitDescriptor = (DeployableUnitDescriptorImpl) this
					.getDeploymentCacheManager()
					.getDeployableUnitIDtoDescriptorMap().get(deployableUnitID);
			if (deployableUnitDescriptor == null)
				throw new UnrecognizedDeployableUnitException(
						"Unrecognized deployable unit " + deployableUnitID);

			// Check if its safe to remove the deployable unit.

			if (this.hasReferringDU(deployableUnitDescriptor)) {

				throw new DependencyException(
						"Somebody is referencing a component of this DU"
								+ " -- cannot uninstall it!");
			}

			removeDU(deployableUnitDescriptor);

			if (logger.isDebugEnabled()) {
				logger.debug("Done with removeDeployableUnit "
						+ deployableUnitID);
				logger.debug("referring components map "
						+ this.getDeploymentCacheManager()
								.getReferringComponents());
				logger.debug("serviceToDUMap = "
						+ this.getDeploymentCacheManager()
								.getComponentIDToDeployableUnitIDMap());
				logger.debug("profileTable = "
						+ this.getDeploymentCacheManager()
								.getProfileComponents());
				logger.debug("sbbComponents = "
						+ this.getDeploymentCacheManager().getSbbComponents());
				logger.debug("serviceComponents = "
						+ this.getDeploymentCacheManager()
								.getServiceComponents());
			}

		} catch (Exception ex) {
			getTransactionManager().setRollbackOnly();
			throw ex;
		} finally {
			if (b)
				getTransactionManager().commit();
		}
	}

	/**
	 * Actually do the unistall.
	 * 
	 * @param deployableUnitID
	 */

    public static Document getDocument(URL url, EntityResolver resolver, boolean validating) throws IllegalArgumentException, IOException {
        if (url == null) throw new IllegalArgumentException("URL is null");

        InputStream is = null;
        try {
            is = url.openStream();
	    InputSource source = new InputSource(is);
	    source.setSystemId(url.toString());	    
	    return getDocument(source, resolver, validating);
	} finally {
            try { if (is != null) is.close(); } catch (IOException ioe) {}
        }
    }

    public static Document getDocument(InputSource source, EntityResolver resolver, boolean validating) throws IOException {
	try 
