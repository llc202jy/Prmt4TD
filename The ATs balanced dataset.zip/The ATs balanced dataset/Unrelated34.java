/*
 * An XML document type.
 * Localname: purchase-order
 * Namespace: http://xmlbean.java.learn.na/BOM
 * Java type: na.learn.java.xmlbean.bom.PurchaseOrderDocument
 *
 * Automatically generated - do not modify.
 */
package na.learn.java.xmlbean.bom.impl;
/**
 * A document containing one purchase-order(@http://xmlbean.java.learn.na/BOM) element.
 *
 * This is a complex type.
 */
public class PurchaseOrderDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements na.learn.java.xmlbean.bom.PurchaseOrderDocument
{
    
    public PurchaseOrderDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PURCHASEORDER$0 = 
        new javax.xml.namespace.QName("http://xmlbean.java.learn.na/BOM", "purchase-order");
    
    
    /**
     * Gets the "purchase-order" element
     */
    public na.learn.java.xmlbean.bom.PurchaseOrderDocument.PurchaseOrder getPurchaseOrder()
    {
        synchronized (monitor())
        {
            check_orphaned();
            na.learn.java.xmlbean.bom.PurchaseOrderDocument.PurchaseOrder target = null;
            target = (na.learn.java.xmlbean.bom.PurchaseOrderDocument.PurchaseOrder)get_store().find_element_user(PURCHASEORDER$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "purchase-order" element
     */
    public void setPurchaseOrder(na.learn.java.xmlbean.bom.PurchaseOrderDocument.PurchaseOrder purchaseOrder)
    {
        synchronized (monitor())
        {
            check_orphaned();
            na.learn.java.xmlbean.bom.PurchaseOrderDocument.PurchaseOrder target = null;
            target = (na.learn.java.xmlbean.bom.PurchaseOrderDocument.PurchaseOrder)get_store().find_element_user(PURCHASEORDER$0, 0);
            if (target == null)
            {
                target = (na.learn.java.xmlbean.bom.PurchaseOrderDocument.PurchaseOrder)get_store().add_element_user(PURCHASEORDER$0);
            }
            target.set(purchaseOrder);
        }
    }
    
    /**
     * Appends and returns a new empty "purchase-order" element
     */
    public na.learn.java.xmlbean.bom.PurchaseOrderDocument.PurchaseOrder addNewPurchaseOrder()
    {
        synchronized (monitor())
        {
            check_orphaned();
            na.learn.java.xmlbean.bom.PurchaseOrderDocument.PurchaseOrder target = null;
            target = (na.learn.java.xmlbean.bom.PurchaseOrderDocument.PurchaseOrder)get_store().add_element_user(PURCHASEORDER$0);
            return target;
        }
    }
    /**
     * An XML purchase-order(@http://xmlbean.java.learn.na/BOM).
     *
     * This is a complex type.
     */
public Statement createStatement() throws SQLException {
		return conn.createStatement();
	}

	public PreparedStatement prepareStatement(String arg0) throws SQLException {
		return conn.prepareStatement(arg0);
	}

	public CallableStatement prepareCall(String arg0) throws SQLException {
		return conn.prepareCall(arg0);
	}

	public String nativeSQL(String arg0) throws SQLException {
		return conn.nativeSQL(arg0);
	}

	public void setAutoCommit(boolean arg0) throws SQLException {
		conn.setAutoCommit(arg0);

	}

	public boolean getAutoCommit() throws SQLException {
		// TODO Auto-generated method stub
		return conn.getAutoCommit();
	}

	public void commit() throws SQLException {
		conn.commit();

	}

	public void rollback() throws SQLException {
		conn.rollback();

	}

	public void close() throws SQLException {
		conn.close();

	}

	public boolean isClosed() throws SQLException {

		return conn.isClosed();
	}

	public DatabaseMetaData getMetaData() throws SQLException {
		return conn.getMetaData();
	}

	public void setReadOnly(boolean arg0) throws SQLException {
		conn.setReadOnly(arg0);

	}

	public boolean isReadOnly() throws SQLException {
		return conn.isReadOnly();
	}

	public void setCatalog(String arg0) throws SQLException {
		conn.setCatalog(arg0);

	}

	public String getCatalog() throws SQLException {
		return conn.getCatalog();
	}

	public void setTransactionIsolation(int arg0) throws SQLException {
		conn.setTransactionIsolation(arg0);

	}

	public int getTransactionIsolation() throws SQLException {
		return conn.getTransactionIsolation();
	}

	public SQLWarning getWarnings() throws SQLException {
		return conn.getWarnings();
	}

	public void clearWarnings() throws SQLException {
		// TODO Auto-generated method stub

	}

	public Statement createStatement(int arg0, int arg1) throws SQLException {

		return conn.createStatement(arg0, arg1);
	}

	public PreparedStatement prepareStatement(String arg0, int arg1, int arg2)
			throws SQLException {
		return conn.prepareStatement(arg0, arg1, arg2);
	}

	public CallableStatement prepareCall(String arg0, int arg1, int arg2)
			throws SQLException {

		return conn.prepareCall(arg0, arg1, arg2);
	}

	public Map<String, Class<?>> getTypeMap() throws SQLException {
		return conn.getTypeMap();
	}

	public void setTypeMap(Map<String, Class<?>> arg0) throws SQLException {
		conn.setTypeMap(arg0);

	}

	public void setHoldability(int arg0) throws SQLException {
		conn.setHoldability(arg0);

	}

	public int getHoldability() throws SQLException {

		return conn.getHoldability();
	}

	public Savepoint setSavepoint() throws SQLException {
		return conn.setSavepoint();
	}

	public Savepoint setSavepoint(String arg0) throws SQLException {
		return conn.setSavepoint(arg0);
	}

	public void rollback(Savepoint arg0) throws SQLException {
		conn.rollback();

	}

	public void releaseSavepoint(Savepoint arg0) throws SQLException {
		// TODO Auto-generated method stub

	}

	public Statement createStatement(int arg0, int arg1, int arg2)
			throws SQLException {

		return conn.createStatement(arg0, arg1, arg2);
	}

	public PreparedStatement prepareStatement(String arg0, int arg1, int arg2,
			int arg3) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	public CallableStatement prepareCall(String arg0, int arg1, int arg2,
			int arg3) throws SQLException {

		return conn.prepareCall(arg0, arg1, arg2, arg3);
	}

	public PreparedStatement prepareStatement(String arg0, int arg1)
			throws SQLException {

		return conn.prepareStatement(arg0, arg1);
	}

	public PreparedStatement prepareStatement(String arg0, int[] arg1)
			throws SQLException {

		return conn.prepareStatement(arg0, arg1);
	}

	public PreparedStatement prepareStatement(String arg0, String[] arg1)
			throws SQLException {

		return conn.prepareStatement(arg0, arg1);
	}
private boolean autoCommit;

	private int transactionIsolation;

	private int initTotalConnections;

	private int minIdle;

	private int maxIdle;

	private int staleAfterTimeMillisecs;

	private int minConnectionsPerHost;

	private int maxConnectionsPerHost;

	private int maxTotalConnections;

	private void setDefaults() {

		autoCommit = true;
		transactionIsolation = Connection.TRANSACTION_NONE;
		initTotalConnections = 5;
		minIdle = 1;
		maxIdle = 1;
		staleAfterTimeMillisecs = 300;
		minConnectionsPerHost = 2;
		maxConnectionsPerHost = 5;
		maxTotalConnections = 25;

	}

	public CommonParams() {
		super();
		setDefaults();
		// TODO Auto-generated constructor stub
	}

	public CommonParams(int initTotalConnections, int maxTotalConnections) {
		setDefaults();
		this.initTotalConnections = initTotalConnections;
		this.maxTotalConnections = maxTotalConnections;
	}

	public boolean isAutoCommit() {
		return autoCommit;
	}

	public void setAutoCommit(boolean autoCommit) {
		this.autoCommit = autoCommit;
	}

	public int getMaxIdle() {
		return maxIdle;
	}

	public void setMaxIdle(int maxIdle) {
		this.maxIdle = maxIdle;
	}

	public int getMinIdle() {
		return minIdle;
	}

	public void setMinIdle(int minIdle) {
		this.minIdle = minIdle;
	}

	public int getStaleAfterTimeMillisecs() {
		return staleAfterTimeMillisecs;
	}

	public void setStaleAfterTimeMillisecs(int staleAfterTimeMillisecs) {
		this.staleAfterTimeMillisecs = staleAfterTimeMillisecs;
	}

	public int getTransactionIsolation() {
		return transactionIsolation;
	}

	public void setTransactionIsolation(int transactionIsolation) {
		this.transactionIsolation = transactionIsolation;
	}

	public int getMaxConnectionsPerHost() {
		return maxConnectionsPerHost;
	}

	public void setMaxConnectionsPerHost(int maxConnectionsPerHost) {
		this.maxConnectionsPerHost = maxConnectionsPerHost;
	}

	public int getMaxTotalConnections() {
		return maxTotalConnections;
	}

	public void setMaxTotalConnections(int maxTotalConnections) {
		this.maxTotalConnections = maxTotalConnections;
	}

	public int getInitTotalConnections() {
		return initTotalConnections;
	}

	public void setInitTotalConnections(int initTotalConnections) {
		this.initTotalConnections = initTotalConnections;
	}

	public int getMinConnectionsPerHost() {
		return minConnectionsPerHost;
	}

	public void setMinConnectionsPerHost(int minConnectionsPerHost) {
		this.minConnectionsPerHost = minConnectionsPerHost;
	}



import java.sql.Connection;

public class CommonParams {

	private boolean autoCommit;

	private int transactionIsolation;

	private int initTotalConnections;

	private int minIdle;

	private int maxIdle;

	private int staleAfterTimeMillisecs;

	private int minConnectionsPerHost;

	private int maxConnectionsPerHost;

	private int maxTotalConnections;

	private void setDefaults() {

		autoCommit = true;
		transactionIsolation = Connection.TRANSACTION_NONE;
		initTotalConnections = 5;
		minIdle = 1;
		maxIdle = 1;
		staleAfterTimeMillisecs = 300;
		minConnectionsPerHost = 2;
		maxConnectionsPerHost = 5;
		maxTotalConnections = 25;

	}

	public CommonParams() {
		super();
		setDefaults();
		// TODO Auto-generated constructor stub
	}

	public CommonParams(int initTotalConnections, int maxTotalConnections) {
		setDefaults();
		this.initTotalConnections = initTotalConnections;
		this.maxTotalConnections = maxTotalConnections;
	}

	public boolean isAutoCommit() {
		return autoCommit;
	}

	public void setAutoCommit(boolean autoCommit) {
		this.autoCommit = autoCommit;
	}

	public int getMaxIdle() {
		return maxIdle;
	}

	public void setMaxIdle(int maxIdle) {
		this.maxIdle = maxIdle;
	}

	public int getMinIdle() {
		return minIdle;
	}

	public void setMinIdle(int minIdle) {
		this.minIdle = minIdle;
	}

	public int getStaleAfterTimeMillisecs() {
		return staleAfterTimeMillisecs;
	}

	public void setStaleAfterTimeMillisecs(int staleAfterTimeMillisecs) {
		this.staleAfterTimeMillisecs = staleAfterTimeMillisecs;
	}

	public int getTransactionIsolation() {
		return transactionIsolation;
	}

	public void setTransactionIsolation(int transactionIsolation) {
		this.transactionIsolation = transactionIsolation;
	}

	public int getMaxConnectionsPerHost() {
		return maxConnectionsPerHost;
	}

	public void setMaxConnectionsPerHost(int maxConnectionsPerHost) {
		this.maxConnectionsPerHost = maxConnectionsPerHost;
	}

	public int getMaxTotalConnections() {
		return maxTotalConnections;
	}

	public void setMaxTotalConnections(int maxTotalConnections) {
		this.maxTotalConnections = maxTotalConnections;
	}

	public int getInitTotalConnections() {
		return initTotalConnections;
	}

	public void setInitTotalConnections(int initTotalConnections) {
		this.initTotalConnections = initTotalConnections;
	}

	public int getMinConnectionsPerHost() {
		return minConnectionsPerHost;
	}

	public void setMinConnectionsPerHost(int minConnectionsPerHost) {
		this.minConnectionsPerHost = minConnectionsPerHost;
	}

}