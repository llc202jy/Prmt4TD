
package org.mobicents.ant.sbbconfigurator;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.tools.ant.BuildException;
import org.mobicents.util.XMLParser;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;

import org.mobicents.ant.SleeDTDResolver;

/**
 * Ant subtask for SbbConfigurator that configures sbb descriptor's env entry elements.
 * @author Eduardo Martins / 2006 PT Inovao (www.ptinovacao.pt)
 */
public class SetEnvEntrySubTask implements SubTask {
	
	// Obtain a suitable logger.
    private static Logger logger = Logger.getLogger(org.mobicents.ant.sbbconfigurator.SetEnvEntrySubTask.class.getName());
    
    // Does all the work, that is, sets a new type and/or new value on a existent env-entry.
    public void run(File sbbDescriptor) {
    	
    	if (envEntryType == null && envEntryValue == null) {
    		// Log the warning
    		logger.log(Level.WARNING, "Skiping sbb description configuration of env-entry with name "+envEntryName+". Reason: new Type and new Value not defined.");
    	}
    	else {	
    		try {    			
    			try {
    				Document sbbjarDoc = XMLParser.getDocument(sbbDescriptor.toURL(), entityResolver);
    				Element sbbRoot = sbbjarDoc.getDocumentElement(); // <sbb-jar>
    				List sbbNodes = XMLParser.getElementsByTagName(sbbRoot, "sbb"); // <sbb>
    							updateXml = true;
    						}    						
    					}
    				}    				    				
    				// write updated descriptor file?
    				if (updateXml) {
    					Source source = new DOMSource(sbbjarDoc);
    					Result result = new StreamResult(sbbDescriptor);
    					Transformer xformer = TransformerFactory.newInstance().newTransformer();
    					DocumentType docType = sbbjarDoc.getDoctype();    					
    					if (docType != null) {    						        					
    						String publicId = docType.getPublicId();    						
    						if(publicId != null) {
    							xformer.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, publicId);    							
    						}
    						String systemId = docType.getSystemId();    						
    						if(systemId != null) {
    							xformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, systemId);    							
    						}
    						//FIXME should we check more properties? 
    					}    	
    					else {
        					logger.warning("sbb descriptor with null doctype");
    					}
    					xformer.transform(source, result);
    				}
    			} catch (IOException e) {
    				throw new BuildException(e);
    			}
    		}
    		catch (Exception ex) {
    			// Log the error
    			logger.log(Level.WARNING, "Bad result: " + ex.getCause().toString());
    		}
    	}
    }
	    
	// The setter for the "name" attribute	
	public void setName(String name) {
		this.envEntryName = name;
	}
	
	// The setter for the "newType" attribute	
	public void setNewType(String newType) {
		this.envEntryType = newType;
	}
	
	// The setter for the "newValue" attribute	
	public void setNewValue(String newValue) {
		this.envEntryValue = newValue;
	}
	
	// The setter for the "sbbName" attribute	
	public void setSbbName(String sbbName) {
		this.sbbName = sbbName;
	}
	
	// The setter for the "sbbVendor" attribute	
	public void setSbbVendor(String sbbVendor) {
		this.sbbVendor = sbbVendor;
	}
	
	// The setter for the "sbbVersion" attribute	
	public void setSbbVersion(String sbbVersion) {
		this.sbbVersion = sbbVersion;
	}
	
	private String envEntryName = null;	
	private String envEntryType = null;
	private String envEntryValue = null;
	private String sbbName = null;	
	private String sbbVendor = null;
	private String sbbVersion = null;
	
	private static final SleeDTDResolver entityResolver = new SleeDTDResolver();
       
}public class RemoteSleeServiceImpl implements RemoteSleeService {
	private NullActivityFactory naf;

	private ActivityContextFactory acf;

	private SleeInternalEndpoint endpoint;

	private EventLookup eventLookup;

	private static Logger log = Logger.getLogger(RemoteSleeServiceImpl.class);

	class DeferredFireEventAction implements
			Runnable {
		ArrayList eventList;

		public DeferredFireEventAction(ArrayList alist) {
			this.eventList = new ArrayList(alist);
		}


		if (eventType == null)
			throw new NullPointerException("eventType is null");
		SleeTransactionManager txmgr = SleeContainer.getTransactionManager();
		boolean b = false;
		try {
			log.debug("fireEvent() called " + txmgr.isInTx());
			if(!txmgr.isInTx())
				txmgr.begin();
{
	    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	    factory.setValidating(validating);	    
            DocumentBuilder builder = factory.newDocumentBuilder();
            if (resolver != null) builder.setEntityResolver(resolver);
	    builder.setErrorHandler(new ParseErrorHandler());
            return builder.parse(source);
        } catch (SAXParseException e) {
	    throw new XMLException("parse error at " + e.getSystemId() + ":" + e.getLineNumber(), e);
        } catch (SAXException e) {
	    throw new XMLException("error reading document", e);
	} catch (ParserConfigurationException e) {
	    throw new XMLException("config error", e);
        }
    }

    /**
     * Get all the descendent element nodes of a given parent node where the
     * name of each descendent node is that given by the specified tag name.
     * Note that only direct child nodes are examined.
     *
     * @param parent the parent element node containing the descendants.
     * @param tagName the name of the tag to retrieve elements for.
     * @return a set of <tt>org.w3c.dom.Element</tt> objects, where each object in the
     *        set corresponds to an element node of the parent node whose tag name is
     *        that specified by <tt>tagName</tt>
     * @exception IllegalArgumentException if either of the supplied
     *        parameters is null, or <tt>tagName</tt> is zero-length..
     */
    public static List getElementsByTagName(Element parent, String tagName) throws IllegalArgumentException {
        if (parent == null) throw new IllegalArgumentException("parent is null");
        if (tagName == null) throw new IllegalArgumentException("tagName is null");
        if (tagName.length() == 0) throw new IllegalArgumentException("tagName is zero-length");

        NodeList nodelist = parent.getChildNodes();
        ArrayList elements = new ArrayList(nodelist.getLength());
        for (int i=0; i<nodelist.getLength(); i++) {
            Node node = nodelist.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE && tagName.equals(((Element)node).getTagName())) {
                elements.add((Element)node);
            }
        }
        return elements;
    }

    /**
     * Get a unique descendant element node from a given parent node.  The
     * descendant element is expected to occur once and only once.
     * 		if ( txmgr.isInTx())
					txmgr.setRollbackOnly();
			} catch (Exception e) {
				log.error("Exception committing tx", e);
			}
			log.error("Exception in fireEvent!", ex);
		} finally {
			try {
				if ( txmgr.isInTx())
					txmgr.commit();
			} catch (Exception e) {
				log.error("Exception committing tx", e);
			}
		}
	}

	public void fireEventQueue(ArrayList queue) {
		if (queue == null)
			throw new NullPointerException("queue is null");
		try {
			log.debug("fireEventQueue() called");
			DeferredFireEventAction daf = new DeferredFireEventAction(queue);
			// The following needs to run in its own tx because 
			// it has to start transactions.
			new ThreadedExecutor().execute(daf);
			
		} catch (Exception ex) {
			throw new RuntimeException("Unexpected error", ex);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.mobicents.slee.connector.server.RemoteSleeService#getEventTypeID(java.lang.String,
	 *      java.lang.String, java.lang.String)
	 */
	public EventTypeID getEventTypeID(String name, String vendor, String version) {
		if (name == null)
			throw new NullPointerException("name is null");
		if (vendor == null)
			throw new NullPointerException("vendor is null");
		if (version == null)
			throw new NullPointerException("version is null");

		log.debug("getEventTypeID() called");
		int eventId = eventLookup.getEventID(name, vendor, version);
		log.debug("eventId is:" + eventId);
		if (eventId == -1) {
			/*
			 * The SLEE spec. does not define what to return if the event type
			 * is not found but we're going to return null
			 */
			return null;
		}
		EventTypeID eventTypeID = eventLookup.getEventTypeID(eventId);
		log.debug("Event type id is:" + eventTypeID);
		return eventTypeID;
	}
}         *
 *  Distributable under LGPL license.              *
 *  See terms of license at gnu.org.               *
 *                                                 *
 ***************************************************
 *
 * Created on Dec 6, 2004 RemoteSleeServiceImpl.java
 */
package org.mobicents.slee.connector.server;

import org.mobicents.slee.container.SleeContainer;
import org.mobicents.slee.resource.EventLookup;
import org.mobicents.slee.runtime.ActivityContext;
import org.mobicents.slee.runtime.ActivityContextFactory;
import org.mobicents.slee.runtime.SleeInternalEndpoint;
import org.mobicents.slee.runtime.facilities.NullActivityFactoryImpl;
import org.mobicents.slee.runtime.facilities.NullActivityImpl;
import org.mobicents.slee.runtime.transaction.SleeTransactionManager;

import java.util.ArrayList;
import java.util.Iterator;
import javax.slee.Address;
import javax.slee.EventTypeID;
import javax.slee.InvalidStateException;
import javax.slee.connection.ExternalActivityHandle;
import javax.slee.nullactivity.NullActivity;
import javax.slee.nullactivity.NullActivityFactory;

import org.jboss.logging.Logger;

import EDU.oswego.cs.dl.util.concurrent.ThreadedExecutor;

/**
 * 
 * Implementation of the RemoteSleeService.
 * 
 * An instance of this class receives invocations via HA-RMI from the outside
 * world.
 * 
 * @author Tim
 */
public class RemoteSleeServiceImpl implements RemoteSleeService {
	private NullActivityFactory naf;

	private ActivityContextFactory acf;

	private SleeInternalEndpoint endpoint;

	private EventLookup eventLookup;

	private static Logger log = Logger.getLogger(RemoteSleeServiceImpl.class);

	class DeferredFireEventAction implements
			Runnable {
		ArrayList eventList;

		public DeferredFireEventAction(ArrayList alist) {
			this.eventList = new ArrayList(alist);
		}




		public void run() {
			log.debug("afterCompletion called -- fireEventQueue Again!");
			Iterator iter = eventList.iterator();
			while (iter.hasNext()) {
				EventInvocation ei = (EventInvocation) iter.next();
				fireEvent(ei.event, ei.eventTypeId, ei.externalActivityHandle,
						ei.address);
			}
		}

	}

	public RemoteSleeServiceImpl(NullActivityFactory naf,
			SleeInternalEndpoint endpoint, EventLookup eventLookup,
			ActivityContextFactory acf) {
		log.debug("Creating RemoteSleeServiceImpl");
		this.naf = naf;
		this.endpoint = endpoint;
		this.eventLookup = eventLookup;
		this.acf = acf;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.mobicents.slee.connector.server.RemoteSleeService#createActivityHandle()
	 */
	public ExternalActivityHandle createActivityHandle() {

		log.debug("createActivityHandle() called current " );
		SleeTransactionManager txmgr = SleeContainer.getTransactionManager();
		boolean b = false;
		try {
			b  = txmgr.requireTransaction();
			NullActivityImpl na = (NullActivityImpl) (((NullActivityFactoryImpl) naf)
					.createNullActivityNoTx());
			ActivityContext ac = acf.getActivityContext(na);

			return new ActivityHandleImpl(ac.getActivityContextId());
		} catch (Exception ex) {
			try {
				if (b)
				txmgr.setRollbackOnly();
			} catch (Exception e) {
				log.error("createActivityHandle(): exception occured", ex);
			}
			return null;
		} finally {
			try {
				if(b)
					txmgr.commit();
			} catch (Exception ex) {
				log.error("createActivityHandle(): exception occured", ex);
			}

		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.mobicents.slee.connector.server.RemoteSleeService#fireEvent(java.lang.Object,
	 *      javax.slee.EventTypeID,
	 *      org.mobicents.slee.connector.server.ActivityHandleImpl,
	 *      javax.slee.Address)
	 */
	public void fireEvent(Object event, EventTypeID eventType,
			ExternalActivityHandle activityHandle, Address address) {
		if (event == null)
			throw new NullPointerException("event is null");
		if (eventType == null)
			throw new NullPointerException("eventType is null");
		SleeTransactionManager txmgr = SleeContainer.getTransactionManager();
		boolean b = false;
		try {
			log.debug("fireEvent() called " + txmgr.isInTx());
			if(!txmgr.isInTx())
				txmgr.begin();

			// fire an event on the slee endpoint using the right null activity
			NullActivityImpl na = null;
			if (activityHandle != null) {

				ActivityHandleImpl handle = (ActivityHandleImpl) activityHandle;
				ActivityContext ac = acf.getActivityContextById(handle
						.getKey());
				if (ac == null) {
					log.error("Invalid activity handle!");
					return;
				}
				na = (NullActivityImpl) ac.getActivity();

			} else {
				log.debug("Creating new null activity");
				na = (NullActivityImpl) ((NullActivityFactoryImpl) naf)
						.createNullActivityNoTx();
			}

			endpoint.enqueueEvent(eventType, event, na, address);
			log.debug("Queued event");
		} catch (Exception ex) {
			try {
				if ( txmgr.isInTx())
					txmgr.setRollbackOnly();
			} catch (Exception e) {
				log.error("Exception committing tx", e);
			}
			log.error("Exception in fireEvent!", ex);
		} finally {
			try {
				if ( txmgr.isInTx())
					txmgr.commit();
			} catch (Exception e) {
				log.error("Exception committing tx", e);
			}
		}
	}

	public void fireEventQueue(ArrayList queue) {
		if (queue == null)
			throw new NullPointerException("queue is null");
		try {
			log.debug("fireEventQueue() called");
			DeferredFireEventAction daf = new DeferredFireEventAction(queue);
			// The following needs to run in its own tx because 
			// it has to start transactions.
			new ThreadedExecutor().execute(daf);
			
		} catch (Exception ex) {
			throw new RuntimeException("Unexpected error", ex);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.mobicents.slee.connector.server.RemoteSleeService#getEventTypeID(java.lang.String,
	 *      java.lang.String, java.lang.String)
	 */
	public EventTypeID getEventTypeID(String name, String vendor, String version) {
		if (name == null)
			throw new NullPointerException("name is null");
		if (vendor == null)
			throw new NullPointerException("vendor is null");
		if (version == null)
			throw new NullPointerException("version is null");

		log.debug("getEventTypeID() called");
		int eventId = eventLookup.getEventID(name, vendor, version);
		log.debug("eventId is:" + eventId);
		if (eventId == -1) {
			/*
			 * The SLEE spec. does not define what to return if the event type
			 * is not found but we're going to return null
			 */
			return null;
		}
		EventTypeID eventTypeID = eventLookup.getEventTypeID(eventId);
		log.debug("Event type id is:" + eventTypeID);
		return eventTypeID;
	}
}package org.mobicents.util;

import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import java.util.HashMap;
import java.io.InputStream;
import java.net.URL;

// Generic resource-lookup-based DTD resolver
public abstract class DTDResolver implements EntityResolver {
    private final HashMap resources = new HashMap();

    /**
     * Register a local resource as a substitute for an external entity reference..
     * @param publicID the public identitify of the external entity.
     * @param resourceURL the URL of the resource
     */
    protected void registerDTDURL(String publicID, URL resourceURL) {
        resources.put(publicID, resourceURL);
    }

    protected void registerDTDResource(String publicId, String resourcePath) {
        registerDTDURL(publicId, getClass().getClassLoader().getResource(resourcePath));
    }

    /**
     * Attempt to resolve an external identity.
     * @param publicId the public identifier of the external entity being referenced.
     * @param systemId the system identifier of the external entity being referenced.
     * @return an InputSource object describing the new input source, or null to request
     *        that the parser open a regular URI connection to the system identifier.
     */
    public InputSource resolveEntity(String publicId, String systemId) {
        URL resourceURL = (URL)resources.get(publicId);
        if (resourceURL != null) {
            InputStream resourceStream = null;
            try {
                resourceStream = resourceURL.openStream();
                InputSource is = new InputSource(resourceStream);
                is.setPublicId(publicId);
                is.setSystemId(resourceURL.toExternalForm());
                return is;
            }
            catch (Exception e) {
                try { if(resourceStream != null) resourceStream.close(); } catch (Exception e2) {}
            }
        }
        return null;
    }
}/*
* Created on Jul 19, 2004
*
* The Open SLEE Project
*
* The source code contained in this file is in in the public domain.          
* It can be used in any project, or product without prior permission, 	      
* license or royalty payments. There is no claim of correctness and
* NO WARRANTY OF ANY KIND provided with this code.
*/
package org.mobicents.slee.container;

import javax.slee.Address;
import org.mobicents.slee.container.management.*;
import org.mobicents.slee.resource.SleeActivityHandle;

import javax.slee.EventTypeID;

/**
 * 
 * Implements the InitialEventSelector interface
 * 
 * @author F.Moggia
 * 
 * 
 */
public class InitialEventSelectorImpl implements javax.slee.InitialEventSelector{
    private EventTypeID eventTypeID;
    private String eventName;
    private Object event;
    private Object activity;
    private Address address;
    private String customName;

    int[] select;
    private boolean isSelectMethod = false;
    private boolean isActivityContextSelected= false;
    private boolean isAddressProfileSelected= false;
    private boolean isAddressSelected= false;
    private boolean isEventSelected= false;
    private boolean isEventTypeSelected= false;
    
    
    private boolean isInitialEvent= false;
    
    
    private String selectMethodName;
    

    
    
    
    public InitialEventSelectorImpl(EventTypeID type, Object event, Object activity,  int[] select, String methodName, Address address) {
        eventTypeID = type;
        this.event = event;
        this.address = address;
        if ( activity instanceof SleeActivityHandle ) {
            SleeActivityHandle sah = (SleeActivityHandle) activity;
            this.activity = sah.getActivity();
        } else this.activity = activity;
        
        for(int i=0; i<select.length;i++){
            switch(select[i]){ 
            	case SbbEventEntry.ACTIVITY_CONTEXT_INITIAL_EVENT_SELECT: this.isActivityContextSelected = true;break;
            	case SbbEventEntry.ADDRESS_INITIAL_EVENT_SELECT:this.isAddressSelected=true;break;
            	case SbbEventEntry.ADDRESS_PROFILE_INITIAL_EVENT_SELECT:this.isAddressProfileSelected=true;break;
            	case SbbEventEntry.EVENT_INITIAL_EVENT_SELECT:this.isEventSelected=true;break;
            	case SbbEventEntry.EVENT_TYPE_INITIAL_EVENT_SELECT:this.isEventTypeSelected=true;break;
           
         
            
            }
        }
        
        if (methodName == null){
            isSelectMethod = false;
        } else {
            isSelectMethod = true;
            selectMethodName = methodName;
        }
        
        
    }
    
    
    public String toString() {
        return new StringBuffer()
        			.append("InitialEventSelector = { ")
        			.append("eventTypeID " + eventTypeID + "eventName " + eventName + " event " + event + " activity " + activity + " address " + address )
        			.append("\n activityContextSelected = "  + isActivityContextSelected)
        			.append("\n isAddressSelected " + this.isAddressSelected)
        			.append("\n isAddressProfileSelected " + this.isAddressProfileSelected)
        			.append("\n isEventSelected " + this.isEventSelected)
        			.append("\n customName " + this.customName)
        			.append("\n selectMethodName " + this.selectMethodName)
        			.append("\n }").toString();
    }
    
    /**
     * @return Returns the isActivityContextSelected.
     */
    public boolean isActivityContextSelected() {
        return this.isActivityContextSelected;
    }
    /**
     * @return Returns the isAddressProfileSelected.
     */
    public boolean isAddressProfileSelected() {
        return this.isAddressProfileSelected;
    }
    /**
     * @return Returns the isAddressSelected.
     */
    public boolean isAddressSelected() {
        return this.isAddressSelected;
    }
    /**
     * @return Returns the isEventTypeSelected.
     */
    public boolean isEventTypeSelected() {
        return this.isEventTypeSelected;
    }
    /**
     * @return Returns the eventType.
     */
    public EventTypeID getEventTypeID() {
        return eventTypeID;
    }
    /**
     * @param eventType The eventType to set.
     */
    public void setEventType(EventTypeID eventTypeID) {
        this.eventTypeID = eventTypeID;
    }
    /**
     * @return Returns the isEventSelected.
     */
    public boolean isEventSelected() {
        return this.isEventSelected;
    }
    /**
     * @param isEventSelected The isEventSelected to set.
     */
    
    /**
     * @param isAddressProfileSelected The isAddressProfileSelected to set.
     */
    public void setAddressProfileSelected(boolean isAddressProfileSelected) {
        this.isAddressProfileSelected = isAddressProfileSelected;
    }
    /**
     * @param isAddressSelected The isAddressSelected to set.
     */
    public void setAddressSelected(boolean isAddressSelected) {
        this.isAddressSelected = isAddressSelected;
    }
    /**
     * @param isEventTypeSelected The isEventTypeSelected to set.
     */
    public void setEventTypeSelected(boolean isEventTypeSelected) {
        this.isEventTypeSelected = isEventTypeSelected;
    }
    /**
     * @return Returns the isSelectMethod.
     */
    public boolean isSelectMethod() {
        return isSelectMethod;
    }
    /**
     * @param isSelectMethod The isSelectMethod to set.
     */
    public void setSelectMethod(boolean isSelectMethod) {
        this.isSelectMethod = isSelectMethod;
    }
    /**
     * @return Returns the selectMethodName.
     */
    public String getSelectMethodName() {
        return selectMethodName;
    }
    /**
     * @param selectMethodName The selectMethodName to set.
     */
    public void setSelectMethodName(String selectMethodName) {
        this.selectMethodName = selectMethodName;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#getEventName()
     */
    public String getEventName() {
        return eventName;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#getEvent()
     */
    public Object getEvent() {
        return event;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#getActivity()
     */
    public Object getActivity() {
        return activity;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#getAddress()
     */
    public Address getAddress() {
        
        return address;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#setAddress(javax.slee.Address)
     */
    public void setAddress(Address address) {
        
        this.address = address;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#getCustomName()
     */
    public String getCustomName() {
        
        return customName;
    }

    public void setCustomName(String customName) {
        this.customName = customName;
    }
    
    public void setActivityContextSelected(boolean isActivityContextSelected) {
        this.isActivityContextSelected = isActivityContextSelected;
    }
    
    public void setEventSelected(boolean isEventSelected) {
        this.isEventSelected = isEventSelected;
    }
    
    public boolean isInitialEvent() {
        return isInitialEvent;
    }
    
    public void setInitialEvent(boolean isInitialEvent) {
        this.isInitialEvent = isInitialEvent;
    }
}package org.mobicents.util;

import java.net.URL;

import java.io.IOException;
import java.io.InputStream;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

import org.w3c.dom.Document;
import org.w3c.dom.Attr;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Element;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.mobicents.util.XMLException;
 
public final class XMLParser {
    /**
     * Parse an XML document.  Equivalent to <tt>getDocument(url, null)</tt>.
     * @param url the url of the document to parse.
     * @return a parsed document tree.
     * @exception IllegalArgumentException if the supplied url is null.
     * @exception IOException if an IO exception or parse error occurs with the URL.
     */
    public static Document getDocument(URL url) throws IllegalArgumentException, IOException {
	return getDocument(url, null);
    }

    /**
     * Parse an XML document using a given resolver for DTDs.
     * @param url the url of the document to parse.
     * @param resolver the entity resolver to use.  If null, no specific resolver
     *        is used.
     * @return a parsed document tree.
     * @exception IllegalArgumentException if the supplied url is null.
     * @exception IOException if an IO exception occurs with the URL.
     */
    public static Document getDocument(URL url, EntityResolver resolver) throws IllegalArgumentException, IOException {
	return getDocument(url, resolver, false);
    }

    private static class ParseErrorHandler implements ErrorHandler {
	public void error(SAXParseException e) throws SAXException {
	    throw e;
	}

	public void fatalError(SAXParseException e) throws SAXException {
	    throw e;
	}

	public void warning(SAXParseException e) throws SAXException {
	    System.err.println("Warning: " + e);
	}
    }

    public static Document getDocument(URL url, EntityResolver resolver, boolean validating) throws IllegalArgumentException, IOException {
        if (url == null) throw new IllegalArgumentException("URL is null");

        InputStream is = null;
        try {
            is = url.openStream();
	    InputSource source = new InputSource(is);
	    source.setSystemId(url.toString());	    
	    return getDocument(source, resolver, validating);
	} finally {
            try { if (is != null) is.close(); } catch (IOException ioe) {}
        }
    }

    public static Document getDocument(InputSource source, EntityResolver resolver, boolean validating) throws IOException {
	try {
	    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	    factory.setValidating(validating);	    
            DocumentBuilder builder = factory.newDocumentBuilder();
            if (resolver != null) builder.setEntityResolver(resolver);
	    builder.setErrorHandler(new ParseErrorHandler());
            return builder.parse(source);
        } catch (SAXParseException e) {
	    throw new XMLException("parse error at " + e.getSystemId() + ":" + e.getLineNumber(), e);
        } catch (SAXException e) {
	    throw new XMLException("error reading document", e);
	} catch (ParserConfigurationException e) {
	    throw new XMLException("config error", e);
        }
    }

    /**
     * Get all the descendent element nodes of a given parent node where the
     * name of each descendent node is that given by the specified tag name.
     * Note that only direct child nodes are examined.
     *
     * @param parent the parent element node containing the descendants.
     * @param tagName the name of the tag to retrieve elements for.
     * @return a set of <tt>org.w3c.dom.Element</tt> objects, where each object in the
     *        set corresponds to an element node of the parent node whose tag name is
     *        that specified by <tt>tagName</tt>
     * @exception IllegalArgumentException if either of the supplied
     *        parameters is null, or <tt>tagName</tt> is zero-length..
     */
    public static List getElementsByTagName(Element parent, String tagName) throws IllegalArgumentException {
        if (parent == null) throw new IllegalArgumentException("parent is null");
        if (tagName == null) throw new IllegalArgumentException("tagName is null");
        if (tagName.length() == 0) throw new IllegalArgumentException("tagName is zero-length");

        NodeList nodelist = parent.getChildNodes();
        ArrayList elements = new ArrayList(nodelist.getLength());
        for (int i=0; i<nodelist.getLength(); i++) {
            Node node = nodelist.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE && tagName.equals(((Element)node).getTagName())) {
                elements.add((Element)node);
            }
        }
        return elements;
    }

    /**
     * Get a unique descendant element node from a given parent node.  The
     * descendant element is expected to occur once and only once.
     * @param parent the parent element node containing the descendant.
     * @param tagName the name of the tag to retrieve elements for.
     * @return the descendant element noe.
     * @exception IllegalArgumentException if either of the supplied
     *        parameters is null, or <tt>tagName</tt> is zero-length..
     * @exception XMLException if zero or more than one descendant
     *        element with the given name is found.
     */
    public static Element getUniqueElement(Element parent, String tagName) throws IllegalArgumentException, XMLException {
        Iterator elements = getElementsByTagName(parent, tagName).iterator();
        if (elements.hasNext()) {
            Element element = (Element)elements.next();
            if (elements.hasNext()) {
                throw new XMLException("Only one \"" + tagName + "\" element expected");
            }
            return element;
        }
        else {
            throw new XMLException("One \"" + tagName + "\" (and only one) element expected");
        }
    }

    /**
     * Get an optional descendant element node from a given parent node.  The
     * descendant may occur at most one time.
     * @param parent the parent element containing the descendant.
     * @param tagName the name of the tag to retrieve elements for.
     * @return the descendant element, or <tt>null</tt> if no descendant
     *        was found.
     * @exception IllegalArgumentException if either of the supplied
     *        parameters is null, or <tt>tagName</tt> is zero-length..
     * @exception XMLException if more than one element was found.
     */
    public static Element getOptionalElement(Element parent, String tagName) throws IllegalArgumentException, XMLException {
        Iterator elements = getElementsByTagName(parent, tagName).iterator();
        if (elements.hasNext()) {
            Element element = (Element)elements.next();
            if (elements.hasNext()) {
                throw new XMLException("At most one \"" + tagName + "\" element expected");
            }
            return element;
        }
        else {
            return null;
        }
    }

    /**
     * Get the contents of an text element.  A text element contains a string of
     * text only, not further XML tags.
     * @param element the text element.
     * @return the text contents of the element as a string.  Whitespace from both
     *        ends of the string is trimmed.
     * @throws IllegalStateException if the element is null
     * @throws XMLException if the element is not a text node.
     */
    public static String getElementContent(Element element) throws IllegalArgumentException, XMLException {
        if (element == null) throw new IllegalArgumentException("Element is null");

        NodeList nodelist = element.getChildNodes();
        if (nodelist.getLength() == 0)
            return "";

        if ((nodelist.getLength() != 1) || (nodelist.item(0).getNodeType() != Node.TEXT_NODE))
            throw new XMLException("Not a text node: " + element);

        return nodelist.item(0).getNodeValue().trim();
    }

    /**
     * Get the contents of a text element that is a child of another node.
     *
     * @param parent the parent element of the text element
     * @param tagName the tag name of the text element
     * @return the text contents of the element as a string.  Whitespace from both
     *        ends of the string is trimmed.
     * @throws XMLException if the element is not found, or is not a text node
     */
    public static String getTextElement(Element parent, String name) throws XMLException {
	return getElementContent(getUniqueElement(parent, name));
    }

    public static String getOptionalTextElement(Element parent, String name) throws XMLException {
	Element e = getOptionalElement(parent, name);
	if (e == null) return null;
	return getElementContent(e);
    }

    /**
     * Create a new tag as a child of an existing element. Fill the tag with
     * the given text string.
     *
     * @param parent the parent element to create the tag as a child of
     * @param tagName the tag name of the child to create
     * @param text the text content to give the newly created tag     
     */
    public static void createTextElement(Element parent, String tagName, String text) {
	Document doc = parent.getOwnerDocument();
	Element newElement = doc.createElement(tagName);
	newElement.appendChild(doc.createTextNode(text));
	parent.appendChild(newElement);
    }

    
    /**
     * Merge two documents. Elements from the toMerge document are copied into the toModify
     * document. Elements with the special attribute 'id' are matched between documents based
     * on the value of the attribute (which is expected to be unique across all instances in
     * a document -- i.e. it is an XML ID attribute).
     *<p>
     * For example, if this is the toModify document:
     *<pre>
     * &lt;doc1&gt
     *   &lt;tag1&gt abc &lt;/tag1&gt
     *   &lt;tag2 id="123"&gt 
     *     &lt;tag3&gt; def &lt;/tag3&gt;
     *   &lt;/tag2&gt
     * &lt;/doc1&gt
     *</pre>
     * .. and this is the toMerge document:
     *<pre>
     * &lt;doc2&gt
     *   &lt;new-tag&gt ghi &lt;/new-tag&gt
     *   &lt;tag2 id="123"&gt
     *     &lt;new-tag-2&gt; jkl &lt;/new-tag-2&gt;
     *   &lt;/tag2&gt
     * &lt;/doc2&gt
     *</pre>
     *</pre>
     * .. then toModify will become:
     *<pre>
     * &lt;doc1&gt
     *   &lt;tag1&gt abc &lt;/tag1&gt
     *   &lt;tag2 id="123"&gt 
     *     &lt;tag3&gt; def &lt;/tag3&gt;
     *     &lt;new-tag-2&gt; jkl &lt;/new-tag-2&gt;
     *   &lt;/tag2&gt
     *   &lt;new-tag&gt ghi &lt;/new-tag&gt
     * &lt;/doc1&gt
     *</pre>
     *
     * @param toModify the document to merge data into
     * @param toMerge the document to merge data from
     * @param tagsToMerge a non-null array of tags where collisions should be merged
     * @throws XMLException if an ID was found in toMerge that could not be matched up with toModify
     */
    public static void mergeDocuments(Document toModify, Document toMerge, String[] tagsToMerge) throws XMLException {
	mergeTree(toModify.getDocumentElement(), toModify.getDocumentElement(), toMerge.getDocumentElement(), tagsToMerge);
    }

    /**
     * As {@link #mergeDocuments(Document,Document,String[])}, but no collisions are merged
     * @param toModify the document to merge data into
     * @param toMerge the document to merge data from
     */
    public static void mergeDocuments(Document toModify, Document toMerge) throws XMLException {
	mergeDocuments(toModify, toMerge, new String[0]);
    }

    private static Element findID(Node top, String id) {
	NodeList childList = top.getChildNodes();
	for (int i = 0; i < childList.getLength(); ++i) {
	    Node child = childList.item(i);
	    if (child.getNodeType() == Node.ELEMENT_NODE) {
		Element elem = (Element)child;
		Attr idAttr = elem.getAttributeNode("id");
		if (idAttr != null) {
		    if (idAttr.getValue().equals(id))
			return elem;
		    else
			continue;  // don't inspect past an existing ID attribute!
		}
	    }
	    
	    // Check subtree
	    Element found = findID(child, id);
	    if (found != null)
		return found;
	}

	return null;
    }

    // Merge children of 'source' to be children of 'dest'.
    // Also do ID merging.
    private static void mergeTree(Node top, Node dest, Node source, String[] tagsToMerge) throws XMLException {
	NodeList sourceList = source.getChildNodes();
	for (int i = 0; i < sourceList.getLength(); ++i) {
	    Node sourceChild = sourceList.item(i);
	    
	    if (sourceChild.getNodeType() == Node.ELEMENT_NODE) {
		Element elem = (Element)sourceChild;
		Attr idAttr = elem.getAttributeNode("id");
		if (idAttr != null) {
		    Element mergeDest = findID(top, idAttr.getValue());
		    if (mergeDest == null)
			throw new XMLException("Missing ID attribute: " + idAttr.getValue());
		    mergeTree(mergeDest, mergeDest, elem, tagsToMerge);
		    continue;
		}

                // Handle node collisions -- merge children.
                boolean found = false;
                NodeList destChildren = dest.getChildNodes();
                for (int j = 0; j < destChildren.getLength() && !found; ++j) {
                    Node destNode = destChildren.item(j);
                    if (destNode.getNodeType() == Node.ELEMENT_NODE && ((Element)destNode).getTagName().equals(elem.getTagName())) {
                        for (int k = 0; k < tagsToMerge.length && !found; ++k) {
                            if (elem.getTagName().equals(tagsToMerge[k])) {
                                // OK to merge, do it.
                                found = true;
                                mergeTree(top, destNode, sourceChild, tagsToMerge);
                            }
                        }
                    }
                }
                
                if (found)
                    continue;
            }

            switch (sourceChild.getNodeType()) {
            default:    
                // Don't copy other nodes (attributes, etc).
                // nb: attributes are actually copied automatically when we import their
                // owning element (see Document.importNode() javadoc)
                break;

            case Node.ELEMENT_NODE:
                {
                    // Import and recurse.
                    Node newNode = dest.getOwnerDocument().importNode(sourceChild, false);
                    dest.appendChild(newNode);	    
                    mergeTree(top, newNode, sourceChild, tagsToMerge);
                    break;
                }

            case Node.PROCESSING_INSTRUCTION_NODE:
            case Node.TEXT_NODE:
            case Node.CDATA_SECTION_NODE:
            case Node.COMMENT_NODE:
            case Node.ENTITY_REFERENCE_NODE:
                {
                    // Do a deep copy import as these nodes cannot contain Elements
                    Node newNode = dest.getOwnerDocument().importNode(sourceChild, true);
                    dest.appendChild(newNode);	    
                    break;
                }
            }
	}
    }    
}