public class Authenticate {
    protected java.lang.String sessionKeyHash;
    protected java.lang.String encryptedPassword;
    
    public Authenticate() {
    }
    
    public Authenticate(java.lang.String sessionKeyHash, java.lang.String encryptedPassword) {
        this.sessionKeyHash = sessionKeyHash;
        this.encryptedPassword = encryptedPassword;
    }
    
    public java.lang.String getSessionKeyHash() {
        return sessionKeyHash;
    }
    
    public void setSessionKeyHash(java.lang.String sessionKeyHash) {
        this.sessionKeyHash = sessionKeyHash;
    }
    
    public java.lang.String getEncryptedPassword() {
        return encryptedPassword;
    }
    
    public void setEncryptedPassword(java.lang.String encryptedPassword) {
        this.encryptedPassword = encryptedPassword;
    }
}