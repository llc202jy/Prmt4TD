package pkiva.ldap.connectors;

import javax.resource.cci.ResourceAdapterMetaData;

public class LDAPResourceAdapterMetaDataImpl implements ResourceAdapterMetaData
{
  
  private static final String ADAPTER_VERSION = "1.0";
  private static final String ADAPTER_VENDOR_NAME = "e-xtendnow";
  private static final String ADAPTER_NAME = "LDAP Resource Adapter";
  private static final String ADAPTER_DESCRIPTION = "A simple sample resource adapter";
  private static final String SPEC_VERSION = "1.0";
  private static final String[] INTERACTION_SPECS_SUPPORTED =
  { "pkiva.ldap.connectors.LDAPInteractionSpecImpl" };
  
  public LDAPResourceAdapterMetaDataImpl()
  {
    super();
  }
  
  public String getAdapterVersion()
  {
    return ADAPTER_VERSION;
  }
  
  public String getAdapterVendorName()
  {
    return ADAPTER_VENDOR_NAME;
  }
  
  public String getAdapterName()
  {
    return ADAPTER_NAME;
  }
  
  public String getAdapterShortDescription()
  {
    return ADAPTER_DESCRIPTION;
  }
  
  public String getSpecVersion()
  {
    return SPEC_VERSION;
  }
  
  public String[] getInteractionSpecsSupported()
  {
    return INTERACTION_SPECS_SUPPORTED;
  }
  
  public boolean supportsExecuteWithInputAndOutputRecord()
  {
    return true;
  }
  
  public boolean supportsExecuteWithInputRecordOnly()
  {
    return false;
  }
  
  public boolean supportsLocalTransactionDemarcation()
  {
    return false;
  }
  
}

package pkiva.ldap.connectors;


import javax.resource.NotSupportedException;
import javax.resource.ResourceException;
import javax.resource.cci.IndexedRecord;
import javax.resource.cci.MappedRecord;
import javax.resource.cci.RecordFactory;

public class LDAPRecordFactoryImpl implements RecordFactory
{
  
  private static final String MAPPED_RECORD_NOT_SUPPORTED_ERROR = "Mapped record not supported";
  private static final String INVALID_RECORD_NAME = "Invalid record name";
  
  public LDAPRecordFactoryImpl()
  {
    super();
  }
  
  public MappedRecord createMappedRecord(String recordName) throws ResourceException
  {
    throw new NotSupportedException(MAPPED_RECORD_NOT_SUPPORTED_ERROR);
  }
  
  public IndexedRecord createIndexedRecord(String recordName) throws ResourceException
  {
    LDAPIndexedRecordImpl record = null;
    if ((recordName.equals(LDAPIndexedRecordImpl.INPUT))
    || (recordName.equals(LDAPIndexedRecordImpl.OUTPUT)))
    {
      record = new LDAPIndexedRecordImpl();
      record.setRecordName(recordName);
    }
    if (record == null)
    {
      throw new ResourceException(INVALID_RECORD_NAME);
    } else
    {
      return record;
    }
  }
  
}

package pkiva.ldap.connectors;

import pkiva.ldap.EstructuralElement;
import pkiva.ldap.LDAPManager;

import java.util.Hashtable;
import java.util.Collection;
import java.util.Date;
import java.beans.PropertyChangeSupport;
import javax.naming.Name;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.NameParser;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.DirContext;
import javax.naming.directory.Attributes;
import javax.resource.ResourceException;

/**
 *
 * @author  Scott.Stark@jboss.org
 * @version $Revision: 1.5 $
 */
public class LDAPJBDirContextImpl implements LDAPJBDirContext
{
   LDAPJBManagedConnection mc;

   /** Creates new FSDirContext */
   public LDAPJBDirContextImpl(LDAPJBManagedConnection mc)
   {
      this.mc = mc;
   }

   protected void setManagedConnection(LDAPJBManagedConnection mc)
   {
      this.mc = mc;
   }

   public Attributes getAttributes(Name name, String[] str) throws NamingException
   {
      return null;
   }
   
   public void close() throws NamingException
   {
//      pkiva.log.LogManager.getLogger(this.getClass()).debug("#### %%%% LDAPJBDirContextImpl close");
      mc.close();
   }

   public NamingEnumeration list(String str) throws NamingException
   {
      return null;
   }
   
   public void unbind(Name name) throws NamingException
   {
   }
   
   public DirContext getSchemaClassDefinition(Name name) throws NamingException
   {
      return null;
   }
   
   public DirContext createSubcontext(String str, Attributes attributes) throws NamingException
   {
      return null;
   }
   
   public String getNameInNamespace() throws NamingException
   {
      return null;
   }
   
   public Object addToEnvironment(String str, Object obj) throws NamingException
   {
      return null;
   }
   
   public NamingEnumeration listBindings(Name name) throws NamingException
   {
      return null;
   }
   
   public void bind(Name name, Object obj) throws NamingException
   {
   }
   
   public NamingEnumeration search(String str, Attributes attributes, String[] str2) throws NamingException
   {
      return null;
   }
   
   public void modifyAttributes(Name name, int param, Attributes attributes) throws NamingException
   {
   }
   
   public Hashtable getEnvironment() throws NamingException
   {
      return null;
   }
   
   public void bind(String str, Object obj) throws NamingException
   {
   }
   
   public void rebind(String str, Object obj, Attributes attributes) throws NamingException
   {
   }
   
   public DirContext getSchema(Name name) throws NamingException
   {
      return null;
   }
   
   public DirContext getSchemaClassDefinition(String str) throws NamingException
   {
      return null;
   }
   
   public Object lookup(String str) throws NamingException
   {
      return null;
   }
   
   public void destroySubcontext(String str) throws NamingException
   {
   }
   
   public Context createSubcontext(Name name) throws NamingException
   {
      return null;
   }
   
   public Object lookupLink(String str) throws NamingException
   {
      return null;
   }
   
   public DirContext getSchema(String str) throws NamingException
   {
      return null;
   }
   
   public Object lookup(Name name) throws NamingException
   {
      return null;
   }
   
   public void destroySubcontext(Name name) throws NamingException
   {
   }
   
   public NamingEnumeration listBindings(String str) throws NamingException
   {
      return null;
   }
   
   public void rebind(String str, Object obj) throws NamingException
   {
   }
   
   public Object removeFromEnvironment(String str) throws NamingException
   {
      return null;
   }
   
   public void bind(String str, Object obj, Attributes attributes) throws NamingException
   {
   }
   
   public NamingEnumeration search(Name name, Attributes attributes) throws NamingException
   {
      return null;
   }
   
   public NameParser getNameParser(String str) throws NamingException
   {
      return null;
   }
   
   public void bind(Name name, Object obj, Attributes attributes) throws NamingException
   {
   }
   
   public Attributes getAttributes(String str) throws NamingException
   {
      return null;
   }
   
   public void rename(String str, String str1) throws NamingException
   {
   }
   
   public void rename(Name name, Name name1) throws NamingException
   {
   }
   
   public DirContext createSubcontext(Name name, Attributes attributes) throws NamingException
   {
      return null;
   }
   
   public void rebind(Name name, Object obj, Attributes attributes) throws NamingException
   {
   }
   
   public NamingEnumeration list(Name name) throws NamingException
   {
      return null;
   }
   
   public Context createSubcontext(String str) throws NamingException
   {
      return null;
   }
   
   public void modifyAttributes(String str, int param, Attributes attributes) throws NamingException
   {
   }
   
   public NamingEnumeration search(String str, Attributes attributes) throws NamingException
   {
      return null;
   }
   
   public Name composeName(Name name, Name name1) throws NamingException
   {
      return null;
   }
   
   public String composeName(String str, String str1) throws NamingException
   {
      return null;
   }
   
   public NamingEnumeration search(Name name, Attributes attributes, String[] str) throws NamingException
   {
      return null;
   }
   
   public void rebind(Name name, Object obj) throws NamingException
   {
   }
   
   public void modifyAttributes(Name name, ModificationItem[] modificationItem) throws NamingException
   {
   }
   
   public NamingEnumeration search(Name name, String str, SearchControls searchControls) throws NamingException
   {
      return null;
   }
   
   public NamingEnumeration search(Name name, String str, Object[] obj, SearchControls searchControls) throws NamingException
   {
      return null;
   }
   
   public void unbind(String str) throws NamingException
   {
   }
   
   public void modifyAttributes(String str, ModificationItem[] modificationItem) throws NamingException
   {
   }
   
   public Attributes getAttributes(Name name) throws NamingException
   {
      return null;
   }
   
   public Object lookupLink(Name name) throws NamingException
   {
      return null;
   }
   
   public NameParser getNameParser(Name name) throws NamingException
   {
      return null;
   }
   
   public Attributes getAttributes(String str, String[] str1) throws NamingException
   {
      return null;
   }
   
   public NamingEnumeration search(String str, String str1, SearchControls searchControls) throws NamingException
   {
      return null;
   }
   
   public NamingEnumeration search(String str, String str1, Object[] obj, SearchControls searchControls) throws NamingException
   {
      return null;
   }

    // JCA Specific methods:
    public Object execute(String strOperation) throws ResourceException
    {
        return execute(strOperation, null);
    }

    public Object execute(String strOperation, Object params) throws ResourceException
    {

//        pkiva.log.LogManager.getLogger(this.getClass()).debug("#### %%%% Request to execute. Function Name: " + strOperation);

        Object returnObj = null;

        if (strOperation.equals(LOAD_DATA_FUNCTION))
        {
          loadData();
        }
        else if (strOperation.equals(GET_ELEMENT_FUNCTION))
        {
          String name = (String) params;
          returnObj = getEstructuralElement( name );
        }
        else if (strOperation.equals(GET_TOP_ELEMENTS_FUNCTION))
        {
          returnObj =  getTopLevelElements();
        }
        else if (strOperation.equals(COLLECT_CAS_FUNCTION))
        {
          returnObj =  collectCAs();
        }
        else if (strOperation.equals(GET_LAST_UPDATED_FUNCTION))
        {
          returnObj =  getLastUpdated();
        }
        else
        {
          pkiva.log.LogManager.getLogger(this.getClass()).error("Invalid request to execute. Function not supported: " + strOperation);
          throw new ResourceException( "Invalid request to execute. Function not supported: " + strOperation);
        }

      return returnObj;
    }

    // PKIVA Specific methods:
    protected EstructuralElement getEstructuralElement( String name ) throws ResourceException
    {
      try
      {
        return LDAPManager.getInstance().getEstructuralElement( name );
      }
      catch(Exception e)
      {
        pkiva.log.LogManager.getLogger(this.getClass()).error("Top level.LDAPManager getEstructuralElement", e);
        // javax.resource.ResourceException does not support chained Exceptions
        throw new ResourceException("Error in LDAPManager getEstructuralElement." + e.getMessage());
      }
    }

    protected Collection getTopLevelElements( ) throws ResourceException
    {
      try
      {
        return LDAPManager.getInstance().getTopLevelElements( );
      }
      catch(Exception e)
      {
        pkiva.log.LogManager.getLogger(this.getClass()).error("Top level.LDAPManager getTopLevelElements", e);
        // javax.resource.ResourceException does not support chained Exceptions
        throw new ResourceException("Error in LDAPManager getTopLevelElements." + e.getMessage());
      }
    }

    protected Collection collectCAs( ) throws ResourceException
    {
      try
      {
        return LDAPManager.getInstance().collectCAs( );
      }
      catch(Exception e)
      {
        pkiva.log.LogManager.getLogger(this.getClass()).error("Top level.LDAPManager collectCAs", e);
        // javax.resource.ResourceException does not support chained Exceptions
        throw new ResourceException("Error in LDAPManager collectCAs." + e.getMessage());
      }
    }

    protected Date getLastUpdated( ) throws ResourceException
    {
      try
      {
        return LDAPManager.getInstance().getLastUpdated( );
      }
      catch(Exception e)
      {
        pkiva.log.LogManager.getLogger(this.getClass()).error("Top level.LDAPManager getLastUpdated", e);
        // javax.resource.ResourceException does not support chained Exceptions
        throw new ResourceException("Error in LDAPManager getLastUpdated." + e.getMessage());
      }
    }

    protected void loadData() throws ResourceException
    {
      try
      {
        LDAPManager.getInstance().loadData( );
      }
      catch(Exception e)
      {
        pkiva.log.LogManager.getLogger(this.getClass()).error("Top level.LDAPManager loadData", e);
        // javax.resource.ResourceException does not support chained Exceptions
        throw new ResourceException("Error in LDAPManager loadData." + e.getMessage());
      }
    }


}

package pkiva.validation.ocsp;

import java.net.*;
import java.io.*;
import java.util.*;
import java.security.cert.*;
import java.security.*;
import org.bouncycastle.ocsp.*;

import pkiva.exceptions.*;
import pkiva.validation.ocsp.connectors.*;

public class OCSPManager
{ //Singleton
  
  static private OCSPManager m_instance = new OCSPManager();
  
  static public OCSPManager instance()
  {
    return m_instance;
  }
  
  protected OCSPManager()
  {
  }
  
  /**
   * find out the validation from an *<b>incomplete</b>* certificate chain.
   * if chain is revoked, throws OCSPRevokedChainException 
   * in case a server error happens, throws OCSPServerException with error status
   * in case another error happens, throws OCSPValidationException with detail message
   */
  public OCSPValidationResponse validate( X509Certificate[] chain ) throws CertPathValidatorException
  {
    try
    {
      if ( ( chain == null ) || ( chain.length == 0 ) )
      {
        throw new OCSPValidationException( new IllegalArgumentException( "Can't validate an empty chain") );
      }
      /*if ( chain.length == 1 )
      {
        throw new OCSPValidationException( new IllegalArgumentException( "Can't validate chain with only one cert") );
      }*/
      pkiva.log.LogManager.getLogger(this.getClass()).debug("Validamos via OCSP cadena de longitud::" + chain.length);
      // chain.length >= 1

      OCSPConnectionData ocspConData = new OCSPConnectionData ( chain );
      
      X509Certificate signcert = ocspConData.getSignCert( );// certificado para firmar
      PrivateKey signkey = null;
      pkiva.log.LogManager.getLogger(this.getClass()).debug("certificado para firmar::" + signcert);
      if ( signcert == null )
      {
        // if there is no alias, don't sign request
        //throw new OCSPValidationException( new IllegalArgumentException( "Can't get sign cert") );
      }
      else
      {
        signkey = ocspConData.getSignKey( ); // clave del certificado para firmar
        pkiva.log.LogManager.getLogger(this.getClass()).debug("clave del certificado para firmar::" + signkey);
        if ( signkey == null )
          // if there is no alias, don't sign request
          //throw new OCSPValidationException( new IllegalArgumentException( "Can't get sign key") );
          signcert = null;
      }

      String url = ocspConData.getURL( );
      pkiva.log.LogManager.getLogger(this.getClass()).debug("URL::" + url);
      if ( url == null )
        throw new OCSPValidationException( new IllegalArgumentException( "Can't get url string") );
      
      String signingAlgorithm = ocspConData.getSigningAlgorithm( );
      pkiva.log.LogManager.getLogger(this.getClass()).debug("signingAlgorithm::" + signingAlgorithm);
      if ( signingAlgorithm == null )
        throw new OCSPValidationException( new IllegalArgumentException( "Can't get signingAlgorithm") );
      
      String provider = ocspConData.getProvider( );
      pkiva.log.LogManager.getLogger(this.getClass()).debug("provider::" + provider);
      if ( provider == null )
        throw new OCSPValidationException( new IllegalArgumentException( "Can't get provider") );
      
      X509Certificate ocspCert = ocspConData.getResponderCert( );
      pkiva.log.LogManager.getLogger(this.getClass()).debug("certificado del OCSP responder::" + ocspCert);
      if ( ocspCert == null )
        throw new OCSPValidationException( new IllegalArgumentException( "Can't get OCSP Responder cert") );
      //ocspValResp.setOCSPCert ( ocspCert );

      OCSPClient ocspClient = new OCSPClient ( chain );
      byte[] requestData = ocspClient.generateRequest(signcert, signkey, signingAlgorithm, provider);
      
      byte[] ocsprespdata = doRequest(requestData, url);

      StringBuffer msg = new StringBuffer ("OCSP Response from [");
      msg.append(url).append("] for Certificate [");
      msg.append(chain[0].getIssuerDN().getName()).append("-").append(chain[0].getSerialNumber()).append("]:\n");
      msg.append(new String(ocsprespdata));
      String msgSt = msg.toString();
      pkiva.log.LogManager.getLogger(this.getClass()).info(msgSt);
      //pkiva.log.AuditManager.getAuditer(this.getClass()).audit(msgSt);

      OCSPResp resp = new OCSPResp(ocsprespdata);
      //ocspValResp.setOCSPData ( ocspData );
      
      int respStatus = resp.getStatus();
      pkiva.log.LogManager.getLogger(this.getClass()).debug("Codigo de respuesta del servidor OCSP::" + respStatus);
      checkServerStatus( respStatus );
      
      RespData respData = checkResponse( resp, ocspCert, provider );
      pkiva.log.LogManager.getLogger(this.getClass()).debug("La respuesta del servidor OCSP es correcta");
      
      SingleResp [] responses = respData.getResponses();
      if (responses==null)
        throw new OCSPValidationException("La respuesta del OCSP no contiene certificados de cliente");
      pkiva.log.LogManager.getLogger(this.getClass()).debug("Numero de respuestas simples del servidor OCSP ::" + responses.length);
      //if (responses.length != (chain.length - 1) ) // quitamos el trustAnchor
      if (responses.length != (chain.length) ) // ya no quitamos el trustAnchor
        throw new OCSPValidationException("El numero de certificados en la respuesta del OCSP no es igual a los de la petici?n");
      
      OCSPValidationInfo ocspInfo = ocspClient.checkChainStatus( responses, ocsprespdata, ocspCert );

      OCSPValidationResponse ocspValResp = new OCSPValidationResponse( OCSPValidationResponse.OK );
      ocspValResp.setInfo ( ocspInfo );

      return ocspValResp;
    }
    // Cambios en el lanzamiento de exceptions (Ver el problema en PKIXMasterCertPathValidator.java:116)
//    catch (  OCSPServerException e )
//    {
//      pkiva.log.LogManager.getLogger(this.getClass()).error("Server Error validating chain via OCSP", e);
//      throw e;
//    }
//    catch ( CertificateChainRevocationException e )
//    {
//      pkiva.log.LogManager.getLogger(this.getClass()).info("Revoked chain via OCSP");
//      throw e;
//    }
//    catch ( OCSPValidationException ve )
//    {
//      pkiva.log.LogManager.getLogger(this.getClass()).error("Internal Error validating chain via OCSP", ve);
//      throw ve;
//    }
    catch (  OCSPServerException e )
    {
      pkiva.log.LogManager.getLogger(this.getClass()).error("Server Error validating chain via OCSP", e);
      throw new CertPathValidatorException(e.getMessage(), e);
    }
    catch ( CertificateChainRevocationException e )
    {
      pkiva.log.LogManager.getLogger(this.getClass()).info("Revoked chain via OCSP");
      throw new CertPathValidatorException(e.getMessage(), e);
    }
    catch ( OCSPValidationException e )
    {
      pkiva.log.LogManager.getLogger(this.getClass()).error("Internal Error validating chain via OCSP", e);
      throw new CertPathValidatorException(e.getMessage(), e);
    }
    catch ( Throwable t )
    {
      pkiva.log.LogManager.getLogger(this.getClass()).error("Internal Error validating chain via OCSP", t);
      OCSPValidationException e = new OCSPValidationException( "Internal Error validating chain via OCSP", t );
      throw new CertPathValidatorException(e.getMessage(), e);
    }
  }
  
   