package com.gargoylesoftware.base.resource.jdbc;

import com.gargoylesoftware.base.resource.ManagedResource;
import com.gargoylesoftware.base.resource.ResourceException;
import com.gargoylesoftware.base.resource.ResourceFactory;
import com.gargoylesoftware.base.resource.ResourceManager;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *  A ResourceFactory for JDBC connections
 *
 * @version  $Revision: 1.6 $
 * @author <a href="mailto:mbowler@GargoyleSoftware.com">Mike Bowler</a>
 */
public class JDBCResourceFactory extends ResourceFactory {

    private final String databaseName_;
    private final String userName_;
    private final String password_;


    /**
     *  Create the factory. The database driver must have been registered prior
     *  to creating an instance of this class. This constructor will always try
     *  to allocate one connection right away to ensure that the database
     *  information was entered correctly.
     *
     * @param  databaseName The name of the database
     * @param  userName The user id that we will use to connect to the database
     * @param  password The password for the specified user
     * @exception  SQLException If an error occurs
     */
    public JDBCResourceFactory(
            final String databaseName,
            final String userName,
            final String password )
        throws
            SQLException {
        this( databaseName, userName, password, true );
    }


    /**
     *  Create the factory. The database driver must have been registered prior
     *  to creating an instance of this class.
     *
     * @param  databaseName The name of the database
     * @param  userName The user id that we will use to connect to the database
     * @param  password The password for the specified user
     * @param  verifyThatConnectionCanBeOpened If true than one connection will
     *      be immediately allocated and then freed from the specified database
     * @exception  SQLException If an error occurs
     */
    public JDBCResourceFactory(
            final String databaseName,
            final String userName,
            final String password,
            final boolean verifyThatConnectionCanBeOpened )
        throws
            SQLException {

        if( databaseName == null ) {
            throw new NullPointerException( "databaseName" );
        }
        if( userName == null ) {
            throw new NullPointerException( "userName" );
        }
        if( password == null ) {
            throw new NullPointerException( "password" );
        }

        databaseName_ = databaseName;
        userName_ = userName;
        password_ = password;

        if( verifyThatConnectionCanBeOpened == true ) {
            ensureDatabaseCanBeOpened();
        }
    }


    /**
     *  Reinitialize the resource to a known state. This is required for
     *  resource pooling as all resources being returned from a pool must have
     *  been initialized to a known state.
     *
     * @param  resource the resource to reinitialize
     * @return  true if the resource was successfully reinitialized
     */
    public boolean reinitializeResourceIfPossible(
            ManagedResource resource ) {
        final ConnectionWrapper wrapper = ( ConnectionWrapper )resource;

        boolean result = false;

        try {
            if( wrapper.isClosed() == false ) {
                result = true;

                wrapper.commit();
                wrapper.setAutoCommit( true );
                wrapper.closeAnyOpenStatements();
                wrapper.closeAnyOpenMetaDatas();
            }
        }
        catch( final SQLException e ) {
            // If any errors occurred then we can't return it to the pool
            result = false;
        }

        return result;
    }


    /**
     *  Allocate a resource for the specified store
     *
     * @param  resourceManager The resource manager that owns this factory
     * @return  The new resource
     * @exception  Exception If an error occurs
     */
    protected ManagedResource getResourceImpl(
            final ResourceManager resourceManager )
        throws
            Exception {

        return new ConnectionWrapper(
                DriverManager.getConnection( databaseName_, userName_, password_ ) );
    }


    /**
     *  Release the specified resource. It must have been allocated by the
     *  specified store
     *
     * @param  resource The resource that we are releasing
     * @param  resourceManager The manager that is controlling this factory
     * @exception  Exception If an error occurs
     */
    protected void releaseResourceImpl(
            final ResourceManager resourceManager,
            final ManagedResource resource )
        throws
            Exception {

        final ConnectionWrapper wrapper = ( ConnectionWrapper )resource;
        if( wrapper.isClosed() == false ) {
            wrapper.close();
        }
    }


    /**
     *  Allocate a real database connection from the DriverManager
     *
     * @param  databaseName The name of the database
     * @param  userName The user id that we will use to connect to the database
     * @param  password The password for the specified user
     * @return  A new connection
     * @exception  SQLException If an error occurs
     */
    protected final Connection allocateRealConnection(
            final String databaseName,
            final String userName,
            final String password )
        throws
            SQLException {

        return DriverManager.getConnection( databaseName, userName, password );
    }


    /**
     *  Free a real database connection
     *
     * @param  connection The connection to release
     * @exception  SQLException If an error occurs
     */
    protected final void freeRealConnection(
            final Connection connection )
        throws
            SQLException {

        connection.close();
    }


    private void ensureDatabaseCanBeOpened()
        throws SQLException {

        final ResourceManager resourceManager = new ResourceManager( "EnsureDatabaseCanBeOpened" );
        try {
            final ConnectionWrapper connection = ( ConnectionWrapper )getResource( resourceManager );
            releaseResource( resourceManager, connection );
        }
        catch( final ResourceException e ) {
            final Throwable enclosedException = e.getEnclosedException();
            if( enclosedException instanceof SQLException ) {
                throw ( SQLException )enclosedException;
            }

            throw e;
        }
    }
}
