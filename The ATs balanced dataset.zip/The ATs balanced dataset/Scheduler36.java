public void start()
    {
        status = THREAD_STARTED;
        startTime = new Date();

        executionThread = new Thread(this);
        executionThread.setPriority(priority);
        executionThread.start();
    }

    /**
     * Stop the job
     */
    public synchronized void stop()
    {
        executionThread = null;
        notify();
        endTime = new Date();
        status = THREAD_STOPPED;
    }

    /**
     * Ssuspend the job.
     */
    public synchronized void suspend()
    {
        status = THREAD_SUSPENDED;
        log.debug("suspended");
    }

    /**
     * Restart the job.
     */
    public synchronized void resume()
    {
        status = THREAD_STARTED;
        notifyAll();
        log.debug("resumed");
    }

    /**
     * This method allows the user to set the Thread priority of this
     * controllable object. Possible priorities are: a) Thread.NORM_PRIORITY, b)
     * Thread.MAX_PRIORITY c) Thread.MIN_PRIORITY The default priority is
     * Thread.NORM_PRIORITY.
     */
    public void setPriority(int priority)
    {
        this.priority = priority;
    }

    /**
     * This method allows the user to set the interval between each thread loop.
     * Default is 10 (0.001 seconds);
     */
    public void setInterval(int interval)
    {
        this.interval = interval;
    }

    /**
     * Set the UnitisedProcess for this UnitisedProcess
     */
    public void setProcess(com.explosion.utilities.process.threads.Process process)
    {
        this.process = (UnitisedProcess) process;
    }

    /**
     * Gets the process for this UnitisedProcess
     */
    public com.explosion.utilities.process.threads.Process getProcess()
    {
        return process;
    }

    /**
     * This method returns the actual thread object upon which this Runnable
     * object is operating.
     */
    public Thread getRunThread()
    {
        return thisThread;
    }

    /**
     * This method returns status of the thread
     */
    public int getStatus()
    {
        return status;
    }

    /**
     * Kills the job
     */
    public void kill()
    {
        stop();
        wasKilled = true;
    }

    /**
     * Returns whether or not the job was killed
     */
    public boolean wasKilled()
    {
        return wasKilled;
    }

    /**
     * Returns a boolean value indicating whther this is a userThread or not
     * @return
     */
    public boolean isUserThread()
    {
        return this.isUserProcess;
    }
    
    /**
     * Sets whtether or not this is a user process.  True means that it is
     * @param truth
     */
    public void setUserThread(boolean truth)
    {
        this.isUserProcess = true;
    }
import java.util.Date;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.explosion.utilities.process.ProcessMonitor;
/**
 * This class provides a simple way to control processes.  IE start stop etc.
 * It provides very simple logic too; the run method does the following
 * 
 * 1) process.initialise
 * 2) while alive or not finished, process.process()
 * 3) process.finalise
 * 
 * @author Stephen
 * Created on 26-Jun-2004
 */
public class SimpleProcessThread implements ProcessThread
{
    private static Logger log = LogManager.getLogger(SimpleProcessThread.class);

    /* Thread controls */
    private int interval = 10;

    private int priority = Thread.NORM_PRIORITY;

    private Thread executionThread;

    private Thread thisThread;

    /* Control elements */
    private boolean finalised = false;

    private com.explosion.utilities.process.threads.SimpleProcess process;

    private Date startTime = null;

    private Date endTime = null;

    private int status = THREAD_NOT_YET_STARTED;

    private boolean wasKilled = false;
    
    private boolean join = false;
    
    /**
     * For an explanation on implementing safely stoppable and suspendable
     * threads please see
     * 
     * @see http://java.sun.com/products/jdk/1.2/docs/guide/misc/threadPrimitiveDeprecation.html
     */
    public void run()
    {
        try
        {
            thisThread = Thread.currentThread();
            
            checkSuspended();

            if (process == null)
            {
               log.warn("No process specified, exiting simple process control.");
               return;
            }
            
            ProcessMonitor.registerProcess(this, process.isUserProcess());
            
            process.initialise();

            checkSuspended();

            /* Perform processing */
            while (executionThread == thisThread && process.getPercentComplete() < 100)
            {
                checkSuspended();
                if (status == THREAD_STOPPED) break;

                process.process();

                checkSuspended();
                if (status == THREAD_STOPPED) break;

                /* Sleep for required interval */
                try
                {
                    if (interval > 0) Thread.sleep(interval);
                } catch (InterruptedException e)
                {}
            }

            process.finalise();
        } catch (Exception ex)
        {
            if (process != null)
                process.finalise(ex);
        }

        try {
			stop();
		} catch (InterruptedException e) {
			//ignore
			log.error("Interrupted",e);
		}

        /* Set the status to completed */
        status = THREAD_COMPLETED;
    }

    /**
     * Performs suspend logic if the thread has been suspended
     */
    public void checkSuspended()
    {
        /* Suspend if required */
        if (status == THREAD_SUSPENDED)
        {
            synchronized (this)
            {
                while (status == THREAD_SUSPENDED && executionThread == thisThread)
                {
                    try
                    {
                        wait();
                    } catch (InterruptedException e)
                    {}
                }
            }
        }
    }

    /**
     * Starts the job.  If join has been specified then this method will not return until the job has finished.
     */
    public void start()
    {
        status = THREAD_STARTED;
        startTime = new Date();

        executionThread = new Thread(this);
        executionThread.setPriority(priority);
        executionThread.start();
        
        try
        {
            if (join)
                executionThread.join();
        }
        catch (InterruptedException e)
        {
        }
    }
    
    /**
     * This parameter needs to be set before the process is started.  If set to true, the 
     * process will call thread.join and will not return from the start method until the run thread is finished.
     * @param join
     */
    public void setJoin(boolean join)
    {
        this.join = join;
    }
    

    /**
     * Stop the job
     */
    public synchronized void stop() throws InterruptedException
    {
        if (!(status == THREAD_STOPPED))
        {
            executionThread = null;
            notify();
            endTime = new Date();
            status = THREAD_STOPPED;
        }
        
        process.kill();
        
        thisThread.interrupt();
        if (executionThread != null)
           executionThread.interrupt();
        
        if (executionThread != null && executionThread.isAlive())
        {
        	executionThread.stop();
        }
    }

    /**
     * Ssuspend the job.
     */
    public synchronized void suspend()
    {
        status = THREAD_SUSPENDED;
    }

    /**
     * Restart the job.
     */
    public synchronized void resume()
    {
        status = THREAD_STARTED;
        notifyAll();
    }

    /**
     * This method allows the user to set the Thread priority of this
     * controllable object. Possible priorities are: a) Thread.NORM_PRIORITY, b)
     * Thread.MAX_PRIORITY c) Thread.MIN_PRIORITY The default priority is
     * Thread.NORM_PRIORITY.
     */
    public void setPriority(int priority)
    {
        this.priority = priority;
    }

    /**
     * This method allows the user to set the interval between each thread loop.
     * Default is 10 (0.001 seconds);
     */
    public void setInterval(int interval)
    {
        this.interval = interval;
    }

    /**
     * Set the UnitisedProcess for this UnitisedProcess
     */
    public void setProcess(com.explosion.utilities.process.threads.Process process)
    {
        this.process = (SimpleProcess) process;
    }

    /**
     * Gets the process for this UnitisedProcess
     */
    public com.explosion.utilities.process.threads.Process getProcess()
    {
        return process;
    }

    /**
     * This method returns the actual thread object upon which this Runnable
     * object is operating.
     */
    public Thread getRunThread()
    {
        return thisThread;
    }

    /**
     * This method returns status of the thread
     */
    public int getStatus()
    {
        return status;
    }

    /**
     * Kills the job
     */
    public void kill()
    {
        try {
			stop();
		} catch (InterruptedException e) {
			//ignore
			log.error("Interrupted",e);
		}
        wasKilled = true;
    }

    /**
     * Returns whether or not the job was killed
     */
    public boolean wasKilled()
    {
        return wasKilled;
    }

}

private int interval = 10;

    private int priority = Thread.NORM_PRIORITY;

    private Thread executionThread;

    private Thread thisThread;

    /* Control elements */
    private boolean finalised = false;

    private com.explosion.utilities.process.threads.UnitisedProcess process;

    private Date startTime = null;

    private Date endTime = null;

    private int status = THREAD_NOT_YET_STARTED;

    private boolean wasKilled = false;

    private boolean isUserProcess = false;
    
    /**
     * For an explanation on implementing safely stoppable and suspendable
     * threads please see
     * 
     * @see http://java.sun.com/products/jdk/1.2/docs/guide/misc/threadPrimitiveDeprecation.html
     */
    public void run()
    {
        try
        {
            thisThread = Thread.currentThread();
            
            ProcessMonitor.registerProcess(this, isUserProcess);
            
            checkSuspended();

            process.initialiseProcessing();

            checkSuspended();

            /* Perform processing */
            stop: while (executionThread == thisThread && process.getPercentComplete() < 100)
            {
                checkSuspended();
                if (status == THREAD_STOPPED) break;

                /* Perform a ProcessingUnit */
                process.beginProcessUnit();

                checkSuspended();
                if (status == THREAD_STOPPED) break;

                while (!process.processUnitComplete())
                {
                    checkSuspended();
                    if (status == THREAD_STOPPED) continue stop;

                    process.processUnit();

                    checkSuspended();
                    if (status == THREAD_STOPPED) continue stop;
                }

                process.endProcessUnit();
                checkSuspended();
                if (status == THREAD_STOPPED) break;

                /* Sleep for required interval */
                try
                {
                    if (interval > 0) Thread.sleep(interval);
                } catch (InterruptedException e)
                {}
            }

            process.finaliseProcessing();
        } catch (Exception ex)
        {
            process.finaliseProcessing(ex);
        }

        /* Set the status to completed */
        status = THREAD_COMPLETED;
    }

    /**
     * Performs suspend logic if the thread has been suspended
     */
    public void checkSuspended()
    {
        /* Suspend if required */
        if (status == THREAD_SUSPENDED)
        {
            synchronized (this)
            {
                while (status == THREAD_SUSPENDED && executionThread == thisThread)
                {
                    try
                    {
                        wait();
                    } catch (InterruptedException e)
                    {}
                }
            }
        }
    }

    /**
     * Starts the job.
     */
    public void start()
    {
        status = THREAD_STARTED;
        startTime = new Date();

        executionThread = new Thread(this);
        executionThread.setPriority(priority);
        executionThread.start();
    }

    /**
     * Stop the job
     */
    public synchronized void stop()
    {
        executionThread = null;
        notify();
        endTime = new Date();
        status = THREAD_STOPPED;
    }

    /**
     * Ssuspend the job.
     */
    public synchronized void suspend()
    {
        status = THREAD_SUSPENDED;
        log.debug("suspended");
    }

    /**
     * Restart the job.
     */
    public synchronized void resume()
    {
        status = THREAD_STARTED;
        notifyAll();
        log.debug("resumed");
    }

    /**
     * This method allows the user to set the Thread priority of this
     * controllable object. Possible priorities are: a) Thread.NORM_PRIORITY, b)
     * Thread.MAX_PRIORITY c) Thread.MIN_PRIORITY The default priority is
     * Thread.NORM_PRIORITY.
     */
    public void setPriority(int priority)
    {
        this.priority = priority;
    }

    /**
     * This method allows the user to set the interval between each thread loop.
     * Default is 10 (0.001 seconds);
     */
    public void setInterval(int interval)
    {
        this.interval = interval;
    }

    /**
     * Set the UnitisedProcess for this UnitisedProcess
     */
    public void setProcess(com.explosion.utilities.process.threads.Process process)
    {
        this.process = (UnitisedProcess) process;
    }

    /**
     * Gets the process for this UnitisedProcess
     */
    public com.explosion.utilities.process.threads.Process getProcess()
    {
        return process;
    }

    /**
     * This method returns the actual thread object upon which this Runnable
     * object is operating.
     */
    public Thread getRunThread()
    {
        return thisThread;
    }

    /**
     * This method returns status of the thread
     */
    public int getStatus()
    {
        return status;
    }

    /**
     * Kills the job
     */
    public void kill()
    {
        stop();
        wasKilled = true;
    }

    /**
     * Returns whether or not the job was killed
     */
    public boolean wasKilled()
    {
        return wasKilled;
    }

    /**
     * Returns a boolean value indicating whther this is a userThread or not
     * @return
     */
    public boolean isUserThread()
    {
        return this.isUserProcess;
    }
    
    /**
     * Sets whtether or not this is a user process.  True means that it is
     * @param truth
     */
    public void setUserThread(boolean truth)
    {
        this.isUserProcess = true;
    }
