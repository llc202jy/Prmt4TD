 * Insert the method's description here.
 * @param table thera.formats.Table
 */
protected void lockTable(Table table)
{
	String stmt = dbspec.lock() + table.x_table + dbspec.lockExclusive();
	doUpd(stmt);
}
/**
 * perform method comment.
 */
public synchronized void perform()
{
	log("log.service", "Service invoked.");
	if (mode.equals(M_NEXTPAGE))
	{
		performNextpage();
		return;
	}
	verifyAccessible();
	thera.formats.Table table = getRequestAsTable();
	table.setMode(mode);
	String stmt = verifyString(table.format(), "Formatted statement");
	if (mode.equals(M_SELECT))
	{
		ResultSet rs = doSel(stmt);
		table.unformat(rs);
	} else if (mode.equals(M_INSERT) && table.x_keytype.equals("auto"))
		performAutoKeyInsert(table, stmt);
	else
	{
		performUpdate(stmt);
		if ((table instanceof thera.formats.MultiRowTable) && mode.equals(M_DELETE))
			 ((thera.formats.MultiRowTable) table).deleteMap();
	}
}
/**
 * Insert the method's description here.
 * @param table thera.formats.Table
 * @param stmt java.lang.String
 */
protected void performAutoKeyInsert(Table table, String stmt) {
	int autocmt = -1;
	try {
		if (con.getAutoCommit()) {
			autocmt = 1;
			con.setAutoCommit(false);
		}
		else
			autocmt = 0;
	}
	catch (SQLException se1) {
	}
	lockTable(table);
	try {
		performUpdate(stmt);
		Table readkey = table.getReadAutoKeyFormat();
		readkey.setMode(M_SELECT);
		String selID = verifyString(readkey.format(), "Formatted statement");
		ResultSet rs = doSel(selID);
		readkey.unformat(rs);
	}
	finally {
		unlockTable(table);
		try {
			if (1 == autocmt)
				con.setAutoCommit(true);
		}
		catch (SQLException se2) {
		}
	}
}
/**
 * Insert the method's description here.
 */
protected void performNextpage()
{
	if (!(getRequest() instanceof thera.formats.MultiRowTable))
		throw new TheraRuntimeException(
			"Request must be MultiRowTable in NEXTPAGE mode, but was: "
				+ Verify.getHint(getRequest()), 
			this); 
	((thera.formats.MultiRowTable) getRequest()).nextPage();
package thera.framework;

/**
 * A single item of data (ie. a variable). <p>
 * The value is of type <code>Object</code>.
 * @author Ivo Maixner
 */
public class DataItem extends Data
{
	protected Object x_value;
/**
 * No args constructor is called by the externalizer.
 */
public DataItem()
{
	this(null, null);
}
/**
 * Parametrized constructor to be called from user code.<p>
 * Constructs <code>DataItem</code> with the given name and
 * <code>null</code> value.
 */
public DataItem(String name)
{
	this(name, null);
}
/**
 * Parametrized constructor to be called from user code. <p>
 * Constructs <code>DataItem</code> with the given name and value.
 */
public DataItem(String name, Object value)
{
	super(name);
	this.x_value = value;
}
/**
 * Clears the <code>DataItem</code>. <p>
 * Sets the <code>value</code> to empty String.
 */
public void clear()
{
	x_value = "";
}
/**
 * Returns the value as <code>double</code>.
 * @return int
 */
public double getDoubleValue()
{
	verifyNotNull(x_value, "Value not set");
	if (x_value instanceof Double)
		return ((Double) x_value).doubleValue();
	if (x_value instanceof Float)
		return ((Float) x_value).floatValue();
	if (x_value instanceof Integer)
		return ((Integer) x_value).doubleValue();
	if (x_value instanceof String)
		return Double.valueOf((String) x_value).doubleValue();
	throw new TheraRuntimeException(
		"Not a double compatible value: " + x_value.getClass(), 
		this); 
}
/**
 * Returns the value as <code>int</code>.
 * @return int
 */
public int getIntValue()
{
	verifyNotNull(x_value, "Value not set");
	if (x_value instanceof Integer)
		return ((Integer) x_value).intValue();
	if (x_value instanceof Short)
		return ((Short) x_value).intValue();
	if (x_value instanceof Byte)
		return ((Byte) x_value).intValue();
	if (x_value instanceof String)
		return verifyInteger((String) x_value, "Value");
	throw new TheraRuntimeException(
		"Not an int compatible value: " + x_value.getClass(), 
		this); 
}
/**
 * Returns <code>null</code> because a <code>DataItem</code>
 * does not hold any child <code>Data</code>.
 */
public Data getSubData(String name)
{
	return null;
}
/**
 * Returns the value.
 * @return java.lang.Object
 */
public Object getValue()
{
	return x_value;
}
/**
 * Sets the value as <code>double</code>.
 * @param newValue double
 */
public void setValue(double newValue)
{
	x_value = new Double(newValue);
}
/**
 * Sets the value as <code>int</code>.
 * @param newValue int
 */
public void setValue(int newValue)
{
	x_value = new Integer(newValue);
}
/**
 * Sets the value.
 * @param newValue java.lang.Object
 */
public void setValue(Object newValue)
{
	x_value = newValue;
}
/**
 * A default String representation of <code>DataItem</code>.<p>
 * Adds the value to the result of the superclass.
 * @return java.lang.String
 */
public String toString()
{
	return super.toString() + ", value = " + getValue();
}
}
