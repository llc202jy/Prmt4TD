/**
 * Returns a name path of a given <code>XElement</code> in the dot
 * naming convention.
 * @return java.lang.String
 * @param elem extern.XElement
 */
public String getNamePath(XElement elem)
{
	String path = elem.getAttribute("name");
	XElement parent = elem.getParent();
	if (null != parent && null != parent.getAttribute("name"))
		path = getNamePath(parent) + "." + path;
	return path;
}
/**
 * Returns the root <code>Context</code> of the current configuration.
 * @return Context
 */
public Context getRootContext()
{
	return ctxRoot;
}
/**
 * Inits the static contexts. This in turn starts all servers in
 * the static contexts and therefore initiates execution of the application.
 */
public void init() {
	if (null == ctxRoot)
		throw new TheraRuntimeException("Externalizer not loaded.", null);
	ctxRoot.init();
}
/**
 * Supports <code>Context</code> linking.<p>
 * Used to find a common parent <code>Context</code> of two 
 * <code>Context</code>s.<p>
 * Searches up the context tree of the <code>current</code> argument
 * for a <code>Context</code> with name path given in 
 * <code>parentFullName</code> argument.
 * @return thera.framework.Context
 * @param current thera.framework.Context
 * @param parentFullName java.lang.String
 */
protected Context matchToCurrentCtx(Context current, String parentFullName)
{
	Context ctx = current;
	while (ctx.isDynamic())
	{
		if (parentFullName.equals(ctx.getPath()))
			return ctx;
		ctx = ctx.getParent();
	}
	return null;
}
}
/**
 * Sets the decorated <code>Format</code>.
 * @param newDecorated Format
 */
public void setDecorated(Format newDecorated)
{
	decorated = newDecorated;
}
/**
 * Forms an XElement that reflects this instance,
 * adds support for the decorated.
 */
public XElement toXElement()
{
	XElement elem = super.toXElement();
	elem.addChild(decorated.toXElement());
	return elem;
}
/**
 * Insert the method's description here.
 * @param data java.lang.Object
 */
public void unformatDB(Object data)
{



package thera.formats;

import thera.data.DataMap;
import thera.data.DataVector;
import thera.framework.*;
/**
 * Insert the type's description here.
 * @author: Ivo Maixner
 */
public class DetailTable extends MultiRowTable {
	public String x_detailvector, x_detailindex;
	public static final Class detailindex_TYPE = DataItem.class;
	private DataVector detailVector = null;
/**
 * DetailTable constructor comment.
 */
public DetailTable() {
	super();
}
/**
 * DetailTable constructor comment.
 * @param name java.lang.String
 * @param table java.lang.String
 * @param keytype java.lang.String
 * @param vector java.lang.String
 * @param pageSize int
 * @param index java.lang.String
 */
public DetailTable(
	String name,
	String table,
	String keytype,
	String vector,
	int pageSize,
	String index,
	String detailIndex,
	String detailVector) 
{
	super(name, table, keytype, vector, pageSize, index);
	x_detailindex = detailIndex;
	x_detailvector = detailVector;
}
/**
 * Insert the method's description here.
 * @return int
 */
public int getIndex()
{
	return getDataItemSafely(x_detailindex, "Detail index").getIntValue();
}
/**
 * Insert the method's description here.
 * @return thera.framework.DataVector
 */
public DataVector getMasterVector() {
	return super.getVector();
}
/**
 * Insert the method's description here.
 * @return thera.framework.DataVector
 */
public synchronized DataVector getVector() {
	if (null == detailVector) {
		int masterindex = getDataItemSafely(x_index, "Index").getIntValue();
		String name = x_vector + "." + masterindex;
		DataMap map = (DataMap) getDataSafely(name, name, DataMap.class);
		Data detvec = map.getChild(x_detailvector);
		if (null == detvec) {
			detailVector = new DataVector(x_detailvector);
			map.addChild(detailVector);
		}
		else if (detvec instanceof DataVector) {
			detailVector = (DataVector) detvec;
		}
		else
			throw new TheraRuntimeException("Not a DataVector", detvec);
	}
	return detailVector;
}
/**
 * Insert the method's description here.
 * @param child thera.framework.Format
 */
protected void prepareSearchChild(Format child)
{
	if (child instanceof DynamicFormat)
	{
		DynamicFormat dynchild = (DynamicFormat) child;
		String base = getMasterVector().getFullName() + "." + super.getIndex();
		dynchild.setDatanameBase(base, true);
	}
}
/**
 * Insert the method's description here.
 */
protected void resetVector() {
	super.resetVector();
	detailVector = null;
}
}
