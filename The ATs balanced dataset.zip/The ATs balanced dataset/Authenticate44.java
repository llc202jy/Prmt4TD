package net.global_village.kerberos;


import junit.framework.TestCase;

import com.dstc.security.kerberos.Kerberos;



/*
 * Test the KerberosAuthenticator functionality.  This is not in the 
 * net.global_village.kerberos.test package as it needs package access to the 
 * net.global_village.kerberos.KerberosAuthenticator class.
 *
 * @author Copyright (c) 2001-2005  Global Village Consulting, Inc.  All rights reserved.
 * This software is published under the terms of the Educational Community License (ECL) version 1.0,
 * a copy of which has been included with this distribution in the LICENSE.TXT file.
 */
public class KerberosAuthenticatorTest extends TestCase
{
    static protected String TestKDCHost = "fill me in";
    static protected String TestRealm =  "fill me in";
    static protected String TestValidUserID = "fill me in";
    static protected String TestValidPassword = "fill me in";
    static protected String TestInvalidUserID = "chillatgvc";
    static protected String TestInvalidPassword = "ScoobySnack";

    protected KerberosAuthenticator testKerberosAuthenticator;


    public KerberosAuthenticatorTest(String name)
    {
        super(name);
    }



    /**
     * Sets up the fixtures.
     */
    public void setUp() throws java.lang.Exception
    {
        super.setUp();
        // KerberosAuthenticator.setDebugMode(true);
        testKerberosAuthenticator = new KerberosAuthenticator(TestKDCHost, TestRealm);
    }



    /**
     * Test methods related to using KerberosAuthenticator as a singleton.
     */
    public void testSingleton()
    {
        try
        {
            KerberosAuthenticator.getInstance();
            fail("getInstance() called before createInstance() but no DBC exception raised");
        } catch (Throwable t) {}

        try
        {
            KerberosAuthenticator.createInstance(null, TestRealm);
            fail("No DBC exception raised for null kdcHost");
        } catch (Throwable t) {}

        try
        {
            KerberosAuthenticator.createInstance(TestKDCHost, null);
            fail("No DBC exception raised for null realm");
        } catch (Throwable t) {}

        try
        {
            KerberosAuthenticator.createInstance("invalid.global-village.net", TestRealm);
            fail("No DBC exception raised invalid kdcHost");
        } catch (Throwable t) {}

        try
        {
            assertTrue(java.net.InetAddress.getByName(TestKDCHost).equals(testKerberosAuthenticator.keyDistributionCenter));
            assertTrue(TestRealm.equals(testKerberosAuthenticator.realm));
        }
        catch (Throwable t)
        {
            // Something unexpected happened.
            fail(t.toString());
        }
    }



    /**
     * Test the constructor
     */
    public void testConstructor()
    {
        try
        {
            new KerberosAuthenticator(null, TestRealm);
            fail("No DBC exception raised for null kdcHost");
        } catch (Throwable t) {}

        try
        {
            new KerberosAuthenticator(TestKDCHost, null);
            fail("No DBC exception raised for null realm");
        } catch (Throwable t) {}

        try
        {
            new KerberosAuthenticator("invalid.global-village.net", TestRealm);
            fail("No DBC exception raised invalid kdcHost");
        } catch (Throwable t) {}

        try
        {
            assertTrue(java.net.InetAddress.getByName(TestKDCHost).equals(testKerberosAuthenticator.keyDistributionCenter));
            assertTrue(TestRealm.equals(testKerberosAuthenticator.realm));
        }
        catch (Throwable t)
        {
            // Something unexpected happened.
            fail(t.toString());
        }
    }



    /**
     * Test credential method for authenticating
     */
    public void testCredential()
    {
        try
        {
            testKerberosAuthenticator.credential(null, TestValidPassword);
            fail("No DBC exception raised for null userID");
        } catch (Throwable t) {}

        try
        {
            testKerberosAuthenticator.credential(TestValidUserID, null);
            fail("No DBC exception raised for null password");
        } catch (Throwable t) {}

        assertTrue(testKerberosAuthenticator.credential(TestValidUserID, TestValidPassword) != null);
        assertTrue(testKerberosAuthenticator.credential(TestValidUserID, TestInvalidPassword) == null);
        assertTrue(testKerberosAuthenticator.credential(TestInvalidUserID, TestValidPassword) == null);
        assertTrue(testKerberosAuthenticator.credential(TestInvalidUserID, TestInvalidPassword) == null);
    }


    
    /**
     * Test canAuthenticate method for authenticating
     */
    public void testCanAuthenticate()
    {
        try
        {
            testKerberosAuthenticator.canAuthenticate(null, TestValidPassword);
            fail("No DBC exception raised for null userID");
        } catch (Throwable t) {}

        try
        {
            testKerberosAuthenticator.canAuthenticate(TestValidUserID, null);
            fail("No DBC exception raised for null password");
        } catch (Throwable t) {}

        assertTrue(testKerberosAuthenticator.canAuthenticate(TestValidUserID, TestValidPassword));
        assertTrue( ! testKerberosAuthenticator.canAuthenticate(TestValidUserID, TestInvalidPassword));
        assertTrue( ! testKerberosAuthenticator.canAuthenticate(TestInvalidUserID, TestValidPassword));
        assertTrue( !testKerberosAuthenticator.canAuthenticate(TestInvalidUserID, TestInvalidPassword));
    }



    /**
     * Tests the encryptionType(String) and encryptionTypes() methods
     */
    public void testEncryptionType()
    {
        try
        {
            KerberosAuthenticator.encryptionType(null);
            fail("No DBC exception raised for null encryptionTypeName");
        } catch (Throwable t) {}

        try
        {
            KerberosAuthenticator.encryptionType("scooby.doo");
            fail("No DBC exception raised for invalid encryptionTypeName");
        } catch (Throwable t) {}

        // Test the lazy creation dictionary
        assertTrue(KerberosAuthenticator.encryptionTypes() != null);

        // Test the known types.
        assertTrue(KerberosAuthenticator.encryptionType("des-cbc-crc") == Kerberos.DES_CBC_CRC);
        assertTrue(KerberosAuthenticator.encryptionType("des-cbc-md4") == Kerberos.DES_CBC_MD4);
        assertTrue(KerberosAuthenticator.encryptionType("des-cbc-md5") == Kerberos.DES_CBC_MD5);
        assertTrue(KerberosAuthenticator.encryptionType("des3-hmac-sha1") == Kerberos.DES3_CBC_HMAC_SHA1_KD);
        assertTrue(KerberosAuthenticator.encryptionType("rc4-hmac") == Kerberos.RC4_HMAC);
    }
  
    
}
 public WOActionResults displayDataAccessFileAction()
    {
        WOActionResults displayFilePage = null;

        String siteID      = (String)RequestUtils.cleanedFormValueForKey(request(), SMActionURLFactory.SITE_KEY);
        String sectionName = (String)RequestUtils.cleanedFormValueForKey(request(), SMActionURLFactory.SECTION_KEY);
        String recordID    = (String)RequestUtils.cleanedFormValueForKey(request(), SMActionURLFactory.RECORD_ID_KEY);
        String columnName  = (String)RequestUtils.cleanedFormValueForKey(request(), SMActionURLFactory.COLUMN_NAME_KEY);

        // Handle missing parameters.
        if ((siteID == null) || (sectionName == null)  || (recordID == null)  || (columnName == null) )
        {
            displayFilePage = SectionDisplay.invalidParametersError(context());
        }
        else
        {
            Website site = Website.websiteForSiteID(siteID, session().defaultEditingContext());

            // Handle reference to site that does not exist.
            if (site == null)
            {
                displayFilePage = SectionDisplay.noSuchSiteError(siteID, context());
            }
            else
            {
                sectionName = URLUtils.toLowerAndNormalize(sectionName);
                Section section = site.sectionForNormalizedName(sectionName);
                Session theSession = (Session) session();

                // Handle reference to Section that does not exist.
                if (section == null)
                {
                    displayFilePage = SectionDisplay.noSuchSectionError(siteID, sectionName, context());
                }
                // Handle http request for file requiring https 
                else if (section.requiresSSLConnection() && 
                         ! RequestUtils.isHTTPSRequest(request()))
                {
                    DebugOut.println(2, "Insecure request for secure data access file, redirecting");
                    displayFilePage = pageWithName("WORedirect");
                    ((WORedirect)displayFilePage).setUrl(SMActionURLFactory.secureProtocol() +
                        RequestUtils.hostNameFromRequest(request()) + 
                        RequestUtils.originalURLFromRequest(request()));
                }
                // Handle wrong Section type
                else if ( ! (section.type() instanceof DataAccessSectionType))
                {
                    displayFilePage = SectionDisplay.dataAccessFileURLError(sectionName + " is not a Data Access section.", context());
                }
                // Handle authenticated user without permission to view Section
                else if (theSession.isUserAuthenticated() && ! section.isViewableByUser(theSession.currentUser())) 
                {
                    displayFilePage = SectionDisplay.dataAccessFileURLError("You do not have permission to view data in that section.",
                                                                            context());
                }
                // Handle unauthenticated user without permission to view Section by forcing to log in
                else if ((! theSession.isUserAuthenticated()) && ! section.isViewableByUser(theSession.currentUser())) 
                {
                    displayFilePage = SMAuthComponent.redirectToLogin(context(), "Authentication is required to access this File.");
                }
                else
                {
                    // At this point we have a valid Website and Section, a not null recordID and columnName, and we know that the user has permission to view the contents of this section.
                    VirtualRow row;

                    try
                    {
                        Integer rowPK = new Integer(recordID);
                        row = (VirtualRow) ((DataAccess)section.component()).databaseTable().objectWithPrimaryKey(rowPK);
                        com.gvcsitemaker.core.pagecomponent.DataAccessSearchMode searchMode = (com.gvcsitemaker.core.pagecomponent.DataAccessSearchMode)((DataAccess)section.component()).componentForMode(com.gvcsitemaker.core.pagecomponent.DataAccessMode.SEARCH_MODE);

                        if ((((DataAccess)section.component()).restrictToDefaultResults()) && ( ! searchMode.storedSearchRowsWithParameters(new DataAccessParameters(context(), (DataAccess)section.component())).containsObject(row)))
                        {
                            displayFilePage = SectionDisplay.dataAccessFileURLError("You do not have permission to view the record holding that file.", context());
                        }
                        // Handle incorrect column name
                        else if ( ! row.hasColumnNamed(columnName))
                        {
                            displayFilePage = SectionDisplay.dataAccessFileURLError("There is no field named " + columnName + " in that section.", context());
                        }
                        // Handle a column that is not visible in Single or List mode
                        else if ( ! ((DataAccess)section.component()).isColumnVisible(columnName))
                        {
                            displayFilePage = SectionDisplay.dataAccessFileURLError("You do not have permission to view the field holding that file.", context());
                        }
                        else
                        {
                            Object file = row.valueForFieldNamed(columnName);

                            // Handle missing VirtualSiteFileField or missing SiteFile
                            if (file == null)
                            {
                                displayFilePage = noSuchFileError(siteID, columnName);
                            }
                            // Handle incorrect field type
                            else if ( ! (file instanceof SiteFile))
                            {
                                displayFilePage = SectionDisplay.dataAccessFileURLError("The field named " + columnName + " does not contain a file.", context());
                            }
                            else
                            {
                                DebugOut.println(10,"Got site: " + site.banner().bannerText());
                                DebugOut.println(10,"Got section: " + sectionName);
                                DebugOut.println(10,"Got file: " + ((SiteFile)file).uploadedFilename());

                                // Everything is OK, display the file.
                                displayFilePage = pageWithName("DisplayFile");
                                ((DisplayFile)displayFilePage).setFile((SiteFile) file);

                                // Use the access override as we have already checked Section permission.  There is no file level permissions in database tables.
                                ((DisplayFile)displayFilePage).setAuthOverride(true);
                            }
                        }
                    }
                    // Handle missing row.
                    catch (com.webobjects.eoaccess.EOObjectNotAvailableException e)
                    {
                        displayFilePage = SectionDisplay.dataAccessFileURLError("The record holding that file has been deleted.", context());
                    }
                }
            }
        }

        return displayFilePage;
        
        /** ensure [valid_result] Result != null;  **/
    }

