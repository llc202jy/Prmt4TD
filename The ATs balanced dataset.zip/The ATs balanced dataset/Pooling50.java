public class OutlineView {
	private Composite parent;

	private Control pageControl;

	private IEclipseContext pageContext;

	@Inject
	public OutlineView(Composite parent) {
		this.parent = parent;
	}

	@Inject
	public void setActivePart(
			@Optional @Named(IServiceConstants.ACTIVE_PART) MPart activePart) {
		if (parent.isDisposed()) {
			return;
		}
		IEclipseContext oldPageContext = pageContext;
		Control oldPageControl = pageControl;

		if (activePart != null) {
			if (activePart.getObject() instanceof IOutlinePageProvider) {
				pageContext = activePart.getContext().createChild();
				Composite comp = new Composite(parent, SWT.NONE);
				comp.setLayout(new FillLayout());
				pageControl = comp;
				pageContext.set(Composite.class, comp);
				ContextInjectionFactory.make(((IOutlinePageProvider) activePart
						.getObject()).getOutlineClass(), pageContext);
			} else {
				oldPageContext = null;
				oldPageControl = null;
			}
		} else {
			Label label = new Label(parent, SWT.NONE);
			label.setText("No outline available");
			pageControl = label;
		}
		
		// Dispose afterwards which helps potential image resource pooling
		if (oldPageContext != null) {
			oldPageContext.dispose();
		}

		if (oldPageControl != null) {
			oldPageControl.dispose();
		}
		
		parent.layout(true, true);
	}
}