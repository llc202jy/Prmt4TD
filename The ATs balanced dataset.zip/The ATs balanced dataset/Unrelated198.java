    }     
    
	/**
	 * Call the given domain object's dao update method
	 * @param obj Domain Object to update
	 */    
    public static void update(Object obj) {
	   	BaseServiceManager manager = (BaseServiceManager)getManager(obj);
	   	manager.update(obj);    	
    }     
   
	/**
	 * Call the given domain object's dao add method
	 * @param obj Domain Object to add
	 */    
   public static void add(Object obj) {
	   	BaseServiceManager manager = (BaseServiceManager)getManager(obj);
	   	manager.add(obj);     	
   }
   
	/**
	 * Call the given domain object's dao print method
	 * @param obj Domain Object to print
	 */   
   public static void print(Object obj) {
	   	BaseServiceManager manager = (BaseServiceManager)getManager(obj);
	   	manager.print(obj);         
   }    
   
	/**
	 * Call the given domain class's get method
	 * @param clazz
	 * @param id
	 */   
   public static Object get(Class clazz, Integer id)  {
	   	BaseServiceManager manager = (BaseServiceManager)getManager(clazz);
	   	return manager.get(id);
   }     
   
   /**
    * Call the given domain class's getCount method
    * @param clazz
    * @param info
    * @return <tt>Integer</tt> count returned
    */
   public static Integer getCount(Class clazz, ValueListInfo info)  {
	   	BaseServiceManager manager = (BaseServiceManager)getManager(clazz);
	   	return manager.getCount(info);
   }      
   
   /**
    * Searches for the given object's class by given property. If doesn't exist, creates it, adds it and returns it
    * @param obj 
    * @param prop Property to search by
    * @return Existing or newly created/added object
    */
   public static Object getOrAdd(Object obj, String prop) {
       Object existing = getBy(OAClassUtil.getPersistentClass(obj), prop, (OABeanUtil.getPropertyValue(obj, prop)).toString());
       if (existing != null)
           return existing;

       add(obj);
	   return obj;
   } 	
   
   //---------------------------------------------------------------------------------------------------------
   
	public static Boolean canDelete(Object obj) {
		BaseServiceManager manager = (BaseServiceManager)getManager(obj);
		return manager.canDelete(obj);
	}
	
	public static Boolean canEdit(Object obj) {
		BaseServiceManager manager = (BaseServiceManager)getManager(obj);
		return manager.canEdit(obj);
	}
	
	public static Boolean canEditLimited(Object obj) {
		BaseServiceManager manager = (BaseServiceManager)getManager(obj);
		return manager.canEditLimited(obj);		
	}	   
    
   //---------------------------------------------------------------------------------------------------------
	
	public static void setStatus(Object obj, Integer newStatus) {
		BaseServiceManager manager = (BaseServiceManager)getManager(obj);
		manager.setStatus(obj, newStatus);
	}
	
	public static void setStatus(Object obj, Object newStatus) {
		BaseServiceManager manager = (BaseServiceManager)getManager(obj);
		manager.setStatus(obj, newStatus);
	}	
	
	public static List getPossibleStatuses(Object obj) {
		BaseServiceManager manager = (BaseServiceManager)getManager(obj);
		return manager.getPossibleStatuses(obj);
	}		
	
   //---------------------------------------------------------------------------------------------------------
	
	public static void updateCalculatedProperties(Object obj) {
		BaseServiceManager manager = (BaseServiceManager)getManager(obj);
		manager.updateCalculatedProperties(obj);
	}	
	
	public static void handlePropertyChange(Object obj, String property) {
		BaseServiceManager manager = (BaseServiceManager)getManager(obj);
		manager.handlePropertyChange(obj, property);
	}		
	
   //---------------------------------------------------------------------------------------------------------	
	
	private static Object getManager(Object obj) {
        return getManager(OAClassUtil.getPersistentClass(obj));
    }	
	
	private static Object getManager(Class clazz) {
        return getManager(OAStringUtil.getSimpleClassName(clazz));
    }
    
    private static Object getManager(String clazzName) {
        return OAServiceUtil.getBean(clazzName + "Manager");
    }    
    
/*     private static Object simpleManagerCall(Object obj, String methodName, Class paramType, Object param) {
         return simpleManagerCall(OAClassUtil.getPersistentClass(obj), methodName, paramType, param);
     }
     
     private static Object simpleManagerCall(Class clazz, String methodName, Class paramType, Object param) {
        Class[] paramTypes = {paramType};
        Object[] params = {param};
        Object manager = getManager(clazz);     	
        try {  
            Method method = manager.getClass().getMethod(methodName, paramTypes);
            return method.invoke(manager, params);                
        } 
        catch (Exception e) {
            if (e.getCause() != null)
                throw new OAJNestedException(e.getCause());
            throw new OAJNestedException(e);                
        }    
     }*/
     
     //---------------------------------------------------------------------------------------------------------     
     
    public static List getAll(Class clazz, ValueListInfo info) {
        if (info == null)
            info = new ValueListInfo();    
        BaseServiceManager manager = (BaseServiceManager)getManager(clazz);
        return listFromValueList((ValueList)manager.find(info));        
    }
    
    public static List getAll(Class clazz) {
    	return getAll(clazz, null);
    }
    
    public static boolean isDuplicate(Class clazz, String prop, Object value, Integer id) {
        ValueListInfo info = new ValueListInfo();
        info.addFilterNamedParam(prop,Op.EQUALS,value.toString());
        if (id != null)
        	info.addFilterNamedParam(OABeanUtil.ID_FIELD,Op.NOTEQUALS,id.toString());
        info.setLimit(1);        
        
        Integer count = getCount(clazz, info);

        return (count != null && count.intValue() > 0);
    }    
    
    public static Object getBy(Class clazz, ValueListInfo info) {
    	List all = getAll(clazz, info);

        if (all.size()>0)
            return all.get(0);
        return null;        
    	
    }
     
    public static Object getBy(Class clazz, String prop, String value) {
        ValueListInfo info = new ValueListInfo();
        info.addFilterNamedParam(prop, Op.EQUALS, value);
        info.setLimit(1);     
        return getBy(clazz, info);
    }
    
    public static Object getByName(Class clazz, String name) {
        return getBy(clazz, OABeanUtil.NAME_FIELD, name);
    }
    
    public static Object getByRef(Class clazz, String ref) {
        return getBy(clazz, OABeanUtil.REF_FIELD, ref);
    }    
    
    public static Integer getByRefLike(Class clazz, String ref) {
        ValueListInfo info = new ValueListInfo();
        info.addFilterNamedParam(OABeanUtil.REF_FIELD, Op.LIKE, ref);
        info.addProperty(OABeanUtil.ID_FIELD);
        info.setLimit(1);        
        
        List all = getAll(clazz, info);

        if (all.size()>0)
            return (Integer)all.get(0);
        return null;     	
    }
    
    public static Object getById(Class clazz, Integer id) {
        return getBy(clazz, OABeanUtil.ID_FIELD, id.toString());
    }       
    
    // NEXT AND PREVIOUS OBJECTS
    
    public static Integer getPrevId(Class clazz, Integer id) {
        ValueListInfo info = new ValueListInfo();
        info.addProperty(OABeanUtil.ID_FIELD);
        info.addFilterNamedParam(OABeanUtil.ID_FIELD, Op.LESS, id.toString());
        info.addSortColumn(OABeanUtil.ID_FIELD, ColumnSort.DESC);
        info.setLimit(1);
        
        List all = getAll(clazz, info);

        if (all.size()>0)
            return (Integer)all.get(0);

        return null;  
    }
