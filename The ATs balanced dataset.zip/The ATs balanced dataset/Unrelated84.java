public class PreparedStatement implements java.sql.PreparedStatement,ProxyjConstant {

    private java.sql.PreparedStatement[] realStatement=null;
    
    private java.sql.Connection[] realConn=null ;
    
    private CNode cnode=null;
    
    private boolean isQuery=false;
    
    public java.sql.PreparedStatement[] returnRealStatement(){
        return realStatement;
    }
    
    public java.sql.Connection[] returnRealConn(){
        return realConn;
    }
    
    public CNode returnCNode(){
        return cnode;
    }
    
    public void assignCNode(CNode cnode){
        this.cnode=cnode;
    }
    
    public void makeQuery(){
        isQuery=true;
    }
    
    public void initAA(){
        isQuery=false;
        realConn=new java.sql.Connection[2];
        realStatement=new java.sql.PreparedStatement[2];
        if(cnode.getDbnodes1().getStatus()==STATE_READY){
            realConn[0]=ConnectionManager.getConnection(cnode.getDbnodes1().getPoolName());
            //realStatement[0]=realConn[0].prepareStatement();
            Logger.logDebug(this, " realConn[0] "+ realConn[0]);
        }  
        if(cnode.getDbnodes2().getStatus()==STATE_READY){
            realConn[1]=ConnectionManager.getConnection(cnode.getDbnodes2().getPoolName());
            Logger.logDebug(this, " realConn[1] "+ realConn[1]);
            //realStatement[0]=realConn[0].prepareStatement();
        }                        
    }
    
    public void initAS(){
        isQuery=false;
        realConn=new java.sql.Connection[2];
        realStatement=new java.sql.PreparedStatement[2];
        if(cnode.getDbnodes1().getStatus()==STATE_READY){
            realConn[0]=ConnectionManager.getConnection(cnode.getDbnodes1().getPoolName());
            //realStatement[0]=realConn[0].prepareStatement();
            Logger.logDebug(this, " realConn[0] "+ realConn[0]);
        }  
        if(cnode.getDbnodes2().getStatus()==STATE_READY){
            realConn[1]=ConnectionManager.getConnection(cnode.getDbnodes2().getPoolName());
            Logger.logDebug(this, " realConn[1] "+ realConn[0]);
            //realStatement[0]=realConn[0].prepareStatement();
        }                        
    }
    
    public void prepareStatement(String sql)
    	throws SQLException{
        if(realConn[0]!=null){           
            realStatement[0]=realConn[0].prepareStatement(sql);
        }  
        if(realConn[1]!=null){              
            realStatement[1]=realConn[1].prepareStatement(sql);
        }    
    }
    
    public void prepareStatement(String sql, int[] columnIndex)
    	throws SQLException{
        if(realConn[0]!=null){           
            realStatement[0]=realConn[0].prepareStatement(sql, columnIndex);
        }  
        if(realConn[1]!=null){              
            realStatement[1]=realConn[1].prepareStatement(sql, columnIndex);
        }    
    }
    
    public void prepareStatement(String sql, String[] columnNames)
    	throws SQLException{
        if(realConn[0]!=null){           
            realStatement[0]=realConn[0].prepareStatement(sql, columnNames);
        }  
        if(realConn[1]!=null){              
            realStatement[1]=realConn[1].prepareStatement(sql, columnNames);
        }    
    }
    
    //private int[] status=new int[]{STATE_FAILED,STATE_FAILED};	
    
    public void setRealConn(Connection[] realConn){
        this.realConn=realConn;
    }
    
    public void setRealStatement(PreparedStatement[] realStatement){
        this.realStatement=realStatement;
    }
    
    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#executeUpdate()
     */
    public int executeUpdate() throws SQLException {
        if(realStatement[0]!=null){   
            if(cnode.getSelectMode()==1){
                if(cnode.getDbnodes1().getStatus()==STATE_READY && 
                        cnode.getDbnodes2().getStatus()==STATE_READY ){
                    realStatement[1].executeUpdate();
                    return realStatement[0].executeUpdate();
                }else if(cnode.getDbnodes1().getStatus()==STATE_READY && 
                        cnode.getDbnodes2().getStatus()!=STATE_READY ){
                    //add callback later
                    return realStatement[0].executeUpdate();
                }else if(cnode.getDbnodes1().getStatus()!=STATE_READY && 
                        cnode.getDbnodes2().getStatus()==STATE_READY ){
                   	//add callback later
                    return realStatement[1].executeUpdate();
                }else{
                	//add callback later
                }
            }
        }  
        if(realStatement[1]!=null){   
            if(cnode.getSelectMode()==2){
                if(cnode.getDbnodes2().getStatus()==STATE_READY && 
                        cnode.getDbnodes1().getStatus()==STATE_READY ){
                    realStatement[0].executeUpdate();
                    return realStatement[1].executeUpdate();
                }else if(cnode.getDbnodes2().getStatus()==STATE_READY && 
                        cnode.getDbnodes1().getStatus()!=STATE_READY ){
                    //add callback later
                    return realStatement[1].executeUpdate();
                }else if(cnode.getDbnodes2().getStatus()!=STATE_READY && 
                        cnode.getDbnodes1().getStatus()==STATE_READY ){
                   	//add callback later
                    return realStatement[0].executeUpdate();
                }else{
                	//add callback later
                }
            }
        } 
        return 0;
    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#addBatch()
     */
    public void addBatch() throws SQLException {
        if(realStatement[0]!=null){   
            realStatement[0].addBatch();
        }  
        if(realStatement[1]!=null){           
            realStatement[1].addBatch();
        }

    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#clearParameters()
     */
    public void clearParameters() throws SQLException {
        if(realStatement[0]!=null){   
            realStatement[0].clearParameters();
        }  
        if(realStatement[1]!=null){           
            realStatement[1].clearParameters();
        }

    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#execute()
     */
    public boolean execute() throws SQLException {
        if(realStatement[0]!=null){   
            if(cnode.getSelectMode()==1){
                if(cnode.getDbnodes1().getStatus()==STATE_READY && 
                        cnode.getDbnodes2().getStatus()==STATE_READY ){
                    realStatement[1].execute();
                    return realStatement[0].execute();
                }else if(cnode.getDbnodes1().getStatus()==STATE_READY && 
                        cnode.getDbnodes2().getStatus()!=STATE_READY ){
                    //add callback later
                    return realStatement[0].execute();
                }else if(cnode.getDbnodes1().getStatus()!=STATE_READY && 
                        cnode.getDbnodes2().getStatus()==STATE_READY ){
                   	//add callback later
                    return realStatement[1].execute();
                }else{
                	//add callback later
                }
            }
        }  
        if(realStatement[1]!=null){   
            if(cnode.getSelectMode()==2){
                if(cnode.getDbnodes2().getStatus()==STATE_READY && 
                        cnode.getDbnodes1().getStatus()==STATE_READY ){
                    realStatement[0].execute();
                    return realStatement[1].execute();
                }else if(cnode.getDbnodes2().getStatus()==STATE_READY && 
                        cnode.getDbnodes1().getStatus()!=STATE_READY ){
                    //add callback later
                    return realStatement[1].execute();
                }else if(cnode.getDbnodes2().getStatus()!=STATE_READY && 
                        cnode.getDbnodes1().getStatus()==STATE_READY ){
                   	//add callback later
                    return realStatement[0].execute();
                }else{
                	//add callback later
                }
            }
        }  
        return false;
    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#setByte(int, byte)
     */
    public void setByte(int parameterIndex, byte x) throws SQLException {
        if(realStatement[0]!=null){           
            realStatement[0].setByte(parameterIndex,x);
        }  
        if(realStatement[1]!=null){           
            realStatement[1].setByte(parameterIndex,x);
        }  

    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#setDouble(int, double)
     */
    public void setDouble(int parameterIndex, double x) throws SQLException {
        if(realStatement[0]!=null){           
            realStatement[0].setDouble(parameterIndex,x);
        }  
        if(realStatement[1]!=null){           
            realStatement[1].setDouble(parameterIndex,x);
        }  

    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#setFloat(int, float)
     */
    public void setFloat(int parameterIndex, float x) throws SQLException {
        if(realStatement[0]!=null){           
            realStatement[0].setFloat(parameterIndex,x);
        }  
        if(realStatement[1]!=null){           
            realStatement[1].setFloat(parameterIndex,x);
        }  

    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#setInt(int, int)
     */
    public void setInt(int parameterIndex, int x) throws SQLException {
        if(realStatement[0]!=null){           
            realStatement[0].setInt(parameterIndex,x);
        }  
        if(realStatement[1]!=null){           
            realStatement[1].setInt(parameterIndex,x);
        }  

    }
/** Created on 2004?~8??17??** TODO To change the template for this generated file go to* Window - Preferences - Java - Code Style - Code Templates*/package org.sparrowcontainer.core.bean.factory;import java.util.HashMap;import java.util.Map;import org.springframework.beans.factory.support.AbstractBeanFactory;import org.springframework.beans.factory.support.DefaultListableBeanFactory;/*** @author Leo** TODO To change the template for this generated type comment go to Window -* Preferences - Java - Code Style - Code Templates*/public class SystemBeanFactory {private static AbstractBeanFactory factory = null;private static Map factoryMap = null;static {factory = new DefaultListableBeanFactory();factoryMap = new HashMap();}public static void setFactory(String factoryName,AbstractBeanFactory _factory) {factoryMap.put(factoryName, _factory);}public static Object getBean(String factoryName, String beanName) {return ((AbstractBeanFactory) factoryMap.get(factoryName)).getBean(beanName);}public static AbstractBeanFactory getFactory(String factoryName) {return (AbstractBeanFactory) factoryMap.get(factoryName);}public static void setFactory(AbstractBeanFactory _factory) {//factory=_factory;factory.setParentBeanFactory(_factory);}public static Object getBean(String name) {return factory.getBean(name);}public static AbstractBeanFactory getFactory() {//factory=_factory;return factory;}}


*
 This package is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License or 
 GNU Lesser General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.
 
 Sparrowcontainer is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License or GNU Lesser General Public License 
 for more details.
 */
package org.sparrowcontainer.network.http.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.sparrowcontainer.network.SocketRequestMessage;
import org.sparrowcontainer.network.SocketResponseMessage;
import org.sparrowcontainer.network.http.HttpException;
import org.sparrowcontainer.network.http.HttpService;
import org.sparrowcontainer.network.http.error.Http400Error;

/**
 * The Http Intercepter to implements your own Http Request. 
 * It support only POST and GET for you to override.  Other than that will fall into service
 * implementation
 * 
 * @author <a href="mailto:leo@sparrowcontainer.org">Leo Chan </a>
 * @version $Revision: 0.1 Alpha $
 */
public abstract class HttpServiceImpl implements HttpService {

    private static Map appCtx = null;

    static {
        appCtx = new HashMap();
    }

    protected Map getApplicationCtx() {
        return appCtx;
    }
    
    /**
     * Provide a common storage for your application Object
     * @param key the key identity of your object for storage
     * @param value the Object to be stored
     *
     */
    protected void setApplicationCtx(Object key, Object value) {
        appCtx.put(key, value);
    }

	/**
     * To return the Object you stored in.
     * @param key the key identity of your object for storage
     * @return Object the object you have been stored
     *
     */
    protected Object getApplicationCtx(Object key) {
        return appCtx.get(key);
    }

	/**
     * To override your own logic and implement HTTP GET here
     * @param req the request Object for the HTTP request
     *@param res the response that you want to be returned for this request
     *
     */
    public void doGet(SocketRequestMessage req, SocketResponseMessage res)
            throws HttpException {
        try {
            res.writeError(Http400Error.getCode());
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

	/**
     * To override your own logic and implement HTTP POST here
     * @param  req the request Object for the HTTP request
     *@param  res the response that you want to be returned for this request
     *
     */
    public void doPost(SocketRequestMessage req, SocketResponseMessage res)
            throws HttpException {
        try {
            res.writeError(Http400Error.getCode());
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
    /**
     * To override your own logic for other HTTP request that is not POST nor GET
     * @param  req the request Object for the HTTP request
     *@param  res the response that you want to be returned for this request
     *
     */

    public void service(SocketRequestMessage req, SocketResponseMessage res)
            throws HttpException {
        try {
            res.writeError(Http400Error.getCode());
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}