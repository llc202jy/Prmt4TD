import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.enhydra.shark.admin.repositorymanagement.RepositoryManager;
import org.enhydra.shark.api.admin.RepositoryMgr;
import org.enhydra.shark.api.admin.UserGroupManagerAdmin;
import org.enhydra.shark.api.client.wfmc.wapi.WMActivityInstance;
import org.enhydra.shark.api.client.wfmc.wapi.WMActivityInstanceIterator;
import org.enhydra.shark.api.client.wfmc.wapi.WMSessionHandle;
import org.enhydra.shark.api.client.wfmodel.WfActivity;
import org.enhydra.shark.api.client.wfmodel.WfAssignment;
import org.enhydra.shark.api.client.wfmodel.WfProcess;
import org.enhydra.shark.api.client.wfmodel.WfProcessMgr;
import org.enhydra.shark.api.client.wfservice.AdminMisc;
import org.enhydra.shark.api.client.wfservice.PackageAdministration;
import org.enhydra.shark.api.client.wfservice.SharkConnection;
import org.enhydra.shark.api.client.wfservice.WMEntity;
import org.enhydra.shark.api.common.SharkConstants;
import org.enhydra.shark.client.utilities.MiscClientUtilities;
import org.enhydra.shark.client.utilities.SharkInterfaceWrapper;
import org.enhydra.shark.utilities.WMEntityUtilities;
import org.enhydra.shark.webclient.spec.SharkParamConsts;
import org.enhydra.shark.webclient.spec.utils.ParamConsts;
import org.enhydra.shark.xpdl.XMLUtil;
import org.w3c.dom.Node;

import com.lutris.appserver.server.ApplicationException;
import com.lutris.util.Config;

public class SharkUtils {

   public static String sharkEdition = null;

   public static String userGroupPlugginName = null;

   public static Map roleMap = null;

   protected static RepositoryMgr repositoryMgr;

   public static RepositoryMgr getRepositoryManager() {
      if (repositoryMgr == null) {
         repositoryMgr = RepositoryManager.getInstance();
      }
      return repositoryMgr;
   }

   public static void init(Config config) {

      // Init Shark Edition

      Class pi = null;
     
      try {
         pi = Class.forName("org.enhydra.shark.ProfInfo");

      } catch (Exception e) {
         pi = null;
      }
      if (pi != null) {
         sharkEdition = SharkParamConsts.SHARK_EDITION_PROFESSIONAL;
         
      } else {
         try {
            pi = Class.forName("org.enhydra.shark.SharkObjectFactoryExt");
         } catch (Exception e) {
            pi = null;
         }
         if (pi != null) {
            sharkEdition = SharkParamConsts.SHARK_EDITION_DEMO;
           
         } else {
            sharkEdition = SharkParamConsts.SHARK_EDITION_COMMUNITY;
           
         }
      }
      try {
         Object ama = SharkInterfaceWrapper.getUserGroupAdmin();
         if (ama != null) {
            if (ama.getClass().getName().indexOf("LDAPUserGroupManagerAdmin") >= 0) {
               userGroupPlugginName = "LDAP";
            } else if (ama.getClass().getName().indexOf("DODSUserGroupManagerAdmin") > 0) {
               userGroupPlugginName = "DODS";
            }
         }
      } catch (Exception e) {

      }
      try {
         // Init role Map

         roleMap = new HashMap();
         String values = null;

         // worklist and processlist
         values = config.getString("SharkWebClient.Security."
                                   + ParamConsts.PROPERTY_PROTECTED_WLH, "none");
         roleMap.put(ParamConsts.PROPERTY_PROTECTED_WLH, values);

         // repository
         values = config.getString("SharkWebClient.Security."
                                   + ParamConsts.PROPERTY_PROTECTED_REPOSITORY, "none");
         roleMap.put(ParamConsts.PROPERTY_PROTECTED_REPOSITORY, values);

         // packagelist
         values = config.getString("SharkWebClient.Security."
                                   + ParamConsts.PROPERTY_PROTECTED_PACKAGE, "none");
         roleMap.put(ParamConsts.PROPERTY_PROTECTED_PACKAGE, values);

         // processinst
         values = config.getString("SharkWebClient.Security."
                                   + ParamConsts.PROPERTY_PROTECTED_PROCESSINST, "none");
         roleMap.put(ParamConsts.PROPERTY_PROTECTED_PROCESSINST, values);

         // processmonitor
         values = config.getString("SharkWebClient.Security."
                                         + ParamConsts.PROPERTY_PROTECTED_PROCESSMONITOR,
                                   "none");
         roleMap.put(ParamConsts.PROPERTY_PROTECTED_PROCESSMONITOR, values);

         // usergroupmanager
         values = config.getString("SharkWebClient.Security."
                                         + ParamConsts.PROPERTY_PROTECTED_USERGROUPMANAG,
                                   "none");

         roleMap.put(ParamConsts.PROPERTY_PROTECTED_USERGROUPMANAG, values);

         // cache
         values = config.getString("SharkWebClient.Security."
                                   + ParamConsts.PROPERTY_PROTECTED_CACHE, "none");

         roleMap.put(ParamConsts.PROPERTY_PROTECTED_CACHE, values);

         // application
         values = config.getString("SharkWebClient.Security."
                                   + ParamConsts.PROPERTY_PROTECTED_APPLICATION, "none");

         roleMap.put(ParamConsts.PROPERTY_PROTECTED_APPLICATION, values);

      } catch (Exception ex) {
      }

      try {
         repositoryMgr = RepositoryManager.getInstance();
         String xpdlRepository = config.getString("SharkWebClient."
                                                  + ParamConsts.PROPERTY_PREFIX_REPOSITORY
                                                  + ".XPDL_repository");
         repositoryMgr.setPathToXPDLRepositoryFolder(xpdlRepository);
      } catch (Exception ex) {
         System.err.println("Repository manager is not configured....");
      }

   }

   public static void uploadPackage(Config appConfig) {
      try {
         String[] packagesToUpload = appConfig.getStrings("SharkWebClient.XPDLS_TO_UPLOAD",null);
         PackageAdministration pa = SharkInterfaceWrapper.getPackageAdministration();
         WMSessionHandle shandle = SharkInterfaceWrapper.getDefaultSessionHandle();
         int i = 0;
         if (packagesToUpload != null) {
            for (i = 0; i < packagesToUpload.length; i++) {
               File cFile = new File(packagesToUpload[i]);
               // if file don't exist, try to resolve relative path
               if (!cFile.exists()) {
                  cFile = new File(appConfig.getConfigFile()
                     .getFile()
                     .getParentFile()
                     .getParentFile()
                     .getCanonicalPath()
                                   + "/" + packagesToUpload[i]);
               }

               if (!cFile.exists()) {
                  throw new ApplicationException("XPDL file "
                                                 + packagesToUpload[i]
                                                 + " does not exist!");
               }
               packagesToUpload[i] = cFile.getCanonicalPath();

               if (!pa.isPackageOpened(shandle,XMLUtil.getIdFromFile(packagesToUpload[i]))) {
                  if (SharkInterfaceWrapper.getClientType().equals("POJO")) {
                     pa.openPackage(shandle, packagesToUpload[i]);
                  } else {
                     File pkgFile = new File(packagesToUpload[i]);
                     RandomAccessFile raf = new RandomAccessFile(pkgFile, "r");
                     byte[] utf8Bytes = null;
                     long noOfBytes = raf.length();
                     if (noOfBytes > 0) {
                        utf8Bytes = new byte[(int) noOfBytes];
                        raf.seek(0);
                        raf.readFully(utf8Bytes);
                     }
                     if (utf8Bytes != null) {
                        SharkInterfaceWrapper.getPackageAdministration()
                           .uploadPackage(shandle, utf8Bytes);
                     }
                  }
               }
            }
         }
      } catch (Exception e) {
         e.printStackTrace();
      }

   }

   public static boolean canSwitchUsers(SharkConnection sc,
                                        String groups,
                                        String userString) {

      boolean isSuperUser = false;
      try {
         UserGroupManagerAdmin ugma = SharkInterfaceWrapper.getUserGroupAdmin();
         if (ugma != null) {
            if (!groups.equalsIgnoreCase("none")) {

               StringTokenizer st = new StringTokenizer(groups, ",");
               if (st.countTokens() > 0) {
                  String group = null;
                  while (st.hasMoreTokens()) {
                     group = st.nextToken();
                     if (ugma.doesGroupExist(sc.getSessionHandle(), group)) {
                        if (ugma.doesUserBelongToGroup(sc.getSessionHandle(),
                                                       group,
                                                       userString)) {
                           isSuperUser = true;
                           break;
                        }
                     }
                  }
               } else if (!groups.equals(new String(""))) {
                  if (ugma.doesGroupExist(sc.getSessionHandle(), groups)) {
                     if (ugma.doesUserBelongToGroup(sc.getSessionHandle(),
                                                    groups,
                                                    userString)) {
                        isSuperUser = true;

                     }
                  }
               } else {
                  isSuperUser = true;
               }
            } else {
               isSuperUser = true;
            }
         } else {
            isSuperUser = true;
         }
      } catch (Exception e) {
         e.printStackTrace();
      }
      return isSuperUser;
   }

   public static void completeActivity(String username, String procId, String actId)
      throws Exception {

      SharkConnection sc = SharkInterfaceWrapper.getSharkConnection(username);
      WfActivity act = sc.getActivity(procId, actId);
      if (act.state().equals(SharkConstants.STATE_OPEN_NOT_RUNNING_NOT_STARTED)) {
         act.change_state(SharkConstants.STATE_OPEN_RUNNING);
      }
      if (!act.state().equals(SharkConstants.STATE_CLOSED_COMPLETED))
         act.complete();
      sc.disconnect();

   }

   public static void updateProcOrActVariablesAndOtherInfo(String username,
                                                           Map procInfo,
                                                           Map actInfo,
                                                           Map vars) throws Exception {

      // System.out.println("PI="+procInfo);
      // System.out.println("AI="+actInfo);
      // System.out.println("VARS="+vars);

      SharkConnection sc = SharkInterfaceWrapper.getSharkConnection(username);
      String procId = (String) procInfo.get("Id");
      String proName = (String) procInfo.get("Name");
      String proDesc = (String) procInfo.get("Description");
      Integer proPri = (Integer) procInfo.get("Priority");
      WfProcess proc = null;
      if (actInfo != null && actInfo.size() > 0) {
         String actId = (String) actInfo.get("Id");
         Integer actPri = (Integer) actInfo.get("Priority");
         String actDesc = (String) actInfo.get("Description");
         String actName = (String) actInfo.get("Name");
         WfActivity act = sc.getActivity(procId, actId);
         if (actName != null) {
            act.set_name(actName);
         }
         if (actDesc != null) {
            act.set_description(actDesc);
         }
         if (actPri != null) {
            act.set_priority(actPri.shortValue());
         }
         filterNonExistingNullVars(vars, act.process_context());
         act.set_result(vars);
         proc = act.container();
      } else {
         proc = sc.getProcess(procId);
      }
      if (proName != null) {
         proc.set_name(proName);
      }
      if (proDesc != null) {
         proc.set_description(proDesc);
      }
      if (proPri != null) {
         proc.set_priority(proPri.shortValue());
      }
      if (actInfo == null || actInfo.size() == 0) {
         filterNonExistingNullVars(vars, proc.process_context());
         proc.set_process_context(vars);
      }
      sc.disconnect();
   }

   public static void filterNonExistingNullVars (Map toUpdate,Map currentVars) throws Exception {
      if (toUpdate!=null && currentVars!=null) {
         Iterator it=toUpdate.entrySet().iterator();
         while (it.hasNext()) {
            Map.Entry me=(Map.Entry)it.next();
            if (me.getValue()==null && !currentVars.containsKey(me.getKey())) {
               it.remove();
            }
         }
      }
   }
   public static void acceptedActivity(String username,
                                       String procId,
                                       String actId,
                                       String accepted) throws Exception {
      SharkConnection sc = SharkInterfaceWrapper.getSharkConnection(username);
      WfActivity act = sc.getActivity(procId, actId);
      if (accepted.equals("false")
          && !act.state().equals(SharkConstants.STATE_OPEN_RUNNING)) {
         act.change_state(SharkConstants.STATE_OPEN_RUNNING);
      } else if (!accepted.equals("false")
                 && !act.state()
                    .equals(SharkConstants.STATE_OPEN_NOT_RUNNING_NOT_STARTED)) {
         act.change_state(SharkConstants.STATE_OPEN_NOT_RUNNING_NOT_STARTED);
      } else if (accepted.equals("")) {
         if (act.state().equals(SharkConstants.STATE_OPEN_RUNNING)) {
            act.change_state(SharkConstants.STATE_OPEN_NOT_RUNNING_NOT_STARTED);
         } else if (act.state().equals(SharkConstants.STATE_OPEN_NOT_RUNNING_NOT_STARTED)) {
            act.change_state(SharkConstants.STATE_OPEN_RUNNING);
         }
      }
      sc.disconnect();
   }

   // if checkFirstActivity is true and the first (manual) activity in the
   // process belongs to the user that started the process, activity's Id is
   // returned
   public static WfActivity createProcess(String username,
                                          String manName,
                                          boolean checkFirstActivity) throws Exception {

      SharkConnection sc = SharkInterfaceWrapper.getSharkConnection(username);
      WfProcessMgr pMan = sc.getProcessMgr(manName);
      WfProcess proc = pMan.create_process(null);
      proc.start();
      sc.disconnect();

      if (checkFirstActivity) {
         return findNextActivity(proc, username);
      }
      return null;
   }

   public static WfActivity findNextActivity(WfProcess proc, String username)
      throws Exception {
      WfActivity[] acts = proc.get_sequence_step(0);
      WfActivity nextAct = null;
      for (int i = 0; i < acts.length; i++) {
         if (acts[i].state().equals(SharkConstants.STATE_OPEN_NOT_RUNNING_NOT_STARTED)) {
            WfAssignment[] ass = acts[i].get_sequence_assignment(0);
            if (ass.length == 0) {
               nextAct = acts[i];
               break;
            }
            for (int j = 0; j < ass.length; j++) {
               if (ass[j].assignee().resource_key().equals(username)) {
                  nextAct = acts[i];
               }
            }
            if (nextAct != null) {
               break;
            }
         }
      }
      return nextAct;
   }

   /**
    * Completes activity and returns true if process is not finished yet.
    */
   public static boolean continueProcess(String username,
                                         String procId,
                                         String actId,
                                         Map vars) throws Exception {
      SharkConnection sc = SharkInterfaceWrapper.getSharkConnection(username);
      WfActivity act = sc.getActivity(procId, actId);
      WfProcess pro = act.container();

      Object nav = vars.get(SharkParamConsts.NAVIGATION_VARIABLE);
      if (nav != null) {
         SharkInterfaceWrapper.getExecutionAdministrationExt()
            .goAnywhere(sc.getSessionHandle(), procId, actId, nav.toString(), MiscClientUtilities.makeWMAttributeArrayContext(vars));
      } else {
         filterNonExistingNullVars(vars, act.process_context());
         act.set_result(vars);

         if (act.state().equals(SharkConstants.STATE_OPEN_NOT_RUNNING_NOT_STARTED)) {
            act.change_state(SharkConstants.STATE_OPEN_RUNNING);
         }
         act.complete();
      }

      boolean running = true;
      if (!pro.state().equals(SharkConstants.STATE_OPEN_RUNNING)) {
         running = false;
      }

      sc.disconnect();

      return running;

   }

   public static boolean isContextUpdated(String username, String procId, String actId)
      throws Exception {

      boolean updated = true;
      SharkConnection sc = SharkInterfaceWrapper.getSharkConnection(username);

      WfActivity act = sc.getActivity(procId, actId);
      Map res = act.result();
      if (res.size() == 0) {
         AdminMisc am = SharkInterfaceWrapper.getAdminMisc();
         WMEntity varEnt = am.getActivityDefinitionInfo(sc.getSessionHandle(),
                                                        procId,
                                                        actId);

         String[][] extAttribs = WMEntityUtilities.getExtAttribNVPairs(sc.getSessionHandle(),
                                                                       SharkInterfaceWrapper.getXPDLBrowser(),
                                                                       varEnt);

         for (int i = 0; i < extAttribs.length; i++) {
            String eaName = extAttribs[i][0];
            if (eaName.equals(SharkParamConsts.EA_VAR_TO_PROCESS_UPDATE)
                || eaName.equals(SharkParamConsts.EA_VAR_TO_PROCESS_FETCH)) {
               updated = false;
               break;
            }
         }
      }
      sc.disconnect();
      return updated;
   }

   /**
    * Check activity extends attributes and retun String[2] array, where 1st element
    * indicates the type of XForms: file definition, class, string or none, and 2nd
    * element respectively represents either file location, full class name, the string
    * representing XForms definition or null in the last case.
    */
   public static String[] getXFormsInfo(String username,
                                        String procId,
                                        String actId,
                                        boolean forVariables) throws Exception {
      SharkConnection sc = SharkInterfaceWrapper.getSharkConnection(username);

      AdminMisc am = SharkInterfaceWrapper.getAdminMisc();

      WMEntity ent = null;
      if (!forVariables || actId != null) {
         ent = am.getActivityDefinitionInfo(sc.getSessionHandle(), procId, actId);
      } else {
         ent = am.getProcessDefinitionInfo(sc.getSessionHandle(), procId);
      }

      String[][] extAttribs = WMEntityUtilities.getExtAttribNVPairs(sc.getSessionHandle(),
                                                                    SharkInterfaceWrapper.getXPDLBrowser(),
                                                                    ent);

      for (int i = 0; i < extAttribs.length; i++) {
         String eaName = extAttribs[i][0];
         String eaVal = extAttribs[i][1];
         boolean found = false;
         if ((forVariables && eaName.equals(SharkParamConsts.EA_XFORMS_FILE_FOR_VARIABLES))
             || (!forVariables && eaName.equals(SharkParamConsts.EA_XFORMS_FILE))) {
            found = true;
         } else if ((forVariables && eaName.equals(SharkParamConsts.EA_XFORMS_XMLC_CLASS_FOR_VARIABLES))
                    || (!forVariables && eaName.equals(SharkParamConsts.EA_XFORMS_XMLC_CLASS))) {
            found = true;
         } else if ((forVariables && eaName.equals(SharkParamConsts.EA_XFORMS_EMBEDED_FOR_VARIABLES))
                    || (!forVariables && eaName.equals(SharkParamConsts.EA_XFORMS_EMBEDED))) {
            found = true;
         } else if (!forVariables && eaName.equals(SharkParamConsts.EA_HTML_VARIABLE)) {
            found = true;
         }
         if (found && !eaVal.trim().equals("")) {
package org.enhydra.shark.webclient.business;

import java.sql.Date;
import java.util.GregorianCalendar;
import org.enhydra.shark.api.client.wfservice.SharkConnection;
import org.enhydra.shark.api.client.wfservice.WMEntity;
import org.enhydra.shark.client.utilities.SharkInterfaceWrapper;
import org.enhydra.shark.utilities.WMEntityUtilities;
import org.enhydra.shark.xpil.XPILExtendedWorkflowFacilityInstanceDocument;
import org.enhydra.shark.xpil.XPILExtendedWorkflowFacilityInstanceDocument.ExtendedWorkflowFacilityInstance;
import org.enhydra.shark.xpil.XPILHeaderDocument.Header;
import org.enhydra.shark.xpil.XPILInstanceExtendedAttributeDocument.InstanceExtendedAttribute;
import org.enhydra.shark.xpil.XPILInstanceExtendedAttributesDocument.InstanceExtendedAttributes;
import org.w3c.dom.Node;

import com.lutris.util.Config;

public class XMLAppMappingBuilder extends XMLBuilderImpl {

   public XMLAppMappingBuilder(String username,
                               Config config,
                               String startElement,
                               String sortCriterion,
                               String sortAsc) {

      this.username = username;
      this.config = config;
      this.from_element = startElement;
      this.sortCriterion = sortCriterion;
      this.sortAsc = sortAsc;

   }

   protected Node fillXMLElements() throws Exception {
      SharkConnection sc = SharkInterfaceWrapper.getSharkConnection(username);

      XPILExtendedWorkflowFacilityInstanceDocument tws = XPILExtendedWorkflowFacilityInstanceDocument.Factory.newInstance();

      tws.addNewExtendedWorkflowFacilityInstance();

      ExtendedWorkflowFacilityInstance ins = tws.getExtendedWorkflowFacilityInstance();
      ins.addNewHeader();
      Header header = tws.getExtendedWorkflowFacilityInstance().getHeader();
      header.setXPILVersion("1.0");
      header.setXPILVendor("Shark");

      GregorianCalendar gC = new GregorianCalendar();
      gC.setTime(new Date(System.currentTimeMillis()));

      header.setCreationTime(gC);

      header.setInstanceDescription("Shark's application mapping");

      int startAt = Integer.parseInt(from_element != null ? from_element : "0");
      from_element = Integer.toString(startAt);
      to_element = Integer.toString(10);
      total_number = Integer.toString(10);

      WMEntity[] wme = WMEntityUtilities.getAllApplications(sc.getSessionHandle(),
                                                            SharkInterfaceWrapper.getXPDLBrowser());

      InstanceExtendedAttributes ies = ins.addNewInstanceExtendedAttributes();
      if (wme != null) {
         for (int i = 0; i < wme.length; i++) {
            InstanceExtendedAttribute ie = ies.addNewInstanceExtendedAttribute();
            ie.setName(wme[i].getId()
                       + ";" + wme[i].getPkgId() + ";" + wme[i].getPkgVer() + ";"
                       + wme[i].getWpId());
            ie.setValue(wme[i].getId()
                        + " [package id: " + wme[i].getPkgId() + ", process def. id: "
                        + wme[i].getWpId() + "]");
         }
      }

      String[][] taMap = SharkInterfaceWrapper.getAdminMisc()
         .getToolAgentsInfo(sc.getSessionHandle());

      InstanceExtendedAttributes iess = ins.addNewInstanceExtendedAttributes();
      for (int i = 0; i < taMap.length; i++) {
         InstanceExtendedAttribute ie1 = iess.addNewInstanceExtendedAttribute();
         ie1.setName(taMap[i][0]);
         ie1.setValue(taMap[i][0]);

      }

      sc.disconnect();

      return tws.getDomNode();
   }

}
