#include "gnats.h"
#include "gnatsd.h"

/* Copy regular file SOURCE onto file DEST.
   Return 1 if an error occurred, 0 if successful. */

int
copy_file (const char *source, const char *dest)
{
  int ifd;
  int ofd;
  char buf[1024 * 8];
  int len;			/* Number of bytes read into `buf'. */
  
  if (unlink (dest) && errno != ENOENT)
    {
      log_msg (LOG_INFO, 1, "cannot remove ", dest);
      return 1;
    }

  ifd = open (source, O_RDONLY, 0);
  if (ifd < 0)
    {
      log_msg (LOG_INFO, 1, "can not open: ", source);
      return 1;
    }
  ofd = open (dest, O_WRONLY | O_CREAT | O_TRUNC, 0600);
  if (ofd < 0)
    {
      log_msg (LOG_INFO, 1, "can not open: ", dest);
      close (ifd);
      return 1;
    }

  while ((len = read (ifd, buf, sizeof (buf))) > 0)
    {
      int wrote = 0;
      char *bp = buf;
      
      do
	{
	  wrote = write (ofd, bp, len);
	  if (wrote < 0)
	    {
	      log_msg (LOG_INFO, 1, "error in writing:", dest);
	      close (ifd);
	      close (ofd);
	      unlink (dest);
	      return 1;
	    }
	  bp += wrote;
	  len -= wrote;
	} while (len > 0);
    }
  if (len < 0)
    {
      log_msg (LOG_INFO, 1, source, strerror(errno));
      close (ifd);
      close (ofd);
      unlink (dest);
      return 1;
    }

  if (close (ifd) < 0)
    {
      log_msg (LOG_INFO, 1, source, strerror(errno));
      close (ofd);
      return 1;
    }
  if (close (ofd) < 0)
    {
      log_msg (LOG_INFO, 1, dest, strerror(errno));
      return 1;
    }

  /* FIXME: This is fine for GNATS, but if there's anything we ever want
     to have special permissions, we must add the code to restore the
     permissions to what they were.  */
  chmod (dest, 0644);
  
  return 0;
}

/* Try to lock the file noted by FP.  */
int
is_gnats_locked (const DatabaseInfo database)
{
  char *path = gnats_adm_dir (database, "gnats.lock");
  int res = fileExists (path);
  free (path);
  return res;
}

int
lock_gnats (const DatabaseInfo database, ErrorDesc *err)
{
  char *path;
  int count, res;
  const int MAXWAIT = 10;
  const int GRANULARITY = 1;

  path = gnats_adm_dir (database, "gnats.lock");


  /* try repeatedly to get the lock */
  for (count = 0; count < MAXWAIT / GRANULARITY; count++)
    {
      errno = 0;
      /* use atomic create, to avoid races */
      if (open (path, O_CREAT | O_TRUNC | O_WRONLY | O_EXCL, 0) != -1)
	{
	  /* success */
	  break;
	}
      else
	{
	  if (errno != EEXIST)
	    {
	      /* something went wrong, error out */
	      break;
	    }
	}
      /* somebody else has the lock, sleep and try again */
      sleep (GRANULARITY);
    }

  if (!errno)
    {
      /* success */
      res = 0;
    }
  else if (errno == EEXIST)
    {
      setError (err, CODE_GNATS_LOCKED,
		"GNATS lock file exists %s", path);
      res = -1;
    }
  else
    {
      setError (err, CODE_FILE_ERROR,
		"GNATS cannot create lock file: %s",
		strerror (errno));
      log_msg(LOG_ERR, 1, "error in lock_gnats:",
	      getErrorMessage (*err));
      res = 1;
    }

  free (path);
  return res;
}


char*
get_lock_path (const DatabaseInfo database, const char *prID)
{
  char *path = NULL;

  if (prID != NULL)
    {
      char *tempname;

      asprintf (&tempname, "locks/%s.lock", prID);
      path = gnats_adm_dir (database, tempname);
      free (tempname);
    }
  return path;
}
