/**
	 * Marks this <code>Runnable</code> to be shutdown and tries to unbind all
	 * remote objects.
	 */
	 package org.ourgrid.mygrid.scheduler;
public class MyGridUIManager extends OurgridUnicastRemoteObject implements UIManager {

	/** Logger (log4j) object to store log events */
	private static transient final org.apache.log4j.Logger LOG = org.apache.log4j.Logger
			.getLogger( MyGridUIManager.class );
**/**
	 * Returns the <code>EBSchedulingHeuristic</code>.
	 * 
	 * @return The <code>EBSchedulingHeuristic</code>
	 */
	public EBSchedulingHeuristic getHeuristic() {

		return this.ebSchedulingHeuristic;
	}package org.ourgrid.mygrid.scheduler;

import java.rmi.RemoteException;
import java.util.Collection;

import org.ourgrid.common.event.Event;
import org.ourgrid.common.event.EventQueue;
import org.ourgrid.common.event.NotifyEvent;
import org.ourgrid.common.event.ResponseEvent;
import org.ourgrid.common.event.ThrowableEvent;
import org.ourgrid.common.rmi.OurgridUnicastRemoteObject;
import org.ourgrid.common.security.MGSecureClientSocketFactory;
import org.ourgrid.common.security.MGSecureServerSocketFactory;
import org.ourgrid.common.spec.GumSpec;
import org.ourgrid.common.spec.JobSpec;
import org.ourgrid.mygrid.scheduler.event.JobCouldNotBeCancelledNotifyEvent;
import org.ourgrid.mygrid.scheduler.event.JobNotFoundNotifyEvent;
import org.ourgrid.mygrid.scheduler.exception.JobCannotBeRemovedException;
import org.ourgrid.mygrid.scheduler.exception.JobCouldNotBeCancelledException;
import org.ourgrid.mygrid.scheduler.exception.JobNotFoundException;
import org.ourgrid.mygrid.scheduler.gridmanager.GridManagerEntry;
import org.ourgrid.mygrid.scheduler.gridmanager.GridManagerListenerRemote;
import org.ourgrid.mygrid.scheduler.jobmanager.JobEntry;
import org.ourgrid.mygrid.scheduler.jobmanager.JobManagerListenerRemote;

/**
 * The <code>Scheduler</code> remote object responsible for receiving RMI
 * calls and translating them to calls on the <code>EBSchedulerFacade</code>.
 */
public class SchedulerImpl extends OurgridUnicastRemoteObject implements Scheduler {

	/**
	 * Serial identification of the class. It need to be changed only if the
	 * class interface is changed.
	 */
	private static final long serialVersionUID = 33L;

	/** The <code>EBSchedulerFacade</code> */
	private EBSchedulerFacade ebSchedulerFacade;


	/**
	 * The constructor.
	 * 
	 * @param ebSchedulerFacade The <code>EBSchedulerFacade</code>
	 */
	protected SchedulerImpl( EBSchedulerFacade ebSchedulerFacade ) throws RemoteException {

		super();
		this.ebSchedulerFacade = ebSchedulerFacade;
	}


	/**
	 * The constructor with SecureSocketFactories.
	 * 
	 * @param ebSchedulerFacade The <code>EBSchedulerFacade</code>
	 * @param secureClientSocketFactory The SecureClientSocketFactory.
	 * @param secureServerSocketFactory The SecureServerSocketFactory.
	 * @param securePort The port where the secure services will be bound.
	 */
	public SchedulerImpl( EBSchedulerFacade ebSchedulerFacade, MGSecureClientSocketFactory secureClientSocketFactory,
							MGSecureServerSocketFactory secureServerSocketFactory, int securePort )
		throws RemoteException {

		super( securePort, secureClientSocketFactory, secureServerSocketFactory );
		this.ebSchedulerFacade = ebSchedulerFacade;
	}


	/**
	 * @see org.ourgrid.mygrid.scheduler.Scheduler#jobList(JobManagerListenerRemote)
	 */
	public Collection<JobEntry> jobList( JobManagerListenerRemote newListener ) throws RemoteException {

		EventQueue<ResponseEvent<Collection<JobEntry>>> responseQueue = ebSchedulerFacade.jobList( newListener );
		ResponseEvent<Collection<JobEntry>> responseEvent = responseQueue.blockingRemove();
		return responseEvent.getResponse();
	}


	/**
	 * @see org.ourgrid.mygrid.scheduler.Scheduler#waitForJob(int)
	 */
	public void waitForJob( int jobId ) throws JobNotFoundException, RemoteException {

		EventQueue responseQueue = ebSchedulerFacade.waitForJob( jobId );
		Event event = responseQueue.blockingRemove();
		if ( event instanceof JobNotFoundNotifyEvent ) {
			throw new JobNotFoundException( jobId );
		}

	}


	/**
	 * @see org.ourgrid.mygrid.scheduler.Scheduler#cancelJob(int)
	 */
	public void cancelJob( int jobId ) throws JobNotFoundException, JobCouldNotBeCancelledException, RemoteException {

		EventQueue<NotifyEvent> responseQueue = ebSchedulerFacade.cancelJob( jobId );
		Event event = responseQueue.blockingRemove();
		if ( event instanceof JobNotFoundNotifyEvent ) {
			throw new JobNotFoundException( jobId );
		} else if ( event instanceof JobCouldNotBeCancelledNotifyEvent ) {
			throw new JobCouldNotBeCancelledException( event.toString() );
		}

	}


	/**
	 * @see org.ourgrid.mygrid.scheduler.Scheduler#addJob(JobSpec)
	 */
	public int addJob( JobSpec jobSpec ) throws RemoteException {

		return ebSchedulerFacade.addJob( jobSpec );
	}


	/**
	 * @see org.ourgrid.mygrid.scheduler.Scheduler#cleanFinishedJobs()
	 */
	public void cleanFinishedJobs() throws RemoteException {

		ebSchedulerFacade.cleanFinishedJobs();
	}


	/**
	 * @see org.ourgrid.mygrid.scheduler.Scheduler#removeJob(int)
	 */
	public void removeJob( int jobId ) throws JobCannotBeRemovedException, RemoteException {

		EventQueue responseQueue = ebSchedulerFacade.removeJob( jobId );
		Event event = responseQueue.blockingRemove();
		if ( event instanceof ThrowableEvent ) {
			throw new JobCannotBeRemovedException();
		}
	}


	public Collection<GridManagerEntry> getGumEntries( GridManagerListenerRemote newListener ) throws RemoteException {

		EventQueue<ResponseEvent<Collection<GridManagerEntry>>> responseQueue = ebSchedulerFacade
				.getGumEntries( newListener );
		ResponseEvent<Collection<GridManagerEntry>> responseEvent = responseQueue.blockingRemove();
		return responseEvent.getResponse();
	}


	public Collection<GumSpec> getGumSpecs() throws RemoteException {

		EventQueue<ResponseEvent<Collection<GumSpec>>> responseQueue = ebSchedulerFacade.getGumSpecs();
		ResponseEvent<Collection<GumSpec>> responseEvent = responseQueue.blockingRemove();
		return responseEvent.getResponse();
	}


	public void removeJobManagerListener( JobManagerListenerRemote listener ) throws RemoteException {

		ebSchedulerFacade.removeJobManagerListener( listener );
	}


	public void removeGridManagerListener( GridManagerListenerRemote listener ) throws RemoteException {

		ebSchedulerFacade.removeGridManagerListener( listener );
	}



	protected EBReplicaExecutorFacade getReplicaExecutorFacade() {

		return ebReplicaExecutorFacade;
	}


	protected boolean schedule( EBSchedulingHeuristic schedulingHeuristic ) {

		return schedulingHeuristic.schedule();
	}

	 * Starts the SchedulerEventEngine <code>Thread</code>.
	 */
	public void startProcessing() {

		this.isAlive = true;
		// Binding the remote objects
		try {
			Naming.rebind( MyGridURLProvider.scheduler(), this.scheduler );
			Naming.rebind( MyGridURLProvider.gumpManager(), this.gumpManager );
			Naming.rebind( MyGridURLProvider.gumpClient(), this.gumpClient );
		} catch ( RemoteException e ) {
			LOG.error( "Error trying to bind remote objects", e );
		} catch ( MalformedURLException e ) {
			LOG.error( "Error trying to bind remote objects. Malformed URL address(es)", e );
		}

		myThread.start();
		LOG.debug( "The SchedulerEventEngine was successfully started." );
	}

/**
	 * Puts an <code>Event</code> in the EventQueue.
	 * 
	 * @param event The <code>Event</code>
	 */
	public void putEvent( ActionEvent event ) {

		eventQueue.put( event );
	}


	/**
	 * Returns the <code>EBJobManager</code>.
	 * 
	 * @return The <code>EBJobManager</code>
	 */
	public JobManager getJobManager() {

		return this.jobManager;
	}


	/**
	 * Returns the <code>EBGridManager</code>.
	 * 
	 * @return The <code>EBGridManager</code>
	 */
	public GridManager getGridManager() {

		return this.ebGridManager;
	}
	private static final long serialVersionUID = 33L;

	private static UIManager uniqueInstance;

	private GumpManager gumpManager;

	private Scheduler scheduler;

	private Notifiable peerStateNotifiable;

	private MyGridFailureDetector failureDetector;

	private EBSchedulerFacade ebSchedulerFacade;

	private EBReplicaExecutorFacade ebReplicaExecutorFacade;


	private MyGridUIManager() throws RemoteException {

		isMyGridRunning();

		try {
			failureDetector = new MyGridFailureDetector( Configuration.QUERY_FREQ );
		} catch ( RemoteException e ) {
			LOG.error( &quot;Error trying to create Failure Detector&quot;, e );
		}

	}


	/**
	 * Resets the singleton.
	 */
	public static synchronized void reset() {

		uniqueInstance = null;
	}


	public static synchronized UIManager getInstance() throws RemoteException {

		if ( uniqueInstance == null ) {

			initRMIRegistry();

			try {
				// tries to get a remote instance already bound by another
				// invocation of this method.
				uniqueInstance = (UIManager) Naming.lookup( MyGridURLProvider.mygridUIManager() );
			} catch ( MalformedURLException e ) {
			} catch ( NotBoundException e ) {
			} catch ( RemoteException e ) {
			}

			if ( uniqueInstance == null ) {

				uniqueInstance = new MyGridUIManager();

				try {
					Naming.rebind( MyGridURLProvider.mygridUIManager(), uniqueInstance );
				} catch ( MalformedURLException e ) {
					LOG.debug( &quot;Error trying to rebind at URL &quot; + MyGridURLProvider.mygridUIManager() );
				}
			}
		}

		return uniqueInstance;

	}


	private static void initRMIRegistry() {

		int registryPort = Integer.parseInt( Configuration.getInstance( Configuration.MYGRID ).getProperty(
				Configuration.PROP_PORT ) );

		System.setProperty( &quot;java.rmi.server.hostname&quot;, Configuration.getInstance().getProperty(
				Configuration.PROP_EXTERNAL_NAME ) );

		try {
			LocateRegistry.createRegistry( registryPort );
		} catch ( RemoteException e ) {
			LOG.debug( &quot;Cannot start RMI registry at port: &quot; + registryPort );
		}

	}


	public void startMyGridService() throws NotExecutingInHomeMachine, MyGridIsAlreadyRunningException,
		StartingMyGridException, ConfigException {

		/**
		 * Security options.
		 */
		if ( Configuration.getInstance().isSecurityEnabled() ) {
			String keyStoreFilename = Configuration.getInstance().getProperty( Configuration.PROP_KEYSTORE_FILENAME );
			String keyStorePassword = Configuration.getInstance().getProperty( Configuration.PROP_KEYSTORE_PASSWORD );

			System.setProperty( &quot;javax.net.ssl.keyStore&quot;, keyStoreFilename );
			System.setProperty( &quot;javax.net.ssl.keyStorePassword&quot;, keyStorePassword );

			String trustStoreFilename = Configuration.getInstance()
					.getProperty( Configuration.PROP_TRUSTSTORE_FILENAME );
			String trustStorePassword = Configuration.getInstance()
					.getProperty( Configuration.PROP_TRUSTSTORE_PASSWORD );

			System.setProperty( &quot;javax.net.ssl.trustStore&quot;, trustStoreFilename );
			System.setProperty( &quot;javax.net.ssl.trustStorePassword&quot;, trustStorePassword );
		}

		if ( !isExecutingInHomeMachine() ) {
			throw new NotExecutingInHomeMachine();
		}

		if ( isMyGridRunning() ) {
			throw new MyGridIsAlreadyRunningException();
		}

		String logfile = Configuration.getInstance().getLogPath();

		Configuration.getInstance().getProperty( MyGridConfiguration.PROP_HEURISTIC );
		boolean ddFile = Configuration.getInstance().isEnabled( MyGridConfiguration.PROP_CACHE_DDFILE );
		try {
			DataDiscovery.initDataDiscovery( ddFile );
		} catch ( DDInitException e ) {
			LOG.error( &quot;Error trying to init Data Discovery&quot;, e );
		}

		String parents = new File( logfile ).getParent();

		if ( parents != null ) {
			new File( parents ).mkdirs();
		}

		/** **** Configuring Log4j ******* */
		String logPropertiesfile = Configuration.getInstance().getLogPropertiesPath();
		LogConfiguration.configure( logPropertiesfile, logfile );

		try {
			// Creating facades
			this.ebSchedulerFacade = new EBSchedulerFacade();
			this.ebReplicaExecutorFacade = new EBReplicaExecutorFacade();

			// Configuring facades
			ebSchedulerFacade.config( ebReplicaExecutorFacade );
			ebReplicaExecutorFacade.config( ebSchedulerFacade );

			// Starting the facades
			ebSchedulerFacade.startEventProcessor();
			ebReplicaExecutorFacade.startEventProcessor();

		} catch ( ConfigException e ) {
			LOG.error( &quot;Error trying to read properties from the MG.properties file&quot;, e );
		} catch ( RemoteException e ) {
			LOG.error( &quot;Error trying to create remote objects&quot;, e );
		}

		if ( isMyGridRunning() ) {
			startFailureDetector();
			LOG.info( UIMessages.MYGRID_IS_UP_AND_RUNNING );
		} else {
			throw new StartingMyGridException();
		}

		loadDefaultGdf();

	}


	private void loadDefaultGdf() {

		String defaultGdf = MyGridConfiguration.getInstance().getProperty( MyGridConfiguration.PROP_DEFAULT_GDF );
		if ( defaultGdf != null ) {

			File defaultSDF = new File( defaultGdf );

			if ( !defaultSDF.exists() ) {
				LOG.info( &quot;OurGrid Peer default SDF not found: &quot; + defaultGdf );
				return;
			}

			try {
				List&lt;PeerSpec&gt; peerSpecs = DescriptionFileCompile.compileGDF( defaultGdf );
				this.setPeers( peerSpecs );
			} catch ( CompilerException e ) {
				LOG.info( &quot;MyGrid could not compile default GDF!&quot; );
			} catch ( RemoteException e ) {
				LOG.info( &quot;MyGrid could not contact UIManager to load default GDF!&quot; );
			}

		}

	}


	private void startFailureDetector() {

		peerStateNotifiable = new PeerStateNotifiable( gumpManager );
		try {

			failureDetector.startMonitoring();
			Naming.rebind( MyGridURLProvider.failureDetector(), failureDetector );

		} catch ( RemoteException e ) {
			LOG.error( &quot;Cannot bind Peer Failure Detector Object.&quot;, e );
		} catch ( MalformedURLException e ) {
			LOG.error( &quot;Cannot bind Peer Failure Detector Object.&quot;, e );
		}
	}


	public void stopMyGridService( boolean wait, boolean callExit ) throws MyGridIsNotRunningException {

		if ( isMyGridRunning() ) {
			shutdown( wait );
		} else {
			throw new MyGridIsNotRunningException();
		}

		if ( callExit ) {
			callExit();
		}
	}


	public void stopMyGridService( boolean callExit ) throws MyGridIsNotRunningException {

		stopMyGridService( true, callExit );
	}


	private void callExit() {

		System.exit( 0 );
	}


	private void shutdown( boolean wait ) {

		if ( this.ebSchedulerFacade != null ) {
			EventQueue&lt;ShutdownResponseEvent&gt; schEq = this.ebSchedulerFacade.shutdown();
			if ( wait ) {
				schEq.blockingRemove();
			}
		}

		if ( this.ebReplicaExecutorFacade != null ) {
			EventQueue&lt;ShutdownResponseEvent&gt; reEq = this.ebReplicaExecutorFacade.shutdown();
			if ( wait ) {
				reEq.blockingRemove();
			}
		}
	}


	public boolean isMyGridRunning() {

		try {
			findExportedObjects();
			return true;
		} catch ( Exception e ) {
			return false;
		}
	}


	private void findExportedObjects() throws MalformedURLException, RemoteException, NotBoundException {

		scheduler = (Scheduler) Naming.lookup( MyGridURLProvider.scheduler() );

		gumpManager = (GumpManager) Naming.lookup( MyGridURLProvider.gumpManager() );
	}


	public boolean isExecutingInHomeMachine() {

		String homeMachine = Configuration.getInstance().getProperty( Configuration.PROP_NAME );

		try {
			String localHost = InetAddress.getLocalHost().getHostName();
			String localHostCompleteName = InetAddress.getLocalHost().getCanonicalHostName();
			String localIp = InetAddress.getLocalHost().getHostAddress();

			if ( homeMachine == null ) {
				throw new UnknownHostException( &quot;Cannot determine home machine name!&quot; );
			}

			return localHost.equals( homeMachine ) || localIp.equals( homeMachine )
					|| localHostCompleteName.equals( homeMachine );

		} catch ( Exception e ) {
			return false;
		}
	}


	public Collection&lt;JobEntry&gt; getJobs( JobManagerListenerRemote newListener ) throws RemoteException {

		if ( !isMyGridRunning() &amp;&amp; scheduler == null ) {
			throw new RemoteException( UIMessages.MYGRID_IS_NOT_RUNNING );
		}

		return scheduler.jobList( newListener );
	}


	public void cancelJob( int jobId ) throws JobNotFoundException, RemoteException, JobCouldNotBeCancelledException {

		if ( !isMyGridRunning() &amp;&amp; scheduler == null ) {
			throw new RemoteException( UIMessages.MYGRID_IS_NOT_RUNNING );
		}

		scheduler.cancelJob( jobId );
	}


	public void waitForJob( int jobId ) throws RemoteException, JobNotFoundException {

		if ( !isMyGridRunning() &amp;&amp; scheduler == null ) {
			throw new RemoteException( UIMessages.MYGRID_IS_NOT_RUNNING );
		}

		scheduler.waitForJob( jobId );

	}


	public int addJob( JobSpec newJob ) throws RemoteException {

		if ( !isMyGridRunning() &amp;&amp; scheduler == null ) {
			throw new RemoteException( UIMessages.MYGRID_IS_NOT_RUNNING );
		}

		int jobId = scheduler.addJob( newJob );
		return jobId;
	}


	public void cleanFinishedJobs() throws RemoteException {

		if ( !isMyGridRunning() &amp;&amp; scheduler == null ) {
			throw new RemoteException( UIMessages.MYGRID_IS_NOT_RUNNING );
		}

		scheduler.cleanFinishedJobs();

	}


	public void removeJob( int jobId ) throws RemoteException, JobCannotBeRemovedException {

		if ( !isMyGridRunning() &amp;&amp; scheduler == null ) {
			throw new RemoteException( UIMessages.MYGRID_IS_NOT_RUNNING );
		}

		scheduler.removeJob( jobId );
	}


	public Collection&lt;PeerEntry&gt; getPeerEntries( GridManagerListenerRemote newListener ) throws RemoteException {

		if ( !isMyGridRunning() &amp;&amp; gumpManager == null ) {
			throw new RemoteException( UIMessages.MYGRID_IS_NOT_RUNNING );
		}

		return gumpManager.getPeerEntries( newListener );
	}


	public void setPeers( Collection&lt;PeerSpec&gt; peerSpecs ) throws RemoteException {

		if ( !isMyGridRunning() &amp;&amp; gumpManager == null ) {
			throw new RemoteException( UIMessages.MYGRID_IS_NOT_RUNNING );
		}

		gumpManager.setPeers( peerSpecs );

		updateFailureDetector( peerSpecs );

	}


	private void updateFailureDetector( Collection&lt;PeerSpec&gt; guMPSpecs ) throws RemoteException {

		/* Removing old registereds Peers in this Failure Detector */
		failureDetector.unregister( peerStateNotifiable );

		/* Registering new Peers in this Failure Detector */
		for ( Iterator iter = guMPSpecs.iterator(); iter.hasNext(); ) {
			PeerSpec peerSpec = (PeerSpec) iter.next();

			String rmiHost = &quot;rmi://&quot; + peerSpec.getName() + &quot;:&quot; + peerSpec.getPort() + &quot;/&quot;
					+ AbstractFailureDetector.BOUND_NAME;

			try {
				failureDetector.register( peerStateNotifiable, rmiHost, true );
			} catch ( MalformedURLException e ) {
				LOG.error( &quot;Cannot register in MyGrid failure Detector the Peer: &quot; + peerSpec.getURL(), e );
			}

		}

	}


	public Collection&lt;GumSpec&gt; getGumSpecs() throws RemoteException {

		if ( !isMyGridRunning() &amp;&amp; scheduler == null ) {
			throw new RemoteException( UIMessages.MYGRID_IS_NOT_RUNNING );
		}

		return scheduler.getGumSpecs();
	}


	public Collection&lt;GridManagerEntry&gt; getGumEntries( GridManagerListenerRemote listener ) throws RemoteException {

		if ( !isMyGridRunning() &amp;&amp; scheduler == null ) {
			throw new RemoteException( UIMessages.MYGRID_IS_NOT_RUNNING );
		}

		return scheduler.getGumEntries( listener );
	}


	@Deprecated
	public void setPeers( String descriptionFilePath ) throws RemoteException, CompilerException {

		List&lt;PeerSpec&gt; result = DescriptionFileCompile.compileGDF( descriptionFilePath );
		this.setPeers( result );
	}


	@Deprecated
	public int addJob( String descriptionFilePath ) throws CompilerException, RemoteException,
		CouldNotAddJobOutsideHomeMachineException {

		if ( !isExecutingInHomeMachine() ) {
			throw new CouldNotAddJobOutsideHomeMachineException();
		}

		JobSpec result = DescriptionFileCompile.compileJDF( descriptionFilePath );
		return this.addJob( result );
	}


	public void removeJobManagerListener( JobManagerListenerRemote listener ) throws RemoteException {

		if ( !isMyGridRunning() &amp;&amp; scheduler == null ) {
			throw new RemoteException( UIMessages.MYGRID_IS_NOT_RUNNING );
		}

		scheduler.removeJobManagerListener( listener );
	}


	public void removeGridManagerListener( GridManagerListenerRemote listener ) throws RemoteException {

		if ( !isMyGridRunning() &amp;&amp; scheduler == null ) {
			throw new RemoteException( UIMessages.MYGRID_IS_NOT_RUNNING );
		}

		scheduler.removeGridManagerListener( listener );
	}
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NoSuchObjectException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import org.ourgrid.common.config.ConfigException;
import org.ourgrid.common.config.Configuration;
import org.ourgrid.common.config.MyGridConfiguration;
import org.ourgrid.common.event.ActionEvent;
import org.ourgrid.common.event.EventQueue;
import org.ourgrid.common.event.ShutdownEventEngine;
import org.ourgrid.common.event.ShutdownResponseEvent;
import org.ourgrid.common.gump.GumpClient;
import org.ourgrid.common.rmi.OurgridUnicastRemoteObject;
import org.ourgrid.common.url.MyGridURLProvider;
import org.ourgrid.mygrid.replicaexecutor.EBReplicaExecutorFacade;
import org.ourgrid.mygrid.scheduler.gridmanager.EBGridManager;
import org.ourgrid.mygrid.scheduler.gridmanager.GridManager;
import org.ourgrid.mygrid.scheduler.gump.GumpManager;
import org.ourgrid.mygrid.scheduler.jobmanager.EBJobManager;
import org.ourgrid.mygrid.scheduler.jobmanager.JobManager;

/**
 * This class is responsible for receiving events that come from the
 * <code>EBSchedulerFacade</code> and process them.
 */
public class SchedulerEventEngine implements ShutdownEventEngine {

	/** Logger (log4j) object to store log events */
	private static transient final org.apache.log4j.Logger LOG = org.apache.log4j.Logger
			.getLogger( SchedulerEventEngine.class );

	/** GridMachineConsumer accessible through RMI. * */
	private GumpClient gumpClient;

	/** GuMPManager accessible through RMI. * */
	private GumpManager gumpManager;

	/** Scheduler accessible through RMI. * */
	private Scheduler scheduler;

	/** The <code>EventQueue</code> */
	private EventQueue<ActionEvent> eventQueue;

	/** The <code>EBJobManager</code> */
	private JobManager jobManager;

	/** The <code>EBGridManager</code> */
	private EBGridManager ebGridManager;

	/** The <code>EBSchedulingHeuristic</code>. */
	private EBSchedulingHeuristic ebSchedulingHeuristic;

	/** The SchedulerEventEngine own <code>Thread</code>. */
	private Thread myThread;

	/** Indicates if this EventEngine is alive. */
	private boolean isAlive;

	/** A control flag */
	private boolean mustShutdown;

	/** The queue for a shutdown request. */
	private EventQueue<ShutdownResponseEvent> shutdownEventQueue;

	private final EBReplicaExecutorFacade ebReplicaExecutorFacade;
/**protected EBSchedulingHeuristic createSchedulingHeuristic() throws ConfigException {

		EBSchedulingHeuristicFactory shf = new EBSchedulingHeuristicFactory();
		String heuristicName = Configuration.getInstance().getProperty( MyGridConfiguration.PROP_HEURISTIC );
		return shf.getHeuristic( heuristicName, jobManager, ebGridManager, ebReplicaExecutorFacade );
	}


	 * The constructor.
	 * 
	 * @param scheduler GuMManager accessible through RMI.
	 * @param gumpManager GuMPManager accessible through RMI.
	 * @param gridMachineConsumer GridMachineConsumer accessible through RMI.
	 * @param ebReplicaExecutorFacade The EBReplicaExecutorFacade
	 * @param ebSchedulerFacade The EBSchedulerFacade
	 * @throws ConfigException When the scheduler could not be created
	 */
	public SchedulerEventEngine( Scheduler scheduler, GumpManager gumpManager, GumpClient gridMachineConsumer,
									EBReplicaExecutorFacade ebReplicaExecutorFacade, EBSchedulerFacade ebSchedulerFacade )
		throws ConfigException {

		this.scheduler = scheduler;
		this.gumpManager = gumpManager;
		this.gumpClient = gridMachineConsumer;
		this.ebReplicaExecutorFacade = ebReplicaExecutorFacade;

		this.eventQueue = new EventQueue<ActionEvent>();
		this.jobManager = new EBJobManager();
		this.ebGridManager = new EBGridManager( ebSchedulerFacade, gumpClient );

		String maxReplicas = Configuration.getInstance().getProperty( MyGridConfiguration.PROP_MAX_REPLICAS );
		String maxFails = Configuration.getInstance().getProperty( MyGridConfiguration.PROP_MAX_FAILS );
		jobManager.setMaxReplicas( maxReplicas );
		jobManager.setMaxFails( maxFails );
		this.ebSchedulingHeuristic = createSchedulingHeuristic();
		this.mustShutdown = false;
		this.myThread = new Thread( this, "SchedulerEventProcessorThread" );
	}

	 
	public void shutdown( EventQueue<ShutdownResponseEvent> eq ) {

		this.ebGridManager.shutdown();
		this.ebSchedulingHeuristic.getEBJobManager().shutdown();
		this.shutdownEventQueue = eq;
		this.mustShutdown = true;

		this.unbindAndUnexportRMIObjects();

	}

/**
	 * The <code>Thread</code> behavior.
	 */
	public void run() {

		boolean scheduled;
		while ( !mustShutdown ) {

			scheduled = schedule( ebSchedulingHeuristic );

			ActionEvent actionEvent;

			/*
			 * If the schedule occurred successfully there could be more
			 * replicas to be scheduled, so the schedule method must be called
			 * even if there are no events in the event queue.
			 */

			if ( scheduled ) {
				actionEvent = eventQueue.unblockingRemove();
			} else {
				actionEvent = eventQueue.blockingRemove();
			}

			if ( actionEvent != null ) {

				try {

					actionEvent.process();

				} catch ( Exception e ) {

					LOG.error( "Error in event process! Cause: " + e.getMessage(), e );
				}
			}
		}
		this.isAlive = false;
		shutdownEventQueue.put( new ShutdownResponseEvent() );
	}
	 * Unbind and unexports all RMI objects created by the Scheduler
	 */
	private void unbindAndUnexportRMIObjects() {

		try {

			Naming.unbind( MyGridURLProvider.scheduler() );

		} catch ( RemoteException e ) {
			LOG.error( "Could not contact registry:" + e.getMessage() );
		} catch ( MalformedURLException e ) {
			LOG.error( "MalformedURLException (this should never happen):" + e.getMessage() );
		} catch ( NotBoundException e ) {
			LOG.debug( MyGridURLProvider.scheduler() + " is already unbound:" + e.getMessage() );
		}

		try {
			OurgridUnicastRemoteObject.unexportObject( this.scheduler, true );
		} catch ( NoSuchObjectException e1 ) {
			LOG.debug( "Object " + this.scheduler + " is already unexported: " + e1.getMessage() );
		}

		try {
			Naming.unbind( MyGridURLProvider.gumpManager() );
		} catch ( RemoteException e ) {
			LOG.error( "Could not contact registry:" + e.getMessage() );
		} catch ( MalformedURLException e ) {
			LOG.error( "MalformedURLException (this should never happen):" + e.getMessage() );
		} catch ( NotBoundException e ) {
			LOG.debug( MyGridURLProvider.gumpManager() + " is already unbound:" + e.getMessage() );
		}

		try {
			OurgridUnicastRemoteObject.unexportObject( this.gumpManager, true );
		} catch ( NoSuchObjectException e2 ) {
			LOG.debug( "Object " + this.gumpManager + " is already unexported: " + e2.getMessage() );
		}

		try {
			Naming.unbind( MyGridURLProvider.gridManager() );
		} catch ( RemoteException e ) {
			LOG.error( "Could not contact registry:" + e.getMessage() );
		} catch ( MalformedURLException e ) {
			LOG.error( "MalformedURLException (this should never happen):" + e.getMessage() );
		} catch ( NotBoundException e ) {
			LOG.debug( MyGridURLProvider.gridManager() + " is already unbound:" + e.getMessage() );
		}

		try {
			Naming.unbind( MyGridURLProvider.gumpClient() );
		} catch ( RemoteException e ) {
			LOG.error( "Could not contact registry:" + e.getMessage() );
		} catch ( MalformedURLException e ) {
			LOG.error( "MalformedURLException (this should never happen):" + e.getMessage() );
		} catch ( NotBoundException e ) {
			LOG.debug( MyGridURLProvider.gumpClient() + " is already unbound:" + e.getMessage() );
		}

		try {
			OurgridUnicastRemoteObject.unexportObject( this.gumpClient, true );
		} catch ( NoSuchObjectException e2 ) {
			LOG.debug( "Object " + this.gumpClient + " is already unexported: " + e2.getMessage() );
		}

	}


	/**
	 * @see org.ourgrid.common.event.EBSyncShutdownable#isAlive()
	 */