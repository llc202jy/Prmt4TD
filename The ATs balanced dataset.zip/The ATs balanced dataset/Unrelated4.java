#include "Federate.hh"
#include "RootObject.hh"
#include "LBTS.hh"
#include "SecurityServer.hh"
#include "HandleManager.hh"
#include "certi.hh"

#ifndef WIN32
#include <unistd.h>
#include <stdlib.h>
#endif

#ifdef FEDERATION_USES_MULTICAST
#include "SocketMC.hh"
#endif

// Libraries
#ifdef HAVE_XML
#include <libxml/xmlmemory.h> // FIXME: should be in the .cc
#include <libxml/parser.h>
#include <libxml/tree.h>
#endif // HAVE_XML

namespace certi {
namespace rtig {

class Federation
{
    // ATTRIBUTES --------------------------------------------------------------
private:
    Handle handle ;
    char *name ;
    char *FEDid ;

    //! Labels and Tags not on synchronization.
    std::map<const char *, const char *> synchronizationLabels ;

    HandleManager<FederateHandle> federateHandles ;
    HandleManager<ObjectHandle> objectHandles ;

    // This object is initialized when the Federation is created, with
    // the reference of the RTIG managed Socket Server. The reference of
    // this object is passed down the Classes Tree with the help of RootObj.
    SecurityServer *server ;
    RootObject *root ;

    LBTS regulators ;

#ifdef FEDERATION_USES_MULTICAST
    SocketMC *MCLink ;
#endif

    bool saveXmlData();
    bool restoreXmlData();

    // METHODS -----------------------------------------------------------------
public:
#ifdef FEDERATION_USES_MULTICAST
    Federation(const char *,
               FederationHandle,
               SocketServer &,
               AuditFile &,
               SocketMC*)
#else
        Federation(const char *, Handle, SocketServer &, AuditFile &, const char *)
#endif
        throw (CouldNotOpenFED, ErrorReadingRID, MemoryExhausted, SecurityError,
               RTIinternalError);

    ~Federation();

    int getNbFederates() const ;
    int getNbRegulators() const ;
    bool isSynchronizing() const ;
    Handle getHandle() const ;
    const char *getName() const ;
    const char *getFEDid() const ;

    // -------------------------
    // -- Federate Management --
    // -------------------------
    FederateHandle add(const char *theName, SocketTCP *theTCPLink)
        throw (FederateAlreadyExecutionMember,
               MemoryExhausted,
               RTIinternalError);

    bool empty() const
        throw (FederatesCurrentlyJoined);

    bool check(FederateHandle theHandle) const
        throw (FederateNotExecutionMember);

    void kill(FederateHandle theFederate) throw ();

    void remove(FederateHandle theHandle)
        throw (FederateOwnsAttributes,
               FederateNotExecutionMember);

    // ---------------------
    // -- Time Management --
    // ---------------------
    void addRegulator(FederateHandle theHandle, FederationTime theTime)
        throw (FederateNotExecutionMember,
               SaveInProgress,
               RestoreInProgress,
               RTIinternalError); // includes Time Regulation already enabled.

    void updateRegulator(FederateHandle theHandle, FederationTime theTime)
        throw (FederateNotExecutionMember,
               RTIinternalError);

    void removeRegulator(FederateHandle theHandle)
        throw (FederateNotExecutionMember,
               SaveInProgress,
               RestoreInProgress,
               RTIinternalError); // includes Time Regulation already disabled.

    void addConstrained(FederateHandle theHandle)
