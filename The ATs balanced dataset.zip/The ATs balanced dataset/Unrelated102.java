ckage org.openware.job.gui;

import java.util.Collection;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import javax.swing.JTable;
import javax.swing.event.*;
import javax.swing.table.*;

public class JPersistSortTable extends JTable implements MouseListener
{
    protected int sortedColumnIndex = -1;
    protected boolean sortedColumnAscending = true;
    protected boolean ignoreCase = false;

    public JPersistSortTable() {
        this(new PersistTableModel());
    }

    public JPersistSortTable(Collection persists) {
        this(new PersistCollectionTable(persists));
    }

    public JPersistSortTable(PersistCollectionTable pct) {
        this(new PersistTableModel(pct));
    }
  
    public JPersistSortTable(ISortTableModel model) {
        super(model);
        initSortHeader();
    }

    protected void initSortHeader() {
        JTableHeader header = getTableHeader();
        header.setDefaultRenderer(new SortHeaderRenderer());
        header.addMouseListener(this);
    }

    public void setIgnoreCase(boolean ignoreCase) {
        this.ignoreCase = ignoreCase;
    }

    public int getSortedColumnIndex() {
        return sortedColumnIndex;
    }
  
    public boolean isSortedColumnAscending() {
        return sortedColumnAscending;
    }
  
    public void mouseReleased(MouseEvent event) {
    }
  
    public void mousePressed(MouseEvent event) {}
    public void mouseClicked(MouseEvent event) {
        TableColumnModel colModel = getColumnModel();
        int index = colModel.getColumnIndexAtX(event.getX());
        int modelIndex = colModel.getColumn(index).getModelIndex();

        ISortTableModel model = (ISortTableModel)getModel();

        /*
         * If the table is disabled, we will ignore the mouse event,
         * effectively preventing sorting.
         */
        
        if(!isEnabled() || isEditing()) {
          return;
        }
        
        /*
         * Save a list of highlighted rows. I don't call getSelectedRows()
         * directly since that would force me to have *two* working arrays.
         */

        String hrows[] = new String[getSelectedRowCount()];
        int nr = getRowCount();
        for(int c = 0, i = 0; i < nr ; i++) {
            if(isRowSelected(i)) {
                hrows[c] = model.getIndexedColumnValue(i);
                c++;
            }
        }

        if (event.getClickCount() == 1 && model.isSortable(modelIndex)) {
            // toggle ascension, if already sorted
            if (sortedColumnIndex == index) {
                sortedColumnAscending = !sortedColumnAscending;
            }
            sortedColumnIndex = index;
            
            model.sortColumn(modelIndex, ignoreCase, sortedColumnAscending);
        }

        /*
         * now rehighlight the rows in their new positions
         */

        clearSelection();
        for(int i = 0; i < hrows.length; i++) {
            int r = model.getRowNumberForIndexedColumnValue(hrows[i]);
            if (r > 0) {
                addRowSelectionInterval(r, r);
            }
        }
    }
    public void mouseEntered(MouseEvent event) {}
    public void mouseExited(MouseEvent event) {}
}
ckage org.openware.job.servlet;

import org.openware.job.data.TableRow;
import org.openware.job.data.BaseDBA;
import org.openware.job.data.UpdateResults;
import org.openware.job.data.PersistException;
import org.openware.job.data.Query;
import org.openware.job.data.Oid;
import org.openware.job.generator.metadata.MetaData;

import java.util.Collection;
import java.net.URL;
import java.net.URLConnection;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.rmi.RemoteException;

public class ServletClient implements JobServletConstants
{
    private String servletUrl = null;
    private String authToken = null;

    public ServletClient(String servletUrl) {
        if (!servletUrl.startsWith("http:") &&
            !servletUrl.startsWith("https")) {
            throw new IllegalArgumentException("Connection string must be a valid HTTP url when connection mode is 'SERVLET'");
        }

        if (servletUrl.endsWith("/")) {
            throw new IllegalArgumentException("URL must not end with '/'");
        }

        this.servletUrl = servletUrl;
    }

    public void setAuthenticationToken(String token) {
        authToken = token;
    }

    private Object getReply(URLConnection connection) 
        throws PersistException, RemoteException {
        ObjectInputStream input = null;
        ServletReply sr = null;

        try {
            input = new ObjectInputStream(connection.getInputStream());
            sr = (ServletReply) input.readObject();
            input.close();
        } catch (Exception e) {
            e.printStackTrace();
            throw new JobServletException("Error reading object: " + e);
        }

        if (sr.getReplyStatus() == EXCEPTION) {
            if (sr.getReply() instanceof RemoteException) {
                throw (RemoteException) sr.getReply();
            } else if (sr.getReply() instanceof PersistException) {
                throw (PersistException) sr.getReply();
            } else {
                ((Exception) sr.getReply()).printStackTrace();
                return null;
            }
        }

        return sr.getReply();
    }

    private URLConnection getUrl(String methodName) throws Exception {
        if (authToken == null) {
            return (URLConnection) (new URL(servletUrl + "?" + 
                                                QUERY_STRING_VALUE_NAME + 
                                                "=" + methodName)).openConnection();
        } else {
            return (URLConnection) (new URL(servletUrl + "?" + 
                                                QUERY_STRING_VALUE_NAME + 
                                                "=" + methodName + 
                                                "&TOKEN=" + authToken)).openConnection();
        }
    }

    public UpdateResults save(BaseDBA dba, 
                              Collection saveList) throws PersistException, RemoteException {
        URLConnection connection = null;
        ObjectOutputStream output = null;

        try {
            Object [] args = null;
            
            args = new Object[2];
            args[0] = dba;
            args[1] = saveList;
            connection = getUrl(SAVE);
            connection.setUseCaches(false);
            connection.setDoInput(true);
            connection.setRequestProperty("Content-Type", "application/octet-stream");
            connection.setDoOutput(true);
            output = new ObjectOutputStream(connection.getOutputStream());
            output.writeObject(args);
            output.flush();
            output.close();
        } catch (Exception e) {
            throw new JobServletException("Error writing object: " + e);
        }
        
        return (UpdateResults) getReply(connection);
    }
    
    public TableRow load(BaseDBA dba, TableRow data) throws PersistException, RemoteException {
        URLConnection connection = null;
        ObjectOutputStream output = null;

        try {
            Object [] args = null;
            
            args = new Object[2];
            args[0] = dba;
            args[1] = data;

            connection = getUrl(LOAD);
            connection.setUseCaches(false);
            connection.setDoInput(true);
            connection.setRequestProperty("Content-Type", "application/octet-stream");
            connection.setDoOutput(true);
            output = new ObjectOutputStream(connection.getOutputStream());
            output.writeObject(args);
            output.flush();
            output.close();
        } catch (Exception e) {
            e.printStackTrace();
            throw new JobServletException("Error writing object: " + e);
        }

        return (TableRow) getReply(connection);
    }
    
    public Collection findBy(BaseDBA dba, TableRow data, Query query) 
        throws PersistException, RemoteException {
        FindByArguments fbargs = null;
        URLConnection connection = null;
        ObjectOutputStream output = null;
        
        fbargs = new FindByArguments(data, query);
        try {
            Object [] args = null;
            
            args = new Object[2];
            args[0] = dba;
            args[1] = fbargs;

            connection = getUrl(FIND_BY);
            connection.setUseCaches(false);
            connection.setDoInput(true);
            connection.setRequestProperty("Content-Type", "application/octet-stream");
            connection.setDoOutput(true);
            output = new ObjectOutputStream(connection.getOutputStream());
            output.writeObject(args);
            output.flush();
            output.close();
        } catch (Exception e) {
            throw new JobServletException("Error writing object: " + e);
        }

        return (Collection) getReply(connection);
    }

    public Collection rawQuery(String query) 
        throws PersistException, RemoteException {
        URLConnection connection = null;
        ObjectOutputStream output = null;
        
        try {
            Object [] args = null;
            
            args = new Object[1];
            args[0] = query;

            connection = getUrl(RAW_QUERY);
            connection.setUseCaches(false);
            connection.setDoInput(true);
            connection.setRequestProperty("Content-Type", "application/octet-stream");
            connection.setDoOutput(true);
            output = new ObjectOutputStream(connection.getOutputStream());
            output.writeObject(args);
            output.flush();
            output.close();
        } catch (Exception e) {
            throw new JobServletException("Error writing object: " + e);
        }

        return (Collection) getReply(connection);
    }

    public int count(BaseDBA dba, TableRow data, Query query) 
        throws PersistException, RemoteException {
        FindByArguments fbargs = null;
        URLConnection connection = null;
        ObjectOutputStream output = null;
        
        fbargs = new FindByArguments(data, query);
        try {
            Object [] args = null;
            
            args = new Object[2];
            args[0] = dba;
            args[1] = fbargs;

            connection = getUrl(COUNT);
            connection.setUseCaches(false);
            connection.setDoInput(true);
            connection.setRequestProperty("Content-Type", "application/octet-stream");
            connection.setDoOutput(true);
            output = new ObjectOutputStream(connection.getOutputStream());
            output.writeObject(args);
            output.flush();
            output.close();
        } catch (Exception e) {
            throw new JobServletException("Error writing object: " + e);
        }

        return ((Integer) getReply(connection)).intValue();
    }

    public int rawUpdate(TableRow shell) throws PersistException, RemoteException {
        URLConnection connection = null;
        ObjectOutputStream output = null;

        try {
            connection = getUrl(RAW_UPDATE);
            connection.setUseCaches(false);
            connection.setDoInput(true);
            connection.setRequestProperty("Content-Type", "application/octet-stream");
            connection.setDoOutput(true);
            output = new ObjectOutputStream(connection.getOutputStream());
            output.writeObject(shell);
            output.flush();
            output.close();
        } catch (Exception e) {
            throw new JobServletException("Error writing object: " + e);
        }

        return ((Integer) getReply(connection)).intValue();
    }

    public MetaData getMetaData(BaseDBA dba) throws PersistException, RemoteException {
        URLConnection connection = null;
        ObjectOutputStream output = null;
        
        try {
            Object [] args = null;

            args = new Object[1];
            args[0] = dba;
            connection = getUrl(GET_META_DATA);
            connection.setUseCaches(false);
            connection.setDoInput(true);
            connection.setRequestProperty("Content-Type", "application/octet-stream");
            connection.setDoOutput(true);
            output = new ObjectOutputStream(connection.getOutputStream());
            output.writeObject(args);
            output.flush();
            output.close();
        } catch (Exception e) {
            throw new JobServletException("Error writing object: " + e);
        }

        return (MetaData) getReply(connection);
    }

    public Collection loadAuditTrailHistory(BaseDBA dba, Oid oid) 
        throws PersistException, RemoteException {
        URLConnection connection = null;
        ObjectOutputStream output = null;
        
        try {
            Object [] args = null;

            args = new Object[2];
            args[0] = dba;
            args[1] = oid;
            connection = getUrl(GET_AUDIT_TRAIL_HISTORY);
            connection.setUseCaches(false);
            connection.setDoInput(true);
            connection.setRequestProperty("Content-Type", "application/octet-stream");
            connection.setDoOutput(true);
            output = new ObjectOutputStream(connection.getOutputStream());
            output.writeObject(args);
            output.flush();
            output.close();
        } catch (Exception e) {
            throw new JobServletException("Error writing object: " + e);
        }

        return (Collection) getReply(connection);
    }

    public long getKeys(long numKeys) throws PersistException, RemoteException {
        URLConnection connection = null;
        ObjectOutputStream output = null;
        ObjectInputStream input = null;
        ServletReply sr = null;

        try {
            connection = getUrl(GET_KEYS);
            connection.setUseCaches(false);
            connection.setDoInput(true);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/octet-stream");
            output = new ObjectOutputStream(connection.getOutputStream());
            output.writeObject(new Long(numKeys));
            output.flush();
            output.close();
        } catch (Exception e) {
            throw new JobServletException("Error writing object: " + e);
        }

        return ((Long) getReply(connection)).longValue();
    }
}
/**
 * The reply from the JobServlet.  Encapsulates whether the return
 * was a normal return or the method threw an exception.
 *
 * @author Vincent Sheffer
 */
public class ServletReply implements JobServletConstants
{
    private int replyStatus = SUCCESS;
    private Object reply = null;
    
    public ServletReply(int replyStatus, Object reply) {
        if (replyStatus != SUCCESS &&
            replyStatus != EXCEPTION) {
            throw new IllegalArgumentException("Invalid servlet reploy status: " + replyStatus);
        }

        this.replyStatus = replyStatus;

        if (reply instanceof RemoteException) {
            RemoteException ri = null;

            ri = (RemoteException) reply;
            if (ri.detail != null) {
                this.reply = ri.detail;
            }
        } else {
            this.reply = reply;
        }
    }

    int getReplyStatus() {
        return replyStatus;
    }

    /**
     * The object that was returned if the reply status is 'SUCCESS' or
     * the exception that was thrown if that status was 'EXCEPTION'.
     */
    Object getReply() {
        return reply;
    }
                    colnum++;
                }
                
                rownum++;
            }

            pctStale = false;
        }
    }

    public int getRowCount() { 
        resetModel();
        return rowCount;
    }

    public int getColumnCount() { 
        resetModel();
        return colCount;
    }

    public Object getValueAt(int row, int col) { 
        resetModel();
        return values[row][col]; 
    }

    public boolean isCellEditable(int row, int col) {
        return false;
    }

  
    public boolean isSortable(int col) {
        return true;
    }
  
    public void sortColumn(int col, boolean ignoreCase, boolean ascending) {
        pct.sort(col, ignoreCase, ascending);
        this.sortCol = col;
        this.ignoreCase = ignoreCase;
        this.ascending = ascending;
        this.pctStale = true;
        //        fireTableChanged(new TableModelEvent(this, TableModelEvent.HEADER_ROW));
    }
    
    public void setValueAt(Object value, int row, int col) {
        resetModel();
        values[row][col] = (String) value;
        fireTableCellUpdated(row, col);
    }
