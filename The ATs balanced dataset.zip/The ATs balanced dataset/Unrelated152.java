public class LearningRateResultProducer 
  implements ResultListener, ResultProducer, OptionHandler,
	     AdditionalMeasureProducer {

  /** for serialization */
  static final long serialVersionUID = -3841159673490861331L;
  
  /** The dataset of interest */
  protected Instances m_Instances;

  /** The ResultListener to send results to */
  protected ResultListener m_ResultListener = new CSVResultListener();

  /** The ResultProducer used to generate results */
  protected ResultProducer m_ResultProducer
    = new AveragingResultProducer();

  /** The names of any additional measures to look for in SplitEvaluators */
  protected String [] m_AdditionalMeasures = null;

  /** 
   * The minimum number of instances to use. If this is zero, the first
   * step will contain m_StepSize instances 
   */
  protected int m_LowerSize = 0;
  
  /**
   * The maximum number of instances to use. -1 indicates no maximum 
   * (other than the total number of instances)
   */
  protected int m_UpperSize = -1;

  /** The number of instances to add at each step */
  protected int m_StepSize = 10;

  /** The current dataset size during stepping */
  protected int m_CurrentSize = 0;

  /** The name of the key field containing the learning rate step number */
  public static String STEP_FIELD_NAME = "Total_instances";

  /**
   * Returns a string describing this result producer
   * @return a description of the result producer suitable for
   * displaying in the explorer/experimenter gui
   */
  public String globalInfo() {
    return "Tells a sub-ResultProducer to reproduce the current run for "
      +"varying sized subsamples of the dataset. Normally used with "
      +"an AveragingResultProducer and CrossValidationResultProducer "
      +"combo to generate learning curve results. For non-numeric "
      +"result fields, the first value is used.";
  }


  /**
   * Determines if there are any constraints (imposed by the
   * destination) on the result columns to be produced by
   * resultProducers. Null should be returned if there are NO
   * constraints, otherwise a list of column names should be
   * returned as an array of Strings.
   * @param rp the ResultProducer to which the constraints will apply
   * @return an array of column names to which resutltProducer's
   * results will be restricted.
   * @throws Exception if constraints can't be determined
   */
  public String [] determineColumnConstraints(ResultProducer rp) 
    throws Exception {
    return null;
  }

  /**
   * Gets the keys for a specified run number. Different run
   * numbers correspond to different randomizations of the data. Keys
   * produced should be sent to the current ResultListener
   *
   * @param run the run number to get keys for.
   * @throws Exception if a problem occurs while getting the keys
   */
  public void doRunKeys(int run) throws Exception {

    if (m_ResultProducer == null) {
      throw new Exception("No ResultProducer set");
    }
    if (m_ResultListener == null) {
      throw new Exception("No ResultListener set");
    }
    if (m_Instances == null) {
      throw new Exception("No Instances set");
    }

    // Tell the resultproducer to send results to us
    m_ResultProducer.setResultListener(this);
    m_ResultProducer.setInstances(m_Instances);

    // For each subsample size
    if (m_LowerSize == 0) {
      m_CurrentSize = m_StepSize;
    } else {
      m_CurrentSize = m_LowerSize;
    }
    while (m_CurrentSize <= m_Instances.numInstances() &&
           ((m_UpperSize == -1) ||
            (m_CurrentSize <= m_UpperSize))) {
      m_ResultProducer.doRunKeys(run);
      m_CurrentSize += m_StepSize;
    }
  }

