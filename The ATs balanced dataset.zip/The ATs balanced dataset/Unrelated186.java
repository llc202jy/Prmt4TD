    /* ------------------------------------------------------------ */
    protected void doStop() throws Exception
    {
        super.doStop();
    }

    /* ------------------------------------------------------------ */
    /**
     * @return Get the number of requests handled by this context
     * since last call of statsReset(). If setStatsOn(false) then this
     * is undefined.
     */
    public int getRequests() {return _requests;}

    /* ------------------------------------------------------------ */
    /**
     * @return Number of requests currently active.
     * Undefined if setStatsOn(false).
     */
    public int getRequestsActive() {return _requestsActive;}

    /* ------------------------------------------------------------ */
    /**
     * @return Maximum number of active requests
     * since statsReset() called. Undefined if setStatsOn(false).
     */
    public int getRequestsActiveMax() {return _requestsActiveMax;}

    /* ------------------------------------------------------------ */
    /**
     * @return Get the number of responses with a 2xx status returned
     * by this context since last call of statsReset(). Undefined if
     * if setStatsOn(false).
     */
    public int getResponses1xx() {return _responses1xx;}

    /* ------------------------------------------------------------ */
    /**
     * @return Get the number of responses with a 100 status returned
     * by this context since last call of statsReset(). Undefined if
     * if setStatsOn(false).
     */
    public int getResponses2xx() {return _responses2xx;}

    /* ------------------------------------------------------------ */
    /**
     * @return Get the number of responses with a 3xx status returned
     * by this context since last call of statsReset(). Undefined if
     * if setStatsOn(false).
     */
    public int getResponses3xx() {return _responses3xx;}

    /* ------------------------------------------------------------ */
    /**
     * @return Get the number of responses with a 4xx status returned
     * by this context since last call of statsReset(). Undefined if
     * if setStatsOn(false).
     */
    public int getResponses4xx() {return _responses4xx;}

    /* ------------------------------------------------------------ */
    /**
     * @return Get the number of responses with a 5xx status returned
     * by this context since last call of statsReset(). Undefined if
     * if setStatsOn(false).
     */
    public int getResponses5xx() {return _responses5xx;}

    /* ------------------------------------------------------------ */
    /** 
     * @return Timestamp stats were started at.
     */
    public long getStatsOnMs()
    {
        return System.currentTimeMillis()-_statsStartedAt;
    }

    /* ------------------------------------------------------------ */
    /**
     * @return Returns the requestsActiveMin.
     */
    public int getRequestsActiveMin()
    {
        return _requestsActiveMin;
    }

    /* ------------------------------------------------------------ */
    /**
     * @return Returns the requestsDurationMin.
     */
    public long getRequestsDurationMin()
    {
        return _requestsDurationMin;
    }

    /* ------------------------------------------------------------ */
    /**
     * @return Returns the requestsDurationTotal.
     */
    public long getRequestsDurationTotal()
    {
        return _requestsDurationTotal;
    }

    /* ------------------------------------------------------------ */
    /** 
     * @return Average duration of request handling in milliseconds 
     * since statsReset() called. Undefined if setStatsOn(false).
     */
    public long getRequestsDurationAve() {return _requests==0?0:(_requestsDurationTotal/_requests);}

    /* ------------------------------------------------------------ */
    /** 
     * @return Get maximum duration in milliseconds of request handling
     * since statsReset() called. Undefined if setStatsOn(false).
     */
    public long getRequestsDurationMax() {return _requestsDurationMax;}
    

}

package org.mortbay.jetty.handler;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mortbay.jetty.EofException;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.Server;
import org.mortbay.util.LazyList;
import org.mortbay.util.MultiException;

/* ------------------------------------------------------------ */
/** A collection of handlers.  
 * For each request, all handler are called, regardless of 
 * the response status or exceptions.
 *  
 * @author gregw
 * @org.apache.xbean.XBean
 */
public class HandlerCollection extends AbstractHandlerContainer
{
    private Handler[] _handlers;

    /* ------------------------------------------------------------ */
    public HandlerCollection()
    {
        super();
    }

    /* ------------------------------------------------------------ */
    /**
     * @return Returns the handlers.
     */
    public Handler[] getHandlers()
    {
        return _handlers;
    }
    
    /* ------------------------------------------------------------ */
    /**
     * 
     * @param handlers The handlers to set.
     */
    public void setHandlers(Handler[] handlers)
    {
        Handler [] old_handlers = _handlers==null?null:(Handler[])_handlers.clone();
        
        if (getServer()!=null)
            getServer().getContainer().update(this, old_handlers, handlers, "handler");
        
        Server server = getServer();
        MultiException mex = new MultiException();
        for (int i=0;handlers!=null && i<handlers.length;i++)
        __parser.redirectEntity("configure_1_2.dtd", configURL);
        __parser.redirectEntity("http://jetty.mortbay.org/configure_1_2.dtd", configURL);
        __parser.redirectEntity("-//Mort Bay Consulting//DTD Configure 1.2//EN", configURL);
        __parser.redirectEntity("configure_1_1.dtd", configURL);
        __parser.redirectEntity("http://jetty.mortbay.org/configure_1_1.dtd", configURL);
        __parser.redirectEntity("-//Mort Bay Consulting//DTD Configure 1.1//EN", configURL);
        __parser.redirectEntity("configure_1_0.dtd", configURL);
        __parser.redirectEntity("http://jetty.mortbay.org/configure_1_0.dtd", configURL);
        __parser.redirectEntity("-//Mort Bay Consulting//DTD Configure 1.0//EN", configURL);
    }

    /* ------------------------------------------------------------ */
    /**
     * Constructor. Reads the XML configuration file.
     *
     * @param configuration
     */
    public XmlConfiguration(URL configuration) throws SAXException, IOException
    {
        initParser();
        synchronized (__parser)
        {
            _config = __parser.parse(configuration.toString());
        }
    }
