using System;
using System.Diagnostics;
using System.Reflection;
using System.Security.Permissions;
using Pulsatrix.Diagnostics.Exceptions;amespace Pulsatrix.Diagnostics.Converters
{
    public abstract class DumpNodeToCountedStringListConverter : IValueConverter
    {
        #region IValueConverter Members

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null)
                return null;
            List<CountedString> countedStrings = new List<CountedString>();
            DumpNode node = value as DumpNode;
            if (node != null)
            {
                BuildCountedStrings(node.Visual, countedStrings);
                countedStrings.Sort(new Comparison<CountedString>(CompareCountedStrings));
            }
            return countedStrings;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }

        #endregion

        private void BuildCountedStrings(Visual root, List<CountedString> countedStrings)
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(root); i++)
            {
                Visual child = VisualTreeHelper.GetChild(root, i) as Visual;
                if (child != null)
                    BuildCountedStrings(child, countedStrings);
            }
            string stringValue = StringFromVisual(root);
            foreach (CountedString str2 in countedStrings)
                if (str2.StringValue == stringValue)
                {
                    str2.Count++;
                    return;
                }
            countedStrings.Add(new CountedString(stringValue));
        }

        private static int CompareCountedStrings(CountedString x, CountedString y)
        {
            return (y.Count - x.Count);
        }

        protected abstract string StringFromVisual(Visual visual);
    }
using Pulsatrix.Framework.Configuration;
using Pulsatrix.Framework.Helpers;
using Pulsatrix.Framework.Services;
using Pulsatrix.Framework.Services.CommandLine;
using Pulsatrix.Framework.Services.Cryptography;
using Pulsatrix.Framework.Services.Diagnostics;
using Pulsatrix.Framework.Services.EntityTranslator;
using Pulsatrix.Framework.Services.Modules;
using Pulsatrix.Framework.Services.Principal;
using Pulsatrix.Framework.Services.UserConfiguration;
using Pulsatrix.Framework.Services.WorkItems;
using Pulsatrix.Framework.Services.Workspace;
using Pulsatrix.Framework.Strategies;
using Pulsatrix.Framework.Visualizers;
using Pulsatrix.Framework.WorkItems;
using Pulsatrix.ObjectBuilder;
using Pulsatrix.ObjectBuilder.Helpers;

namespace Pulsatrix.Framework
{
    /// <summary>
    /// Defines the <see cref="CabApplication"/> as an application having a well known lifecycle
    /// and as root <see cref="WorkItem"/> instance providing the scope for the application.
    /// </summary>
    public abstract class CabApplication : WorkItem
    {
        private FrameworkSettings frameworkSettings;
        private TraceSource objectBuilderTraceSource;
        private IVisualizer visualizer;
        private Type visualizerType;

        public IVisualizer Visualizer
        {
            get { return visualizer; }
        }

        /// <summary>
        /// Sets the visualizer type to be used for the application; if set to null, will turn
        /// off visualizer support (even if visualizations are configured in App.config).
        /// </summary>
        protected Type VisualizerType
        {
            get { return visualizerType; }
            set
            {
                if (value != null)
                    Guard.TypeIsAssignableFromType(value, typeof (IVisualizer), "VisualizerType");

                visualizerType = value;
            }
        }

        /// <summary>
        /// Returns the <see cref="FrameworkSettings"/> that controls the configuration for this <see cref="CabApplication"/>.
        /// </summary>
        protected virtual FrameworkSettings Configuration
        {
            get
            {
                if (frameworkSettings == null)
                {
                    frameworkSettings = FrameworkSettings.GetFrameworkSettings(ConfigurationSource);
                    if (frameworkSettings == null)
                        frameworkSettings = new FrameworkSettings();
                }

                return frameworkSettings;
            }
        }

        public bool DiagnosticMode
        {
            get
            {
                ICommandLineService service = Services.Get<ICommandLineService>(true);
                return (service.GetArgument("diagnostics") != null);
            }
        }

        public bool TestingStartup
        {
            get
            {
                ICommandLineService service = Services.Get<ICommandLineService>(true);
                return (service.GetArgument("teststartup") != null);
            }
        }

        public Version Version
        {
            get { return Assembly.GetEntryAssembly().GetName().Version; }
        }
