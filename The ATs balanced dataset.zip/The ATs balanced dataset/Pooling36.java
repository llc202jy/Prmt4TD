namespace App.Model
{
    #region Example Usage
    namespace ObjectPoolTester
    {
        #region ObjectPoolTester
        public class ObjectPoolTester
        {
            public void Test()
            {
                // Obtain objects from pool
                SampleForm x = ObjectPool.New<sampleform>();
                SampleForm x1 = ObjectPool.New<sampleform>();
                SampleForm x2 = ObjectPool.New<sampleform>();
                SampleClass x3 = ObjectPool.New<sampleclass>();

                // return objects to object pool
                ObjectPool.Delete<sampleform>(x);
                ObjectPool.Delete<sampleform>(x1);
                ObjectPool.Delete<sampleform>(x2);
                ObjectPool.Delete<sampleclass>(x3);

                // again obtain objects from object pool, note that
                // objects will be reused
                SampleForm x4 = ObjectPool.New<sampleform>();
                SampleClass x5 = ObjectPool.New<sampleclass>();
            }
        }
        #endregion

        #region SampleClass
        public class SampleClass : IPoolable
        {
            public void Create()
            {
            }

            public void New()
            {

            }

            public void Delete()
            {

            }
        }
        #endregion

        #region SampleForm
        public class SampleForm : IPoolable
        {
            public void Create()
            {
            }

            public void New()
            {

            }

            public void Delete()
            {

            }
        }
        #endregion
    }
    #endregion

    #region IPoolable
    public interface IPoolable
    {
        void Create();
        void New();
        void Delete();
    }
    #endregion

    #region ObjectPool
    public class ObjectPool
    {
        #region Data Members
        private static Dictionary<system.type,> pools = new Dictionary<type,>();

        #endregion

        #region New

        public static T New<t>() where T : IPoolable, new()
        {
            T x = default(T);

            if (pools.ContainsKey(typeof(T)))
            {
                x = (T)pools[typeof(T)].Pop();
            }
            else
            {
                lock (pools)
                {
                    pools[typeof(T)] = new PoolableObject(10);
                }
            }

            if (x == null)
            {
                x = new T();
                x.Create();
            }
            x.New();

            return x;
        }

        #endregion

        #region Delete
        public static void Delete<t>(T obj) where T : IPoolable
        {
            if (pools.ContainsKey(typeof(T)))
            {
                obj.Delete();
                pools[typeof(T)].Push(obj);
            }
            else
            {
                throw new Exception("ObjectPool.Delete can not be 
                called for object which is not created using ObjectPool.New");
            }
        }

        #endregion

        #region Clear

        public static void Clear()
        {
            lock (pools)
            {
                foreach (PoolableObject po in pools.Values)
                {
                    po.Clear();
                }

                pools.Clear();
            }
        }
        #endregion
    }
    #endregion

    #region PoolableObject
    public class PoolableObject
    {
        #region Data Members
        private Stack<ipoolable> pool;

        #endregion

        #region Ctor
        public PoolableObject(int capacity)
        {
            pool = new Stack<ipoolable>(capacity);
        }
        #endregion

        #region Properties
        public Int32 Count
        {
            get { return pool.Count; }
        }
        #endregion

        #region Pop
        public IPoolable Pop()
        {
            lock (pool)
            {
                if (pool.Count > 0)
                {
                    return pool.Pop();
                }

                return null;
            }
        }
        #endregion

        #region Push
        public void Push(IPoolable obj)
        {
            if (obj == null)
            {
                throw new ArgumentNullException("Items added to a Pool cannot be null");
            }

            lock (pool)
            {
                pool.Push(obj);
            }
        }
        #endregion

        #region Clear
        public void Clear()
        {
            lock (pool)
            {
                pool.Clear();
            }
        }
        #endregion
    }
    #endregion
}