public interface AuthenticationManager {

    /** The Avalon Role */
    String ROLE = AuthenticationManager.class.getName();

    /**
     * Is the current user authenticated for the given handler?
     * @return Returns the corresponding handler if the user is authenticated.
     */
    UserHandler isAuthenticated(String handlerName)
    throws ProcessingException;

    /**
     * Is the current user authenticated for the given handler?
     * If the user is already authenticated, the {@link RequestState}
     * is updated to the provided information (handler and application).
     */
    boolean checkAuthentication(Redirector redirector,
                                 String     handlerName,
                                 String     applicationName)
    throws ProcessingException, IOException;

    /**
     * Try to login the user.
     * If the authentication is successful, the user handler is returned.
     * If not, <code>null</code> is returned.
     */
    UserHandler login(String              handlerName,
                      String              applicationName,
                      SourceParameters    parameters)
    throws ProcessingException;

    /**
     * Perform a logout of the user.
     */
    void logout(String handlerName,
                 int mode)
    throws ProcessingException;

    /**
     * Get the current state of authentication
     */
    RequestState getState();

    /**
     * Create Application Context.
     * This context is destroyed when the user logs out of the handler
     */
    SessionContext createApplicationContext(String name,
                                            String loadURI,
                                            String saveURI)
    throws ProcessingException;
}
ackage org.apache.cocoon.webapps.authentication;

/**
 * The <code>Constants</code> used throughout the core of the authentication
 * framework.
 *
 * @deprecated This block is deprecated and will be removed in future versions.
 * @version $Id: AuthenticationConstants.java 587757 2007-10-24 02:52:49Z vgritsenko $
 */
public interface AuthenticationConstants {

    /** The name of the authentication context. */
    String SESSION_CONTEXT_NAME = "authentication";

    /** Logout mode: session is terminated immediately */
    int LOGOUT_MODE_IMMEDIATELY = 0;
    
    /** Logout mode: session is terminated if not used anymore (by the 
     * session or the authentication framework */
    int LOGOUT_MODE_IF_UNUSED = 1;

    /** Logout mode: session is terminated if the user is not authenticated
     * to any handler anymore. */
    int LOGOUT_MODE_IF_NOT_AUTHENTICATED = 2;
}

