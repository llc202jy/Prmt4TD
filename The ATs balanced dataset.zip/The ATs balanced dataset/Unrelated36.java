package pkiva.validation.connectors;


import javax.naming.NamingException;
import javax.naming.Reference;
import javax.resource.ResourceException;
import javax.resource.cci.Connection;
import javax.resource.cci.ConnectionFactory;
import javax.resource.cci.ConnectionSpec;
import javax.resource.cci.RecordFactory;
import javax.resource.cci.ResourceAdapterMetaData;
import javax.resource.spi.ConnectionManager;
import javax.resource.spi.ManagedConnectionFactory;

public class CertValidationChannelConnectionFactoryImpl implements ConnectionFactory
{
  
  private Reference reference;
  private ConnectionManager cm;
  private ManagedConnectionFactory mcf;
  
  
  public CertValidationChannelConnectionFactoryImpl(ManagedConnectionFactory mcf,ConnectionManager cm)
  {
    super();
    this.mcf = mcf;
    this.cm = cm;
  }
  public Connection getConnection() throws ResourceException
  {
    return (Connection) cm.allocateConnection(mcf, null);
  }
  
  public Connection getConnection(ConnectionSpec connectionSpec) throws ResourceException
  {
    return getConnection();
  }
  
  //abstract public RecordFactory getRecordFactory() throws ResourceException ;
  public RecordFactory getRecordFactory() throws ResourceException
  {
    return new CertValidationChannelRecordFactoryImpl();
  }
  
  public ResourceAdapterMetaData getMetaData() throws ResourceException
  {
    return new CertValidationChannelResourceAdapterMetaDataImpl();
  }
  
  public void setReference(Reference reference)
  {
    this.reference = reference;
  }
  
  public Reference getReference() throws NamingException
  {
    return reference;
  }
  
}

package pkiva.validation.connectors;

import java.security.cert.*;
import javax.resource.NotSupportedException;
import javax.resource.ResourceException;
import javax.resource.cci.Connection;
import javax.resource.cci.Interaction;
import javax.resource.cci.InteractionSpec;
import javax.resource.cci.Record;
import javax.resource.cci.IndexedRecord;
import javax.resource.cci.ResourceWarning;
import java.lang.reflect.Proxy;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.*;

import pkiva.validation.crl.*;

abstract public class CertValidationChannelInteractionImpl implements Interaction
{
  //protected static String CHANNELSTR="";
  //private static final int CERTIFICATE_FIELD = 0;
  private static final int SELECTOR_FIELD = 0;
  private static final String CLOSED_ERROR = "Connection closed";
  private static final String INVALID_FUNCTION_ERROR = "Invalid function";
  private static final String INVALID_INPUT_ERROR = "Invalid input record for function";
  private static final String INVALID_OUTPUT_ERROR = "Invalid output record for function";
  private static final String EXECUTE_WITH_INPUT_RECORD_ONLY_NOT_SUPPORTED = "execute() with input record only not supported";
  
  private Connection connection;
  private boolean valid;
  
  public CertValidationChannelInteractionImpl(Connection connection)
  {
    super();
    this.connection = connection;
    valid = true;
  }
  
  public void close() throws ResourceException
  {
    connection = null;
    valid = false;
  }
  
  public Connection getConnection()
  {
    return connection;
  }
  
    /*public boolean execute(InteractionSpec ispec, Record input, Record output) throws ResourceException {
     
       if (valid) {
        String strOperation="";
           try{
           java.lang.reflect.Method m=ispec.getClass().getMethod("getFunctionName",new Class[0]);
           strOperation=(String)m.invoke(ispec,new Object[0]);
        }catch(Exception e){
            throw new ResourceException("Exception in resource adapter when invoking getFunctionName");
        }
     
        boolean bReturn=false;
        boolean isValidFunction=false;
     
        if (strOperation.equals(CertValidationChannelInteractionSpec.IS_REVOKED_FUNCTION)) {
            isValidFunction=true;
            X509Certificate cert=(X509Certificate)((CertValidationChannelIndexedRecord)input).get(CERTIFICATE_FIELD);
            bReturn=!validateCertificate(cert);
        }
        if (isValidFunction)
           addOutputValue(input,output,new Boolean(bReturn));
        else
           throw new ResourceException(INVALID_FUNCTION_ERROR);
      } else {
            throw new ResourceException(CLOSED_ERROR);
        }
        return true;
    }*/
  
  public boolean execute(InteractionSpec ispec, Record input, Record output) throws ResourceException
  {
    
    if (valid)
    {
      String strOperation="";
      try
      {
        java.lang.reflect.Method m=ispec.getClass().getMethod("getFunctionName",new Class[0]);
        strOperation=(String)m.invoke(ispec,new Object[0]);
      }
      catch(Exception e)
      {
      // javax.resource.ResourceException does not support chained Exceptions
        throw new ResourceException("Exception in resource adapter when invoking getFunctionName:" + e.getMessage());
      }
      
      pkiva.log.LogManager.getLogger(this.getClass()).debug("Request to execute. Function Name: " + strOperation);
      
      if (strOperation.equals(CertValidationChannelInteractionSpec.GET_CRLS_FUNCTION))
      {
        CRLSelector sel = (CRLSelector)((IndexedRecord)input).get(SELECTOR_FIELD);
        CRLValidationResponse resp = getCRLs( sel );
        addOutputValue(input,output,resp);
      }
      /*else if (strOperation.equals(CertValidationChannelInteractionSpec.INIT_FUNCTION))
      {
        // TODO: call 2 init function
        //addOutputValue(input,output, null);
      }*/
      else
      {
        pkiva.log.LogManager.getLogger(this.getClass()).error("Invalid request to execute. Function not supported: " + strOperation);
        throw new ResourceException(INVALID_FUNCTION_ERROR);
      }
    } 
    else
    {
      throw new ResourceException(CLOSED_ERROR);
    }
    return true;
  }
  
  public Record execute(InteractionSpec ispec, Record input) throws ResourceException
  {
    throw new NotSupportedException(EXECUTE_WITH_INPUT_RECORD_ONLY_NOT_SUPPORTED);
  }
  
  public ResourceWarning getWarnings() throws ResourceException
  {
    return null;
  }
  public void clearWarnings() throws ResourceException
  {
  }
  
  protected void addOutputValue(Record input, Record output,Object outval) throws ResourceException
  {
    
    if (input.getRecordName().equals(CertValidationChannelIndexedRecord.INPUT))
    {
      if (output.getRecordName().equals(CertValidationChannelIndexedRecord.OUTPUT))
      {
        ((CertValidationChannelIndexedRecord) output).clear();
        ((CertValidationChannelIndexedRecord) output).add(outval);
      } else
      {
        throw new ResourceException(INVALID_OUTPUT_ERROR);
      }
    } else
    {
      throw new ResourceException(INVALID_INPUT_ERROR);
    }
    
    
  }
  
  //abstract protected boolean validateCertificate(X509Certificate Certificate)  throws ResourceException;
  
  abstract protected CRLValidationResponse getCRLs(CRLSelector sel) throws ResourceException;
  
  //abstract protected void init( ) throws ResourceException;
  
  
}

package pkiva.validation.connectors;

import pkiva.validation.crl.CRLManager;

import java.util.Hashtable;
import java.util.Collection;
import java.util.Date;
import java.beans.PropertyChangeSupport;
import java.security.cert.CRLSelector;
import javax.naming.Name;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.NameParser;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.DirContext;
import javax.naming.directory.Attributes;
import javax.resource.ResourceException;

/**
 *
 * @author  Scott.Stark@jboss.org
 * @version $Revision: 1.5 $
 */
public class CRLJBDirContextImpl implements CRLJBDirContext
{
   CRLJBManagedConnection mc;

   /** Creates new FSDirContext */
   public CRLJBDirContextImpl(CRLJBManagedConnection mc)
   {
      this.mc = mc;
   }

   protected void setManagedConnection(CRLJBManagedConnection mc)
   {
      this.mc = mc;
   }

   public Attributes getAttributes(Name name, String[] str) throws NamingException
   {
      return null;
   }
   
   public void close() throws NamingException
   {
//      pkiva.log.LogManager.getLogger(this.getClass()).debug("#### %%%% LDAPJBDirContextImpl close");
      mc.close();
   }

   public NamingEnumeration list(String str) throws NamingException
   {
      return null;
   }
   
   public void unbind(Name name) throws NamingException
   {
   }
   
   public DirContext getSchemaClassDefinition(Name name) throws NamingException
   {
      return null;
   }
   
   public DirContext createSubcontext(String str, Attributes attributes) throws NamingException
   {
      return null;
   }
   
   public String getNameInNamespace() throws NamingException
   {
      return null;
   }
   
   public Object addToEnvironment(String str, Object obj) throws NamingException
   {
      return null;
   }
   
   public NamingEnumeration listBindings(Name name) throws NamingException
   {
      return null;
   }
   
   public void bind(Name name, Object obj) throws NamingException
   {
   }
   
   public NamingEnumeration search(String str, Attributes attributes, String[] str2) throws NamingException
   {
      return null;
   }
   
   public void modifyAttributes(Name name, int param, Attributes attributes) throws NamingException
   {
   }
   
   public Hashtable getEnvironment() throws NamingException
   {
      return null;
   }
   
   public void bind(String str, Object obj) throws NamingException
   {
   }
   
   public void rebind(String str, Object obj, Attributes attributes) throws NamingException
   {
   }
   
   public DirContext getSchema(Name name) throws NamingException
   {
      return null;
   }
   
   public DirContext getSchemaClassDefinition(String str) throws NamingException
   {
      return null;
   }
   
   public Object lookup(String str) throws NamingException
   {
      return null;
   }
   
   public void destroySubcontext(String str) throws NamingException
   {
   }
   
   public Context createSubcontext(Name name) throws NamingException
   {
      return null;
   }
   
   public Object lookupLink(String str) throws NamingException
   {
      return null;
   }
   
   public DirContext getSchema(String str) throws NamingException
   {
      return null;
   }
   
   public Object lookup(Name name) throws NamingException
   {
      return null;
   }
   
   public void destroySubcontext(Name name) throws NamingException
   {
   }
   
   public NamingEnumeration listBindings(String str) throws NamingException
   {
      return null;
   }
   
   public void rebind(String str, Object obj) throws NamingException
   {
   }
   
   public Object removeFromEnvironment(String str) throws NamingException
   {
      return null;
   }
   
   public void bind(String str, Object obj, Attributes attributes) throws NamingException
   {
   }
   
   public NamingEnumeration search(Name name, Attributes attributes) throws NamingException
   {
      return null;
   }
   
   public NameParser getNameParser(String str) throws NamingException
   {
      return null;
   }
   
   public void bind(Name name, Object obj, Attributes attributes) throws NamingException
   {
   }
   
   public Attributes getAttributes(String str) throws NamingException
   {
      return null;
   }
   
   public void rename(String str, String str1) throws NamingException
   {
   }
   
   public void rename(Name name, Name name1) throws NamingException
   {
   }
   
   public DirContext createSubcontext(Name name, Attributes attributes) throws NamingException
   {
      return null;
   }
   
   public void rebind(Name name, Object obj, Attributes attributes) throws NamingException
   {
   }
   
   public NamingEnumeration list(Name name) throws NamingException
   {
      return null;
   }
   
   public Context createSubcontext(String str) throws NamingException
   {
      return null;
   }
   
   public void modifyAttributes(String str, int param, Attributes attributes) throws NamingException
   {
   }
   
   public NamingEnumeration search(String str, Attributes attributes) throws NamingException
   {
      return null;
   }
   
   public Name composeName(Name name, Name name1) throws NamingException
   {
      return null;
   }
   
   public String composeName(String str, String str1) throws NamingException
   {
      return null;
   }
   
   public NamingEnumeration search(Name name, Attributes attributes, String[] str) throws NamingException
   {
      return null;
   }
   
   public void rebind(Name name, Object obj) throws NamingException
   {
   }
   
   public void modifyAttributes(Name name, ModificationItem[] modificationItem) throws NamingException
   {
   }
   
   public NamingEnumeration search(Name name, String str, SearchControls searchControls) throws NamingException
   {
      return null;
   }
   
   public NamingEnumeration search(Name name, String str, Object[] obj, SearchControls searchControls) throws NamingException
   {
      return null;
   }
   
   public void unbind(String str) throws NamingException
   {
   }
   
   public void modifyAttributes(String str, ModificationItem[] modificationItem) throws NamingException
   {
   }
   
   public Attributes getAttributes(Name name) throws NamingException
   {
      return null;
   }
   
   public Object lookupLink(Name name) throws NamingException
   {
      return null;
   }
   
   public NameParser getNameParser(Name name) throws NamingException
   {
      return null;
   }
   
   public Attributes getAttributes(String str, String[] str1) throws NamingException
   {
      return null;
   }
   
   public NamingEnumeration search(String str, String str1, SearchControls searchControls) throws NamingException
   {
      return null;
   }
   
   public NamingEnumeration search(String str, String str1, Object[] obj, SearchControls searchControls) throws NamingException
   {
      return null;
   }

    // JCA Specific methods:
    public Object execute(String strOperation) throws ResourceException
    {
        return execute(strOperation, null);
    }

    public Object execute(String strOperation, Object params) throws ResourceException
    {

//        pkiva.log.LogManager.getLogger(this.getClass()).debug("#### %%%% Request to execute. Function Name: " + strOperation);

        Object returnObj = null;

        if (strOperation.equals(GET_CRLS_FUNCTION))
        {
            returnObj = getCRLs( (CRLSelector) params );
        }
        else
        {
          pkiva.log.LogManager.getLogger(this.getClass()).error("Invalid request to execute. Function not supported: " + strOperation);
          throw new ResourceException( "Invalid request to execute. Function not supported: " + strOperation);
        }

      return returnObj;
    }

    // PKIVA Specific methods:
    protected CRLValidationResponse getCRLs(CRLSelector sel)
    {
      CRLValidationResponse crlResponse = null;

      try
      {
        Collection col = CRLManager.instance().getCRLs(sel);
        if ( col != null )
          crlResponse = new CRLValidationResponse ( col );
      }
      catch(Exception e)
      {
        pkiva.log.LogManager.getLogger(this.getClass()).debug("Top level.getting CRLs:" + e);
        crlResponse = new CRLValidationResponse ( e );
      }

      return crlResponse;
    }
}

package pkiva.validation.connectors;

import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Vector;

import javax.resource.NotSupportedException;
import javax.resource.ResourceException;
import javax.resource.spi.ConnectionEvent;
import javax.resource.spi.ConnectionEventListener;
import javax.resource.spi.ConnectionRequestInfo;
import javax.resource.spi.LocalTransaction;
import javax.resource.spi.ManagedConnection;
import javax.resource.spi.ManagedConnectionMetaData;
import javax.security.auth.Subject;
import javax.transaction.xa.XAResource;

abstract public class CertValidationChannelManagedConnectionImpl implements ManagedConnection
{
  
  private static final String TRANSACTIONS_NOT_SUPPORTED_ERROR =	"Transactions not supported";
  protected CertValidationChannelConnectionImpl connection;
  private Vector listeners = new Vector();
  private PrintWriter out;
  
  public CertValidationChannelManagedConnectionImpl()
  {
    super();
  }
  
  public void close()
  {

//      [org.jboss.resource.connectionmanager.NoTxConnectionManager] Throwable from unregisterConnection
//      java.lang.IllegalStateException: Trying to return an unknown connection2! javax.resource.spi.ConnectionEvent[source=pkiva.ldap.connectors.LDAPManagedConnectionImpl@19ffd6f]
//          at org.jboss.resource.connectionmanager.CachedConnectionManager.unregisterConnection(CachedConnectionManager.java:374)
//      [org.jboss.resource.connectionmanager.NoTxConnectionManager] Unregistered handle that was not registered! javax.resource.spi.ConnectionEvent[source=pkiva.ldap.connectors.LDAPManagedConnectionImpl@19ffd6f] for managedConnection: pkiva.ldap.connectors.LDAPManagedConnectionImpl@19ffd6f

    Enumeration list = listeners.elements();
    ConnectionEvent event =	new ConnectionEvent(this, ConnectionEvent.CONNECTION_CLOSED);
    event.setConnectionHandle(connection);
    while (list.hasMoreElements())
    {
      ((ConnectionEventListener) list.nextElement()).connectionClosed(event);
    }
      if ( connection != null )
      connection.invalidate();

//      2005-03-15 15:47:40,269 INFO  [org.jboss.resource.connectionmanager.CachedConnectionManager] Closing a connection for you.  Please close them yourself: pkiva.ldap.connectors.LDAPConnectionImpl@11ce012
//      java.lang.Exception: STACKTRACE
//          at org.jboss.resource.connectionmanager.CachedConnectionManager.registerConnection(CachedConnectionManager.java:320)
//          at org.jboss.resource.connectionmanager.BaseConnectionManager2.allocateConnection(BaseConnectionManager2.java:477)
//          at org.jboss.resource.connectionmanager.BaseConnectionManager2$ConnectionManagerProxy.allocateConnection(BaseConnectionManager2.java:838)
//          at pkiva.ldap.connectors.LDAPConnectionFactoryImpl.getConnection(Unknown Source)
   
  }
  
  abstract public Object getConnection(Subject subject,ConnectionRequestInfo cxRequestInfo) throws ResourceException ;
    /*public Object getConnection(Subject subject,ConnectionRequestInfo cxRequestInfo) throws ResourceException {
        connection = new CertValidationChannelConnectionImpl(this);
        return connection;
    }*/
  
  public void destroy() throws ResourceException
  {
    if ( connection != null )
      connection.invalidate();
    connection = null;
    listeners = null;
  }
  
  public void cleanup() throws ResourceException
  {
    if ( connection != null )
      connection.invalidate();
  }
  
  public void associateConnection(Object connection) throws ResourceException
  {
  }
  
  public void addConnectionEventListener(ConnectionEventListener listener)
  {
    listeners.add(listener);
  }
  
  public void removeConnectionEventListener(ConnectionEventListener listener)
  {
    listeners.remove(listener);
  }
  
  public XAResource getXAResource() throws ResourceException
  {
    throw new NotSupportedException(TRANSACTIONS_NOT_SUPPORTED_ERROR);
  }
  
  public LocalTransaction getLocalTransaction() throws ResourceException
  {
    throw new NotSupportedException(TRANSACTIONS_NOT_SUPPORTED_ERROR);
  }
  
  public ManagedConnectionMetaData getMetaData() throws ResourceException
  {
    return new CertValidationChannelManagedConnectionMetaDataImpl(connection.getMetaData());
  }
  
  public void setLogWriter(PrintWriter out) throws ResourceException
  {
    this.out = out;
  }
  
  public PrintWriter getLogWriter() throws ResourceException
  {
    return out;
  }
  
}
package pkiva.validation.connectors;

import javax.resource.ResourceException;
import javax.resource.cci.Interaction;
import javax.resource.spi.ManagedConnection;

public class CRLCVCConnectionImpl extends CertValidationChannelConnectionImpl
{
  
  public CRLCVCConnectionImpl(ManagedConnection mc)
  {
    super(mc);
  }
  
  public Interaction createInteraction() throws ResourceException
  {
    if (valid)
      return new CRLCVCInteractionImpl(this);
    else
      throw new ResourceException(CLOSED_ERROR);
  }
  
}
public class CertValidationChannelInteractionSpecProxy implements java.lang.reflect.InvocationHandler
{
  
  private Object obj;
  
  public static Object newInstance(Object obj)
  {
    Object ret= java.lang.reflect.Proxy.newProxyInstance(
    CertValidationChannelInteractionSpec.class.getClassLoader(),
    new Class[]
    { CertValidationChannelInteractionSpec.class },
    new CertValidationChannelInteractionSpecProxy(obj));
    return ret;
  }
  
  private CertValidationChannelInteractionSpecProxy(Object obj)
  {
    this.obj = obj;
  }
  
  public Object invoke(Object proxy, Method m, Object[] args)	throws Throwable
  {
    Object result;
    try
    {
      result = m.invoke(obj, args);
    } catch (InvocationTargetException e)
    {
      throw e.getTargetException();
    }
    return result;
  }
}
