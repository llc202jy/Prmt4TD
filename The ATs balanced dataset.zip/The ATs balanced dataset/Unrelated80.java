package com.kylietech.oaj.server.logic.orders;

import java.util.*;

import net.javalib.util.vl.*;

import org.springframework.beans.*;

import com.kylietech.oaj.common.util.*;
import com.kylietech.oaj.server.domain.orders.*;
import com.kylietech.oaj.server.domain.party.relationship.*;
import com.kylietech.oaj.server.logic.party.*;
import com.kylietech.oaj.server.util.*;
import com.kylietech.oaj.types.*;

public class BaseOrderUtil {
	
	// ----------------------------------------------------------------------------------------------------------------------------------	

	public static boolean isClosed(BaseOrder order) {
		return order.getStatus().equals(OrderStatus._CLOSED);
	}
	
	public static boolean isOpen(BaseOrder order) {
		return order.getStatus().equals(OrderStatus._OPEN);
	}	
	
	// ----------------------------------------------------------------------------------------------------------------------------------
	
    /**
     * Returns a <tt>List</tt> of BaseOrder filtered by options.
     * @param options Options to filter by.
	 * @param orderClass class of order (PurchaseOrder.class, SalesOrder.class, etc)
     * @return <tt>List</tt> of BaseOrder filtered by options.
     */
	protected static List getOrderSummary(QueryOptions options, Class orderClass) {
        ValueListInfo info = new ValueListInfo();       
        options.copyTo(info);
        return OADomainUtil.getAll(orderClass, info);
    }	
	
    /**
     * Returns a <tt>List</tt> of BaseOrder filtered by options.
     * @param options Options to filter by.
	 * @param orderClass class of order (PurchaseOrder.class, SalesOrder.class, etc)
     * @return <tt>List</tt> of BaseOrder filtered by options.
     */
	public static List getOpenOrderSummary(ValueListInfo info, Class orderClass) {
        addIsOrderOpenFilter(info); 
        return OADomainUtil.getAll(orderClass, info);
    }		
	
    /**
     * Returns a <tt>List</tt> of OrderLineProduct filtered by options.
     * @param options Options to filter by.
	 * @param orderClass class of order (PurchaseOrder.class, SalesOrder.class, etc)
     * @return <tt>List</tt> of OrderLineProduct filtered by options.
     */
	protected static List getOrderLines(ValueListInfo info, QueryOptions options, Class orderClass) {
        if (info == null)
        	info = new ValueListInfo();
        addParentIsOfOrderClassFilter(info, orderClass);
        info.addSortColumn(OABeanUtil.POSITION_FIELD, ColumnSort.ASC);        
        info.addSortColumn("parent.id", ColumnSort.ASC);
        if (options != null) {
	        options.setPropertyPrefix("parent.");        
	        options.copyTo(info);
        }
        
        return OADomainUtil.getAll(OrderLineProduct.class, info);
    }    	
	
    /**
     * Returns a <tt>List</tt> of <tt>BaseOrder</tt> that can be closed. 
     * Checks every position of selected (and open) POs whether ordered quantity=delivered quantity.
     * @param options Options to filter by (can be null).
	 * @param orderClass class of order (PurchaseOrder.class, SalesOrder.class, etc)
     * @return <tt>List</tt> of <tt>BaseOrder</tt> that can be closed. 
     * Checks every position of selected (and open) POs whether ordered quantity=delivered quantity.
     */
	protected static List getCompletedOrderSummary(ValueListInfo info, Class orderClass) {
        addIsOrderOpenFilter(info); 
        
        Iterator poi =  OADomainUtil.getAll(orderClass, info).iterator();
        Vector v = new Vector();
        
        while (poi.hasNext()) {
            BaseOrder order = (BaseOrder)poi.next();
            Iterator i = order.getLines().iterator();
            boolean canClose = true;
            
            while (i.hasNext()) {
                OrderLineProduct line = (OrderLineProduct)i.next();
                if (line.getQuantityDelivered().doubleValue() < line.getQuantity().doubleValue()) {
                    canClose = false;
                    break;
                }
            }
            
            if (canClose)
                v.add(order);
        }
        return v;
    }  	
	
	/**
	 * Return OrderLineProduct lines that can be closed, where ordered quantity=delivered quantity
	 * @param orderClass class of order (PurchaseOrder.class, SalesOrder.class, etc)
	 * @return List of OrderLineProduct lines that can be closed
	 */
	public static List getCompletedOrderLines(ValueListInfo info, Class orderClass) {
		List canCloseList = new Vector();

		info.addFilterNamedParam(OABeanUtil.CLOSED_FIELD, Op.EQUALS, "0");
		info.addSortColumn("parent.ref", ColumnSort.ASC);
		addParentIsOfOrderClassFilter(info, orderClass);
		List openPos = OADomainUtil.getAll(OrderLineProduct.class, info);
		Iterator i = openPos.iterator();
		while (i.hasNext()) {
			OrderLineProduct line = (OrderLineProduct)i.next();
	        
	        if (line.getQuantity().doubleValue() == line.getQuantityDelivered().doubleValue())
	        	canCloseList.add(line);
		}	
		return canCloseList;		
	}	
	
	// ----------------------------------------------------------------------------------------------------------------------------------
	
	/**
	 * Adds is-BaseOrder-open filter options to a ValueListInfo (adds BaseOrder.status = OrderStatus._OPEN)
	 * @param info The ValueListInfo to modify
	 */
	public static void addIsOrderOpenFilter(ValueListInfo info) {
		info.addFilterNamedParam(OABeanUtil.STATUS_FIELD, Op.EQUALS, OrderStatus._OPEN, OAQueryUtil.hibCustomType(OrderStatusUserType.class));
	}	
	
	protected static void addParentIsOfOrderClassFilter(ValueListInfo info, Class orderClass) {
		BaseOrder order = (BaseOrder)BeanUtils.instantiateClass(orderClass);
		info.addFilterNamedParam("parent.clazz", Op.EQUALS, order.getDiscriminatorValue());
	}
	
	// ----------------------------------------------------------------------------------------------------------------------------------
	
	public static void updateTotal(BaseOrder order) {
		double total = 0;
		Iterator i = order.getLines().iterator();
		// add all the lines
		while (i.hasNext()) {
			OrderLine line = (OrderLine)i.next();
			line.updateTotal();
			total += line.getTotal().doubleValue();
		}
		
		// add shipment charge
		total += order.getShippingAmount().doubleValue();
		// add tax
		total += order.getTax().doubleValue();
		// set total in the order
		order.setTotal(new Double(total));		
	}
	
	// ----------------------------------------------------------------------------------------------------------------------------------
	
	public static void copyPartyRelationshipDefaults(BaseOrder order, PartyRelationship relationship) {
		if (relationship != null) {
			order.setCurrency(relationship.getCurrency());
			order.setPaymentTerm(relationship.getPaymentTerm());
			order.setPaymentType(relationship.getPaymentType());
			order.setShipmentType(relationship.getShipmentType());
			order.setShippedBy(relationship.getShipper());
			order.setTaxAuthority(relationship.getTaxAuthority());
		}
	}
	
	public static void handleSupplierPropertyChange(BaseOrder order, String property) {
		// supplier has changed. copy supplier defaults to quote
		if (OABeanUtil.TAKENBY_FIELD.equals(property)) {
			BaseOrderUtil.copyPartyRelationshipDefaults(order, PartyUtil.getSupplierRelationship(order.getTakenBy()));
		}		
	}
	
	public static void handleCustomerPropertyChange(BaseOrder order, String property) {
		// customer has changed. copy customer defaults to quote
		if (OABeanUtil.PLACEDBY_FIELD.equals(property)) {
			BaseOrderUtil.copyPartyRelationshipDefaults(order, PartyUtil.getCustomerRelationship(order.getPlacedBy()));
		}		
	}	
	
}
