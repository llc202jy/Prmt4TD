 * This is a login module that works as a central dispatcher for all other configurable
 * login modules.
 *
 * @author Carlos Munoz <a href="mailto:camunoz@redhat.com">camunoz@redhat.com</a>
 */
public class ZanataCentralLoginModule implements LoginModule
{

   private String internalAuthDomain;
   private String kerberosDomain;
   private String openIdDomain;
   private String jaasDomain;

   private Subject subject;
   private CallbackHandler callbackHandler;

   @Override
   public void initialize(Subject subject, CallbackHandler callbackHandler, Map<String, ?> sharedState, Map<String, ?> options)
   {
      this.subject = subject;
      this.callbackHandler = callbackHandler;

      JndiBackedConfig jndiConfig = (JndiBackedConfig) Component.getInstance(JndiBackedConfig.class);

      internalAuthDomain = jndiConfig.getAuthPolicyName(AuthenticationType.INTERNAL.name().toLowerCase());
      kerberosDomain = jndiConfig.getAuthPolicyName(AuthenticationType.KERBEROS.name().toLowerCase());
      openIdDomain = jndiConfig.getAuthPolicyName(AuthenticationType.OPENID.name().toLowerCase());
      jaasDomain = jndiConfig.getAuthPolicyName(AuthenticationType.JAAS.name().toLowerCase());
   }

   @Override
   public boolean login() throws LoginException
   {
      AuthenticationTypeCallback authTypeCallback = new AuthenticationTypeCallback();

      // Get the authentication type
      try
      {
         callbackHandler.handle(new Callback[]{authTypeCallback});
      }
      catch( UnsupportedCallbackException ucex )
      {
         // This happens on kerberos authentication
         // NB: A custom callback handler could be configured on the app server to avoid this.
         authTypeCallback.setAuthType( AuthenticationType.KERBEROS );
      }
      catch (Exception e)
      {
         LoginException lex = new LoginException(e.getMessage());
         lex.initCause(e);
         throw lex;
      }
      AuthenticationType authType = authTypeCallback.getAuthType();

      String delegateName = null;
      switch (authType)
      {
         case INTERNAL:
            delegateName = internalAuthDomain;
            break;
         case KERBEROS:
            delegateName = kerberosDomain;
            break;
         case OPENID:
            delegateName = openIdDomain;
            break;
         case JAAS:
            delegateName = jaasDomain;
            break;
      }

      LoginContext delegate = new LoginContext(delegateName, subject, callbackHandler);
      delegate.login();
      return true;
   }

   @Override
   public boolean commit() throws LoginException
   {
      return true;
   }

   @Override
   public boolean abort() throws LoginException
   {
      return true;
   }

   @Override
   public boolean logout() throws LoginException
   {
      return true;
   }
}