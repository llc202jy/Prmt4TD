public class GlobalContextFactory {
	private final String connector;
	private final String url;
	
	public GlobalContextFactory() {
		ResourceBundle bundle = ResourceBundle.getBundle("application");
		
		this.connector = bundle.getString("connector");
		this.url = bundle.getString("url");
	}
	
	public GlobalContext getContext() {
		COMConnector con = new COMConnector(connector);

		return con.connect(url);
	}
	
	public void recycleContext(GlobalContext context) {
		// Nothing to do right now
		// In pooling here must be recycle methods
	}
}