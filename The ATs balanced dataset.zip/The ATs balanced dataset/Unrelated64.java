import com.uwyn.rife.database.exceptions.RollbackException;
import com.uwyn.rife.tools.ExceptionUtils;
import com.uwyn.rife.tools.InnerClassException;
import java.util.logging.Logger;

/**
 * By extending this class it's possible to provide the logic that should be
 * executed by the {@link DbQueryManager#inTransaction(DbTransactionUser) inTransaction}
 * method in the {@link DbQueryManager} class.
 * <p>This class has both a default constructor and one that can take a data
 * object. This can be handy when using it as an extending anonymous inner
 * class when you need to use variables inside the inner class that are
 * cumbersome to change to <code>final</code> in the enclosing class.
 * 
 * @author Geert Bevin (gbevin[remove] at uwyn dot com)
 * @version $Revision: 3884 $
 * @see DbQueryManager#inTransaction(DbTransactionUser)
 * @since 1.0
 */
public abstract class DbTransactionUser<ResultType, DataType> implements Cloneable
{
	protected DataType  mData = null;
	
	public DbTransactionUser()
	{
	}
	
	public DbTransactionUser(DataType data)
	{
		mData = data;
	}
	
	public DataType getData()
	{
		return mData;
	}
	
	/**
	 * Should be overridden if the transaction has to be executed in another
	 * isolation level.
	 * 
	 * @return <code>-1</code> when the active isolation level should be
	 * preserved; or
	 * <p>a level constant from {@link java.sql.Connection Connection} if the
	 * isolation needs to be changed.
	 * @since 1.0
	 */
	public int getTransactionIsolation()
	{
		return -1;
	}
	
	/**
	 * Should be used to roll back ongoing transactions, otherwise enclosing
	 * transaction users might not be interrupted and subsequent modification
	 * can still happen outside the transaction.
	 * 
	 * @exception RollbackException indicates that a rollback should happen
	 * and all further transaction logic interrupted.
	 * @since 1.0
	 */
	public void rollback()
	throws RollbackException
	{
		throw new RollbackException();
	}
	
	/**
	 * Calling this method makes it possible to throw a checked exception from
	 * within this class.
	 * <p>To catch it you should surround the {@link
	 * DbQueryManager#inTransaction(DbTransactionUser) inTransaction} with a
	 * <code>try-catch</code> block that catching
	 * <code>InnerClassException</code>. The original exception is then
	 * available through <code>getCause()</code> and can for example be
	 * rethrown.
	 * 
	 * @exception InnerClassException when a checked exception needs to be
	 * thrown from within this class and caught outside the caller.
	 * @since 1.0
	 */
	public void throwException(Exception exception)
	throws InnerClassException
	{
		throw new InnerClassException(exception);
	}
	
	/**
	 * Should be implemented by all extending classes.
	 * 
	 * @since 1.0
	 */
	public abstract ResultType useTransaction() throws InnerClassException;

	/**
	 * Simply clones the instance with the default clone method since this
	 * class contains no member variables.
	 * 
	 * @since 1.0
	 */
	public Object clone()
	{
		try
		{
			return super.clone();
		}
		catch (CloneNotSupportedException e)
		{
			// this should never happen
			Logger.getLogger("com.uwyn.rife.database").severe(ExceptionUtils.getExceptionStackTrace(e));
			return null;
		}
	}
}/*
 * Copyright 2001-2007 Geert Bevin <gbevin[remove] at uwyn dot com>
 * Licensed under the Apache License, Version 2.0 (the "License")
 * $Id: DbResultSetHandler.java 3877 2007-08-03 19:48:10Z gbevin $
 */
package com.uwyn.rife.database;

import com.uwyn.rife.database.queries.Query;
import com.uwyn.rife.tools.ExceptionUtils;
import java.sql.SQLException;
import java.util.logging.Logger;

/**
 * By extending this class it's possible to easily customize the behaviour of
 * some methods in the {@link DbQueryManager} class.
 * <p>You're able to perform custom logic with the resultset of a query by
 * overriding the {@link #concludeResults(DbResultSet) concludeResults} method
 * and returning an object.
 * <p>You're not supposed to close the resultset in this method.
 * 
 * @author Geert Bevin (gbevin[remove] at uwyn dot com)
 * @version $Revision: 3877 $
 * @see DbResultSet
 * @see DbQueryManager
 * @since 1.0
 */
public abstract class DbResultSetHandler implements Cloneable
{
	public DbStatement createStatement(DbConnection connection)
	{
		return connection.createStatement();
	}

	public DbPreparedStatement getPreparedStatement(Query query, DbConnection connection)
	{
		return connection.getPreparedStatement(query);
	}

	public Object concludeResults(DbResultSet resultset)
	throws SQLException
	{
		return null;
	}

	/**
	 * Simply clones the instance with the default clone method since this
	 * class contains no member variables.
	 * 
	 * @since 1.0
	 */
	public Object clone()
	{
		try
		{
			return super.clone();
		}
		catch (CloneNotSupportedException e)
		{
			// this should never happen
			Logger.getLogger("com.uwyn.rife.database").severe(ExceptionUtils.getExceptionStackTrace(e));
			return null;
		}
	}
}/*
 * Copyright 2001-2007 Geert Bevin <gbevin[remove] at uwyn dot com>
 * Distributed under the terms of either:
 * - the common development and distribution license (CDDL), v1.0; or
 * - the GNU Lesser General Public License, v2.1 or later
 * $Id: LightweightException.java 3705 2007-03-28 20:00:24Z gbevin $
 */
package com.uwyn.rife.tools.exceptions;

import com.uwyn.rife.config.RifeConfig;

public class LightweightException extends Error
{
	private static final long serialVersionUID = -6077740593752636392L;
	
	public LightweightException()
	{
		super();
	}
	
	public LightweightException(String message)
	{
		super(message);
	}
	
	public LightweightException(String message, Throwable cause)
	{
		super(message, cause);
	}
	
	public LightweightException(Throwable cause)
	{
		super(cause);
	}
	
	public Throwable fillInStackTrace()
	{
		if (RifeConfig.Global.getUseFastExceptions())
		{
			return null;
		}
		else
		{
			return super.fillInStackTrace();
		}
    }
	
    public StackTraceElement[] getStackTrace()
	{
		if (RifeConfig.Global.getUseFastExceptions())
		{
			return new StackTraceElement[0];
		}
		else
		{
			return super.getStackTrace();
		}
    }
} Primitive Collections for Java.
 *  Copyright (C) 2002  S?ren Bak
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.uwyn.rife.pcj.hash;

/**
 *  This interface represents hash functions from int values
 *  to int values. The int value result is chosen to achieve
 *  consistence with the common
 *  {@link Object#hashCode() hashCode()}
 *  method. The interface is provided to alter the hash functions used
 *  by hashing data structures, like
 *  {@link com.uwyn.rife.pcj.map.IntKeyIntChainedHashMap IntKeyIntChainedHashMap}
 *  or
 *  {@link com.uwyn.rife.pcj.set.IntChainedHashSet IntChainedHashSet}.
 *
 *  @see        DefaultIntHashFunction
 *
 *  @author     S&oslash;ren Bak
 *  @version    1.0     2002/29/12
 *  @since      1.0
 */
public interface IntHashFunction {

    /**
     *  Returns a hash code for a specified int value.
     *
     *  @param      v
     *              the value for which to return a hash code.
     *
     *  @return     a hash code for the specified value.
     */
    int hash(int v);

}/*
 * Copyright 2001-2007 Geert Bevin (gbevin[remove] at uwyn dot com)
 * Licensed under the Apache License, Version 2.0 (the "License")
 * $Id: DbConnectionUser.java 3884 2007-08-22 08:52:24Z gbevin $
 */
package com.uwyn.rife.database;

/**
 * By extending this class it's possible to provide the logic that should be
 * executed by the {@link DbQueryManager#reserveConnection(DbConnectionUser)
 * reserveConnection} method in the {@link DbQueryManager} class.
 * <p>This class has both a default constructor and one that can take a data
 * object. This can be handy when using it as an extending anonymous inner
 * class when you need to use variables inside the inner class that are
 * cumbersome to change to <code>final</code> in the enclosing class.
 * 
 * @author JR Boyens (jboyens[remove] at uwyn dot com)
 * @author Geert Bevin (gbevin[remove] at uwyn dot com)
 * @version $Revision: 3884 $
 * @see DbConnection
 * @see DbQueryManager#reserveConnection(DbConnectionUser)
 * @since 1.0
 */
import com.uwyn.rife.tools.ExceptionUtils;
import com.uwyn.rife.tools.InnerClassException;
import java.util.logging.Logger;

public abstract class DbConnectionUser<ResultType, DataType> implements Cloneable
{
	protected DataType  mData = null;

	/**
	 * Create a new DbConnectionUser.
	 * 
	 * @since 1.0
	 */
	public DbConnectionUser()
	{
	}

	/**
	 * Create a new DbConnectionUser with a data object.
	 * 
	 * @param data a user data object to be stored locally
	 * @since 1.0
	 */
	public DbConnectionUser(DataType data)
	{
		mData = data;
	}

	/**
	 * Retrieve the data object that was provided to the constructor.
	 * 
	 * @return the provided data object; or
	 * <p><code>null</code> if no data object was provided
	 * @since 1.0
	 */
	public DataType getData()
	{
		return mData;
	}
	
	/**
	 * Calling this method makes it possible to throw a checked exception
	 * from within this class.
	 * <p>To catch it you should surround the {@link
	 * DbQueryManager#reserveConnection(DbConnectionUser)
	 * reserveConnection} with a <code>try-catch</code> block that catches
	 * <code>InnerClassException</code>. The original exception is then
	 * available through <code>getCause()</code> and can for example be
	 * rethrown.
	 * 
	 * @param exception the exception to be thrown
	 * @exception InnerClassException when a checked exception needs to be
	 * thrown from within this class and caught outside the caller.
	 * @since 1.0
	 */
	public void throwException(Exception exception)
	throws InnerClassException
	{
		throw new InnerClassException(exception);
	}
	
	/**
	 * Should be implemented by all extending classes.
	 * 
	 * @param connection the connection that should be used
	 * @since 1.0
	 */
	public abstract ResultType useConnection(DbConnection connection) throws InnerClassException;

	/**
	 * Simply clones the instance with the default clone method since this
	 * class contains no member variables.
	 * 
	 * @since 1.0
	 */
	public Object clone()
	{
		try
		{
			return super.clone();
		}
		catch (CloneNotSupportedException e)
		{
			// this should never happen
			Logger.getLogger("com.uwyn.rife.database").severe(ExceptionUtils.getExceptionStackTrace(e));
			return null;
		}
	}
}