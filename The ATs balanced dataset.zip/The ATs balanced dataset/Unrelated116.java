package org.metastatic.jessie.provider;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.InputStream;
import java.io.IOException;

import java.math.BigInteger;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * This class decodes DER sequences into Java objects. The methods of
 * this class do not have knowledge of higher-levels of structure in the
 * DER stream -- such as ASN.1 constructions -- and it is therefore up
 * to the calling application to determine if the data are structured
 * properly by inspecting the {@link DERValue} that is returned.
 *
 * @author Casey Marshall (rsdio@metastatic.org)
 */
public class DERReader implements DER
{

  // Fields.
  // ------------------------------------------------------------------------

  protected InputStream in;

  protected final ByteArrayOutputStream encBuf;

  // Constructor.
  // ------------------------------------------------------------------------

  /**
   * Create a new DER reader from a byte array.
   *
   * @param in The encoded bytes.
   */
  public DERReader(byte[] in)
  {
    this(new ByteArrayInputStream(in));
  }

  /**
   * Create a new DER readed from an input stream.
   *
   * @param in The encoded bytes.
   */
  public DERReader(InputStream in)
  {
    if (!in.markSupported())
      this.in = new BufferedInputStream(in, 16384);
    else
      this.in = in;
    encBuf = new ByteArrayOutputStream(2048);
  }

  // Class methods.
  // ------------------------------------------------------------------------

  /**
   * Convenience method for reading a single primitive value from the
   * given byte array.
   *
   * @param encoded The encoded bytes.
   * @throws IOException If the bytes do not represent an encoded
   * object.
   */
  public static DERValue read(byte[] encoded) throws IOException
  {
    return new DERReader(encoded).read();
  }

  // Instance methods.
  // ------------------------------------------------------------------------

  /**
   * Decode a single value from the input stream, returning it in a new
   * {@link DERValue}. By "single value" we mean any single type in its
   * entirety -- including constructed types such as SEQUENCE and all
   * the values they contain. Usually it is sufficient to call this
   * method once to parse and return the top-level structure, then to
   * inspect the returned value for the proper contents.
   *
   * @return The parsed DER structure.
   * @throws IOException If an error occurs reading from the input
   * stream.
   * @throws DEREncodingException If the input does not represent a
   * valid DER stream.
   */
  public DERValue read() throws IOException
  {
    int tag = in.read();
    if (tag == -1)
      throw new EOFException();
    encBuf.write(tag);
    int len = readLength();
    DERValue value = null;
    if ((tag & CONSTRUCTED) == CONSTRUCTED)
      {
        in.mark(2048);
        byte[] encoded = new byte[len];
        in.read(encoded);
        encBuf.write(encoded);
        value = new DERValue(tag, len, CONSTRUCTED_VALUE, encBuf.toByteArray());
        in.reset();
        encBuf.reset();
        return value;
      }
    switch (tag & 0xC0)
      {
        case UNIVERSAL:
          value = new DERValue(tag, len, readUniversal(tag, len),
            encBuf.toByteArray());
          encBuf.reset();
          break;
        case CONTEXT:
          byte[] encoded = new byte[len];
          in.read(encoded);
          encBuf.write(encoded);
          value = new DERValue(tag, len, encoded, encBuf.toByteArray());
          encBuf.reset();
          break;
        case APPLICATION:
          // This should not be reached, since (I think) APPLICATION is
          // always constructed.
          throw new DEREncodingException("non-constructed APPLICATION data");
        default:
          throw new DEREncodingException("PRIVATE class not supported");
      }
    return value;
  }

  public void skip(int len) throws IOException
  {
    in.skip(len);
  }

  // Own methods.
  // ------------------------------------------------------------------------

  private Object readUniversal(int tag, int len) throws IOException
  {
    byte[] value = new byte[len];
    in.read(value);
    encBuf.write(value);
    switch (tag & 0x1F)
      {
        case BOOLEAN:
          if (value.length != 1)
            throw new DEREncodingException();
          return new Boolean(value[0] != 0);
        case NULL:
          if (len != 0)
            throw new DEREncodingException();
          return null;
        case INTEGER:
        case ENUMERATED:
          return new BigInteger(value);
        case BIT_STRING:
          byte[] bits = new byte[len - 1];
          System.arraycopy(value, 1, bits, 0, bits.length);
          return new BitString(bits, value[0] & 0xFF);
        case OCTET_STRING:
          return value;
        case NUMERIC_STRING:
        case PRINTABLE_STRING:
        case T61_STRING:
        case VIDEOTEX_STRING:
        case IA5_STRING:
        case GRAPHIC_STRING:
        case ISO646_STRING:
        case GENERAL_STRING:
        case UNIVERSAL_STRING:
        case BMP_STRING:
        case UTF8_STRING:
          return makeString(tag, value);
        case UTC_TIME:
        case GENERALIZED_TIME:
          return makeTime(tag, value);
        case OBJECT_IDENTIFIER:
          return new OID(value);
        case RELATIVE_OID:
          return new OID(value, true);
        default:
          throw new DEREncodingException("unknown tag " + tag);
      }
  }

  private int readLength() throws IOException
  {
    int i = in.read();
    if (i == -1)
      throw new EOFException();
    encBuf.write(i);
    if ((i & ~0x7F) == 0)
      {
        return i;
      }
    else if (i < 0xFF)
      {
        byte[] octets = new byte[i & 0x7F];
        in.read(octets);
        encBuf.write(octets);
        return new BigInteger(1, octets).intValue();
      }
    throw new DEREncodingException();
  }

  private String makeString(int tag, byte[] value)
    throws IOException
  {
    String charset = null;
    switch (tag & 0x1F)
      {
        case NUMERIC_STRING:
        case PRINTABLE_STRING:
        case T61_STRING:
        case VIDEOTEX_STRING:
        case IA5_STRING:
        case GRAPHIC_STRING:
        case ISO646_STRING:
        case GENERAL_STRING:
          return new String(value, "ISO-8859-1");
        case UNIVERSAL_STRING:
          // XXX The docs say UniversalString is encoded in four bytes
          // per character, but Java has no support (yet) for UTF-32.
          //return new String(buf, "UTF-32");
        case BMP_STRING:
          return new String(value, "UTF-16BE");
        case UTF8_STRING:
          return new String(value, "UTF-8");
        default:
          throw new DEREncodingException("unknown string tag");
      }
  }

  private Date makeTime(int tag, byte[] value) throws IOException
  {
    Calendar calendar = Calendar.getInstance();
    String str = makeString(PRINTABLE_STRING, value);

    // Classpath's SimpleDateFormat does not work for parsing these
    // types of times, so we do this by hand.
    String date = str;
    String tz = "";
    if (str.indexOf("+") > 0)
      {
        date = str.substring(0, str.indexOf("+"));
        tz = str.substring(str.indexOf("+"));
      }
    else if (str.indexOf("-") > 0)
      {
        date = str.substring(0, str.indexOf("-"));
        tz = str.substring(str.indexOf("-"));
      }
    else if (str.endsWith("Z"))
      {
        date = str.substring(0, str.length()-2);
        tz = "Z";
      }
    if (!tz.equals("Z") && tz.length() > 0)
      calendar.setTimeZone(TimeZone.getTimeZone(tz));
    else
      calendar.setTimeZone(TimeZone.getTimeZone("UTC"));
    if ((tag & 0x1F) == UTC_TIME)
      {
        if (date.length() < 10)  // must be at least 10 chars long
          throw new DEREncodingException("cannot parse date");
        // UTCTime is of the form "yyMMddHHmm[ss](Z|(+|-)hhmm)"
        try
          {
            int year = Integer.parseInt(str.substring(0, 2));
            if (year < 50)
              year += 2000;
            else
              year += 1900;
            calendar.set(year,
              Integer.parseInt(str.substring( 2,  4))-1,  // month
              Integer.parseInt(str.substring( 4,  6)),    // day
              Integer.parseInt(str.substring( 6,  8)),    // hour
              Integer.parseInt(str.substring( 8, 10)));   // minute
            if (date.length() == 12);
              calendar.set(calendar.SECOND,
                Integer.parseInt(str.substring(10, 12)));
          }
        catch (NumberFormatException nfe)
          {
            throw new DEREncodingException("cannot parse date");
          }
      }
    else
      {
        if (date.length() < 10)  // must be at least 10 chars long
          throw new DEREncodingException("cannot parse date");
        // GeneralTime is of the form "yyyyMMddHH[mm[ss[(.|,)SSSS]]]"
        // followed by "Z" or "(+|-)hh[mm]"
        try
          {
            calendar.set(
              Integer.parseInt(date.substring(0, 4)),      // year
              Integer.parseInt(date.substring(4, 6))-1,    // month
              Integer.parseInt(date.substring(6, 8)),      // day
              Integer.parseInt(date.substring(8, 10)), 0); // hour, min
            switch (date.length())
              {
                case 19:
                case 18:
                case 17:
                case 16:
                  calendar.set(calendar.MILLISECOND,
                    Integer.parseInt(date.substring(15)));
                case 14:
                  calendar.set(calendar.SECOND,
                    Integer.parseInt(date.substring(12, 14)));
                case 12:
                  calendar.set(calendar.MINUTE,
                    Integer.parseInt(date.substring(10, 12)));
              }
          }
        catch (NumberFormatException nfe)
          {
            throw new DEREncodingException("cannot parse date");
          }
      }
    return calendar.getTime();
  }
}
/* DiffieHellman.java -- Diffie-Hellman key exchange.
   Copyright (C) 2003  Casey Marshall <rsdio@metastatic.org>

This file is a part of Jessie.

Jessie is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

Jessie is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with Jessie; if not, write to the

   Free Software Foundation, Inc.,
   59 Temple Place, Suite 330,
   Boston, MA  02111-1307
   USA

Linking this library statically or dynamically with other modules is
making a combined work based on this library.  Thus, the terms and
conditions of the GNU General Public License cover the whole
combination.

As a special exception, the copyright holders of this library give you
permission to link this library with independent modules to produce an
executable, regardless of the license terms of these independent
modules, and to copy and distribute the resulting executable under terms
of your choice, provided that you also meet, for each linked independent
module, the terms and conditions of the license of that module.  An
independent module is a module which is not derived from or based on
this library.  If you modify this library, you may extend this exception
to your version of the library, but you are not obligated to do so.  If
you do not wish to do so, delete this exception statement from your
version.  */


package org.metastatic.jessie.provider;

import java.math.BigInteger;
import gnu.crypto.key.dh.GnuDHPrivateKey;

/**
 * <p>Simple implementation of two-party Diffie-Hellman key agreement.</p>
 *
 * <p>The primes used in this class are from the following documents:</p>
 *
 * <ul>
 * <li>D. Harkins and D. Carrel, "The Internet Key Exchange (IKE)", <a
 * href="http://www.ietf.org/rfc/rfc2409.txt">RFC 2409</a>.</li>
 * <li>T. Kivinen and M. Kojo, "More Modular
 * Exponential (MODP) Diffie-Hellman groups for Internet Key Exchange
 * (IKE)", <a href="http://www.ietf.org/rfc/rfc3526.txt">RFC
 * 3526</a>.</li>
 * </li>
 *
 * <p>The generator for all these primes is 2.</p>
 */
final class DiffieHellman
{

  // Class method.
  // -------------------------------------------------------------------------

  /**
   * Get the system's Diffie-Hellman parameters, in which <i>g</i> is 2
   * and <i>p</i> is determined by the property
   * <code>"jessie.keypool.dh.group"</code>. The default value for <i>p</i>
   * is 18, corresponding to {@link #GROUP_18}.
   */
  static GnuDHPrivateKey getParams()
  {
    BigInteger p = DiffieHellman.GROUP_18;
    String group = Util.getSecurityProperty("jessie.key.dh.group");
    if (group != null)
      {
        group = group.trim();
        if (group.equals("1"))
          p = DiffieHellman.GROUP_1;
        else if (group.equals("2"))
          p = DiffieHellman.GROUP_2;
        else if (group.equals("5"))
          p = DiffieHellman.GROUP_5;
        else if (group.equals("14"))
          p = DiffieHellman.GROUP_14;
        else if (group.equals("15"))
          p = DiffieHellman.GROUP_15;
        else if (group.equals("16"))
          p = DiffieHellman.GROUP_16;
        else if (group.equals("17"))
          p = DiffieHellman.GROUP_17;
        else if (group.equals("18"))
          p = DiffieHellman.GROUP_18;
      }
    return new GnuDHPrivateKey(null, p, DH_G, null);
  }

  // Constants.
  // -------------------------------------------------------------------------

  /**
   * The generator for all Diffie Hellman groups below.
   */
  static final BigInteger DH_G = BigInteger.valueOf(2L);

  /**
   * p = 2^768 - 2 ^704 - 1 + 2^64 * { [2^638 pi] + 149686 }
import com.ibm.aglet.*;
import com.ibm.awb.misc.Encoding;
import java.io.*;
import java.net.URL;
import java.util.Enumeration;

/**
 * WebServerAglet is an aglet which behaves like WebServer.
 * Please enable the HTTP messaging feature in the configuration panel
 * Options -> Network Cofiguration -> Others.
 * If the aglet is successfully created, please try
 * <pre>
 * http://aglet.server:434/aglets/default/test/index.html
 * </pre>
 * in your web browser. The port number have to be same number on which
 * the aglet server is running. (434 by default)
 * 
 * @version     1.00	$Date: 2002/03/16 00:42:05 $
 * @author	Mitsuru Oshima
 */
public class WebServerAglet extends Aglet {
	static private final Encoding ENCODING = Encoding.getDefault();
	static private final String ENCODING_JAVA = ENCODING.getJavaEncoding();
	static private final String CHARSET_PAGE = ENCODING.getHTMLCharset();
	static private String META_TAG = null;
	static {
		META_TAG = "<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html;";
		if (CHARSET_PAGE != null) {
			META_TAG += " charset=" + CHARSET_PAGE;
		} 
		META_TAG += "\">";
	} 

	String indexPage = null;

	// 
	// If it's http request.
	// 
	boolean handleHttpRequest(Message m, PrintWriter p) {
		System.out.println(m);
		if (m.sameKind("index.html") || m.sameKind("")) {
			p.println(indexPage);
			p.flush();
		} else if (m.sameKind("next.html")) {
			p.println("<HTML>");
			p.println("<HEAD>");
			p.println(META_TAG);
			p.println("<TITLE>");
			p.println("NEXT");
			p.println("</TITLE>");
			p.println("</HEAD>");
			p.println("<BODY>");
			p.println("<H1> Here is a list of proxies in <TT>" 
					  + getAgletContext().getHostingURL() + "</TT></H1>");
			Enumeration e = getAgletContext().getAgletProxies(ACTIVE 
					| INACTIVE);

			p.println("<PRE>");
			while (e.hasMoreElements()) {
				AgletProxy proxy = (AgletProxy)e.nextElement();

				try {
					p.println(proxy.getAgletInfo().toString());
				} catch (Exception ex) {
					ex.printStackTrace(p);
				} 
			} 
			p.println("</PRE>");
			p.println("</BODY>");
			p.println("</HTML>");
			p.flush();
			m.sendReply("text/html");
		} else if (m.sameKind("go")) {
			System.out.println((String)m.getArg("location"));
			String l = (String)m.getArg("location");

			if (l.startsWith("atp:")) {
				l = l.substring(4);
				if (l.indexOf(':') < 0) {
					p.println("<HTML>");
					p.println("<HEAD>");
					p.println(META_TAG);
					p.println("<TITLE>");
					p.println("ILLEGAL INPUT");
					p.println("</TITLE>");
					p.println("</HEAD>");
					p.println("<BODY>");
					p.println("<H1>");
					p.println("Please specify port number. default = 434");
					p.println("</H1>");
					p.println("</BODY>");
					p.println("</HTML>");
					p.flush();
					m.sendReply("text/html");
					return true;
				} 
			} 

			try {
				p.println("<HTML>");
				p.println("<HEAD>");
				p.println(META_TAG);
				p.println("<TITLE>");
				p.println("MOVING TO");
				p.println("</TITLE>");
				p.println("</HEAD>");
				p.println("<BODY>");
				p.println("<H1> Moving to...! </H1>");
				String contextName = getAgletContext().getName();

				if (contextName.equals("")) {
					contextName = "default";
				} 

				p.println("<a href= \"http:" + l + "/aglets/" + contextName 
						  + "/" + getAgletID() 
						  + "/index.html\" TARGET=_top> atp:" + l + " </a>");
				p.println("Click above link to trace me! <BR>");
				p.println("</BODY>");
				p.println("</HTML>");
				p.flush();
				m.sendReply("text/html");

				dispatch(new java.net.URL("atp:" + l));

			} catch (IOException ex) {
				ex.printStackTrace();
			} catch (RequestRefusedException ex) {
				ex.printStackTrace();
			} 
		} else {
			return false;
		}
		return true;
	}
	public boolean handleMessage(Message m) {

		// 
		// This is just a temporary solution.
		// 
		Object o = m.getArg("cgi-response");
		PrintStream p = null;

		if (o != null && o instanceof OutputStream) {
			OutputStream os = (OutputStream)o;
			OutputStreamWriter osw = null;

			try {
				osw = new OutputStreamWriter(os, ENCODING_JAVA);
			} catch (UnsupportedEncodingException excpt) {
				osw = new OutputStreamWriter(os);
			} 
			PrintWriter pw = new PrintWriter(osw);

			return handleHttpRequest(m, pw);
		} 
		return true;
	}
	/*
	 * index page
	 */
	void indexPage() {
		StringBuffer b = new StringBuffer();

		b.append("<HTML>");
		b.append("<HEAD>");
		b.append(META_TAG);
		b.append("<TITLE>");
		b.append("CGI TEST");
		b.append("</TITLE>");
		b.append("</HEAD>");
		b.append("<BODY>");
		b.append("<H1> Welcome to WebServerAglet! </H1>");
		b.append("<a href=next.html> List Proxies </a> <BR>");
		b.append("<FORM METHOD=GET ACTION=go>");
		b.append("<INPUT NAME=location VALUE=\"atp://your.host\">");
		b.append("<INPUT TYPE=submit VALUE=GO!> <BR>");
		b.append("<P><FONT color=#FF0000>note:</FONT> Check box ");
		b.append("for \"Accept HTTP Request as a message\"<BR>");
		b.append("in \"Network Preference\" of target server <B>must be checked</B>.");
		b.append("</BODY>");
		b.append("</HTML>");
		indexPage = b.toString();
	}
	public void onCreation(Object init) {

		// 
		// this is just a convension.
		// 
		getAgletContext().setProperty("name.test", getAgletID());

		// 
		// Creating pages in advance.
		// 
		indexPage();

		// 
		// Accepts http requests concurrently.
		// 
		getMessageManager().setPriority("index.html", 
										MessageManager.NOT_QUEUED);
		getMessageManager().setPriority("next.html", 
										MessageManager.NOT_QUEUED);
	}
}
package org.metastatic.jessie.provider;

import java.io.ByteArrayOutputStream;

import java.util.Arrays;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.Mac;

import javax.net.ssl.SSLException;

class JCESecurityParameters implements SecurityParameters
{

  // Fields.
  // -------------------------------------------------------------------------

  private Cipher inCipher, outCipher;
  private Mac inMac, outMac;
  private Inflater inflater;
  private Deflater deflater;
  private int fragmentLength;
  private long inSequence, outSequence;
  private ProtocolVersion version;

  // Constructors.
  // -------------------------------------------------------------------------

  JCESecurityParameters ()
  {
    fragmentLength = 16384;
    inSequence = 0L;
    outSequence = 0L;
  }

  // Instance methods.
  // -------------------------------------------------------------------------

  public void reset()
  {
    inCipher = null;
    outCipher = null;
    inMac = null;
    outMac = null;
    deflater = null;
    inflater = null;
  }

  public void setInCipher (Object inCipher)
  {
    this.inCipher = (Cipher) inCipher;
  }

  public void setOutCipher (Object outCipher)
  {
    this.outCipher = (Cipher) outCipher;
  }

  public void setInMac (Object inMac)
  {
    this.inMac = (Mac) inMac;
    inSequence = 0L;
  }

  public void setOutMac (Object outMac)
  {
    this.outMac = (Mac) outMac;
    outSequence = 0L;
  }

  public void setDeflating (boolean deflate)
  {
    if (deflate)
      {
        if (deflater == null)
          deflater = new Deflater();
      }
    else
      deflater = null;
  }

  public void setInflating (boolean inflate)
  {
    if (inflate)
      {
        if (inflater == null)
          inflater = new Inflater();
      }
    else
      inflater = null;
  }

  public int getFragmentLength()
  {
    return fragmentLength;
  }

  public void setFragmentLength (int fragmentLength)
  {
    this.fragmentLength = fragmentLength;
  }

  public ProtocolVersion getVersion()
  {
    return version;
  }

  public void setVersion (ProtocolVersion version)
  {
    this.version = version;
  }

  public synchronized byte[] decrypt (byte[] fragment, ProtocolVersion version,
                                      ContentType type)
    throws MacException, OverflowException, SSLException
  {
    boolean badpad = false;
    if (inCipher != null)
      {
        // We imagine that the JCE would be used in cases where hardware
        // acceleration is available, since it isn't really that useful for
        // pure Java crypto. We decrypt (and encrypt, below) in one go
        // to minimize (potential) calls to native methods.
        try
          {
            fragment = inCipher.doFinal (fragment);
          }
        catch (BadPaddingException bpe)
          {
            badpad = true;
          }
        catch (IllegalBlockSizeException ibse)
          {
            badpad = true;
          }
      }

    if (inMac != null)
      {
        int macLen = inMac.getMacLength();
        int fragLen = fragment.length - macLen;
        byte[] mac = Util.trim (fragment, fragLen, macLen);
        fragment = Util.trim (fragment, fragLen);
        inMac.update ((byte) (inSequence >>> 56));
        inMac.update ((byte) (inSequence >>> 48));
        inMac.update ((byte) (inSequence >>> 40));
        inMac.update ((byte) (inSequence >>> 32));
        inMac.update ((byte) (inSequence >>> 24));
        inMac.update ((byte) (inSequence >>> 16));
        inMac.update ((byte) (inSequence >>>  8));
        inMac.update ((byte)  inSequence);
        inMac.update ((byte) type.getValue());
        if (version != ProtocolVersion.SSL_3)
          {
            inMac.update ((byte) version.getMajor());
            inMac.update ((byte) version.getMinor());
          }
        inMac.update ((byte) (fragLen >>> 8));
        inMac.update ((byte)  fragLen);
        inMac.update (fragment);
        if (!Arrays.equals (mac, inMac.doFinal()) || badpad)
          throw new MacException();
      }

    if (inflater != null)
      {
        byte[] buf = new byte[1024];
        ByteArrayOutputStream bout = new ByteArrayOutputStream (fragment.length << 1);
        inflater.setInput (fragment);
        int len;
        try
          {
            while ((len = inflater.inflate (buf)) > 0)
              {
                bout.write (buf, 0, len);
                if (bout.size() > fragmentLength + 1024)
                  throw new OverflowException ("inflated data too large");
              }
          }
        catch (DataFormatException dfe)
          {
            throw new SSLException (String.valueOf (dfe));
          }
        fragment = bout.toByteArray();
        inflater.reset();
      }

    inSequence++;
    return fragment;
  }

  public synchronized byte[] encrypt (byte[] fragment, int off, int len,
                                      ContentType type)
    throws OverflowException, SSLException
  {
    if (deflater != null)
      {
        byte[] buf = new byte[1024];
        ByteArrayOutputStream bout = new ByteArrayOutputStream (len >>> 1);
        deflater.setInput (fragment, off, len);
        deflater.finish();
        len = 0;
        while ((len = deflater.deflate (buf)) > 0)
          bout.write (buf, 0, len);
        // This should technically never happen for zlib.
        if (bout.size() > fragmentLength + 1024)
          throw new OverflowException ("deflated data too large");
        fragment = bout.toByteArray();
        off = 0;
        len = fragment.length;
        deflater.reset();
      }

    if (outMac != null)
      {
        outMac.update ((byte) (inSequence >>> 56));
        outMac.update ((byte) (inSequence >>> 48));
        outMac.update ((byte) (inSequence >>> 40));
        outMac.update ((byte) (inSequence >>> 32));
        outMac.update ((byte) (inSequence >>> 24));
        outMac.update ((byte) (inSequence >>> 16));
        outMac.update ((byte) (inSequence >>>  8));
        outMac.update ((byte)  inSequence);
        outMac.update ((byte) type.getValue());
        if (version != ProtocolVersion.SSL_3)
          {
            outMac.update ((byte) version.getMajor());
            outMac.update ((byte) version.getMinor());
          }
        outMac.update ((byte) (len >>> 8));
        outMac.update ((byte)  len);
        outMac.update (fragment, off, len);
        fragment = Util.concat (fragment, outMac.doFinal());
        off = 0;
        len = fragment.length;
      }

    if (outCipher != null)
      {
        try
          {
            fragment = outCipher.doFinal (fragment, off, len);
          }
        catch (BadPaddingException shouldNeverHappen)
          {
            // This is nonsensical. Don't even pretend that we can handle this.
            throw new RuntimeException ("bad padding thrown while encrypting");
          }
        catch (IllegalBlockSizeException ibse)
          {
            // Ditto.
            throw new RuntimeException ("illegal block size thrown while encrypting");
          }
        off = 0;
        len = fragment.length;
      }

    outSequence++;
    if (off == 0 && len == fragment.length)
      return fragment;
    else
      return Util.trim (fragment, off, len);
  }
}
package org.metastatic.jessie.provider;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.net.ssl.SSLProtocolException;

final class ClientHello implements Handshake.Body
{

  // Fields.
  // -------------------------------------------------------------------------

  private ProtocolVersion version;
  private Random random;
  private byte[] sessionId;
  private List suites;
  private List comp;
  private List extensions;

  // Constructor.
  // -------------------------------------------------------------------------

  ClientHello(ProtocolVersion version, Random random,
              byte[] sessionId, List suites, List comp)
  {
    this(version, random, sessionId, suites, comp, null);
  }

  ClientHello(ProtocolVersion version, Random random,
              byte[] sessionId, List suites, List comp, List extensions)
  {
    this.version = version;
    this.random = random;
    this.sessionId = sessionId;
    this.suites = suites;
    this.comp = comp;
    this.extensions = extensions;
  }

  // Class methods.
  // -------------------------------------------------------------------------

  static ClientHello read(InputStream in) throws IOException
  {
    ProtocolVersion vers = ProtocolVersion.read(in);
    Random rand = Random.read(in);
    byte[] id = new byte[in.read() & 0xFF];
    in.read(id);
    int len = (in.read() & 0xFF) << 8 | (in.read() & 0xFF);
    ArrayList suites = new ArrayList(len / 2);
    for (int i = 0; i < len; i += 2)
      {
        suites.add(CipherSuite.read(in).resolve(vers));
      }
    len = in.read() & 0xFF;
    ArrayList comp = new ArrayList(len);
    for (int i = 0; i < len; i++)
      {
        comp.add(CompressionMethod.read(in));
      }

    List ext = null;
    // Since parsing MAY need to continue into the extensions fields, or it
    // may end here, the specified input stream MUST be a ByteArrayInputStream
    // over all the data this hello contains. Otherwise this will mess up
    // the data stream.
    if (in.available() > 0) // then we have extensions.
      {
        ext = new LinkedList();
        len = (in.read() & 0xFF) << 8 | (in.read() & 0xFF);
        int count = 0;
        while (count < len)
          {
            Extension e = Extension.read(in);
            ext.add(e);
            count += e.getValue().length + 4;
          }
      }
    return new ClientHello(vers, rand, id, suites, comp, ext);
  }

  // Instance methods.
  // -------------------------------------------------------------------------

  public void write(OutputStream out) throws IOException
  {
    version.write(out);
    random.write(out);
    out.write(sessionId.length);
    out.write(sessionId);
    out.write((suites.size() << 1) >>> 8 & 0xFF);
    out.write((suites.size() << 1) & 0xFF);
    for (Iterator i = suites.iterator(); i.hasNext(); )
      {
        ((CipherSuite) i.next()).write(out);
      }
    out.write(comp.size());
    for (Iterator i = comp.iterator(); i.hasNext(); )
      {
        out.write(((CompressionMethod) i.next()).getValue());
      }
    if (extensions != null)
      {
        ByteArrayOutputStream out2 = new ByteArrayOutputStream();
        for (Iterator i = extensions.iterator(); i.hasNext(); )
          {
            ((Extension) i.next()).write(out2);
          }
        out.write(out2.size() >>> 8 & 0xFF);
        out.write(out2.size() & 0xFF);
        out2.writeTo(out);
      }
  }

  ProtocolVersion getVersion()
  {
    return version;
  }

  Random getRandom()
  {
    return random;
  }

  byte[] getSessionId()
  {
    return sessionId;
  }

  List getCipherSuites()
  {
    return suites;
  }

  List getCompressionMethods()
  {
    return comp;
  }

  List getExtensions()
  {
    return extensions;
  }

  public String toString()
  {
    StringWriter str = new StringWriter();
    PrintWriter out = new PrintWriter(str);
    out.println("struct {");
    out.println("  version = " + version + ";");
    BufferedReader r = new BufferedReader(new StringReader(random.toString()));
    String s;
    try
      {
        while ((s = r.readLine()) != null)
          {
            out.print("  ");
            out.println(s);
          }
      }
    catch (IOException ignored)
      {
      }
    out.println("  sessionId = " + Util.toHexString(sessionId, ':') + ";");
    out.println("  cipherSuites = {");
    for (Iterator i = suites.iterator(); i.hasNext(); )
      {
        out.print("    ");
        out.println(i.next());
      }
    out.println("  };");
    out.print("  compressionMethods = { ");
    for (Iterator i = comp.iterator(); i.hasNext(); )
      {
        out.print(i.next());
        if (i.hasNext())
          out.print(", ");
      }
    out.println(" };");
    if (extensions != null)
      {
        out.println("  extensions = {");
        for (Iterator i = extensions.iterator(); i.hasNext(); )
          {
            r = new BufferedReader(new StringReader(i.next().toString()));
            try
              {
                while ((s = r.readLine()) != null)
                  {
                    out.print("    ");
                    out.println(s);
                  }
              }
            catch (IOException ignored)
              {
              }
          }
        out.println("  };");
      }
    out.println("} ClientHello;");
    return str.toString();
  }
}
