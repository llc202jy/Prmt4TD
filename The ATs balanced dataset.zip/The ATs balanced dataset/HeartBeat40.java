  public static void sendXML(String XMLdata) throws Exception 
    {
	    if (instance == null)
	    	return;
	    
	    synchronized (instance.out)
	    {
			instance.out.print(XMLdata);
			instance.out.flush();

	    }
	}
	   

 public void closeConnection()
    {
	    if (connectionRunning == false)
	    	return;
	    	
	    try
	    {
	    	User.setOffline();
    	}
    	catch (Exception ex)
    	{
	    	ex.printStackTrace();
    	}
	    
	    //stop the heartbeat
	    Heartbeat.stop();
	    
	    sendCloseTag();
	    
		connectionRunning = false;
	   
		//destroy the user
		User.destroyUser();
		
		try
		{
		    //close the in/out
		    if (in != null)
		    {
			    in.close();
			    in = null;
		    }
		    
		    if (out != null)
		    {
			 	out.close();
			 	out = null;   
		    }
			    
		    if (socket != null)
		    {
				socket.close(); 
				socket = null;
		    }
	    } 
	    catch (Exception ex)
	    {
		    ex.printStackTrace();
	    }
    }
    
    
	
	
	private void sendHeartbeat()
	{
		if (connection == null)
		{
			System.out.println("Heartbeat.sendHeartbeat(): Connection invalid!");
			return;
		}
		
		
		try
		{
			//xml already cached
			Connection.sendXML(heartbeat);
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
	}
	
	/*
		start the heartbeat process
	*/
	
	public static void start(Connection conn)
	{
		/*
		if (instance != null)
		{
			System.out.println("Heartbeat.start(): instance already created!");
			return;
		}
		*/
		
		instance = new Heartbeat();
		
		instance.connection = conn;
		
		//cache the heartbeat
		instance.heartbeat = "<service type=\"heartbeat\"/>";
		
		instance.timer = new javax.swing.Timer(20000,new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				instance.sendHeartbeat();
			}
		});
		
		instance.timer.start();
		
	}
	
	public static void stop()
	{
		if (instance == null)
		{
			System.out.println("Heartbeat.stop(): instance not created yet!");
			return;
		}
		
		instance.timer.stop();
	}
	