
namespace Diagnostika.Security
{
    public class Audit
    {
        public Audit(){}

        public static void Save(User user, string url, string sql, IPAddress ip)
        {
            if(user.Id > 0)  
                SqlHelper.ExecuteScalar(DataConfiguration.DataBaseConnection, System.Data.CommandType.Text, string.Format("INSERT INTO [AUDIT] (user_id, page, sql, ip) VALUES ('{0}', '{1}', '{2}', '{3}')", user.Id, url, sql.Replace("'", "''"), ip.ToString())); 
            else
                SqlHelper.ExecuteScalar(DataConfiguration.DataBaseConnection, System.Data.CommandType.Text, string.Format("INSERT INTO [AUDIT] (page, sql, ip) VALUES ('{0}', '{1}', '{2}')", url, sql.Replace("'", "''"), ip.ToString())); 
        }
    }
}