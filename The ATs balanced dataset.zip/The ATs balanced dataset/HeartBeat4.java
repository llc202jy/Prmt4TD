using namespace std;

WalkControllerBehavior* WalkControllerBehavior::theOne = NULL;

void WalkControllerBehavior::runCommand(unsigned char *command) {
	// First, turn off the stop-if-no-heartbeat timer
	erouter->removeTimer(this);

	// Extract the command parameter
	float param;
	unsigned char *paramp = (unsigned char *) &param;

#if defined(BYTE_ORDER) && BYTE_ORDER==BIG_ENDIAN
	paramp[0] = command[4];
	paramp[1] = command[3];
	paramp[2] = command[2];
	paramp[3] = command[1];
#else
	paramp[0] = command[1];
	paramp[1] = command[2];
	paramp[2] = command[3];
	paramp[3] = command[4];
#endif

	// Find out what type of command this is
	switch(command[0]) {
	case CMD_fwd:
		dx = param;
		break;
	case CMD_roto:
		da = param;
		break;
	case CMD_side:
		dy = param;
		break;
	case CMD_opt0:
		{
			/*			HeadPointerMC *head =
				(HeadPointerMC*)motman->checkoutMotion(head_id);
			head->setJoints(0,0,0);
			motman->checkinMotion(head_id);*/
			break;
		}
	case CMD_opt1:
	case CMD_opt2:
	case CMD_opt3:
	case CMD_opt4:
		cout << "MECHA: hey, reprogram this button!" << endl;
		break;
	case CMD_opt5:
		sndman->playFile("howl.wav");
		break;
	case CMD_opt6:
		sndman->playFile("yap.wav");
		break;
	case CMD_opt7:
		sndman->playFile("whimper.wav");
		break;
	case CMD_opt8:
		sndman->playFile("growl.wav");
		break;
	case CMD_opt9:
		sndman->playFile("barkmed.wav");
		break;
		// The options button commands.
	default:
		cout << "MECHA: unknown command " << command[0] << endl;
	}

	// If the command was a new motion command, apply the
	// new motion parameters:
	switch(command[0]) {
	case CMD_fwd:
	case CMD_roto:
	case CMD_side:
		{
			MMAccessor<WalkMC> walker(getWalkID());
			float tdx=dx*walker->getCP().max_vel[dx>0?WalkMC::CalibrationParam::forward:WalkMC::CalibrationParam::reverse];
			float tdy=dy*walker->getCP().max_vel[WalkMC::CalibrationParam::strafe];
			float tda=da*walker->getCP().max_vel[WalkMC::CalibrationParam::rotate];
			walker->setTargetVelocity(tdx,tdy,tda);
		}
	}

	// Reset the stop-if-no-heartbeat timer -- if we don't
	// hear from the mothership in three seconds, stop immediately.
	erouter->addTimer(this, 0, 3000, false);
}

void WalkControllerBehavior::DoStart() {
	// Behavior startup
	BehaviorBase::DoStart();
	// We listen to timers (but don't need to explicitly tell erouter -- addTimer implies this)
	//erouter->addListener(this, EventBase::timerEGID);
	// Enable walker (the MC_ID can be accessed through the shared_walker later)
	motman->addPersistentMotion(shared_walker);
	// Turn on wireless
	theLastOne=theOne;
	theOne=this;
	cmdsock=wireless->socket(Socket::SOCK_STREAM, 2048, 2048);
	wireless->setReceiver(cmdsock->sock, mechacmd_callback);
	wireless->setDaemon(cmdsock,true); 
	wireless->listen(cmdsock->sock, config->main.walkControl_port);
	// Open the WalkGUI on the desktop
	Controller::loadGUI("org.tekkotsu.mon.WalkGUI","WalkGUI",config->main.walkControl_port);
}

void WalkControllerBehavior::DoStop() {
	// Close the GUI
	Controller::closeGUI("WalkGUI");
	// Turn off timers
	erouter->removeListener(this);
	// Close socket; turn wireless off
	wireless->setDaemon(cmdsock,false); 
	wireless->close(cmdsock);
	theOne=theLastOne;
	// Disable walker
	motman->removeMotion(getWalkID());
	// Total behavior stop
	BehaviorBase::DoStop();
}

// The command packet reassembly mechanism
int WalkControllerBehavior::mechacmd_callback(char *buf, int bytes) {
  static char cb_buf[5];
  static int cb_buf_filled;
