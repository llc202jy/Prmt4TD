package de.x4technology.auditing;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * @author ingo,uwe
 *  
 */
public final class AuditingType implements Serializable
{
    private static int nextOrdinal = 0;
    
    private static transient Map constantMap = new HashMap(10);
    private final String name;
    private final int ordinal = nextOrdinal++;

    private AuditingType(String name)
    {
        this.name = name;
        if (constantMap.get(name) != null)
            throw new IllegalArgumentException(this.getClass().getName() + " with name '" + name + "' already exists ");
        constantMap.put(name, this);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        return name;
    }

    /**
     * @see java.lang.Object#equals(Object)
     */
    public boolean equals(Object other)
    {
        if (other instanceof AuditingType)
        {
            AuditingType new_name = (AuditingType) other;
            return (new_name.ordinal == this.ordinal);
        }
        return false;
    }

    /**
     * fixes reference after de-serialization
     */
    private Object readResolve()
    {
        Object o = constantMap.get(name);
        if (o != null) return o;
        return this;
    }

    public int hashCode()
    {
        return ordinal;
    }

    public static final AuditingType getById(String id)
    {
        if (id == null) throw new NullPointerException("id");
        return (AuditingType) constantMap.get(id);
    }
    // ADD NEW CONSTANTS AT END OF LIST !

    public static final AuditingType FATAL = new AuditingType("FATAL");
    public static final AuditingType ERROR = new AuditingType("ERROR");
    public static final AuditingType WARNING = new AuditingType("WARNING");
    public static final AuditingType INFO = new AuditingType("INFO");
    public static final AuditingType TRACE = new AuditingType("TRACE");
    
    public static final AuditingType DEFAULT = TRACE;
}
package de.x4technology.auditing.store;

import de.x4technology.auditing.AuditingMessage;

/**
 * @author ingo
 *  
 */
public interface AuditingStore
{
    void store(AuditingMessage message);
    void storeSync(AuditingMessage message);
    void flush();
    void shutdown();
}

package de.x4technology.auditing;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * @author ingo,uwe
 *  
 */
public final class AuditingCategory implements Serializable
{
    private static int nextOrdinal = 0;
    private static transient Map constantMap = new HashMap(10);
    
    private final String name;
    private final int ordinal = nextOrdinal++;

    private AuditingCategory(String name)
    {
        this.name = name;
        if (constantMap.get(name) != null)
            throw new IllegalArgumentException(this.getClass().getName() + " with name '" + name + "' already exists ");
        constantMap.put(name, this);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        return name;
    }

    /**
     * @see java.lang.Object#equals(Object)
     */
    public boolean equals(Object other)
    {
        if (other instanceof AuditingCategory)
        {
            AuditingCategory new_name = (AuditingCategory) other;
            return (new_name.ordinal == this.ordinal);
        }
        return false;
    }

    /**
     * fixes reference after de-serialization
     */
    private Object readResolve()
    {
        Object o = constantMap.get(name);
        if (o != null) return o;
        return this;
    }

    public int hashCode()
    {
        return ordinal;
    }

    public static final AuditingCategory getById(String id)
    {
        if (id == null) throw new NullPointerException("id");
        return (AuditingCategory) constantMap.get(id);
    }

    // ADD NEW CONSTANTS AT END OF LIST !
    public static final AuditingCategory SYSTEM = new AuditingCategory("SYSTEM");
    public static final AuditingCategory SECURITY = new AuditingCategory("SECURITY");
    public static final AuditingCategory OBJECT = new AuditingCategory("OBJECT");
    
    public static final AuditingCategory DEFAULT = SYSTEM;
}
package de.x4technology.auditing.store;

/**
 * @author uwe
 */
public final class AuditingStoreHolder
{

    private static final AuditingStoreHolder INSTANCE = new AuditingStoreHolder();

    public static final AuditingStoreHolder getInstance()
    {
        return INSTANCE;
    }

    private AuditingStoreHolder()
    {
    }

    private Object instanceToHold = null;

    public AuditingStore get()
    {
        if (this.instanceToHold == null)
        {
            throw new IllegalStateException("Holder in unconfigured state");
        }
        return (AuditingStore) this.instanceToHold;
    }

    public void register(AuditingStore instanceToHold)
    {
        if (instanceToHold == null)
        {
            throw new NullPointerException("instanceToHold");
        }
        if (this.instanceToHold != null)
        {
            throw new IllegalStateException("already defined ! AuditingStore="
                                            + this.instanceToHold.getClass().getName());
        }
        this.instanceToHold = instanceToHold;
    }

    public void unregister()
    {
        if (this.instanceToHold != null)
        {
            shutdown(this.instanceToHold);
            this.instanceToHold = null;
        }
    }

    private static void shutdown(Object instanceToHold2)
    {
    }

    /**
     * @return
     */
    public boolean isConfigured()
    {
        return this.instanceToHold != null;
    }
}

package de.x4technology.auditing.store;

import de.x4technology.auditing.AuditingMessage;

/**
 * @author ingo
 */
public abstract class AbstractAuditingStore implements AuditingStore
{
    /*
     * 
     */
    public final void storeSync(AuditingMessage message)
    {
        store(message);
        flush();
    }

    private static transient de.x4technology.logging.LogFacility __log = null;

    private static de.x4technology.logging.LogFacility log()
    {
        if (__log == null)
        {
            __log = de.x4technology.logging.LogFactory.getFacility(AbstractAuditingStore.class);
        }
        return __log;
    }

}

package de.x4technology.auditing;

import java.io.Serializable;
import java.util.Date;

import de.x4technology.helper.Assert;

/**
 * @author ingo,uwe
 */
public class AuditingMessage implements Serializable
{
    private final AuditingCategory category;
    private final AuditingType type;
    private final String message;
    private final String source;
    private final Date date;
    private String userName;
    private final String externalizedEntityDescriptor;

    public AuditingMessage(AuditingCategory category, AuditingType type, String source, String message, String userName)
    {
        this(category, type, source, message, userName, null);
    }

    public AuditingMessage(AuditingCategory category, AuditingType type, String source, String message,
            String userName, String externalizedEntityDescriptor)
    {
        Assert.parameterNotNull(category, "category");
        Assert.parameterNotNull(type, "type");
        Assert.parameterNotNull(source, "source");
        Assert.parameterNotNull(message, "message");
        Assert.parameterNotNull(userName, "username");
        this.date = new Date();
        this.category = category;
        this.type = type;
        this.message = message;
        this.source = source;
        this.userName = userName;
        this.externalizedEntityDescriptor = externalizedEntityDescriptor;
    }

    public AuditingCategory getCategory()
    {
        return this.category;
    }

    public Date getDate()
    {
        return this.date;
    }

    public String getMessage()
    {
        return this.message;
    }

    public String getSource()
    {
        return this.source;
    }

    public AuditingType getType()
    {
        return this.type;
    }

    public String getUserName()
    {
        return this.userName;
    }

    public void setUserName(String userName)
    {
        Assert.isNotNull(userName);
        this.userName = userName;
    }

    public String getExternalizedEntityDescriptor()
    {
        return this.externalizedEntityDescriptor;
    }
}

package de.x4technology.auditing.file;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.List;

import de.x4technology.auditing.AuditingMessage;
import de.x4technology.auditing.store.AbstractAsyncAuditingStore;
import de.x4technology.auditing.store.AuditingStoreException;
import de.x4technology.helper.Assert;
import de.x4technology.helper.io.FileHelper;
import de.x4technology.helper.lang.StringHelper;

/**
 * @author uwe
 */
public class FileAuditingStore extends AbstractAsyncAuditingStore
{

    private File outputFileName;

    public FileAuditingStore()
    {
        // Nothing
    }

    public void setFilename(String absoulteFilename)
    {
        Assert.isNotNull(absoulteFilename);
        absoulteFilename = FileHelper.unifyPath(absoulteFilename);
        this.outputFileName = new File(absoulteFilename);
        if (this.outputFileName.isDirectory())
        {
            throw new IllegalArgumentException("'" + absoulteFilename + "' must NOT point to a directory");
        }

        String parentPath = StringHelper.beforeLastSlash(absoulteFilename);
        new File(parentPath).mkdirs();
    }

    public FileAuditingStore(File outputFileName)
    {
        setFilename(outputFileName.getAbsolutePath());
    }

    protected synchronized void processMessages(List currentQueue)
    {
        assert (currentQueue != null);
        if (currentQueue.size() == 0)
        {
            return;
        }
        if (log().isDebugEnabled())
        {
            log().debug("IN: process messages");
        }

        OutputStream os = null;
        try
        {
            if (log().isDebugEnabled())
            {
                log().debug("Create file output stream on '" + this.outputFileName + "'");
            }
            os = new BufferedOutputStream(new FileOutputStream(this.outputFileName, true));
            for (Iterator iter = currentQueue.iterator(); iter.hasNext();)
            {
                AuditingMessage msg = (AuditingMessage) iter.next();
                os.write(AuditingMessageStringRenderer.render(msg).getBytes());
                iter.remove();
            }
            os.flush();
            os.close();
            os = null;

            if (log().isDebugEnabled())
            {
                log().debug("OUT: process messages");
            }
        }
        catch (IOException e)
        {
            throw new AuditingStoreException(e);
        }
        finally
        {
            if (os != null)
            {
                try
                {
                    os.flush();
                }
                catch (IOException i)
                {
                }

                try
                {
                    os.close();
                }
                catch (IOException ignore)
                {
                }
            }
        }

    }

    private static transient de.x4technology.logging.LogFacility __log = null;

    private static de.x4technology.logging.LogFacility log()
    {
        if (__log == null)
        {
            __log = de.x4technology.logging.LogFactory.getFacility(FileAuditingStore.class);
        }
        return __log;
    }

}

package de.x4technology.auditing.store;

import de.x4technology.helper.exception.X4Exception;

/**
 * @author ingo
 *
 */
public class AuditingStoreException extends RuntimeException implements X4Exception
{

    /**
     * 
     */
    public AuditingStoreException()
    {
        super();

    }

    /**
     * @param message
     */
    public AuditingStoreException(String message)
    {
        super(message);

    }

    /**
     * @param cause
     */
    public AuditingStoreException(Throwable cause)
    {
        super(cause);

    }

    /**
     * @param message
     * @param cause
     */
    public AuditingStoreException(String message, Throwable cause)
    {
        super(message, cause);

    }

}

package de.x4technology.auditing.file;

import de.x4technology.auditing.AuditingMessage;

/**
 * @author uwe
 */
public final class AuditingMessageStringRenderer
{
    private static final int INITIAL_BUFFER_SIZE = 128;
    private static final char DELIMITER = ' ';

    private AuditingMessageStringRenderer()
    {
    }

    /**
     * @param msg
     * @return
     */
    public static String render(AuditingMessage msg)
    {
        StringBuffer sb = new StringBuffer(INITIAL_BUFFER_SIZE);

        sb.append(msg.getDate());
        sb.append(DELIMITER);

        sb.append(msg.getType());
        sb.append(DELIMITER);

        sb.append(msg.getCategory());
        sb.append(DELIMITER);

        sb.append(msg.getSource());
        sb.append(DELIMITER);

        sb.append(msg.getUserName());
        sb.append(DELIMITER);

        sb.append(msg.getMessage());
        sb.append(DELIMITER);

        // TODO add code here if the AuditingMessage class will be enhanced
        return sb.toString();
    }

}

package de.x4technology.auditing.store;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import de.x4technology.auditing.AuditingMessage;
import de.x4technology.helper.Assert;
import de.x4technology.helper.lang.ExceptionHelper;

/**
 * @author uwe
 */
public abstract class AbstractAsyncAuditingStore extends AbstractAuditingStore
{

    private List msgQueue = createQueue();
    private QueueProcessor processor = null;

    protected AbstractAsyncAuditingStore()
    {
        this.processor = new QueueProcessor(this);
        this.processor.setDaemon(true);
        this.processor.start();
    }

    /**
     * @return
     */
    private final List createQueue()
    {
        return Collections.synchronizedList(new LinkedList());
    }

    public synchronized final void store(AuditingMessage message)
    {
        Assert.isNotNull(message);
        if (log().isDebugEnabled())
        {
            log().debug("Store message");
        }
        this.msgQueue.add(message);
    }

    public final synchronized void flush()
    {
        if (this.msgQueue.size() == 0)
        {
            return;
        }

        List currentQueue = this.msgQueue;
        this.msgQueue = createQueue();
        try
        {
            processMessages(currentQueue);
        }
        catch (Exception e)
        {
            if (log().isWarnEnabled())
            {
                log().warn("Caught while process messages: " + ExceptionHelper.dump(e));
            }
            if (log().isDebugEnabled())
            {
                log().debug("Flushing failed. Let us re-inject them into the queue");
            }
            this.msgQueue.addAll(currentQueue);
        }
    }

    /**
     * @param currentQueue
     */
    protected abstract void processMessages(List currentQueue);

    /*
     * 
     */
    protected void finalize() throws Throwable
    {
        shutdown();
        super.finalize();
    }

    public synchronized void shutdown()
    {
        flush();
        if ((this.processor != null) && this.processor.isAlive())
        {
            this.processor.shutdown();
        }
    }

    public void setIntervalInMsec(long msec)
    {
        this.processor.setInterval(msec);
    }

    private static transient de.x4technology.logging.LogFacility __log = null;

    private static de.x4technology.logging.LogFacility log()
    {
        if (__log == null)
        {
            __log = de.x4technology.logging.LogFactory.getFacility(AbstractAsyncAuditingStore.class);
        }
        return __log;
    }

}

class QueueProcessor extends Thread
{

    private boolean shouldRun = true;
    private final AbstractAsyncAuditingStore store;
    private long interval = 10000; // 10 sec.

    /**
     * @param store
     */
    public QueueProcessor(AbstractAsyncAuditingStore store)
    {
        this.store = store;
    }

    /**
     * @param msec
     */
    public synchronized void setInterval(long msec)
    {
        this.interval = msec;
        interrupt();
    }

    /*
     * 
     */
    public void run()
    {
        while (this.shouldRun)
        {
            try
            {
                Thread.sleep(this.interval);
            }
            catch (InterruptedException ignore)
            {
            }
            if (this.shouldRun)
            {
                this.store.flush();
            }
        }
    }

    /**
     * 
     */
    public synchronized void shutdown()
    {
        this.shouldRun = false;
        this.interrupt();
    }

}
