package thera.framework;

import java.util.Enumeration;
import java.util.Vector;

import thera.steps.AbortOperationException;

import extern.XElement;
/**
 * Thera operation. <p>
 * Ordered sequence of <a href="OperationStep">OperationStep</a>s.
 * When the <code>Operation</code> is executed, it executes the steps
 * in the specified order.
 * @author Ivo Maixner
 */
public class Operation extends Executable
{
	protected Vector children;
/**
 * No args constructor is called by the externalizer.
 */
public Operation()
{
	this(null);
}
/**
 * Parametrized constructor to be called from user code.
 */
public Operation(String name)
{
	super(name);
	children = new Vector();
}
/**
 * Adds an <code>OperationStep</code> to this <code>Operation</code>.
 * @param step OperationStep
 */
public void addStep(OperationStep step)
{
	children.addElement(step);
	step.setContext(getContext());
}
/**
 * Returns the contained <code>OperationStep</code> on a given
 * (zero based) index.
 * @param i int
 * @return OperationStep
 */
public OperationStep getStep(int i)
{
	return (OperationStep) children.elementAt(i);
}
/**
 * Initializes this instance from a given XElement,
 * adds support for children.
 */
public void initializeFrom(XElement element)
{
	super.initializeFrom(element);
	children.removeAllElements();
	Enumeration elemChildren = element.getChildren();
	while (elemChildren.hasMoreElements())
	{
		XElement child = (XElement) elemChildren.nextElement();
		OperationStep step = (OperationStep) getExternalizer().createObject(child.getName());
		step.setContext(getContext());
		step.initializeFrom(child);
		addStep(step);
	}
}
/**
 * Runs (executes) the <code>Operation</code>.<p>
 * Executes contained <code>OperationStep</code>s in the specified order.<p>
 * Catches <code>AbortOperationException</code> and aborts the
 * execution on all subsequent steps when this exception is caught.
 */
public void run() {
	log("log.operation", "Operation invoked.");
	getThread().pushContext(getContext());
	for (int i = 0; i < children.size(); i++) {
		try {
			OperationStep step = getStep(i);
			step.log("log.operation.step", "Step invoked.");
			step.run();
		}
		catch (AbortOperationException aoe) {
			break;
		}
	}
	getThread().popContext();
}
/**
 * Runs this <code>Operation</code> in a <code>TheraThread</code>.
 * Waits for the completion.
 */
public void runFromOutside()
{
	TheraThread thread = new TheraThread(this, getName(), null);
	thread.execute();
}
/**
 * Sets the <code>Context</code> to which is this 
 * <code>Operation</code> bound.<p>
 * Sets the <code>Context</code> for all contained steps as well.
 * @param newContext thera.framework.Context
 */
public void setContext(Context context)
{
	super.setContext(context);
	for (int i = 0; i < children.size(); i++)
		getStep(i).setContext(context);
}
/**
 * Returns the number of child operation steps.
 * @return java.util.Enumeration
 */
public int size() {
	return children.size();
}
/**
 * Forms an XElement that reflects this instance,
 * adds support for children.
 */
public XElement toXElement()
{
	XElement elem = super.toXElement();
	for (int i = 0; i < children.size(); i++)
		elem.addChild(((External) children.elementAt(i)).toXElement());
	return elem;
}
}
package thera.framework;

import thera.utils.Verify;

import extern.*;
import extern.sxml.SXmlFactory;
/**
 * Thera externalizer. <p>
 * Creates the elements to be executed in run-time according
 * to a Thera configuration file.
 * @author Ivo Maixner
 */
public class XdeExternalizer extends Externalizer
{
	protected Context ctxRoot;
	private static XdeExternalizer inst;
/**
 * Constructs and loads an <code>XdeExternalizer</code> with a given 
 * factory and reader.
 * @param factory XItemFactory
 * @param data java.io.Reader
 */
public XdeExternalizer(XItemFactory factory, java.io.Reader data)
{
	super(factory, data);
	setUp();
}
/**
 * Constructs and loads an <code>XdeExternalizer</code> with a given 
 * factory, reader and writer.
 * @param factory XItemFactory
 * @param data java.io.Reader
 */
public XdeExternalizer(XItemFactory factory, java.io.Reader data, java.io.Writer writer)
{
	super(factory, data, writer);
	setUp();
}
/**
 * Returns a loaded default <code>XdeExternalizer</code> with a SXmlFactory
 * and a reader linked to file &quot;xde.xml&quot;.
 * @return XdeExternalizer
 */
public static XdeExternalizer getInstance() {
	if (null == inst) {
		java.io.Reader data;
		try {
			data = new java.io.FileReader("xde.xml");
		}
		catch (java.io.FileNotFoundException e) {
			throw new TheraRuntimeException("File not found: " + e.getMessage(), null);
		}
		inst = new XdeExternalizer(SXmlFactory.getInstance(), data);
		inst.init();
	}
	return inst;
}
