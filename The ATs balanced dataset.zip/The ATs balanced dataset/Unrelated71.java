    }

    private boolean queryRunnerListIsFull() {
        return activeQueryRunners.size() >= getMaxConcurrentQueries();
    }

    protected void addQueryRunnerToList(QueryRunnerInterface t, QueryRunnerWorkUnit qrwu) {
        activeQueryRunners.put(t, qrwu);
    }

    public void addQuery(String query) throws SQLException {
        addQuery(query, new NullResolvableDomainObject());
    }

    public void addQuery(String query, ResolvableFromConcurrentQuery resolvableDomainObject) throws SQLException {

        checkForCompletions();

        if (queryRunnerListIsFull()) {
            addQueryToQueue(query, resolvableDomainObject);
        } else if (!getQueuedQueries().isEmpty()) {
            while (!queryRunnerListIsFull() && !getQueuedQueries().isEmpty()) {
            	   ResolvableFromConcurrentQuery r = (ResolvableFromConcurrentQuery)getQueuedQueries().keySet().toArray()[0];
                String q = getQueuedQueries().get(r);
                getQueuedQueries().remove(r);
                startQueryRunner(q, r);
            }

            if (!queryRunnerListIsFull()) {
                startQueryRunner(query, resolvableDomainObject);
            } else {
                addQueryToQueue(query, resolvableDomainObject);                
            }

        } else {
            startQueryRunner(query, resolvableDomainObject);
        }

    }package net.sourceforge.concurrentQuery.query;

import net.sourceforge.concurrentQuery.domain.ResolvableFromConcurrentQuery;

import java.sql.Connection;

public class QueryRunnerWorkUnit {

    private String query = null;
    private ResolvableFromConcurrentQuery resolvableDomainObject = null;
    private Connection connection = null;

    private QueryRunnerWorkUnit(){}

    public QueryRunnerWorkUnit(String query, ResolvableFromConcurrentQuery resolvableDomainObject, Connection connection) {
        this.query = query;
        this.resolvableDomainObject = resolvableDomainObject;
        this.connection = connection;
    }

    public String getQuery() {
        return query;
    }

    public ResolvableFromConcurrentQuery getResolvableDomainObject() {
        return resolvableDomainObject;
    }

    public Connection getConnection() {
        return connection;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof QueryRunnerWorkUnit)) return false;

        final QueryRunnerWorkUnit queryRunnerWorkUnit = (QueryRunnerWorkUnit) o;

        if (query != null ? !query.equals(queryRunnerWorkUnit.query) : queryRunnerWorkUnit.query != null) return false;
        if (resolvableDomainObject != null ? !resolvableDomainObject.equals(queryRunnerWorkUnit.resolvableDomainObject) : queryRunnerWorkUnit.resolvableDomainObject != null) return false;
        if (connection != null ? !connection.equals(queryRunnerWorkUnit.connection) : queryRunnerWorkUnit.connection != null) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = (query != null ? query.hashCode() : 0);
        result = 29 * result + (resolvableDomainObject != null ? resolvableDomainObject.hashCode() : 0);
        result = 29 * result + (connection != null ? connection.hashCode() : 0);
        return result;
    }


}private boolean checkForCompletions() throws SQLException {

        boolean foundCompletedTask = false;

        if (!activeQueryRunners.isEmpty()) {
            for (QueryRunnerInterface queryRunner : activeQueryRunners.keySet()) {
                if (!queryRunner.isRunning()) {
                    foundCompletedTask = true;
                    if (queryRunner.getSQLException() != null) {
                        activeQueryRunners.remove(queryRunner);
                        throw new SQLException(queryRunner.getSQLException().getMessage());
                    }
                    activeQueryRunners.get(queryRunner).getResolvableDomainObject().processResultSet(queryRunner.getResultSet());
                    activeQueryRunners.remove(queryRunner);

                }
            }
        }

        return foundCompletedTask;

    }