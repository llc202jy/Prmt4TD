 * An SPI interface needed to be implemented by individual applications requiring an audit trail record keeping
 * functionality, to provide a current resource on which an audit-able action is being performed.
 * 
 * @author Dmitriy Kopylenko
 * @version $Revision$ $Date$
 * @since 1.0
 */
public interface AuditResourceResolver {

    /**
     * Resolve the auditable resource.
     * 
     * @param target the join point that contains the arguments.
     * @param returnValue	The returned value
     * @return	The resource String.
     */
    String[] resolveFrom(JoinPoint target, Object returnValue);
    
    /**
     * Resolve the auditable resource for an audit-able action that has
     * incurred an exception.
     * 
     * @param target the join point that contains the arguments.
     * @param exception	The exception incurred when the join point proceeds.
     * @return	The resource String.
     */
    String[] resolveFrom(JoinPoint target, Exception exception);
} * An SPI interface needed to be implemented by individual applications requiring an audit trail record keeping
 * functionality, to provide the action taken.
 * 
 * @author Scott Battaglia
 * @version $Revision$ $Date$
 * @since 1.0
 */
public interface AuditActionResolver {
	

    /**
     * Resolve the action for the audit event.
     * 
     * @param auditableTarget
     * @param retval	The returned value
     * @param audit the Audit annotation that may contain additional information.
     * @return	The resource String
     */
    String resolveFrom(JoinPoint auditableTarget, Object retval, Audit audit);
    
    /**
     * Resolve the action for the audit event that has incurred
     * an exception.
     * 
     * @param auditableTarget
     * @param exception	The exception incurred when the join point proceeds.
     * @param audit the Audit annotation that may contain additional information.
     * @return	The resource String
     */
    String resolveFrom(JoinPoint auditableTarget, Exception exception, Audit audit);

}