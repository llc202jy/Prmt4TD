import org.enhydra.shark.api.client.wfmc.wapi.WMSessionHandle;
import org.enhydra.shark.api.client.wfmodel.WfEventAudit;
import org.enhydra.shark.api.client.wfmodel.WfEventAuditIterator;
import org.enhydra.shark.api.common.SharkConstants;
import org.enhydra.shark.api.internal.eventaudit.AssignmentEventAuditPersistenceObject;
import org.enhydra.shark.api.internal.eventaudit.CreateProcessEventAuditPersistenceObject;
import org.enhydra.shark.api.internal.eventaudit.DataEventAuditPersistenceObject;
import org.enhydra.shark.api.internal.eventaudit.EventAuditManagerInterface;
import org.enhydra.shark.api.internal.eventaudit.EventAuditPersistenceInterface;
import org.enhydra.shark.api.internal.eventaudit.StateEventAuditPersistenceObject;
import org.enhydra.shark.api.internal.scripting.Evaluator;

/**
 * Iterator for event audits of activity or the process. The following names may be used:
 * time_stamp, username, event_type, activity_key, activity_name, process_key, process_name,
 * process_mgr_name, process_mgr_version, package_id, process_definition_id,
 * process_definition_name, activity_definition_id, activity_definition_name
 * and activity_definition_type 
 * that will be applied for all event types.
 * <p>
 * Here are the list of attributes that if specified will be applied to specific event
 * type:
 * <p>
 * WfCreateProcessEventAudit: p_activity_key, p_process_key, p_process_name,
 * p_process_mgr_name, p_process_mgr_version, p_package_id, p_process_definition_id,
 * p_process_definition_name, p_activity_definition_id and p_activity_definition_name
 * <p>
 * WfDataEventAudit: old_data_varId and new_data_varId, where varId is the Id of variable
 * from appropriate process/activity
 * <p>
 * WfStateEventAudit: old_state and new_state
 * <p>
 * WfAssignmentEventAudit: old_res, new_res and is_accepted
 * 
 * @author Sasa Bojanic
 */
public class WfEventAuditIteratorWrapper extends BaseIteratorWrapper implements
                                                                    WfEventAuditIterator {

   protected String procId;

   protected String actId;

   protected WfEventAuditIteratorWrapper(WMSessionHandle shandle, String procId) throws Exception {
      super(shandle);
      this.procId = procId;
   }

   protected WfEventAuditIteratorWrapper(WMSessionHandle shandle,
                                         String procId,
                                         String actId) throws Exception {
      super(shandle);
      this.procId = procId;
      this.actId = actId;
   }

   public WfEventAudit get_next_object() throws Exception {
      long tStamp = SharkUtilities.methodStart(shandle,"WfEventAuditIteratorWrapper.get_next_object");
      try {
         checkSecurity("get_next_object", null);

         return (WfEventAudit) super.getNextObject();
      } finally {
         SharkUtilities.methodEnd(shandle,tStamp,
                                  "WfEventAuditIteratorWrapper.get_next_object",
                                  this);
      }
   }

   public WfEventAudit get_previous_object() throws Exception {
      long tStamp = SharkUtilities.methodStart(shandle,"WfEventAuditIteratorWrapper.get_previous_object");
      try {
         checkSecurity("get_previous_object", null);

         return (WfEventAudit) super.getPreviousObject();
      } finally {
         SharkUtilities.methodEnd(shandle,tStamp,
                                  "WfEventAuditIteratorWrapper.get_previous_object",
                                  this);
      }
   }

   public WfEventAudit[] get_next_n_sequence(int max_number) throws Exception {
      long tStamp = SharkUtilities.methodStart(shandle,"WfEventAuditIteratorWrapper.get_next_n_sequence");
      try {
         checkSecurity("get_next_n_sequence", null);

         WfEventAudit[] ret = null;
         List l = super.getNextNSequence(max_number);
         ret = new WfEventAudit[l.size()];
         l.toArray(ret);
         return ret;
      } finally {
         SharkUtilities.methodEnd(shandle,tStamp,
                                  "WfEventAuditIteratorWrapper.get_next_n_sequence",
                                  this);
      }
   }

   public WfEventAudit[] get_previous_n_sequence(int max_number) throws Exception {
      long tStamp = SharkUtilities.methodStart(shandle,"WfEventAuditIteratorWrapper.get_previous_n_sequence");
      try {
         checkSecurity("get_previous_n_sequence", null);

         WfEventAudit[] ret = null;
         List l = super.getNextNSequence(max_number);
         ret = new WfEventAudit[l.size()];
         l.toArray(ret);
         return ret;
      } finally {
         SharkUtilities.methodEnd(shandle,tStamp,
                                  "WfEventAuditIteratorWrapper.get_previous_n_sequence",
                                  this);
      }
   }

   protected void fillObjectList() throws Exception {
      if (objectList != null)
         return;

      List events = new ArrayList();

      EventAuditManagerInterface eam = SharkEngineManager.getInstance()
         .getDefaultEventAuditManager();
      if (null != eam) {
         List l = new ArrayList();
         if (actId == null) {
            l.addAll(eam.restoreProcessHistory(shandle, procId));
         } else {
            l.addAll(eam.restoreActivityHistory(shandle, procId, actId));
         }
         Evaluator evaluator = SharkEngineManager.getInstance()
            .getScriptingManager()
            .getEvaluator(shandle,queryGrammar);

         boolean eVal = queryExpression != null && queryExpression.trim().length() > 0;

         for (int i = 0; i < l.size(); i++) {
            EventAuditPersistenceInterface po = (EventAuditPersistenceInterface) l.get(i);
            boolean toAdd = true;
            if (eVal) {
               Map context = new HashMap();
               context.put(SharkConstants.EA_TIME_STAMP, new Long(po.getRecordedTime()));
               context.put(SharkConstants.EA_USERNAME, new Long(po.getUsername()));
               context.put(SharkConstants.EA_EVENT_TYPE, po.getType());
               context.put(SharkConstants.EA_ACTIVITY_KEY, po.getActivityId());
               
                           po.getProcessDefinitionId());
               context.put(SharkConstants.EA_PROCESS_DEFINITION_NAME,
                           po.getProcessDefinitionName());
               context.put(SharkConstants.EA_ACTIVITY_DEFINITION_ID,
                           po.getActivityDefinitionId());
               context.put(SharkConstants.EA_ACTIVITY_DEFINITION_NAME,
                           po.getActivityDefinitionName());
               context.put(SharkConstants.EA_ACTIVITY_DEFINITION_TYPE,
                           new Integer(po.getActivityDefinitionType()));

               if (po instanceof CreateProcessEventAuditPersistenceObject) {
                  CreateProcessEventAuditPersistenceObject cpo = (CreateProcessEventAuditPersistenceObject) po;
                  
                  context.put(SharkConstants.CEA_P_ACTIVITY_DEFINITION_ID,
                              cpo.getPActivityDefinitionId());
                  context.put(SharkConstants.CEA_P_ACTIVITY_DEFINITION_NAME,
                              cpo.getPActivityDefinitionName());
               } else if (po instanceof DataEventAuditPersistenceObject) {
                  DataEventAuditPersistenceObject dpo = (DataEventAuditPersistenceObject) po;
                  if (queryExpression.indexOf(SharkConstants.DEA_OLD_DATA_) != -1) {
                     Map od = dpo.getOldData();
                     if (od != null) {
                        Iterator it = od.entrySet().iterator();
                        while (it.hasNext()) {
                           Map.Entry me = (Map.Entry) it.next();

                           String name = SharkConstants.DEA_OLD_DATA_
                                         + me.getKey().toString();
                           Object value = me.getValue();
                           context.put(name, value);
                        }
                     }
                  }
                  if (queryExpression.indexOf(SharkConstants.DEA_NEW_DATA_) != -1) {
                     Map nd = dpo.getNewData();
                     if (nd != null) {
                        Iterator it = nd.entrySet().iterator();
                        while (it.hasNext()) {
                           Map.Entry me = (Map.Entry) it.next();

                           String name = SharkConstants.DEA_NEW_DATA_
                                         + me.getKey().toString();
                           Object value = me.getValue();
                           context.put(name, value);
                        }
                     }
                  }

               } else if (po instanceof StateEventAuditPersistenceObject) {
                  StateEventAuditPersistenceObject spo = (StateEventAuditPersistenceObject) po;
                  context.put(SharkConstants.SEA_OLD_STATE, spo.getOldState());
                  context.put(SharkConstants.SEA_NEW_STATE, spo.getNewState());
               } else if (po instanceof AssignmentEventAuditPersistenceObject) {
                  AssignmentEventAuditPersistenceObject apo = (AssignmentEventAuditPersistenceObject) po;
                  context.put(SharkConstants.AEA_OLD_RES, apo.getOldResourceUsername());
                  context.put(SharkConstants.AEA_NEW_RES, apo.getNewResourceUsername());
                  context.put(SharkConstants.AEA_IS_ACCEPTED,
                              new Boolean(apo.getIsAccepted()));
               }

               toAdd = evaluator.evaluateCondition(shandle,
                                                   po.getProcessId(),
                                                   po.getActivityId(),
                                                   queryExpression,
                                                   context);
            }
            if (toAdd) {
               if (po instanceof CreateProcessEventAuditPersistenceObject) {
                  events.add(SharkEngineManager.getInstance()
                     .getObjectFactory()
                     .createCreateProcessEventAuditWrapper(shandle,
                                                           (CreateProcessEventAuditPersistenceObject) po));
               } else if (po instanceof DataEventAuditPersistenceObject) {
                  events.add(SharkEngineManager.getInstance()
                     .getObjectFactory()
                     .createDataEventAuditWrapper(shandle,
                                                  (DataEventAuditPersistenceObject) po));
               } else if (po instanceof StateEventAuditPersistenceObject) {
                  events.add(SharkEngineManager.getInstance()
                     .getObjectFactory()
                     .createStateEventAuditWrapper(shandle,
                                                   (StateEventAuditPersistenceObject) po));
               } else if (po instanceof AssignmentEventAuditPersistenceObject) {
                  events.add(SharkEngineManager.getInstance()
                     .getObjectFactory()
                     .createAssignmentEventAuditWrapper(shandle,
                                                        (AssignmentEventAuditPersistenceObject) po));
               }
            }
         }

      }

      setObjectList(events);
   }

}




import com.lutris.util.Config;

/**
 * This class is internally used to get all shark's managers.
 * 
 * @author Sasa Bojanic, Nenad Stefanovic, Vladimir Puskas
 */
public final class SharkEngineManager implements SharkInterface {
   private CallbackUtilities callbackUtilities;

   private ObjectFactory objectFactory;

   private ToolActivityHandler toolActivityHandler;

   private XMLInterface xmlInterface;

   private AssignmentManager assManager;

   private CacheMgr cacheManager;

   private PersistentManagerInterface instancePersistenceMgr;

   private List eventAuditManagers = new ArrayList();

   private LoggingManager logManager;

   private RepositoryPersistenceManager repPersistenceMgr;

   private ScriptingManager scriptingManager;

   private SecurityManager securityManager;

   private ToolAgentManager toolAgentManager;

   private TxSynchronizationFactory txSynchronizationFactory;

   private WfEngineInteroperability wfEngineInteroperabilityMgr;

   // the one and only instance of this class
   private static SharkEngineManager engineManager;

   static SharkEngineManager getInstance() {
      if (engineManager == null) {
         engineManager = new SharkEngineManager();
      }
      return engineManager;
   }

   void init(Properties props) {
      String cbuClassName = props.getProperty("CallbackUtilitiesClassName",
                                              "org.enhydra.shark.CallbackUtil");

      String objectFactoryClassName = props.getProperty("ObjectFactoryClassName",
                                                        "org.enhydra.shark.SharkObjectFactory");

      String tahClassName = props.getProperty("ToolActivityHandlerClassName",
                                              "org.enhydra.shark.StandardToolActivityHandler");

      String txsfClassName = props.getProperty("TxSynchronizationFactoryClassName",
                                               "org.enhydra.shark.SharkTxSynchronizationFactory");

      String amClassName = props.getProperty("AssignmentManagerClassName");

      String cmClassName = props.getProperty("CacheManagerClassName");

      String persistentManagerClassName = props.getProperty("InstancePersistenceManagerClassName");

      List eventAuditManagerClassNames = new ArrayList();
      String eamCNames = props.getProperty("EventAuditManagerClassName");
      String[] eamCNamesArr = null;
      if (eamCNames != null) {
         eamCNamesArr = MiscUtilities.tokenize(eamCNames, ",");
      }
      if (eamCNamesArr != null && eamCNames.length() > 0) {
         for (int i = 0; i < eamCNamesArr.length; i++) {
            eventAuditManagerClassNames.add(eamCNamesArr[i].trim());
         }
      } else {
         eventAuditManagerClassNames.add("");
      }

      String logClassName = props.getProperty("LoggingManagerClassName");

      String rpClassName = props.getProperty("RepositoryPersistenceManagerClassName");

      String smClassName = props.getProperty("ScriptingManagerClassName");

      String seClassName = props.getProperty("SecurityManagerClassName");

      String tamClassName = props.getProperty("ToolAgentManagerClassName");

      String wfEIClassName = props.getProperty("WfEngineInteroperabilityManagerClassName");

      ClassLoader cl = getClass().getClassLoader();

      try {
         callbackUtilities = (CallbackUtilities) cl.loadClass(cbuClassName).newInstance();
         callbackUtilities.setProperties(props);
         objectFactory = (ObjectFactory) cl.loadClass(objectFactoryClassName)
            .newInstance();
         toolActivityHandler = (ToolActivityHandler) cl.loadClass(tahClassName)
            .newInstance();

         txSynchronizationFactory = (TxSynchronizationFactory) cl.loadClass(txsfClassName)
            .newInstance();
         xmlInterface = new XMLInterfaceForJDK13();

      } catch (Throwable ex) {
         String msg = "SharkEngineManager -> Problems instantiating core managers - ";
         if (callbackUtilities == null) {
            msg += "Can't find CallbackUtilities class '"
                   + cbuClassName + "' in classpath!";
         } else if (objectFactory == null) {
            msg += "Can't find ObjectFactory class '"
                   + objectFactoryClassName + "' in classpath!";
         } else if (toolActivityHandler == null) {
            msg += "Can't find ToolActivityHandler class '"
                   + tahClassName + "' in classpath!";
         } else if (txSynchronizationFactory == null) {
            msg += "Can't find TxSynchronizationFactory class '"
                   + txsfClassName + "' in classpath!";
         } else {
            msg += "Unknown problem!";
         }
         System.err.println(msg);
         throw new RootError(msg, ex);
      }

      try {
         logManager = (LoggingManager) cl.loadClass(logClassName).newInstance();
         logManager.configure(callbackUtilities);
         callbackUtilities.info(null, "SharkEngineManager -> Working with '"
                                      + cbuClassName
                                      + "' implementation of core CallbackUtilities API");
         callbackUtilities.info(null, "SharkEngineManager -> Working with '"
                                      + objectFactoryClassName
                                      + "' implementation of core SharkObjectFactory API");
         callbackUtilities.info(null, "SharkEngineManager -> Working with '"
                                      + tahClassName
                                      + "' implementation of core ToolAgentManager API");
         callbackUtilities.info(null, "SharkEngineManager -> Working with '"
                                      + logClassName + "' implementation of Logging API");
      } catch (Exception ex) {
         boolean throwError = true;
         String msg = "SharkEngineManager -> Can't work - ";
         if (logClassName == null || logClassName.trim().equals("")) {
            msg = "SharkEngineManager -> Working without Logging API implementation - ";
            msg += "LoggingManager is not specified.";
            throwError = false;
         } else if (logManager == null) {
            msg += "Can't find LoggingManager class '" + logClassName + "' in classpath!";
         } else {
            msg += "Problems while configuring LoggingManager!";
         }
         callbackUtilities.info(null, msg);
         if (throwError) {
            throw new RootError(msg, ex);
         }
      }

      try {
         assManager = (AssignmentManager) cl.loadClass(amClassName).newInstance();
         assManager.configure(callbackUtilities);
         callbackUtilities.info(null, "SharkEngineManager -> Working with '"
                                      + amClassName
                                      + "' implementation of Assignment API");
      } catch (Exception ex) {
         boolean throwError = true;
         String msg = "SharkEngineManager -> Can't work - ";
         if (amClassName == null || amClassName.trim().equals("")) {
            msg = "SharkEngineManager -> Working without Assignment API implementation - ";
            msg += "AssignmentManager is not specified.";
            throwError = false;
         } else if (assManager == null) {
            msg += "Can't find AssignmentManager class '"
                   + amClassName + "' in classpath!";
         } else {
            msg += "Problems while configuring AssignmentManager!";
         }
         callbackUtilities.info(null, msg);
         if (throwError) {
            throw new RootError(msg, ex);
         }
      }

      try {
         cacheManager = (CacheMgr) cl.loadClass(cmClassName).newInstance();
         cacheManager.configure(callbackUtilities);
         callbackUtilities.info(null, "SharkEngineManager -> Working with '"
                                      + cmClassName + "' implementation of Caching API");
      } catch (Exception ex) {
         boolean throwError = true;
         String msg = "SharkEngineManager -> Can't work - ";
         if (cmClassName == null || cmClassName.trim().equals("")) {
            msg = "SharkEngineManager -> Working without Caching API implementation - ";
            msg += "CacheManager is not specified.";
            throwError = false;
         } else if (cacheManager == null) {
            msg += "Can't find CacheManager class '" + cmClassName + "' in classpath!";
         } else {
            msg += "Problems while configuring CacheManager!";
         }
         callbackUtilities.info(null, msg);
         if (throwError) {
            throw new RootError(msg, ex);
         }
      }

      try {
         instancePersistenceMgr = (PersistentManagerInterface) cl.loadClass(persistentManagerClassName)
            .newInstance();
         instancePersistenceMgr.configure(callbackUtilities);
         callbackUtilities.info(null, "SharkEngineManager -> Working with '"
                                      + persistentManagerClassName
                                      + "' implementation of InstancePersistence API");
      } catch (Exception ex) {
         String msg = "SharkEngineManager -> Can not work - ";
         if (persistentManagerClassName == null
             || persistentManagerClassName.trim().equals("")) {
            msg += "InstancePersistenceManager is not specified.";
         } else if (instancePersistenceMgr == null) {
            msg += "Can't find InstancePersistenceManager class '"
                   + persistentManagerClassName + "' in classpath";
         } else {
            msg += "Problems while configuring InstancePersistenceManager!";
         }
         callbackUtilities.error(null, msg, ex.getMessage());
         throw new RootError(msg, ex);
      }

      String eventAuditManagerClassName = "";
      EventAuditManagerInterface evAudMgr = null;
      try {
         for (int i = 0; i < eventAuditManagerClassNames.size(); i++) {
            eventAuditManagerClassName = (String) eventAuditManagerClassNames.get(i);
            evAudMgr = (EventAuditManagerInterface) cl.loadClass(eventAuditManagerClassName)
               .newInstance();
            evAudMgr.configure(callbackUtilities);
            eventAuditManagers.add(evAudMgr);
            callbackUtilities.info(null, "SharkEngineManager -> Working with '"
                                         + eventAuditManagerClassName
                                         + "' implementation of EventAudit API");
         }
      } catch (Exception ex) {
         boolean throwError = true;
         String msg = "SharkEngineManager -> Can't work - ";
         if (eventAuditManagerClassName == null
             || eventAuditManagerClassName.trim().equals("")) {
            msg = "SharkEngineManager -> Working without EventAudit API implementation - ";
            msg += "EventAuditManager is not specified.";
            throwError = false;
         } else if (evAudMgr == null) {
            msg += "Can't find EventAuditManager class '"
                   + eventAuditManagerClassName + "' in classpath!";
         } else {
            msg += "Problems while configuring EventAuditManager!";
         }
         callbackUtilities.info(null, msg);
         if (throwError) {
            throw new RootError(msg, ex);
         }
      }

      try {
         repPersistenceMgr = (RepositoryPersistenceManager) cl.loadClass(rpClassName)
            .newInstance();
         repPersistenceMgr.configure(callbackUtilities);
         callbackUtilities.info(null, "SharkEngineManager -> Working with '"
                                      + rpClassName
                                      + "' implementation of RepositoryPersistence API");
      } catch (Exception ex) {
         String msg = "SharkEngineManager -> Can not work - ";
         if (rpClassName == null || rpClassName.trim().equals("")) {
            msg += "RepositoryPersistenceManager is not specified.";
         } else if (repPersistenceMgr == null) {
            msg += "Can't find RepositoryPersistenceManager class '"
                   + rpClassName + "' in classpath";
         } else {
            msg += "Problems while configuring RepositoryPersistenceManager!";
         }
         callbackUtilities.error(null, msg, ex.getMessage());
         throw new RootError(msg, ex);
      }

      try {
         scriptingManager = (ScriptingManager) cl.loadClass(smClassName).newInstance();
         scriptingManager.configure(callbackUtilities);
         callbackUtilities.info(null, "SharkEngineManager -> Working with '"
                                      + smClassName + "' implementation of Scripting API");
      } catch (Exception ex) {
         String msg = "SharkEngineManager -> Can not work - ";
         if (smClassName == null || smClassName.trim().equals("")) {
            msg += "ScriptingManager is not specified.";
         } else if (scriptingManager == null) {
            msg += "Can't find ScriptingManager class '" + smClassName + "' in classpath";
         } else {
            msg += "Problems while configuring ScriptingManager!";
         }
         callbackUtilities.error(null, msg, ex.getMessage());
         throw new RootError(msg, ex);
      }

      try {
         securityManager = (SecurityManager) cl.loadClass(seClassName).newInstance();
         securityManager.configure(callbackUtilities);
         callbackUtilities.info(null, "SharkEngineManager -> Working with '"
                                      + seClassName + "' implementation of Security API");
      } catch (Exception ex) {
         boolean throwError = true;
         String msg = "SharkEngineManager -> Can't work - ";
         if (seClassName == null || seClassName.trim().equals("")) {
            msg = "SharkEngineManager -> Working without Security API implementation - ";
            msg += "SecurityManager is not specified.";
            throwError = false;
         } else if (securityManager == null) {
            msg += "Can't find SecurityManager class '" + seClassName + "' in classpath!";
         } else {
            msg += "Problems while configuring SecurityManager!";
         }
         callbackUtilities.info(null, msg);
         if (throwError) {
            throw new RootError(msg, ex);
         }
      }
