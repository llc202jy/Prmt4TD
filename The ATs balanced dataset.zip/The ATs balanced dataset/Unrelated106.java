
 * The <code>GumProxy</code> test. It will try to execute all steps from the
 * proxy creation, to the <code>EBGum<code> and the GridMachine.
 */
public class GumProxyTest2 extends TestCase implements PeerPreCommitTest {

	private static final long REQID_1 = 1;

	private GumSpec gumSpec;


	@Override
	protected void setUp() throws Exception {

		gumSpec = new GumSpec();
		gumSpec.putAttribute( GumSpec.ATT_NAME, "mockGum1" );

		Configuration.getInstance( Configuration.PEER );

	}


	@Override
	protected void tearDown() throws Exception {

		super.tearDown();
	}


	public void testGumFailure() throws RemoteException {

		Gum mockGum = EasyMock.createMock( Gum.class );
		EBPeerManagerFacade mockPeerManagerFacade = EasyMock.createMock( EBPeerManagerFacade.class );

		final EBGumFacade ebGum = EBGumCreator.createGuM( mockGum, gumSpec );
		ebGum.start();
		GumProxy proxyWithMockGum = new GumProxy( ebGum, mockPeerManagerFacade, REQID_1 );

		mockGum.startReplica();
		EasyMock.expectLastCall().andThrow( new ConnectException( "" ) ).once();

		mockPeerManagerFacade.lostGum( EasyMock.eq( gumSpec.getGumID() ), EasyMock.eq( REQID_1 ) );
		EasyMock.expectLastCall().once();

		EasyMock.replay( mockGum );
		EasyMock.replay( mockPeerManagerFacade );

		try {
			proxyWithMockGum.startReplica();
			fail();
		} catch ( RemoteException e ) {
		}

		EasyMock.verify( mockGum );
		EasyMock.verify( mockPeerManagerFacade );

	}
	package org.ourgrid.peer.manager.request;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.ourgrid.common.exception.RequestAlreadyExistsException;
import org.ourgrid.common.gump.GumpClient;
import org.ourgrid.common.id.GumID;
import org.ourgrid.common.id.ObjectID;
import org.ourgrid.common.spec.RequestSpec;
import org.ourgrid.common.spec.RequestSpec.RequestSource;
import org.ourgrid.peer.manager.allocation.AllocationEntry.GumSource;
import org.ourgrid.peer.manager.exception.RequestDoesNotExistException;

/**
 * Keeps track of all the requests and manage them.
 */
public class RequestManager {

	private Map<Long,RequestEntry> requests;

	private static RequestManager instance = null;


	public static RequestManager getInstance() {

		if ( instance == null ) {
			instance = new RequestManager();
		}

		return instance;
	}


	private RequestManager() {

		// this map must be sorted
		this.requests = new LinkedHashMap<Long,RequestEntry>();
	}


	/**
	 * Creates and stores a request.
	 */
	public RequestEntry createRequestEntry( RequestSpec requestSpec ) throws RequestAlreadyExistsException {

		RequestEntry requestEntry;

		if ( this.requestExists( requestSpec.getID() ) ) {
			throw new RequestAlreadyExistsException( "Already exists a request with ID <" + requestSpec.getID() + ">" );
		}

		requestEntry = new RequestEntry( requestSpec );

		requests.put( requestSpec.getID(), requestEntry );

		return requestEntry;
	}


	public boolean requestExists( long requestID ) {

		return this.requests.containsKey( requestID );
	}


	/**
	 * Get the <code>GumpClient</code> of the given request id.
	 * 
	 * @throws RequestDoesNotExistException
	 */
	public GumpClient getGumpClient( long requestID ) throws RequestDoesNotExistException {

		RequestEntry requestEntry;

		requestEntry = this.getRequestEntry( requestID );

		return requestEntry.getSpec().getGumpClient();

	}


	/**
	 * Informs that this request was canceled by its consumer.
	 */
	public void deleteRequest( long requestID ) {

		this.requests.remove( requestID );
	}


	/**
	 * Indicates that a request does not want more gums as far. The request was
	 * paused.
	 */
	public void pauseRequestGums( long requestID ) throws RequestDoesNotExistException {

		RequestEntry requestEntry = this.getRequestEntry( requestID );

		requestEntry.pauseRequest();
	}


	/**
	 * Indicates that a request needs gums again.
	 */
	public void resumeRequestGums( long requestID ) throws RequestDoesNotExistException {

		RequestEntry requestEntry = this.getRequestEntry( requestID );

		requestEntry.resumeRequest();
	}


	/**
	 * Refresh this request about the <code>hereIsGuM()</code> command.
	 * 
	 * @throws RequestDoesNotExistException
	 */
	public void hereIsGumToRequest( long requestID, GumID gumID ) throws RequestDoesNotExistException {

		RequestEntry requestEntry = this.getRequestEntry( requestID );

		requestEntry.hereIsGum( gumID );
	}


	/**
	 * Refresh this request about the <code>dispose</code> instruction.
	 * 
	 * @throws RequestDoesNotExistException
	 */
	public void removeGumFromRequest( long requestID, GumID gumID ) throws RequestDoesNotExistException {

		RequestEntry requestEntry = this.getRequestEntry( requestID );

		requestEntry.disposeOfGum( gumID );
	}


	private RequestEntry getRequestEntry( long requestID ) throws RequestDoesNotExistException {

		RequestEntry request = requests.get( requestID );
		if ( request == null ) {
			throw new RequestDoesNotExistException( requestID );
		}
		return request;
	}


	public Collection<RequestEntry> getAliveRequests( RequestSource source ) {

		Collection<RequestEntry> allRequests = this.requests.values();
		Collection<RequestEntry> chosenRequests = new LinkedList<RequestEntry>();

		for ( RequestEntry request : allRequests )
			if ( request.getSpec().getSource().equals( source ) && request.getStatus().isAlive() )
				chosenRequests.add( request );

		return chosenRequests;
	}


	public Collection<RequestEntry> getRequestsWithAllocatedGums( RequestSource source ) {

		Collection<RequestEntry> allRequests = this.requests.values();
		Collection<RequestEntry> chosenRequests = new LinkedList<RequestEntry>();

		for ( RequestEntry request : allRequests )
			if ( request.getSpec().getSource().equals( source ) && request.numberOfAllocatedGums() > 0 )
				chosenRequests.add( request );

		return chosenRequests;
	}


	/**
	 * Recovers a <code>Collection</code> containing all
	 * <code>GumpClient</code> local <code>RequestEntry</code>
	 * 
	 * @return The collection containing the local requests.
	 */
	public Collection<RequestEntry> getRequests( GumpClient gumpClient ) {

		Collection<RequestEntry> allRequests = this.requests.values();
		Collection<RequestEntry> result = new LinkedList<RequestEntry>();

		for ( RequestEntry request : allRequests ) {
			if ( request.getSpec().getGumpClient().equals( gumpClient ) ) {
				result.add( request );
			}
		}

		return result;
	}


	/**
	 * Recovers a <code>Collection</code> containing all <code>PeerID</code>
	 * local <code>RequestEntry</code>
	 * 
	 * @return The collection containing the requests from PeerID.
	 */
	public Collection<RequestEntry> getConsumerRequests( ObjectID peerID ) {

		Collection<RequestEntry> allRequests = this.requests.values();
		Collection<RequestEntry> result = new LinkedList<RequestEntry>();

		for ( RequestEntry request : allRequests ) {

			ObjectID objID;

			objID = request.getSpec().getObjectID();
			if ( peerID != null && objID.equals( peerID ) ) {
				result.add( request );
			}
		}

		return result;

	}


	/**
	 * Recovers a <code>Collection</code> containing all <code>PeerID</code>
	 * local <code>RequestEntry</code>
	 * 
	 * @return The collection containing the requests from PeerID.
	 */
	public Collection<Long> getConsumerRequestsIDs( ObjectID consumerID ) {

		Collection<Long> result = new LinkedList<Long>();

		for ( RequestEntry request : this.requests.values() ) {

			if ( request.getSpec().getObjectID().equals( consumerID ) ) {
				result.add( new Long( request.getSpec().getID() ) );
			}
		}

		return result;

	}


	public Collection<GumID> getGums( GumpClient gumpClient, GumSource source ) {

		Collection<RequestEntry> requestEntries = getRequests( gumpClient );
		Collection<GumID> result = new LinkedList<GumID>();
		for ( RequestEntry request : requestEntries ) {
			result.addAll( request.getGums( source ) );
		}

		return result;
	}


	public Collection<GumID> getGums( GumpClient gumpClient ) {

		Collection<GumID> gums = getGums( gumpClient, GumSource.LOCAL );
		gums.addAll( getGums( gumpClient, GumSource.REMOTE ) );

		return gums;

	}


	public Collection<GumID> getGums( ObjectID peerID ) {

		Collection<GumID> gums = getGums( peerID, GumSource.LOCAL );
		gums.addAll( getGums( peerID, GumSource.REMOTE ) );

		return gums;
	}


	public Collection<GumID> getGums( ObjectID peerID, GumSource source ) {

		Collection<RequestEntry> requestEntries = getConsumerRequests( peerID );
		Collection<GumID> result = new LinkedList<GumID>();
		for ( RequestEntry request : requestEntries ) {
			result.addAll( request.getGums( source ) );
		}

		return result;
	}


	/**
	 * Gets a Collection containing all consumers (local or remote)
	 * 
	 * @param source Choose if the list to be returned will be composed by local
	 *        or remote consumers
	 * @return A collection with the selected consumers
	 */
	public Collection<GumpClient> getConsumers( RequestSource source ) {

		Collection<GumpClient> consumers = new LinkedList<GumpClient>();

		for ( RequestEntry request : this.requests.values() ) {
			GumpClient consumer = request.getSpec().getGumpClient();

			if ( request.getSpec().getSource().equals( source ) && !consumers.contains( consumer ) )
				consumers.add( consumer );
		}

		return consumers;
	}


	/**
	 * Gets a Collection containing all Id's of current consumers
	 * 
	 * @param source Choose if the list to be returned will be composed by local
	 *        or remote consumers
	 * @return A collection with the selected consumers Id's
	 */
	public Collection<ObjectID> getConsumersIDs( RequestSource source ) {

		Collection<ObjectID> result = new LinkedList<ObjectID>();

		for ( RequestEntry request : this.requests.values() ) {
			ObjectID consumerId = request.getSpec().getObjectID();

			if ( request.getSpec().getSource().equals( source ) && !result.contains( consumerId ) )
				result.add( consumerId );
		}

		return result;
	}


	/**
	 * Selects the requests that still need Gums.
	 * 
	 * @return The collection containing the selected requests
	 */
	public Collection<RequestEntry> getRequestsThatNeedGums( Collection<RequestEntry> requestList ) {

		Collection<RequestEntry> requestsThatNeedGums = new LinkedList<RequestEntry>();

		for ( RequestEntry request : requestList ) {

			if ( request.needMoreGums() ) {
				requestsThatNeedGums.add( request );
			}
		}

		return requestsThatNeedGums;
	}


	public void unwantedGum( long requestID, GumID gumID ) throws RequestDoesNotExistException {

		RequestEntry request = this.getRequestEntry( requestID );

		request.unwantedGum( gumID );
	}


	public Set<GumID> getUnwantedGumsForRequest( long requestID ) throws RequestDoesNotExistException {

		RequestEntry request = this.getRequestEntry( requestID );

		return request.getUnwantedGums();
	}


	public static void reset() {

		instance = null;
	}


	public Collection<GumID> getRequestGums( long requestID ) throws RequestDoesNotExistException {

		RequestEntry request = this.getRequestEntry( requestID );

		return request.getGums();
	}


	public boolean requestIsLocal( long requestID ) throws RequestDoesNotExistException {

		RequestEntry request = this.getRequestEntry( requestID );

		return request.getSpec().isFromALocalBroker();
	}


	public void deleteConsumerRequests( ObjectID consumerID ) {

		Iterator<Entry<Long,RequestEntry>> it = this.requests.entrySet().iterator();

		while ( it.hasNext() ) {
			Entry<Long,RequestEntry> entry = it.next();
			if ( entry.getValue().getSpec().getObjectID().equals( consumerID ) ) {
				it.remove();
			}
		}
	}


	public RequestSpec getRequestSpec( long requestID ) throws RequestDoesNotExistException {

		RequestEntry request = this.getRequestEntry( requestID );

		return request.getSpec();
	}


	public boolean requestWantsGum( long requestID, GumID gumID ) throws RequestDoesNotExistException {

		RequestEntry request = this.getRequestEntry( requestID );

		return !request.isGumUnwanted( gumID );
	}


	public boolean requestNeedMoreGums( long requestId ) throws RequestDoesNotExistException {

		RequestEntry request = this.getRequestEntry( requestId );

		return request.needMoreGums();
	}


	public int getRequestNeededGums( long requestId ) throws RequestDoesNotExistException {

		RequestEntry request = this.getRequestEntry( requestId );

		return request.getNeededGums();
	}


	public boolean requestIsPaused( long requestId ) throws RequestDoesNotExistException {

		RequestEntry request = this.getRequestEntry( requestId );

		return request.isPaused();
	}


	public boolean requestHasGum( long requestId, GumID gumID ) throws RequestDoesNotExistException {

		RequestEntry request = this.getRequestEntry( requestId );

		return request.getGums().contains( gumID );
	}
}

import org.ourgrid.mygrid.ui.ConcreteUIServices;
import org.ourgrid.mygrid.ui.CouldNotAddJobException;
import org.ourgrid.mygrid.ui.MyGridSetter;
import org.ourgrid.mygrid.ui.UIServices;
import org.ourgrid.common.spec.*;
import org.ourgrid.common.util.TempFileManager;

/*
 * Copyright (c) 2002-2004 Universidade Federal de Campina Grande
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA
 */

/**
 * @author Alexandre N?brega Duarte - alex@dsc.ufcg.edu.br
 * 
 * Description: This class uses MyGrid to sort a data set read from stdin. The
 * sort process is done by breaking the input data on n sub-sets, sorting each
 * of the sub-sets individually and then merging the results to produce the
 * sorted output.
 * 
 * @version 1.0 Created on 18/08/2004
 */
public class GridSorter {

    /**
     * The Grid Description File wich provides information about the grid to be
     * used to sort the data.
     */
    private String gridDescriptionFile;

    /**
     * The number of tasks to be created to sorte the data. This also represents
     * the number of sub-sets that will be created from the given input data
     * set.
     */
    private int ntasks;

    /**
     * Creates a Grid Sorter with a given grid description file and a predefined
     * number of tasks.
     * 
     * @param gridDescriptionFile
     *            The Grid Description File wich provides information about the
     *            grid to be used to sort the data.
     * @param ntasks
     *            The number of tasks to be created to sorte the data. This also
     *            represents the number of sub-sets that will be created from
     *            the given input data set.
     */
    public GridSorter(String gridDescriptionFile, int ntasks) {

        this.gridDescriptionFile = gridDescriptionFile;
        this.ntasks = ntasks;

    }

    /**
     * Use MyGrid to sort a vector of strings.
     * 
     * @param input
     *            The vector of strings to be sorted.
     * @return An alphabetically ordered vector with all strings in input.
     * @throws GridSorterException
     *             If some problem ocurrs during the sort process.
     */
    public Vector sort(Vector input) throws GridSorterException {

        //Sets the grid
        try {

            MyGridSetter gridSetter = new MyGridSetter();
            gridSetter.setGrid(gridDescriptionFile);

        } catch (RemoteException re) {

            throw new GridSorterException("Could not contact MyGrid!", re);

        } catch (CompilerException ce) {

            throw new GridSorterException("Could not set the grid!", ce);

        }

        //Creates the job that will sort the input.
        try {

            JobSpec sorterJob = createSorterJobSpec(input);
            
            addAndWaitForJob(sorterJob);

        } catch (IOException ioe) {

            throw new GridSorterException("Could not create sorter job spec!", ioe);

        } catch (JobSpecificationException e) {
        	throw new GridSorterException("Problems with the Job Specification!", e);
	}

        File outputFile = null;
        Vector output = null;

        //Merges the results from the sorter job.
        try {

            outputFile = TempFileManager.createTempFile();
            JobSpec mergerJobSpec = createMergerJobSpec(outputFile.getAbsolutePath());
            addAndWaitForJob(mergerJobSpec);
            output = readOutput(outputFile);

        } catch (IOException ioe) {

            throw new GridSorterException("Could not merge the sorter results!", ioe);

        } catch (JobSpecificationException e) {
        	throw new GridSorterException("Problems with the Job Specification!", e);
	}

        return output;

    }

    /**
     * Asks MyGrid to execute a given job and waits for its end.
     * 
     * @param aJobSpec
     *            A job to be executed by MyGrid.
     * @throws GridSorterException
     *             If the job could not be executed by some problem.
     */
    private void addAndWaitForJob(JobSpec aJobSpec) throws GridSorterException {

        UIServices services = ConcreteUIServices.getInstance();

        try {

            int jobId = services.addJob(aJobSpec);
            services.waitForJob(jobId);

        } catch (CouldNotAddJobException cnaje) {

            throw new GridSorterException("Could not add the Job Spec!", cnaje);

        } catch (JobNotFoundException jnfe) {

            throw new GridSorterException("Could not wait for the Job Spec!", jnfe);

        } catch (RemoteException re) {

            throw new GridSorterException("Could not contact MyGrid!", re);

        }

    }

    /**
     * Creates a job spec for the sorter job. This jobs breaks the input set in
     * n sub-set and sort then individually.
     * 
     * @param list
     *            The data set to be sorted.
     * @return A job spec the represents a sorter job.
     * @throws IOException
     *             If it could not create the sub-sets for the given data set.
     * @throws JobSpecificationException
     */
    private JobSpec createSorterJobSpec(Vector list) throws IOException, JobSpecificationException {

        JobSpec aJobSpec = new JobSpec("Sorter");

        int slicesSize = list.size() / ntasks;
        int pos = 0;
        Vector taskList = new Vector();

        for (int i = 0; i < ntasks; i++) {
            File input = TempFileManager.createTempFile();
            BufferedWriter writer = new BufferedWriter(new FileWriter(input));
            for (int j = 0; j < slicesSize && pos < list.size(); j++, pos++) {
                writer.write(list.elementAt(pos).toString());
                writer.newLine();
            }
            writer.flush();
            writer.close();

            taskList.add(createSorterTaskSpec(input.getAbsolutePath()));

        }

        aJobSpec.setTaskSpecs(taskList);

        return aJobSpec;

    }

    /**
     * Creates a job spec for the merger job. This jobs merges the output from
     * the sorter job to produce a sorted set as output.
     * 
     * @param outputFilePath
     *            The file where the sorted data will be saved.
     * @return A job spec that represents the merger job.
     * @throws JobSpecificationException
     */
    private JobSpec createMergerJobSpec(String outputFilePath) throws JobSpecificationException {

        JobSpec aJobSpec = new JobSpec("Merger");

        Vector taskList = new Vector();
        taskList.add(createMergerTaskSpec(outputFilePath));
        aJobSpec.setTaskSpecs(taskList);

        return aJobSpec;

    }

    /**
     * Creates a task spec to sort a given input file, which is a subset of the
     * whole input data set. It uses the unix sort command to sorte the file.
     * 
     * @param inputFile
     *            The file to be sorted.
     * @return A taskspec that sorts a given input file.
     */
    private TaskSpec createSorterTaskSpec(String inputFile) {

        IOBlock initBlock = new IOBlock();
        String remoteScript = "nice sort $STORAGE/sorter-$TASK.input > sorter-$TASK.output";
        IOBlock finalBlock = new IOBlock();

        initBlock.putEntry(new IOEntry("STORE", inputFile, "sorter-$TASK.input"));

        finalBlock.putEntry(new IOEntry("GET", "sorter-$TASK.output", "/tmp/gridsorter/sorter-$TASK.output"));

        TaskSpec taskSpec = null;

        try {
            taskSpec = new TaskSpec(initBlock, remoteScript, finalBlock);
        } catch (TaskSpecificationException e) {
            //This should never be throwed since WE are creating the task
            // specification here.
            e.printStackTrace();
        }

        return taskSpec;

    }

    /**
     * Creates a task spec to merge the sorted files produced by the sorter job.
     * It uses the unix sort command to merge the files.
     * 
     * @param outputFilePath
     *            The file where the sorted data will be saved.
     * @return A task spec that merge sorted files.
     */
    private TaskSpec createMergerTaskSpec(String outputFilePath) {

        IOBlock initBlock = new IOBlock();

        for (int i = 1; i <= ntasks; i++) {
            initBlock.putEntry(new IOEntry("STORE", "/tmp/gridsorter/sorter-" + i + ".output", "merger-" + i + ".input"));
        }

        String remoteScript = "nice sort -m";
        for (int i = 1; i <= ntasks; i++) {
            remoteScript = remoteScript + " $STORAGE/merger-" + i + ".input";
        }

        remoteScript = remoteScript + " > merger-$JOB.output";

        IOBlock finalBlock = new IOBlock();

        finalBlock.putEntry(new IOEntry("GET", "merger-$JOB.output", outputFilePath));
        TaskSpec taskSpec = null;

        try {
            taskSpec = new TaskSpec(initBlock, remoteScript, finalBlock);
        } catch (TaskSpecificationException e) {
            //This should never be throwed since WE are creating the task
            // specification here.
            e.printStackTrace();
        }

        return taskSpec;
    }

    /**
     * Creates a vector with all file data.
     * 
     * @param outputFile
     *            The file to be read.
     * @return A vector with all file data,
     * @throws IOException
     *             If cannot read or find the file.
     */
    private Vector readOutput(File outputFile) throws IOException {

        BufferedReader reader = new BufferedReader(new FileReader(outputFile));
        String line;
        Vector v = new Vector();

        while ((line = reader.readLine()) != null) {
            v.add(line);
        }

        return v;

    }

    /**
     * This methods reads data from the stdin, sort it using the GridSorter and
     * prints the sorted result to the stdout.
     * 
     * @param args
     *            The main method needs two command line argumenst: the grid
     *            description file name and the number of tasks to be created.
     *  
     */
    public static void main(String args[]) {

        if( args.length !=2 ) {
            
            System.err.println( "java GridSorter grid_description_file number_of_tasks");
            System.exit(1);
            
        }
        
        GridSorter gridSorter = new GridSorter(args[0], Integer.parseInt(args[1]));

        Vector list = new Vector();
        
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
                        
            String line;            
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line != "") {
                    list.add(line);
                }
            }
            
            reader.close();
        } catch (IOException ioe) {

            System.err.println( "Could not read input data! Cause: " + ioe.getMessage() );
            System.exit(2);
            
        }

        try {            
            Vector output = gridSorter.sort(list);
            
            Iterator it = output.iterator();
            while(it.hasNext() ) {
                System.out.println( it.next() );
            }

        } catch (GridSorterException gse) {

            System.err.println( gse.getMessage() );
            System.exit(3);
            
        }
        
        System.exit(0);

    }

}
/*
 * Copyright (c) 2002-2006 Universidade Federal de Campina Grande
 * 
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA
 */
package org.ourgrid.deployer;



