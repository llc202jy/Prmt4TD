
template<unsigned int MAX_UNREAD, unsigned int MAX_RECEIVERS, unsigned int MAX_SENDERS>
void MessageQueue<MAX_UNREAD,MAX_RECEIVERS,MAX_SENDERS>::markRead(index_t msg, SemaphoreManager::semid_t rcvr) {
		AutoLock autolock(lock);
		index_t rcvr_id=lookupReceiver(rcvr);
		if(rcvr_id==rcvrs.end())
			return;
		if(mq[msg].readFlags[rcvr_id]) {
			std::cerr << "WARNING: MessageQueue::markRead(): Receiver re-reading message, could be recycled/invalidated any time" << std::endl;
			return; // already read, just return it
		}
		mq[msg].readFlags[rcvr_id]=true;
		mq[msg].numRead++;
		if(mq[msg].numRead==numReceivers) {
			//all processes have gotten a look, remove the neutral MessageQueue reference
			RCRegion * rcr = RCRegion::attach(mq[msg].id);
			rcr->RemoveSharedReference();
			rcr->RemoveReference();
			mq.erase(msg);
			messagesRead++;
			for(index_t sit=sndrs.begin(); sit!=sndrs.end(); sit=sndrs.next(sit))
				semgr->raise(sndrs[sit],1);
		}
}

template<unsigned int MAX_UNREAD, unsigned int MAX_RECEIVERS, unsigned int MAX_SENDERS>
typename MessageQueue<MAX_UNREAD,MAX_RECEIVERS,MAX_SENDERS>::rcvrs_t::index_t
MessageQueue<MAX_UNREAD,MAX_RECEIVERS,MAX_SENDERS>::lookupReceiver(SemaphoreManager::semid_t rcvr) const {
	for(index_t rcvr_id=rcvrs.begin(); rcvr_id!=rcvrs.end(); rcvr_id=rcvrs.next(rcvr_id))
		if(rcvrs[rcvr_id]==rcvr)
			return rcvr_id;
	std::cerr << "WARNING: tried to look up queue receiver " << rcvr << ", which is not registered as a receiver for this queue" << std::endl;
	return rcvrs.end();
}

/*! @file
 * @brief Defines MessageQueue, which provides mechanisms for sending shared memory regions between processes
 * @author ejt (Creator)
 *
 * $Author: ejt $
 * $Name:  $
 * $Revision: 1.31 $
 * $State: Exp $
 * $Date: 2007/03/16 19:48:04 $
 */

#endif //APERIOS check

#endif //INCLUDED


template<unsigned int MAX_UNREAD, unsigned int MAX_RECEIVERS, unsigned int MAX_SENDERS>
RCRegion * MessageQueue<MAX_UNREAD,MAX_RECEIVERS,MAX_SENDERS>::readMessage(index_t msg, SemaphoreManager::semid_t rcvr) {
		AutoLock autolock(lock);
		RCRegion * rcr = RCRegion::attach(mq[msg].id);
		index_t rcvr_id=lookupReceiver(rcvr);
		if(rcvr_id==rcvrs.end())
			return rcr;
		if(mq[msg].readFlags[rcvr_id]) {
			std::cerr << "WARNING: MessageQueue::readMessage(): Receiver re-reading message, could be recycled/invalidated any time" << std::endl;
			return rcr; // already read, just return it
		}
		mq[msg].readFlags[rcvr_id]=true;
		mq[msg].numRead++;
		if(mq[msg].numRead==numReceivers) {
			//all processes have gotten a look, remove the neutral MessageQueue reference
			rcr->RemoveSharedReference();
			mq.erase(msg);
			messagesRead++;
			for(index_t sit=sndrs.begin(); sit!=sndrs.end(); sit=sndrs.next(sit))
				semgr->raise(sndrs[sit],1);
		}
		return rcr;
}

template<unsigned int MAX_UNREAD, unsigned int MAX_RECEIVERS, unsigned int MAX_SENDERS>
RCRegion * MessageQueue<MAX_UNREAD,MAX_RECEIVERS,MAX_SENDERS>::peekMessage(index_t msg) {
		//AutoLock autolock(lock); //I don't think a lock is necessary here
		return RCRegion::attach(mq[msg].id);
}
	// *** Entering Burns-Lamport *** //
	do {
		doors[i].BL_in_use=true;
		for(unsigned int t=0; t<i; t++)
			if(doors[t].BL_in_use) {
				doors[i].BL_in_use=false;
				if(!block) {
					doors[i].BL_ready=false;
#ifdef DEBUG_MUTEX_LOCK
					if(state==NULL || state->buttons[LFrPawOffset])
						std::cerr << doors[i].id << " giving up on lock " << this << " held by " << owner_index << " at " << get_time() << std::endl;
#endif	
					return false;
				}
				while(doors[t].BL_in_use)
					spin();
				break;
			}
	} while(!doors[i].BL_in_use);
	for(unsigned int t=i+1; t<num_doors; t++)
		while(doors[t].BL_in_use)
			spin();
	// *** Leaving Burns-Lamport ***//
	// *** Lock has been given *** //
	owner_index=i;
#ifdef DEBUG_MUTEX_LOCK
	if(state==NULL || state->buttons[LFrPawOffset])
		std::cerr << doors[i].id << " received lock " << this << " at " << get_time() << std::endl;
#endif	
	return true;
}


template<unsigned int num_doors>
unsigned int
MutexLock<num_doors>::lookup(int id) {
	// TODO - this could break if two new processes are adding themselves at the same time
	//        or an id is being forgotten at the same time
	//I'm expecting a very small number of processes to be involved
	//probably not worth overhead of doing something fancy like a sorted array
	unsigned int i;
	for(i=0; i<doors_used; i++)
		if(doors[i].id==id)
			return i;
	if(i==num_doors)
		return NO_OWNER;
	doors[i].id=id;
	doors_used++;
	return i;
}


template<unsigned int num_doors>
void
MutexLock<num_doors>::forget(int id) { //not tested thoroughly (or at all?)
	unsigned int i = lookup(id);
	do_try_lock(i,true);
	doors[i].id=doors[--doors_used].id;
	doors[doors_used].id=NO_OWNER;
	releaseAll();
}

#endif //MUTEX_LOCK_ET_USE_SOFTWARE_ONLY

/*! @file 
 * @brief Defines MutexLock, a software only mutual exclusion lock.
 * @author ejt (Creator), Edward A. Lycklama, Vassos Hadzilacos (paper from which this was based)
 *
 * $Author: ejt $
 * $Name:  $
 * $Revision: 1.19 $
 * $State: Exp $
 * $Date: 2007/06/14 06:53:36 $
 */

template<unsigned int num_doors>
bool
MutexLock<num_doors>::do_try_lock(unsigned int i, bool block) {
	if(i==NO_OWNER) {
		std::cerr << "WARNING: new process attempted to lock beyond num_doors ("<<num_doors<<")" << std::endl;
		return false;
	}
#ifdef DEBUG_MUTEX_LOCK
	if(state==NULL || state->buttons[LFrPawOffset])
		std::cerr << doors[i].id << " attempting lock " << this << " held by " << owner_index << " at " << get_time() << std::endl;
#endif	
	unsigned char S[num_doors]; // a local copy of everyone's doors
	// *** Entering FCFS doorway *** //
	doors[i].FCFS_in_use=true;
	for(unsigned int j=0; j<num_doors; j++)
		S[j]=doors[j].turn;
	doors[i].next_turn_bit=1-doors[i].next_turn_bit;
	doors[i].turn^=(1<<doors[i].next_turn_bit);
	doors[i].BL_ready=true;
	doors[i].FCFS_in_use=false;
	// *** Leaving FCFS doorway *** //
	for(unsigned int j=0; j<num_doors; j++) {
		while(doors[j].FCFS_in_use || (doors[j].BL_ready && S[j]==doors[j].turn))
			if(block)
				spin();
			else {
				doors[i].BL_ready=false;
#ifdef DEBUG_MUTEX_LOCK
				if(state==NULL || state->buttons[LFrPawOffset])
					std::cerr << doors[i].id << " giving up on lock " << this << " held by " << owner_index << " at " << get_time() << std::endl;
#endif	
				return false;
			}
	}
template<unsigned int num_doors>
void
MutexLock<num_doors>::unlock() {
	if(lockcount==0) {
		std::cerr << "Warning: MutexLock::unlock caused underflow" << std::endl;
		return;
	}
#ifdef DEBUG_MUTEX_LOCK
	if(state==NULL || state->buttons[LFrPawOffset])
		std::cerr << doors[owner_index].id << " unlock " << this << " level "<< lockcount << std::endl;
#endif
	if(--lockcount==0) {
		if(owner_index!=NO_OWNER) {
			unsigned int tmp = owner_index;
			owner_index=NO_OWNER;
			doors[tmp].BL_in_use=false;
			doors[tmp].BL_ready=false;
			// *** Lock has been released *** //
#ifndef PLATFORM_APERIOS
			if(owner_index==id) {
				thdLock[sem].unlock();
			}
#endif
		}
	}
}


//! If you define this to do something more interesting, can use it to see what's going on in the locking process
//#define mutexdebugout(i,c) { std::cout << ((char)(i==0?c:((i==1?'M':'a')+(c-'A')))) << std::flush; }


#ifndef PLATFORM_APERIOS
#include "RCRegion.h"
#include "Shared/MarkScope.h"
#include "Shared/debuget.h"
#include "Thread.h"
#include <unistd.h>
#include <sstream>
#include <sys/stat.h>
#include <errno.h>

#if TEKKOTSU_SHM_STYLE!=SYSV_SHM && TEKKOTSU_SHM_STYLE!=POSIX_SHM && TEKKOTSU_SHM_STYLE!=NO_SHM
#  error Unknown TEKKOTSU_SHM_STYLE setting
#endif

#if TEKKOTSU_SHM_STYLE==SYSV_SHM
#  include <sys/ipc.h>
#  include <sys/shm.h>
#elif TEKKOTSU_SHM_STYLE==POSIX_SHM
#  include <sys/mman.h>
#  include <sys/fcntl.h>
#  ifdef USE_UNBACKED_SHM
plist::Primitive<bool> RCRegion::useUniqueMemoryRegions(false);
#  else
plist::Primitive<std::string> RCRegion::shmRoot("/tmp/tekkotsu_sim/");
plist::Primitive<bool> RCRegion::useUniqueMemoryRegions(true);
#  endif
pid_t RCRegion::rootPID(::getpid());
#endif

using namespace std;

#if TEKKOTSU_SHM_STYLE==SYSV_SHM
key_t RCRegion::nextKey=1024;
#elif TEKKOTSU_SHM_STYLE==POSIX_SHM || TEKKOTSU_SHM_STYLE==NO_SHM
key_t RCRegion::nextKey=0;
#endif

RCRegion::attachedRegions_t RCRegion::attachedRegions;
bool RCRegion::isFaultShutdown=false;
bool RCRegion::multiprocess=true;
ThreadNS::Lock* RCRegion::staticLock=NULL;


#if TEKKOTSU_SHM_STYLE==SYSV_SHM
//under SYSV shared memory, the keys are just numbers, and it's just as likely that the conflicted
//region belongs to an unrelated process as it is that the region is from a previous run -- so we
//take the safe route and rename our own keys
RCRegion::ConflictResolutionStrategy RCRegion::conflictStrategy=RCRegion::RENAME;

#elif TEKKOTSU_SHM_STYLE==POSIX_SHM
//under POSIX shared memory, the keys are names, so we can have some confidence that a region
//with the same name is ours from a previous run, so we replace it to avoid leaking (although
//it's still possible we're conflicting with another application, but good name choices should
//mitigate this)
RCRegion::ConflictResolutionStrategy RCRegion::conflictStrategy=RCRegion::REPLACE;

#elif TEKKOTSU_SHM_STYLE==NO_SHM
//with shared memory disabled, a conflict indicates we're reusing the same name... this is probably
//a bug, so we should fail-fast
RCRegion::ConflictResolutionStrategy RCRegion::conflictStrategy=RCRegion::EXIT;

#endif

RCRegion * RCRegion::attach(const Identifier& rid) {
	MarkScope l(getStaticLock());
	attachedRegions_t::iterator it=attachedRegions.find(rid.key);
	if(it==attachedRegions.end())
		return new RCRegion(rid); // the constructor will add entry to attachedRegions
	else {
		ASSERTRETVAL((*it).second!=NULL,"ERROR: attached region is NULL!",NULL);
		(*it).second->AddReference();
		return (*it).second;
	}
}

void RCRegion::AddReference() {
	MarkScope l(getStaticLock());
	//cout << "AddReference " << id.shmid << ' ' << ProcessID::getID();
	references[ProcessID::getID()]++;
	references[ProcessID::NumProcesses]++;
	//cout << " counts are now:";
	//for(unsigned int i=0; i<ProcessID::NumProcesses+1; i++)
	//	cout << ' ' << references[i];
	//cout << endl;
}

void RCRegion::RemoveReference() {
	//cout << "RemoveReference " << id.key << ' ' << ProcessID::getID();
	ThreadNS::Lock * old=NULL;
	{
		MarkScope l(getStaticLock());
		if(references[ProcessID::getID()] == 0) {
			cerr << "Warning: RCRegion reference count underflow on " << id.key << " by " << ProcessID::getID() << "!  ";
			for(unsigned int i=0; i<ProcessID::NumProcesses+1; i++)
				cerr << ' ' << references[i];
			cerr << endl;
			return;
		}
		bool wasLastProcRef=(--references[ProcessID::getID()] == 0);
		bool wasLastAnyRef=(--references[ProcessID::NumProcesses] == 0);
		ASSERT(wasLastProcRef || !wasLastAnyRef,"global reference decremented beyond process reference");
#if TEKKOTSU_SHM_STYLE==NO_SHM
		wasLastProcRef=wasLastAnyRef;
#else
		if(!multiprocess)
			wasLastProcRef=wasLastAnyRef;
#endif
		/*if(isFaultShutdown) {
			cerr << "Process " << ProcessID::getID() << " dereferenced " << id.key << ".  Counts are now:";
			for(unsigned int i=0; i<ProcessID::NumProcesses+1; i++)
				cerr << ' ' << references[i];
			cerr << endl;
		}*/
		if(wasLastProcRef) {
			//cout << " detach";
#if TEKKOTSU_SHM_STYLE==SYSV_SHM
			if(shmdt(base)<0)
				perror("Warning: Region detach");
			base=NULL;
			references=NULL;
			if(wasLastAnyRef) {
				//cout << " delete" << endl;
				if(shmctl(id.shmid,IPC_RMID,NULL)<0)
					perror("Warning: Region delete");
			}
#elif TEKKOTSU_SHM_STYLE==POSIX_SHM
			if(munmap(base,calcRealSize(id.size))<0) {
				perror("Warning: Shared memory unmap (munmap)");
			}
			base=NULL;
			references=NULL;
			if(wasLastAnyRef) {
				//cout << " delete" << endl;
				if(!unlinkRegion()) {
					int err=errno;
					if(isFaultShutdown && (err==EINVAL || err==ENOENT))
						//On a fault shutdown, we initially try to unlink everything right away,
						// so an error now is just confirmation that it worked
						cerr << "Region " << id.key << " appears to have been successfully unlinked" << endl;
					else {
						cerr << "Warning: Shared memory unlink of region " << id.key << " returned " << strerror(err);
						if(err==EINVAL || err==ENOENT)
							cerr << "\n         May have already been unlinked by a dying process.";
						cerr << endl;
					}
				} else if(isFaultShutdown)
					//That shouldn't have succeeded on a faultShutdown...
					cerr << "Region " << id.key << " appears to have been successfully unlinked (nonstandard)" << endl;
			}
#elif TEKKOTSU_SHM_STYLE==NO_SHM
			delete base;
			base=NULL;
			references=NULL;
#else
#  error "Unknown TEKKOTSU_SHM_STYLE setting"
#endif
			delete this;
			if(attachedRegions.size()==0 && !isFaultShutdown) {
				//was last attached region, clean up lock for good measure
				old=staticLock;
				staticLock=NULL;
			}
		}
	}
	delete old;
	//cout << endl;
}

void RCRegion::AddSharedReference() {
	MarkScope l(getStaticLock());
	//cout << "AddSharedReference " << id.shmid << ' ' << ProcessID::getID();
	references[ProcessID::NumProcesses]++;
	//cout << " counts are now:";
	//for(unsigned int i=0; i<ProcessID::NumProcesses+1; i++)
	//	cout << ' ' << references[i];
	//cout << endl;
}

void RCRegion::RemoveSharedReference() {
	MarkScope l(getStaticLock());
	//cout << "RemoveSharedReference " << id.shmid << ' ' << ProcessID::getID();
	if(references[ProcessID::NumProcesses]==0) {
		cerr << "Warning: RCRegion shared reference count underflow on " << id.key << " by " << ProcessID::getID() << "!  ";
		for(unsigned int i=0; i<ProcessID::NumProcesses+1; i++)
			cerr << ' ' << references[i];
		cerr << endl;
		return;
	}
	references[ProcessID::NumProcesses]--;
	ASSERT(references[ProcessID::NumProcesses]>0,"removal of shared reference was last reference -- should have local reference as well");
	//cout << " counts are now:";
	//for(unsigned int i=0; i<ProcessID::NumProcesses+1; i++)
	//	cout << ' ' << references[i];
	//cout << endl;
}


void RCRegion::aboutToFork(ProcessID::ProcessID_t newID) {
	//cout << "RCRegion aboutToFork to " << newID << endl;
	ThreadNS::Lock* old;
	{
		MarkScope l(getStaticLock());
		attachedRegions_t::const_iterator it=attachedRegions.begin();
		for(; it!=attachedRegions.end(); ++it) {
			//cout << "Duplicating attachments for " << (*it).first;
			(*it).second->references[newID]=(*it).second->references[ProcessID::getID()];
			(*it).second->references[ProcessID::NumProcesses]+=(*it).second->references[newID];
			//cout << " counts are now:";
			//for(unsigned int i=0; i<ProcessID::NumProcesses+1; i++)
			//	cout << ' ' << (*it).second->references[i];
			//cout << endl;
		}
		old=staticLock;
		staticLock=NULL;
	}
	delete old;
}

void RCRegion::faultShutdown() {
	MarkScope l(getStaticLock());
	if(isFaultShutdown) {
		cerr << "WARNING: RCRegion::faultShutdown() called again... ignoring" << endl;
		return;
	}
	isFaultShutdown=true;
	if(attachedRegions.size()==0) {
		cerr << "WARNING: RCRegion::faultShutdown() called without any attached regions (may be a good thing?)" << endl;
		return;
	}
#if TEKKOTSU_SHM_STYLE==POSIX_SHM
	//this may not really work, but it's worth a last-ditch attempt
	//in case the reference counts are screwed up.
	attachedRegions_t::const_iterator it=attachedRegions.begin();
	for(; it!=attachedRegions.end(); ++it) {
		cerr << "RCRegion::faultShutdown(): Process " << ProcessID::getID() << " unlinking " << (*it).second->id.key << endl;
#ifdef USE_UNBACKED_SHM
		shm_unlink(getQualifiedName((*it).second->id.key).c_str());
#else
		unlink(getQualifiedName((*it).second->id.key).c_str());
#endif
	}
#endif
	for(unsigned int i=0; i<100; i++) {
		unsigned int attempts=ProcessID::NumProcesses;
		unsigned int lastSize=attachedRegions.size();
		while(attachedRegions.size()==lastSize && attempts-->0)
			(*attachedRegions.begin()).second->RemoveReference();
		if(attempts==-1U) {
			cout << "Warning: could not dereference " << attachedRegions.begin()->second->id.key << endl;
			attachedRegions.erase(attachedRegions.begin());
		}
		if(attachedRegions.size()==0)
			break;
	}
}

RCRegion::attachedRegions_t::const_iterator RCRegion::attachedBegin(bool threadSafe) {
	if(threadSafe) {
		MarkScope l(getStaticLock());
		attachedRegions.begin()->second->AddReference();
		return attachedRegions.begin();
	} else
		return attachedRegions.begin();
}
RCRegion::attachedRegions_t::const_iterator RCRegion::attachedEnd() {
	return attachedRegions.end();
}
void RCRegion::attachedAdvance(RCRegion::attachedRegions_t::const_iterator& it, int x/*=1*/) {
	MarkScope l(getStaticLock());
	if(it!=attachedRegions.end())
		it->second->RemoveReference();
	std::advance(it,x);
	if(it!=attachedRegions.end())
		it->second->AddReference();
}

RCRegion::~RCRegion() {
	MarkScope l(getStaticLock());
	attachedRegions.erase(id.key);
	ASSERT(base==NULL,"destructed with attachment!");
	ASSERT(references==NULL,"destructed with local references!");
	//cout << "~RCRegion " << id.shmid << ' ' << ProcessID::getID() << endl;
}
	
//! provides compatability with the OPEN-R type of the same name
class RCRegion {
public:

	// The type of region Identifier depends on the style of shared memory being used

#if TEKKOTSU_SHM_STYLE==SYSV_SHM
	//! contains all information needed to attach this region from a different process
	struct Identifier {
		Identifier() : key(), shmid(), size(0) {}
		key_t key; //!< key_t is defined by system headers, contains system region info
		int shmid; //!< an integer key value which identifies the region
		size_t size; //!< the size of the region
	};

#elif TEKKOTSU_SHM_STYLE==POSIX_SHM || TEKKOTSU_SHM_STYLE==NO_SHM
	//! maximum guaranteed length for users' region names (might have a little leeway depending on process ID prefix or tmp path prefix)
	static const unsigned int MAX_NAME_LEN=64;

	//! contains all information needed to attach this region from a different process
	struct Identifier {
		Identifier() : size(0) {}
		char key[MAX_NAME_LEN]; //!< a string name for the key
		size_t size; //!< size of the region
	};

#  if TEKKOTSU_SHM_STYLE==POSIX_SHM
#    ifndef USE_UNBACKED_SHM
	static plist::Primitive<std::string> shmRoot; //!< determines location of the file backing within file system
#    endif
	static plist::Primitive<bool> useUniqueMemoryRegions; //!< if true, prefixes region names with #rootPID
	static pid_t rootPID; //!< this is the pid of the original process, used for unique names of memory regions; pid_t is from sys/types.h
#  endif
#endif


	// The constructors, offering either an Aperios-compatable version,
	// or a linux-specific version offering explicit control over the
	// key value, aids better debugging

#if TEKKOTSU_SHM_STYLE==SYSV_SHM
	//! constructor (OPEN-R compatability)
	explicit RCRegion(size_t sz)
		: id(), base(NULL), references(NULL)
	{ init(sz,nextKey,true); }
	//! constructor, name isn't used for sysv-style shared memory (not OPEN-R compatable)
	/*! could hash the name to generate key...? */
	RCRegion(const std::string&, size_t sz)
		: id(), base(NULL), references(NULL)
	{ init(sz,nextKey,true); }

#elif TEKKOTSU_SHM_STYLE==POSIX_SHM || TEKKOTSU_SHM_STYLE==NO_SHM
	//! constructor (OPEN-R compatability, name is autogenerated)
	explicit RCRegion(size_t sz)
		: id(), base(NULL), references(NULL)
	{
		char name[RCRegion::MAX_NAME_LEN];
		snprintf(name,RCRegion::MAX_NAME_LEN,"Rgn.%d.%u",ProcessID::getID(),static_cast<unsigned int>(++nextKey));
		name[RCRegion::MAX_NAME_LEN-1]='\0';
		init(sz,name,true);
	}
	//! constructor, specify your own name for better debugging accountability (not OPEN-R compatable)
	RCRegion(const std::string& name, size_t sz)
		: id(), base(NULL), references(NULL)
	{ init(sz,name,true); }
#endif

	//! requests that a specified RCRegion be loaded into the current process's memory space
	static RCRegion * attach(const Identifier& rid);
	
	char * Base() const { return base; } //!< the pointer to the shared memory region
	size_t Size() const { return id.size; } //!< the size of the shared memory region
	static void setNextKey(key_t k) { nextKey=k; } //!< sets the next key to be used for automatic assignment to new regions
	static key_t getNextKey() { return nextKey+1; } //!< return the next region serial number -- doesn't actually increment it though, repeated calls will return the same value until the value is actually used
	const Identifier& ID() const { return id; } //!< returns the identifier of this region
	
	int NumberOfReference() const { return references[ProcessID::NumPro