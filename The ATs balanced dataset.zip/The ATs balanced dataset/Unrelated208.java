*
 * $Id: main.c,v 1.19 2001/02/11 08:08:44 chipx86 Exp $
 *
 * Copyright (C) 1998-2001, Freedows
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
#include <kmalloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <multiboot.h>
#include <time.h>

#include <freedows/FreedowsKernel.h>
#include <freedows/Kernel.h>
#include <freedows/ArchKernel.h>

#include <freedows/paging.h>
#include <freedows/driver.h>
#include <freedows/timer.h>

#include <freedows/debugger/debugger.h>

#include <drivers/block/floppy/floppy.h>
#include <drivers/block/ramdisk/ramdisk.h>
#include <drivers/char/keyboard/keyboard.h>
#include <drivers/char/console/console.h>

#include <sys/8259.h>
#include <sys/idt.h>
#include <sys/ELF.h>
#include <sys/desc.h>
#include <sys/io.h>

#include <apps/fred.h>


#define KERNEL_LOAD_ADDR 0x100000

void kmain(char *real_mem_base, int kernel_size, char *init_script,
		   int init_script_size);

extern int _end;
static multiboot_info_t multiboot_header;
long idle_counter = 0; /* idle counter */
unsigned int kernel_size;
unsigned int mem_size;

static void
init_drivers(void)
{
	Driver *kb_driver;
	Driver *floppy_driver;

	kprintf("8259\n");
	init_8259();                      /* Initialize the 8259 PIC       */
	kprintf("idt\n");
	init_idt();                       /* Initialize the IDT            */
//	kprintf("debugger\n");
//	debugger_init();
	kprintf("timer\n");
	timer_init();                     /* Initialize the timer          */

	kb_driver = keyboard_init();
	floppy_driver = floppy_driver_init();
	
	driver_register(kb_driver);       /* Register the Keyboard Driver  */
	driver_register(floppy_driver);   /* Register the floppy driver    */
	
	kprintf("KB driver.\n");
	driver_open(kb_driver);           /* Initialize the keyboard       */
	kprintf("Floppy driver.\n");
	driver_open(floppy_driver);       /* Iniitalize the floppy driver  */

	kprintf("Done loading drivers.\n");
//
	console_clear();
}

void
init_kernel_mb(unsigned long magic, multiboot_info_t *mb)
{
	/* Check if we were booted by a multiboot-compliant boot loader */
	if (magic != MULTIBOOT_BOOTLOADER_MAGIC)
	{
		kprintf("Invalid magic number: 0x%X\n", magic);
		return;
	}

	multiboot_header = *mb;

	kernel_size = ((int)&_end) - KERNEL_LOAD_ADDR;

	mem_size = multiboot_header.mem_upper * 1024 + 1024 * 1024;

	/* TODO: Check kernel params */

	kmain((char *)0x8000, kernel_size, NULL, 0);
}

static void
setup_consoles(void)
{
	Driver *console_driver;
	Console *con;
	int i;

	/* Load the console driver */
	console_driver = console_driver_init();
	driver_register(console_driver);
	driver_open(console_driver);
	
	/* Create the consoles */
	for (i = 0; i < 5; i++)
	{
		TextConsoleOps *ops; 
		char buffer[10];

		sprintf(buffer, "Console %d", (i + 1));
		
		con = create_console(CONSOLE_TYPE_TEXT);
		ops = (TextConsoleOps *)con->ops;
		console_add(con);

		ops->set_xy(con, 70, 0);
		ops->write_str(con, buffer);
		ops->set_xy(con, 0, 0);
	}

	/* Write the OS info text */
	console_switch(0);
	console_set_xy(0, 0);
	console_set_attr(ATTRIB_BRIGHT | ATTRIB_CYAN);
	kprintf("Freedows");
	
	console_set_attr(ATTRIB_WHITE);
	kprintf(" build " VERSION "\n");
	
	kprintf("Copyright (C) 1998-2001 Freedows. All rights reserved.\n");
}

void
test_task_1(void)
{
	int num = 0;
//	int i;
	long flags;

	for (;;)
	{
//		save_flags(flags);
//		cli();
		
		console_set_xy(0, 0);
		kprintf("Task 1: %08X\n", num++);

//		restore_flags(flags);
	}
}

void
test_task_2(void)
{
	int num = 0;
//	int i;
	long flags;

	for (;;)
	{
//		save_flags(flags);
//		cli();
		
		console_set_xy(20, 0);
		kprintf("Task 2: %08X\n", num++);

//		restore_flags(flags);
	}
}


void
kmain(char *real_mem_base, int kernel_size, char *init_script,
	  int init_script_size)
{
	long flags;
	int num;

	desc_init();

	setup_consoles();

//	kernel_size = (kernel_size + PAGE_SIZE - 1) & PAGE_MASK;
	
	kprintf("kernel_size = 0x%X (%d), mem_size = 0x%X (%d)\n",
			kernel_size, kernel_size, mem_size, mem_size);

	kprintf("Calling kmem_init()\n");
	kmem_init();
	
	/* Load the rest of the drivers */
	kprintf("Loading drivers...\n");
	init_drivers();

	/* Start Fred */
	kprintf("creating fred_main task\n");
	create_kernel_task(test_task_1, -5);
	create_kernel_task(test_task_2, -5);
//	create_kernel_task(fred_main, -5);
//	fred_main();

	while(1)
	{
#if 0
		save_flags(flags);
		cli();
//
		dump_task_statistic();

		console_set_xy(0, 23);
		kprintf("Enter Idle : %08X", ++num);
		
		restore_flags(flags);
#endif
//		__asm__ __volatile__ ("hlt");
	}