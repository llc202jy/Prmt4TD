/*
 * usb100.h
 *
 * USB 1.0 support
 *
 * This file is part of the w32api package.
 *
 * Contributors:
 *   Created by Casper S. Hornstrup <chorns@users.sourceforge.net>
 *
 * THIS SOFTWARE IS NOT COPYRIGHTED
 *
 * This source code is offered for use in the public domain. You may
 * use, modify or distribute it freely.
 *
 * This code is distributed in the hope that it will be useful but
 * WITHOUT ANY WARRANTY. ALL WARRANTIES, EXPRESS OR IMPLIED ARE HEREBY
 * DISCLAIMED. This includes but is not limited to warranties of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

#ifndef __USB100_H
#define __USB100_H

#if __GNUC__ >=3
#pragma GCC system_header
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define MAXIMUM_USB_STRING_LENGTH         255

#define USB_DEVICE_CLASS_RESERVED           0x00
#define USB_DEVICE_CLASS_AUDIO              0x01
#define USB_DEVICE_CLASS_COMMUNICATIONS     0x02
#define USB_DEVICE_CLASS_HUMAN_INTERFACE    0x03
#define USB_DEVICE_CLASS_MONITOR            0x04
#define USB_DEVICE_CLASS_PHYSICAL_INTERFACE 0x05
#define USB_DEVICE_CLASS_POWER              0x06
#define USB_DEVICE_CLASS_PRINTER            0x07
#define USB_DEVICE_CLASS_STORAGE            0x08
#define USB_DEVICE_CLASS_HUB                0x09
#define USB_DEVICE_CLASS_VENDOR_SPECIFIC    0xFF

#define USB_RESERVED_DESCRIPTOR_TYPE        0x06
#define USB_CONFIG_POWER_DESCRIPTOR_TYPE    0x07
#define USB_INTERFACE_POWER_DESCRIPTOR_TYPE 0x08

#define USB_REQUEST_GET_STATUS            0x00
#define USB_REQUEST_CLEAR_FEATURE         0x01
#define USB_REQUEST_SET_FEATURE           0x03
#define USB_REQUEST_SET_ADDRESS           0x05
#define USB_REQUEST_GET_DESCRIPTOR        0x06
#define USB_REQUEST_SET_DESCRIPTOR        0x07
#define USB_REQUEST_GET_CONFIGURATION     0x08
#define USB_REQUEST_SET_CONFIGURATION     0x09
#define USB_REQUEST_GET_INTERFACE         0x0A
#define USB_REQUEST_SET_INTERFACE         0x0B
#define USB_REQUEST_SYNC_FRAME            0x0C

#define USB_GETSTATUS_SELF_POWERED            0x01
#define USB_GETSTATUS_REMOTE_WAKEUP_ENABLED   0x02

#define BMREQUEST_HOST_TO_DEVICE          0
#define BMREQUEST_DEVICE_TO_HOST          1

#define BMREQUEST_STANDARD                0
#define BMREQUEST_CLASS                   1
#define BMREQUEST_VENDOR                  2

#define BMREQUEST_TO_DEVICE               0
#define BMREQUEST_TO_INTERFACE            1
#define BMREQUEST_TO_ENDPOINT             2
#define BMREQUEST_TO_OTHER                3

/* USB_COMMON_DESCRIPTOR.bDescriptorType constants */
#define USB_DEVICE_DESCRIPTOR_TYPE        0x01
#define USB_CONFIGURATION_DESCRIPTOR_TYPE 0x02
#define USB_STRING_DESCRIPTOR_TYPE        0x03
#define USB_INTERFACE_DESCRIPTOR_TYPE     0x04
#define USB_ENDPOINT_DESCRIPTOR_TYPE      0x05

typedef struct _USB_COMMON_DESCRIPTOR {
	UCHAR  bLength;
	UCHAR  bDescriptorType;
} USB_COMMON_DESCRIPTOR, *PUSB_COMMON_DESCRIPTOR;

#define USB_DESCRIPTOR_MAKE_TYPE_AND_INDEX(d, i) ((USHORT)((USHORT)d << 8 | i))

/* USB_CONFIGURATION_DESCRIPTOR.bmAttributes constants */
#define USB_CONFIG_POWERED_MASK           0xc0
#define USB_CONFIG_BUS_POWERED            0x80
#define USB_CONFIG_SELF_POWERED           0x40
#define USB_CONFIG_REMOTE_WAKEUP          0x20

#include <pshpack1.h>
typedef struct _USB_CONFIGURATION_DESCRIPTOR {
  UCHAR  bLength;
  UCHAR  bDescriptorType;
  USHORT  wTotalLength;
  UCHAR  bNumInterfaces;
  UCHAR  bConfigurationValue;
  UCHAR  iConfiguration;
  UCHAR  bmAttributes;
  UCHAR  MaxPower;
} USB_CONFIGURATION_DESCRIPTOR, *PUSB_CONFIGURATION_DESCRIPTOR;
#include <poppack.h>

typedef struct _USB_DEVICE_DESCRIPTOR {
  UCHAR  bLength;
  UCHAR  bDescriptorType;
  USHORT  bcdUSB;
  UCHAR  bDeviceClass;
  UCHAR  bDeviceSubClass;
  UCHAR  bDeviceProtocol;
  UCHAR  bMaxPacketSize0;
  USHORT  idVendor;
  USHORT  idProduct;
  USHORT  bcdDevice;
  UCHAR  iManufacturer;
  UCHAR  iProduct;
  UCHAR  iSerialNumber;
  UCHAR  bNumConfigurations;
} USB_DEVICE_DESCRIPTOR, *PUSB_DEVICE_DESCRIPTOR;

#define USB_ENDPOINT_DIRECTION_MASK       0x80

#define USB_ENDPOINT_DIRECTION_OUT(x) (!((x) & USB_ENDPOINT_DIRECTION_MASK))
#define USB_ENDPOINT_DIRECTION_IN(x) ((x) & USB_ENDPOINT_DIRECTION_MASK)

/* USB_ENDPOINT_DESCRIPTOR.bmAttributes constants */
#define USB_ENDPOINT_TYPE_MASK            0x03
#define USB_ENDPOINT_TYPE_CONTROL         0x00
#define USB_ENDPOINT_TYPE_ISOCHRONOUS     0x01
#define USB_ENDPOINT_TYPE_BULK            0x02
#define USB_ENDPOINT_TYPE_INTERRUPT       0x03

#include <pshpack1.h>
typedef struct _USB_ENDPOINT_DESCRIPTOR {
  UCHAR  bLength;
  UCHAR  bDescriptorType;
  UCHAR  bEndpointAddress;
  UCHAR  bmAttributes;
  USHORT  wMaxPacketSize;
  UCHAR  bInterval;
} USB_ENDPOINT_DESCRIPTOR, *PUSB_ENDPOINT_DESCRIPTOR;
#include <poppack.h>

#define USB_FEATURE_ENDPOINT_STALL        0x0000
#define USB_FEATURE_REMOTE_WAKEUP         0x0001

typedef struct _USB_INTERFACE_DESCRIPTOR {
  UCHAR  bLength;
  UCHAR  bDescriptorType;
  UCHAR  bInterfaceNumber;
  UCHAR  bAlternateSetting;
  UCHAR  bNumEndpoints;
  UCHAR  bInterfaceClass;
  UCHAR  bInterfaceSubClass;
  UCHAR  bInterfaceProtocol;
  UCHAR  iInterface;
} USB_INTERFACE_DESCRIPTOR, *PUSB_INTERFACE_DESCRIPTOR;

typedef struct _USB_STRING_DESCRIPTOR {
  UCHAR  bLength;
  UCHAR  bDescriptorType;
  WCHAR  bString[1];
} USB_STRING_DESCRIPTOR, *PUSB_STRING_DESCRIPTOR;

#include <pshpack1.h>
typedef struct _USB_HUB_DESCRIPTOR {
	UCHAR  bDescriptorLength;
	UCHAR  bDescriptorType;
	UCHAR  bNumberOfPorts;
	USHORT  wHubCharacteristics;
	UCHAR  bPowerOnToPowerGood;
	UCHAR  bHubControlCurrent;
	UCHAR  bRemoveAndPowerMask[64];
} USB_HUB_DESCRIPTOR, *PUSB_HUB_DESCRIPTOR;
#include <poppack.h>

#define USB_SUPPORT_D0_COMMAND            0x01
#define USB_SUPPORT_D1_COMMAND            0x02
#define USB_SUPPORT_D2_COMMAND            0x04
#define USB_SUPPORT_D3_COMMAND            0x08

#define USB_SUPPORT_D1_WAKEUP             0x10
#define USB_SUPPORT_D2_WAKEUP             0x20

typedef struct _USB_CONFIGURATION_POWER_DESCRIPTOR {
	UCHAR  bLength;
	UCHAR  bDescriptorType;
	UCHAR  SelfPowerConsumedD0[3];
	UCHAR  bPowerSummaryId;
	UCHAR  bBusPowerSavingD1;
	UCHAR  bSelfPowerSavingD1;
	UCHAR  bBusPowerSavingD2;
	UCHAR  bSelfPowerSavingD2;
	UCHAR  bBusPowerSavingD3;
	UCHAR  bSelfPowerSavingD3;
	USHORT  TransitionTimeFromD1;
	USHORT  TransitionTimeFromD2;
	USHORT  TransitionTimeFromD3;
} USB_CONFIGURATION_POWER_DESCRIPTOR, *PUSB_CONFIGURATION_POWER_DESCRIPTOR;

#define USB_FEATURE_INTERFACE_POWER_D0    0x0002
#define USB_FEATURE_INTERFACE_POWER_D1    0x0003
#define USB_FEATURE_INTERFACE_POWER_D2    0x0004
#define USB_FEATURE_INTERFACE_POWER_D3    0x0005

#include <pshpack1.h>
typedef struct _USB_INTERFACE_POWER_DESCRIPTOR {
	UCHAR  bLength;
	UCHAR  bDescriptorType;
	UCHAR  bmCapabilitiesFlags;
	UCHAR  bBusPowerSavingD1;
	UCHAR  bSelfPowerSavingD1;
	UCHAR  bBusPowerSavingD2;
	UCHAR  bSelfPowerSavingD2;
	UCHAR  bBusPowerSavingD3;
	UCHAR  bSelfPowerSavingD3;
	USHORT  TransitionTimeFromD1;
	USHORT  TransitionTimeFromD2;
	USHORT  TransitionTimeFromD3;
} USB_INTERFACE_POWER_DESCRIPTOR, *PUSB_INTERFACE_POWER_DESCRIPTOR;
#include <poppack.h>

#ifdef __cplusplus
}
#endif

#endif /* __USB100_H */
/*
 * cfg.h
 *
 * PnP Configuration Manager shared definitions between user mode and kernel mode code
 *
 * This file is part of the w32api package.
 *
 * Contributors:
 *   Created by Casper S. Hornstrup <chorns@users.sourceforge.net>
 *
 * THIS SOFTWARE IS NOT COPYRIGHTED
 *
 * This source code is offered for use in the public domain. You may
 * use, modify or distribute it freely.
 *
 * This code is distributed in the hope that it will be useful but
 * WITHOUT ANY WARRANTY. ALL WARRANTIES, EXPRESS OR IMPLIED ARE HEREBY
 * DISCLAIMED. This includes but is not limited to warranties of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

#ifndef _CFG_INCLUDED_
#define _CFG_INCLUDED_

#if __GNUC__ >=3
#pragma GCC system_header
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define CM_PROB_NOT_CONFIGURED              0x00000001
#define CM_PROB_DEVLOADER_FAILED            0x00000002
#define CM_PROB_OUT_OF_MEMORY               0x00000003
#define CM_PROB_ENTRY_IS_WRONG_TYPE         0x00000004
#define CM_PROB_LACKED_ARBITRATOR           0x00000005
#define CM_PROB_BOOT_CONFIG_CONFLICT        0x00000006
#define CM_PROB_FAILED_FILTER               0x00000007
#define CM_PROB_DEVLOADER_NOT_FOUND         0x00000008
#define CM_PROB_INVALID_DATA                0x00000009
#define CM_PROB_FAILED_START                0x0000000A
#define CM_PROB_LIAR                        0x0000000B
#define CM_PROB_NORMAL_CONFLICT             0x0000000C
#define CM_PROB_NOT_VERIFIED                0x0000000D
#define CM_PROB_NEED_RESTART                0x0000000E
#define CM_PROB_REENUMERATION               0x0000000F
#define CM_PROB_PARTIAL_LOG_CONF            0x00000010
#define CM_PROB_UNKNOWN_RESOURCE            0x00000011
#define CM_PROB_REINSTALL                   0x00000012
#define CM_PROB_REGISTRY                    0x00000013
#define CM_PROB_VXDLDR                      0x00000014
#define CM_PROB_WILL_BE_REMOVED             0x00000015
#define CM_PROB_DISABLED                    0x00000016
#define CM_PROB_DEVLOADER_NOT_READY         0x00000017
#define CM_PROB_DEVICE_NOT_THERE            0x00000018
#define CM_PROB_MOVED                       0x00000019
#define CM_PROB_TOO_EARLY                   0x0000001A
#define CM_PROB_NO_VALID_LOG_CONF           0x0000001B
#define CM_PROB_FAILED_INSTALL              0x0000001C
#define CM_PROB_HARDWARE_DISABLED           0x0000001D
#define CM_PROB_CANT_SHARE_IRQ              0x0000001E
#define CM_PROB_FAILED_ADD                  0x0000001F
#define CM_PROB_DISABLED_SERVICE            0x00000020
#define CM_PROB_TRANSLATION_FAILED          0x00000021
#define CM_PROB_NO_SOFTCONFIG               0x00000022
#define CM_PROB_BIOS_TABLE                  0x00000023
#define CM_PROB_IRQ_TRANSLATION_FAILED      0x00000024
#define CM_PROB_FAILED_DRIVER_ENTRY         0x00000025
#define CM_PROB_DRIVER_FAILED_PRIOR_UNLOAD  0x00000026
#define CM_PROB_DRIVER_FAILED_LOAD          0x00000027
#define CM_PROB_DRIVER_SERVICE_KEY_INVALID  0x00000028
#define CM_PROB_LEGACY_SERVICE_NO_DEVICES   0x00000029
#define CM_PROB_DUPLICATE_DEVICE            0x0000002A
#define CM_PROB_FAILED_POST_START           0x0000002B
#define CM_PROB_HALTED                      0x0000002C
#define CM_PROB_PHANTOM                     0x0000002D
#define CM_PROB_SYSTEM_SHUTDOWN             0x0000002E
#define CM_PROB_HELD_FOR_EJECT              0x0000002F
#define CM_PROB_DRIVER_BLOCKED              0x00000030
#define CM_PROB_REGISTRY_TOO_LARGE          0x00000031
#define CM_PROB_SETPROPERTIES_FAILED        0x00000032
#define NUM_CM_PROB                         0x00000033

#define LCPRI_FORCECONFIG                 0x00000000
#define LCPRI_BOOTCONFIG                  0x00000001
#define LCPRI_DESIRED                     0x00002000
#define LCPRI_NORMAL                      0x00003000
#define LCPRI_LASTBESTCONFIG              0x00003FFF
#define LCPRI_SUBOPTIMAL                  0x00005000
#define LCPRI_LASTSOFTCONFIG              0x00007FFF
#define LCPRI_RESTART                     0x00008000
#define LCPRI_REBOOT                      0x00009000
#define LCPRI_POWEROFF                    0x0000A000
#define LCPRI_HARDRECONFIG                0x0000C000
#define LCPRI_HARDWIRED                   0x0000E000
#define LCPRI_IMPOSSIBLE                  0x0000F000
#define LCPRI_DISABLED                    0x0000FFFF
#define MAX_LCPRI                         0x0000FFFF

#define DN_ROOT_ENUMERATED  0x00000001	/* Was enumerated by ROOT */
#define DN_DRIVER_LOADED    0x00000002	/* Has Register_Device_Driver */
#define DN_ENUM_LOADED      0x00000004	/* Has Register_Enumerator */
#define DN_STARTED          0x00000008	/* Is currently configured */
#define DN_MANUAL           0x00000010	/* Manually installed */
#define DN_NEED_TO_ENUM     0x00000020	/* May need reenumeration */
#define DN_NOT_FIRST_TIME   0x00000040	/* Has received a config */
#define DN_HARDWARE_ENUM    0x00000080	/* Enum generates hardware ID */
#define DN_LIAR             0x00000100	/* Lied about can reconfig once */
#define DN_HAS_MARK         0x00000200	/* Not CM_Create_DevNode lately */
#define DN_HAS_PROBLEM      0x00000400	/* Need device installer */
#define DN_FILTERED         0x00000800	/* Is filtered */
#define DN_MOVED            0x00001000	/* Has been moved */
#define DN_DISABLEABLE      0x00002000	/* Can be rebalanced */
#define DN_REMOVABLE        0x00004000	/* Can be removed */
#define DN_PRIVATE_PROBLEM  0x00008000	/* Has a private problem */
#define DN_MF_PARENT        0x00010000	/* Multi function parent */
#define DN_MF_CHILD         0x00020000	/* Multi function child */
#define DN_WILL_BE_REMOVED  0x00040000	/* Devnode is being removed */

typedef enum _PNP_VETO_TYPE {
  PNP_VetoTypeUnknown,
  PNP_VetoLegacyDevice,
  PNP_VetoPendingClose,
  PNP_VetoWindowsApp,
  PNP_VetoWindowsService,
  PNP_VetoOutstandingOpen,
  PNP_VetoDevice,
  PNP_VetoDriver,
  PNP_VetoIllegalDeviceRequest,
  PNP_VetoInsufficientPower,
  PNP_VetoNonDisableable,
  PNP_VetoLegacyDriver
} PNP_VETO_TYPE, *PPNP_VETO_TYPE;

#define CM_GLOBAL_STATE_CAN_DO_UI           0x00000001
#define CM_GLOBAL_STATE_ON_BIG_STACK        0x00000002
#define CM_GLOBAL_STATE_SERVICES_AVAILABLE  0x00000004
#define CM_GLOBAL_STATE_SHUTTING_DOWN       0x00000008
#define CM_GLOBAL_STATE_DETECTION_PENDING   0x00000010

#ifdef __cplusplus
}
#endif

#endif /* _CFG_INCLUDED_ */
#ifndef _LMWKSTA_H
#define _LMWKSTA_H
#if __GNUC__ >=3
#pragma GCC system_header
#endif

#ifdef __cplusplus
extern "C" {
#endif
#include <lmuseflg.h>
#define WKSTA_PLATFORM_ID_PARMNUM 100
#define WKSTA_COMPUTERNAME_PARMNUM 1
#define WKSTA_LANGROUP_PARMNUM 2
#define WKSTA_VER_MAJOR_PARMNUM 4
#define WKSTA_VER_MINOR_PARMNUM 5
#define WKSTA_LOGGED_ON_USERS_PARMNUM 6
#define WKSTA_LANROOT_PARMNUM 7
#define WKSTA_LOGON_DOMAIN_PARMNUM 8
#define WKSTA_LOGON_SERVER_PARMNUM 9
#define WKSTA_CHARWAIT_PARMNUM 10
#define WKSTA_CHARTIME_PARMNUM 11
#define WKSTA_CHARCOUNT_PARMNUM 12
#define WKSTA_KEEPCONN_PARMNUM 13
#define WKSTA_KEEPSEARCH_PARMNUM 14
#define WKSTA_MAXCMDS_PARMNUM 15
#define WKSTA_NUMWORKBUF_PARMNUM 16
#define WKSTA_MAXWRKCACHE_PARMNUM 17
#define WKSTA_SESSTIMEOUT_PARMNUM 18
#define WKSTA_SIZERROR_PARMNUM 19
#define WKSTA_NUMALERTS_PARMNUM 20
#define WKSTA_NUMSERVICES_PARMNUM 21
#define WKSTA_NUMCHARBUF_PARMNUM 22
#define WKSTA_SIZCHARBUF_PARMNUM 23
#define WKSTA_ERRLOGSZ_PARMNUM 27
#define WKSTA_PRINTBUFTIME_PARMNUM 28
#define WKSTA_SIZWORKBUF_PARMNUM 29
#define WKSTA_MAILSLOTS_PARMNUM 30
#define WKSTA_NUMDGRAMBUF_PARMNUM 31
#define WKSTA_WRKHEURISTICS_PARMNUM 32
#define WKSTA_MAXS_PARMNUM 33
#define WKSTA_LOCKQUOTA_PARMNUM 41
#define WKSTA_LOCKINCREMENT_PARMNUM 42
#define WKSTA_LOCKMAXIMUM_PARMNUM 43
#define WKSTA_PIPEINCREMENT_PARMNUM 44
#define WKSTA_PIPEMAXIMUM_PARMNUM 45
#define WKSTA_DORMANTFILELIMIT_PARMNUM 46
#define WKSTA_CACHEFILETIMEOUT_PARMNUM 47
#define WKSTA_USEOPPORTUNISTICLOCKING_PARMNUM 48
#define WKSTA_USEUNLOCKBEHIND_PARMNUM 49
#define WKSTA_USECLOSEBEHIND_PARMNUM 50
#define WKSTA_BUFFERNAMEDPIPES_PARMNUM 51
#define WKSTA_USELOCKANDREADANDUNLOCK_PARMNUM 52
#define WKSTA_UTILIZENTCACHING_PARMNUM 53
#define WKSTA_USERAWREAD_PARMNUM 54
#define WKSTA_USERAWWRITE_PARMNUM 55
#define WKSTA_USEWRITERAWWITHDATA_PARMNUM 56
#define WKSTA_USEENCRYPTION_PARMNUM 57
#define WKSTA_BUFFILESWITHDENYWRITE_PARMNUM 58
#define WKSTA_BUFFERREADONLYFILES_PARMNUM 59
#define WKSTA_FORCECORECREATEMODE_PARMNUM 60
#define WKSTA_USE512BYTESMAXTRANSFER_PARMNUM 61
#define WKSTA_READAHEADTHRUPUT_PARMNUM 62
#define WKSTA_OTH_DOMAINS_PARMNUM 101
#define TRANSPORT_QUALITYOFSERVICE_PARMNUM 201
#define TRANSPORT_NAME_PARMNUM 202

typedef struct _WKSTA_INFO_100 {
	DWORD wki100_platform_id;
	LPWSTR wki100_computername;
	LPWSTR wki100_langroup;
	DWORD wki100_ver_major;
	DWORD wki100_ver_minor;
}WKSTA_INFO_100,*PWKSTA_INFO_100,*LPWKSTA_INFO_100;
typedef struct _WKSTA_INFO_101 {
	DWORD wki101_platform_id;
	LPWSTR wki101_computername;
	LPWSTR wki101_langroup;
	DWORD wki101_ver_major;
	DWORD wki101_ver_minor;
	LPWSTR wki101_lanroot;
}WKSTA_INFO_101,*PWKSTA_INFO_101,*LPWKSTA_INFO_101;
typedef struct _WKSTA_INFO_102 {
	DWORD wki102_platform_id;
	LPWSTR wki102_computername;
	LPWSTR wki102_langroup;
	DWORD wki102_ver_major;
	DWORD wki102_ver_minor;
	LPWSTR wki102_lanroot;
	DWORD wki102_logged_on_users;
}WKSTA_INFO_102,*PWKSTA_INFO_102,*LPWKSTA_INFO_102;
typedef struct _WKSTA_INFO_302{
	DWORD wki302_char_wait;
	DWORD wki302_collection_time;
	DWORD wki302_maximum_collection_count;
	DWORD wki302_keep_conn;
	DWORD wki302_keep_search;
	DWORD wki302_max_cmds;
	DWORD wki302_num_work_buf;
	DWORD wki302_siz_work_buf;
	DWORD wki302_max_wrk_cache;
	DWORD wki302_sess_timeout;
	DWORD wki302_siz_error;
	DWORD wki302_num_alerts;
	DWORD wki302_num_services;
	DWORD wki302_errlog_sz;
	DWORD wki302_print_buf_time;
	DWORD wki302_num_char_buf;
	DWORD wki302_siz_char_buf;
	LPWSTR wki302_wrk_heuristics;
	DWORD wki302_mailslots;
	DWORD wki302_num_dgram_buf;
}WKSTA_INFO_302,*PWKSTA_INFO_302,*LPWKSTA_INFO_302;
typedef struct _WKSTA_INFO_402{
	DWORD wki402_char_wait;
	DWORD wki402_collection_time;
	DWORD wki402_maximum_collection_count;
	DWORD wki402_keep_conn;
	DWORD wki402_keep_search;
	DWORD wki402_max_cmds;
	DWORD wki402_num_work_buf;
	DWORD wki402_siz_work_buf;
	DWORD wki402_max_wrk_cache;
	DWORD wki402_sess_timeout;
	DWORD wki402_siz_error;
	DWORD wki402_num_alerts;
	DWORD wki402_num_services;
	DWORD wki402_errlog_sz;
	DWORD wki402_print_buf_time;
	DWORD wki402_num_char_buf;
	DWORD wki402_siz_char_buf;
	LPWSTR wki402_wrk_heuristics;
	DWORD wki402_mailslots;
	DWORD wki402_num_dgram_buf;
	DWORD wki402_max_s;
}WKSTA_INFO_402,*PWKSTA_INFO_402,*LPWKSTA_INFO_402;
typedef struct _WKSTA_INFO_502{
	DWORD wki502_char_wait;
	DWORD wki502_collection_time;
	DWORD wki502_maximum_collection_count;
	DWORD wki502_keep_conn;
	DWORD wki502_max_cmds;
	DWORD wki502_sess_timeout;
	DWORD wki502_siz_char_buf;
	DWORD wki502_max_s;
	DWORD wki502_lock_quota;
	DWORD wki502_lock_increment;
	DWORD wki502_lock_maximum;
	DWORD wki502_pipe_increment;
	DWORD wki502_pipe_maximum;
	DWORD wki502_cache_file_timeout;
	DWORD wki502_dormant_file_limit;
	DWORD wki502_read_ahead_throughput;
	DWORD wki502_num_mailslot_buffers;
	DWORD wki502_num_srv_announce_buffers;
	DWORD wki502_max_illegal_datagram_events;
	DWORD wki502_illegal_datagram_event_reset_frequency;
	BOOL wki502_log_election_packets;
	BOOL wki502_use_opportunistic_locking;
	BOOL wki502_use_unlock_behind;
	BOOL wki502_use_close_behind;
	BOOL wki502_buf_named_pipes;
	BOOL wki502_use_lock_read_unlock;
	BOOL wki502_utilize_nt_caching;
	BOOL wki502_use_raw_read;
	BOOL wki502_use_raw_write;
	BOOL wki502_use_write_raw_data;
	BOOL wki502_use_encryption;
	BOOL wki502_buf_files_deny_write;
	BOOL wki502_buf_read_only_files;
	BOOL wki502_force_core_create_mode;
	BOOL wki502_use_512_byte_max_transfer;
}WKSTA_INFO_502,*PWKSTA_INFO_502,*LPWKSTA_INFO_502;
typedef struct _WKSTA_INFO_1010 { DWORD wki1010_char_wait;} WKSTA_INFO_1010,*PWKSTA_INFO_1010,*LPWKSTA_INFO_1010;
typedef struct _WKSTA_INFO_1011 { DWORD wki1011_collection_time;} WKSTA_INFO_1011,*PWKSTA_INFO_1011,*LPWKSTA_INFO_1011;
typedef struct _WKSTA_INFO_1012 { DWORD wki1012_maximum_collection_count;} WKSTA_INFO_1012,*PWKSTA_INFO_1012,*LPWKSTA_INFO_1012;
typedef struct _WKSTA_INFO_1027 { DWORD wki1027_errlog_sz;} WKSTA_INFO_1027,*PWKSTA_INFO_1027,*LPWKSTA_INFO_1027;
typedef struct _WKSTA_INFO_1028 { DWORD wki1028_print_buf_time;} WKSTA_INFO_1028,*PWKSTA_INFO_1028,*LPWKSTA_INFO_1028;
typedef struct _WKSTA_INFO_1032 { DWORD wki1032_wrk_heuristics;} WKSTA_INFO_1032,*PWKSTA_INFO_1032,*LPWKSTA_INFO_1032;
typedef struct _WKSTA_INFO_1013 { DWORD wki1013_keep_conn;} WKSTA_INFO_1013,*PWKSTA_INFO_1013,*LPWKSTA_INFO_1013;
typedef struct _WKSTA_INFO_1018 { DWORD wki1018_sess_timeout;} WKSTA_INFO_1018,*PWKSTA_INFO_1018,*LPWKSTA_INFO_1018;
typedef struct _WKSTA_INFO_1023 { DWORD wki1023_siz_char_buf;} WKSTA_INFO_1023,*PWKSTA_INFO_1023,*LPWKSTA_INFO_1023;
typedef struct _WKSTA_INFO_1033 { DWORD wki1033_max_ad_unlock;} WKSTA_INFO_1052,*PWKSTA_INFO_1052,*LPWKSTA_INFO_1052;
typedef struct _WKSTA_INFO_1053 { BOOL wki1053_utilize_nt_caching;} WKSTA_INFO_1053,*PWKSTA_INFO_1053,*LPWKSTA_INFO_1053;
typedef struct _WKSTA_INFO_1054 { BOOL wki1054_use_raw_read;} WKSTA_INFO_1054,*PWKSTA_INFO_1054,*LPWKSTA_INFO_1054;
typedef struct _WKSTA_INFO_1055 { BOOL wki1055_use_raw_write;} WKSTA_INFO_1055,*PWKSTA_INFO_1055,*LPWKSTA_INFO_1055;
typedef struct _WKSTA_INFO_1056 { BOOL wki1056_use_write_raw_data;} WKSTA_INFO_1056,*PWKSTA_INFO_1056,*LPWKSTA_INFO_1056;
typedef struct _WKSTA_INFO_1057 { BOOL wki1057_use_encryption;} WKSTA_INFO_1057,*PWKSTA_INFO_1057,*LPWKSTA_INFO_1057;
typedef struct _WKSTA_INFO_1058 { BOOL wki1058_buf_files_deny_write;} WKSTA_INFO_1058,*PWKSTA_INFO_1058,*LPWKSTA_INFO_1058;
typedef struct _WKSTA_INFO_1059 { BOOL wki1059_buf_read_only_files;} WKSTA_INFO_1059,*PWKSTA_INFO_1059,*LPWKSTA_INFO_1059;
typedef struct _WKSTA_INFO_1060 { BOOL wki1060_force_core_create_mode;} WKSTA_INFO_1060,*PWKSTA_INFO_1060,*LPWKSTA_INFO_1060;
typedef struct _WKSTA_INFO_1061 { BOOL wki1061_use_512_byte_max_transfer;} WKSTA_INFO_1061,*PWKSTA_INFO_1061,*LPWKSTA_INFO_1061;
typedef struct _WKSTA_INFO_1062 { DWORD wki1062_read_ahead_throughput;} WKSTA_INFO_1062,*PWKSTA_INFO_1062,*LPWKSTA_INFO_1062;
typedef struct _WKSTA_USER_INFO_0 { LPWSTR wkui0_username;}WKSTA_USER_INFO_0,*PWKSTA_USER_INFO_0,*LPWKSTA_USER_INFO_0;
typedef struct _WKSTA_USER_INFO_1 {
	LPWSTR wkui1_username;
	LPWSTR wkui1_logon_domain;
	LPWSTR wkui1_oth_domains;
	LPWSTR wkui1_logon_server;
}WKSTA_USER_INFO_1,*PWKSTA_USER_INFO_1,*LPWKSTA_USER_INFO_1;
typedef struct _WKSTA_USER_INFO_1101 { LPWSTR wkui1101_oth_domains;} WKSTA_USER_INFO_1101,*PWKSTA_USER_INFO_1101,*LPWKSTA_USER_INFO_1101;
typedef struct _WKSTA_TRANSPORT_INFO_0 {
	DWORD wkti0_quality_of_service;
	DWORD wkti0_number_of_vcs;
	LPWSTR wkti0_transport_name;
	LPWSTR wkti0_transport_address;
	BOOL wkti0_wan_ish;
}WKSTA_TRANSPORT_INFO_0,*PWKSTA_TRANSPORT_INFO_0,*LPWKSTA_TRANSPORT_INFO_0;

NET_API_STATUS WINAPI NetWkstaGetInfo(LPWSTR,DWORD,PBYTE*);
NET_API_STATUS WINAPI NetWkstaSetInfo(LPWSTR,DWORD,PBYTE,PDWORD);
NET_API_STATUS WINAPI NetWkstaUserGetInfo(LPWSTR,DWORD,PBYTE*);
NET_API_STATUS WINAPI NetWkstaUserSetInfo(LPWSTR,DWORD,PBYTE,PDWORD);
NET_API_STATUS WINAPI NetWkstaUserEnum(LPWSTR,DWORD,PBYTE*,DWORD,PDWORD,PDWORD,PDWORD);
NET_API_STATUS WINAPI NetWkstaTransportAdd(LPWSTR,DWORD,PBYTE,PDWORD);
NET_API_STATUS WINAPI NetWkstaTransportDel(LPWSTR,LPWSTR,DWORD);
NET_API_STATUS WINAPI NetWkstaTransportEnum(LPWSTR,DWORD,PBYTE*,DWORD,PDWORD,PDWORD,PDWORD);

#ifdef __cplusplus
}
#endif
#endif
/*
 * smbus.h
 *
 * System Management Bus driver interface
 *
 * This file is part of the w32api package.
 *
 * Contributors:
 *   Created by Casper S. Hornstrup <chorns@users.sourceforge.net>
 *
 * THIS SOFTWARE IS NOT COPYRIGHTED
 *
 * This source code is offered for use in the public domain. You may
 * use, modify or distribute it freely.
 *
 * This code is distributed in the hope that it will be useful but
 * WITHOUT ANY WARRANTY. ALL WARRANTIES, EXPRESS OR IMPLIED ARE HEREBY
 * DISCLAIMED. This includes but is not limited to warranties of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

#ifndef __SMBUS_H
#define __SMBUS_H

#if __GNUC__ >=3
#pragma GCC system_header
#endif

#ifdef __cplusplus
extern "C" {
#endif

#if !defined(SMBCLASS)
  #define SMBCLASSAPI DECLSPEC_IMPORT
#else
  #define SMBCLASSAPI DECLSPEC_EXPORT
#endif

#define SMB_BUS_REQUEST \
  CTL_CODE(FILE_DEVICE_UNKNOWN, 0, METHOD_NEITHER, FILE_ANY_ACCESS)

#define SMB_DEREGISTER_ALARM_NOTIFY \
  CTL_CODE(FILE_DEVICE_UNKNOWN, 2, METHOD_NEITHER, FILE_ANY_ACCESS)

#define SMB_REGISTER_ALARM_NOTIFY \
  CTL_CODE(FILE_DEVICE_UNKNOWN, 1, METHOD_NEITHER, FILE_ANY_ACCESS)


struct _SMB_CLASS;

#define SMB_MAX_DATA_SIZE                 32

/* SMB_REQUEST.Status constants */
#define SMB_STATUS_OK                     0x00
#define SMB_UNKNOWN_FAILURE               0x07
#define SMB_ADDRESS_NOT_ACKNOWLEDGED      0x10
#define SMB_DEVICE_ERROR                  0x11
#define SMB_COMMAND_ACCESS_DENIED         0x12
#define SMB_UNKNOWN_ERROR                 0x13
#define SMB_DEVICE_ACCESS_DENIED          0x17
#define SMB_TIMEOUT                       0x18
#define SMB_UNSUPPORTED_PROTOCOL          0x19
#define SMB_BUS_BUSY                      0x1A

/* SMB_REQUEST.Protocol constants */
#define SMB_WRITE_QUICK                   0x00
#define SMB_READ_QUICK                    0x01
#define SMB_SEND_BYTE                     0x02
#define SMB_RECEIVE_BYTE                  0x03
#define SMB_WRITE_BYTE                    0x04
#define SMB_READ_BYTE                     0x05
#define SMB_WRITE_WORD                    0x06
#define SMB_READ_WORD                     0x07
#define SMB_WRITE_BLOCK                   0x08
#define SMB_READ_BLOCK                    0x09
#define SMB_PROCESS_CALL                  0x0A
#define SMB_MAXIMUM_PROTOCOL              0x0A

typedef struct _SMB_REQUEST {
  UCHAR  Status;
  UCHAR  Protocol;
  UCHAR  Address;
  UCHAR  Command;
  UCHAR  BlockLength;
  UCHAR  Data[SMB_MAX_DATA_SIZE];
} SMB_REQUEST, *PSMB_REQUEST;

typedef VOID STDCALL
(*SMB_ALARM_NOTIFY)(
  PVOID  Context,
  UCHAR  Address,
  USHORT  Data);

typedef struct _SMB_REGISTER_ALARM {
  UCHAR  MinAddress;
  UCHAR  MaxAddress;
  SMB_ALARM_NOTIFY  NotifyFunction;
  PVOID  NotifyContext;
} SMB_REGISTER_ALARM, *PSMB_REGISTER_ALARM;

/* SMB_CLASS.XxxVersion constants */
#define SMB_CLASS_MAJOR_VERSION           0x0001
#define SMB_CLASS_MINOR_VERSION           0x0000

typedef NTSTATUS DDKAPI
(*SMB_RESET_DEVICE)(
  IN struct _SMB_CLASS  *SmbClass,
  IN PVOID  SmbMiniport);

typedef VOID DDKAPI
(*SMB_START_IO)(
  IN struct _SMB_CLASS  *SmbClass,
  IN PVOID  SmbMiniport);

typedef NTSTATUS DDKAPI
(*SMB_STOP_DEVICE)(
  IN struct _SMB_CLASS  *SmbClass,
  IN PVOID  SmbMiniport);

typedef struct _SMB_CLASS {
  USHORT  MajorVersion;
  USHORT  MinorVersion;
  PVOID  Miniport;
  PDEVICE_OBJECT  DeviceObject;
  PDEVICE_OBJECT  PDO;
  PDEVICE_OBJECT  LowerDeviceObject;
  PIRP  CurrentIrp;
  PSMB_REQUEST  CurrentSmb;
  SMB_RESET_DEVICE  ResetDevice;
  SMB_START_IO  StartIo;
  SMB_STOP_DEVICE  StopDevice;
} SMB_CLASS, *PSMB_CLASS;

SMBCLASSAPI
VOID
DDKAPI
SmbClassAlarm(
  IN PSMB_CLASS  SmbClass,
  IN UCHAR  Address,
  IN USHORT  Data);

SMBCLASSAPI
VOID
DDKAPI
SmbClassCompleteRequest(
  IN PSMB_CLASS  SmbClass);

typedef NTSTATUS DDKAPI
(*PSMB_INITIALIZE_MINIPORT)(
  IN PSMB_CLASS  SmbClass,
  IN PVOID  MiniportExtension,
  IN PVOID  MiniportContext);

SMBCLASSAPI
NTSTATUS
DDKAPI
SmbClassCreateFdo(
  IN PDRIVER_OBJECT  DriverObject,
  IN PDEVICE_OBJECT  PDO,
  IN ULONG  MiniportExtensionSize,
  IN PSMB_INITIALIZE_MINIPORT  MiniportInitialize,
  IN PVOID  MiniportContext,
  OUT PDEVICE_OBJECT  *FDO);

SMBCLASSAPI
NTSTATUS
DDKAPI
SmbClassInitializeDevice(
  IN ULONG  MajorVersion,
  IN ULONG  MinorVersion,
  IN PDRIVER_OBJECT  DriverObject);

SMBCLASSAPI
VOID
DDKAPI
SmbClassLockDevice(
  IN PSMB_CLASS  SmbClass);

SMBCLASSAPI
VOID
DDKAPI
SmbClassUnlockDevice(
  IN PSMB_CLASS  SmbClass);
#ifndef _NTDDTDI_
#define _NTDDTDI_

#ifdef __cplusplus
extern "C" {
#endif

#define DD_TDI_DEVICE_NAME "\\Device\\UNKNOWN"
#define _TDI_CONTROL_CODE(request,method)   CTL_CODE(FILE_DEVICE_TRANSPORT, request, method, FILE_ANY_ACCESS)
#define IOCTL_TDI_ACCEPT                    _TDI_CONTROL_CODE( 0, METHOD_BUFFERED )
#define IOCTL_TDI_CONNECT                   _TDI_CONTROL_CODE( 1, METHOD_BUFFERED )
#define IOCTL_TDI_DISCONNECT                _TDI_CONTROL_CODE( 2, METHOD_BUFFERED )
#define IOCTL_TDI_LISTEN                    _TDI_CONTROL_CODE( 3, METHOD_BUFFERED )
#define IOCTL_TDI_QUERY_INFORMATION         _TDI_CONTROL_CODE( 4, METHOD_OUT_DIRECT )
#define IOCTL_TDI_RECEIVE                   _TDI_CONTROL_CODE( 5, METHOD_OUT_DIRECT )
#define IOCTL_TDI_RECEIVE_DATAGRAM          _TDI_CONTROL_CODE( 6, METHOD_OUT_DIRECT )
#define IOCTL_TDI_SEND                      _TDI_CONTROL_CODE( 7, METHOD_IN_DIRECT )
#define IOCTL_TDI_SEND_DATAGRAM             _TDI_CONTROL_CODE( 8, METHOD_IN_DIRECT )
#define IOCTL_TDI_SET_EVENT_HANDLER         _TDI_CONTROL_CODE( 9, METHOD_BUFFERED )
#define IOCTL_TDI_SET_INFORMATION           _TDI_CONTROL_CODE( 10, METHOD_IN_DIRECT )
#define IOCTL_TDI_ASSOCIATE_ADDRESS         _TDI_CONTROL_CODE( 11, METHOD_BUFFERED )
#define IOCTL_TDI_DISASSOCIATE_ADDRESS      _TDI_CONTROL_CODE( 12, METHOD_BUFFERED )
#define IOCTL_TDI_ACTION                    _TDI_CONTROL_CODE( 13, METHOD_OUT_DIRECT )

#ifdef __cplusplus
}
#endif/*
 * ntddcdvd.h
 *
 * DVD IOCTL interface.
 *
 * This file is part of the w32api package.
 *
 * Contributors:
 *   Created by Casper S. Hornstrup <chorns@users.sourceforge.net>
 *
 * THIS SOFTWARE IS NOT COPYRIGHTED
 *
 * This source code is offered for use in the public domain. You may
 * use, modify or distribute it freely.
 *
 * This code is distributed in the hope that it will be useful but
 * WITHOUT ANY WARRANTY. ALL WARRANTIES, EXPRESS OR IMPLIED ARE HEREBY
 * DISCLAIMED. This includes but is not limited to warranties of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

#ifndef __NTDDCDVD_H
#define __NTDDCDVD_H

#if __GNUC__ >=3
#pragma GCC system_header
#endif

#include "ntddstor.h"

#ifdef __cplusplus
extern "C" {
#endif

#define IOCTL_DVD_BASE                    FILE_DEVICE_DVD

#define IOCTL_DVD_END_SESSION \
  CTL_CODE(IOCTL_DVD_BASE, 0x0403, METHOD_BUFFERED, FILE_READ_ACCESS)

#define IOCTL_DVD_GET_REGION \
  CTL_CODE(IOCTL_DVD_BASE, 0x0405, METHOD_BUFFERED, FILE_READ_ACCESS)

#define IOCTL_DVD_READ_KEY \
  CTL_CODE(IOCTL_DVD_BASE, 0x0401, METHOD_BUFFERED, FILE_READ_ACCESS)

#define IOCTL_DVD_READ_STRUCTURE \
  CTL_CODE(IOCTL_DVD_BASE, 0x0450, METHOD_BUFFERED, FILE_READ_ACCESS)

#define IOCTL_DVD_SEND_KEY \
  CTL_CODE(IOCTL_DVD_BASE, 0x0402, METHOD_BUFFERED, FILE_READ_ACCESS)

#define IOCTL_DVD_START_SESSION \
  CTL_CODE(IOCTL_DVD_BASE, 0x0400, METHOD_BUFFERED, FILE_READ_ACCESS)

#define IOCTL_DVD_SET_READ_AHEAD \
  CTL_CODE(IOCTL_DVD_BASE, 0x0404, METHOD_BUFFERED, FILE_READ_ACCESS)


typedef ULONG DVD_SESSION_ID, *PDVD_SESSION_ID;

typedef struct _STORAGE_SET_READ_AHEAD {
	LARGE_INTEGER  TriggerAddress;
	LARGE_INTEGER  TargetAddress;
} STORAGE_SET_READ_AHEAD, *PSTORAGE_SET_READ_AHEAD;

typedef enum DVD_STRUCTURE_FORMAT {
  DvdPhysicalDescriptor,
  DvdCopyrightDescriptor,
  DvdDiskKeyDescriptor,
  DvdBCADescriptor,
  DvdManufacturerDescriptor,
  DvdMaxDescriptor
} DVD_STRUCTURE_FORMAT, *PDVD_STRUCTURE_FORMAT;

#include <pshpack1.h>
typedef struct DVD_READ_STRUCTURE {
  LARGE_INTEGER  BlockByteOffset;
  DVD_STRUCTURE_FORMAT  Format;
  DVD_SESSION_ID  SessionId;
  UCHAR  LayerNumber;
} DVD_READ_STRUCTURE, *PDVD_READ_STRUCTURE;
#include <poppack.h>

typedef struct _DVD_DESCRIPTOR_HEADER {
    USHORT Length;
    UCHAR Reserved[2];
    UCHAR Data[0];
} DVD_DESCRIPTOR_HEADER, *PDVD_DESCRIPTOR_HEADER;

#include <pshpack1.h>
typedef struct _DVD_LAYER_DESCRIPTOR {
  UCHAR  BookVersion : 4;
  UCHAR  BookType : 4;
  UCHAR  MinimumRate : 4;
  UCHAR  DiskSize : 4;
  UCHAR  LayerType : 4;
  UCHAR  TrackPath : 1;
  UCHAR  NumberOfLayers : 2;
  UCHAR  Reserved1 : 1;
  UCHAR  TrackDensity : 4;
  UCHAR  LinearDensity : 4;
  ULONG  StartingDataSector;
  ULONG  EndDataSector;
  ULONG  EndLayerZeroSector;
  UCHAR  Reserved5 : 7;
  UCHAR  BCAFlag : 1;
  UCHAR  Reserved6;
} DVD_LAYER_DESCRIPTOR, *PDVD_LAYER_DESCRIPTOR;
#include <poppack.h>

typedef struct _DVD_COPYRIGHT_DESCRIPTOR {
  UCHAR  CopyrightProtectionType;
  UCHAR  RegionManagementInformation;
  USHORT  Reserved;
} DVD_COPYRIGHT_DESCRIPTOR, *PDVD_COPYRIGHT_DESCRIPTOR;

typedef struct _DVD_DISK_KEY_DESCRIPTOR {
  UCHAR  DiskKeyData[2048];
} DVD_DISK_KEY_DESCRIPTOR, *PDVD_DISK_KEY_DESCRIPTOR;

typedef enum _DVD_KEY_TYPE {
	DvdChallengeKey = 0x01,
	DvdBusKey1,
	DvdBusKey2,
	DvdTitleKey,
	DvdAsf,
	DvdSetRpcKey = 0x6,
	DvdGetRpcKey = 0x8,
	DvdDiskKey = 0x80,
	DvdInvalidateAGID = 0x3f
} DVD_KEY_TYPE;

typedef struct _DVD_COPY_PROTECT_KEY {
	ULONG  KeyLength;
	DVD_SESSION_ID  SessionId;
	DVD_KEY_TYPE  KeyType;
	ULONG  KeyFlags;
	union {
		HANDLE  FileHandle;
		LARGE_INTEGER  TitleOffset;
	} Parameters;
	UCHAR  KeyData[0];
} DVD_COPY_PROTECT_KEY, *PDVD_COPY_PROTECT_KEY;

#define DVD_CHALLENGE_KEY_LENGTH          (12 + sizeof(DVD_COPY_PROTECT_KEY))
#define DVD_BUS_KEY_LENGTH                (8 + sizeof(DVD_COPY_PROTECT_KEY))
#define DVD_TITLE_KEY_LENGTH              (8 + sizeof(DVD_COPY_PROTECT_KEY))
#define DVD_DISK_KEY_LENGTH               (2048 + sizeof(DVD_COPY_PROTECT_KEY))
#define DVD_RPC_KEY_LENGTH                (sizeof(DVD_RPC_KEY) + sizeof(DVD_COPY_PROTECT_KEY))
#define DVD_SET_RPC_KEY_LENGTH            (sizeof(DVD_SET_RPC_KEY) + sizeof(DVD_COPY_PROTECT_KEY))
#define DVD_ASF_LENGTH                    (sizeof(DVD_ASF) + sizeof(DVD_COPY_PROTECT_KEY))

#define DVD_END_ALL_SESSIONS              ((DVD_SESSION_ID) 0xffffffff)


#define DVD_CGMS_RESERVED_MASK            0x00000078

#define DVD_CGMS_COPY_PROTECT_MASK        0x00000018
#define DVD_CGMS_COPY_PERMITTED           0x00000000
#define DVD_CGMS_COPY_ONCE                0x00000010
#define DVD_CGMS_NO_COPY                  0x00000018

#define DVD_COPYRIGHT_MASK                0x00000040
#define DVD_NOT_COPYRIGHTED               0x00000000
#define DVD_COPYRIGHTED                   0x00000040

#define DVD_SECTOR_PROTECT_MASK           0x00000020
#define DVD_SECTOR_NOT_PROTECTED          0x00000000
#define DVD_SECTOR_PROTECTED              0x00000020


typedef struct _DVD_BCA_DESCRIPTOR {
  UCHAR  BCAInformation[0];
} DVD_BCA_DESCRIPTOR, *PDVD_BCA_DESCRIPTOR;

typedef struct _DVD_MANUFACTURER_DESCRIPTOR {
  UCHAR  ManufacturingInformation[2048];
} DVD_MANUFACTURER_DESCRIPTOR, *PDVD_MANUFACTURER_DESCRIPTOR;

typedef struct _DVD_RPC_KEY {
  UCHAR  UserResetsAvailable : 3;
  UCHAR  ManufacturerResetsAvailable : 3;
  UCHAR  TypeCode : 2;
  UCHAR  RegionMask;
  UCHAR  RpcScheme;
  UCHAR  Reserved2[1];
} DVD_RPC_KEY, *PDVD_RPC_KEY;

typedef struct _DVD_SET_RPC_KEY {
  UCHAR  PreferredDriveRegionCode;
  UCHAR  Reserved[3];
} DVD_SET_RPC_KEY, *PDVD_SET_RPC_KEY;

typedef struct _DVD_ASF {
  UCHAR  Reserved0[3];
  UCHAR  SuccessFlag : 1;
  UCHAR  Reserved1 : 7;
} DVD_ASF, *PDVD_ASF;

typedef struct _DVD_REGION {
	UCHAR  CopySystem;
	UCHAR  RegionData;
	UCHAR  SystemRegion;
	UCHAR  ResetCount;
} DVD_REGION, *PDVD_REGION;

#ifdef __cplusplus
}
#endif

#endif /* __NTDDCDVD_H */


#endif 

#ifdef __cplusplus
}
#endif

#endif /* __SMBUS_H */
