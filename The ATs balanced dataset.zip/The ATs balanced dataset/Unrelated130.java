/*
 * prntfont.h
 *
 * Declarations for Windows NT printer driver font metrics
 *
 * This file is part of the w32api package.
 *
 * Contributors:
 *   Created by Filip Navara <xnavara@volny.cz>
 *
 * THIS SOFTWARE IS NOT COPYRIGHTED
 *
 * This source code is offered for use in the public domain. You may
 * use, modify or distribute it freely.
 *
 * This code is distributed in the hope that it will be useful but
 * WITHOUT ANY WARRANTY. ALL WARRANTIES, EXPRESS OR IMPLIED ARE HEREBY
 * DISCLAIMED. This includes but is not limited to warranties of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

#ifndef __PRNTFONT_H
#define __PRNTFONT_H

#define UNIFM_VERSION_1_0		0x10000
#define UNI_GLYPHSETDATA_VERSION_1_0	0x10000

#define UFM_SOFT	1
#define UFM_CART        2
#define UFM_SCALABLE    4

#define DF_TYPE_HPINTELLIFONT	0
#define DF_TYPE_TRUETYPE	1
#define DF_TYPE_PST1		2
#define DF_TYPE_CAPSL		3
#define DF_TYPE_OEM1		4
#define DF_TYPE_OEM2		5
#define DF_NOITALIC		1
#define DF_NOUNDER		2
#define DF_XM_CR		4
#define DF_NO_BOLD		8
#define DF_NO_DOUBLE_UNDERLINE	16
#define DF_NO_STRIKETHRU	32
#define DF_BKSP_OK		64

#define MTYPE_COMPOSE			1
#define MTYPE_DIRECT			2
#define MTYPE_PAIRED			4
#define MTYPE_FORMAT_MASK		7
#define MTYPE_SINGLE			8
#define MTYPE_DOUBLE			16
#define MTYPE_DOUBLEBYTECHAR_MASK	24
#define MTYPE_REPLACE			32
#define MTYPE_ADD			64
#define MTYPE_DISABLE			128
#define MTYPE_PREDEFIN_MASK		192

#define CC_NOPRECNV	0x0000FFFF
#define CC_DEFAULT	0
#define CC_CP437	-1
#define CC_CP850	-2
#define CC_CP863	-3
#define CC_BIG5		-10
#define CC_ISC		-11
#define CC_JIS		-12
#define CC_JIS_ANK	-13
#define CC_NS86		-14
#define CC_TCA		-15
#define CC_GB2312	-16
#define CC_SJIS		-17
#define CC_WANSUNG	-18

#define UFF_FILE_MAGIC		TAG('1','F','F','U')
#define UFF_VERSION_NUMBER	0x10001
#define FONT_DIR_SORTED		1
#define FONT_REC_SIG            TAG('C','E','R','F')
#define WINNT_INSTALLER_SIG     TAG('I','F','T','N')

#define FONT_FL_UFM             0x0001
#define FONT_FL_IFI             0x0002
#define FONT_FL_SOFTFONT        0x0004
#define FONT_FL_PERMANENT_SF    0x0008
#define FONT_FL_DEVICEFONT      0x0010
#define FONT_FL_GLYPHSET_GTT    0x0020
#define FONT_FL_GLYPHSET_RLE    0x0040
#define FONT_FL_RESERVED        0x8000

#define DATA_UFM_SIG        TAG('M','F','U','D')
#define DATA_IFI_SIG        TAG('I','F','I','D')
#define DATA_GTT_SIG        TAG('T','T','G','D')
#define DATA_CTT_SIG        TAG('T','T','C','D')
#define DATA_VAR_SIG        TAG('R','A','V','D')

#define FG_CANCHANGE	128
#define WM_FI_FILENAME	900

#define GET_UNIDRVINFO(pUFM) ((PUNIDRVINFO)((ULONG_PTR)(pUFM) + (pUFM)->loUnidrvInfo))
#define GET_IFIMETRICS(pUFM) ((IFIMETRICS*)((ULONG_PTR)(pUFM) + (pUFM)->loIFIMetrics))
#define GET_EXTTEXTMETRIC(pUFM) ((EXTTEXTMETRIC*)((ULONG_PTR)(pUFM) + (pUFM)->loExtTextMetric))
#define GET_WIDTHTABLE(pUFM) ((PWIDTHTABLE)((ULONG_PTR)(pUFM) + (pUFM)->loWidthTable))
#define GET_KERNDATA(pUFM) ((PKERNDATA)((ULONG_PTR)(pUFM) + (pUFM)->loKernPair))
#define GET_SELECT_CMD(pUni) ((PCHAR)(pUni) + (pUni)->SelectFont.loOffset)
#define GET_UNSELECT_CMD(pUni) ((PCHAR)(pUni) + (pUni)->UnSelectFont.loOffset)
#define GET_GLYPHRUN(pGTT) ((PGLYPHRUN)((ULONG_PTR)(pGTT) + ((PUNI_GLYPHSETDATA)pGTT)->loRunOffset))
#define GET_CODEPAGEINFO(pGTT) ((PUNI_CODEPAGEINFO)((ULONG_PTR)(pGTT) + ((PUNI_GLYPHSETDATA)pGTT)->loCodePageOffset))
#define GET_MAPTABLE(pGTT) ((PMAPTABLE)((ULONG_PTR)(pGTT) + ((PUNI_GLYPHSETDATA)pGTT)->loMapTableOffset))

typedef struct _UNIFM_HDR
{
  DWORD  dwSize;
  DWORD  dwVersion;
  ULONG  ulDefaultCodepage;
  LONG  lGlyphSetDataRCID;
  DWORD  loUnidrvInfo;
  DWORD  loIFIMetrics;
  DWORD  loExtTextMetric;
  DWORD  loWidthTable;
  DWORD  loKernPair;
  DWORD  dwReserved[2];
} UNIFM_HDR, *PUNIFM_HDR;

typedef struct _INVOC
{
  DWORD  dwCount;
  DWORD  loOffset;
} INVOC, *PINVOC;

typedef struct _UNIDRVINFO
{
  DWORD  dwSize;
  DWORD  flGenFlags;
  WORD  wType;
  WORD  fCaps;
  WORD  wXRes;
  WORD  wYRes;
  SHORT  sYAdjust;
  SHORT  sYMoved;
  WORD  wPrivateData;
  SHORT  sShift;
  INVOC  SelectFont;
  INVOC  UnSelectFont;
  WORD  wReserved[4];
} UNIDRVINFO, *PUNIDRVINFO;

typedef struct _EXTTEXTMETRIC
{
  SHORT  emSize;
  SHORT  emPointSize;
  SHORT  emOrientation;
  SHORT  emMasterHeight;
  SHORT  emMinScale;
  SHORT  emMaxScale;
  SHORT  emMasterUnits;
  SHORT  emCapHeight;
  SHORT  emXHeight;
  SHORT  emLowerCaseAscent;
  SHORT  emLowerCaseDescent;
  SHORT  emSlant;
  SHORT  emSuperScript;
  SHORT  emSubScript;
  SHORT  emSuperScriptSize;
  SHORT  emSubScriptSize;
  SHORT  emUnderlineOffset;
  SHORT  emUnderlineWidth;
  SHORT  emDoubleUpperUnderlineOffset;
  SHORT  emDoubleLowerUnderlineOffset;
  SHORT  emDoubleUpperUnderlineWidth;
  SHORT  emDoubleLowerUnderlineWidth;
  SHORT  emStrikeOutOffset;
  SHORT  emStrikeOutWidth;
  WORD  emKernPairs;
  WORD  emKernTracks;
} EXTTEXTMETRIC, *PEXTTEXTMETRIC;

typedef struct _WIDTHRUN
{
  WORD  wStartGlyph;
  WORD  wGlyphCount;
  DWORD  loCharWidthOffset;
} WIDTHRUN, *PWIDTHRUN;

typedef struct _WIDTHTABLE
{
  DWORD  dwSize;
  DWORD  dwRunNum;
  WIDTHRUN  WidthRun[1];
} WIDTHTABLE, *PWIDTHTABLE;

typedef struct _KERNDATA
{
  DWORD  dwSize;
  DWORD  dwKernPairNum;
  FD_KERNINGPAIR  KernPair[1];
} KERNDATA, *PKERNDATA;

typedef struct _UNI_GLYPHSETDATA
{
  DWORD  dwSize;
  DWORD  dwVersion;
  DWORD  dwFlags;
  LONG  lPredefinedID;
  DWORD  dwGlyphCount;
  DWORD  dwRunCount;
  DWORD  loRunOffset;
  DWORD  dwCodePageCount;
  DWORD  loCodePageOffset;
  DWORD  loMapTableOffset;
  DWORD  dwReserved[2];
} UNI_GLYPHSETDATA, *PUNI_GLYPHSETDATA;

typedef struct _UNI_CODEPAGEINFO
{
  DWORD  dwCodePage;
  INVOC  SelectSymbolSet;
  INVOC  UnSelectSymbolSet;
} UNI_CODEPAGEINFO, *PUNI_CODEPAGEINFO;

typedef struct _GLYPHRUN
{
  WCHAR  wcLow;
  WORD  wGlyphCount;
} GLYPHRUN, *PGLYPHRUN;

typedef struct _TRANSDATA
{
  BYTE  ubCodePageID;
  BYTE  ubType;
  union
  {
    SHORT  sCode;
    BYTE  ubCode;
    BYTE  ubPairs[2];
  } uCode;
} TRANSDATA, *PTRANSDATA;

typedef struct _MAPTABLE {
  DWORD  dwSize;
  DWORD  dwGlyphNum;
  TRANSDATA  Trans[1];
} MAPTABLE, *PMAPTABLE;

typedef struct _UFF_FILEHEADER {
  DWORD  dwSignature;
  DWORD  dwVersion;
  DWORD  dwSize;
  DWORD  nFonts;
  DWORD  nGlyphSets;
  DWORD  nVarData;
  DWORD  offFontDir;
  DWORD  dwFlags;
  DWORD  dwReserved[4];
} UFF_FILEHEADER, *PUFF_FILEHEADER;

typedef struct _UFF_FONTDIRECTORY {
  DWORD  dwSignature;
  WORD  wSize;
  WORD  wFontID;
  SHORT  sGlyphID;
  WORD  wFlags;
  DWORD  dwInstallerSig;
  DWORD  offFontName;
  DWORD  offCartridgeName;
  DWORD  offFontData;
  DWORD  offGlyphData;
  DWORD  offVarData;
} UFF_FONTDIRECTORY, *PUFF_FONTDIRECTORY;

typedef struct _DATA_HEADER {
  DWORD  dwSignature;
  WORD  wSize;
  WORD  wDataID;
  DWORD  dwDataSize;
  DWORD  dwReserved;
} DATA_HEADER, *PDATA_HEADER;

typedef struct _OEMFONTINSTPARAM {
  DWORD  cbSize;
  HANDLE  hPrinter;
  HANDLE  hModule;
  HANDLE  hHeap;
  DWORD  dwFlags;
  PWSTR  pFontInstallerName;
} OEMFONTINSTPARAM, *POEMFONTINSTPARAM;

#endif /* __PRNTFONT_H */
is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _XCMC_H
#define _XCMC_H

#ifdef __cplusplus
extern "C" {
#endif

typedef char                CMC_sint8;
typedef short               CMC_sint16;
typedef long int            CMC_sint32;
typedef unsigned short int  CMC_uint16;
typedef unsigned long int   CMC_uint32;
typedef void*               CMC_buffer;
typedef char*               CMC_string;

typedef CMC_uint16          CMC_boolean;
typedef CMC_sint32          CMC_enum;
typedef CMC_uint32          CMC_return_code;
typedef CMC_uint32          CMC_flags;
typedef CMC_string          CMC_object_identifier;
typedef CMC_uint32          CMC_session_id;
typedef CMC_uint32          CMC_ui_id;

#define CMC_FALSE   ((CMC_boolean)0)
#define CMC_TRUE    ((CMC_boolean)1)

#define CMC_SUCCESS                         ((CMC_return_code) 0)

#define CMC_E_AMBIGUOUS_RECIPIENT           ((CMC_return_code) 1)
#define CMC_E_ATTACHMENT_NOT_FOUND          ((CMC_return_code) 2)
#define CMC_E_ATTACHMENT_OPEN_FAILURE       ((CMC_return_code) 3)
#define CMC_E_ATTACHMENT_READ_FAILURE       ((CMC_return_code) 4)
#define CMC_E_ATTACHMENT_WRITE_FAILURE      ((CMC_return_code) 5)
#define CMC_E_COUNTED_STRING_UNSUPPORTED    ((CMC_return_code) 6)
#define CMC_E_DISK_FULL                     ((CMC_return_code) 7)
#define CMC_E_FAILURE                       ((CMC_return_code) 8)
#define CMC_E_INSUFFICIENT_MEMORY           ((CMC_return_code) 9)
#define CMC_E_INVALID_CONFIGURATION         ((CMC_return_code) 10)
#define CMC_E_INVALID_ENUM                  ((CMC_return_code) 11)
#define CMC_E_INVALID_FLAG                  ((CMC_return_code) 12)
#define CMC_E_INVALID_MEMORY                ((CMC_return_code) 13)
#define CMC_E_INVALID_MESSAGE_PARAMETER     ((CMC_return_code) 14)
#define CMC_E_INVALID_MESSAGE_REFERENCE     ((CMC_return_code) 15)
#define CMC_E_INVALID_PARAMETER             ((CMC_return_code) 16)
#define CMC_E_INVALID_SESSION_ID            ((CMC_return_code) 17)
#define CMC_E_INVALID_UI_ID                 ((CMC_return_code) 18)
#define CMC_E_LOGON_FAILURE                 ((CMC_return_code) 19)
#define CMC_E_MESSAGE_IN_USE                ((CMC_return_code) 20)
#define CMC_E_NOT_SUPPORTED                 ((CMC_return_code) 21)
#define CMC_E_PASSWORD_REQUIRED             ((CMC_return_code) 22)
#define CMC_E_RECIPIENT_NOT_FOUND           ((CMC_return_code) 23)
#define CMC_E_SERVICE_UNAVAILABLE           ((CMC_return_code) 24)
#define CMC_E_TEXT_TOO_LARGE                ((CMC_return_code) 25)
#define CMC_E_TOO_MANY_FILES                ((CMC_return_code) 26)
#define CMC_E_TOO_MANY_RECIPIENTS           ((CMC_return_code) 27)
#define CMC_E_UNABLE_TO_NOT_MARK_AS_READ    ((CMC_return_code) 28)
#define CMC_E_UNRECOGNIZED_MESSAGE_TYPE     ((CMC_return_code) 29)
#define CMC_E_UNSUPPORTED_ACTION            ((CMC_return_code) 30)
#define CMC_E_UNSUPPORTED_CHARACTER_SET     ((CMC_return_code) 31)
#define CMC_E_UNSUPPORTED_DATA_EXT          ((CMC_return_code) 32)
#define CMC_E_UNSUPPORTED_FLAG              ((CMC_return_code) 33)
#define CMC_E_UNSUPPORTED_FUNCTION_EXT      ((CMC_return_code) 34)
#define CMC_E_UNSUPPORTED_VERSION           ((CMC_return_code) 35)
#define CMC_E_USER_CANCEL                   ((CMC_return_code) 36)
#define CMC_E_USER_NOT_LOGGED_ON            ((CMC_return_code) 37)

#define CMC_ERROR_DISPLAYED                 ((CMC_return_code) 0x00008000)
#define CMC_ERROR_RSV_MASK                  ((CMC_return_code) 0x0000FFFF)
#define CMC_ERROR_IMPL_MASK                 ((CMC_return_code) 0xFFFF0000)

typedef struct {
    CMC_uint32          length;
    char                string[1];
} CMC_counted_string;

typedef CMC_counted_string CMC_message_reference;

typedef struct {
    CMC_sint8  second;
    CMC_sint8  minute;
    CMC_sint8  hour;
    CMC_sint8  day;
    CMC_sint8  month;
    CMC_sint8  year;
    CMC_sint8  isdst;
    CMC_sint8  unused1;
    CMC_sint16 tmzone;
    CMC_sint16 unused2;
} CMC_time;

#define CMC_NO_TIMEZONE ((CMC_sint16) 0x8000)


typedef struct {
    CMC_uint32 item_code;
    CMC_uint32 item_data;
    CMC_buffer item_reference;
    CMC_flags  extension_flags;
} CMC_extension;

#define CMC_EXT_REQUIRED                    ((CMC_flags) 0x00010000)
#define CMC_EXT_OUTPUT                      ((CMC_flags) 0x00020000)
#define CMC_EXT_LAST_ELEMENT                ((CMC_flags) 0x80000000)
#define CMC_EXT_RSV_FLAG_MASK               ((CMC_flags) 0xFFFF0000)
#define CMC_EXT_ITEM_FLAG_MASK              ((CMC_flags) 0x0000FFFF)


typedef struct CMC_attachment_s {
    CMC_string              attach_title;
    CMC_object_identifier   attach_type;
    CMC_string              attach_filename;
    CMC_flags               attach_flags;
    CMC_extension          *attach_extensions;
} CMC_attachment;

#define CMC_ATT_APP_OWNS_FILE  ((CMC_flags) 1)
#define CMC_ATT_LAST_ELEMENT   ((CMC_flags) 0x80000000)

#define CMC_ATT_OID_BINARY      "? ? ? ? ? ?"
#define CMC_ATT_OID_TEXT        "? ? ? ? ? ?"


typedef struct {
    CMC_string              name;
    CMC_enum                name_type;
    CMC_string              address;
    CMC_enum                role;
    CMC_flags               recip_flags;
    CMC_extension          *recip_extensions;
} CMC_recipient;

#define CMC_TYPE_UNKNOWN                    ((CMC_enum) 0)
#define CMC_TYPE_INDIVIDUAL                 ((CMC_enum) 1)
#define CMC_TYPE_GROUP                      ((CMC_enum) 2)

#define CMC_ROLE_TO                         ((CMC_enum) 0)
#define CMC_ROLE_CC                         ((CMC_enum) 1)
#define CMC_ROLE_BCC                        ((CMC_enum) 2)
#define CMC_ROLE_ORIGINATOR                 ((CMC_enum) 3)
#define CMC_ROLE_AUTHORIZING_USER           ((CMC_enum) 4)

#define CMC_RECIP_IGNORE                    ((CMC_flags) 1)
#define CMC_RECIP_LIST_TRUNCATED            ((CMC_flags) 2)
#define CMC_RECIP_LAST_ELEMENT              ((CMC_flags) 0x80000000)


typedef struct {
    CMC_message_reference  *message_reference;
    CMC_string              message_type;
    CMC_string              subject;
    CMC_time                time_sent;
    CMC_string              text_note;
    CMC_recipient          *recipients;
    CMC_attachment         *attachments;
    CMC_flags               message_flags;
    CMC_extension          *message_extensions;
} CMC_message;

#define CMC_MSG_READ                        ((CMC_flags) 1)
#define CMC_MSG_TEXT_NOTE_AS_FILE           ((CMC_flags) 2)
#define CMC_MSG_UNSENT                      ((CMC_flags) 4)
#define CMC_MSG_LAST_ELEMENT                ((CMC_flags) 0x80000000)


typedef struct {
    CMC_message_reference  *message_reference;
    CMC_string              message_type;
    CMC_string              subject;
    CMC_time                time_sent;
    CMC_uint32              byte_length;
    CMC_recipient          *originator;
    CMC_flags               summary_flags;
    CMC_extension          *message_summary_extensions;
} CMC_message_summary;

#define CMC_SUM_READ                        ((CMC_flags) 1)
#define CMC_SUM_UNSENT                      ((CMC_flags) 2)
#define CMC_SUM_LAST_ELEMENT                ((CMC_flags) 0x80000000)

#define CMC_ERROR_UI_ALLOWED                ((CMC_flags) 0x01000000)
#define CMC_LOGON_UI_ALLOWED                ((CMC_flags) 0x02000000)
#define CMC_COUNTED_STRING_TYPE             ((CMC_flags) 0x04000000)

CMC_return_code WINAPI cmc_send(
    CMC_session_id          session,
    CMC_message            *message,
    CMC_flags               send_flags,
    CMC_ui_id               ui_id,
    CMC_extension          *send_extensions
);

#define CMC_SEND_UI_REQUESTED               ((CMC_flags) 1)


CMC_return_code WINAPI cmc_send_documents(
    CMC_string              recipient_addresses,
    CMC_string              subject,
    CMC_string              text_note,
    CMC_flags               send_doc_flags,
    CMC_string              file_paths,
    CMC_string              file_names,
    CMC_string              delimiter,
    CMC_ui_id               ui_id
);

#define CMC_FIRST_ATTACH_AS_TEXT_NOTE       ((CMC_flags) 2)


CMC_return_code WINAPI cmc_act_on(
    CMC_session_id          session,
    CMC_message_reference  *message_reference,
    CMC_enum                operation,
    CMC_flags               act_on_flags,
    CMC_ui_id               ui_id,
    CMC_extension          *act_on_extensions
);

#define CMC_ACT_ON_EXTENDED                 ((CMC_enum) 0)
#define CMC_ACT_ON_DELETE                   ((CMC_enum) 1)


CMC_return_code WINAPI cmc_list(
    CMC_session_id          session,
    CMC_string              message_type,
    CMC_flags               list_flags,
    CMC_message_reference  *seed,
    CMC_uint32             *count,
    CMC_ui_id               ui_id,
    CMC_message_summary   **result,
    CMC_extension          *list_extensions
);

#define CMC_LIST_UNREAD_ONLY                ((CMC_flags) 1)
#define CMC_LIST_MSG_REFS_ONLY              ((CMC_flags) 2)
#define CMC_LIST_COUNT_ONLY                 ((CMC_flags) 4)

#define CMC_LENGTH_UNKNOWN          0xFFFFFFFF


CMC_return_code WINAPI cmc_read(
    CMC_session_id          session,
    CMC_message_reference  *message_reference,
    CMC_flags               read_flags,
    CMC_message           **message,
    CMC_ui_id               ui_id,
    CMC_extension          *read_extensions
);

#define CMC_DO_NOT_MARK_AS_READ             ((CMC_flags) 1)
#define CMC_MSG_AND_ATT_HDRS_ONLY           ((CMC_flags) 2)
#define CMC_READ_FIRST_UNREAD_MESSAGE       ((CMC_flags) 4)


CMC_return_code WINAPI cmc_look_up(
    CMC_session_id          session,
    CMC_recipient          *recipient_in,
    CMC_flags               look_up_flags,
    CMC_ui_id               ui_id,
    CMC_uint32             *count,
    CMC_recipient         **recipient_out,
    CMC_extension          *look_up_extensions
);

#define CMC_LOOKUP_RESOLVE_PREFIX_SEARCH    ((CMC_flags) 1)
#define CMC_LOOKUP_RESOLVE_IDENTITY         ((CMC_flags) 2)
#define CMC_LOOKUP_RESOLVE_UI               ((CMC_flags) 4)
#define CMC_LOOKUP_DETAILS_UI               ((CMC_flags) 8)
#define CMC_LOOKUP_ADDRESSING_UI            ((CMC_flags) 16)


CMC_return_code WINAPI cmc_free( CMC_buffer memory );

CMC_return_code WINAPI cmc_logoff(
    CMC_session_id          session,
    CMC_ui_id               ui_id,
    CMC_flags               logoff_flags,
    CMC_extension          *logoff_extensions
);

CMC_return_code WINAPI cmc_logon(
    CMC_string              service,
    CMC_string              user,
    CMC_string              password,
    CMC_object_identifier   character_set,
    CMC_ui_id               ui_id,
    CMC_uint16              caller_cmc_version,
    CMC_flags               logon_flags,
    CMC_session_id         *session,
    CMC_extension          *logon_extensions
);

#define CMC_VERSION         ((CMC_uint16) 100)

CMC_return_code WINAPI cmc_query_configuration(
    CMC_session_id          session,
    CMC_enum                item,
    CMC_buffer              reference,
    CMC_extension          *config_extensions
);

#define CMC_CONFIG_CHARACTER_SET            ((CMC_enum) 1)
#define CMC_CONFIG_LINE_TERM                ((CMC_enum) 2)
#define CMC_CONFIG_DEFAULT_SERVICE          ((CMC_enum) 3)
#define CMC_CONFIG_DEFAULT_USER             ((CMC_enum) 4)
#define CMC_CONFIG_REQ_PASSWORD             ((CMC_enum) 5)
#define CMC_CONFIG_REQ_SERVICE              ((CMC_enum) 6)
#define CMC_CONFIG_REQ_USER                 ((CMC_enum) 7)
#define CMC_CONFIG_UI_AVAIL                 ((CMC_enum) 8)
#define CMC_CONFIG_SUP_NOMKMSGREAD          ((CMC_enum) 9)
#define CMC_CONFIG_SUP_COUNTED_STR          ((CMC_enum) 10)
#define CMC_CONFIG_VER_IMPLEM               ((CMC_enum) 11)
#define CMC_CONFIG_VER_SPEC                 ((CMC_enum) 12)

#define CMC_LINE_TERM_CRLF                  ((CMC_enum) 0)
#define CMC_LINE_TERM_CR                    ((CMC_enum) 1)
#define CMC_LINE_TERM_LF                    ((CMC_enum) 2)

#define CMC_REQUIRED_NO                     ((CMC_enum) 0)
#define CMC_REQUIRED_YES                    ((CMC_enum) 1)
#define CMC_REQUIRED_OPT                    ((CMC_enum) 2)

#define CMC_CHAR_CP437                      "1 2 840 113556 3 2 437"
#define CMC_CHAR_CP850                      "1 2 840 113556 3 2 85"
#define CMC_CHAR_CP1252                     "1 2 840 113556 3 2 1252"
#define CMC_CHAR_ISTRING                    "1 2 840 113556 3 2 0"
#define CMC_CHAR_UNICODE                    "1 2 840 113556 3 2 1"

#ifdef __cplusplus
}
#endif

#endif /* #ifndef _XCMC_H *
#ifndef __USBCAMDI_H
#define __USBCAMDI_H

#if __GNUC__ >=3
#pragma GCC system_header
#endif

#if !defined(__USB_H) && !defined(__USBDI_H)
#error include usb.h or usbdi.h before usbcamdi.h
#else

#ifdef __cplusplus
extern "C" {
#endif

#pragma pack(push,4)

#if defined(_BATTERYCLASS_)
  #define USBCAMAPI DECLSPEC_EXPORT
#else
  #define USBCAMAPI DECLSPEC_IMPORT
#endif


/* FIXME: Unknown definition */
typedef PVOID PHW_STREAM_REQUEST_BLOCK;

DEFINE_GUID(GUID_USBCAMD_INTERFACE,
  0x2bcb75c0, 0xb27f, 0x11d1, 0xba, 0x41, 0x0, 0xa0, 0xc9, 0xd, 0x2b, 0x5);

#define USBCAMD_PROCESSPACKETEX_DropFrame             0x0002
#define USBCAMD_PROCESSPACKETEX_NextFrameIsStill      0x0004
#define USBCAMD_PROCESSPACKETEX_CurrentFrameIsStill   0x0008

#define USBCAMD_DATA_PIPE                 0x0001
#define USBCAMD_MULTIPLEX_PIPE            0x0002
#define USBCAMD_SYNC_PIPE                 0x0004
#define USBCAMD_DONT_CARE_PIPE            0x0008

#define USBCAMD_VIDEO_STREAM              0x1
#define USBCAMD_STILL_STREAM              0x2
#define USBCAMD_VIDEO_STILL_STREAM        (USBCAMD_VIDEO_STREAM | USBCAMD_STILL_STREAM)

#define USBCAMD_STOP_STREAM               0x00000001
#define USBCAMD_START_STREAM              0x00000000

typedef struct _pipe_config_descriptor {
  CHAR  StreamAssociation;
  UCHAR  PipeConfigFlags;
} USBCAMD_Pipe_Config_Descriptor, *PUSBCAMD_Pipe_Config_Descriptor;

typedef enum {
	USBCAMD_CamControlFlag_NoVideoRawProcessing = 1,
	USBCAMD_CamControlFlag_NoStillRawProcessing = 2,
	USBCAMD_CamControlFlag_AssociatedFormat = 4,
	USBCAMD_CamControlFlag_EnableDeviceEvents = 8
} USBCAMD_CamControlFlags;

typedef NTSTATUS DDKAPI
(*PCAM_ALLOCATE_BW_ROUTINE)(
  PDEVICE_OBJECT  BusDevice
typedef NTSTATUS DDKAPI
(*PCAM_START_CAPTURE_ROUTINE_EX)(
  PDEVICE_OBJECT  BusDeviceObject,
  PVOID  DeviceContext,
  ULONG  StreamNumber);

typedef NTSTATUS DDKAPI
(*PCAM_STOP_CAPTURE_ROUTINE)(
  PDEVICE_OBJECT  BusDeviceObject,
  PVOID  DeviceContext);

typedef NTSTATUS DDKAPI
(*PCAM_STOP_CAPTURE_ROUTINE_EX)(
  PDEVICE_OBJECT  BusDeviceObject,
  PVOID  DeviceContext,
  ULONG  StreamNumber);

typedef struct _USBCAMD_DEVICE_DATA {
	ULONG  Sig;
	PCAM_INITIALIZE_ROUTINE  CamInitialize;
	PCAM_INITIALIZE_ROUTINE  CamUnInitialize;
	PCAM_PROCESS_PACKET_ROUTINE  CamProcessUSBPacket;
	PCAM_NEW_FRAME_ROUTINE  CamNewVideoFrame;
	PCAM_PROCESS_RAW_FRAME_ROUTINE  CamProcessRawVideoFrame;
	PCAM_START_CAPTURE_ROUTINE  CamStartCapture;
	PCAM_STOP_CAPTURE_ROUTINE  CamStopCapture;
	PCAM_CONFIGURE_ROUTINE  CamConfigure;
	PCAM_STATE_ROUTINE  CamSaveState;
	PCAM_STATE_ROUTINE  CamRestoreState;
	PCAM_ALLOCATE_BW_ROUTINE  CamAllocateBandwidth;
	PCAM_FREE_BW_ROUTINE  CamFreeBandwidth;
} USBCAMD_DEVICE_DATA, *PUSBCAMD_DEVICE_DATA;

typedef struct _USBCAMD_DEVICE_DATA2 {
	ULONG  Sig;
	PCAM_INITIALIZE_ROUTINE  CamInitialize;
	PCAM_INITIALIZE_ROUTINE  CamUnInitialize;
	PCAM_PROCESS_PACKET_ROUTINE_EX  CamProcessUSBPacketEx;
	PCAM_NEW_FRAME_ROUTINE_EX  CamNewVideoFrameEx;
	CAM_PROCESS_RAW_FRAME_ROUTINE_EX  CamProcessRawVideoFrameEx;
	PCAM_START_CAPTURE_ROUTINE_EX  CamStartCaptureEx;
	PCAM_STOP_CAPTURE_ROUTINE_EX  CamStopCaptureEx;
	PCAM_CONFIGURE_ROUTINE_EX  #define USBCAMD_VERSION_200               0x200

typedef struct _USBCAMD_INTERFACE {
  INTERFACE  Interface;
  PFNUSBCAMD_WaitOnDeviceEvent  USBCAMD_WaitOnDeviceEvent;
  PFNUSBCAMD_BulkReadWrite  USBCAMD_BulkReadWrite;
  PFNUSBCAMD_SetVideoFormat  USBCAMD_SetVideoFormat;
  PFNUSBCAMD_SetIsoPipeState  USBCAMD_SetIsoPipeState;
  PFNUSBCAMD_CancelBulkReadWrite  USBCAMD_CancelBulkReadWrite;
} USBCAMD_INTERFACE, *PUSBCAMD_INTERFACE;

typedef VOID DDKAPI
(*PSTREAM_RECEIVE_PACKET)(
  IN PVOID  Srb,
  IN PVOID  DeviceContext,
  IN PBOOLEAN  Completed);

#if defined(DEBUG_LOG)

USBCAMAPI
VOID
DDKAPI
USBCAMD_Debug_LogEntry(
	IN CHAR  *Name,
	IN ULONG  Info1,
	IN ULONG  Info2,
	IN ULONG  Info3);

#define ILOGENTRY(sig, info1, info2, info3) \
  USBCAMD_Debug_LogEntry(sig, (ULONG)info1, (ULONG)info2, (ULONG)info3)
*
 * usbcamdi.h
 *
 * USB Camera driver interface.
 *
 * This file is part of the w32api package.
 *
 * Contributors:
 *   Created by Casper S. Hornstrup <chorns@users.sourceforge.net>
 *
 * THIS SOFTWARE IS NOT COPYRIGHTED
 *
 * This source code is offered for use in the public domain. You may
 * use, modify or distribute it freely.
 *
 * This code is distributed in the hope that it will be useful but
 * WITHOUT ANY WARRANTY. ALL WARRANTIES, EXPRESS OR IMPLIED ARE HEREBY
 * DISCLAIMED. This includes but is not limited to warranties of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

#ifndef __USBCAMDI_H
#define __USBCAMDI_H

#if __GNUC__ >=3
#pragma GCC system_header
#endif

#if !defined(__USB_H) && !defined(__USBDI_H)
#error include usb.h or usbdi.h before usbcamdi.h
#else

#ifdef __cplusplus
extern "C" {
#endif

#pragma pack(push,4)

#if defined(_BATTERYCLASS_)
  #define USBCAMAPI DECLSPEC_EXPORT
#else
  #define USBCAMAPI DECLSPEC_IMPORT
#endif


/* FIXME: Unknown definition */
typedef PVOID PHW_STREAM_REQUEST_BLOCK;

DEFINE_GUID(GUID_USBCAMD_INTERFACE,
  0x2bcb75c0, 0xb27f, 0x11d1, 0xba, 0x41, 0x0, 0xa0, 0xc9, 0xd, 0x2b, 0x5);

#define USBCAMD_PROCESSPACKETEX_DropFrame             0x0002
#define USBCAMD_PROCESSPACKETEX_NextFrameIsStill      0x0004
#define USBCAMD_PROCESSPACKETEX_CurrentFrameIsStill   0x0008

#define USBCAMD_DATA_PIPE                 0x0001
#define USBCAMD_MULTIPLEX_PIPE            0x0002
#define USBCAMD_SYNC_PIPE                 0x0004
#define USBCAMD_DONT_CARE_PIPE            0x0008

#define USBCAMD_VIDEO_STREAM              0x1
#define USBCAMD_STILL_STREAM              0x2
#define USBCAMD_VIDEO_STILL_STREAM        (USBCAMD_VIDEO_STREAM | USBCAMD_STILL_STREAM)

#define USBCAMD_STOP_STREAM               0x00000001
#define USBCAMD_START_STREAM              0x00000000

typedef struct _pipe_config_descriptor {
  CHAR  StreamAssociation;
  UCHAR  PipeConfigFlags;
} USBCAMD_Pipe_Config_Descriptor, *PUSBCAMD_Pipe_Config_Descriptor;

typedef enum {
	USBCAMD_CamControlFlag_NoVideoRawProcessing = 1,
	USBCAMD_CamControlFlag_NoStillRawProcessing = 2,
	USBCAMD_CamControlFlag_AssociatedFormat = 4,
	USBCAMD_CamControlFlag_EnableDeviceEvents = 8
} USBCAMD_CamControlFlags;

typedef NTSTATUS DDKAPI
(*PCAM_ALLOCATE_BW_ROUTINE)(
  PDEVICE_OBJECT  BusDeviceObject,
  PVOID  DeviceContext,
  PULONG  RawFrameLength,
  PVOID  Format);

typedef NTSTATUS DDKAPI
(*PCAM_ALLOCATE_BW_ROUTINE_EX)(
  PDEVICE_OBJECT  BusDeviceObject,
  PVOID  DeviceContext,
  PULONG  RawFrameLength,
  PVOID  Format,
  ULONG  StreamNumber);

typedef NTSTATUS DDKAPI
(*PCAM_CONFIGURE_ROUTINE)(
  PDEVICE_OBJECT  BusDeviceObject,
  PVOID  DeviceContext,
  PUSBD_INTERFACE_INFORMATION  Interface,
  PUSB_CONFIGURATION_DESCRIPTOR  ConfigurationDescriptor,
  PLONG  DataPipeIndex,
  PLONG  SyncPipeIndex);

typedef NTSTATUS DDKAPI
(*PCAM_CONFIGURE_ROUTINE_EX)(
  PDEVICE_OBJECT  BusDeviceObject,
  PVOID  DeviceContext,
  PUSBD_INTERFACE_INFORMATION  Interface,
  PUSB_CONFIGURATION_DESCRIPTOR  ConfigurationDescriptor,
  ULONG  PipeConfigListSize,
  PUSBCAMD_Pipe_Config_Descriptor  PipeConfig,
  PUSB_DEVICE_DESCRIPTOR  DeviceDescriptor);

typedef NTSTATUS DDKAPI
(*PCAM_FREE_BW_ROUTINE)(
  PDEVICE_OBJECT  BusDeviceObject,
  PVOID  DeviceContext);

typedef NTSTATUS DDKAPI
(*PCAM_FREE_BW_ROUTINE_EX)(
  PDEVICE_OBJECT  BusDeviceObject,
  PVOID  DeviceContext,
  ULONG  StreamNumber);

typedef NTSTATUS DDKAPI
(*PCAM_INITIALIZE_ROUTINE)(
  PDEVICE_OBJECT  BusDeviceObject,
  PVOID  DeviceContext);

typedef VOID DDKAPI
(*PCAM_NEW_FRAME_ROUTINE)(
  PVOID  DeviceContext,
  PVOID  FrameContext);

typedef VOID DDKAPI
(*PCAM_NEW_FRAME_ROUTINE_EX)(
  PVOID  DeviceContext,
  PVOID  FrameContext,
  ULONG  StreamNumber,
  PULONG  FrameLength);

typedef NTSTATUS DDKAPI
(*PCAM_PROCESS_RAW_FRAME_ROUTINE)(
  PDEVICE_OBJECT  BusDeviceObject,
  PVOID  DeviceContext,
  PVOID  FrameContext,
  PVOID  FrameBuffer,
  ULONG  FrameLength,
  PVOID  RawFrameBuffer,
  ULONG  RawFrameLength,
  ULONG  NumberOfPackets,
  PULONG  BytesReturned);

typedef NTSTATUS DDKAPI
(*PCAM_PROCESS_RAW_FRAME_ROUTINE_EX)(
  PDEVICE_OBJECT  BusDeviceObject,
  PVOID  DeviceContext,
  PVOID  FrameContext,
  PVOID  FrameBuffer,
  ULONG  FrameLength,
  PVOID  RawFrameBuffer,
  ULONG  RawFrameLength,
  ULONG  NumberOfPackets,
  PULONG  BytesReturned,
  ULONG  ActualRawFrameLength,
  ULONG  StreamNumber);

typedef ULONG DDKAPI
(*PCAM_PROCESS_PACKET_ROUTINE)(
  PDEVICE_OBJECT  BusDeviceObject,
  PVOID  DeviceContext,
  PVOID  CurrentFrameContext,
  PUSBD_ISO_PACKET_DESCRIPTOR  SyncPacket,
  PVOID  SyncBuffer,
  PUSBD_ISO_PACKET_DESCRIPTOR  DataPacket,
  PVOID  DataBuffer,
  PBOOLEAN  FrameComplete,
  PBOOLEAN  NextFrameIsStill);

typedef ULONG DDKAPI
(*PCAM_PROCESS_PACKET_ROUTINE_EX)(
  PDEVICE_OBJECT  BusDeviceObject,
  PVOID  DeviceContext,
  PVOID  CurrentFrameContext,
  PUSBD_ISO_PACKET_DESCRIPTOR  SyncPacket,
  PVOID  SyncBuffer,
  PUSBD_ISO_PACKET_DESCRIPTOR  DataPacket,
  PVOID  DataBuffer,
  PBOOLEAN  FrameComplete,
  PULONG  PacketFlag,
  PULONG  ValidDataOffset);

typedef NTSTATUS DDKAPI
(*PCAM_STATE_ROUTINE)(
  PDEVICE_OBJECT  BusDeviceObject,
  PVOID  DeviceContext);

typedef NTSTATUS DDKAPI
(*PCAM_START_CAPTURE_ROUTINE)(
  PDEVICE_OBJECT  BusDeviceObject,
  PVOID  DeviceContext);

typedef NTSTATUS DDKAPI
(*PCAM_START_CAPTURE_ROUTINE_EX)(
  PDEVICE_OBJECT  BusDeviceObject,
  PVOID  DeviceContext,
  ULONG  StreamNumber);

typedef NTSTATUS DDKAPI
(*PCAM_STOP_CAPTURE_ROUTINE)(
  PDEVICE_OBJECT  BusDeviceObject,
  PVOID  DeviceContext);

typedef NTSTATUS DDKAPI
(*PCAM_STOP_CAPTURE_ROUTINE_EX)(
  PDEVICE_OBJECT  BusDeviceObject,
  PVOID  DeviceContext,
  ULONG  StreamNumber);

typedef struct _USBCAMD_DEVICE_DATA {
	ULONG  Sig;
	PCAM_INITIALIZE_ROUTINE  CamInitialize;
	PCAM_INITIALIZE_ROUTINE  CamUnInitialize;
	PCAM_PROCESS_PACKET_ROUTINE  CamProcessUSBPacket;
	PCAM_NEW_FRAME_ROUTINE  CamNewVideoFrame;
	PCAM_PROCESS_RAW_FRAME_ROUTINE  CamProcessRawVideoFrame;
	PCAM_START_CAPTURE_ROUTINE  CamStartCapture;
	PCAM_STOP_CAPTURE_ROUTINE  CamStopCapture;
	PCAM_CONFIGURE_ROUTINE  CamConfigure;
	PCAM_STATE_ROUTINE  CamSaveState;
	PCAM_STATE_ROUTINE  CamRestoreState;
	PCAM_ALLOCATE_BW_ROUTINE  CamAllocateBandwidth;
	PCAM_FREE_BW_ROUTINE  CamFreeBandwidth;
} USBCAMD_DEVICE_DATA, *PUSBCAMD_DEVICE_DATA;

typedef struct _USBCAMD_DEVICE_DATA2 {
	ULONG  Sig;
	PCAM_INITIALIZE_ROUTINE  CamInitialize;
	PCAM_INITIALIZE_ROUTINE  CamUnInitialize;
	PCAM_PROCESS_PACKET_ROUTINE_EX  CamProcessUSBPacketEx;
	PCAM_NEW_FRAME_ROUTINE_EX  CamNewVideoFrameEx;
	PCAM_PROCESS_RAW_FRAME_ROUTINE_EX  CamProcessRawVideoFrameEx;
	PCAM_START_CAPTURE_ROUTINE_EX  CamStartCaptureEx;
	PCAM_STOP_CAPTURE_ROUTINE_EX  CamStopCaptureEx;
	PCAM_CONFIGURE_ROUTINE_EX  CamConfigureEx;
	PCAM_STATE_ROUTINE  CamSaveState;
	PCAM_STATE_ROUTINE  CamRestoreState;
	PCAM_ALLOCATE_BW_ROUTINE_EX  CamAllocateBandwidthEx;
	PCAM_FREE_BW_ROUTINE_EX  CamFreeBandwidthEx;
} USBCAMD_DEVICE_DATA2, *PUSBCAMD_DEVICE_DATA2;

USBCAMAPI
ULONG
DDKAPI
USBCAMD_InitializeNewInterface(
  IN PVOID  DeviceContext,
  IN PVOID  DeviceData,
  IN ULONG  Version,
  IN ULONG  CamControlFlag);

typedef VOID DDKAPI
(*PCOMMAND_COMPLETE_FUNCTION)(
  PVOID  DeviceContext,
  PVOID  CommandContext,
  NTSTATUS  NtStatus);

typedef NTSTATUS DDKAPI
(*PFNUSBCAMD_BulkReadWrite)(
  IN PVOID  DeviceContext,
  IN USHORT  PipeIndex,
  IN PVOID  Buffer,
  IN ULONG  BufferLength,
  IN PCOMMAND_COMPLETE_FUNCTION  CommandComplete,
  IN PVOID  CommandContext);

typedef NTSTATUS DDKAPI
(*PFNUSBCAMD_SetIsoPipeState)(
  IN PVOID  DeviceContext,
  IN ULONG  PipeStateFlags);

typedef NTSTATUS DDKAPI
(*PFNUSBCAMD_CancelBulkReadWrite)(
  IN PVOID  DeviceContext,
  IN ULONG  PipeIndex);

typedef NTSTATUS DDKAPI
(*PFNUSBCAMD_SetVideoFormat)(
  IN PVOID  DeviceContext,
  IN PHW_STREAM_REQUEST_BLOCK  pSrb);

typedef NTSTATUS DDKAPI
(*PFNUSBCAMD_WaitOnDeviceEvent)(
  IN PVOID  DeviceContext,
  IN ULONG  PipeIndex,
  IN PVOID  Buffer,
  IN ULONG  BufferLength,
  IN PCOMMAND_COMPLETE_FUNCTION  EventComplete,
  IN PVOID  EventContext,
  IN BOOLEAN  LoopBack);

USBCAMAPI
PVOID
DDKAPI
USBCAMD_AdapterReceivePacket(
  IN PHW_STREAM_REQUEST_BLOCK  Srb,
  IN PUSBCAMD_DEVICE_DATA  DeviceData,
  IN PDEVICE_OBJECT  *DeviceObject,
  IN BOOLEAN  NeedsCompletion);

USBCAMAPI
NTSTATUS
DDKAPI
USBCAMD_ControlVendorCommand(
  IN PVOID  DeviceContext,
  IN UCHAR  Request,
  IN USHORT  Value,
  IN USHORT  Index,
  IN PVOID  Buffer,
  IN OUT PULONG  BufferLength,
  IN BOOLEAN  GetData,
  IN PCOMMAND_COMPLETE_FUNCTION  CommandComplete,
  IN PVOID  CommandContext);

typedef VOID DDKAPI
(*PADAPTER_RECEIVE_PACKET_ROUTINE)(
  IN PHW_STREAM_REQUEST_BLOCK  Srb);

USBCAMAPI
ULONG
DDKAPI
USBCAMD_DriverEntry(
  PVOID  Context1,
  PVOID  Context2,
  ULONG  DeviceContextSize,
  ULONG  FrameContextSize,
  PADAPTER_RECEIVE_PACKET_ROUTINE  ReceivePacket);

USBCAMAPI
NTSTATUS
DDKAPI
USBCAMD_GetRegistryKeyValue(
  IN HANDLE  Handle,
  IN PWCHAR  KeyNameString,
  IN ULONG  KeyNameStringLength,
  IN PVOID  Data,
  IN ULONG  DataLength);

USBCAMAPI
NTSTATUS
DDKAPI
USBCAMD_SelectAlternateInterface(
  IN PVOID  DeviceContext,
  IN OUT PUSBD_INTERFACE_INFORMATION  RequestInterface);

#define USBCAMD_VERSION_200               0x200

typedef struct _USBCAMD_INTERFACE {
  INTERFACE  Interface;
  PFNUSBCAMD_WaitOnDeviceEvent  USBCAMD_WaitOnDeviceEvent;
  PFNUSBCAMD_BulkReadWrite  USBCAMD_BulkReadWrite;
  PFNUSBCAMD_SetVideoFormat  USBCAMD_SetVideoFormat;
  PFNUSBCAMD_SetIsoPipeState  USBCAMD_SetIsoPipeState;
  PFNUSBCAMD_CancelBulkReadWrite  USBCAMD_CancelBulkReadWrite;
} USBCAMD_INTERFACE, *PUSBCAMD_INTERFACE;

typedef VOID DDKAPI
(*PSTREAM_RECEIVE_PACKET)(
  IN PVOID  Srb,
  IN PVOID  DeviceContext,
  IN PBOOLEAN  Completed);

#if defined(DEBUG_LOG)

USBCAMAPI
VOID
DDKAPI
USBCAMD_Debug_LogEntry(
	IN CHAR  *Name,
	IN ULONG  Info1,
	IN ULONG  Info2,
	IN ULONG  Info3);

#define ILOGENTRY(sig, info1, info2, info3) \
  USBCAMD_Debug_LogEntry(sig, (ULONG)info1, (ULONG)info2, (ULONG)info3)

#else

#define ILOGENTRY(sig, info1, info2, info3)

#endif /* DEBUG_LOG */

#pragma pack(pop)

#ifdef __cplusplus
}
#endif

#endif /* !defined(__USB_H) && !defined(__USBDI_H) */


#endif /* __USBCAMDI_H */

#else

#define ILOGENTRY(sig, info1, info2, info3)

#endif /* DEBUG_LOG */

#pragma pack(pop)

#ifdef __cplusplus
}
#endif

#endif /* !defined(__USB_H) && !defined(__USBDI_H) */


#endif /* __USBCAMDI_H */
