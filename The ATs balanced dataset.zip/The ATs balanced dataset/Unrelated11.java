	return true;
}

bool
RawCamBehavior::writeColor(const FilterBankEvent& e) {
	FilterBankGenerator& fbkgen=*e.getSource();

	unsigned int y_layer=fbkgen.getNumLayers()-1-config->vision.rawcam.y_skip;
	unsigned int uv_layer=fbkgen.getNumLayers()-1-config->vision.rawcam.uv_skip;

	if(config->vision.rawcam.channel==-1) {
		if(e.getGeneratorID()==EventBase::visRawCameraEGID && config->vision.rawcam.compression==Config::vision_config::RawCamConfig::COMPRESS_NONE
			 || e.getGeneratorID()==EventBase::visJPEGEGID && config->vision.rawcam.compression==Config::vision_config::RawCamConfig::COMPRESS_JPEG) {
			if(const JPEGGenerator* jgen=dynamic_cast<const JPEGGenerator*>(&fbkgen))
				if(jgen->getCurrentSourceFormat()==JPEGGenerator::SRC_COLOR)
					return true;
			openPacket(fbkgen,e.getTimeStamp(),uv_layer);
			if(cur==NULL) //error should have been displayed by openPacket
				return false;
			
			if(!LoadSave::encodeInc("FbkImage",cur,avail,"ran out of space %s:%un",__FILE__,__LINE__)) return false;;
			if(!LoadSave::encodeInc(0,cur,avail,"ran out of space %s:%un",__FILE__,__LINE__)) return false;;
			if(!LoadSave::encodeInc(0,cur,avail,"ran out of space %s:%un",__FILE__,__LINE__)) return false;;
			if(!LoadSave::encodeInc(-1,cur,avail,"ran out of space %s:%un",__FILE__,__LINE__)) return false;;
			if(!LoadSave::encodeInc(RawCameraGenerator::CHAN_Y,cur,avail,"ran out of space %s:%un",__FILE__,__LINE__)) return false;;
			if(!LoadSave::encodeInc("blank",cur,avail,"ran out of space %s:%un",__FILE__,__LINE__)) return false;;

			fbkgen.selectSaveImage(uv_layer,RawCameraGenerator::CHAN_U);
			if(!LoadSave::checkInc(fbkgen.saveBuffer(cur,avail),cur,avail,"image size too large -- may need to set Config::vision.rawcam.transport to TCP and reopen raw cam")) return false;
			
			fbkgen.selectSaveImage(uv_layer,RawCameraGenerator::CHAN_V);
			if(!LoadSave::checkInc(fbkgen.saveBuffer(cur,avail),cur,avail,"image size too large -- may need to set Config::vision.rawcam.transport to TCP and reopen raw cam")) return false;

			closePacket();
		}
		return true;
	}

	unsigned int big_layer=y_layer;
	unsigned int small_layer=uv_layer;
	if(y_layer<uv_layer) { 
		big_layer=uv_layer;
		small_layer=y_layer;
	}
	if(const JPEGGenerator* jgen=dynamic_cast<const JPEGGenerator*>(&fbkgen)) {
		if(config->vision.rawcam.compression!=Config::vision_config::RawCamConfig::COMPRESS_JPEG)
			return true;
		if(jgen->getCurrentSourceFormat()==JPEGGenerator::SRC_COLOR && big_layer-small_layer<2) {
			openPacket(fbkgen,e.getTimeStamp(),big_layer);
			if(cur==NULL) //error should have been displayed by openPacket
				return false;
			
			fbkgen.selectSaveImage(big_layer,0);
			if(!LoadSave::checkInc(fbkgen.saveBuffer(cur,avail),cur,avail,"image size too large -- may need to set Config::vision.rawcam.transport to TCP and reopen raw cam")) return false;
			
			closePacket();
		} else if(jgen->getCurrentSourceFormat()==JPEGGenerator::SRC_GRAYSCALE && big_layer-small_layer>=2) {
			bool opened=openPacket(fbkgen,e.getTimeStamp(),big_layer);
			if(cur==NULL) //error should have been displayed by openPacket
				return false;
			
			if(big_layer==y_layer) {
				fbkgen.selectSaveImage(y_layer,RawCameraGenerator::CHAN_Y);
				if(!LoadSave::checkInc(fbkgen.saveBuffer(cur,avail),cur,avail,"image size too large -- may need to set Config::vision.rawcam.transport to TCP and reopen raw cam")) return false;
			} else {
				fbkgen.selectSaveImage(uv_layer,RawCameraGenerator::CHAN_U);
				if(!LoadSave::checkInc(fbkgen.saveBuffer(cur,avail),cur,avail,"image size too large -- may need to set Config::vision.rawcam.transport to TCP and reopen raw cam")) return false;
				fbkgen.selectSaveImage(uv_layer,RawCameraGenerator::CHAN_V);
				if(!LoadSave::checkInc(fbkgen.saveBuffer(cur,avail),cur,avail,"image size too large -- may need to set Config::vision.rawcam.transport to TCP and reopen raw cam")) return false;
			}
			
