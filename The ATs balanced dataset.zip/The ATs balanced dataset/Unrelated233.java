package org.mifos.application.checklist.business;

import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.mifos.application.checklist.exceptions.CheckListException;
import org.mifos.application.checklist.persistence.CheckListPersistence;
import org.mifos.application.checklist.util.helpers.CheckListType;
import org.mifos.application.checklist.util.resources.CheckListConstants;
import org.mifos.application.master.business.SupportedLocalesEntity;
import org.mifos.framework.business.BusinessObject;
import org.mifos.framework.exceptions.PersistenceException;
import org.mifos.framework.util.helpers.StringUtils;

public abstract class CheckListBO extends BusinessObject {

	private final Short checklistId;

	private String checklistName;

	private Short checklistStatus;

	private Set<CheckListDetailEntity> checklistDetails;

	private SupportedLocalesEntity supportedLocales;

	protected CheckListBO() {
		this.checklistId = null;
		checklistDetails = new LinkedHashSet<CheckListDetailEntity>();

	}

	protected CheckListBO(String checkListName, Short checkListStatus,
			List<String> details, Short localeId, Short userId)
			throws CheckListException {
		setCreateDetails(userId, new Date());
		this.checklistId = null;

		if (details.size() > 0) {
			setCheckListDetails(details, localeId);
		} else {
			throw new CheckListException(
					CheckListConstants.CHECKLIST_CREATION_EXCEPTION);
		}
		if (checkListName != null) {
			this.checklistName = checkListName;
		} else {
			throw new CheckListException(
					CheckListConstants.CHECKLIST_CREATION_EXCEPTION);
		}
		this.checklistStatus = checkListStatus;
		this.supportedLocales = new SupportedLocalesEntity(localeId);
	}

	public Short getChecklistId() {
		return checklistId;
	}

	public String getChecklistName() {
		return this.checklistName;
	}

	@SuppressWarnings("unused") // see .hbm.xml file
	private void setChecklistName(String checklistName) {
		this.checklistName = checklistName;
	}

	public Short getChecklistStatus() {
		return this.checklistStatus;
	}

	@SuppressWarnings("unused") // see .hbm.xml file
	private void setChecklistStatus(Short checklistStatus) {
		this.checklistStatus = checklistStatus;
	}

	public Set<CheckListDetailEntity> getChecklistDetails() {
		return this.checklistDetails;

	}

	@SuppressWarnings("unused") // see .hbm.xml file
	private void setChecklistDetails(
			Set<CheckListDetailEntity> checklistDetailSet) {
		this.checklistDetails = checklistDetailSet;
	}

	public SupportedLocalesEntity getSupportedLocales() {
		return this.supportedLocales;
	}

	@SuppressWarnings("unused") // see .hbm.xml file
	private void setSupportedLocales(SupportedLocalesEntity supportedLocales) {
		this.supportedLocales = supportedLocales;
	}

	public void addChecklistDetail(CheckListDetailEntity checkListDetailEntity) {
		checklistDetails.add(checkListDetailEntity);
	}

	public void save() throws CheckListException {
		try {
			new CheckListPersistence().createOrUpdate(this);
		} catch (PersistenceException e) {
			throw new CheckListException(e);
		}
	}

	private void setCheckListDetails(List<String> details, Short locale) {
		checklistDetails = new HashSet<CheckListDetailEntity>();
		for (String detail : details) {
			CheckListDetailEntity checkListDetailEntity = new CheckListDetailEntity(
					detail, Short.valueOf("1"), this, locale);
			checklistDetails.add(checkListDetailEntity);
		}
	}

	public abstract CheckListType getCheckListType();

	protected void update(String checkListName, Short checkListStatus,
			List<String> details, Short localeId, Short userId)
			throws CheckListException {
		setUpdateDetails(userId);
		if (details == null || details.size() <= 0)
			throw new CheckListException(
					CheckListConstants.CHECKLIST_CREATION_EXCEPTION);
		if (StringUtils.isNullOrEmpty(checkListName))
			throw new CheckListException(
					CheckListConstants.CHECKLIST_CREATION_EXCEPTION);
		this.checklistName = checkListName;
		getChecklistDetails().clear();
		for (String detail : details) {
			CheckListDetailEntity checkListDetailEntity = new CheckListDetailEntity(
					detail, Short.valueOf("1"), this, localeId);
			getChecklistDetails().add(checkListDetailEntity);
		}
		this.checklistStatus = checkListStatus;
		this.supportedLocales = new SupportedLocalesEntity(localeId);
	}

	protected void validateCheckListState(Short masterTypeId, Short stateId,
			boolean isCustomer) throws CheckListException {
		Integer records;
		try {
			records = new CheckListPersistence().isValidCheckListState(
					masterTypeId, stateId, isCustomer);
			if (records.intValue() != 0)
				throw new CheckListException(
						CheckListConstants.EXCEPTION_STATE_ALREADY_EXIST);
		} catch (PersistenceException pe) {
			throw new CheckListException(pe);
		}
	}
}

package org.mifos.framework.components.taggenerator;

import java.util.HashMap;
import java.util.Map;

import org.mifos.application.accounts.loan.business.LoanBO;
import org.mifos.application.accounts.savings.business.SavingsBO;
import org.mifos.application.customer.business.CustomerAccountBO;
import org.mifos.application.customer.business.CustomerBO;
import org.mifos.application.customer.center.business.CenterBO;
import org.mifos.application.customer.client.business.ClientBO;
import org.mifos.application.customer.group.business.GroupBO;
import org.mifos.application.customer.util.helpers.CustomerLevel;
import org.mifos.application.office.business.OfficeBO;
import org.mifos.application.personnel.business.PersonnelBO;
import org.mifos.framework.business.BusinessObject;
import org.mifos.framework.exceptions.FrameworkRuntimeException;
import org.mifos.framework.exceptions.PageExpiredException;

public class TagGeneratorFactory {

	private Map<String, String> generatorNames = new HashMap<String, String>();

	private static TagGeneratorFactory instance = new TagGeneratorFactory();

	protected Map<String, String> getGeneratorNames() {
		return generatorNames;
	}

	private TagGeneratorFactory() {
		generatorNames
				.put("org.mifos.application.customer.client.business.ClientBO",
						"org.mifos.framework.components.taggenerator.CustomerTagGenerator");
		generatorNames
				.put("org.mifos.application.customer.center.business.CenterBO",
						"org.mifos.framework.components.taggenerator.CustomerTagGenerator");
		generatorNames
				.put("org.mifos.application.customer.group.business.GroupBO",
						"org.mifos.framework.components.taggenerator.CustomerTagGenerator");
		generatorNames
				.put("org.mifos.application.office.business.OfficeBO",
						"org.mifos.framework.components.taggenerator.OfficeTagGenerator");
		generatorNames
				.put(
						"org.mifos.application.accounts.savings.business.SavingsBO",
						"org.mifos.framework.components.taggenerator.AccountTagGenerator");
		generatorNames
				.put("org.mifos.application.accounts.loan.business.LoanBO",
						"org.mifos.framework.components.taggenerator.AccountTagGenerator");
		generatorNames
				.put(
						"org.mifos.application.accounts.business.CustomerAccountBO",
						"org.mifos.framework.components.taggenerator.AccountTagGenerator");
		generatorNames
				.put("org.mifos.application.personnel.business.PersonnelBO",
						"org.mifos.framework.components.taggenerator.PersonnelTagGenerator");

	}

	public static TagGeneratorFactory getInstance() {
		return instance;
	}

	public TagGenerator getGenerator(BusinessObject bo) throws PageExpiredException {
		try {
			
			if ( bo==null) throw new PageExpiredException();
			return (TagGenerator) Class.forName(
					getGeneratorNames().get(getClassName(bo))).newInstance();
		} catch (ClassNotFoundException e) {
			throw new FrameworkRuntimeException(e);
		} catch (IllegalAccessException e) {
			throw new FrameworkRuntimeException(e);
		} catch (InstantiationException e) {
			throw new FrameworkRuntimeException(e);
		}
	}

	private String getClassName(BusinessObject bo) {
		if (bo instanceof CenterBO)
			return "org.mifos.application.customer.center.business.CenterBO";
		if (bo instanceof GroupBO)
			return "org.mifos.application.customer.group.business.GroupBO";
		if (bo instanceof ClientBO)
			return "org.mifos.application.customer.client.business.ClientBO";
		if (bo instanceof SavingsBO)
			return "org.mifos.application.accounts.savings.business.SavingsBO";
		if (bo instanceof LoanBO)
			return "org.mifos.application.accounts.loan.business.LoanBO";
		if (bo instanceof CustomerAccountBO)
			return "org.mifos.application.accounts.business.CustomerAccountBO";
		if (bo instanceof OfficeBO)
			return "org.mifos.application.office.business.OfficeBO";
		if (bo instanceof PersonnelBO)
			return "org.mifos.application.personnel.business.PersonnelBO";
		if (bo instanceof CustomerBO) {
			if (((CustomerBO) bo).getCustomerLevel().getId().equals(
					CustomerLevel.CLIENT.getValue()))
				return "org.mifos.application.customer.client.business.ClientBO";
			if (((CustomerBO) bo).getCustomerLevel().getId().equals(
					CustomerLevel.GROUP.getValue()))
				return "org.mifos.application.customer.group.business.GroupBO";
			if (((CustomerBO) bo).getCustomerLevel().getId().equals(
					CustomerLevel.CENTER.getValue()))
				return "org.mifos.application.customer.center.business.CenterBO";
		}
		return null;
	}

}
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "name",
    "officeId",
    "loanOfficerId",
    "weeklyMeeting",
    "monthlyMeeting",
    "externalId",
    "mfiJoiningDate",
    "address",
    "customField",
    "feeAmount"
})
@XmlRootElement(name = "center")
public class Center {

    @XmlElement(required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String name;
    protected short officeId;
    protected short loanOfficerId;
    protected WeeklyMeeting weeklyMeeting;
    protected MonthlyMeeting monthlyMeeting;
    protected String externalId;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar mfiJoiningDate;
    protected Address address;
    protected List<CustomField> customField;
    protected List<FeeAmount> feeAmount;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the officeId property.
     * 
     */
    public short getOfficeId() {
        return officeId;
    }

    /**
     * Sets the value of the officeId property.
     * 
     */
    public void setOfficeId(short value) {
        this.officeId = value;
    }

    /**
     * Gets the value of the loanOfficerId property.
     * 
     */
    public short getLoanOfficerId() {
        return loanOfficerId;
    }

    /**
     * Sets the value of the loanOfficerId property.
     * 
     */
    public void setLoanOfficerId(short value) {
        this.loanOfficerId = value;
    }

    /**
     * Gets the value of the weeklyMeeting property.
     * 
     * @return
     *     possible object is
     *     {@link WeeklyMeeting }
     *     
     */
    public WeeklyMeeting getWeeklyMeeting() {
        return weeklyMeeting;
    }

    /**
     * Sets the value of the weeklyMeeting property.
     * 
     * @param value
     *     allowed object is
     *     {@link WeeklyMeeting }
     *     
     */
    public void setWeeklyMeeting(WeeklyMeeting value) {
        this.weeklyMeeting = value;
    }

    /**
     * Gets the value of the monthlyMeeting property.
     * 
     * @return
     *     possible object is
     *     {@link MonthlyMeeting }
     *     
     */
    public MonthlyMeeting getMonthlyMeeting() {
        return monthlyMeeting;
    }

    /**
     * Sets the value of the monthlyMeeting property.
     * 
     * @param value
     *     allowed object is
     *     {@link MonthlyMeeting }
     *     
     */
    public void setMonthlyMeeting(MonthlyMeeting value) {
        this.monthlyMeeting = value;
    }

    /**
     * Gets the value of the externalId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalId() {
        return externalId;
    }

    /**
     * Sets the value of the externalId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalId(String value) {
        this.externalId = value;
    }

    /**
     * Gets the value of the mfiJoiningDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getMfiJoiningDate() {
        return mfiJoiningDate;
    }

    /**
     * Sets the value of the mfiJoiningDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setMfiJoiningDate(XMLGregorianCalendar value) {
        this.mfiJoiningDate = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link Address }
     *     
     */
    public Address getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link Address }
     *     
     */
    public void setAddress(Address value) {
        this.address = value;
    }

    /**
     * Gets the value of the customField property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customField property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomField().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CustomField }
     * 
     * 
     */
    public List<CustomField> getCustomField() {
        if (customField == null) {
            customField = new ArrayList<CustomField>();
        }
        return this.customField;
    }

    /**
     * Gets the value of the feeAmount property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the feeAmount property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFeeAmount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FeeAmount }
     * 
     * 
     */
    public List<FeeAmount> getFeeAmount() {
        if (feeAmount == null) {
            feeAmount = new ArrayList<FeeAmount>();
        }
        return this.feeAmount;
    }

}
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "fieldId",
    "name",
    "stringValue",
    "numericValue",
    "dateValue"
})
@XmlRootElement(name = "customField")
public class CustomField {

    protected Short fieldId;
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String name;
    protected String stringValue;
    protected Integer numericValue;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateValue;

    /**
     * Gets the value of the fieldId property.
     * 
     * @return
     *     possible object is
     *     {@link Short }
     *     
     */
    public Short getFieldId() {
        return fieldId;
    }

    /**
     * Sets the value of the fieldId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Short }
     *     
     */
    public void setFieldId(Short value) {
        this.fieldId = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }
