		Enumeration atts=session.getAttachments().keys();
		while(atts.hasMoreElements()) {
		    ByteStore bs=session.getAttachment((String)atts.nextElement());
		    InternetHeaders ih=new InternetHeaders();
		    ih.addHeader("Content-Transfer-Encoding","BASE64");
		    
		    PipedInputStream pin=new PipedInputStream();
		    PipedOutputStream pout=new PipedOutputStream(pin);
		    
		    /* This is used to write to the Pipe asynchronously to avoid blocking */
		    StreamConnector sconn=new StreamConnector(pin,(int)(bs.getSize()*1.6)+1000);
		    BufferedOutputStream encoder=new BufferedOutputStream(MimeUtility.encode(pout,"BASE64"));
		    encoder.write(bs.getBytes());
		    encoder.flush();
		    encoder.close();
		    //MimeBodyPart att1=sconn.getResult();
		    MimeBodyPart att1=new MimeBodyPart(ih,sconn.getResult().getBytes());

			if(bs.getDescription()!="") {
		    	att1.setDescription(bs.getDescription(),"utf-8");
			}
		    // Modified by exce, start
		    /**
		     * As described in FileAttacher.java line #95, now we need to 
		     * encode the attachment file name.
		     */
		    // att1.setFileName(bs.getName());
		    String fileName = bs.getName();
			String localeCharset=getLocaleCharset(locale.getLanguage(),locale.getCountry());
			String encodedFileName=MimeUtility.encodeText(fileName, localeCharset, null);
			if(encodedFileName.equals(fileName)) {
				att1.addHeader("Content-Type",bs.getContentType());
				att1.setFileName(fileName);
			} else {
				att1.addHeader("Content-Type",bs.getContentType()+"; charset="+localeCharset);
				encodedFileName=encodedFileName.substring(localeCharset.length()+5, encodedFileName.length()-2);
				encodedFileName=encodedFileName.replace('=','%');
				att1.addHeaderLine("Content-Disposition: attachment; filename*="+localeCharset+"''"+encodedFileName);
			}
		    // Modified by exce, end
		    cont.addBodyPart(att1);
		}
		msg.setContent(cont);
		// 		}

		msg.saveChanges();

		boolean savesuccess=true;

		msg.setHeader("Message-ID",session.getUserModel().getWorkMessage().getAttribute("msgid"));
		if(session.getUser().wantsSaveSent()) {
		    String folderhash=session.getUser().getSentFolder();		    
		    try {
			Folder folder=session.getFolder(folderhash);
			Message[] m=new Message[1];
			m[0]=msg;
			folder.appendMessages(m);
		    } catch(MessagingException e) {
			savesuccess=false;
		    } catch(NullPointerException e) {
			// Invalid folder:
			savesuccess=false;
		    }
		}

		boolean sendsuccess=false;

		try {
		    Transport.send(msg);
		    Address sent[]=new Address[to.length+cc.length+bcc.length];
		    int c1=0;int c2=0;
		    for(c1=0;c1<to.length;c1++) {
			sent[c1]=to[c1];
		    }
		    for(c2=0;c2<cc.length;c2++) {
			sent[c1+c2]=cc[c2];
		    }
		    for(int c3=0;c3<bcc.length;c3++) {
			sent[c1+c2+c3]=bcc[c3];
		    }
		    sendsuccess=true;
		    throw new SendFailedException("success",new Exception("success"),sent,null,null);
		} catch(SendFailedException e) {
		    session.handleTransportException(e);
		}
		
		//session.clearMessage();

		content=new XHTMLDocument(session.getModel(),
					  store.getStylesheet("sendresult.xsl",
							      user.getPreferredLocale(),user.getTheme()));
//		if(sendsuccess) session.clearWork();
	    } catch(Exception e) {
		e.printStackTrace();
		
		store.log(Storage.LOG_ERR,e);
		throw new DocumentNotFoundException("Could not send message. (Reason: "+e.getMessage()+")");
	    }
	    
	} else if(head.isContentSet("ATTACH")) {
	    /* Redirect request for attachment (unfortunately HTML forms are not flexible enough to 
	       have two targets without Javascript) */
	    content=parent.getURLHandler().handleURL("/compose/attach",session,head);
	} else {
	    throw new DocumentNotFoundException("Could not send message. (Reason: No content given)");
	}
	return content;
    }

	private String getLocaleCharset(String language, String country) {
		if (language.equals("zh") && country.equals("TW")) {
			return "Big5";
		}
		if(language.equals("hu")) {
			return "iso-8859-2";
		}
		return "UTF-8";
	}

    public String provides() {
	return "message send";
    }

    public String requires() {
	return "composer";
    }
} // SendMessage
/* CVS ID: $Id: FileAttacher.java,v 1.2 2002/11/04 08:45:17 wastl Exp $ */
import net.wastl.webmail.ui.html.*;
import net.wastl.webmail.ui.xml.*;
import net.wastl.webmail.server.*;
import net.wastl.webmail.server.http.*;
import net.wastl.webmail.exceptions.*;
import java.util.*;
import java.text.*;
import java.io.*;
import javax.mail.*;
import net.wastl.webmail.misc.*;

import net.wastl.webmail.session.user.UserSession;
import net.wastl.webmail.storage.StorageManager;

/**
 * FileAttacher.java
 *
 * Created: Tue Sep  7 16:45:21 1999
 *
 * Copyright (C) 1999-2000 Sebastian Schaffert
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
/**
 * This plugin shows the Form for attaching files to a message as well as does
 * the actual attaching to a UserSession
 *
 * provides: attach
 * requires: composer
 *
 * @author Sebastian Schaffert
 * @version
 */

public class FileAttacher implements URLHandler, Plugin {
    
    public static final String VERSION="1.00";
    public static final String URL="/compose/attach";
    
    StorageManager store;

    public FileAttacher() {
	
    }

    public void register(WebMailServer parent) {
	parent.getURLHandler().registerHandler(URL,this);
	this.store=parent.getStorage();
	parent.getConfigScheme().configRegisterStringKey("MAX ATTACH SIZE","1000000","Maximum size of attachments in bytes");
    }

    public String getName() {
	return "FileAttacher";
    }

    public String getDescription() {
	return "This URL-Handler handles file attachments for the Composer.";
    }

    public String getVersion() {
	return VERSION;
    }

    public String getURL() {
	return URL;
    }
    
    public HTMLDocument handleURL(String suburl, HTTPSession sess, HTTPRequestHeader head) throws WebMailException {
	if(sess == null) {
	    throw new WebMailException("No session was given. If you feel this is incorrect, please contact your system administrator");
	}
	UserSession session=(UserSession)sess;
	UserData user=session.getUser();
	if(head.isContentSet("ADD")) {
	    try {
		/* Read the file from the HTTP Header and store it in the user's session */
		ByteStore bs=(ByteStore)head.getObjContent("FILE");
		String description="";
		if(head.isContentSet("DESCRIPTION")) {
		    description=new String(((ByteStore)head.getObjContent("DESCRIPTION")).getBytes());
		}
		//System.err.println("Description: "+description);
		// Modified by exce, start
		/**
		 * It seems that IE will use its browser encoding setting to 
		 * encode the file name that sent to us. Hence we have to 
		 * transcode this carefully. 
		 *
		 * Since we set browser's encoding to UTF-8, the attachment 
		 * fliename, ie, p.getFileName(), should be UTF-8 encoded. 
		 * However the filename retrived from JavaMail MimeBodyPart
		 * is ISO8859_1 encoded, we have to decode its raw bytes and
		 * construct a new string with UTF-8 encoding. 
		 *
		 * But where should we write this code? 
		 * UserSession.java, FileAttacher.java, or HTTPRequestHeader.java?
		 *
		 * I guess the transocde operation should be done here. We retain the
		 * original bytes in HTTP header processing classes.
		 *
		 * Note that the after we called bs.setName() to set name to fileName,
		 * the client browser will display the file name correctly. However,
		 * to safely transfer mail, the file name must be encoded -- eg, by
		 * MimeUtility.encodeText() which is also adopted by M$-OutLook. 
		 * We delay such operation until the mail is being sent, that is, 
		 * SendMessage.java line #390.
		 */
		String fileName = bs.getName();
		
		// Transcode file name
		if (!((fileName == null) || fileName.equals(""))) {
			int offset = fileName.lastIndexOf("\\");		// This is no effect. It seems that MimeBodyPart.getFileName() filters '\' character.
			fileName = fileName.substring(offset + 1);
			fileName = new String(fileName.getBytes("ISO8859_1"), "UTF-8");
			bs.setName(fileName);
		}
		
		// Transcode decription
		if ((description != null) && (!description.equals("")))
			description = new String(description.getBytes("ISO8859_1"), "UTF-8");
		// Modified by exce, end
		if(bs!=null && bs.getSize() >0 ) {
		    session.addWorkAttachment(bs.getName(),bs,description);
		}
	    } catch(Exception e) {
		e.printStackTrace();
		throw new DocumentNotFoundException("Could not attach file. (Reason: "+e.getMessage()+")");
	    }
	} else if(head.isContentSet("DELETE") && head.isContentSet("ATTACHMENTS")) {
		try {
			// Modified by exce, Start
			/**
			 * Since attachmentName comes from HTTPRequestHeader, we have to 
			 * transcode it.
			 */
		    // System.err.println("Removing "+head.getContent("ATTACHMENTS"));
		    // session.removeWorkAttachment(head.getContent("ATTACHMENTS"));
			String attachmentName = head.getContent("ATTACHMENTS");
			attachmentName = new String(attachmentName.getBytes("ISO8859_1"), "UTF-8");
	    	System.err.println("Removing " + attachmentName);
		    session.removeWorkAttachment(attachmentName);
			// Modified by exce, end
		} catch (Exception e) {
			e.printStackTrace();
			throw new DocumentNotFoundException("Could not remove attachment. (Reason: "+e.getMessage()+")");
		}
	}
	    
	return new XHTMLDocument(session.getModel(),
				 store.getStylesheet("compose_attach.xsl",
						     user.getPreferredLocale(),user.getTheme()));
    }

    public String provides() {
	return "attach";
    }

    public String requires() {
	return "composer";
    }
// import net.wastl.webmail.ui.ContentProvider;
import net.wastl.webmail.ui.html.*;
import net.wastl.webmail.ui.xml.*;
import net.wastl.webmail.misc.*;
import net.wastl.webmail.exceptions.*;
import net.wastl.webmail.session.user.UserSession;
import net.wastl.webmail.storage.StorageManager;

import org.w3c.dom.*;

import javax.xml.parsers.*;

/*
 * WebMailHelp.java
 *
 * Created: Wed Sep  1 16:23:14 1999
 *
 * Copyright (C) 1999-2000 Sebastian Schaffert
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
/**
 * Show WebMail help file
 *
 * provides: help
 * requires: content bar
 *
 * @author Sebastian Schaffert
 * @version
 */

public class WebMailHelp implements Plugin, URLHandler {

    public static final String VERSION="2.0";
    public static final String URL="/help";

    ExpireableCache cache;

    StorageManager store;

    public WebMailHelp() {
	
    }

    public void register(WebMailServer parent) {
	parent.getURLHandler().registerHandler(URL,this);
	cache=new ExpireableCache(20,(float).9);
	store=parent.getStorage();
    }

    public String getName() {
	return "WebMailHelp";
    }

    public String getDescription() {
	return "This is the WebMail help content-provider.";
    }	

    public String getVersion() {
	return VERSION;
    }

    public String getURL() {
	return URL;
    }

    public HTMLDocument handleURL(String suburl, HTTPSession session, HTTPRequestHeader header) throws WebMailException {
	UserData user=((UserSession)session).getUser();

	Document helpdoc=(Document)cache.get(user.getPreferredLocale().getLanguage()+"/"+user.getTheme());

	if(helpdoc == null) {
	    String helpdocpath="file://"+store.getBasePath(user.getPreferredLocale(),user.getTheme())+"help.xml";
	    
	    try {
		DocumentBuilder parser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		helpdoc=parser.parse(helpdocpath);
	    } catch(Exception ex) {
		ex.printStackTrace();
		throw new WebMailException("Could not parse "+helpdocpath);
	    }

	    cache.put(user.getPreferredLocale().getLanguage()+"/"+user.getTheme(),helpdoc);
	}
	
	/* Unfortunately we can't use two input documents, so we will temporarily insert the help document
	   into the user's model */
	Node n=session.getModel().importNode(helpdoc.getDocumentElement(),true);
	session.getModel().getDocumentElement().appendChild(n);

	if(header.isContentSet("helptopic") && session instanceof UserSession) {
	    ((UserSession)session).getUserModel().setStateVar("helptopic",header.getContent("helptopic"));
	}


	HTMLDocument retdoc=new XHTMLDocument(session.getModel(),store.getStylesheet("help.xsl",user.getPreferredLocale(),user.getTheme()));

	/* Here we remove the help document from the model */
	session.getModel().getDocumentElement().removeChild(n);
	/* Remove the indicator for a specific help topic */
	if(header.isContentSet("helptopic") && session instanceof UserSession) {
	    ((UserSession)session).getUserModel().removeAllStateVars("helptopic");
	}


	return retdoc;
    }

    public String provides() {
	return "help";
    }

    public String requires() {
	return "content bar";
    }
} // WebMailHelp
