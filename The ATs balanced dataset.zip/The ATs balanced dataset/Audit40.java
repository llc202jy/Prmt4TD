


package org.jivesoftware.openfire.security;

import org.jivesoftware.database.SequenceManager;
import org.jivesoftware.database.DbConnectionManager;
import org.jivesoftware.util.JiveConstants;
import org.jivesoftware.util.Log;
import org.jivesoftware.util.StringUtils;
import org.jivesoftware.openfire.XMPPServer;

import java.util.List;
import java.util.Date;
import java.util.ArrayList;
import java.sql.*;

/**
 * The default security audit provider stores the logs in a ofSecurityAuditLog table.
 *
 * @author Daniel Henninger
 */
public class DefaultSecurityAuditProvider implements SecurityAuditProvider {

    private static final String LOG_ENTRY =
            "INSERT INTO ofSecurityAuditLog(msgID,username,entryStamp,summary,node,details) VALUES(?,?,?,?,?,?)";
    private static final String GET_EVENTS =
            "SELECT msgID,username,entryStamp,summary,node,details FROM ofSecurityAuditLog";
    private static final String GET_EVENT =
            "SELECT msgID,username,entryStamp,summary,node,details FROM ofSecurityAuditLog WHERE msgID=?";
    private static final String GET_EVENT_COUNT =
            "SELECT COUNT(msgID) FROM ofSecurityAuditLog";

    /**
     * Constructs a new DefaultSecurityAuditProvider
     */
    public DefaultSecurityAuditProvider() {

    }

    /**
     * The default provider logs events into a ofSecurityAuditLog table in the database.
     * @see org.jivesoftware.openfire.security.SecurityAuditProvider#logEvent(String, String, String)
     */
    public void logEvent(String username, String summary, String details) {
        Connection con = null;
        PreparedStatement pstmt = null;
        try {
            long msgID = SequenceManager.nextID(JiveConstants.SECURITY_AUDIT);
            con = DbConnectionManager.getConnection();
            pstmt = con.prepareStatement(LOG_ENTRY);
            pstmt.setLong(1, msgID);
            pstmt.setString(2, username);
            pstmt.setLong(3, new Date().getTime());
            pstmt.setString(4, StringUtils.abbreviate(summary, 250));
            pstmt.setString(5, XMPPServer.getInstance().getServerInfo().getHostname());
            pstmt.setString(6, details);
            pstmt.executeUpdate();
        }
        catch (SQLException e) {
            Log.warn("Error trying to insert a new row in ofSecurityAuditLog: ", e);
        }
        finally {
            DbConnectionManager.closeConnection(pstmt, con);
        }
    }

    /**
     * The default provider retrieves events from a ofSecurityAuditLog table in the database.
     * @see org.jivesoftware.openfire.security.SecurityAuditProvider#getEvents(String, Integer, Integer, java.util.Date, java.util.Date)
     */
    public List<SecurityAuditEvent> getEvents(String username, Integer skipEvents, Integer numEvents, Date startTime, Date endTime) {
        List<SecurityAuditEvent> events = new ArrayList<SecurityAuditEvent>();
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = GET_EVENTS;
        boolean addedOne = false;
        if (username != null) {
            sql += " WHERE username = ?";
            addedOne = true;
        }
        if (startTime != null) {
            if (!addedOne) {
                sql += " WHERE";
            }
            else {
                sql += " AND";
            }
            sql += " entryStamp >= ?";
            addedOne = true;
        }
        if (endTime != null) {
            if (!addedOne) {
                sql += " WHERE";
            }
            else {
                sql += " AND";
            }
            sql += " entryStamp <= ?";
        }
        sql += " ORDER BY entryStamp DESC";
        try {
            con = DbConnectionManager.getConnection();
            pstmt = DbConnectionManager.createScrollablePreparedStatement(con, sql);
            if (skipEvents != null) {
                DbConnectionManager.scrollResultSet(rs, skipEvents);
            }
            if (numEvents != null) {
                DbConnectionManager.setFetchSize(rs, numEvents);
            }
            int i = 1;
            if (username != null) {
                pstmt.setString(i, username);
                i++;
            }
            if (startTime != null) {
                pstmt.setLong(i, startTime.getTime());
                i++;
            }
            if (endTime != null) {
                pstmt.setLong(i, endTime.getTime());
            }
            rs = pstmt.executeQuery();
            int count = 0;
            while (rs.next() && count < numEvents) {
                SecurityAuditEvent event = new SecurityAuditEvent();
                event.setMsgID(rs.getLong(1));
                event.setUsername(rs.getString(2));
                event.setEventStamp(new Date(rs.getLong(3)));
                event.setSummary(rs.getString(4));
                event.setNode(rs.getString(5));
                event.setDetails(rs.getString(6));
                events.add(event);
                count++;
            }
        }
        catch (SQLException e) {
            Log.error(e);
        }
        finally {
            DbConnectionManager.closeConnection(rs, pstmt, con);
        }
        return events;
    }

    /**
     * The default provider retrieves events from a ofSecurityAuditLog table in the database.
     * @see org.jivesoftware.openfire.security.SecurityAuditProvider#getEvent(Integer)
     */
    public SecurityAuditEvent getEvent(Integer msgID) throws EventNotFoundException {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        SecurityAuditEvent event = null;
        try {
            con = DbConnectionManager.getConnection();
            pstmt = con.prepareStatement(GET_EVENT);
            pstmt.setLong(1, msgID);
            rs = pstmt.executeQuery();
            if (!rs.next()) {
                throw new EventNotFoundException();
            }
            event = new SecurityAuditEvent();
            event.setMsgID(rs.getLong(1));
            event.setUsername(rs.getString(2));
            event.setEventStamp(new Date(rs.getLong(3)));
            event.setSummary(rs.getString(4));
            event.setNode(rs.getString(5));
            event.setDetails(rs.getString(6));
        }
        catch (Exception e) {
            throw new EventNotFoundException();
        }
        finally {
            DbConnectionManager.closeConnection(rs, pstmt, con);
        }

        return event;
    }

    /**
     * The default provider counts the number of entries in the ofSecurityAuditLog table.
     * @see org.jivesoftware.openfire.security.SecurityAuditProvider#getEventCount()
     */
    public Integer getEventCount() {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Integer cnt = 0;
        try {
            con = DbConnectionManager.getConnection();
            pstmt = con.prepareStatement(GET_EVENT_COUNT);
            rs = pstmt.executeQuery();
            cnt = rs.getInt(1);
        }
        catch (Exception e) {
            // Hrm.  That should not occur.
            Log.error("Error while looking up number of security audit events: ", e);
        }
        finally {
            DbConnectionManager.closeConnection(rs, pstmt, con);
        }

        return cnt;
    }

    /**
     * The default provider writes logs into a local Openfire database.
     * @see org.jivesoftware.openfire.security.SecurityAuditProvider#isWriteOnly()
     */
    public boolean isWriteOnly() {
        return false;
    }

    /**
     * The default provider uses Openfire's own audit log viewer.
     * @see org.jivesoftware.openfire.security.SecurityAuditProvider#getAuditURL()
     */
    public String getAuditURL() {
        return null;
    }

    /**
     * The default provider logs user events.
     * @see org.jivesoftware.openfire.security.SecurityAuditProvider#blockUserEvents()
     */
    public boolean blockUserEvents() {
        return false;
    }

    /**
     * The default provider logs group events.
     * @see org.jivesoftware.openfire.security.SecurityAuditProvider#blockGroupEvents()
     */
    public boolean blockGroupEvents() {
        return false;
    }

}
package org.jivesoftware.openfire.security;

import org.jivesoftware.util.*;

import java.util.Map;
import java.util.List;
import java.util.Date;

/**
 * The SecurityAuditManager manages the SecurityAuditProvider configured for this server, and provides
 * a proper conduit for making security log entries and looking them up.  Ideally there is no reason
 * for outside classes to interact directly with a provider.
 *
 * The provider can be specified in system properties by adding:
 *
 * <ul>
 * <li><tt>provider.securityAudit.className = my.security.audit.provider</tt></li>
 * </ul>
 *
 * @author Daniel Henninger
 */
public class SecurityAuditManager {

    // Wrap this guy up so we can mock out the SecurityAuditManager class.
    private static class SecurityAuditManagerContainer {
        private static SecurityAuditManager instance = new SecurityAuditManager();
    }

    /**
     * Returns the currently-installed SecurityAuditProvider. <b>Warning:</b> in virtually all
     * cases the security audit provider should not be used directly. Instead, the appropriate
     * methods in SecurityAuditManager should be called. Direct access to the security audit
     * provider is only provided for special-case logic.
     *
     * @return the current SecurityAuditProvider.
     */
    public static SecurityAuditProvider getSecurityAuditProvider() {
        return SecurityAuditManagerContainer.instance.provider;
    }

    /**
     * Returns a singleton instance of SecurityAuditManager.
     *
     * @return a SecurityAuditManager instance.
     */
    public static SecurityAuditManager getInstance() {
        return SecurityAuditManagerContainer.instance;
    }

    private SecurityAuditProvider provider;

    /**
     * Constructs a SecurityAuditManager, setting up the provider, and a listener.
     */
    private SecurityAuditManager() {
        // Load an security audit provider.
        initProvider();

        // Detect when a new security audit provider class is set
        PropertyEventListener propListener = new PropertyEventListener() {
            public void propertySet(String property, Map params) {
                if ("provider.securityAudit.className".equals(property)) {
                    initProvider();
                }
            }

            public void propertyDeleted(String property, Map params) {
                //Ignore
            }

            public void xmlPropertySet(String property, Map params) {
                //Ignore
            }

            public void xmlPropertyDeleted(String property, Map params) {
                //Ignore
            }
        };
        PropertyEventDispatcher.addListener(propListener);
    }

    /**
     * Initializes the server's security audit provider, based on configuration and defaults to
     * DefaultSecurityAuditProvider if the specified provider is not valid or not specified.
     */
    private void initProvider() {
        // Convert XML based provider setup to Database based
        JiveGlobals.migrateProperty("provider.securityAudit.className");

        String className = JiveGlobals.getProperty("provider.securityAudit.className",
                "org.jivesoftware.openfire.security.DefaultSecurityAuditProvider");
        // Check if we need to reset the provider class
        if (provider == null || !className.equals(provider.getClass().getName())) {
            try {
                Class c = ClassUtils.forName(className);
                provider = (SecurityAuditProvider) c.newInstance();
            }
            catch (Exception e) {
                Log.error("Error loading security audit provider: " + className, e);
                provider = new DefaultSecurityAuditProvider();
            }
        }
    }

    /**
     * Records a security event in the audit logs.
     *
     * @param username Username of user who performed the security event.
     * @param summary Short description of the event, similar to a subject.
     * @param details Detailed description of the event, can be null if not desired.
     */
    public void logEvent(String username, String summary, String details) {
        provider.logEvent(username, summary, details);
    }

    /**
     * Retrieves security events that have occurred, filtered by the parameters passed.
     * The events will be in order of most recent to least recent.
     *
     * Any parameters that are left null are to be ignored.  In other words, if username is null,
     * then no specific username is being searched for.
     *
     * @param username Username of user to look up.  Can be null for no username filtering.
     * @param skipEvents Number of events to skip past (typically for paging).  Can be null for first page.
     * @param numEvents Number of events to retrieve.  Can be null for "all" events.
     * @param startTime Oldest date of range of events to retrieve.  Can be null for forever.
     * @param endTime Most recent date of range of events to retrieve.  Can be null for "now".
     * @return Array of security events.
     * @throws AuditWriteOnlyException if provider can not be read from.
     */
    public List<SecurityAuditEvent> getEvents(String username, Integer skipEvents, Integer numEvents, Date startTime, Date endTime) throws AuditWriteOnlyException {
        if (provider.isWriteOnly()) {
            throw new AuditWriteOnlyException();
        }
        return provider.getEvents(username, skipEvents, numEvents, startTime, endTime);
    }

    /**
     * Retrieves a specific event by ID in the form of a SecurityAuditEvent.
     *
     * @param msgID ID number of event to retrieve.
     * @return SecurityAuditEvent object with information from retrieved event.
     * @throws EventNotFoundException if event was not found.
     * @throws AuditWriteOnlyException if provider can not be read from.
     */
    public SecurityAuditEvent getEvent(Integer msgID) throws EventNotFoundException, AuditWriteOnlyException {
        if (provider.isWriteOnly()) {
            throw new AuditWriteOnlyException();
        }
        return provider.getEvent(msgID);
    }

}
