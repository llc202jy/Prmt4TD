package de.x4technology.hibernate;

import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;
import net.sf.hibernate.dialect.Dialect;
import net.sf.hibernate.tool.hbm2ddl.SchemaExport;
import net.sf.hibernate.tool.hbm2ddl.SchemaUpdate;
import de.x4technology.helper.lang.ExceptionHelper;
import de.x4technology.helper.reflect.ReflectionHelper;

/**
 * @author uwe
 */
public final class HibernateConfigurationFactory
{

    private static HibernateConfigurationFactory instance = null;

    public static final HibernateConfigurationFactory getInstance()
    {
        if (instance == null) throw new IllegalArgumentException("use init(configFilename) first.");
        return instance;
    }

    /**
     * @deprecated use init(PackageSummaryCollector c, Properties p)
     * @param cfgFileName
     */
    public static final void init(String cfgFileName)
    {
        instance = new HibernateConfigurationFactory(cfgFileName);
    }

    private HibernateConfigurationFactory(String hibernateConfigFile)
    {
        if (hibernateConfigFile == null) throw new NullPointerException("hibernateConfigFile");

        URL url = this.getClass().getResource(hibernateConfigFile);

        if (url == null) throw new IllegalArgumentException("cannot find " + hibernateConfigFile);

        configuration = HibernateHelper.createConfiguration(url);
        try
        {
            sessionFactory = configuration.buildSessionFactory();
        }
        catch (HibernateException e)
        {
            throw new PersistenceLayerException(ExceptionHelper.dump(e));
        }
    }

    private HibernateConfigurationFactory(PackageSummaryCollector c, Properties p)
    {
        if (p == null) throw new NullPointerException("p");
        if (c == null) throw new NullPointerException("c");
        try
        {
            configuration = new Configuration();
            c.addClasses(configuration);
            configuration.setProperties(p);
            sessionFactory = configuration.buildSessionFactory();
        }
        catch (HibernateException e)
        {
            throw new PersistenceLayerException(ExceptionHelper.dump(e));
        }
    }
    private final Configuration configuration;

    private final SessionFactory sessionFactory;

    /**
     * @return Returns the configuration.
     */
    public Configuration getConfiguration()
    {
        return configuration;
    }

    public SessionFactory getSessionFactory()
    {
        return sessionFactory;
    }

    /**
     *  
     */
    public void exportSchema()
    {
        exportSchema(true);
    }

    public void exportSchema(boolean useInnoDBTables)
    {
        try
        {

            SchemaExport schemaExport = new SchemaExport(configuration);
            schemaExport.drop(true, true);
            Session s = configuration.buildSessionFactory().openSession();
            try
            {
                if (useInnoDBTables)
                {
                    PreparedStatement p = s.connection().prepareStatement("SET GLOBAL table_type=InnoDB;");
                    p.execute();
                }
                SchemaUpdate schemaUpdate = new SchemaUpdate(configuration);
                schemaUpdate.execute(true, true);
                if (useInnoDBTables)
                {
                    PreparedStatement p = s.connection().prepareStatement("SET GLOBAL table_type=MyISAM;");
                    p.execute();
                }

            }
            catch (SQLException e1)
            {
                throw new RuntimeException(e1);
            }
            finally
            {
                try
                {
                    if (s != null) s.close();
                }
                catch (Exception ignore)
                {
                }
            }

            // DEBUG CODE
            //
            //            try
            //            {
            //                SessionFactory sessionFactory = getConfiguration().buildSessionFactory();
            //                Session openSession = sessionFactory.openSession();
            //                Connection connection = openSession.connection();
            //                MySQLDialect dia = new MySQLDialect();
            //                DatabaseMetadata dbMeta = new DatabaseMetadata(connection, dia);
            //
            //                TableMetadata tableMetadata = dbMeta.getTableMetadata("_account");
            //
            //                String[] generateSchemaUpdateScript = getConfiguration().generateSchemaUpdateScript(dia, dbMeta);
            //                tlog().debug("generatorscript: ");
            //                for (int i = 0; i < generateSchemaUpdateScript.length; i++)
            //                {
            //                    String string = generateSchemaUpdateScript[i];
            //                    tlog().debug(string);
            //                }
            //            }
            //            catch (Exception e)
            //            {
            //                throw new RuntimeException(ExceptionHelper.dump(e));
            //            }

        }
        catch (HibernateException e)
        {
            throw new PersistenceLayerException(ExceptionHelper.dump(e));
        }

    }

    public void updateSchema()
    {
        try
        {
            new SchemaUpdate(configuration).execute(true, true);
        }
        catch (HibernateException e)
        {
            throw new PersistenceLayerException(ExceptionHelper.dump(e));
        }

    }

    /**
     * @param c
     * @param p
     */
    public static void init(PackageSummaryCollector c, Properties p)
    {
        instance = new HibernateConfigurationFactory(c, p);
    }

    /**
     * @return
     */
    public Dialect getDialect()
    {

        String dialectString = configuration.getProperty(PROPERTY_DIALECT);
        if (dialectString == null)
            throw new RuntimeException("Expected configuration-property named '" + PROPERTY_DIALECT
                    + "' in hibernate config.");

        return (Dialect) ReflectionHelper.createInstance(dialectString);

    }

    private static final String PROPERTY_DIALECT = "hibernate.dialect";

}
package de.x4technology.component.callback.convenience;

import de.x4technology.component.Priority;
import de.x4technology.component.callback.ServiceComponent;

/**
 * Implementation template for simple ServiceComponents with LifeCycle-Support.
 * 
 * @author uwe
 */
public abstract class AbstractServiceComponent implements ServiceComponent
{

    public boolean isStarted()
    {
        return this.started;
    }

    private boolean started;

    /*
     * 
     */
    public final boolean start()
    {
        if (this.started)
        {
            throw new IllegalStateException("Service already started.");
        }

        if (!checkPreconditions())
        {
            return false;
        }

        this.started = doStart();
        return this.started;
    }

    /**
     * @return true if preconditions are met
     */
    protected boolean checkPreconditions()
    {
        return true;
    }

    /**
     * @return true if start was successful
     */
    protected abstract boolean doStart();

    /*
     * 
     */
    public final void stop()
    {
        if (!this.started)
        {
            throw new IllegalStateException("Service not yet started.");
        }
        doStop();
        this.started = false;
    }

    /**
     * 
     */
    protected void doStop()
    {

    }

    /**
     * @return Priority level for init/start
     * 
     */
    public Priority getPriority()
    {
        return Priority.DONT_CARE;
    }

}
package de.x4technology.mail;

import java.text.MessageFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.Message.RecipientType;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import de.x4technology.component.Priority;
import de.x4technology.component.callback.ServiceComponent;
import de.x4technology.helper.Assert;
import de.x4technology.helper.lang.ExceptionHelper;
import de.x4technology.helper.lang.StringHelper;
import de.x4technology.mail.descriptor.MailAttachmentDescriptor;
import de.x4technology.mail.exception.SendMailException;

/**
 * @author Ingo
 */
public class MailService implements ServiceComponent
{
    public static final String COMPONENT_ID = "MailService";
    private String defaultFrom = "dont_answer@domain.tld";
    private String smtpServer;
    private String mailFooter = ""; // "\n\n\n-----------------------------------------------------------\n(c){0}
                                    // Image Transfer
                                    // GmbH\nhttp://www.x4technology.de";
    private static final String VERSION = "1.0";
    private static final int NUMBEROFTRIESBEFOREGIVINGUP = 3;
    private String encoding = "UTF-8";
    private String debugEmail;

    public void setDebugEmail(String debugEmail)
    {
        Assert.isNotNull(debugEmail);
        this.debugEmail = debugEmail;
    }

    public boolean start()
    {
        validate();

        if (isDebug())
        {
            log().warn(
                    "MailService is configured for DEBUG MODE, all mails will be sent to '" + this.debugEmail
                            + "' not to their real recipients.");
        }

        return true;
    }

    private void validate()
    {
        MailHelper.validateEmailAddress(this.defaultFrom);
        if (isDebug())
        {
            MailHelper.validateEmailAddress(this.debugEmail);
        }
    }

    public boolean isStarted()
    {
        return true;
    }

    public void stop()
    {
        // Nothing to do
    }

    public Priority getPriority()
    {
        return Priority.DONT_CARE;
    }

    /**
     * Creates a mail with a default from-address
     * 
     * @return
     */
    public Mail createMail()
    {
        Mail mail = new Mail();
        mail.setFrom(getDefaultFrom());
        return mail;
    }

    public void send(Mail mail) throws SendMailException
    {
        int count = NUMBEROFTRIESBEFOREGIVINGUP;
        for (;;)
        {
            try
            {
                doSend(mail);
                return;
            }
            catch (MessagingException me)
            {
                if (--count <= 0)
                {
                    log().error(ExceptionHelper.dump(me));
                    // TODO refine error codes
                    throw new SendMailException(MailErrorCodes.ERRORCODE_ERROR, me);
                }

                // wait a little... maybe mail server will serve our request in
                // some seconds
                try
                {
                    Thread.sleep(1000);
                }
                catch (InterruptedException e)
                {
                    // ignore
                }
            }
        }
    }

    private void doSend(Mail mail) throws MessagingException
    {
        Assert.isNotNull(mail);
        MailHelper.validate(mail);

        Properties properties = System.getProperties();
        properties.put("mail.smtp.host", this.smtpServer);
        Session session = Session.getInstance(properties, null);

        MimeMessage message = new MimeMessage(session);
        prepareHeader(message, mail);

        message.setFrom(new InternetAddress(mail.getFrom()));
        setReplyTo(message, mail.getReplyTo());

        if (isDebug())
        {
            message.setRecipient(Message.RecipientType.TO, new InternetAddress(this.debugEmail));
        }
        else
        {
            addRecipients(message, Message.RecipientType.TO, mail.getTo());
            addRecipients(message, Message.RecipientType.CC, mail.getCc());
            addRecipients(message, Message.RecipientType.BCC, mail.getBcc());
        }

        String subject = prepareSubject(mail);
        message.setSubject(subject);

        String mailMessage = prepareMessage(mail);
        if (!mail.hasAttachments())
        {
            message.setText(mailMessage, getEncoding());
        }
        else
        {
            MimeBodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.addHeader("Content-Type", "text/plain; charset=" + getEncoding());
            messageBodyPart.addHeader("Content-Transfer-Encoding", "quoted-printable");
            messageBodyPart.setText(mailMessage, getEncoding());

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);

            List att = mail.getAttachments();
            for (Iterator i = att.iterator(); i.hasNext();)
            {
                MailAttachmentDescriptor attachment = (MailAttachmentDescriptor) i.next();
                messageBodyPart = new MimeBodyPart();
                DataSource source = attachment.getDataSource();
                messageBodyPart.setDataHandler(new DataHandler(source));
                messageBodyPart.setFileName(attachment.getFilenameInMail());
                multipart.addBodyPart(messageBodyPart);
            }

            message.setContent(multipart);
        }

        Transport.send(message);
    }

    private String prepareSubject(Mail mail)
    {
        String subject = mail.getSubject();
        if (isDebug())
        {
            subject = (subject == null) ? "[debug]" : subject + " [debug]";
        }
        return subject;
    }

    private String prepareMessage(Mail mail)
    {
        String mailMessage = mail.getMessage();
        if (isDebug())
        {
            mailMessage = addDebugInfo(mail, mailMessage);
        }
        mailMessage = appendFooter(mailMessage);
        return mailMessage;
    }

    private void prepareHeader(MimeMessage message, Mail mail) throws MessagingException
    {
        message.addHeader("X-Mailer", "X4MailService " + VERSION + " (http://www.x4technology.de)");
        message.setSentDate(new java.util.Date());

        if (!mail.hasAttachments())
        {
            message.addHeader("Content-Type", "text/plain; charset=" + getEncoding());
            message.addHeader("Content-Transfer-Encoding", "quoted-printable");
        }

        for (Iterator i = mail.getHeaders().entrySet().iterator(); i.hasNext();)
        {
            Map.Entry entry = (Map.Entry) i.next();
            message.addHeader((String) entry.getKey(), (String) entry.getValue());
        }
    }

    private void setReplyTo(MimeMessage message, List replyTo) throws MessagingException
    {
        if (replyTo.isEmpty())
        {
            return;
        }

        Address[] arr = new Address[replyTo.size()];
        int count = 0;
        for (Iterator i = replyTo.iterator(); i.hasNext();)
        {
            String email = (String) i.next();
            arr[count++] = new InternetAddress(email);
        }

        message.setReplyTo(arr);
    }

    private String addDebugInfo(Mail mail, String mailMessage)
    {
        StringBuffer sb = new StringBuffer(mailMessage.length() + 256);

        sb.append("Real mail would have been sent using the following data:");
        if (!mail.getTo().isEmpty())
        {
            sb.append("\n\nTo:\n");
            sb.append(StringHelper.indent(formatList(mail.getTo()), 2));
        }
        if (!mail.getCc().isEmpty())
        {
            sb.append("\n\nCC:\n");
            sb.append(StringHelper.indent(formatList(mail.getCc()), 2));
        }
        if (!mail.getBcc().isEmpty())
        {
            sb.append("\n\nBCC:\n");
            sb.append(StringHelper.indent(formatList(mail.getBcc()), 2));
        }
        sb.append("\n\n------------------ Mailtext follows -----------------------\n\n");

        sb.append(mailMessage);

        return sb.toString();
    }

    private String formatList(List listOfStrings)
    {
        StringBuffer sb = new StringBuffer();

        for (Iterator i = listOfStrings.iterator(); i.hasNext();)
        {
            String s = (String) i.next();
            sb.append(s);
            if (i.hasNext())
            {
                sb.append("\n");
            }
        }

        return sb.toString();
    }

    private void addRecipients(MimeMessage message, RecipientType type, List recipientEmails) throws MessagingException
    {
        for (Iterator i = recipientEmails.iterator(); i.hasNext();)
        {
            String email = (String) i.next();
            message.addRecipient(type, new InternetAddress(email));
        }
    }

    private boolean isDebug()
    {
        return StringHelper.hasAtLeastOneCharacter(this.debugEmail);
    }

    private String appendFooter(String message)
    {
        int fromYear = 2005;
        int untilYear = Calendar.getInstance().get(Calendar.YEAR);

        String copyrightYear = String.valueOf(fromYear);
        if (fromYear < untilYear)
        {
            copyrightYear += "-" + untilYear;
        }
        String footer = MessageFormat.format(this.mailFooter, new Object[] { copyrightYear });

        return message + footer;
    }
