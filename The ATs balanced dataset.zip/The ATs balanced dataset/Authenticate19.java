    import java.util.Map;   
      
    /**  
     
    *  
     
    * @author udayaprasad.vakalapudi  
     
    */   
      
    public class Main {   
      
    /**  
     
    * @param args the command line arguments  
     
    */   
      
    public static void main(String[] args) {   
      
    // TODO code application logic here   
      
    ADAuthenticator authenticator = new ADAuthenticator();   
      
    Map userMap = null;   
      
    try {   
      
    userMap = authenticator.authenticate("udayaprasad.vakalapu",   
    "PASSWORD");   
      
    } catch (Exception x) {   
      
    System.out.println(x.getMessage());   
      
    }   
      
    if (userMap != null) {   
      
    System.out.println("User Authenticated Successfully");   
      
    System.out.println("Generating token for the authenticated user("   
    + userMap.get("givenName") + ")...");   
      
    System.out.println("Token generated: "   
    + authenticator.generateToken());   
      
    }   
      
    else {   
      
    System.out.println("User Authentication Failed! Incorrect Username/Password!");   
      
    }   
      
    }   
      
    }  




view plaincopy to clipboardprint?
Note: Text content in the code blocks is automatically word-wrapped

    2) ADAuthenticator.java   
      
      
      
      
      
    import java.util.HashMap;   
      
    import java.util.Hashtable;   
      
    import java.util.Map;   
      
    import java.util.UUID;   
      
    import javax.naming.Context;   
      
    import javax.naming.NamingEnumeration;   
      
    import javax.naming.NamingException;   
      
    import javax.naming.directory.Attribute;   
      
    import javax.naming.directory.Attributes;   
      
    import javax.naming.directory.SearchControls;   
      
    import javax.naming.directory.SearchResult;   
      
    import javax.naming.ldap.InitialLdapContext;   
      
    import javax.naming.ldap.LdapContext;   
      
    /**  
     
    *  
     
    * @author niranjan.vaidya  
     
    */   
      
    public class ADAuthenticator {   
      
    private String domain;   
      
    private String ldapHost;   
      
    private String searchBase;   
      
    public ADAuthenticator() {   
      
    this.domain = "companyname.in";   
      
    this.ldapHost = "ldap://IPADDRESS";   
      
    this.searchBase = "dc=bajajallianz,dc=in";   
      
    }   
      
    public ADAuthenticator(String domain, String host, String dn) {   
      
    this.domain = domain;   
      
    this.ldapHost = host;   
      
    this.searchBase = dn;   
      
    }   
      
    public Map authenticate(String user, String pass) {   
      
    String returnedAtts[] = { "sn", "givenName", "mail" };   
      
    String searchFilter = "(&(objectClass=user)(sAMAccountName=" + user   
    + "))";   
      
    //Create the search controls   
      
    SearchControls searchCtls = new SearchControls();   
      
    searchCtls.setReturningAttributes(returnedAtts);   
      
    //Specify the search scope   
      
    searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);   
      
    Hashtable env = new Hashtable();   
      
    env.put(Context.INITIAL_CONTEXT_FACTORY,   
    "com.sun.jndi.ldap.LdapCtxFactory");   
      
    env.put(Context.PROVIDER_URL, ldapHost);   
      
    env.put(Context.SECURITY_AUTHENTICATION, "simple");   
      
    env.put(Context.SECURITY_PRINCIPAL, user + "@" + domain);   
      
    env.put(Context.SECURITY_CREDENTIALS, pass);   
      
    LdapContext ctxGC = null;   
      
    try {   
      
    ctxGC = new InitialLdapContext(env, null);   
      
    //Search objects in GC using filters   
      
    NamingEnumeration answer = ctxGC.search(searchBase, searchFilter,   
    searchCtls);   
      
    while (answer.hasMoreElements()) {   
      
    SearchResult sr = (SearchResult) answer.next();   
      
    Attributes attrs = sr.getAttributes();   
      
    Map amap = null;   
      
    if (attrs != null) {   
      
    amap = new HashMap();   
      
    NamingEnumeration ne = attrs.getAll();   
      
    while (ne.hasMore()) {   
      
    Attribute attr = (Attribute) ne.next();   
      
    amap.put(attr.getID(), attr.get());   
      
    // System.out.println("attr.getID()" + attr.getID());   
      
    // System.out.println("attr.get()" + attr.get());   
      
    }   
      
    ne.close();   
      
    }   
      
    return amap;   
      
    }   
      
    } catch (NamingException ex) {   
      
    System.out.println(ex.getMessage());   
      
    }   
      
    return null;   
      
    }   
      
    public String generateToken() {   
      
    return UUID.randomUUID().toString();   
      
    }   
      
    }   