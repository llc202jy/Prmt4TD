public class Unrelated10{
   public String getTitle(HttpServletRequest request, Object command) {
        if (command instanceof Base) {
            String name = ((Base)command).getName();            
            if (OAStringUtil.hasLength(name))
                return ((Base)command).getTypeName() + " [" + OAStringUtil.dotifyMedium(name) + "]";
            return ((Base)command).getTypeName();
        }
        return null;
    }    	
    
    public boolean hasBrowse(HttpServletRequest request) {
    	return true;
    }

	protected void getModel(Map model, HttpServletRequest request, Object command) throws Exception {
		if (command instanceof BaseConcrete) {
			Integer myId = new Integer(0);
			if (isEditing(request))
				myId = new Integer(request.getParameter(OAFormConsts.GET_EDIT));

			if (hasBrowse(request)) {
				model.put("_prevID", OADomainUtil.getPrevId(OAClassUtil.getPersistentClass(command), myId));
				model.put("_nextID", OADomainUtil.getNextId(OAClassUtil.getPersistentClass(command), myId));
			}
		}
		
		model.put("m_isCommandSaved", new Boolean(OABeanUtil.getId(command) != null));		

		super.getModel(model, request, command);
	}
	
	
	protected void onBind(HttpServletRequest request, Object command,
			BindException errors) throws Exception {
		// update any calculated properties (eg. totals)
		if (command instanceof BaseConcrete)
			OADomainUtil.updateCalculatedProperties(command);	
		
        // handle a change status request
        if (WebUtils.hasSubmitParameter(request, OAFormConsts.POST_CHANGE_STATUS)) {
	        int newStatus = RequestUtils.getIntParameter(request, OAFormConsts.CHANGE_STATUS_NEW_STATUS, -1);
	        if (newStatus >= 0)
	        	onSetStatus(command, new Integer(newStatus));
        }	
        
        // handle a change property request (eg. change customer in sales order)
        String propertyChange = RequestUtils.getStringParameter(request, OAFormConsts.POST_SUBMIT_PROPERTY_CHANGE, null);
        if (propertyChange != null)
        	OADomainUtil.handlePropertyChange(command, propertyChange);
		
		super.onBind(request, command, errors);
	}	

	/**
	 * Return the id if editing, viewing, deleting, printing or viewing history
	 * @param request HTTP Parameters
	 * @return  Request id for action
	 */
	protected int getRequestId(HttpServletRequest request) {
        int id = RequestUtils.getIntParameter(request, OAFormConsts.GET_EDIT, 0);
        if (id == 0)
            id = RequestUtils.getIntParameter(request, OAFormConsts.GET_VIEW, 0);            
        if (id == 0)
            id = RequestUtils.getIntParameter(request, OAFormConsts.GET_DELETE, 0);
        if (id == 0)
            id = RequestUtils.getIntParameter(request, OAFormConsts.GET_PRINT, 0);     
        if (id == 0)
            id = RequestUtils.getIntParameter(request, OAFormConsts.GET_HISTORY, 0);   
        return id;
	}
	
	/**
	 * Return the string name to use for session-stored command. Base this on the id being edited otherwise can't edit the same object
	 * more than once on the same client
	 */
	protected String getFormSessionAttributeName(HttpServletRequest request) {
		return getFormSessionAttributeName() + getRequestId(request);
	}
	
    protected Object formBackingObject(HttpServletRequest request) throws Exception {
        if (getCommandClass() != null && BaseConcrete.class.isAssignableFrom(getCommandClass())) {
        	int id = getRequestId(request);
            if (id > 0) {
                Object obj = OADomainUtil.getById(getCommandClass(), new Integer(id));
                // formBackingObject should never return null
                // retreival can fail if the url is edited manually and an invalid id is entered
                if (obj == null)
                    throw new IllegalArgumentException("Invalid identifier (" + id + ") sent to edit page.");
                return obj;
            }
        }
        
        return super.formBackingObject(request);
    }   	

    /**
     * Handle save command.
     */
   protected void onSave(Object command, HttpServletRequest request) {
		if (command instanceof BaseConcrete)
			OADomainUtil.add(command);
	}

	/**
	 * Handle update command.
	 */
   protected void onUpdate(Object command, HttpServletRequest request) {
		if (command instanceof BaseConcrete)
			OADomainUtil.update(command);
	}

   /**
    * Handle delete command.
    */
	protected void onDelete(Object command) {
		if (command instanceof BaseConcrete)
			OADomainUtil.remove(command);
	}
	
	/**
	 * Handle change status command
	 * @param command Command object
	 * @param newStatus New status changing to
	 */
    protected void onSetStatus(Object command, Integer newStatus)  {
    	OADomainUtil.setStatus(command, newStatus);
    }   	
    
    protected ModelAndView onSubmit(HttpServletRequest request,	HttpServletResponse response, Object command, BindException errors)
			throws Exception {
		try {
			super.onSubmit(request, response, command, errors);
		} catch (Exception e) {
			if (handleDomainException(e, errors)) {
				return showForm(request, response, errors);
			} else
				throw e;
		}

		return onSuccess(request, command);
	}      
    
    protected boolean handleDomainException(Exception ex, BindException errors) {
        while (ex instanceof OAJNestedException)
            ex = (Exception)((Throwable)ex).getCause();
        
        if (ex instanceof DataIntegrityViolationException) {
            errors.reject("DATA_INTEGRITY", GetText.get("The entry already exists. Please enter a unique entry."));
            return true;
        }
        
        if (ex instanceof OAJValidationException) {
            return handleDomainValidationException((OAJValidationException)ex, errors);            
        }
        
        return false;
    }    
    
    protected boolean handleDomainValidationException(OAJValidationException ex, BindException errors) {
        if (ex.getField() != null)
            errors.rejectValue(ex.getField(), ex.getMessageCode(), ex.getMessage());
        else
            errors.reject(ex.getMessageCode(), ex.getMessage());
        return true;      	
    }

	protected ModelAndView getReturnSuccessView(HttpServletRequest request,	Object command, boolean successEdit) {
        
		// check for "save and new"
        if (request.getParameter(OAFormConsts.POST_SUBMIT_MORE) != null)
            return new ModelAndView(new RedirectView(getViewResolver().getNewView()));   
        
        // check for "save and stay"
        if (request.getParameter(OAFormConsts.POST_SUBMIT_STAY) != null) {
        	ModelAndView mv = new ModelAndView(new RedirectView(getViewResolver().getNewView()));
        	if (OABeanUtil.hasProperty(command, OABeanUtil.ID_FIELD)) {
	        	Integer id = (Integer)OABeanUtil.getId(command);
	        	if (id != null)
	        		mv.addObject(OAFormConsts.GET_EDIT, id);
	        	
	        	String returnPage = RequestUtils.getStringParameter(request, OAFormConsts.GET_RETURN_PAGE, null);
	            if (returnPage != null) {
	            	mv.addObject(OAFormConsts.GET_RETURN_PAGE, returnPage);
	            	
	            	int returnID = RequestUtils.getIntParameter(request, OAFormConsts.GET_RETURN_ID, 0);
	                if (returnID > 0)
	                    mv.addObject(OAFormConsts.GET_RETURN_ID, new Integer(returnID));	            	
	            }
        	}
        	return mv;
        }
        
        // check for "open"
        if (isOpening(request)) {
        	ModelAndView mv = new ModelAndView(new RedirectView(getViewResolver().getNewView()));
            Integer foundID = OADomainUtil.getByRefLike(getCommandClass(), request.getParameter(OABeanUtil.REF_FIELD));
            if (foundID != null && foundID.intValue() > 0)
                mv.addObject(OAFormConsts.GET_EDIT, foundID);       	
        	return mv;
        }
        
		return super.getReturnSuccessView(request, command, successEdit);
	}
}
