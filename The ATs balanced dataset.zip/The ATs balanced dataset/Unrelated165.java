*
 * $Id: Kernel.c,v 1.3 2001/01/07 08:37:16 chipx86 Exp $
 *
 * Copyright (C) 1998-2001, Freedows
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <kmalloc.h>

#include <freedows/OSKernel.h>
#include <freedows/ArchKernel.h>

OSKernel *
osk_create()
{
	OSKernel *kernel;

	kernel = (OSKernel *)kmalloc(sizeof(OSKernel));
	memset(kernel, 0, sizeof(OSKernel));
	
	if (kernel == NULL)
	{
		kprintf("OSKernel == NULL!\n");
		return NULL;
	}
	
	kernel->kernel_type = OS_KERNEL;
	kernel->kid         = -1;

	kernel->init           = osk_stub_init;
	kernel->destroy        = osk_stub_destroy;
	kernel->get_identifier = osk_stub_get_identifier;
	kernel->exec_bytecode  = osk_stub_exec_bytecode;

	return kernel;
}

void
osk_destroy(OSKernel *kernel)
{
	if (kernel == NULL)
		return;

	kfree(kernel);
}

ArchKernel *
archk_create(void)
{
	ArchKernel *kernel;

	kernel = (ArchKernel *)kmalloc(sizeof(ArchKernel));
	memset(kernel, 0, sizeof(ArchKernel));
	
	if (kernel == NULL)
	{
		kprintf("ArchKernel == NULL!\n");
		return NULL;
	}
	
	kernel->kernel_type = ARCH_KERNEL;
	kernel->kid         = -1;

	kernel->init           = archk_stub_init;
	kernel->destroy        = archk_stub_destroy;
	kernel->get_identifier = archk_stub_get_identifier;
	kernel->exec_bytecode  = archk_stub_exec_bytecode;
	kernel->exec           = archk_stub_exec;

	return kernel;
}

void
archk_destroy(ArchKernel *kernel)
{
	if (kernel == NULL)
		return;

	kfree(kernel);
}

/* Stubs */

void
osk_stub_init(OSKernel *kernel)
{
}

void
osk_stub_destroy(OSKernel *kernel)
{
}

char *
osk_stub_get_identifier(OSKernel *kernel)
{
	return strdup("");
}

void
osk_stub_exec_bytecode(OSKernel *kernel, Process *process, char bytecode)
{
}

void
archk_stub_init(ArchKernel *kernel)
{
}

void
archk_stub_destroy(ArchKernel *kernel)
{
}


char *
archk_stub_get_identifier(ArchKernel *kernel)
{
	return strdup("");
}

void
archk_stub_exec_bytecode(ArchKernel *kernel, Process *process, char bytecode)
{
}


void
archk_stub_exec(ArchKernel *kernel, char *filename)

#include <sys/desc.h>
#include <sys/mem.h>
#include <sys/io.h>
#include <string.h>
#include <kprintf.h>
#include <multiboot.h>

#define KTSS_SEL 0x28 /* Move this! */

#define GDT_DESCRIPTOR_COUNT 1024
#define LDT_DESCRIPTOR_COUNT 1024
#define IDT_DESCRIPTOR_COUNT  256

extern unsigned int kernel_stack;

unsigned long kernel_base;      /**< Physical base address of kernel. */
TSS kernel_tss;                 /**< TSS for the main kernel task.    */

/**
 * Interrupt Descriptor Table (IDT)
 * 
 * Filled during kernel initialization.
 */
gate_descriptor idt[IDT_DESCRIPTOR_COUNT] =
{
};

/**
 * Local Descriptor Table (LDT)
 *
 * Filled during kernel initialization.
 */
sys_descriptor ldt[LDT_DESCRIPTOR_COUNT] =
{
};

/**
 * Global Descriptor Table (GDT)
 */

/*
 * Kernel page dir and table
 */
unsigned long pd[NPTE] = {0};
unsigned long pt[NPTE] = {0};

TSS ktss;

static bool __inline__
is_descriptor_local(unsigned short selector)
{
	return ((selector & 0x04) ? true : false);
}

bool
build_descriptor(unsigned short selector, unsigned int base,
				 unsigned int limit, unsigned short type)
{
	if (is_descriptor_local(selector))
		return build_ldt_descriptor(selector >> 3, base, limit, type);
	else
		return build_gdt_descriptor(selector >> 3, base, limit, type);
}

bool
build_gdt_descriptor(unsigned short num, unsigned int base,
					 unsigned int limit, unsigned short type)
{
	sys_descriptor *desc = &gdt[num];
	
	if (type & 0x0800)          /* If segment is page granular:            */
		limit >>= 12;           /*   Calculate number of pages from limit. */
	else                        /* If it is byte granular:                 */
		if (limit >= 0x100000)  /*   Is limit greater than 1MB?            */
			return false;       /*     Yes. Return with error.             */

	desc->limit_low = (unsigned short)limit;
	desc->gav_limit = (unsigned short)(limit >> 16) | ((type >> 4) & 0xF0);
	desc->base_low  = (unsigned short)base;
	desc->base_med  = (unsigned char)(base >> 16);
	desc->base_high = (unsigned char)(base >> 24);
	desc->dpl_type  = (unsigned char)type;

	return true;
}

void
kmain(char *real_mem_base, int kernel_size, char *init_script,
	  int init_script_size)
{
	long flags;
	int num;

	desc_init();

	setup_consoles();

//	kernel_size = (kernel_size + PAGE_SIZE - 1) & PAGE_MASK;
	
	kprintf("kernel_size = 0x%X (%d), mem_size = 0x%X (%d)\n",
			kernel_size, kernel_size, mem_size, mem_size);

	kprintf("Calling kmem_init()\n");
	kmem_init();
	
	/* Load the rest of the drivers */
	kprintf("Loading drivers...\n");
	init_drivers();

	/* Start Fred */
	kprintf("creating fred_main task\n");
	create_kernel_task(test_task_1, -5);
	create_kernel_task(test_task_2, -5);
//	create_kernel_task(fred_main, -5);
//	fred_main();

	while(1)
	{
#if 0
		save_flags(flags);
		cli();
//
		dump_task_statistic();

		console_set_xy(0, 23);
		kprintf("Enter Idle : %08X", ++num);
		
		restore_flags(flags);
#endif
//		__asm__ __volatile__ ("hlt");
	}
}