  include_once("AuthenticateUser.inc");

  //////////////////////////////////////////////////////////////////////

  class AuthenticateUser extends AuthenticateBase
  {
    var $sPackageAndClassName = "AuthenticateUser";

    ///////////////////////////////////////////////////////////////////////////

    function AuthenticateUser($lp = "username", $pw = "password", $pages = array(), $debug = 0)
    {
      # Superclass constructor.
      $this->AuthenticateBase($lp, $pw, $pages, $debug);
    }

    ///////////////////////////////////////////////////////////////////////////

    function connectToDB($db = "EIS", $configg, $dbug = 0)
    {
      if($this->debug >= 4) {
        print("dbug: $dbug<br>\n");
        print("db: $db<br>\n");
        print("configg: $configg<br>\n");
      }

	  if($dbug == 0) {
	    $dbug = "0";
	  }
	  
      $sss = "\$temp =  new " . $this->config->getAttribute("DatabaseDriver") . "(\$configg, \$db, $dbug);";

      if($this->debug >= 2) {
        print("sss: $sss<br>\n");
      }

      eval ($sss);

      if($this->debug >= 2) {
        print ("temp: $temp<br>\n");
      }

      return $temp;
    }

    ///////////////////////////////////////////////////////////////////////////

    function authenticate($applicationName, $thepersonid = 0)
    {
      if($this->debug) {
        print("In authenticate: $applicationName, $thepersonid<br>\n");
      }

      $configg = new ConfigFileReader($applicationName);

      $this->debug = ($this->debug == 0 ? $configg->getAttribute("DebugLevel") : $this->debug);

      $results = array();

      if($this->debug) {
        print("thepersonid: $thepersonid<br>\n");
      }

      if($thepersonid == 0) {
        # If we don't have the username and password, we should just
        # give up and go home.
        $username = $_REQUEST[$this->usernameField];
        $password = $_REQUEST[$this->passwordField];

        if($this->debug >= 4) {
          print("user: $username, password: $password<br>\n");
        }

        $this->got_UP();
      }

      $dbh = $this->connectToDB($configg->getAttribute("SecDB"), $configg, $this->debug);

      if($configg->getAttribute("SecDB") == $configg->getAttribute("NameDB")) {
        $dbi = $dbh;
      } else {
        $dbi = $this->connectToDB($configg->getAttribute("NameDB"), $configg, $this->debug);
      }


      if ($thepersonid) {
        $results = $dbh->Select(
            $configg->getAttribute("SecID"). "," .  $configg->getAttribute("SecLevel"),
            $configg->getAttribute("SecTable"),
            ($configg->getAttribute("SecAppName") != "" ? "upper('" . $configg->getAttribute("SecAppName") . "') = upper('$applicationName') AND " : "") . $configg->getAttribute("SecID") . " = $thepersonid");

        $resduex = $dbi->Select(
            $configg->getAttribute("NameFirst") . ", " . $configg->getAttribute("NameLast"),
            $configg->getAttribute("NameTable"),
            $configg->getAttribute("NameID") . " = $thepersonid");

        $results = array_merge($results,$resduex);

      } else {
        # If we don't have the username and password, we should just
        # give up and go home.
        $username = $_REQUEST[$this->usernameField];
        $password = $_REQUEST[$this->passwordField];

        if($this->debug) {
          print("Before<br>\n");
          flush();
        }

        $results = $dbh->Select(
            $configg->getAttribute("SecID"). "," .  $configg->getAttribute("SecLevel"),
            $configg->getAttribute("SecTable"),
            ($configg->getAttribute("SecAppName") != "" ? "upper('" . $configg->getAttribute("SecAppName") . "') = upper('$applicationName') AND " : "") .
            ($configg->getAttribute("SecAppID") != "" ? $configg->getAttribute("SecAppID") . " = (select id from application where upper(name) = upper('$applicationName')) AND " : "") .
            "upper(" . $configg->getAttribute("SecUsername") . ") = upper('" . $username . "') AND upper(" . $configg->getAttribute("SecPassword") . ") = upper('" . $password . "')");

        if(!isset($results[0]) || $results[0][$configg->getAttribute("SecID")] == "") {
          $this->invalid_UP("Username and password not found in the security database.");
          $dbh->Close();

          if($configg->getAttribute("SecDB") != $configg->getAttribute("NameDB")) {
            $dbi->Close();
          }

          return 0;
        }

        $resduex = $dbi->Select(
            $configg->getAttribute("NameFirst") . ", " . $configg->getAttribute("NameLast"),
            $configg->getAttribute("NameTable"),
            $configg->getAttribute("NameID") . " = " .  $results[0][$configg->getAttribute("SecID")]);

        if($this->debug) {
          print("After<br>\n");
          flush();
        }

      }

      $dbh->Close();

      if($configg->getAttribute("SecDB") != $configg->getAttribute("NameDB")) {