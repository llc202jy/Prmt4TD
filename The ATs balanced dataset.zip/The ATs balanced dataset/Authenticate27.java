namespace FreeSwitch.EventSocket.Commands
{
	/// <summary>
	/// Authentication command.
	/// </summary>
	public class Authenticate : ICommand
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="Authenticate"/> class.
		/// </summary>
		/// <param name="password">Password configured in <![CDATA[freeswitch\conf\autoload_configs\eventsocket.conf.xml]]>.</param>
		public Authenticate(string password)
		{
			Password = password;
		}

		/// <summary>
		/// Gets or sets password used during authentication
		/// </summary>
		public string Password { get; set; }

		#region ICommand Members

		/// <summary>
		/// Parses a reply sent from FreeSWITCH for a command.
		/// </summary>
		/// <param name="msg"></param>
		/// <returns></returns>
		public ICommandReply ParseReply(ParsedMessage msg)
		{
			return CommandReply.Parse(msg);
		}

		/// <summary>
		/// Generate a string that can be sent to FreeSWITCH
		/// </summary>
		/// <returns>String that FreeSWITCH can interpret as a command.</returns>
		public string ToCommandString()
		{
			return string.Format("auth {0}\n", Password);
		}

		#endregion

		/// <summary>
		/// Returns a <see cref="T:System.String"/> that represents the current <see cref="T:System.Object"/>.
		/// </summary>
		/// <returns>
		/// A <see cref="T:System.String"/> that represents the current <see cref="T:System.Object"/>.
		/// </returns>
		public override string ToString()
		{
			return "Authenticate(password is hidden)";
		}
	}