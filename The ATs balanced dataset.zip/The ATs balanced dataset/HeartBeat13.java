import org.omg.CORBA.FT.FaultNotifier;
import org.omg.CORBA.FT.GlobalFaultDetectorPOA;
import org.omg.CORBA.FT.MonitorableHelper;
import org.omg.CORBA.FT.PullMonitorable;
import org.omg.CORBA.FT.PullMonitorableHelper;
import org.omg.CORBA.FT.PushMonitor;
import org.omg.CORBA.FT.PushMonitorHelper;
import org.omg.CORBA.FT.PushMonitorable;
import org.omg.CORBA.FT.PushMonitorableHelper;
import org.omg.CORBA.FT.ReplicationManager;
import org.omg.CORBA.FT.ReplicationManagerHelper;
import org.omg.CORBA.FT.RingMember;
import org.omg.CORBA.FT.RingMemberHelper;
import org.omg.CORBA.FT.Status;
import org.omg.CORBA.FT.Voter;
import org.omg.CORBA.FT.VoterHelper;
import org.omg.CosNotification.EventHeader;
import org.omg.CosNotification.EventType;
import org.omg.CosNotification.FixedEventHeader;
import org.omg.CosNotification.Property;
import org.omg.CosNotification.StructuredEvent;
import org.omg.PortableServer.POA;
	//            (PushMonitorable), (Integer),   (Long),   (Status)
	protected volatile edu.lcmi.grouppac.util.VectorTable monitorables;
	protected volatile Hashtable timers;
	// voting support
	protected volatile Hashtable suspects;
	protected volatile Hashtable polls;

	// detector monitor
	protected boolean monitor_enabled = true;
	protected DetectorMonitor monitor;

	// Class that implement a resetable timer
	public class StatusTimer implements Runnable {

		private PushMonitorable o;
		private long t;
		private volatile boolean reported;

		public StatusTimer(PushMonitorable target, long timeout) {
			o = target;
			t = timeout;
		}

		public void run() {
			Thread.yield();
			try {
				Thread.sleep(t);
			} catch (Exception e) {
			}
			if (!reported) {
				suspect(o);
			}
		}

		public void setReported() {
			reported = true;
		}

		public PushMonitorable getTarget() {
			return o;
		}

		public long getTimeout() {
			return t;
		}
	}

	// Class that implement a resetable timer
	public class PollTimer implements Runnable {

		private int p;
		private long t;

		public PollTimer(int poll_id, long timeout) {
			p = poll_id;
			t = timeout;
		}

		public void run() {
			Thread.yield();
			try {
				Thread.sleep(t);
			} catch (Exception e) {
			}
			closePoll(p);
		}
	}

	// Class that implement a resetable timer
	public class ViewTimer implements Runnable {

		private int p;
		private long t;

		public ViewTimer(long timeout) {
			t = timeout;
		}

		public void run() {
			Thread.yield();
			try {
				Thread.sleep(t);
			} catch (Exception e) {
			}
			generateNewView();
		}
	}

	public class RingCheckThread implements Runnable {

		private volatile boolean running = true;

		public void stopThread() {
			running = false;
		}

		public void run() {
			long interval = ring_interval / 10000;
			while (running) {
				/* Wait before passing the token */
				Thread.yield();
				try {
					Thread.sleep(interval);
				} catch (Exception e) {
					return;
				}
				token++;
				startRoundTrip(token);
			}
		}
	}

	/**
	 * Default constructor. Creation date: (25/03/01 11:02:29)
	 * 
	 * @param args an array of command-line arguments
	 */
	public GlobalFaultDetectorImpl(String[] args) {
		init();
		parseArgs(args);
	}

	/**
	 * addMonitor method comment.
	 */
	public void addMonitor(DetectorMonitor monitor) {
		if (monitor != this.monitor) {
			this.monitor.monitorUnregistered(this);
		}
		this.monitor = monitor;
		monitor.monitorRegistered(this);
	}

	// Voter interface
	public void check(org.omg.CORBA.Object target, int poll_id) {
		if (this_address.equals(ParsedIOGR.getAddress(target))) {
			Voter leader = getVoterLeader();
			if (leader == null)
				return;
			leader.vote(target, poll_id, Status.ALIVE);
			return;
		}

		/*
		 * this is a kind of pull monitoring, but is needed
		 * to ensure that the rest (_is_a) will happen as expected
		 */
		if (target._non_existent())
			getVoterLeader().vote(target, poll_id, Status.SUSPECT);
		boolean is_pull_monitorable = false;
		boolean is_push_monitorable = false;
		try {
			is_pull_monitorable = target._is_a("IDL:omg.org/CORBA/FT/PullMonitorable:1.0");
			is_push_monitorable = target._is_a("IDL:omg.org/CORBA/FT/PushMonitorable:1.0");
		} catch (Exception e) {
			getVoterLeader().vote(target, poll_id, Status.SUSPECT);
			return;
		}
		if (is_pull_monitorable) {
			PullMonitorable pull = PullMonitorableHelper.narrow(target);
			boolean is_alive = false;
			try {
				is_alive = pull.is_alive();
			} catch (Exception e) {
			}
			if (is_alive)
				getVoterLeader().vote(target, poll_id, Status.ALIVE);
			else
				getVoterLeader().vote(target, poll_id, Status.SUSPECT);
		} else if (is_push_monitorable) {
			synchronized (monitorables) {
				Object[] row = monitorables.getRow(target);
				if (row != null)
					getVoterLeader().vote(target, poll_id, (Status) row[3]);
			}
		}
	}

	/**
	 * getLocation method comment.
	 */
	public String getLocation() {
		return Main.getORBLocation();
	}

	/**
	 * getStatus method comment.
	 */
	public int getStatus(org.omg.CORBA.Object target) {
		int i = monitorables.indexOf(0, target);
		if (i != -1) {
			return ((Status) monitorables.get(3, i)).value();
		}
		return Status._SUSPECT;
	}

	// PushMonitor interface
	public void i_am_alive(PushMonitorable target) {
		Debug.output(2, "GFD: Object at " + ParsedIOGR.getAddress(target) + " is reporting as alive.");
		synchronized (monitorables) {
			int index = monitorables.indexOf(0, target);
			Object[] row = monitorables.remove(index);
			row[3] = Status.ALIVE;
			StatusTimer s = (StatusTimer) timers.get(target);
			if (s != null)
				s.setReported();
			monitorables.add(row);
			long interval = ((Long) row[2]).longValue();
			startCounter(target, interval);
		}
	}

	// PullMonitorable interface
	public boolean is_alive() {
		return true;
	}

	/**
	 * listObjects method comment.
	 */
	public org.omg.CORBA.Object[] listObjects() {
		Vector v = monitorables.getColumn(0);
		org.omg.CORBA.Object[] objects = new org.omg.CORBA.Object[v.size()];
		v.copyInto(objects);
		return objects;
	}

	// RingMember interface
	public void pass(int loop_id) {
		// if the ring_information is null, we can do nothing!
		if (ring_information == null) {
			//Debug.assert(ring_information != null, "ring_information is null in suspect_breach()");
			return;
		}

		// this is the leader, so no need to pass on the token
		if (ring_position == 0) {
			endRoundTrip(loop_id);
			return;
		}
		token = loop_id;
		Debug.output(3, "GFD: Received token no. " + loop_id + " and passing to " + next_location);
		final int _token = token;
		final long _interval = ring_interval / 10000 / ring_information.getNumberOfObjects();
		Runnable task = new Runnable() {
			public void run() {
				try {
					Thread.sleep(_interval);
				} catch (Exception e) {
					return;
				}
				try {
					RingMember rm = RingMemberHelper.narrow(next_ref);
					rm.pass(_token);
					Debug.output(4, "GFD: Token no. " + _token + " passed");
				} catch (Throwable t) {
					Debug.output(
						2,
						"GFD: Suspect breach for token no. "
							+ _token
							+ " at location: "
							+ ParsedIOGR.getAddress(next_ref));
					suspect_breach(next_ref, _token);
				}
			}
		};
		Runnable exception = new Runnable() {
			public void run() {
				Debug.output(
					2,
					"GFD: Suspect breach for token no. "
						+ _token
						+ " at location: "
						+ ParsedIOGR.getAddress(next_ref));
				suspect_breach(next_ref, _token);
			}
		};
		TimedTask tt = new TimedTask("token passer", task, ring_interval, null, exception);
		(new Thread(tt)).start();
	}

	/**
	 * removeMonitor method comment.
	 */
	public void removeMonitor(DetectorMonitor monitor) {
		monitor.monitorUnregistered(this);
		if (monitor == this.monitor) {
			this.monitor = null;
		}
	}

	/**
	 * Runs the GenericFactory.
	 */
	public void run(Object notificator) {
		try {
			poa = Main.getPOA();
			poa.the_POAManager().activate();
			this_address = Main.getORBLocation();
			org.omg.CORBA.Object obj = Main.getPOA().servant_to_reference(this);
			org.omg.CORBA.Object gfd_iogr = Main.resolve_str("GlobalFaultDetector.service");
			if (gfd_iogr != null) {
				Main.registerMember(gfd_iogr, obj);
				Debug.output(0, "GlobalFaultDetector registered in the GlobalReplicationManager.");
			} else {
				Debug.output(0, "GlobalFaultDetector *NOT* registered in the GlobalReplicationManager.");
				Debug.output(0, "GlobalFaultDetector IOR: " + ParsedIOGR.toString(obj));
			}

			/* Initializing the monitor */
			if (monitor_enabled) {
				DetectorMonitorImpl m = new DetectorMonitorImpl();
				addMonitor(m);
				m.show();
			}
			Debug.output(0, "GlobalFaultDetector ready.");
		} catch (Exception e) {
			Debug.output(3, e);
			Debug.output(0, "GlobalFaultDetector NOT ready.");
		}

		/* notify the main thread */
		synchronized (notificator) {
			notificator.notifyAll();
		}
	}

	// PushMonitor interface
	public void start_monitoring(PushMonitorable target, int granularity, long interval, long timeout) {
		ParsedIOGR group = new ParsedIOGR(target);
		if (!group.isIOGR()) {
			synchronized (monitorables) {
				try {
					target.register_push_monitor(toPushMonitor(), interval, timeout);
					Object[] row = { target, new Integer(granularity), new Long(interval), Status.UNKNOWN };
					monitorables.add(row);
					if (monitor != null) {
						monitor.startMonitoring(target);
					}
					startCounter(target, interval);
				} catch (Exception e) {
					Debug.output(2, e);
				}
			}
		} else {
			synchronized (monitorables) {
				int k = group.getNumberOfObjects();
				for (int i = 0; i < k; i++) {
					org.omg.CORBA.Object o = group.getObjectReference(i);
					try {
						PushMonitorable pm = PushMonitorableHelper.narrow(o);
						pm.register_push_monitor(toPushMonitor(), interval, timeout);
						Object[] row = { pm, new Integer(granularity), new Long(interval), Status.UNKNOWN };
						if (monitor != null) {
							monitor.startMonitoring(pm);
						}
						startCounter(pm, interval);
						monitorables.add(row);
					} catch (Exception e) {
						Debug.output(2, e);
					}
				}
			}
		}
	}

	// PushMonitor interface
	public void stop_monitoring(PushMonitorable target) {
		ParsedIOGR group = new ParsedIOGR(target);
		if (!group.isIOGR()) {
			synchronized (monitorables) {
				int index = monitorables.indexOf(0, target);
				if (index > 0)
					monitorables.remove(index);
				suspects.remove(target);
				StatusTimer s = (StatusTimer) timers.get(target);
				if (s != null)
					s.setReported();
				if (monitor != null) {
					monitor.stopMonitoring(target);
				}
			}
		} else {
			synchronized (monitorables) {
				int k = group.getNumberOfObjects();
				for (int i = 0; i < k; i++) {
					org.omg.CORBA.Object o = group.getObjectReference(i);
					PushMonitorable pm = PushMonitorableHelper.narrow(o);
					int index = monitorables.indexOf(0, target);
					if (index > 0)
						monitorables.remove(index);
					suspects.remove(pm);
					StatusTimer s = (StatusTimer) timers.get(pm);
					if (s != null)
						s.setReported();
					if (monitor != null) {
						monitor.stopMonitoring(target);
					}
				}
			}
		}
	}

	// PushMonitor interface
	public void suspect(PushMonitorable target) {
		synchronized (monitorables) {
			int index = monitorables.indexOf(0, target);
			if (index < 0)
				return;
			Object[] row = monitorables.remove(index);
			row[3] = Status.SUSPECT;
			monitorables.add(row);
			if (monitor != null) {
				monitor.update(target, Status._SUSPECT);
			}
			if (ring_position == 0)

				// Am I the leader? Then start a check
				synchronized (ring_information) {
					int k = ring_information.getNumberOfObjects();
					for (int i = 0; i < k; i++) {
						org.omg.CORBA.Object o = ring_information.getObjectReference(i);
						Voter voter = VoterHelper.narrow(o);
						voter.check(MonitorableHelper.narrow(target), token++);
					}
				} else

				// Am I not? Notify the leader
				synchronized (ring_information) {
					org.omg.CORBA.Object o = ring_information.getObjectReference(0);
					try {
						PushMonitor leader = PushMonitorHelper.narrow(o);
						leader.suspect(target);
					} catch (Throwable t) {
						// if the leader is down, find the next object that is up
						// and fix the leadership before everything else
						int k = ring_information.getNumberOfObjects();
						RingMember leader = RingMemberHelper.narrow(o);
						int tok = token++;
						for (int i = 1; i < k; i++) {
							if (i != ring_position) {
								o = ring_information.getObjectReference(i);
								try {
									RingMember new_leader = RingMemberHelper.narrow(o);
									new_leader.suspect_breach(leader, tok);
								} catch (Throwable ttt) {
								} // ignore the exception
							}
						}
					}
				}
		}
	}

	// RingMember interface
	public void suspect_breach(org.omg.CORBA.Object target, int loop_id) {

		// if the ring_information is null, we can do nothing!
		if (ring_information == null) {
			//Debug.assert(ring_information != null, "ring_information is null in suspect_breach()");
			return;
		}
		if (monitor != null) {
			monitor.update(target, Status._SUSPECT);
		}
		if (ring_position != 0) {
			RingMember leader = getLeader();
			if (leader == null)
				return;
			if (this_address == null)
				this_address = Main.getORBLocation();
			if (!this_address.equals(ParsedIOGR.getAddress(leader))) {
				leader.suspect_breach(target, loop_id);
				return;
			}
		}

		/* Stop the ring checking until the breach is solved */
		ringCheckThread(false);
		if (contains(suspects, target))
			return;
		Integer key = new Integer(loop_id);
		while (polls.containsKey(key)) {
			key = new Integer(loop_id++);
		}
		polls.put(key, new Integer(0));
		suspects.put(target, key);
		synchronized (new_ring_view_lock) {
			synchronized (ring_information) {
				int k = ring_information.getNumberOfObjects();
				if (new_ring_view == null)
					new_ring_view = new Vector(k);
				for (int i = 0; i < k; i++) {
					final org.omg.CORBA.Object o = ring_information.getObjectReference(i);
					final int _loop_id = loop_id;
					Runnable task = new Runnable() {
						public void run() {
							try {
								Voter voter = VoterHelper.narrow(o);
								voter.check(o, _loop_id);
							} catch (Exception ignore) {
							}
						}
					};
					TimedTask tt = new TimedTask("voter invocation", task, ring_interval, this);
					(new Thread(tt)).start();
				}
			}
		}
		ring_suspicions++;
		(new Thread(new ViewTimer(ring_interval / 10000), "New ring view timer")).start();
	}

	/**
	 * taskFinished method comment.
	 */
	public void taskFinished(java.lang.String task_name, org.omg.CORBA.CompletionStatus status) {
	}

	/**
	 * Lazy evaluation of PushMonitor reference of this object.
	 * @return org.omg.CORBA.FT.PushMonitor
	 */
	public PushMonitor toPushMonitor() throws Exception {
		if (my_ref == null) {
			org.omg.CORBA.Object member = Main.getPOA().servant_to_reference(this);
			my_ref = PushMonitorHelper.narrow(member);
		}
		return my_ref;
	}

	/**
	 * Lazy evaluation of RingMember reference of this object.
	 * @return org.omg.CORBA.FT.RingMember
	 */
	public RingMember toRingMember() {
		if (this_member == null) {
			try {
				org.omg.CORBA.Object member = Main.getPOA().servant_to_reference(this);
				this_member = RingMemberHelper.narrow(member);
			} catch (Exception ignore) {
			}
		}
		return this_member;
	}

	/**
	 * Lazy evaluation of Voter reference of this object.
	 * @return org.omg.CORBA.FT.Voter
	 */
	public Voter toVoter() {
		if (this_voter == null) {
			try {
				org.omg.CORBA.Object member = Main.getPOA().servant_to_reference(this);
				this_voter = VoterHelper.narrow(member);
			} catch (Exception ignore) {
			}
		}
		return this_voter;
	}

	// PushMonitor interface
	public void update_monitoring(PushMonitorable target, int granularity, long interval, long timeout) {
		stop_monitoring(target);
		start_monitoring(target, granularity, interval, timeout);
	}

	// RingMember interface
	public void update_ring_information(org.omg.CORBA.Object group) {
		// what if the ring information is not from this interface?
		if (!group._is_a(this._all_interfaces(null, null)[0])) {
			return;
		}
		Debug.output(2, "GFD: Ring information update received at " + this_address);
		if (ring_information == null) {
			ring_information = new ParsedIOGR(group);
		}
		synchronized (ring_information) {
			ring_position = findMe(ring_information);

			//alteracao feita por luciana
			if (ring_position == -1) {
				stop_monitoring_all();
				return;
			}
			//alteracao termina aqui.

			try {
				rm = getRM();
			} catch (Exception e) {
				Debug.output(0, "GFD: Unable to obtain a reference to the GlobalReplicationManager, update canceled.");
				return;
			}
			try {
				Map p = Main.toMap(rm.get_properties(group));
				ring_interval = Long.parseLong((String) p.get(Main.FMI));
			} catch (Exception no_interval) {
				try {
					Map p = Main.toMap(rm.get_default_properties());
					ring_interval = Long.parseLong((String) p.get(Main.FMI));
				} catch (Exception ignore) {
				}
			}
			ring_information = new ParsedIOGR(group);
			int n = ring_information.getNumberOfObjects();
			int p = ring_position - 1;
			if (p < 0)
				p = n - 1;
			next_ref = ring_information.getObjectReference(p, false);
			Debug.output(3, "GFD: Total: " + n + " Me:" + ring_position + " Next:" + p);
		}
		next = RingMemberHelper.narrow(next_ref);
		next_location = ParsedIOGR.getAddress(next_ref);
		/**try {
			((org.jacorb.orb.Delegate) ((org.omg.CORBA.portable.ObjectImpl) next_ref)._get_delegate()).connection.setTimeOut((int) (ring_interval / 10000));
			((org.jacorb.orb.Delegate) ((org.omg.CORBA.portable.ObjectImpl) next)._get_delegate()).connection.setTimeOut((int) (ring_interval / 10000));
		} catch (Exception ignore) {
		}*/
		ringCheckThread(true);
	}

	// Voter interface
	public void vote(org.omg.CORBA.Object target, int poll_id, org.omg.CORBA.FT.Status opinion) {
		// is it about an internal voting?
		synchronized (new_ring_view_lock) {
			if (target._is_a("IDL:omg.org/CORBA/FT/GlobalFaultDetector:1.0")
				&& opinion.equals(Status.ALIVE)
				&& new_ring_view != null) {
				if (!contains(new_ring_view, target)) {
					new_ring_view.addElement(target);
				}
				return;
			}
		}

		// so it's about an application object
		Integer key = new Integer(poll_id);
		// We count the number of voters that report the target as suspect
		if (polls.containsKey(key)) {
			int v = 0;
			if (opinion.equals(Status.SUSPECT)) {
				synchronized (polls) {
					v = ((Integer) polls.get(key)).intValue();
					polls.put(key, new Integer(v++));
				}
			}
			synchronized (ring_information) {
				int k = ring_information.getNumberOfObjects();
				// If there is only one voter, engage "authoritary mode"
				if (k == 1) {
					closePoll(poll_id);
				} else

					// If we achieve majority, remove the target from it's group
					if (v >= (k / 2)) {
						closePoll(poll_id);
					}
			}
		}
	}

	/**
	 * Close an open pool.
	 * Creation date: (29/03/01 21:45:19)
	 * @param poll_id int
	 */
	protected void closePoll(int poll_id) {
		synchronized (polls) {
			Integer key = new Integer(poll_id);
			polls.remove(key);
			org.omg.CORBA.Object target = null;
			for (java.util.Enumeration e = suspects.keys(); e.hasMoreElements();) {
				Object o = e.nextElement();
				if (suspects.get(o).equals(key)) {
					target = (org.omg.CORBA.Object) o;
					break;
				}
			}
			suspects.remove(target);
			reportFailure(target);
		}
	}

	/**
	 * Tries to find the CORBA object on the Vector.
	 *
	 * Creation date: (5/5/2001 18:51:22)
	 * @return boolean
	 * @param v java.util.Vector
	 * @param o org.omg.CORBA.Object
	 */
	private boolean contains(Hashtable v, org.omg.CORBA.Object o) {
		try {
			String o_location = ParsedIOGR.getAddress(o);
			String n_location;
			for (Enumeration e = v.keys(); e.hasMoreElements(); ) {
				n_location = ParsedIOGR.getAddress((org.omg.CORBA.Object) e.nextElement());
				if (o_location.equals(n_location)) {
					return true;
				}
			}
			return false;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Tries to find the CORBA object on the Vector.
	 *
	 * Creation date: (5/5/2001 18:51:22)
	 * @return boolean
	 * @param v java.util.Vector
	 * @param o org.omg.CORBA.Object
	 */
	private boolean contains(Vector v, org.omg.CORBA.Object o) {
		try {
			String o_location = ParsedIOGR.getAddress(o);
			String n_location;
			for (Iterator e = v.iterator(); e.hasNext(); ) {
				n_location = ParsedIOGR.getAddress((org.omg.CORBA.Object) e.next());
				if (o_location.equals(n_location)) {
					return true;
				}
			}
			return false;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Ends a roundtrip in the ring.
	 *
	 * Creation date: (5/5/2001 17:11:37)
	 */
	protected void endRoundTrip(int loop_id) {
		// close the roundtrip
		Debug.output(3, "GFD: Received token no. " + loop_id + " and closing roundtrip.");
		roundtrips.removeElement(new Integer(token));
	}

	/**
	 * Find this object in an IOGR.
	 * Returns -1 if this object was NOT found in the IOGR,
	 * which probably means that something wrong is going on.
	 * Creation date: (24/03/01 11:33:42)
	 * @return int The profile position in the IOGR
	 * @param iogr edu.lcmi.grouppac.ParsedIOGR The group IOGR
	 */
	private int findMe(ParsedIOGR iogr) {
		if (this_address == null)
			this_address = Main.getORBLocation();
		if (iogr.isIOGR()) {
			int k = iogr.getNumberOfObjects();
			for (int i = 0; i < k; i++) {
				String address = ParsedIOGR.getAddress(iogr.getObjectReference(i));
				if (address.equals(this_address)) {
					return i;
				}
			}
		}
		return -1;
	}

	/**
	 * Returns a StructuredEvent filled with the parameters.
	 * @return org.omg.CosNotification.StructuredEvent
	 * @param domain_id java.lang.String
	 * @param location java.lang.String
	 * @param type_id java.lang.String
	 * @param group_id long
	 */
	private StructuredEvent generateEvent(
		String domain_id,
		String location,
		String type_id,
		long group_id) {

		StructuredEvent event = new StructuredEvent();
		event.remainder_of_body = orb.create_any();
		event.remainder_of_body.insert_string("");
		event.header = new EventHeader();
		event.header.fixed_header = new FixedEventHeader();
		event.header.fixed_header.event_name = "";
		event.header.fixed_header.event_type = new EventType();
		event.header.fixed_header.event_type.domain_name = "FT_CORBA";

		//inicializa??o para poder haver comunica??o
		event.header.variable_header = new Property[1];
		Any any = orb.create_any();
		any.insert_string("");
		event.header.variable_header[0] = new Property("", any);
		if (type_id == null && group_id == 0)
			event.filterable_data = new Property[2];
		else
			event.filterable_data = new Property[4];
		//criando o filterable_data[0]
		event.filterable_data[0] = new Property();
		event.filterable_data[0].name = "FTDomainId";
		event.filterable_data[0].value = orb.create_any();
		event.filterable_data[0].value.insert_string(domain_id);
		//criando o filterable_data[1]
		event.filterable_data[1] = new Property();
		event.filterable_data[1].name = "Location";
		event.filterable_data[1].value = orb.create_any();
		event.filterable_data[1].value.insert_string(location);
		if (!(type_id == null && group_id == 0)) {
			event.header.fixed_header.event_type.type_name = "ObjectCrashFault";
			//criando o filterable_data[2]
			event.filterable_data[2] = new Property();
			event.filterable_data[2].name = "TypeId";
			event.filterable_data[2].value = orb.create_any();
			event.filterable_data[2].value.insert_string(type_id);
			//criando o filterable_data[3]
			event.filterable_data[3] = new Property();
			event.filterable_data[3].name = "ObjectGroupId";
			event.filterable_data[3].value = orb.create_any();
			event.filterable_data[3].value.insert_longlong(group_id);
		} else
			event.header.fixed_header.event_type.type_name = "HostCrashFault";
		return event;
	}

	/**
	 * Generate a new view by reporting
	 * the failure of all members that haven't
	 * reported during the poll duration.
	 *
	 * Creation date: (5/5/2001 15:13:08)
	 */
	protected synchronized void generateNewView() {
		ring_suspicions--;
		if (ring_suspicions != 0)
			return;
		Debug.output(2, "GFD: New ring view being generated...");
		int k = 0;
		int l = 0;
		int m = 0;
		Vector failures = new Vector(0);
		synchronized (new_ring_view_lock) {
			synchronized (ring_information) {
				k = ring_information.getNumberOfObjects();
				l = new_ring_view.size();
				failures = new Vector(k - l + 1);
				for (int i = 0; i < k; i++) {
					org.omg.CORBA.Object o = ring_information.getObjectReference(i);
					if (!contains(new_ring_view, o)) {
						if (!this_address.equals(ParsedIOGR.getAddress(o))) {
							//Debug.output(2, "GFD: Failure of " + failed + " being prepared.");
							failures.addElement(o);
						}
					}
				}
			}
			m = failures.size();
			for (int i = 0; i < m; i++) {
				org.omg.CORBA.Object o = (org.omg.CORBA.Object) failures.elementAt(i);
				reportFailure(o);
			}
			new_ring_view = null;
		}
		if (m == 0) {
			Debug.output(3, "GFD: No breaches detected, restarting ring check.");
			ringCheckThread(true);
		}
	}

	/**
	 * Lazy evaluation of FaultNotifier reference.
	 * Creation date: (26/03/01 00:59:33)
	 * @return org.omg.CORBA.FT.FaultNotifier
	 */
	protected FaultNotifier getFN() throws Exception {
		if (fn == null)
			fn = getRM().get_fault_notifier();
		return fn;
	}

	/**
	 * Tries to find a ring leader.
	 * If the real leader fails, keeps trying until
	 * somebody answer.
	 *
	 * Creation date: (5/5/2001 13:55:18)
	 * @return org.omg.CORBA.FT.RingMember
	 */
	private synchronized void reportFailure(org.omg.CORBA.Object target) {
		ParsedIOGR piogr = new ParsedIOGR(target);
		if (piogr.isIOGR()) {
			if (monitor != null) {
				monitor.update(target, 3);
			}
			String domain = piogr.getFTDomainId();
			String location = piogr.getObjectLocation(target)[0].id;
			String type_id = piogr.getTypeId();
			long group = piogr.getObjectGroupId();
			org.omg.CosNotification.StructuredEvent event = generateEvent(domain, location, type_id, group);
			try {
				getFN().push_structured_fault(event);
			} catch (Exception e) {
				Debug.output(2, "##HFD: Failure report could not be pushed to FaultNotifier");
				Debug.output(3, e);
			}
		}
	}

	/**
	 * Insert the method's description here.

	/**
	 * Start a status timer on a PushMonitorable.
	 * Creation date: (26/03/01 00:30:34)
	 * @param target org.omg.CORBA.FT.PushMonitorable
	 * @param timeout long
