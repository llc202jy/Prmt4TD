public GeneralNames(final byte[] encoded) throws IOException
  {
    names = new LinkedList();
    DERReader der = new DERReader(encoded);
    DERValue nameList = der.read();
    if (!nameList.isConstructed())
      throw new ASN1ParsingException("malformed GeneralNames");
    int len = 0;
    while (len < nameList.getLength())
      {
        DERValue name = der.read();
        List namePair = new ArrayList(2);
        if (name.getTagClass() != DER.APPLICATION)
          throw new ASN1ParsingException("malformed GeneralName");
        namePair.add(new Integer(name.getTag()));
        DERValue val = null;
        switch (name.getTag())
          {
          case RFC822_NAME:
          case DNS_NAME:
          case X400_ADDRESS:
          case URI:
            namePair.add(new String((byte[]) name.getValue()));
            break;

          case OTHER_NAME:
          case EDI_PARTY_NAME:
            namePair.add(name.getValue());
            break;

          case DIRECTORY_NAME:
            byte[] b = name.getEncoded();
            b[0] = (byte) (DER.CONSTRUCTED|DER.SEQUENCE);
            namePair.add(new X500Name(b).toString());
            break;

          case IP_ADDRESS:
            namePair.add(InetAddress.getByAddress((byte[]) name.getValue())
                         .getHostAddress());
            break;

          case REGISTERED_ID:
            byte[] bb = name.getEncoded();
            bb[0] = (byte) DER.OBJECT_IDENTIFIER;
            namePair.add(new OID(bb).toString());
            break;

          default:
            throw new ASN1ParsingException("unknown tag " + name.getTag());
          }
        names.add(namePair);
        len += name.getEncodedLength();
      }
  }

  // Instance methods.
  // -------------------------------------------------------------------------

  public List getNames()
  {
    List l = new ArrayList(names.size());
    for (Iterator it = names.iterator(); it.hasNext(); )
      {
        List ll = (List) it.next();
        List pair = new ArrayList(2);
        pair.add(ll.get(0));
        if (ll.get(1) instanceof byte[])
          pair.add(((byte[]) ll.get(1)).clone());
        else
          pair.add(ll.get(1));
        l.add(Collections.unmodifiableList(pair));
      }
    return Collections.unmodifiableList(l);
  }
}
package javax.net;

import java.io.IOException;

import java.net.InetAddress;
import java.net.ServerSocket;

import java.security.Security;

/**
 * A factory for server sockets. The purpose of this class is to serve
 * as the superclass of server socket factories that produce server
 * sockets of a particular type, such as <i>Secure Socket Layer</i>
 * (<b>SSL</b>) server sockets.
 *
 * @author Casey Marshall (rsdio@metastatic.org)
 */
public abstract class ServerSocketFactory
{

  // Constructors.
  // ------------------------------------------------------------------------

  /**
   * Default 0-argument constructor.
   */
  protected ServerSocketFactory()
  {
    super();
  }

  // Class methods.
  // ------------------------------------------------------------------------

  /**
   * Returns the default server socket factory. The type of factory
   * returned may depend upon the installation.
   *
   * @return The default server socket factory.
   */
  public static synchronized ServerSocketFactory getDefault()
  {
    try
      {
        String s = Security.getProperty("gnu.defaultServerSocketFactory");
        if (s != null)
          {
            Class c = Class.forName(s);
            return (ServerSocketFactory) c.newInstance();
          }
      }
    catch (Exception e)
      {
      }
    return new VanillaServerSocketFactory();
  }

  // Instance methods.
  // ------------------------------------------------------------------------

  /**
   * Create an unbound server socket.
   *
   * @return The new server socket.
   * @throws IOException If a networking error occurs.
   */
  public ServerSocket createServerSocket() throws IOException
  {
    throw new UnsupportedOperationException();
  }

  /**
   * Create a server socket bound to the given port.
   *
   * @param port The port to bind the server socket to.
   * @return A server socket bound to <i>port</i>.
   * @throws IOException If a networking error occurs.
   */
  public abstract ServerSocket createServerSocket(int port) throws IOException;

  public abstract ServerSocket createServerSocket(int port, int backlog) throws IOException;

  public abstract ServerSocket createServerSocket(int port, int backlog, InetAddress bindAddress) throws IOException;
}
supportedSuites.add(CipherSuite.TLS_DHE_DSS_WITH_AES_256_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_DHE_RSA_WITH_AES_256_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_DH_DSS_WITH_AES_256_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_DH_RSA_WITH_AES_256_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_RSA_WITH_AES_256_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_DHE_DSS_WITH_AES_128_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_DHE_RSA_WITH_AES_128_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_DH_DSS_WITH_AES_128_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_DH_RSA_WITH_AES_128_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_RSA_WITH_AES_128_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_RSA_WITH_3DES_EDE_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_RSA_WITH_RC4_128_MD5);
    supportedSuites.add(CipherSuite.TLS_RSA_WITH_RC4_128_SHA);
    supportedSuites.add(CipherSuite.TLS_DHE_DSS_WITH_DES_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_DHE_RSA_WITH_DES_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_DH_DSS_WITH_DES_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_DH_RSA_WITH_DES_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_RSA_WITH_DES_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_RSA_EXPORT_WITH_DES40_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_RSA_EXPORT_WITH_RC4_40_MD5);
    supportedSuites.add(CipherSuite.TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA);
    supportedSuites.add(CipherSuite.TLS_RSA_WITH_NULL_MD5);
    supportedSuites.add(CipherSuite.TLS_RSA_WITH_NULL_SHA);
  }

// Constructors.
  // -------------------------------------------------------------------------

  SSLSocket(Socket socket, String host, int port, boolean autoClose)
    throws IOException
  {
    underlyingSocket = socket;
    remoteHost = host;
    underlyingPort = port;
    this.autoClose = autoClose;
    initialize();
  }

  @HAVE_CLASSPATH_TRUE@SSLSocket (Socket socket, SocketChannel channel)
  @HAVE_CLASSPATH_TRUE@{
  @HAVE_CLASSPATH_TRUE@  underlyingSocket = socket;
  @HAVE_CLASSPATH_TRUE@  this.channel = channel;
  @HAVE_CLASSPATH_TRUE@  initialize ();
  @HAVE_CLASSPATH_TRUE@}

  SSLSocket() throws IOException
  {
    super();
    initialize();
  }

  SSLSocket(InetAddress addr, int port) throws IOException
  {
    super(addr, port);
    initialize();
    remoteHost = addr.getHostName();
    if (remoteHost == null)
      {
        remoteHost = addr.getHostAddress();
      }
  }

  SSLSocket(InetAddress addr, int port, InetAddress laddr, int lport)
    throws IOException
  {
    super(addr, port, laddr, lport);
    initialize();
    remoteHost = addr.getHostName();
    if (remoteHost == null)
      remoteHost = addr.getHostAddress();
  }

  SSLSocket(String host, int port) throws IOException
  {
    super(host, port);
    initialize();
    remoteHost = host;
  }

  SSLSocket(String host, int port, InetAddress laddr, int lport)
    throws IOException
  {
    super(host, port, laddr, lport);
    initialize();
    remoteHost = host;
  }

  private void initialize()
  {
    session = new Session();
    session.enabledSuites = new ArrayList(supportedSuites);
    session.enabledProtocols = new TreeSet(supportedProtocols);
    session.protocol = ProtocolVersion.TLS_1;
    session.params.setVersion (ProtocolVersion.TLS_1);
    handshakeListeners = new LinkedList();
    handshakeDone = false;
  }

// SSL methods.
  // -------------------------------------------------------------------------

  public void addHandshakeCompletedListener(HandshakeCompletedListener l)
  {
    synchronized (handshakeListeners)
      {
        if (l == null)
          throw new NullPointerException();
        if (!handshakeListeners.contains(l))
          handshakeListeners.add(l);
      }
  }

  public void removeHandshakeCompletedListener(HandshakeCompletedListener l)
  {
    synchronized (handshakeListeners)
      {
        handshakeListeners.remove(l);
      }
  }

  public String[] getEnabledProtocols()
  {
    synchronized (session.enabledProtocols)
      {
        try
          {
            return (String[]) Util.transform(session.enabledProtocols.toArray(),
                                             String.class, "toString", null);
          }
        catch (Exception x)
          {
            RuntimeException re = new RuntimeException (x.getMessage());
@HAVE_CLASSPATH_TRUE@            re.initCause (x);
            throw re;
          }
      }
  }

  public void setEnabledProtocols(String[] protocols)
  {
    if (protocols == null || protocols.length == 0)
      throw new IllegalArgumentException();
    for (int i = 0; i < protocols.length; i++)
      {
        if (!(protocols[i].equalsIgnoreCase("SSLv3") ||
              protocols[i].equalsIgnoreCase("TLSv1") ||
              protocols[i].equalsIgnoreCase("TLSv1.1")))
          {
            throw new
              IllegalArgumentException("unsupported protocol: " +
                                       protocols[i]);
          }
      }
    synchronized (session.enabledProtocols)
      {
        session.enabledProtocols.clear();
        for (int i = 0; i < protocols.length; i++)
          {
            if (protocols[i].equalsIgnoreCase("SSLv3"))
              {
                session.enabledProtocols.add(ProtocolVersion.SSL_3);
              }
            else if (protocols[i].equalsIgnoreCase("TLSv1"))
              {
                session.enabledProtocols.add(ProtocolVersion.TLS_1);
              }
            else
              {
                session.enabledProtocols.add(ProtocolVersion.TLS_1_1);
              }
          }
      }
  }

  public String[] getSupportedProtocols()
  {
    return new String[] { /* "TLSv1.1", */ "TLSv1", "SSLv3" };
  }

  public String[] getEnabledCipherSuites()
  {
    synchronized (session.enabledSuites)
      {
        try
          {
            return (String[]) Util.transform(session.enabledSuites.toArray(),
                                             String.class, "toString", null);
          }
        catch (Exception x)
          {
            RuntimeException re = new RuntimeException (x.getMessage());
@HAVE_CLASSPATH_TRUE@            re.initCause (x);
            throw re;
          }
      }
  }

  public void setEnabledCipherSuites(String[] suites)
  {
    if (suites == null || suites.length == 0)
      throw new IllegalArgumentException();
    for (int i = 0; i < suites.length; i++)
      if (CipherSuite.forName(suites[i]) == null)
        throw new IllegalArgumentException("unsupported suite: " +
                                           suites[i]);
    synchronized (session.enabledSuites)
      {
        session.enabledSuites.clear();
        for (int i = 0; i < suites.length; i++)
          {
            CipherSuite suite = CipherSuite.forName(suites[i]);
            if (!session.enabledSuites.contains(suite))
              {
                session.enabledSuites.add(suite);
              }
          }
      }
  }

  public String[] getSupportedCipherSuites()
  {
    return (String[]) CipherSuite.availableSuiteNames().toArray(new String[52]);
  }

  public SSLSession getSession()
  {
    return session;
  }

  public boolean getEnableSessionCreation()
  {
    return createSessions;
  }

  public void setEnableSessionCreation(boolean flag)
  {
    createSessions = flag;
  }

  public boolean getNeedClientAuth()
  {
    return needClientAuth;
  }

  public void setNeedClientAuth(boolean flag)
  {
    needClientAuth = flag;
  }

  public boolean getWantClientAuth()
  {
    return wantClientAuth;
  }

  public void setWantClientAuth(boolean flag)
  {
    wantClientAuth = flag;
  }

  public boolean getUseClientMode()
  {
    return clientMode;
  }

  public void setUseClientMode(boolean flag)
  {
    this.clientMode = flag;
  }

  public synchronized void startHandshake() throws IOException
  {
    if (DEBUG_HANDSHAKE_LAYER)
      {
        debug.println("startHandshake called in " +
                      Thread.currentThread());
        handshakeTime = System.currentTimeMillis();
      }
    if (handshakeDone)
      {
        if (clientMode)
          {
            handshakeDone = false;
            doClientHandshake();
          }
        else
          {
            Handshake req = new Handshake(Handshake.Type.HELLO_REQUEST, null);
            req.write (handshakeOut, session.protocol);
            handshakeOut.flush();
//             recordOutput.setHandshakeAvail(req.write(handshakeOut, session.protocol));
          }
        return;
      }
    if (recordInput == null)
      {
        setupIO();
      }
    if (clientMode)
      {
        doClientHandshake();
      }
    else
      {
        doServerHandshake();
      }
  }

// Socket methods.
  // -------------------------------------------------------------------------

  public InetAddress getInetAddress()
  {
    if (underlyingSocket != null)
      {
        return underlyingSocket.getInetAddress();
      }
    else
      {
        return super.getInetAddress();
      }
  }

  public InetAddress getLocalAddress()
  {
    if (underlyingSocket != null)
      {
        return underlyingSocket.getLocalAddress();
      }
    else
      {
        return super.getLocalAddress();
      }
  }

  public int getPort()
  {
    if (underlyingSocket != null)
      {
        return underlyingSocket.getPort();
      }
    else
      {
        return super.getPort();
      }
  }

  public int getLocalPort()
  {
    if (underlyingSocket != null)
      {
        return underlyingSocket.getLocalPort();
      }
    else
      {
        return super.getLocalPort();
      }
  }

  public InputStream getInputStream() throws IOException
  {
    if (applicationIn == null)
      {
        setupIO();
      }
    return applicationIn;
  }

  public OutputStream getOutputStream() throws IOException
  {
    if (applicationOut == null)
      {
        setupIO();
      }
    return applicationOut;
  }

  public void setTcpNoDelay(boolean flag) throws SocketException
  {
    if (underlyingSocket != null)
      {
        underlyingSocket.setTcpNoDelay(flag);
      }
    else
      {
        super.setTcpNoDelay(flag);
      }
  }

  public boolean getTcpNoDelay() throws SocketException
  {
    if (underlyingSocket != null)
      {
        return underlyingSocket.getTcpNoDelay();
      }
    else
      {
        return super.getTcpNoDelay();
      }
  }

  public void setSoLinger(boolean flag, int linger) throws SocketException
  {
    if (underlyingSocket != null)
      {
        underlyingSocket.setSoLinger(flag, linger);
      }
    else
      {
        super.setSoLinger(flag, linger);
      }
  }

  public int getSoLinger() throws SocketException
  {
    if (underlyingSocket != null)
      {
        return underlyingSocket.getSoLinger();
      }
    else
      {
        return super.getSoLinger();
      }
  }

  public void sendUrgentData(int data) throws IOException
  {
    throw new UnsupportedOperationException("not implemented");
  }

  public void setSoTimeout(int timeout) throws SocketException
  {
    if (underlyingSocket != null)
      {
        underlyingSocket.setSoTimeout(timeout);
      }
    else
      {
        super.setSoTimeout(timeout);
      }
  }

  public int getSoTimeout() throws SocketException
  {
    if (underlyingSocket != null)
      {
        return underlyingSocket.getSoTimeout();
      }
    else
      {
        return super.getSoTimeout();
      }
  }

  public void setSendBufferSize(int size) throws SocketException
  {
    if (underlyingSocket != null)
      {
        underlyingSocket.setSendBufferSize(size);
      }
    else
      {
        super.setSendBufferSize(size);
      }
  }

  public int getSendBufferSize() throws SocketException
  {
    if (underlyingSocket != null)
      {
        return underlyingSocket.getSendBufferSize();
      }
    else
      {
        return super.getSendBufferSize();
      }
  }

  public void setReceiveBufferSize(int size) throws SocketException
  {
    if (underlyingSocket != null)
      {
        underlyingSocket.setReceiveBufferSize(size);
      }
    else
      {
        super.setReceiveBufferSize(size);
      }
  }

  public int getReceiveBufferSize() throws SocketException
  {
    if (underlyingSocket != null)
      {
        return underlyingSocket.getReceiveBufferSize();
      }
    else
      {
        return super.getReceiveBufferSize();
      }
  }

  public synchronized void close() throws IOException
  {
    if (recordInput == null)
      {
        if (underlyingSocket != null)
          {
            if (autoClose)
              underlyingSocket.close();
          }
        else
          super.close();
        return;
      }
//     while (recordOutput.applicationDataPending()) Thread.yield();
    Alert close = new Alert (Alert.Level.WARNING, Alert.Description.CLOSE_NOTIFY);
    sendAlert (close);
    long wait = System.currentTimeMillis() + 60000L;
    while (session.currentAlert == null && !recordInput.pollClose())
      {

        Thread.yield();
        if (wait <= System.currentTimeMillis())
          {
            break;
          }
      }
    boolean gotClose = session.currentAlert != null &&
      session.currentAlert.getDescription() == Alert.Description.CLOSE_NOTIFY;
//     recordInput.setRunning(false);
//     recordOutput.setRunning(false);
//     recordLayer.interrupt();
    recordInput = null;
//     recordOutput = null;
//     recordLayer = null;
    if (underlyingSocket != null)
      {
        if (autoClose)
          underlyingSocket.close();
      }
    else
      super.close();
    if (!gotClose)
      {
        session.invalidate();
        throw new SSLException("did not receive close notify");
      }
  }

  public String toString()
  {
    if (underlyingSocket != null)
      {
        return SSLSocket.class.getName() + " [ " + underlyingSocket + " ]";
      }
    else
      {
        return SSLSocket.class.getName() + " [ " + super.toString() + " ]";
      }
  }

  // Configuration insanity begins here.

  @HAVE_CLASSPATH_TRUE@public void connect(SocketAddress saddr) throws IOException
  @HAVE_CLASSPATH_TRUE@{
  @HAVE_CLASSPATH_TRUE@  if (underlyingSocket != null)
  @HAVE_CLASSPATH_TRUE@    {
  @HAVE_CLASSPATH_TRUE@      underlyingSocket.connect(saddr);
  @HAVE_CLASSPATH_TRUE@    }
  @HAVE_CLASSPATH_TRUE@  else
  @HAVE_CLASSPATH_TRUE@    {
  @HAVE_CLASSPATH_TRUE@      super.connect(saddr);
  @HAVE_CLASSPATH_TRUE@    }
  @HAVE_CLASSPATH_TRUE@}

  @HAVE_CLASSPATH_TRUE@public void connect(SocketAddress saddr, int timeout) throws IOException
  @HAVE_CLASSPATH_TRUE@{
  @HAVE_CLASSPATH_TRUE@  if (underlyingSocket != null)
  @HAVE_CLASSPATH_TRUE@    {
  @HAVE_CLASSPATH_TRUE@      underlyingSocket.connect(saddr, timeout);
  @HAVE_CLASSPATH_TRUE@    }
  @HAVE_CLASSPATH_TRUE@  else
  @HAVE_CLASSPATH_TRUE@    {
  @HAVE_CLASSPATH_TRUE@      super.connect(saddr, timeout);
  @HAVE_CLASSPATH_TRUE@    }
  @HAVE_CLASSPATH_TRUE@}

  @HAVE_CLASSPATH_TRUE@public void bind(SocketAddress saddr) throws IOException
  @HAVE_CLASSPATH_TRUE@{
  @HAVE_CLASSPATH_TRUE@  if (underlyingSocket != null)
  @HAVE_CLASSPATH_TRUE@    {
  @HAVE_CLASSPATH_TRUE@      underlyingSocket.bind(saddr);
  @HAVE_CLASSPATH_TRUE@    }
  @HAVE_CLASSPATH_TRUE@  else
  @HAVE_CLASSPATH_TRUE@    {
  @HAVE_CLASSPATH_TRUE@      super.bind(saddr);
  @HAVE_CLASSPATH_TRUE@    }
  @HAVE_CLASSPATH_TRUE@}

  @HAVE_CLASSPATH_TRUE@public SocketAddress getLocalSocketAddress()
  @HAVE_CLASSPATH_TRUE@{
  @HAVE_CLASSPATH_TRUE@  if (underlyingSocket != null)
  @HAVE_CLASSPATH_TRUE@    {
  @HAVE_CLASSPATH_TRUE@      return underlyingSocket.getLocalSocketAddress();
  @HAVE_CLASSPATH_TRUE@    }
  @HAVE_CLASSPATH_TRUE@  else
  @HAVE_CLASSPATH_TRUE@    {
  @HAVE_CLASSPATH_TRUE@      return super.getLocalSocketAddress();
  @HAVE_CLASSPATH_TRUE@    }
  @HAVE_CLASSPATH_TRUE@}

  @HAVE_CLASSPATH_TRUE@public SocketChannel getChannel()
  @HAVE_CLASSPATH_TRUE@{
  @HAVE_CLASSPATH_TRUE@  return channel;
  @HAVE_CLASSPATH_TRUE@}

  public boolean isBound()
  {
    @HAVE_CLASSPATH_TRUE@if (underlyingSocket != null)
    @HAVE_CLASSPATH_TRUE@  {
    @HAVE_CLASSPATH_TRUE@    return underlyingSocket.isBound();
    @HAVE_CLASSPATH_TRUE@  }
    @HAVE_CLASSPATH_TRUE@else
    @HAVE_CLASSPATH_TRUE@  {
    @HAVE_CLASSPATH_TRUE@    return super.isBound();
    @HAVE_CLASSPATH_TRUE@  }
    @HAVE_CLASSPATH_FALSE@throw new UnsupportedOperationException("1.4 methods not enabled");
  }

  public boolean isClosed()
  {
    @HAVE_CLASSPATH_TRUE@if (underlyingSocket != null)
    @HAVE_CLASSPATH_TRUE@  {
    @HAVE_CLASSPATH_TRUE@    return underlyingSocket.isClosed();
    @HAVE_CLASSPATH_TRUE@  }
    @HAVE_CLASSPATH_TRUE@else
    @HAVE_CLASSPATH_TRUE@  {
    @HAVE_CLASSPATH_TRUE@    return super.isClosed();
    @HAVE_CLASSPATH_TRUE@  }
    @HAVE_CLASSPATH_FALSE@throw new UnsupportedOperationException("1.4 methods not enabled");
  }

  @HAVE_1_4_TRUE@public SocketAddress getRemoteSocketAddress()
  @HAVE_1_4_TRUE@{
  @HAVE_1_4_TRUE@  if (underlyingSocket != null)
  @HAVE_1_4_TRUE@    {
  @HAVE_1_4_TRUE@      return underlyingSocket.getRemoteSocketAddress();
  @HAVE_1_4_TRUE@    }
  @HAVE_1_4_TRUE@  else
  @HAVE_1_4_TRUE@    {
  @HAVE_1_4_TRUE@      return super.getRemoteSocketAddress();
  @HAVE_1_4_TRUE@    }
  @HAVE_1_4_TRUE@}

  public void setOOBInline(boolean flag) throws SocketException
  {
    @HAVE_1_4_TRUE@if (underlyingSocket != null)
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    underlyingSocket.setOOBInline(flag);
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_TRUE@else
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    super.setOOBInline(flag);
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_FALSE@throw new UnsupportedOperationException("1.4 methods not enabled");
  }

  public boolean getOOBInline() throws SocketException
  {
    @HAVE_1_4_TRUE@if (underlyingSocket != null)
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    return underlyingSocket.getOOBInline();
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_TRUE@else
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    return super.getOOBInline();
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_FALSE@throw new UnsupportedOperationException("1.4 methods not enabled");
  }

  public void setKeepAlive(boolean flag) throws SocketException
  {
    @HAVE_1_4_TRUE@if (underlyingSocket != null)
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    underlyingSocket.setKeepAlive(flag);
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_TRUE@else
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    super.setKeepAlive(flag);
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_FALSE@throw new UnsupportedOperationException("1.4 methods not enabled");
  }

  public boolean getKeepAlive() throws SocketException
  {
    @HAVE_1_4_TRUE@if (underlyingSocket != null)
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    return underlyingSocket.getKeepAlive();
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_TRUE@else
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    return super.getKeepAlive();
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_FALSE@throw new UnsupportedOperationException("1.4 methods not enabled");
  }

  public void setTrafficClass(int clazz) throws SocketException
  {
    @HAVE_1_4_TRUE@if (underlyingSocket != null)
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    underlyingSocket.setTrafficClass(clazz);
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_TRUE@else
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    super.setTrafficClass(clazz);
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_FALSE@throw new UnsupportedOperationException("1.4 methods not enabled");
  }

  public int getTrafficClass() throws SocketException
  {
    @HAVE_1_4_TRUE@if (underlyingSocket != null)
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    return underlyingSocket.getTrafficClass();
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_TRUE@else
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    return super.getTrafficClass();
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_FALSE@throw new UnsupportedOperationException("1.4 methods not enabled");
  }

  public void setReuseAddress(boolean flag) throws SocketException
  {
    @HAVE_1_4_TRUE@if (underlyingSocket != null)
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    underlyingSocket.setReuseAddress(flag);
    @HAVE_1_4_TRUE@  }
    @HAVE_1_4_TRUE@else
    @HAVE_1_4_TRUE@  {
    @HAVE_1_4_TRUE@    super.setReuseAddress(flag);
 public static final String DATATYPEFACTORY_PROPERTY = "javax.xml.datatype.DatatypeFactory";

  /**
   * JAXP 1.3 default implementation class name.
   */
  public static final java.lang.String DATATYPEFACTORY_IMPLEMENTATION_CLASS = "gnu.xml.datatype.JAXPDatatypeFactory";

  protected DatatypeFactory()
  {
  }

  /**
   * Returns a new factory instance.
   */
  public static DatatypeFactory newInstance()
    throws DatatypeConfigurationException
  {
    try
      {
        Class t = Class.forName(DATATYPEFACTORY_IMPLEMENTATION_CLASS);
        return (DatatypeFactory) t.newInstance();
      }
    catch (Exception e)
      {
        throw new DatatypeConfigurationException (e);
      }
  }

  /**
   * Returns a new duration from its string representation.
   * @param lexicalRepresentation the lexical representation of the
   * duration, as specified in XML Schema 1.0 section 3.2.6.1.
   */
  public abstract Duration newDuration(String lexicalRepresentation);

  /**
   * Returns a new duration.
   * @param durationInMilliseconds the duration in milliseconds
   */
  public abstract Duration newDuration(long durationInMilliSeconds);

  /**
   * Returns a new duration by specifying the individual components.
   * @param isPositive whether the duration is positive
   * @param years the number of years
   * @param months the number of months
   * @param days the number of days
   * @param hours the number of hours
   * @param minutes th number of minutes
   * @param seconds the number of seconds
   */
  public abstract Duration newDuration(boolean isPositive,
                                       BigInteger years,
                                       BigInteger months,
                                       BigInteger days,
                                       BigInteger hours,
                                       BigInteger minutes,
                                       BigDecimal seconds);

  /**
   * Returns a new duration by specifying the individual components.
   * @param isPositive whether the duration is positive
   * @param years the number of years
   * @param months the number of months
   * @param days the number of days
   * @param hours the number of hours
   * @param minutes th number of minutes
   * @param seconds the number of seconds
   */
  public Duration newDuration(boolean isPositive,
                              int years,
                              int months,
                              int days,
                              int hours,
                              int minutes,
                              int seconds)
  {
    return newDuration(isPositive,
                       BigInteger.valueOf((long) years),
                       BigInteger.valueOf((long) months),
                       BigInteger.valueOf((long) days),
                       BigInteger.valueOf((long) hours),
                       BigInteger.valueOf((long) minutes),
                       BigDecimal.valueOf((long) seconds));
  }

  /**
   * Returns a new dayTimeDuration from its string representation.
   * @param lexicalRepresentation the lexical representation of the
   * duration, as specified in XML Schema 1.0 section 3.2.6.1.
   */
  public Duration newDurationDayTime(String lexicalRepresentation)
  {
    return newDuration(lexicalRepresentation);
  }

  /**
   * Returns a new dayTimeDuration.
   * @param durationInMilliseconds the duration in milliseconds
   */
  public Duration newDurationDayTime(long durationInMilliseconds)
  {
    // TODO xmlSchemaType
    return newDuration(durationInMilliseconds);
  }

  /**
   * Returns a new dayTimeDuration by specifying the individual components.
   * @param isPositive whether the duration is positive
   * @param days the number of days
   * @param hours the number of hours
   * @param minutes th number of minutes
   * @param seconds the number of seconds
   */
  public Duration newDurationDayTime(boolean isPositive,
                                     BigInteger days,
                                     BigInteger hours,
                                     BigInteger minutes,
                                     BigDecimal seconds)
  {
    return newDuration(isPositive,
                       null,
                       null,
                       days,
                       hours,
                       minutes,
                       seconds);
  }

  /**
   * Returns a new dayTimeDuration by specifying the individual components.
   * @param isPositive whether the duration is positive
   * @param days the number of days
   * @param hours the number of hours
   * @param minutes th number of minutes
   * @param seconds the number of seconds
   */
  public Duration newDurationDayTime(boolean isPositive,
                                     int days,
                                     int hours,
                                     int minutes,
                                     int seconds)
  {
    return newDuration(isPositive,
                       null,
                       null,
                       BigInteger.valueOf((long) days),
                       BigInteger.valueOf((long) hours),
                       BigInteger.valueOf((long) minutes),
                       BigDecimal.valueOf((long) seconds));
  }

  /**
   * Returns a new yearMonthDuration from its string representation.
   * @param lexicalRepresentation the lexical representation of the
   * duration, as specified in XML Schema 1.0 section 3.2.6.1.
   */
  public Duration newDurationYearMonth(String lexicalRepresentation)
  {
    return newDuration(lexicalRepresentation);
  }

  /**
   * Returns a new yearMonthDuration.
   * @param durationInMilliseconds the duration in milliseconds
   */
  public Duration newDurationYearMonth(long durationInMilliseconds)
  {
    // TODO xmlSchemaType
    return newDuration(durationInMilliseconds);
  }

  /**
 
   */
  public Duration newDurationYearMonth(boolean isPositive,
                                       BigInteger years,
                                       BigInteger months)
  {
    return newDuration(isPositive,
                       years,
                       months,
                       null,
                       null,
                       null,
                       null);
  }

  /**
   