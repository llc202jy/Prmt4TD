public class AnnotationReader {
	
	private static Map<Class, String> idProperties = new HashMap<Class, String>();

	public static String getSQLName(Class domainObjectClass){
		if(domainObjectClass.getAnnotation(SQLName.class) != null){
			SQLName name = (SQLName)domainObjectClass.getAnnotation(SQLName.class);
			return name.value();
		}
		return domainObjectClass.getSimpleName();
	}
	
	public static Command getCommand(Class classe, String commandType){
		
		//Verificando se est? na lista de n?o suportados
		if(classe.getAnnotation(NotSupportedCommands.class) != null){
			NotSupportedCommands notSupported = (NotSupportedCommands)classe.getAnnotation(NotSupportedCommands.class);
			String[] types = notSupported.value();
			for(int i = 0; i < types.length; i++){
				if(types[i].equals(commandType)){
					throw new NotSupportedOperationException("O comando "+commandType+ " ? explicitamente n?o suportado para a classe " + classe.getSimpleName() );
				}
			}
		}
		
		//Verificando se existe alguma classe diferente para retornar
		if(classe.getAnnotation(Commands.class) != null){
			Commands commands = (Commands)classe.getAnnotation(Commands.class);
			String[] types = commands.type();
			for(int i = 0; i < types.length; i++){
				if(types[i].equals(commandType)){
					try {
						return (Command) commands.classes()[i].newInstance();
					} catch (Throwable e) {
						throw new NotSupportedOperationException("Houve problemas ao criar o comando "+commandType+ " para a classe " + classe.getSimpleName() );
					}
				}
			}
		}
		
		if(commandType == CommandTypes.INSERT)
			return new InsertCommand();
		if(commandType == CommandTypes.UPDATE)
			return new UpdateCommand();
		if(commandType == CommandTypes.DELETE)
			return new DeleteCommand();
		if(commandType == CommandTypes.LIST)
			return new ListCommand();
		if(commandType == CommandTypes.GET_BY_ID)
			return new GetByIdCommand();
		if(commandType == CommandTypes.GET_COMPLETE_BY_ID)
			return new GetCompleteByIdComand();
		if(commandType == CommandTypes.SEARCH)
			return new SearchCommand();
		
		throw new NotSupportedOperationException("N?o foi encontrado o comando "+commandType+ " para a classe " + classe.getSimpleName() );
	}
	
	public static boolean isDependenceOfType(Dependence dependence, String type){
		String[] values = dependence.value();
		for(String value : values)
			if(value.equals(type))
				return true;
		return false;
	}
	
	public static List<String> getFieldNamesWithDependence(Class objClass, String type){
		List<String> list = new ArrayList<String>();
		for(Field field : objClass.getDeclaredFields()){
			if(field.getAnnotation(Dependence.class) != null && isDependenceOfType((Dependence)field.getAnnotation(Dependence.class),type)){
				list.add(field.getName());
			}
		}
		return list;
	}
	
	public static List<String> getFieldNamesWithDependence(Class objClass){
		List<String> list = new ArrayList<String>();
		for(Field field : objClass.getDeclaredFields()){
			if(field.getAnnotation(Dependence.class) != null){
				list.add(field.getName());
			}
		}
		return list;
	}
		//Procurando por m?todos de acesso chamados getId e setId
		for (Method method : methods) {
			if(method.getName().equals("getId")){
				return "id";
			}
		}
		
		throw new NoIdDefinedException(beanClass.getName() + " doesn't have an id defined!");
	}

	public static void setId(Object bean, Object id) {
		if (bean instanceof DomainObject) {
			((DomainObject) bean).setId(id);
			return;
		}
		if (AnnotationReader.idProperties.containsKey(bean.getClass())) {
			BeanUtils.setProperty(bean, AnnotationReader.idProperties.get(bean.getClass()), id);
			return;
		}
		String idProperty = getIdProperty(bean.getClass());
		AnnotationReader.idProperties.put(bean.getClass(), idProperty);
		BeanUtils.setProperty(bean, idProperty, id);
	}

	public static Object getId(Object bean) {
		if (bean instanceof DomainObject) {
			return ((DomainObject) bean).getId();
		}
		if (AnnotationReader.idProperties.containsKey(bean.getClass())) {
			return BeanUtils.getProperty(bean, AnnotationReader.idProperties.get(bean.getClass()));
		}
		String idProperty = getIdProperty(bean.getClass());
		AnnotationReader.idProperties.put(bean.getClass(), idProperty);
		return BeanUtils.getProperty(bean, idProperty);
	}

	


