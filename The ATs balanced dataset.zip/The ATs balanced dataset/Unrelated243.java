<group>Buddies</group>
					<group>Family</group>
					<group>Naya Yug</group>
					
				</groups>
				
				<buddies>
					<buddy username="HrithikRohan87">
						<groups>Naya Yug</groups>
						<presence>
							<status>offline</status>
						</presence>
					</buddy>
					<buddy username="BulwinkleofDoom">
						<groups>Buddies</groups>
						<presence>
							<status>online</status>
							<statusmessage>Status Message</statusmessage>
						</presence>
					</buddy>
				</buddies>
			
			
			</buddylist>
		</service>
	*/
	public static void parseBuddyList(XmlPullParser xpp) throws Exception
	{
		if (instance == null)
			throw new Exception("BuddyList.parseBuddyList(): instance not created yet!");
			
		{		//DEBUG
			System.out.println("BuddyList.parseBuddyList(): parsing...");
		}		//DEBUG
		
		int eventType = 0;
		
		instance.buddyListLoaded = false;
		
		do
		{
			eventType = xpp.getEventType();
			
			if (eventType == XmlPullParser.START_TAG)
			{
				String name = xpp.getName();
				name = name.toLowerCase();
				
				if ("buddy".equals(name))
				{
					//get the username
					String username = xpp.getAttributeValue(null,"username");
					
					if (username == null)	//krap
						throw new Exception("BuddyList.parseBuddyList(): username attribute of buddy tag is null!");
						
					//create an entry in the hashmap
					BuddyList.Buddy buddy = instance.createBuddy();
					
					String lw = username.toLowerCase();
					
					instance.buddies.put(lw,buddy);
					
					//now use buddy to parse the rest
					buddy.parseBuddy(xpp);	//we know control will be returned to us... someday... (I hope)
				}
				
				//now we parse for groups
				else if ("group".equals(name))
				{
					String groupname = xpp.nextText();
					
					System.out.println("BuddyList.parseBuddyList(): Parsed group: " + groupname);
					
					BuddyList.Group group = instance.createGroup();
					
					group.setName(groupname);
					
					//push it in the linked list
					instance.groups.put(group.getName(),group);
					
				}
				
				
			}
			else if (eventType == XmlPullParser.END_TAG)
			{
				String name = xpp.getName();
				name = name.toLowerCase();
				
				if ("buddylist".equals(name))
				{
				
					instance.buddyListLoaded = true;
					
					//okay we're done parsing - tell the BuddyListPanel
					//we're ready to rock and roll
					BuddyListPanel.setBuddyList();
					
					
