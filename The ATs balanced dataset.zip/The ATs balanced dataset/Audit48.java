ublic partial class admin_audits : System.Web.UI.Page
{
    #region Events
    String redirect_page = "home.aspx";
    SecurityModule security;
    LoginUserInfo userInfo;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["security"] == null)
            {
                //Response.Redirect(Common.sLoginPage);
                //return;
                Response.Redirect(Common.sLoginPage);
            }

            //CHECK FOR SECURITY
            userInfo = (LoginUserInfo)Session["security"];
            security = userInfo.getModuleSecurity("Audit Trail Management");
            if (security == null)
                Response.Redirect(redirect_page);
            else
            {
                if (security.getView() == 0)
                    Response.Redirect(redirect_page);
                if (security.getExport() == 0)
                    btnExport.Visible = false;
            }
            if (!Page.IsPostBack)
            {
                this.Master.setHeader("setup");
                this.Master.setHeaderText("Audit Trail List");
                this.Master.setBreadcrumb("<img src='../images/white_arrow_2.jpg' width='10px' height='10px' /> Audit Trail");


                //set gridview row count
                string sGvRowCount = SqlDbClass.getGVRowCount().ToString();
                if (sGvRowCount.Trim() != string.Empty)
                    if (Common.isNumeric(sGvRowCount))
                        gvAudit.PageSize = int.Parse(sGvRowCount);

                if (gvAudit.PageIndex == gvAudit.PageCount - 1)
                    setPagerBtn(false, false);
                else
                    setPagerBtn(false, true);

            }

            bindGrid();
            setPager();

            //show/hide search box
            divSearch.Attributes["style"] = "display:" + hdSearch.Value.Trim();
            if (hdSearch.Value.Trim() == "none")
                imgSearch.ImageUrl = "../images/down2.jpg";
            else
                imgSearch.ImageUrl = "../images/up2.jpg";
        }
        catch (Exception ex)
        {
            lblMsg.Text = "System cannot load the page successfully.";
        }
    }

    protected void btnSearch2_Click(object sender, EventArgs e)
    {
        try
        {
            //DECLARE CRITERIA VALUE
            string cValue = txtByDate.Text.Trim();

            //GET CRITERIA FIELD
            //string cField = hdCriField.Value;
            DateTime d;
            if (DateTime.TryParse(cValue, out d))
            {
                hdSelectCmd.Value = "SELECT audit_id AS Id,access_user,access_login_name,access_func,access_date, access_desc "
                                    + " FROM [AuditTrail] WHERE DateDiff(dd,access_date,'" + cValue + "')=0";

            }
            else
            {
                hdSelectCmd.Value = "SELECT audit_id AS Id,access_user,access_login_name,access_func,access_date, access_desc "
                                    + " FROM [AuditTrail] WHERE [access_date] = '1/1/1900'";
            }
            bindGrid();

            gvAudit.PageIndex = 0;
            setPagerBtn(false, true);
            showRowInfo();
            restoreCriteriaDate();
        }
        catch (Exception ex)
        {
            lblMsg.Text = "System produced error in searching.";
            Common.MessageBox(lblMsg.Text, this);
        }
    }
      
    
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            //DECLARE CRITERIA VALUE
            string cValue = txtByName.Text.Trim();

            //GET CRITERIA FIELD
            //string cField = hdCriField.Value; 

            //FOR LOGIN NAME FIELD
            if(ddlSearchCriteria.Value.Trim() == "0")
                hdSelectCmd.Value = "SELECT audit_id AS Id,access_login_name,access_func, access_desc,access_date "
                                    + " FROM [AuditTrail] WHERE [access_login_name] LIKE '%" + cValue + "%'";
            else
                hdSelectCmd.Value = "SELECT audit_id AS Id,access_login_name,access_func, access_desc,access_date "
                                    + " FROM [AuditTrail] WHERE [access_desc] LIKE '%" + cValue + "%'";

            
            bindGrid();
        
            gvAudit.PageIndex = 0;
            setPagerBtn(false, true);
            showRowInfo();
        }
        catch (Exception ex)
        {
            lblMsg.Text = "System produced error in searching.";
            Common.MessageBox(lblMsg.Text, this);
        }
    }
            
    protected void lbtStart_Click(object sender, EventArgs e)
    {
        try
        {
            gvAudit.PageIndex = 0;
            bindGrid();

            //show row info
            showRowInfo();

            //setting the button
            setPagerBtn(false, true);
        }
        catch (Exception ex)
        {
            lblMsg.Text = "System produced error in going to start page.";
            Common.MessageBox(lblMsg.Text, this);
        }

    }

    protected void lbtPrevious_Click(object sender, EventArgs e)
    {
        try
        {
            if (gvAudit.PageIndex != 0)
                gvAudit.PageIndex = gvAudit.PageIndex - 1;

            //bind grid
            bindGrid();

            if (gvAudit.PageIndex == 0)
                setPagerBtn(false, true);
            else
                setPagerBtn(true, true);

            //show row info
            showRowInfo();
        }
        catch (Exception ex)
        {
            lblMsg.Text = "System produced error in going to previous page.";
            Common.MessageBox(lblMsg.Text, this);
        }
    }

    protected void lbtNext_Click(object sender, EventArgs e)
    {
        try
        {
            if (gvAudit.PageIndex != (gvAudit.PageCount - 1))
                gvAudit.PageIndex = gvAudit.PageIndex + 1;

            bindGrid();

            if (gvAudit.PageIndex == gvAudit.PageCount - 1)
                setPagerBtn(true, false);
            else
                setPagerBtn(true, true);

            //show row info
            showRowInfo();
        }
        catch (Exception ex)
        {
            lblMsg.Text = "System produced error in going to next page.";
            Common.MessageBox(lblMsg.Text, this);
        }
    }

    protected void lbtEnd_Click(object sender, EventArgs e)
    {
        try
        {
            gvAudit.PageIndex = gvAudit.PageCount - 1;
            bindGrid();

            //setting the button
            setPagerBtn(true, false);

            //show row info
            showRowInfo();
        }
        catch (Exception ex)
        {
            lblMsg.Text = "System produced error in going to end page.";
            Common.MessageBox(lblMsg.Text, this);
        }

    }

    protected void gvAudit_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DateTime dt = DateTime.Parse(e.Row.Cells[4].Text);
                e.Row.Cells[4].Text = dt.ToString("dd MMM yyyy hh:mm:ss tt");
            }

            //adding img for sorting
            if (e.Row.RowType == DataControlRowType.Header)
            {
                int iCellIndex = -1;

                for (int i = 0; i < gvAudit.Columns.Count; i++)
                {
                    DataControlField field = gvAudit.Columns[i];

                    Image img = new Image();
                    //e.Row.Cells[gvAuditTrail.Columns.IndexOf(field)].CssClass = "headerstyle";

                    if (field.SortExpression == gvAudit.SortExpression)
                    {
                        //iCellIndex = gvAuditTrail.Columns.IndexOf(field);

                        img.ImageUrl = gvAudit.SortDirection == SortDirection.Ascending ?
                            "../images/sort_asc.gif" : "../images/sort_desc.gif";
                        e.Row.Cells[gvAudit.Columns.IndexOf(field)].Controls.AddAt(0, img);
                    }
                    else
                    {
                        img.ImageUrl = "../images/arrow_down.gif";
                        e.Row.Cells[gvAudit.Columns.IndexOf(field)].Controls.AddAt(0, img);
                    }
                }

                if (iCellIndex > -1)
                {
                    //e.Row.Cells[iCellIndex].CssClass = gvAuditTrail.SortDirection == SortDirection.Ascending ?
                    //"sortascheaderstyle" : "sortdescheaderstyle";

                }
            }//end of if header

            if (e.Row.RowType == DataControlRowType.Footer)
            {

                //Show Current Row and All Row Count 
                showRowInfo();
            }

        }
        catch (Exception ex)
        {
            lblMsg.Text = "System produced an error in loading data as a list view.";
        }
    }

    protected void gvAudit_Sorting(object sender, GridViewSortEventArgs e)
    {
        try
        {
            //adding sort image to header
            Image img = new Image();
            if (e.SortDirection == SortDirection.Ascending)
            {
                img.ImageUrl = "../images/sort_arrowup.gif";
                img.AlternateText = "Ascending Order";
            }
            else
            {
                img.ImageUrl = "../images/sort_arrowdown.gif";
                img.AlternateText = "Decending Order";
            }

            setPagerBtn(false, true);
            showRowInfo();
            bindGrid();
        }
        catch (Exception ex)
        {
            lblMsg.Text = "System produced error in sorting the list.";
            Common.MessageBox(lblMsg.Text, this);
        }
    }

    protected void SqlDataSource1_Selected(object sender, SqlDataSourceStatusEventArgs e)
    {
        hdRowCount.Value = e.AffectedRows.ToString();
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        try
        {
            StringBuilder sb = new StringBuilder();
            string sFileName = "Audits_" + DateTime.Today.ToString("ddMMyyyy");

            //Add Response header 
            Response.Clear();
            Response.AddHeader("content-disposition", string.Format("attachment;filename={0}.csv", sFileName));
            Response.Charset = "";
            Response.ContentType = "application/vnd.xls";

            //Add Header to Excel file            
            for (int i = 1; i < gvAudit.Columns.Count; i++)
            {
                if (i != 1)
                    sb.Append(",");
                sb.Append(gvAudit.Columns[i].HeaderText.Trim());
            }
            Response.Write(sb.ToString() + "\n");
            Response.Flush();

            //Add Data to Excel file
            //Reterive data from db in order to get all rows since Gridview only have rows for one page
            // if there are many pages in gridview
            DataSet ds = SqlDbClass.ExecuteDataSet(hdSelectCmd.Value.Trim());
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                sb = new StringBuilder();
                for (int j = 1; j < ds.Tables[0].Columns.Count; j++)
                {
                    if (j != 1)
                        sb.Append(",");
                    if (j == 4)
                    {
                        if (ds.Tables[0].Rows[i][j].ToString() != "")
                        {
                            DateTime dt = DateTime.Parse(ds.Tables[0].Rows[i][j].ToString());
                            string sDt = dt.ToString(SqlDbClass.getDTFormat().ToString());
                            sb.Append(sDt);
                        }
                        sb.Append("");
                    }
                    else
                    {
                        string sTemp = ds.Tables[0].Rows[i][j].ToString().Replace("\t", " ");
                        sTemp = sTemp.Replace("\r", string.Empty);
                        sTemp = sTemp.Replace("\n", " ");
                        sTemp = sTemp.Replace(",", " ");
                        sb.Append(sTemp);                       
                    }
                }
                Response.Write(sb.ToString() + "\n");
                Response.Flush();
            }

            Response.End();
        }
        catch (Exception ex)
        {
            lblMsg.Text = "System cannot export Excel file.";
            Common.MessageBox(lblMsg.Text, this);
        }
    }

    protected void btnExportAll_Click(object sender, EventArgs e)
    {
        try
        {
            string sQuery;
            StringBuilder sb = new StringBuilder();
            string sFileName = "CandidateList_" + DateTime.Today.ToString("ddMMyyyy");

            //Add Response header 
            Response.Clear();
            string attachment = string.Format("attachment; filename={0}.csv", sFileName);
            Response.ClearContent();
            Response.AddHeader("content-disposition", attachment);
            Response.ContentType = "application/vnd.csv";

            sQuery = "SELECT access_user,(SELECT role_name FROM [User],Role WHERE user_role_id = role_id AND user_login_name = access_login_name) as [role_name]"
                    + ",access_func,access_desc,access_date FROM [AuditTrail] ORDER BY access_date DESC";

            //Add Header to Excel file 
            Response.Write("User Name, Role, Accessed Function, Description, Accessed Date" + "\n");
            Response.Flush();

            //Add Data to Excel file
            //Reterive data from db in order to get all rows since Gridview only have rows for one page
            // if there are many pages in gridview
            DataSet ds = SqlDbClass.ExecuteDataSet(sQuery);
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                sb = new StringBuilder();
                string tab = "";
                for (int j = 0; j < ds.Tables[0].Columns.Count; j++)
                {
                    string sData;
                    DateTime dt;

                    sData = ds.Tables[0].Rows[i][j].ToString();
                    sData = Common.escapeCsvField(sData);
                    sData = Common.removeHTMLTab(sData);

                    if (DateTime.TryParse(sData, out dt))
                    {
                        string sDt = dt.ToString(SqlDbClass.getDTFormat().ToString());
                        sb.Append(tab + sDt);
                    }
                    else
                    {
                        sb.Append(tab + sData);
                    }

                    tab = ",";
                }
                Response.Write(sb.ToString() + "\n");
                Response.Flush();
            }

        }
        catch (Exception ex)
        {
            lblMsg.Text = "System cannot export Excel file.";
            Common.MessageBox(lblMsg.Text, this);
        }

        Response.Flush();
        Response.End();
    }

    #endregion 

    #region User Defined Functions

    protected void bindGrid()
    {
        SqlDataSource1.SelectCommand = hdSelectCmd.Value;
        gvAudit.DataBind();
    }

    protected void showRowInfo()
    {
        //Show Current Row and All Row Count
        if (gvAudit.PageIndex == gvAudit.PageCount - 1)
        {
            lblPage.Text = "(" + (1 + (gvAudit.PageSize * gvAudit.PageIndex)) + " - " + hdRowCount.Value + " of " + hdRowCount.Value + ")";
            lblPage1.Text = lblPage.Text;
        }
        else
        {
            lblPage.Text = "(" + (1 + (gvAudit.PageSize * gvAudit.PageIndex)) + " - " + (gvAudit.PageSize * (gvAudit.PageIndex + 1)) + " of " + hdRowCount.Value + ")";
            lblPage1.Text = lblPage.Text;
        }
    }

    protected void setPagerBtn(bool blPrevious, bool blNext)
    {
        lbtPrevious.Enabled = blPrevious;
        lbtPrevious1.Enabled = blPrevious;
        lbtNext.Enabled = blNext;
        lbtNext1.Enabled = blNext;

    }

    protected void restoreCriteriaDate()
    {
        System.Text.StringBuilder b = new System.Text.StringBuilder();
        b.Append("<script language='javascript'>\n");
        b.Append("var f = document.getElementById('ddlSearchCriteria');\n");
        b.Append("f.value = 1;\n");
        b.Append("var v = document.getElementById('byDate');\n");
        b.Append("v.style.display = 'inline';\n");
        b.Append("v = document.getElementById('byName');\n");
        b.Append("v.style.display = 'none';\n");
        b.Append("v = document.getElementById('byNameSearchButton');\n");        
        b.Append("v.style.display = 'none';\n");
        b.Append("v = document.getElementById('byDateSearchButton');\n");
        b.Append("v.style.display = 'inline';\n");
        b.Append("v = document.getElementById('byNameVal');\n");
        b.Append("v.style.display = 'none';\n");        
        b.Append("</script>");

        Type t = this.GetType();        
        if (!ClientScript.IsStartupScriptRegistered(t, "PopupScript"))
            ClientScript.RegisterStartupScript(t, "PopupScript", b.ToString());                

        //Type t = this.GetType();
        
        //if (!ClientScript.IsClientScriptBlockRegistered(t, "PopupScript"))
        //    ClientScript.RegisterClientScriptBlock(t, "PopupScript", b.ToString());

    }

    protected void setPager()
    {
        bool blPrevious = true;
        bool blNext = true;

        /** Enable or Disable pager button **/
        if (gvAudit.PageCount == 1)  //only one page
            blPrevious = blNext = false;
        else if (gvAudit.PageIndex == 0)
            blPrevious = false;
        else if (gvAudit.PageIndex == gvAudit.PageCount - 1)
            blNext = false;
        
        lbtPrevious.Enabled = blPrevious;
        lbtPrevious1.Enabled = blPrevious;
        lbtNext.Enabled = blNext;
        lbtNext1.Enabled = blNext;

        string sCurrentRecords = string.Empty;
        if ((gvAudit.PageSize * (gvAudit.PageIndex + 1)) < int.Parse(hdRowCount.Value))
            sCurrentRecords = (gvAudit.PageSize * (gvAudit.PageIndex + 1)).ToString();
        else
            sCurrentRecords = hdRowCount.Value;

        lblPage.Text = "(" + (1 + (gvAudit.PageSize * gvAudit.PageIndex)) + " - " + sCurrentRecords + " of " + hdRowCount.Value + ")";
        lblPage1.Text = lblPage.Text;
    } 

    #endregion
    