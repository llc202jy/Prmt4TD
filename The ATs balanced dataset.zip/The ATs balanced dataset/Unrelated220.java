using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using CCNetConfig.Core;
using System.IO;
using System.Configuration;
using System.Net;
using CCNetConfig.BugTracking;
using CCNetConfig.BugTracking.Configuration.Handlers;
using System.Xml;
using CCNetConfig.Core.Configuration;
using CCNetConfig.Updater.Core;
using CCNetConfig.UI;
namespace CCNetConfig {
/// <summary>
/// The static class that starts the application
/// </summary>
  public static class Program {

    private static CCNetConfigConfiguration _configuration = null;
    private static BugTracker _bugTracker = null;
    private static CommandLineArguments arguments = null;
    /// <summary>
    /// Start the application
    /// </summary>
    /// <param name="args">The args.</param>
    [STAThread()]
    static void Main ( string[] args ) {
      try {
        Application.SetUnhandledExceptionMode ( UnhandledExceptionMode.CatchException, false );
      } catch { }

      Application.EnableVisualStyles ();
      AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler ( Program.OnUnhandledException );

      arguments = new CommandLineArguments ( args );
      Util.ShowSpashScreen ( );
      MainForm form = new MainForm ();
      try {
        Application.Run ( form );
      } catch ( Exception ex ) {
        XmlDocument doc = null;
        if (form != null && !form.IsDisposed )
          doc = CruiseControlToXmlDocument ( form.CruiseControl );
        Program.BugTracker.SubmitExceptionDialog ( null, ex, doc );
      }
    }

    /// <summary>
    /// Called when unhandled exception occurs.
    /// </summary>
    /// <param name="sender">The sender.</param>
    /// <param name="e">The <see cref="System.UnhandledExceptionEventArgs"/> instance containing the event data.</param>
    private static void OnUnhandledException ( object sender, UnhandledExceptionEventArgs e ) {
      Exception ex = e.ExceptionObject as Exception;
      Program.BugTracker.SubmitExceptionDialog ( null, ex, (XmlDocument)null );
      //Environment.Exit ( 1 );
    }

    /// <summary>
    /// Gets the bug tracker.
    /// </summary>
    /// <value>The bug tracker.</value>
    public static BugTracker BugTracker {
      get {
        if ( _bugTracker == null ) {
          BugTrackingConfigurationSectionHandler btcsh = new BugTrackingConfigurationSectionHandler ();
          XmlDocument bugTrackerDoc = new XmlDocument ();
          bugTrackerDoc.Load (Path.Combine (Application.StartupPath, Program.Configuration["BugTracking"].Path));
          _bugTracker = btcsh.Create (null, null, bugTrackerDoc.DocumentElement);
        }

        return _bugTracker;
      }
    }

    /*public static CCNetConfigConfiguration Configuration {
      get {
        return CCNetConfig.Core.Util.Configuration;
      }
    }*/

    /// <summary>
    /// Gets the configuration.
    /// </summary>
    /// <value>The configuration.</value>
    public static CCNetConfigConfiguration Configuration {
      get {
        if ( _configuration == null )
          _configuration = (CCNetConfigConfiguration)ConfigurationManager.GetSection ( "CCNetConfigConfiguration" );
        return _configuration;
      }
    }

    /// <summary>
    /// Gets the command line arguments.
    /// </summary>
    /// <value>The command line arguments.</value>
    public static CommandLineArguments CommandLineArguments { get { return arguments; } }

    /// <summary>
    /// Cruises the control to XML document.
    /// </summary>
    /// <param name="cc">The cc.</param>
    /// <returns></returns>
    public static XmlDocument CruiseControlToXmlDocument ( CruiseControl cc ) {
      XmlDocument tdoc = new XmlDocument ();
      try {
        if ( cc != null ) {
          XmlElement ele = cc.Serialize ();
          if ( ele != null )
            tdoc.ImportNode ( ele, true );
        }
      } catch { }
      return tdoc;
    }
  }
}
using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.Specialized;
using System.Text.RegularExpressions;
using System.Collections;

namespace CCNetConfig.Updater.Core {
  /// <summary>
  /// Command line parser.  
  /// </summary>
  public class CommandLineArguments {
    // Variables
    private new Dictionary<string,string> namedParameters;
    private List<string> unnamedParameters;
    /// <summary>
    /// Creates a <see cref="CommandLineArguments"/> object to parse
    /// command lines.
    /// </summary>
    /// <param name="args">The command line to parse.</param>
    public CommandLineArguments ( string[] args ) {
      namedParameters = new Dictionary<string,string> ();
      unnamedParameters = new List<string> ();
      Regex splitter = new Regex ( Properties.Strings.ArgumentsSplitterRegex, RegexOptions.IgnoreCase | RegexOptions.Compiled );
      Regex remover = new Regex ( Properties.Strings.ArgumentsRemoverRegex, RegexOptions.IgnoreCase | RegexOptions.Compiled );
      string parameter = null;
      string[] parts;

      foreach ( string str in args ) {
        // Do we have a parameter (starting with -, /, or --)?
        if ( str.StartsWith ( "-" ) || str.StartsWith ( "/" ) ) {
          // Look for new parameters (-,/ or --) and a possible
          // enclosed value (=,:)
          parts = splitter.Split ( str, 3 );
          switch ( parts.Length ) {
            // Found a value (for the last parameter found
            // (space separator))
            case 1:
              if ( parameter != null ) {
                if ( !namedParameters.ContainsKey ( parameter ) ) {
                  parts[0] =
                      remover.Replace ( parts[0], "$1" );
                  namedParameters.Add (
                      parameter, parts[0] );
                }
                parameter = null;
              }
              // else Error: no parameter waiting for a value
              // (skipped)
              break;
            // Found just a parameter
            case 2:
              // The last parameter is still waiting. With no
              // value, set it to true.
              if ( parameter != null ) {
                if ( !namedParameters.ContainsKey ( parameter ) )
                  namedParameters.Add ( parameter, "true" );
              }
              parameter = parts[1];
              break;
            // parameter with enclosed value
            case 3:
              // The last parameter is still waiting. With no
              // value, set it to true.
              if ( parameter != null ) {
                if ( !namedParameters.ContainsKey ( parameter ) )
                  namedParameters.Add ( parameter, "true" );
              }
              parameter = parts[1];
              // Remove possible enclosing characters (",')
              if ( !namedParameters.ContainsKey ( parameter ) ) {
                parts[2] = remover.Replace ( parts[2], "$1" );
                namedParameters.Add ( parameter, parts[2] );
              }
              parameter = null;
              break;
          }
        } else {
          unnamedParameters.Add ( str );
        }
      }
      // In case a parameter is still waiting
      if ( parameter != null ) {
        if ( !namedParameters.ContainsKey ( parameter ) )
          namedParameters.Add ( parameter, "true" );
      }
    }

    /// <summary>
    /// Retrieves the parameter with the specified name.
    /// </summary>
    /// <param name="name">
    /// The name of the parameter. The name is case insensitive.
    /// </param>
    /// <returns>
    /// The parameter or <c>null</c> if it can not be found.
    /// </returns>
    public string this[string name] {
      get {
        return ( namedParameters[name] );
      }
    }

    /// <summary>
    /// Retrieves an unnamed parameter (that did not start with '-'
    /// or '/').
    /// </summary>
    /// <param name="index">The index of the unnamed parameter.</param>
    /// <returns>The unnamed parameter or <c>null</c> if it does not
    /// exist.</returns>
    /// <remarks>
    /// Primarily used to retrieve filenames which extension has been
    /// associated to the application.
    /// </remarks>
    public string this[int index] {
      get {
        return (string)( index < unnamedParameters.Count ?
            unnamedParameters[index] :
        null );
      }
    }

    /// <summary>
    /// Gets the keys.
    /// </summary>
    /// <value>The keys.</value>
    public Dictionary<string, string>.KeyCollection Keys {
      get { return namedParameters.Keys; }
    }

    /// <summary>
    /// Gets the values.
    /// </summary>
    /// <value>The values.</value>
    public Dictionary<string, string>.ValueCollection Values {
      get { return this.namedParameters.Values; }
    }

    /// <summary>
    /// Gets the count.
    /// </summary>
    /// <value>The count.</value>
    public int Count { get { return this.UnnamedParametersCount + this.NamedParametersCount; } }

    /// <summary>
    /// Gets the unnamed parameters count.
    /// </summary>
    /// <value>The unnamed parameters count.</value>
    public int UnnamedParametersCount { get { return this.unnamedParameters.Count; } }

    /// <summary>
    /// Gets the named parameters count.
    /// </summary>
    /// <value>The named parameters count.</value>
    public int NamedParametersCount { get { return this.namedParameters.Count; } }

    /// <summary>
    /// Converts unnamed parameters to array.
    /// </summary>
    /// <returns></returns>
    public string[] UnnamedParametersToArray(  ) {
      return this.unnamedParameters.ToArray ();
    }

    /// <summary>
    /// Determines whether this contains specified param.
    /// </summary>
    /// <param name="param">The param.</param>
    /// <returns>
    /// 	<c>true</c> if this contains specified param; otherwise, <c>false</c>.
    /// </returns>
    public bool ContainsParam ( string param ) {
      return this.namedParameters.ContainsKey ( param );
    }
  }
}

using System;
using System.Collections.Generic;
using System.Text;

namespace CCNetConfig.Core {
  /// <summary>
  /// A List&lt;&gt; that implements <see cref="System.ICloneable" />
  /// </summary>
  /// <typeparam name="T"></typeparam>
  public class CloneableList<T> : List<T>, ICloneable {
    #region ICloneable Members
    /// <summary>
    /// Creates a deep copy of this collection.
    /// </summary>
    /// <returns></returns>
    public virtual CloneableList<T> Clone ( ) {
       CloneableList<T> list = new CloneableList<T> ( );
      foreach ( T item in this ) {
        if ( typeof ( T ).GetType ( ).GetInterface ( "System.ICloneable", true ) != null ) {
          ICloneable citem = item as ICloneable;
          if ( citem != null )
            list.Add ( ( T ) citem.Clone ( ) );
          else
            list.Add ( ( T ) citem );
        }
      }
      return list;
    }

    /// <summary>
    /// Creates a new object that is a copy of the current instance.
    /// </summary>
    /// <returns>
    /// A new object that is a copy of this instance.
    /// </returns>
    object ICloneable.Clone ( ) {
      return this.Clone ( );
    }

    #endregion
  }
}

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace CCNetConfig.Core {
  /// <summary>
  /// A collection of PublishersTasks
  /// </summary>
  public class PublishersTasksList : SerializableList<PublisherTask> {
    private string _typeName = string.Empty;
    /// <summary>
    /// Initializes a new instance of the <see cref="PublishersTasksList"/> class.
    /// </summary>
    /// <param name="elementName">Name of the element.</param>
    public PublishersTasksList ( string elementName ) {
      this._typeName = elementName;
    }

    /// <summary>
    /// Serializes this instance.
    /// </summary>
    /// <returns></returns>
    public override XmlElement Serialize ( ) {
      XmlDocument doc = new XmlDocument ( );
      XmlElement root = doc.CreateElement ( this._typeName );
      foreach ( PublisherTask pt in this )
        root.AppendChild ( doc.ImportNode ( pt.Serialize ( ), true ) );
      return root;
    }

    /// <summary>
    /// Deserializes the specified element.
    /// </summary>
    /// <param name="element">The element.</param>
    public override void Deserialize ( XmlElement element ) {
      if ( string.Compare ( element.Name, this._typeName, false ) != 0 )
        throw new InvalidCastException ( string.Format ( "Unable to convert {0} to a {1}", element.Name, this.GetType ( ).Name ) );
      this.Clear ( );

      if ( element != null ) {
        foreach ( XmlElement trig in element.SelectNodes ( "./*" ) ) {
          PublisherTask pt = Util.GetPublisherTaskFromElement ( trig );
          if ( pt != null )
            this.Add ( pt );
        }
      }

    }

    /// <summary>
    /// Clones this instance.
    /// </summary>
    /// <returns></returns>
    public new virtual SerializableList<PublisherTask> Clone ( ) {
      PublishersTasksList list = new PublishersTasksList ( this._typeName );
      foreach ( PublisherTask item in this ) {
        if ( typeof ( PublisherTask ).GetType ( ).GetInterface ( "System.ICloneable", true ) != null ) {
          ICloneable citem = item as ICloneable;
          if ( citem != null )
            list.Add ( ( PublisherTask ) citem.Clone ( ) );
          else
            list.Add ( ( PublisherTask ) citem );
        }
      }
      return list;
    }
  }
  /// <summary>
  /// A collection of Publishers
  /// </summary>
  public class PublishersList : PublishersTasksList {
    /// <summary>
    /// Initializes a new instance of the <see cref="PublishersList"/> class.
    /// </summary>
    public PublishersList ( ) : base ( "publishers" ) { }
    /// <summary>
    /// Clones this instance.
    /// </summary>
    /// <returns></returns>
    public override SerializableList<PublisherTask> Clone ( ) {
      PublishersList list = new PublishersList ( );
      foreach ( PublisherTask item in this ) {
        if ( typeof ( PublisherTask ).GetType ( ).GetInterface ( "System.ICloneable", true ) != null ) {
          ICloneable citem = item as ICloneable;
          if ( citem != null )
            list.Add ( ( PublisherTask ) citem.Clone ( ) );
          else
            list.Add ( ( PublisherTask ) citem );
        }
      }
      return list;
    }
  }

  /// <summary>
  /// A collection of Tasks
  /// </summary>
  public class TasksList : PublishersTasksList {
    /// <summary>
    /// Initializes a new instance of the <see cref="TasksList"/> class.
    /// </summary>
    public TasksList ( ) : base ( "tasks" ) { }
    /// <summary>
    /// Clones this instance.
    /// </summary>
    /// <returns></returns>
    public override SerializableList<PublisherTask> Clone ( ) {
      TasksList list = new TasksList ( );
      foreach ( PublisherTask item in this ) {
        if ( typeof ( PublisherTask ).GetType ( ).GetInterface ( "System.ICloneable", true ) != null ) {
          ICloneable citem = item as ICloneable;
          if ( citem != null )
            list.Add ( ( PublisherTask ) citem.Clone ( ) );
          else
            list.Add ( ( PublisherTask ) citem );
        }
      }
      return list;
    }
  }

  /// <summary>
  /// A collection of Prebuild items
  /// </summary>
  public class PrebuildsList : PublishersTasksList {
    /// <summary>
    /// Initializes a new instance of the <see cref="PrebuildsList"/> class.
    /// </summary>
    public PrebuildsList ( ) : base ( "prebuild" ) { }
    /// <summary>
    /// Clones this instance.
    /// </summary>
    /// <returns></returns>
    public override SerializableList<PublisherTask> Clone ( ) {
      PrebuildsList list = new PrebuildsList ( );
      foreach ( PublisherTask item in this ) {
        if ( typeof ( PublisherTask ).GetType ( ).GetInterface ( "System.ICloneable", true ) != null ) {
          ICloneable citem = item as ICloneable;
          if ( citem != null )
            list.Add ( ( PublisherTask ) citem.Clone ( ) );
          else
            list.Add ( ( PublisherTask ) citem );
        }
      }
      return list;
    }
  }
}

using System;
using System.Collections.Generic;
using System.Text;
using CCNetConfig.Core.Serialization;
using System.ComponentModel;

namespace CCNetConfig.Core {
  /// <summary>
  /// Trigger blocks allow you to specify when CruiseControl.NET will start a new integration cycle.
  /// </summary>
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public abstract class Trigger : ISerialize, ICCNetObject, ICloneable {
    private string typeName = string.Empty;

    /// <summary>
    /// Initializes a new instance of the <see cref="Trigger"/> class.
    /// </summary>
    /// <param name="typeName">Name of the type.</param>
    protected Trigger(string typeName) {
      this.typeName = typeName;
    }

    /// <summary>
    /// Internally used property to get the type name of the trigger
    /// </summary>
    [Browsable(false)]
    public string TypeName { 
      get { return this.typeName; } }

      /// <summary>
      /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
      /// </summary>
      /// <returns>
      /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
      /// </returns>
    public override string ToString () {
      return this.GetType ().Name;
    }
    #region ISerialize Members

    /// <summary>
    /// Serializes this instance.
    /// </summary>
    /// <returns></returns>
    public abstract System.Xml.XmlElement Serialize();
    /// <summary>
    /// Deserializes the specified element.
    /// </summary>
    /// <param name="element">The element.</param>
    public abstract void Deserialize( System.Xml.XmlElement element );

    #endregion

    #region ICloneable Members
    /// <summary>
    /// Creates a copy of this object.
    /// </summary>
    /// <returns></returns>
    public abstract Trigger Clone ();
    object ICloneable.Clone () {
      return this.Clone ();
    }

    #endregion
  }
}
