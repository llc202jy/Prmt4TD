package org.phramer.interfaceimpl.pooling;

import org.phramer.*;
import org.phramer.interfaceimpl.pooling.*;

public class TranslationTask extends AbstractTranslationTask
{
	private int sentenceIdx;
	private String[] output;
	
	public TranslationTask(String fSentence, int sentenceIdx , boolean xml , boolean chunk , int outputDelta , String[] output)
	{
		super(fSentence , xml , chunk , outputDelta);
		this.sentenceIdx = sentenceIdx;
		this.output = output;
	}
	/**
	 * Returs true if it should be added to the output pool
	 */
	public void execute(MachineTranslator resource) throws Exception
	{
		output[outputDelta] = resource.translate(fSentence , sentenceIdx , xml , chunk);
	}
	public boolean putInOutput()
	{
		return false;
	}
	