 confName and the configuration file
confName carries the name of a JAAS configuration. The ninth command-line parameter (the name of a client configuration) specifies the JAAS configuration that the client wants to use for authentication. The JAAS configuration file, specified by the eighth command-line parameter, contains one or more client configurations, out of which the client can use any one.

A JAAS configuration specifies the mechanism that will be used for authentication. The concept of configuration files allows Java applications to choose an authentication mechanism independent of authentication logic.

JAAS configurations are stored as .conf files. The sample JAAS configuration file in Listing 2 has two configurations. The GSSClient configuration looks like the this:

GSSClient {
   com.sun.security.auth.module.Krb5LoginModule required;
};


This JAAS configuration specifies the name of the Java class com.sun.security.auth.module.Krb5LoginModule. This class is the Kerberos login module in JAAS, and the GSSClient configuration uses it for login. Thus, specifying this configuration means that we will use Kerberos as our mechanism for authentication.

Listing 2. JAAS login configuration for GSSClient and GSSServer

/****
    Login.conf
****/

GSSClient{
     com.sun.security.auth.module.Krb5LoginModule required;
};

GSSServer{
    com.sun.security.auth.module.Krb5LoginModule required
    storeKey=true;
};
public class BeanCallbackHandler implements CallbackHandler {

    // Store username and password.
    String name = null;
    String password = null;
  
    public BeanCallbackHandler(String name, String password)
    {
        this.name = name;
        this.password = password;
    }//BeanCallbackHandler


    public void handle (Callback[] callbacks) throws
      UnsupportedCallbackException, IOException 
    {
        for(int i=0; i<callbacks.length; i++) {
            Callback callBack = callbacks[i];

            // Handles username callback.
            if (callBack instanceof NameCallback) {
                NameCallback nameCallback = (NameCallback)callBack;
                nameCallback.setName(name);

             // Handles password callback.
            } else if (callBack instanceof PasswordCallback) {
              PasswordCallback passwordCallback = 
                  (PasswordCallback)callBack;
              passwordCallback.setPassword(password.toCharArray());
 
          } else {
              throw new UnsupportedCallbackException(callBack, 
                  "Call back not supported");
          }//else
      }//for 
	  
  }//handle
  