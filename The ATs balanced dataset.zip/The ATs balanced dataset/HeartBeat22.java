import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.jini.config.Configuration;
import net.jini.core.entry.Entry;
import net.jini.core.lookup.ServiceID;
import net.jini.core.lookup.ServiceItem;
import net.jini.lookup.LookupCache;
import net.jini.lookup.ServiceDiscoveryEvent;
import net.jini.lookup.entry.Name;
import net.assimilator.core.FaultDetectionHandler;
import net.assimilator.core.FaultDetectionListener;

/**
 * The AbstractFaultDetectionHandler provides a base class which can be extended 
 * to provide concrete FaultDetectionHandler capabilities. The basic infrastructure 
 * included in the AbstractFaultDetectionHandler includes 
 * {@link net.assimilator.core.FaultDetectionListener} registration and notification,
 * a {@link net.jini.lookup.ServiceDiscoveryListener} implementation
 * 
 * Properties that will be common across all classes wich extend this class are also
 * provided:
 * <ul>
 * <li>retryCount
 * <li>retryTimeout
 * </ul>
 * 
 * @see net.assimilator.core.FaultDetectionHandler
 * @see net.assimilator.core.FaultDetectionListener
 */
public abstract class AbstractFaultDetectionHandler implements FaultDetectionHandler {
    public static final int DEFAULT_RETRY_COUNT = 3;
    public static final long DEFAULT_RETRY_TIMEOUT = 1000 * 1;
    public static final String RETRY_COUNT_KEY = "retryCount";
    public static final String RETRY_TIMEOUT_KEY = "retryTimeout";
    /** Object that can be used to communicate to the service */
    protected Object proxy;
    protected int retryCount = DEFAULT_RETRY_COUNT;
    protected long retryTimeout = DEFAULT_RETRY_TIMEOUT;
    /** Collection of FaultDetectionListeners */
    private Vector listeners = new Vector();    
    /** ServiceID used to discover service instance */
    private ServiceID serviceID;    
    /** The LookupCache */
    private LookupCache lCache;
    /** Flag to indicate the utility is terminating */
    protected boolean terminating = false;
    /** Flag to indicate Listeners have already been notified */
    private boolean notified = false;
    /** Configuration arguments */
    protected String[] configArgs;
    /** A Configuration object */
    protected Configuration config;    
    /** Listener for the LookupCache */
    private FDHListener fdhListener;
    /** Component name, used for config and logger */
    private static final String COMPONENT = 
        "net.assimilator.resources.client.AdminFaultDetectionHandler";
    /** Class which provides service monitoring */
    protected ServiceMonitor serviceMonitor;
    /** A Logger */
    static Logger logger = Logger.getLogger(COMPONENT);
    
    /**
     * @see net.assimilator.core.FaultDetectionHandler#register
     */
    public void register(FaultDetectionListener listener) {
        if(listener == null)
            throw new NullPointerException("listener is null");
        if(!listeners.contains(listener))
            listeners.addElement(listener);
    }

    /**
     * @see net.assimilator.core.FaultDetectionHandler#unregister
     */
    public void unregister(FaultDetectionListener listener) {
        if(listener == null)
            throw new NullPointerException("listener is null");
        listeners.remove(listener);
    }

    /**
     * @see net.assimilator.core.FaultDetectionHandler#monitor
     */
    public void monitor(Object proxy, Object id, LookupCache lCache) throws Exception {
        if(proxy == null)
            throw new NullPointerException("proxy is null");
        if(id == null)
            throw new NullPointerException("id is null");
        if(lCache == null)
            throw new NullPointerException("lCache is null");
        
        this.serviceID = (ServiceID)id;        
        this.lCache = lCache;
        this.proxy = proxy;
        fdhListener = new FDHListener();
        this.lCache.addListener(fdhListener);                
        serviceMonitor = getServiceMonitor();        
    }

    /**
     * Get the class which implements the ServiceMonitor
     */
    protected abstract ServiceMonitor getServiceMonitor() throws Exception;
    
    /**
     * @see net.assimilator.core.FaultDetectionHandler#terminate
     */
    public void terminate() {
        if(terminating)
            return;
        terminating = true;        
        if(lCache != null && fdhListener!=null) {
            try {
                lCache.removeListener(fdhListener);
            } catch (Throwable t) {
                logger.log(Level.WARNING, 
                           "Exception {0} removing Listener from LookupCache",
                           new Object[] {t.getClass().getName()});
            }
        }
        if(serviceMonitor != null) {
            serviceMonitor.drop();
        }
    }

    /**
     * Notify FaultDetectionListener instances the service has been removed
     */
    protected void notifyListeners() {
        if(notified)
            return;
        Object[] arrLocal = listeners.toArray();
        for(int i = arrLocal.length - 1; i >= 0; i--)
            ((FaultDetectionListener)arrLocal[i]).serviceFailure(proxy,
                                                                 serviceID);
        notified = true;
    }
    
    /**
     * Defines the semantics of an internal class which will be used in addition
     * to the 
     */
    public interface ServiceMonitor {
        /**
         * Drop the Monitor, its not longer needed
         */
        void drop();
        
        /**
         * Verify that the service can be reached. If the service cannot be reached
         * return false
         */
        boolean verify();
    }
    
    /**
     * Listen for service removal events for the service we're interested in
     */
    class FDHListener extends ServiceDiscoveryAdapter {
        boolean reachable = false;

        /**
         * Notification that the service has been removed
         * 
         * @param sdEvent The ServiceDiscoveryEvent
         */
        public void serviceRemoved(ServiceDiscoveryEvent sdEvent) {
            ServiceItem item = sdEvent.getPreEventServiceItem();
            if(!item.serviceID.equals(serviceID))
                return;
            if(serviceMonitor != null) {
                for(int i = 0; i < retryCount; i++) {                    
                    reachable = serviceMonitor.verify();
                    if(!reachable) {
                        break;
                    }
                    if(retryTimeout > 0) {
                        try {
                            Thread.sleep(retryTimeout);
                        } catch(InterruptedException ie) {
                            ;
                        }
                    }
                }
            }
            if(logger.isLoggable(Level.FINEST))
                logger.finest("FDH: service ["+getName(item.attributeSets)+"], "+
                              "proxy ["+proxy.getClass().getName()+"] "+
                              "is reachable ["+reachable+"]");
            if(!reachable && !terminating) {
                notifyListeners();
                terminate();
            }
        }
    }
        
    
    /**
     * Get the first Name.name from the attribute collection set
     */
    protected String getName(Entry[] attrs) {
        for(int i=0; i<attrs.length; i++) {
            if(attrs[i] instanceof Name) {
                return(((Name)attrs[i]).name);
            }
        }
        return("unknown");
    }
}