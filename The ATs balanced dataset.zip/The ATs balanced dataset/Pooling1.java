package na.learn.java.corepatterns.pooling;

import java.util.Hashtable;
import java.util.WeakHashMap;

//Singleton
public class ConnectionManager {

	private CommonParams commonParams = null;

	private static ConnectionManager connManager = null;

	//	 A Hashtable containing (key=hostURL, value = configurationMap)
	private WeakHashMap configurationMap;

	// A Hashtable containing (key=configurationMap, value = connection)
	private ConnectionPool connectionPool;

	private ConnectionManager() {
		super();
		connectionPool = new ConnectionPool();
	}

	// Singleton
	public static final ConnectionManager getInstance() {
		if (connManager == null) {
			synchronized (connManager) {
				if (connManager == null)
					connManager = new ConnectionManager();

			}
		}
		connManager.commonParams = new CommonParams();		
		return connManager;

	}

	public void setParams(CommonParams commonParams) {
		this.commonParams = commonParams;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException("Single can not be cloned. ");
	}
	
	
	public Connection getConnection(HostSpecificParams hostparams) {
		Connection conn = connectionPool.getFreeConnection(hostparams);
		if(configurationMap== null)
			configurationMap = new WeakHashMap();
		/*configurationMap.put();*/
		return null;

	}

	class ConnectionPool {

		private int numHosts;

		private int totalLiveConnections;

		private Hashtable pool = new Hashtable();

		/**
		 * 1. If there is any free connection in Pool for this host, return it.
		 * else if ( num_Of_In-use_Connections_for_this_host < minConnPerHost), create and return a new connection.
		 * else (if num_Of_In-use_Connections_for_this_host >= minConnPerHost and < maxConnectionsPerHost)
		 * 	2. create a new Connection and return it.
		 * else if( Total_IN-use_connections is less than maxTotalConnections),
		 * 	3. create a new Connection and return it.
		 *  
		 * @param hostParams
		 * @return
		 */
		public Connection getFreeConnection(HostSpecificParams hostParams) {

			return null;

		}

	}public class BaseThreadPool extends AbstractThreadPool
{
	public void init(Node nodConfig) throws Exception
	{
		super.init(nodConfig);
	}
}package na.learn.java.corepatterns.pooling;

import java.util.WeakHashMap;

public class ConnectionPoolImpl implements ConnectionPool {
	
	WeakHashMap connectionPool;
	WeakHashMap configMap;

	public ConnectionPoolImpl() {
		super();		
		connectionPool = new WeakHashMap();
		
		// TODO Auto-generated constructor stub
	}

	public Connection getConnection(HostSpecificParams hostParams) {
		if(configMap.containsKey(hostParams.getUrl()))
		{
			if(isChanged(hostParams))
				updateParamsAndConnections(hostParams);
			
		}
			
		return null;
	}

	/**
	 *  
	 * @param newHostParams
	 */
	private void updateParamsAndConnections(HostSpecificParams newHostParams) {
		
		HostSpecificParams oldParams = (HostSpecificParams)configMap.get(newHostParams.getUrl());
		
		HostConnectionPool conn = (HostConnectionPool)connectionPool.get(oldParams);
		/*Class.forName()*/
		((HostSpecificParams)configMap.get(newHostParams.getUrl())).update(newHostParams);
		
		
		
	}

	private boolean isChanged(HostSpecificParams hostParams) {
		HostSpecificParams origHostParam = (HostSpecificParams)configMap.get(hostParams.getUrl());
		return origHostParam.equals(hostParams);
		

	}
	
	
	

}public class BaseThreadPool extends AbstractThreadPool
{
	public void init(Node nodConfig) throws Exception
	{
		super.init(nodConfig);
	}
}package na.learn.java.corepatterns.pooling;

import java.util.WeakHashMap;

public class ConnectionPoolImpl implements ConnectionPool {
	
	WeakHashMap connectionPool;
	WeakHashMap configMap;

	public ConnectionPoolImpl() {
		super();		
		connectionPool = new WeakHashMap();
		
		// TODO Auto-generated constructor stub
	}

	public Connection getConnection(HostSpecificParams hostParams) {
		if(configMap.containsKey(hostParams.getUrl()))
		{
			if(isChanged(hostParams))
				updateParamsAndConnections(hostParams);
			
		}
			
		return null;
	}

	/**
	 *  package na.learn.java.corepatterns.pooling;

import java.util.Hashtable;
import java.util.WeakHashMap;

//Singleton
public class ConnectionManager {

	private CommonParams commonParams = null;

	private static ConnectionManager connManager = null;

	//	 A Hashtable containing (key=hostURL, value = configurationMap)
	private WeakHashMap configurationMap;

	// A Hashtable containing (key=configurationMap, value = connection)
	private ConnectionPool connectionPool;

	private ConnectionManager() {
		super();
		connectionPool = new ConnectionPool();
	}

	// Singleton
	public static final ConnectionManager getInstance() {
		if (connManager == null) {
			synchronized (connManager) {
				if (connManager == null)
					connManager = new ConnectionManager();

			}
		}
		connManager.commonParams = new CommonParams();		
		return connManager;

	}

	public void setParams(CommonParams commonParams) {
		this.commonParams = commonParams;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException("Single can not be cloned. ");
	}
	
	
	public Connection getConnection(HostSpecificParams hostparams) {
		Connection conn = connectionPool.getFreeConnection(hostparams);
		if(configurationMap== null)
			configurationMap = new WeakHashMap();
		/*configurationMap.put();*/
		return null;

	}

	class ConnectionPool {

		private int numHosts;

		private int totalLiveConnections;

		private Hashtable pool = new Hashtable();

		/**
		 * 1. If there is any free connection in Pool for this host, return it.
		 * else if ( num_Of_In-use_Connections_for_this_host < minConnPerHost), create and return a new connection.
		 * else (if num_Of_In-use_Connections_for_this_host >= minConnPerHost and < maxConnectionsPerHost)
		 * 	2. create a new Connection and return it.
		 * else if( Total_IN-use_connections is less than maxTotalConnections),
		 * 	3. create a new Connection and return it.
		 *  
		 * @param hostParams
		 * @return
		 */
		public Connection getFreeConnection(HostSpecificParams hostParams) {

			return null;

		}

	}public class BaseThreadPool extends AbstractThreadPool
{
	public void init(Node nodConfig) throws Exception
	{
		super.init(nodConfig);
	}
}package na.learn.java.corepatterns.pooling;

import java.util.WeakHashMap;

public class ConnectionPoolImpl implements ConnectionPool {
	
	WeakHashMap connectionPool;
	WeakHashMap configMap;

	public ConnectionPoolImpl() {
		super();		
		connectionPool = new WeakHashMap();
		
		// TODO Auto-generated constructor stub
	}

	public Connection getConnection(HostSpecificParams hostParams) {
		if(configMap.containsKey(hostParams.getUrl()))
		{
			if(isChanged(hostParams))
				updateParamsAndConnections(hostParams);
			
		}
			
		return null;
	}

	/**
	 *  
	 * @param newHostParams
	 */
	private void updateParamsAndConnections(HostSpecificParams newHostParams) {
		
		HostSpecificParams oldParams = (HostSpecificParams)configMap.get(newHostParams.getUrl());
		
		HostConnectionPool conn = (HostConnectionPool)connectionPool.get(oldParams);
		/*Class.forName()*/
		((HostSpecificParams)configMap.get(newHostParams.getUrl())).update(newHostParams);
		
		
		
	}

	private boolean isChanged(HostSpecificParams hostParams) {
		HostSpecificParams origHostParam = (HostSpecificParams)configMap.get(hostParams.getUrl());
		return origHostParam.equals(hostParams);
		

	}
	
	
	

}public class BaseThreadPool extends AbstractThreadPool
{
	public void init(Node nodConfig) throws Exception
	{
		super.init(nodConfig);
	}
}package na.learn.java.corepatterns.pooling;

import java.util.WeakHashMap;

public class ConnectionPoolImpl implements ConnectionPool {
	
	WeakHashMap connectionPool;
	WeakHashMap configMap;

	public ConnectionPoolImpl() {
		super();		
		connectionPool = new WeakHashMap();
		
		// TODO Auto-generated constructor stub
	}

	public Connection getConnection(HostSpecificParams hostParams) {
		if(configMap.containsKey(hostParams.getUrl()))
		{
			if(isChanged(hostParams))
				updateParamsAndConnections(hostParams);
			
		}
			
		return null;
	}

	/**
	 *  
	 * @param newHostParams
	 */
	private void updateParamsAndConnections(HostSpecificParams newHostParams) {
		
		HostSpecificParams oldParams = (HostSpecificParams)configMap.get(newHostParams.getUrl());
		
		HostConnectionPool conn = (HostConnectionPool)connectionPool.get(oldParams);
		/*Class.forName()*/
		((HostSpecificParams)configMap.get(newHostParams.getUrl())).update(newHostParams);
		
		
		
	}

	private boolean isChanged(HostSpecificParams hostParams) {
		HostSpecificParams origHostParam = (HostSpecificParams)configMap.get(hostParams.getUrl());
		return origHostParam.equals(hostParams);
		

	}
	
	
	

}
	 * @param newHostParams
	 */
	private void updateParamsAndConnections(HostSpecificParams newHostParams) {
		
		HostSpecificParams oldParams = (HostSpecificParams)configMap.get(newHostParams.getUrl());
		
		HostConnectionPool conn = (HostConnectionPool)connectionPool.get(oldParams);
		/*Class.forName()*/
		((HostSpecificParams)configMap.get(newHostParams.getUrl())).update(newHostParams);
		
		
		
	}

	private boolean isChanged(HostSpecificParams hostParams) {
		HostSpecificParams origHostParam = (HostSpecificParams)configMap.get(hostParams.getUrl());
		return origHostParam.equals(hostParams);
		

	}
	
	
	

}package na.learn.java.corepatterns.pooling;

import java.util.Hashtable;
import java.util.WeakHashMap;

//Singleton
public class ConnectionManager {

	private CommonParams commonParams = null;

	private static ConnectionManager connManager = null;

	//	 A Hashtable containing (key=hostURL, value = configurationMap)
	private WeakHashMap configurationMap;

	// A Hashtable containing (key=configurationMap, value = connection)
	private ConnectionPool connectionPool;

	private ConnectionManager() {
		super();
		connectionPool = new ConnectionPool();
	}

	// Singleton
	public static final ConnectionManager getInstance() {
		if (connManager == null) {
			synchronized (connManager) {
				if (connManager == null)
					connManager = new ConnectionManager();

			}
		}
		connManager.commonParams = new CommonParams();		
		return connManager;

	}

	public void setParams(CommonParams commonParams) {
		this.commonParams = commonParams;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException("Single can not be cloned. ");
	}
	
	
	public Connection getConnection(HostSpecificParams hostparams) {
		Connection conn = connectionPool.getFreeConnection(hostparams);
		if(configurationMap== null)
			configurationMap = new WeakHashMap();
		/*configurationMap.put();*/
		return null;

	}

	class ConnectionPool {

		private int numHosts;

		private int totalLiveConnections;

		private Hashtable pool = new Hashtable();

		/**
		 * 1. If there is any free connection in Pool for this host, return it.
		 * else if ( num_Of_In-use_Connections_for_this_host < minConnPerHost), create and return a new connection.
		 * else (if num_Of_In-use_Connections_for_this_host >= minConnPerHost and < maxConnectionsPerHost)
		 * 	2. create a new Connection and return it.
		 * else if( Total_IN-use_connections is less than maxTotalConnections),
		 * 	3. create a new Connection and return it.
		 *  
		 * @param hostParams
		 * @return
		 */
		public Connection getFreeConnection(HostSpecificParams hostParams) {

			return null;

		}

	}