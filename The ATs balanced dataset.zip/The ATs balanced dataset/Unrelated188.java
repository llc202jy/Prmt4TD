
package org.mortbay.jetty.handler;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;

/* ------------------------------------------------------------ */
/** HandlerList.
 * This extension of {@link org.mortbay.jetty.handler.HandlerCollection} will call
 * each contained handler in turn until either an exception is thrown, the response 
 * is committed or a positive response status is set.
 */
public class HandlerList extends HandlerCollection
{
    /* ------------------------------------------------------------ */
    /* 
     * @see org.mortbay.jetty.EventHandler#handle(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public void handle(String target, HttpServletRequest request, HttpServletResponse response, int dispatch) 
        throws IOException, ServletException
    {
        Handler[] handlers = getHandlers();
        
        if (handlers!=null && isStarted())
        {
            Request base_request = HttpConnection.getCurrentConnection().getRequest();
            for (int i=0;i<handlers.length;i++)
            {
                handlers[i].handle(target,request, response, dispatch);
                if ( base_request.isHandled())
                    return;
            }
        }
    }
}

package org.mortbay.jetty.handler;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.Response;

public class StatisticsHandler extends HandlerWrapper
{
    transient long _statsStartedAt;
    
    transient int _requests;
    
    transient long _requestsDurationMin;         // min request duration
    transient long _requestsDurationMax;         // max request duration
    transient long _requestsDurationTotal;       // total request duration
    
    transient int _requestsActive;
    transient int _requestsActiveMin;            // min number of connections handled simultaneously
    transient int _requestsActiveMax;
    transient int _responses1xx; // Informal
    transient int _responses2xx; // Success
    transient int _responses3xx; // Redirection
    transient int _responses4xx; // Client Error
    transient int _responses5xx; // Server Error
    

    /* ------------------------------------------------------------ */
    public void statsReset()
    {
        synchronized(this)
        {
            if (isStarted())
                _statsStartedAt=System.currentTimeMillis();
            _requests=0;
            _requestsActiveMax=_requestsActive;
            _responses1xx=0;
            _responses2xx=0;
            _responses3xx=0;
            _responses4xx=0;
            _responses5xx=0;
          
            _requestsActiveMin=_requestsActive;
            _requestsActiveMax=_requestsActive;
            _requestsActive=0;

            _requestsDurationMin=0;
            _requestsDurationMax=0;
            _requestsDurationTotal=0;
        }
    }


    /* ------------------------------------------------------------ */
    public void handle(String target, HttpServletRequest request, HttpServletResponse response, int dispatch) throws IOException, ServletException
    {
        final Request base_request=(request instanceof Request)?((Request)request):HttpConnection.getCurrentConnection().getRequest();
        final Response base_response=(response instanceof Response)?((Response)response):HttpConnection.getCurrentConnection().getResponse();
        
        try
        {
            synchronized(this)
            {
                _requests++;
                _requestsActive++;
                if (_requestsActive>_requestsActiveMax)
                    _requestsActiveMax=_requestsActive;
            }
            
            super.handle(target, request, response, dispatch);
        }
        finally
        {
            synchronized(this)
            {
                _requestsActive--;
                if (_requestsActive<0)
                    _requestsActive=0;
                if (_requestsActive < _requestsActiveMin)
                    _requestsActiveMin=_requestsActive;
                
                long duration = System.currentTimeMillis()-base_request.getTimeStamp();
                
                _requestsDurationTotal+=duration;
                if (_requestsDurationMin==0 || duration<_requestsDurationMin)
                    _requestsDurationMin=duration;
                if (duration>_requestsDurationMax)
                    _requestsDurationMax=duration;
                
                switch(base_response.getStatus()/100)
                {
                    case 1: _responses1xx++;break;
                    case 2: _responses2xx++;break;
                    case 3: _responses3xx++;break;
                    case 4: _responses4xx++;break;
                    case 5: _responses5xx++;break;
                }
                
            }
        }
    }

    /* ------------------------------------------------------------ */
    protected void doStart() throws Exception
    {
        super.doStart();
        _statsStartedAt=System.currentTimeMillis();
    }

     * Constructor.
     *
     * @param configuration An input stream containing a complete e.g. configuration file
     * @exception SAXException
     * @exception IOException
     */
    public XmlConfiguration(InputStream configuration) throws SAXException, IOException
    {
        initParser();
        InputSource source = new InputSource(configuration);
        synchronized (__parser)
        {
            _config = __parser.parse(source);
        }
    }

    /* ------------------------------------------------------------ */
    public Map getIdMap()
    {
        return _idMap;
    }
    
    /* ------------------------------------------------------------ */
    public void setIdMap(Map map)
