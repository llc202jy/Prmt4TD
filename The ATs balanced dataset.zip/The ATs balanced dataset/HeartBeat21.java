/**
 * Sub-interface of {@link WebServiceConnection} that is aware of any Fault messages received. Fault messages (such as
 * {@link SoapFault} SOAP Faults) often require different processing rules. Typically, fault detection is done by
 * inspecting connection error codes, etc.
 *
 * @author Arjen Poutsma
 * @since 1.0.0
 */
public interface FaultAwareWebServiceConnection extends WebServiceConnection {

    /**
     * Indicates whether this connection received a fault.
     * <p/>
     * Typically implemented by looking at an HTTP status code.
     *
     * @return <code>true</code> if this connection received a fault; <code>false</code> otherwise.
     * @throws IOException in case of I/O errors
     */
    boolean hasFault() throws IOException;

    /**
     * Sets whether this connection will send a fault.
     * <p/>
     * Typically implemented by setting an HTTP status code.
     *
     * @param fault <code>true</code> if this will send a fault; <code>false</code> otherwise.
     * @throws IOException in case of I/O errors
     */
    void setFault(boolean fault) throws IOException;
}

public class NetMonitorActionImpl extends ActionImpls {

   public static final int PAST_LINES_TO_STORE_PER_ADDR = 5;

   public NetMonitorActionImpl( NetMonitorServer server ) {
      super( server );
   }

   public ActionError handleLine( String line, Socket socket ) {
      String ret = handleLineForAddr( new NetLine(line, socket.getInetAddress()) );
      if( ret != null ) {
         System.out.println( "NetMonitorActionImpl: indicates a possible fault" );
      }
      return new ActionError(ret);
   }


   protected HashMap<InetAddress,LinkedList<NetLine>> lastLine
      = new HashMap<InetAddress,LinkedList<NetLine>>();
   public String handleLineForAddr( NetLine line ) {
      LinkedList<NetLine> linesForThisAddr = lastLine.get( line.getAddr() );
      if( linesForThisAddr == null ) {
         linesForThisAddr = new LinkedList<NetLine>();
         lastLine.put( line.getAddr(), linesForThisAddr );
      }
      if( linesForThisAddr.size() >= PAST_LINES_TO_STORE_PER_ADDR ) {
         linesForThisAddr.removeFirst();
      }
      linesForThisAddr.add( line );
      return indicatesFault( linesForThisAddr );
   }

   /**
    * Overload this function to do fault detection!
    * @return null iff no fault occred.
    */
   public String indicatesFault( LinkedList<NetLine> lines ) {
      //print most recently added (last) line.
      System.out.println( lines.getLast() );
      return null;
   }

}