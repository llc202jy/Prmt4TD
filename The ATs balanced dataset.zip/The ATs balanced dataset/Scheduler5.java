final Runnable job = new Runnable() {
	public void run() {
		log.info("Executing the job");
	}
};
String schedulingExpression = "0 15 10 ? * MON-FRI";
this.scheduler.addJob("myJob", job, null, schedulingExpression, true);
long period = 3*60; //the period is expressed in seconds
this.scheduler.addPeriodicJob("myJob", job, null, period, true);
SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
String date = "2020/01/10";
java.util.Date fireDate = formatter.parse(date);
this.scheduler.fireJobAt("myJob", job, null, fireDate);

/**
 *  This service executes scheduled jobs
 *  
 *	@scr.component immediate="true" metatype="false"
 *
 */
public class HelloWorldScheduledService {
	
    /** Default log. */
    protected final Logger log = LoggerFactory.getLogger(this.getClass());
    
    /** The scheduler for rescheduling jobs.
     * @scr.reference */
    private Scheduler scheduler;
    

    protected void activate(ComponentContext componentContext) throws Exception {
        //case 1: with addJob() method: executes the job every minute
    	String schedulingExpression = "0 * * * * ?";
    	String jobName1 = "case1";
    	Map<String, Serializable> config1 = new HashMap<String, Serializable>();
    	boolean canRunConcurrently = true;
        final Runnable job1 = new Runnable() {
            public void run() {
            	log.info("Executing job1");
            }
        };
        try {
        	this.scheduler.addJob(jobName1, job1, config1, schedulingExpression, canRunConcurrently);
        } catch (Exception e) {
            job1.run();
        }
    	
        //case 2: with addPeriodicJob(): executes the job every 3 minutes
        String jobName2 = "case2";
    	long period = 180;
    	Map<String, Serializable> config2 = new HashMap<String, Serializable>();
        final Runnable job2 = new Runnable() {
            public void run() {
            	log.info("Executing job2");
            }
        };
        try {
        	this.scheduler.addPeriodicJob(jobName2, job2, config2, period, canRunConcurrently);
        } catch (Exception e) {
            job2.run();
        }

        //case 3: with fireJobAt(): executes the job at a specific date (date of deployment + delay of 30 seconds)
        String jobName3 = "case3";
    	final long delay = 30*1000;
    	final Date fireDate = new Date();
        fireDate.setTime(System.currentTimeMillis() + delay);
    	Map<String, Serializable> config3 = new HashMap<String, Serializable>();
        final Runnable job3 = new Runnable() {
            public void run() {
            	log.info("Executing job3 at date: {} with a delay of: {} seconds", fireDate, delay/1000);
            }
        };
        try {
        	this.scheduler.fireJobAt(jobName3, job3, config3, fireDate);
        } catch (Exception e) {
            job3.run();
        }
    }

    protected void deactivate(ComponentContext componentContext) {
        log.info("Deactivated, goodbye!");
    }

}

package sling.docu.examples;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @scr.component
 * @scr.service interface="java.lang.Runnable"
 * @scr.property name="scheduler.expression" value="0 * * * * ?"
 */
public class ScheduledCronJob implements Runnable {

	/** Default log. */
    protected final Logger log = LoggerFactory.getLogger(this.getClass());
    
    public void run() {
    	log.info("Executing a cron job (job#1) through the whiteboard pattern");
    }
//
