*
 * Copyright (c) 2002-2006 Universidade Federal de Campina Grande
 * 
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA
 */
package org.ourgrid.mygrid.scheduler;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.ourgrid.common.config.Configuration;
import org.ourgrid.common.exception.UnableToDigestFileException;
import org.ourgrid.common.gum.GumClient;
import org.ourgrid.common.id.GumID;
import org.ourgrid.common.spec.GumSpec;
import org.ourgrid.common.util.JavaFileUtil;
import org.ourgrid.mygrid.scheduler.exception.DDEntryNotFoundException;
import org.ourgrid.mygrid.scheduler.exception.DDInitException;

/**
 * This is the Data Discovery class. It generates a record of all successful
 * file transfers resulting from STORE directives defined in Job Description
 * Files. This list is made available to Storage Affinity for ([file size] +
 * [location]) discovery.
 */

public class DataDiscovery {

	/** Logger (log4j) object to store log events */
	private static transient final org.apache.log4j.Logger LOG = org.apache.log4j.Logger
			.getLogger( DataDiscovery.class );

	/**
	 * Duration of entry validity. Not yet used.
	 */
	public static final long DEFAULT_DURATION = 604800000L;

	/**
	 * Default name for the DD cache file
	 */
	private static String ddCache = "ddCache.log";

	/**
	 * HashMap containing DD instances
	 */
	private static HashMap<Boolean,DataDiscovery> ddLookup = new HashMap<Boolean,DataDiscovery>();

	/**
	 * HashMap containing DDEntries that have been recorded
	 */
	private static HashMap<String,DataDiscoveryEntry> entries = new HashMap<String,DataDiscoveryEntry>();

	/**
	 * File form of cached entries.
	 */
	private File ddFile;


	/**
	 * The constructor. Reads the history file from disk to populate the lookup
	 * table, or creates a new one if directed to do so. Writes active entries
	 * to disk when the Data Discovery is terminated.
	 * 
	 * @param cachefile Indicates if the Data Discovery log should be generated.
	 */
	private DataDiscovery( boolean cacheFile ) {

		if ( cacheFile ) {
			String ddPath = Configuration.getInstance().getRootDir() + File.separator + ddCache;
			ddFile = new File( ddPath );

			try {
				if ( !(ddFile.exists()) ) {
					ddFile.createNewFile();
				}
			} catch ( IOException ioe ) {
				System.err.println( "Cannot create DD history file ! STORE activity will not be logged." );
			}

			/*
			 * If entries exist, load them into the table.
			 */
			if ( ddFile.length() > 0L ) {
				readHistory();
			}

			/*
			 * Write entries to file when DD exits.
			 */
			Runtime.getRuntime().addShutdownHook( new Thread( "Data Discovery Shutdown Hook" ) {

				@Override
				public void run() {

					writeHistory();
				}
			} );
		}
	}


	private void readHistory() {

		String digest;
		DataDiscoveryEntry entry;
		FileInputStream fileInput;
		ObjectInputStream objInput = null;
		try {
			fileInput = new FileInputStream( ddFile );
			objInput = new ObjectInputStream( fileInput );
		} catch ( FileNotFoundException exception ) {
			System.err.println( "Cannot find the DD history file !!!" );
		} catch ( IOException exception ) {
			System.err.println( "Unable to open object stream !!!" );
		}

		try {
			while ( true ) {
				entry = (DataDiscoveryEntry) objInput.readObject();
				digest = entry.getDigest();
				entries.put( digest, entry );
			}
		} catch ( EOFException eof ) {
		} catch ( ClassNotFoundException noClass ) {
		} catch ( IOException ioe ) {
		} finally {
			try {
				objInput.close();
			} catch ( IOException ioe ) {
			}
		}
	}


	private void writeHistory() {

		ObjectOutputStream out = null;
		try {
			out = new ObjectOutputStream( new FileOutputStream( ddFile ) );
		} catch ( IOException ioe ) {
			System.err.println( ioe );
		}
		Collection<DataDiscoveryEntry> list = entries.values();
		Iterator<DataDiscoveryEntry> iter = list.iterator();
		try {
			while ( iter.hasNext() ) {
				DataDiscoveryEntry entry = iter.next();
				out.writeObject( entry );
				out.flush();
			}
		} catch ( IOException ioe ) {
			System.err.println( "Error writing to the DD history file." );
		} finally {
			try {
				out.close();
			} catch ( IOException ioe ) {
				System.err.println( ioe );
			}
		}
	}


	/**
	 * Generates the unique identifier for a file location.
	 * 
	 * @param gumClient The target grid machine
	 * @return The unique location identifier
	 */
	private String formatLocation( GumClient gumClient ) {

		String location;
		Map<String,String> atts = gumClient.getGumSpec().getAttributes();
		String shareStor = atts.get( GumSpec.ATT_STORAGE_SHARED );
		String gumSite = atts.get( GumSpec.ATT_SITE );
		String gumName = gumClient.getGumSpec().getGumID().toString();

		if ( gumSite == null ) {
			gumSite = Configuration.getInstance().getProperty( Configuration.PROP_NAME );
		}
		if ( shareStor == "no" || shareStor == null ) {
			location = "file://" + gumSite + "/" + gumName;
		} else {
			location = "file://" + gumSite + "/*";
		}
		return location;
	}


	/**
	 * Generates the unique identifier for a file location.
	 * 
	 * @param spec The specifications of the target grid machine
	 * @return The unique location identifier
	 */
	private String formatLocation( GumSpec spec ) {

		String location;
		String shareStor = spec.getAttribute( GumSpec.ATT_STORAGE_SHARED );

		GumID gumID = spec.getGumID();

		String gumSite = gumID.getPeerName() + ":" + gumID.getPeerPort();
		String gumName = gumID.getGumName() + ":" + gumID.getGumPort();

		if ( shareStor == "no" || shareStor == null ) {
			location = "file://" + gumSite + "/" + gumName;
		} else {
			location = "file://" + gumSite + "/*";
		}
		return location;
	}


	/**
	 * Instantiate the Data Discovery lookup table
	 */
	public synchronized static DataDiscovery initDataDiscovery( boolean cacheFile ) throws DDInitException {

		DataDiscovery dd = ddLookup.get( new Boolean( true ) );
		if ( dd == null ) {
			dd = new DataDiscovery( cacheFile );
			ddLookup.put( new Boolean( true ), dd );
			return dd;
		}
		throw new DDInitException( "DataDiscovery is already initialized." );
	}


	/**
	 * Erases the DataDiscovery lookup table.
	 */
	public static void resetInstance() {

		entries.clear();
	}


	/**
	 * Allow other objects to use the same DD instance
	 * 
	 * @return the current DD instance
	 */
	public static DataDiscovery getInstance() {

		return ddLookup.get( new Boolean( true ) );
	}


	/**
	 * Records STORE file transfer activity for repeated transfers. If an entry
	 * for the file already exists, the location information is updated.
	 * 
	 * @param fileDigest Digest of a transfered file. Used as primary key.
	 * @param remotePath Destination file system path of transfered file.
	 * @param fileSize The size in bytes of the file transfered.
	 * @param spec The destination GuM's specification
	 */
	public void putDDEntry( String fileDigest, String remotePath, long fileSize, GumSpec spec ) {

		String location;
		String filePath;
		long toDay = System.currentTimeMillis();
		location = formatLocation( spec );
		filePath = location + remotePath;

		if ( entries.containsKey( fileDigest ) ) {
			DataDiscoveryEntry entry = entries.get( fileDigest );
			entry.setLocation( filePath, toDay );
		} else {
			DataDiscoveryEntry entry = new DataDiscoveryEntry( fileDigest, fileSize, filePath, toDay );
			entries.put( fileDigest, entry );
		}

	}


	/**
	 * Records STORE file transfer activity for repeated transfers. If an entry
	 * for the file already exists, the location information is updated.
	 * 
	 * @param fileDigest Digest of a transfered file. Used as primary key.
	 * @param remotePath Destination file system path of transfered file.
	 * @param fileSize The size in bytes of the file transfered.
	 * @param gum The destination GuM's specification
	 */
	public void putDDEntry( String fileDigest, String remotePath, long fileSize, GumClient gum ) {

		String location;
		String filePath;
		long toDay = System.currentTimeMillis();
		location = formatLocation( gum );
		filePath = location + remotePath;

		if ( entries.containsKey( fileDigest ) ) {
			DataDiscoveryEntry entry = entries.get( fileDigest );
			entry.setLocation( filePath, toDay );
		} else {
			DataDiscoveryEntry entry = new DataDiscoveryEntry( fileDigest, fileSize, filePath, toDay );
			entries.put( fileDigest, entry );
		}

	}


	/**
	 * Retrieves an entry for a given file digest
	 * 
	 * @param fileDigest Digest of a transfered file.
	 * @return DataDiscoveryEntry
	 * @throws DDEntryNotFoundException
	 */
	public DataDiscoveryEntry getDDEntry( String fileDigest ) throws DDEntryNotFoundException {

		if ( entries.containsKey( fileDigest ) ) {
			return entries.get( fileDigest );
		}
		throw new DDEntryNotFoundException( "No DataDiscoveryEntry with such key!" );

	}


	/**
	 * Removes invalid locations from an entry and deletes an entry if its
	 * location sub-table is empty.
	 * 
	 * @param fileDigest Digest of a transfered file.
	 * @param remotePath Destination file system path of transfered file.
	 * @param spec The destination GuM's specification.
	 */
	public void modDDEntry( String fileDigest, String remotePath, GumSpec spec ) {

		DataDiscoveryEntry entry;
		String location;
		String filePath;
		try {
			entry = getDDEntry( fileDigest );
		} catch ( DDEntryNotFoundException noDD ) {
			return;
		}
		Map<String,Long> locations = entry.getLocations();

		location = formatLocation( spec );
		filePath = location + remotePath;

		locations.remove( filePath );
		if ( locations.isEmpty() ) {
			entries.remove( fileDigest );
		}
	}


	/**
	 * Determines the number of unique files listed in the Data Discovery table
	 * 
	 * @return number of entries
	 */
	public int numberOfEntries() {

		return entries.size();
	}


	/**
	 * Determines whether a file is at a specific location
	 * 
	 * @param localPath Local file system path of transfered file.
	 * @param remotePath Destination file system path of transfered file.
	 * @param gumClient Destination GuM
	 * @return size of the file if found, 0 if not found
	 */
	public long amountAtDestination( String localPath, String remotePath, GumClient gumClient ) {

		File file = new File( localPath );
		String targetLocation;
		String filePath;
		DataDiscoveryEntry entry = null;

		targetLocation = formatLocation( gumClient );
		filePath = targetLocation + remotePath;

		try {
			String digest = JavaFileUtil.getDigestRepresentation( file );
			entry = getDDEntry( digest );
		} catch ( UnableToDigestFileException exception ) {
			LOG.error( "", exception );
			return 0L;
		} catch ( DDEntryNotFoundException noDD ) {
			return 0L;
		}
		Map<String,Long> locations = entry.getLocations();
		if ( locations.containsKey( filePath ) ) {
			return entry.getSize();
		}
		return 0L;

private void unbindAndUnexportRMIObjects() {

		try {

			Naming.unbind( MyGridURLProvider.scheduler() );

		} catch ( RemoteException e ) {
			LOG.error( "Could not contact registry:" + e.getMessage() );
		} catch ( MalformedURLException e ) {
			LOG.error( "MalformedURLException (this should never happen):" + e.getMessage() );
		} catch ( NotBoundException e ) {
			LOG.debug( MyGridURLProvider.scheduler() + " is already unbound:" + e.getMessage() );
		}

		try {
			OurgridUnicastRemoteObject.unexportObject( this.scheduler, true );
		} catch ( NoSuchObjectException e1 ) {
			LOG.debug( "Object " + this.scheduler + " is already unexported: " + e1.getMessage() );
		}

		try {
			Naming.unbind( MyGridURLProvider.gumpManager() );
		} catch ( RemoteException e ) {
			LOG.error( "Could not contact registry:" + e.getMessage() );
		} catch ( MalformedURLException e ) {
			LOG.error( "MalformedURLException (this should never happen):" + e.getMessage() );
		} catch ( NotBoundException e ) {
			LOG.debug( MyGridURLProvider.gumpManager() + " is already unbound:" + e.getMessage() );
		}

		try {
			OurgridUnicastRemoteObject.unexportObject( this.gumpManager, true );
		} catch ( NoSuchObjectException e2 ) {
			LOG.debug( "Object " + this.gumpManager + " is already unexported: " + e2.getMessage() );
		}

		try {
			Naming.unbind( MyGridURLProvider.gridManager() );
		} catch ( RemoteException e ) {
			LOG.error( "Could not contact registry:" + e.getMessage() );
		} catch ( MalformedURLException e ) {
			LOG.error( "MalformedURLException (this should never happen):" + e.getMessage() );
		} catch ( NotBoundException e ) {
			LOG.debug( MyGridURLProvider.gridManager() + " is already unbound:" + e.getMessage() );
		}

		try {
			Naming.unbind( MyGridURLProvider.gumpClient() );
		} catch ( RemoteException e ) {
			LOG.error( "Could not contact registry:" + e.getMessage() );
		} catch ( MalformedURLException e ) {
			LOG.error( "MalformedURLException (this should never happen):" + e.getMessage() );
		} catch ( NotBoundException e ) {
			LOG.debug( MyGridURLProvider.gumpClient() + " is already unbound:" + e.getMessage() );
		}

		try {
			OurgridUnicastRemoteObject.unexportObject( this.gumpClient, true );
		} catch ( NoSuchObjectException e2 ) {
			LOG.debug( "Object " + this.gumpClient + " is already unexported: " + e2.getMessage() );
		}

	}


	/**
	 * @see org.ourgrid.common.event.EBSyncShutdownable#isAlive()
	 */
	public boolean isAlive() {

		return this.isAlive;
	}
}*
 * Copyright (c) 2002-2006 Universidade Federal de Campina Grande
 * 
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA
 */
package org.ourgrid.mygrid.scheduler;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * This is the Data Discovery Entry class. It represents a single entry in the
 * Data Discovery lookup table..
 */

public class DataDiscoveryEntry implements Serializable {

	/**
	 * Serial identification of the class. It need to be changed only if the
	 * class interface is changed.
	 */
	private static final long serialVersionUID = 33L;

	/**
	 * This represents the digest of a transfered file. Is used as the primary
	 * key
	 */
	private String digest;

	/** This represents the size in bytes of a file within an entry record */
	private long size;

	/**
	 * This is a sub-table used to map the relationship between file
	 * destinations and the date they were last contacted
	 */
	private HashMap<String,Long> location = new HashMap<String,Long>();


	/*
	 * Empty Constructor
	 */
	public DataDiscoveryEntry() {

	}


	/**
	 * Creates a new Data Discovery entry
	 * 
	 * @param fileDigest Digest of a transfered file. Used as primary key.
	 * @param fileSize The size in bytes of the file transfered.
	 * @param fileLocation The full path (file://site/remote_path) of the file's
	 *        destination
	 * @param expireDate The date at which the location information is no longer
	 *        valid. Not yet used.
	 */
	public DataDiscoveryEntry( String fileDigest, long fileSize, String fileLocation, long expireDate ) {

		this.digest = fileDigest;
		this.size = fileSize;
		this.location.put( fileLocation, new Long( expireDate ) );
	}


	/**
	 * Assigns the digest value for this entry
	 * 
	 * @param fileDigest Digest of a transfered file. Used as primary key.
	 */
	public void setDigest( String fileDigest ) {

		this.digest = fileDigest;
	}


	/**
	 * Assigns the file size value for this entry
	 * 
	 * @param fileSize The size in bytes of the file transfered.
	 */
	public void setSize( long fileSize ) {

		this.size = fileSize;
	}


	/**
	 * Adds a valid location and time-stamp to the locations sub-table
	 * 
	 * @param fileLocation The full path (file://site/remote_path) of the file's
	 *        destination
	 * @param expireDate The date at which the location information is no longer
	 *        valid. Not yet used.
	 */
	public void setLocation( String fileLocation, long expireDate ) {

		location.put( fileLocation, new Long( expireDate ) );
	}


	/** Returns an entry's file digest */
	public String getDigest() {

		return this.digest;
	}


	/** Returns an enttry's file size */
	public long getSize() {

		return this.size;
	}


	/** Returns an entry's locations sub-table */
	public Map<String,Long> getLocations() {

		return this.location;
	}


	/** Formats an entry as a string */
	public String toString() {

		StringBuffer message = new StringBuffer();
		Iterator<String> it = this.location.keySet().iterator();

		message.append( "File " + this.digest + " of size " + this.size + " is at:\n" );
		while ( it.hasNext() ) {
			String key = it.next();
			message.append( "     [" + key + " - " + this.location.get( key ) + "]\n" );
		}

		return message.toString();
	}/*
 * Copyright (c) 2002-2006 Universidade Federal de Campina Grande
 * 
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA
 */
package org.ourgrid.mygrid.scheduler;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.ourgrid.common.config.Configuration;
import org.ourgrid.common.exception.UnableToDigestFileException;
import org.ourgrid.common.gum.GumClient;
import org.ourgrid.common.id.GumID;
import org.ourgrid.common.spec.GumSpec;
import org.ourgrid.common.util.JavaFileUtil;
import org.ourgrid.mygrid.scheduler.exception.DDEntryNotFoundException;
import org.ourgrid.mygrid.scheduler.exception.DDInitException;

/**
 * This is the Data Discovery class. It generates a record of all successful
 * file transfers resulting from STORE directives defined in Job Description
 * Files. This list is made available to Storage Affinity for ([file size] +
 * [location]) discovery.
 */

public class DataDiscovery {

	/** Logger (log4j) object to store log events */
	private static transient final org.apache.log4j.Logger LOG = org.apache.log4j.Logger
			.getLogger( DataDiscovery.class );

	/**
	 * Duration of entry validity. Not yet used.
	 */
	public static final long DEFAULT_DURATION = 604800000L;

	/**
	 * Default name for the DD cache file
	 */
	private static String ddCache = "ddCache.log";

	/**
	 * HashMap containing DD instances
	 */
	private static HashMap<Boolean,DataDiscovery> ddLookup = new HashMap<Boolean,DataDiscovery>();

	/**
	 * HashMap containing DDEntries that have been recorded
	 */
	private static HashMap<String,DataDiscoveryEntry> entries = new HashMap<String,DataDiscoveryEntry>();

	/**
	 * File form of cached entries.
	 */
	private File ddFile;


	/**
	 * The constructor. Reads the history file from disk to populate the lookup
	 * table, or creates a new one if directed to do so. Writes active entries
	 * to disk when the Data Discovery is terminated.
	 * 
	 * @param cachefile Indicates if the Data Discovery log should be generated.
	 */
	private DataDiscovery( boolean cacheFile ) {

		if ( cacheFile ) {
			String ddPath = Configuration.getInstance().getRootDir() + File.separator + ddCache;
			ddFile = new File( ddPath );

			try {
				if ( !(ddFile.exists()) ) {
					ddFile.createNewFile();
				}
			} catch ( IOException ioe ) {
				System.err.println( "Cannot create DD history file ! STORE activity will not be logged." );
			}

			/*
			 * If entries exist, load them into the table.
			 */
			if ( ddFile.length() > 0L ) {
				readHistory();
			}

			/*
			 * Write entries to file when DD exits.
			 */
			Runtime.getRuntime().addShutdownHook( new Thread( "Data Discovery Shutdown Hook" ) {

				@Override
				public void run() {

					writeHistory();
				}
			} );
		}
	}


	private void readHistory() {

		String digest;
		DataDiscoveryEntry entry;
		FileInputStream fileInput;
		ObjectInputStream objInput = null;
		try {
			fileInput = new FileInputStream( ddFile );
			objInput = new ObjectInputStream( fileInput );
		} catch ( FileNotFoundException exception ) {
			System.err.println( "Cannot find the DD history file !!!" );
		} catch ( IOException exception ) {
			System.err.println( "Unable to open object stream !!!" );
		}

		try {
			while ( true ) {
				entry = (DataDiscoveryEntry) objInput.readObject();
				digest = entry.getDigest();
				entries.put( digest, entry );
			}
		} catch ( EOFException eof ) {
		} catch ( ClassNotFoundException noClass ) {
		} catch ( IOException ioe ) {
		} finally {
			try {
				objInput.close();
			} catch ( IOException ioe ) {
			}
		}
	}


	private void writeHistory() {

		ObjectOutputStream out = null;
		try {
			out = new ObjectOutputStream( new FileOutputStream( ddFile ) );
		} catch ( IOException ioe ) {
			System.err.println( ioe );
		}
		Collection<DataDiscoveryEntry> list = entries.values();
		Iterator<DataDiscoveryEntry> iter = list.iterator();
		try {
			while ( iter.hasNext() ) {
				DataDiscoveryEntry entry = iter.next();
				out.writeObject( entry );
				out.flush();
			}
		} catch ( IOException ioe ) {
			System.err.println( "Error writing to the DD history file." );
		} finally {
			try {
				out.close();
			} catch ( IOException ioe ) {
				System.err.println( ioe );
			}
		}
	}


	/**
	 * Generates the unique identifier for a file location.
	 * 
	 * @param gumClient The target grid machine
	 * @return The unique location identifier
	 */
	private String formatLocation( GumClient gumClient ) {

		String location;
		Map<String,String> atts = gumClient.getGumSpec().getAttributes();
		String shareStor = atts.get( GumSpec.ATT_STORAGE_SHARED );
		String gumSite = atts.get( GumSpec.ATT_SITE );
		String gumName = gumClient.getGumSpec().getGumID().toString();

		if ( gumSite == null ) {
			gumSite = Configuration.getInstance().getProperty( Configuration.PROP_NAME );
		}
		if ( shareStor == "no" || shareStor == null ) {
			location = "file://" + gumSite + "/" + gumName;
		} else {
			location = "file://" + gumSite + "/*";
		}
		return location;
	}


	/**
	 * Generates the unique identifier for a file location.
	 * 
	 * @param spec The specifications of the target grid machine
	 * @return The unique location identifier
	 */
	private String formatLocation( GumSpec spec ) {

		String location;
		String shareStor = spec.getAttribute( GumSpec.ATT_STORAGE_SHARED );

		GumID gumID = spec.getGumID();

		String gumSite = gumID.getPeerName() + ":" + gumID.getPeerPort();
		String gumName = gumID.getGumName() + ":" + gumID.getGumPort();

		if ( shareStor == "no" || shareStor == null ) {
			location = "file://" + gumSite + "/" + gumName;
		} else {
			location = "file://" + gumSite + "/*";
		}
		return location;
	}


	/**
	 * Instantiate the Data Discovery lookup table
	 */
	public synchronized static DataDiscovery initDataDiscovery( boolean cacheFile ) throws DDInitException {

		DataDiscovery dd = ddLookup.get( new Boolean( true ) );
		if ( dd == null ) {
			dd = new DataDiscovery( cacheFile );
			ddLookup.put( new Boolean( true ), dd );
			return dd;
		}
		throw new DDInitException( "DataDiscovery is already initialized." );
	}


	/**
	 * Erases the DataDiscovery lookup table.
	 */
	public static void resetInstance() {

		entries.clear();
	}


	/**
	 * Allow other objects to use the same DD instance
	 * 
	 * @return the current DD instance
	 */
	public static DataDiscovery getInstance() {

		return ddLookup.get( new Boolean( true ) );
	}


	/**
	 * Records STORE file transfer activity for repeated transfers. If an entry
	 * for the file already exists, the location information is updated.
	 * 
	 * @param fileDigest Digest of a transfered file. Used as primary key.
	 * @param remotePath Destination file system path of transfered file.
	 * @param fileSize The size in bytes of the file transfered.
	 * @param spec The destination GuM's specification
	 */
	public void putDDEntry( String fileDigest, String remotePath, long fileSize, GumSpec spec ) {

		String location;
		String filePath;
		long toDay = System.currentTimeMillis();
		location = formatLocation( spec );
		filePath = location + remotePath;

		if ( entries.containsKey( fileDigest ) ) {
			DataDiscoveryEntry entry = entries.get( fileDigest );
			entry.setLocation( filePath, toDay );
		} else {
			DataDiscoveryEntry entry = new DataDiscoveryEntry( fileDigest, fileSize, filePath, toDay );
			entries.put( fileDigest, entry );
		}

	}


	/**
	 * Records STORE file transfer activity for repeated transfers. If an entry
	 * for the file already exists, the location information is updated.
	 * 
	 * @param fileDigest Digest of a transfered file. Used as primary key.
	 * @param remotePath Destination file system path of transfered file.
	 * @param fileSize The size in bytes of the file transfered.
	 * @param gum The destination GuM's specification
	 */
	public void putDDEntry( String fileDigest, String remotePath, long fileSize, GumClient gum ) {

		String location;
		String filePath;
		long toDay = System.currentTimeMillis();
		location = formatLocation( gum );
		filePath = location + remotePath;

		if ( entries.containsKey( fileDigest ) ) {
			DataDiscoveryEntry entry = entries.get( fileDigest );
			entry.setLocation( filePath, toDay );
		} else {
			DataDiscoveryEntry entry = new DataDiscoveryEntry( fileDigest, fileSize, filePath, toDay );
			entries.put( fileDigest, entry );
		}

	}


	/**
	 * Retrieves an entry for a given file digest
	 * 
	 * @param fileDigest Digest of a transfered file.
	 * @return DataDiscoveryEntry
	 * @throws DDEntryNotFoundException
	 */
	public DataDiscoveryEntry getDDEntry( String fileDigest ) throws DDEntryNotFoundException {
* Determines the number of unique files listed in the Data Discovery table
	 * 
	 * @return number of entries
	 */
	public int numberOfEntries() {

		return entries.size();
	}


	/**
	 * Determines whether a file is at a specific location
	 * 
	 * @param localPath Local file system path of transfered file.
	 * @param remotePath Destination file system path of transfered file.
	 * @param gumClient Destination GuM
	 * @return size of the file if found, 0 if not found
	 */
	public long amountAtDestination( String localPath, String remotePath, GumClient gumClient ) {

		File file = new File( localPath );
		String targetLocation;
		String filePath;
		DataDiscoveryEntry entry = null;

		Map<String,Long> locations = entry.getLocations();
		if ( locations.containsKey( filePath ) ) {
			return entry.getSize();
		}
	