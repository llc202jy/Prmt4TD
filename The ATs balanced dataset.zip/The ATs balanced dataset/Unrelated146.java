package net.sourceforge.concurrentQuery.article.serialized;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import net.sourceforge.concurrentQuery.test.pool.JDCConnectionDriver;

public class SleepyObject {   
	private String jdbcDriver = "org.postgresql.Driver";
	private String jdbcURL = "jdbc:postgresql://localhost:5432/test?user=postgres";
	private String jdbcPoolURL = "jdbc:jdc:jdcpool";
	private String jdbcUser = "postgres";
	private String jdbcPasswd = "postgres";
	
	private int value = 0;
	
	public SleepyObject(int sleepSeconds) throws SQLException {
		
	    try {
	    		Class.forName(jdbcDriver).newInstance();
	    } catch (Exception e) {
	    		throw new SQLException(e.getMessage());
	    }
	    try {
	    		new JDCConnectionDriver(jdbcDriver, jdbcURL, jdbcUser, jdbcPasswd);
	    } catch (Exception e) {
	    		throw new SQLException(e.getMessage());
	    }
		create(sleepSeconds);
	}
	
	private void create(int sleepSeconds) throws SQLException {
		Connection connection = DriverManager.getConnection(jdbcPoolURL, jdbcUser, jdbcPasswd);
	    Statement statement = connection.createStatement();
	    String sql = "select sleep(" + sleepSeconds + ")";
	    System.out.println("query is: " + sql);
	    if (statement.execute(sql)) {
	    		ResultSet resultSet = statement.getResultSet();
	    		if (resultSet.next()) {
	    			value = resultSet.getInt(1);
	    		}
	    		connection.close();
	    }
	}
	
	public int getValue() {
		return value;
	}
}import java.sql.SQLException;

public class Example1 {

    public Example1() {}
    public static void main(String[] args) throws SQLException {
	    
	    long start = System.currentTimeMillis();
	    
	    SleepyObject[] sleepyObjects = { 	new SleepyObject(2),
	    									new SleepyObject(1),
	    									new SleepyObject(2),
	    									new SleepyObject(2),
	    									new SleepyObject(1)
	    								 };
	    int i = 1;
	    for (SleepyObject sleepyObject : sleepyObjects) {	    	    
	    		System.out.println("SleepyObject " + i++ + " returned " 
	    				           + sleepyObject.getValue());
	    }
        long end = System.currentTimeMillis();
        System.out.println("took: " + new Float(end - start) / 1000 + " seconds");
	    
	    
    }
}    
package net.sourceforge.concurrentQuery.domain.model.test;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import net.sourceforge.concurrentQuery.domain.model.CityInfo;
import net.sourceforge.concurrentQuery.domain.model.CityList;
import net.sourceforge.concurrentQuery.domain.model.CountryList;
import net.sourceforge.concurrentQuery.query.ConcurrentQueryFactoryBroker;
import net.sourceforge.concurrentQuery.query.ConcurrentQueryInterface;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class ModelDriver {
    private static Logger logger = Logger.getLogger(ModelDriver.class);
    public static void main(String[] args) throws SQLException {

    		try {
	        BasicConfigurator.configure();
	        Logger.getRootLogger().setLevel(Level.WARN);
	        long start = System.currentTimeMillis();
	        ConcurrentQueryInterface cq = ConcurrentQueryFactoryBroker.getInstance().createConcurrentQuery();
	        CountryList countryList = new CountryList(75);
	        long end = System.currentTimeMillis();
	
	        printResults(countryList);
	        System.out.println("took: " + new Long(end - start) + " millis");
    		} finally {
    			ConcurrentQueryFactoryBroker.getInstance().createConcurrentQuery().shutdown();
    		}

        return;


    }

    private static void printResults(CountryList cl) {
        for (String country : cl.getMapOfCountries().keySet()) {
            System.out.println("Country Code: " + country);
            Map<String, CityList> districtMap = cl.getMapOfCountries().get(country).getMapOfDistricts();
            for (String district : districtMap.keySet()) {
                System.out.println("\tDistrict: " + district);
                List<CityInfo> cityList = districtMap.get(district).getListOfCities();
                for (CityInfo cityInfo : cityList) {
                    System.out.println("\t\tcity name: " + cityInfo.getName() + ", population: " + cityInfo.getPopulation());
                }
            }
        }
    }
    
}