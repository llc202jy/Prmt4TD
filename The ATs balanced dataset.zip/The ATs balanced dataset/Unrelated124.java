/* The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License). You may not use this file except in
 * compliance with the License.
 *
 * You can obtain a copy of the License at
 * https://opensso.dev.java.net/public/CDDLv1.0.html or
 * opensso/legal/CDDLv1.0.txt
 * See the License for the specific language governing
 * permission and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at opensso/legal/CDDLv1.0.txt.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * your own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * $Id: CookieUtils.java,v 1.2 2006/08/25 21:19:57 veiming Exp $
 *
 * Copyright 2005 Sun Microsystems Inc. All Rights Reserved
 */

package com.iplanet.services.util;

import com.iplanet.am.util.SystemProperties;
import com.sun.identity.shared.Constants;
import com.sun.identity.shared.debug.Debug;
import com.sun.identity.shared.encode.URLEncDec;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.StringTokenizer;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

/**
 * Implements utility methods for handling Cookie.
 *
 * @deprecated As of OpenSSO version 8.0
 *             {@link com.sun.identity.shared.encode.CookieUtils}
 */

public class CookieUtils {
    static boolean secureCookie = (SystemProperties
            .get(Constants.AM_COOKIE_SECURE) != null && SystemProperties.get(
            Constants.AM_COOKIE_SECURE).equalsIgnoreCase("true"));

    static boolean cookieEncoding = (SystemProperties
            .get(Constants.AM_COOKIE_ENCODE) != null && SystemProperties.get(
            Constants.AM_COOKIE_ENCODE).equalsIgnoreCase("true"));

    static String amCookieName = SystemProperties.get(Constants.AM_COOKIE_NAME);

    static String amPCookieName = SystemProperties
            .get(Constants.AM_PCOOKIE_NAME);

    static String cdssoCookiedomain = SystemProperties
            .get(Constants.SERVICES_CDSSO_COOKIE_DOMAIN);

    static String fedCookieName = SystemProperties
            .get(Constants.FEDERATION_FED_COOKIE_NAME);

    private static Set cookieDomains = null;

    private static int defAge = -1;

    static Debug debug = Debug.getInstance("amCookieUtils");

    /**
     * Gets property value of "com.iplanet.am.cookie.name"
     * 
     * @return the property value of "com.iplanet.am.cookie.name"
     */
    public static String getAmCookieName() {
        return amCookieName;
    }

    /**
     * Gets property value of "com.iplanet.am.pcookie.name"
     * 
     * @return the property value of "com.iplanet.am.pcookie.name"
     */
    public static String getAmPCookieName() {
        return amPCookieName;
    }

    /**
     * Gets property value of "com.iplanet.services.cdsso.cookiedomain"
     * 
     * @return the property value of "com.iplanet.services.cdsso.cookiedomain"
     */
    public static Set getCdssoCookiedomain() {
        if (cookieDomains != null) {
            return cookieDomains;
        }

        Set cookieDomains = new HashSet();
        if (cdssoCookiedomain == null || cdssoCookiedomain.length() < 1) {
            return Collections.EMPTY_SET;
        }

        StringTokenizer st = new StringTokenizer(cdssoCookiedomain, ",");
        while (st.hasMoreTokens()) {
            String token = st.nextToken().trim();
            if (token.length() > 0) {
                cookieDomains.add(token);
            }
        }

        if (cookieDomains.isEmpty()) {
            return Collections.EMPTY_SET;
        }

        return cookieDomains;
    }

    /**
     * Gets property value of "com.sun.identity.federation.fedCookieName"
     * 
     * @return the property value of "com.sun.identity.federation.fedCookieName"
     */
    public static String getFedCookieName() {
        return fedCookieName;
    }

    /**
     * Gets property value of "com.iplanet.am.cookie.secure"
     * 
     * @return the property value of "com.iplanet.am.cookie.secure"
     */
    public static boolean isCookieSecure() {
        return secureCookie;
    }

    /**
     * Gets value of cookie that has mached name in servlet request
     * 
     * @param HttpServletRequest
     *            request
     * @param cookie
     *            name in servlet request
     * @return value of that name of cookie
     */
    public static String getCookieValueFromReq(HttpServletRequest req,
            String name) {
        String cookieValue = null;
        try {
            Cookie cookie = getCookieFromReq(req, name);
            if (cookie != null) {
                return getCookieValue(cookie);
            } else {
                debug.message("No Cookie is in the request");
            }
        } catch (Exception e) {
            debug.error("Error getting cookie  : ", e);
        }

        return cookieValue;
    }

    /**
     * Gets cookie object that has mached name in servlet request
     * 
     * @param HttpServletRequest
     *            request
     * @param cookie
     *            name in servlet request
     * @return value of that name of cookie
     */
    public static Cookie getCookieFromReq(HttpServletRequest req, String name) {
        Cookie cookies[] = req.getCookies();
        if (cookies != null) {
            for (int nCookie = 0; nCookie < cookies.length; nCookie++) {
                if (cookies[nCookie].getName().equalsIgnoreCase(name)) {
                    return cookies[nCookie];
                }
            }
        }
        return null;
    }

    /**
     * Gets normalized value of cookie
     * 
     * @param cookie
     *            cookie object
     * @return value
     */
    public static String getCookieValue(Cookie cookie) {
        String cookieValue = checkDoubleQuote(cookie.getValue());

        // Check property value and it decode value
        // Bea, IBM
        if (cookieValue != null && cookieEncoding) {
            return URLEncDec.decode(cookieValue);
        }
        return cookieValue;
    }

    /**
     * Gets Array of cookie in servlet request
     * 
     * @param HttpServletRequest
     *            request
     * 
     */
    public static Cookie[] getCookieArrayFromReq(HttpServletRequest req) {
        Cookie cookies[] = req.getCookies();

        if (!cookieEncoding) {
            return cookies;
        }

        if (cookies != null) {
            for (int nCookie = 0; nCookie < cookies.length; nCookie++) {
                String cookieValue = checkDoubleQuote(cookies[nCookie]
                        .getValue());
                if (cookieValue != null) {
                    cookies[nCookie].setValue(URLEncDec.decode(cookieValue));
                }
            }
        }
        return cookies;
    }

    /**
     * Constructs a cookie with a specified name and value.
     * 
     * @param name
     *            a String specifying the name of the cookie
     * 
     * @param value
     *            a String specifying the value of the cookie
     * 
     * @return constructed cookie
     */
    public static Cookie newCookie(String name, String value) {
        return newCookie(name, value, defAge, null, null);
    }

    /**
     * Constructs a cookie with a specified name and value and sets the maximum
     * age of the cookie in seconds.
     * 
     * @param name
     *            a String specifying the name of the cookie
     * 
     * @param value
     *            a String specifying the value of the cookie
     * 
     * @param maxAge
     *            an integer specifying the maximum age of the cookie in
     *            seconds; if negative, means the cookie is not stored; if zero,
     *            deletes the cookie
     * 
     * @return constructed cookie
     */
    public static Cookie newCookie(String name, String value, int maxAge) {
        return newCookie(name, value, maxAge, null, null);
    }

    /**
     * Constructs a cookie with a specified name and value and sets a path for
     * the cookie to which the client should return the cookie.
     * 
     * @param name
     *            a String specifying the name of the cookie
     * 
     * @param value
     *            a String specifying the value of the cookie
     * 
     * @param path
     *            a String specifying a path
     * 
     * @return constructed cookie
     */
    public static Cookie newCookie(String name, String value, String path) {
        return newCookie(name, value, defAge, path, null);
    }

    /**
     * Constructs a cookie with a specified name and value and sets a path for
     * the cookie to which the client should return the cookie and sets the
     * domain within which this cookie should be presented.
     * 
     * @param name
     *            a String specifying the name of the cookie
     * 
     * @param value
     *            a String specifying the value of the cookie
     * 
     * @param path
     *            a String specifying a path
     * 
     * @param domain
     *            a String containing the domain name within which this cookie
     *            is visible; form is according to <code>RFC 2109</code>
     * 
     * @return constructed cookie
     */
    public static Cookie newCookie(String name, String value, String path,
            String domain) {
        return newCookie(name, value, defAge, path, domain);
    }

    /**
     * Constructs a cookie with a specified name and value and sets the maximum
     * age of the cookie in seconds and sets a path for the cookie to which the
     * client should return the cookie and sets the domain within which this
     * cookie should be presented.
     * 
     * @param name
     *            a String specifying the name of the cookie
     * 
     * @param value
     *            a String specifying the value of the cookie
     * 
     * @param maxAge
     *            an integer specifying the maximum age of the cookie in
     *            seconds; if negative, means the cookie is not stored; if zero,
     *            deletes the cookie
     * 
     * @param path
     *            a String specifying a path
     * 
     * @param domain
     *            a String containing the domain name within which this cookie
     *            is visible; form is according to RFC 2109
     * 
     * @return constructed cookie
     */
    public static Cookie newCookie(String name, String value, int maxAge,
            String path, String domain) {
        Cookie cookie = null;

        // Based on property value it does url encoding.
        // BEA, IBM
        if (cookieEncoding) {
            cookie = new Cookie(name, URLEncDec.encode(value));
        } else {
            cookie = new Cookie(name, value);
        }

        cookie.setMaxAge(maxAge);

        if ((path != null) && (path.length() > 0)) {
            cookie.setPath(path);
        } else {
            cookie.setPath("/");
        }

        if ((domain != null) && (domain.length() > 0)) {
            cookie.setDomain(domain);
        }

        cookie.setSecure(isCookieSecure());

        return cookie;
    }

    /**
     * Check cookie value whether it has double quote or not. Remove start /
     * ending double quote from cookie and returns cookie value only.
     * 
     * @param cookie
     *            a String value of cookie
     * 
     * @return cookie value without double quote
     */
    public static String checkDoubleQuote(String cookie) {
        String double_quote = "\"";

        if ((cookie != null) && cookie.startsWith(double_quote)
                && cookie.endsWith(double_quote)) {
            int last = cookie.length() - 1;
            cookie = cookie.substring(1, last);
        }
        return cookie;
    }
}
* The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License). You may not use this file except in
 * compliance with the License.
 *
 * You can obtain a copy of the License at
 * https://opensso.dev.java.net/public/CDDLv1.0.html or
 * opensso/legal/CDDLv1.0.txt
 * See the License for the specific language governing
 * permission and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at opensso/legal/CDDLv1.0.txt.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * your own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * $Id: XMLParser.java,v 1.1 2005/11/01 00:30:27 arvindp Exp $
 *
 * Copyright 2005 Sun Microsystems Inc. All Rights Reserved
 */

package com.iplanet.services.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Hashtable;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * <p>
 * XMLParser provides a way for applications to handle a hook into applications
 * and applications and it's server.
 * </p>
 */

public class XMLParser {
    private Hashtable elemmap = new Hashtable();

    private boolean useGenericClass = false;

    /*
     * static public void main(String argv[]) throws Exception { XMLParser wp =
     * new XMLParser(true); GenericNode n = (GenericNode) wp.parse(new
     * FileInputStream(argv[0])); System.out.println("FINAL:"+n.toString()); }
     */

    ParseOutput walkTree(Node nd) throws XMLException {
        Vector elements = new Vector();
        String pcdata = null;
        Hashtable atts = new Hashtable();
        NamedNodeMap nd_map = nd.getAttributes();
        if (nd_map != null) {
            for (int i = 0; i < nd_map.getLength(); i++) {
                Node att = nd_map.item(i);
                atts.put(att.getNodeName(), att.getNodeValue());
            }
        }
        for (Node ch = nd.getFirstChild(); ch != null; ch = ch.getNextSibling())
        {
            switch (ch.getNodeType()) {
            case Node.ELEMENT_NODE:
                elements.addElement(walkTree(ch));
                break;
            case Node.TEXT_NODE:
                String tmp = stripWhitespaces(ch.getNodeValue());
                if (tmp != null && tmp.length() != 0)
                    pcdata = tmp;
                break;
            default:
            // System.out.println("DBG: Ignoring :"+ch.getNodeType());
            }

        }
        // lookup hash
        String po_name = (String) elemmap.get(nd.getNodeName());
        ParseOutput po;
        if (po_name == null) {
            if (useGenericClass)
                po = new GenericNode();
            else
                throw new XMLException("No class registered for"
                        + nd.getNodeName());
        } else {
            try {
                po = (ParseOutput) Class.forName(po_name).newInstance();
            } catch (Exception ex) {
                StringBuffer buf = new StringBuffer();
                buf.append("Got Exception while creating class instance of ");
                buf.append(nd.getNodeName());
                buf.append(" :");
                buf.append(ex.toString());
                throw new XMLException(buf.toString());
            }
        }
        po.process(nd.getNodeName(), elements, atts, pcdata);
        return po;
    }

    String stripWhitespaces(String s) {
        return s.trim();
    }

    /**
     * <p>
     * The application have to implement Parseoutput interface when use
     * constructor without parameter.
     * </p>
     */
    public XMLParser() {
    }

    /**
     * <p>
     * Use default GenericNode as node type if usegeneric is true.
     * </p>
     * 
     * @param usegeneric
     */
    public XMLParser(boolean usegeneric) {
        useGenericClass = usegeneric;
    }

    /**
     * Parses an XML document from a String variable.
     */
    public Object parse(String s) throws XMLException {
        ByteArrayInputStream bin = null;
        String st = stripWhitespaces(s);
        try {
            bin = new ByteArrayInputStream(st.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException ex) {
            throw new XMLException("Encoding not supported:" + ex.toString());
        }
        return parse(bin);
    }

    /**
     * <p>
     * Parse an XML document.
     * </p>
     */
    public Object parse(InputStream xmlin) throws XMLException {

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        DocumentBuilder db = null;
        try {
            db = dbf.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            throw new XMLException("DBG:Got ParserConfigurationException:"
                    + e.toString());
        }

        Document doc = null;
        try {
            doc = db.parse(xmlin);
        } catch (SAXParseException e) {
            throw new XMLException("DBG:Got SAXParseException:" + e.toString()
                    + "line:" + e.getLineNumber() + " col :"
                    + e.getColumnNumber());
        } catch (SAXException e) {
            throw new XMLException("DBG:Got SAXException:" + e.toString());
        } catch (IOException ex) {
            throw new XMLException("DBG: Got IOException:" + ex.toString());
        }

        Element elem = doc.getDocumentElement();
        return (walkTree(elem));

    }
	
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

/**
 * This class configures SP & IDP deployed war's if it hasn't done so.
 * Also it creates COT on both instances, loads IDFF meta on both side with
 * one as SP & one as IDP.
 */
public class ConfigureIDFFProtocols extends IDFFCommon {
    private WebClient webClient;
    private Map<String, String> configMap;
    private String  baseDir;
    private String spurl;
    private String idpurl;
    private String spmetadata;
    private String spmetadataext;
    private FederationManager fmSP;
    private FederationManager fmIDP;
    
    /** Creates a new instance of ConfigureIDFF */
    public ConfigureIDFFProtocols() {
        super("ConfigureIDFFProtocols");
    }
    
    /**
     * Create the webClient which should be run before each test.
     */
    private void getWebClient()
    throws Exception {
        try {
            webClient = new WebClient(BrowserVersion.MOZILLA_1_0);
        } catch (Exception e) {
            log(Level.SEVERE, "getWebClient", e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }
    
    /**
     * Configure sp & idp
     * @DocTest: IDFF|Configure SP & IDP by loading metadata on both sides.
     */
    @Parameters({"ssoprofile", "sloprofile", "terminationprofile", 
    "registrationprofile"})
    @BeforeTest(groups={"ldapv3", "ldapv3_sec", "s1ds", "s1ds_sec", "ad", "ad_sec", "amsdk", "amsdk_sec", "jdbc", "jdbc_sec"})
    public void ConfigureIDFFProtocol(String strSSOProfile,
            String strSLOProfile, String strTermProfile, String strRegProfile)
    throws Exception {
        Object[] params = {strSSOProfile, strSLOProfile, 
            strTermProfile, strRegProfile};
        entering("ConfigureIDFF", params);
        try {
            baseDir = getTestBase();
            //Upload global properties file in configMap
            configMap = new HashMap<String, String>();
            configMap = getMapFromResourceBundle("idff" + fileseparator +
                    "idffTestConfigData");
            configMap.putAll(getMapFromResourceBundle("idff" + fileseparator +
                    "idffTestData"));
            log(Level.FINEST, "setup", "Map is " + configMap);
            spurl = configMap.get(TestConstants.KEY_SP_PROTOCOL) +
                    "://" + configMap.get(TestConstants.KEY_SP_HOST) + ":" +
                    configMap.get(TestConstants.KEY_SP_PORT) +
                    configMap.get(TestConstants.KEY_SP_DEPLOYMENT_URI);
            idpurl = configMap.get(TestConstants.KEY_IDP_PROTOCOL) +
                    "://" + configMap.get(TestConstants.KEY_IDP_HOST) + ":" +
                    configMap.get(TestConstants.KEY_IDP_PORT) +
                    configMap.get(TestConstants.KEY_IDP_DEPLOYMENT_URI);
            } catch (Exception e) {
                log(Level.SEVERE, "setup", e.getMessage());
                e.printStackTrace();
                throw e;
            }
        try {
            getWebClient();
            
            //If any of the profile is diff than the default profile, 
            //then only delete & import the metadata. Else leave it as it is. 
            if (strSSOProfile.equals("post") || strSLOProfile.equals("soap") ||
                    strTermProfile.equals("soap") || 
                    strRegProfile.equals("soap")) {
                consoleLogin(webClient, spurl + "/UI/Login",
                    exiting("ConfigureIDFF");
    }
    
    /**
     * Configure sp & idp by loading default SP metadata on both sides
     * @DocTest: IDFF|Unconfigure SP & IDP by loading default SP metadata on 
     * both sides.
     */
    @Parameters({"ssoprofile", "sloprofile", "terminationprofile", 
    "registrationprofile"})
    @AfterTest(groups={"ldapv3", "ldapv3_sec", "s1ds", "s1ds_sec", "ad", "ad_sec", "amsdk", "amsdk_sec", "jdbc", "jdbc_sec"})
    public void UnconfigureIDFFProtocol(String strSSOProfile,
            String strSLOProfile, String strTermProfile, String strRegProfile)
    throws Exception {
        Object[] params = {strSSOProfile, strSLOProfile, 
            strTermProfile, strRegProfile};
        entering("UnconfigureIDFF", params);
        try {
            getWebClient();
            
            consoleLogin(webClient, spurl + "/UI/Login",
                    configMap.get(TestConstants.KEY_SP_AMADMIN_USER),
                    configMap.get(TestConstants.KEY_SP_AMADMIN_PASSWORD));
            consoleLogin(webClient, idpurl + "/UI/Login", configMap.get(
                    TestConstants.KEY_IDP_AMADMIN_USER),
                    configMap.get(TestConstants.KEY_IDP_AMADMIN_PASSWORD));

            //If any of the profile is diff than the default profile, 
            //then only delete & import the metadata. Else leave it as it is. 
            if (strSSOProfile.equals("post") || strSLOProfile.equals("soap") ||
                    strTermProfile.equals("soap") ||
                    strRegProfile.equals("soap")) {
                //Remove & Import Entity with modified metadata. 
                log(Level.FINE, "setup", "Since SP metadata have changed, " +
                        "delete SP entity & Import it again. "); 
                assert (loadSPMetadata(spmetadata, spmetadataext, fmSP, fmIDP, 
                        configMap, webClient, false));
            }
        } catch (Exception e) {
            log(Level.SEVERE, "setup", e.getMessage());
            e.printStackTrace();
            throw e;
        } finally {
            log(Level.FINEST, "cleanup", "Logging out of SP & IDP");
            consoleLogout(webClient, spurl + "/UI/Logout");
            consoleLogout(webClient, idpurl + "/UI/Logout");
        }        
        exiting("ConfigureIDFF");
    }    
}
            configMap.get(TestConstants.KEY_SP_AMADMIN_USER),
                        configMap.get(TestConstants.KEY_SP_AMADMIN_PASSWORD));

                fmSP = new FederationManager(spurl);
                consoleLogin(webClient, idpurl + "/UI/Login", configMap.get(
                        TestConstants.KEY_IDP_AMADMIN_USER),
                        configMap.get(TestConstants.KEY_IDP_AMADMIN_PASSWORD));
                fmIDP = new FederationManager(idpurl);
                HtmlPage spmetaPage = fmSP.exportEntity(webClient,
                        (String)configMap.get(TestConstants.KEY_SP_ENTITY_NAME), 
                        (String)configMap.get(TestConstants.KEY_SP_EXECUTION_REALM),
                        false, true, true, "idff");
                if (FederationManager.getExitCode(spmetaPage) != 0) {
                    log(Level.SEVERE, "setup", "exportEntity famadm command" +
                            " failed");
                    assert false;
                }
                spmetadataext = MultiProtocolCommon.getExtMetadataFromPage(
                        spmetaPage);            
                spmetadata =
                        MultiProtocolCommon.getMetadataFromPage(spmetaPage);

                //if profile is set to post, change the metadata & run the 


    /**
     * <p>
     * Register a call back function.
     * 
     * @param elemname
     *            is the tag name of this node
     * @param classname
     *            is the call back function
     */
    public void register(String elemname, String classname) {
        // TODO : add error checking : if classname exists, null, etc
        if (elemmap == null)
            elemmap = new Hashtable();
        elemmap.put(elemname, classname);
    }
}
