package de.x4technology.tools.generator;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import de.x4technology.helper.lang.StringHelper;

/**
 * @author martin
 */
public class CompilationUnit
{
    public static final int TYPE_CLASS = 0;
    public static final int TYPE_INTERFACE = 1;

    private boolean isPublic = true;
    private boolean isAbstract = true;

    private int type = TYPE_CLASS;
    private String name;

    private Set extendedClasses = new HashSet();
    private Set implementedInterfaces = new HashSet();
    private boolean isFinal = false;

    public CompilationUnit(String name)
    {
        if (name == null) throw new NullPointerException("name");

        if (StringHelper.containsAny(name, new char[]
        { '/', '\\', '$', '.', ',' }))
        {
            throw new IllegalArgumentException("Invalid class name '" + name + "'.");
        }
        this.name = name;
    }

    public CompilationUnit(String name, int type)
    {
        this(name);
        if (type != TYPE_CLASS && type != TYPE_INTERFACE)
        {
            throw new IllegalArgumentException("Illegal type=" + type);
        }
        this.type = type;
    }

    public CompilationUnit(String name, int type, boolean isAbstract)
    {
        this(name, type);
        this.isAbstract = isAbstract;
    }

    public CompilationUnit(String name, int type, boolean isAbstract, boolean isPublic)
    {
        this(name, type, isAbstract);
        this.isPublic = isPublic;
    }

    public String getDeclaration()
    {
        if (type == TYPE_INTERFACE)
        {
            return getDeclarationInterface();
        }
        if (type == TYPE_CLASS)
        {
            return getDeclarationClass();
        }
        throw new IllegalArgumentException("Illegal type=" + type);
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        return getDeclaration();
    }

    /**
     * @return
     */
    private String getDeclarationInterface()
    {
        StringBuffer sb = new StringBuffer();
        if (isPublic)
        {
            sb.append("public ");
        }
        sb.append("abstract interface ");

        sb.append(getUnqualifiedName());
        appendExtends(sb);
        if (!implementedInterfaces.isEmpty())
        {
            throw new IllegalArgumentException("Interface implements interfaces...");
        }
        return sb.toString();
    }

    /**
     * @return
     */
    private String getDeclarationClass()
    {
        StringBuffer sb = new StringBuffer();

        if (isPublic)
        {
            sb.append("public ");
        }
        if (isFinal)
        {
            sb.append("final ");
        }
        if (isAbstract)
        {
            sb.append("abstract ");
        }

        sb.append("class ");
        sb.append(getUnqualifiedName());
        appendExtends(sb);
        appendImplements(sb);
        return sb.toString();
    }

    /**
     * @return
     */
    private String getUnqualifiedName()
    {
        String name = getName();
        if (name.indexOf('.') != -1)
        {
            name = StringHelper.afterLastDot(name);
        }
        return name;
    }

    /**
     * @param sb
     */
    private void appendExtends(StringBuffer sb)
    {
        if (extendedClasses.isEmpty())
        {
            return;
        }
        sb.append(" extends ");
        for (Iterator i = extendedClasses.iterator(); i.hasNext();)
        {
            String cl = (String) i.next();
            sb.append(cl);
            if (i.hasNext())
            {
                sb.append(", ");
            }
        }
    }

    /**
     * @param sb
     */
    private void appendImplements(StringBuffer sb)
    {
        if (implementedInterfaces.isEmpty())
        {
            return;
        }
        sb.append(" implements ");
        for (Iterator i = implementedInterfaces.iterator(); i.hasNext();)
        {
            String cl = (String) i.next();
            sb.append(cl);
            if (i.hasNext())
            {
                sb.append(", ");
            }
        }
    }

    public void addExtends(Class c)
    {
        if (c == null) throw new NullPointerException("c");
        if (c.isInterface() && type == TYPE_CLASS) throw new IllegalArgumentException("given class is an interface");
        if (!c.isInterface() && type == TYPE_INTERFACE)
            throw new IllegalArgumentException("given class is no interface");
        addExtends(c.getName().toString());
    }

    public void addExtends(String s)
    {
        if (type == TYPE_CLASS && !extendedClasses.isEmpty())
        {
            throw new IllegalArgumentException("Java classes cannot extend more than one class");
        }
        extendedClasses.add(s);
    }

    public void addImplements(Class c)
    {
        if (type == TYPE_INTERFACE) throw new IllegalArgumentException("interfaces cannot implement interface");
        if (c == null) throw new NullPointerException("c");
        if (!c.isInterface()) throw new IllegalArgumentException("given class is no interface");
        addImplements(c.getName().toString());
    }

    public void addImplements(String s)
    {
        implementedInterfaces.add(s);
    }

    /**
     * @return
     */
    String getName()
    {
        return name;
    }

    /**
     * @return Returns the isAbstract.
     */
    public boolean isAbstract()
    {
        return this.isAbstract;
    }

    /**
     * @param isAbstract The isAbstract to set.
     */
    public void setAbstract(boolean isAbstract)
    {
        this.isAbstract = isAbstract;
    }

    /**
     * @return Returns the isFinal.
     */
    public boolean isFinal()
    {
        return this.isFinal;
    }

    /**
     * @param isFinal The isFinal to set.
     */
    public void setFinal(boolean isFinal)
    {
        this.isFinal = isFinal;
    }

    /**
     * @return Returns the isPublic.
     */
    public boolean isPublic()
    {
        return this.isPublic;
    }

    /**
     * @param isPublic The isPublic to set.
     */
    public void setPublic(boolean isPublic)
    {
        this.isPublic = isPublic;
    }
}
package de.x4technology.tools.generator;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import de.x4technology.helper.io.FileHelper;

/**
 * @author ingo
 *
 */
public class CVSIgnoreFile
{
    public static final String CVSIGNOREFILENAME = ".cvsignore";
    private static final String CRLF = "\n";
    private Set entries = new HashSet();
    private File file;

    private boolean isDirty = false;

    /**
     * @see CVSIgnoreFile(File cvsIgnoreFile)
     * @param fullPathToCVSIgnoreFile
     * @throws FileNotFoundException
     * @throws IOException
     */
    public CVSIgnoreFile(String fullPathToCVSIgnoreFile) throws FileNotFoundException, IOException
    {
        this(new File(fullPathToCVSIgnoreFile));
    }

    /**
     * Creates the given File if it does not exist yet.
     * @param cvsIgnoreFile
     * @throws FileNotFoundException
     * @throws IOException
     */
    public CVSIgnoreFile(File cvsIgnoreFile) throws FileNotFoundException, IOException
    {
        if (cvsIgnoreFile == null) throw new NullPointerException("cvsIgnoreFile");

        if (cvsIgnoreFile.isDirectory())
        {
            throw new IllegalArgumentException("File '" + cvsIgnoreFile.getAbsolutePath() + "' is a directory.");
        }

        if (!cvsIgnoreFile.exists())
        {
            new File(FileHelper.getDirectoryFromPath(cvsIgnoreFile.getAbsolutePath())).mkdirs();
            if (!cvsIgnoreFile.createNewFile())
            {
                throw new IOException("Could not create file '" + cvsIgnoreFile.getAbsolutePath() + "'.");
            }
        }

        this.file = cvsIgnoreFile;
        readEntries();
    }

    private void readEntries() throws FileNotFoundException, IOException
    {
        clear();
        BufferedReader br = new BufferedReader(new FileReader(file));
        try
        {
            String str = null;

            do
            {
                str = br.readLine();
                if (str != null)
                {
                    entries.add(str);
                }
            }
            while (str != null);
        }
        finally
        {
            br.close();
        }
    }

    private void writeEntries() throws FileNotFoundException, IOException
    {
        BufferedWriter bw = new BufferedWriter(new FileWriter(file));
        try
        {
            for (Iterator iter = entries.iterator(); iter.hasNext();)
            {
                bw.write((String) iter.next() + CRLF);
            }
            bw.flush();
        }
        finally
        {
            bw.close();
        }
    }

    public void save() throws FileNotFoundException, IOException
    {
        if (isDirty)
        {
            writeEntries();
            isDirty = false;
        }
    }

    public int size()
    {
        return entries.size();
    }

    public void clear()
    {
        int count = entries.size();
        entries.clear();
        isDirty = count > 0;
    }

    public boolean isEmpty()
    {
        return entries.isEmpty();
    }

    public boolean add(Object arg0)
    {
        isDirty = entries.add(arg0);
        return isDirty;
    }

    public boolean remove(Object arg0)
    {
        isDirty = entries.remove(arg0);
        return isDirty;

    }

    public String getFileName()
    {
        return file.getAbsolutePath();
    }

    public boolean isDirty()
    {
        return isDirty;
    }
}

package de.x4technology.tools.generator;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * @author uwe
 */
public class JavaSourceFile
{

    public JavaSourceFile(String packageName, String className, boolean isInterface, boolean isAbstract,
            boolean isPublic)
    {
        this.packageName = packageName;
        int type = isInterface ? CompilationUnit.TYPE_INTERFACE : CompilationUnit.TYPE_CLASS;
        this.compilationUnit = new CompilationUnit(className, type, isAbstract, isPublic);

    }

    private static final char EOL = '\n';
    private final CompilationUnit compilationUnit;
    private final ImportManager importManager = new ImportManager();
    private final String packageName;
    private String comment = "/**\n * Generated class\n */\n";
    private final List content = new LinkedList();
    

    /**
     * @param c
     */
    public void addExtends(Class c)
    {
        compilationUnit.addExtends(c);
    }

    public void addExtends(String s)
    {
        compilationUnit.addExtends(s);
    }
    /**
     * @param c
     */
    public void addImplements(Class c)
    {
        compilationUnit.addImplements(c);
    }

    public void addImplements(String s)
    {
        compilationUnit.addImplements(s);
    }
    /*
     * 
     */
    public String toString()
    {
        StringBuffer sb = new StringBuffer(8192);
        sb.append("package ");
        sb.append(packageName);
        sb.append(";");
        sb.append(EOL);

        sb.append(importManager.toString());

        sb.append(comment);
        sb.append(compilationUnit.getDeclaration());
        sb.append("{");

        for (Iterator iter = content.iterator(); iter.hasNext();)
        {
            String c = (String) iter.next();
            sb.append(c);
        }

        sb.append("}");

        return sb.toString();
    }

    /**
     * @param clazz
     */
    public void addImport(Class clazz)
    {
        importManager.add(clazz);
    }

    public void addContent(String c)
    {
        this.content.add(c);
    }

    /**
     * @param comment The comment to set.
     */
    public void setComment(String comment)
    {
        this.comment = comment;
    }

    /**
     * @return
     */
    public String getCompilationUnitName()
    {
        return compilationUnit.getName();
    }

    /**
     * 
     */
    public void setFinal()
    {
        compilationUnit.setFinal(true);
        
    }

    /**
     * @param string
     */
    public void addImport(String string)
    {
        importManager.add(string);
        
    }

    
}

package de.x4technology.application.model;

/**
 * @author uwe
 */
public abstract class ApplicationConfigurationElement
{
    protected ApplicationConfigurationElement parentAttributable;
    protected Attribute[] attribute;
    protected String authenticatorRef;

    /**
     * @return Returns the parentAttributable.
     */
    protected ApplicationConfigurationElement getParentAttributable()
    {
        return parentAttributable;
    }

    /**
     * @param parentAttributable The parentAttributable to set.
     */
    protected void setParentAttributable(ApplicationConfigurationElement parentAttributable)
    {
        this.parentAttributable = parentAttributable;
    }

    /**
     * @return Returns the attribute.
     */
    public Attribute[] getAttribute()
    {
        return attribute;
    }

    /**
     * @param attribute The attribute to set.
     */
    public void setAttribute(Attribute[] attribute)
    {
        this.attribute = attribute;
    }

    /*
    public String getAttribute(String name)
    {
        if (name == null) throw new NullPointerException("name");
        for (int i = 0; i < attribute.length; i++)
        {
            Attribute a = attribute[i];
            if (a.getName().equals(name)) return a.getValue();
        }

        if (parentAttributable != null)
        {
            return parentAttributable.getAttribute(name);
        }

        return null;
    }
    */

    public String getAuthenticatorRef()
    {
        return authenticatorRef;
    }
    public void setAuthenticatorRef(String authenticatorRef)
    {
        this.authenticatorRef = authenticatorRef;
    }

    /**
     * @return
     */
    public boolean hasAuthenticatorRef()
    {
        return (getAuthenticatorRef() != null && getAuthenticatorRef().length() != 0);
    }
}

package de.x4technology.application.model;

/**
 * @author uwe
 */
public class Application extends ApplicationConfigurationElement
{
    private String id;
    private String base;
    private String gui;
    private String rootModuleRef;

    private Context[] context;

    /**
     * @return Returns the base.
     */
    public String getBase()
    {
        return base;
    }

    /**
     * @return Returns the context.
     */
    public Context[] getContext()
    {
        return context;
    }

    /**
     * @return Returns the gui.
     */
    public String getGui()
    {
        return gui;
    }

    /**
     * @return Returns the id.
     */
    public String getId()
    {
        return id;
    }

    /**
     * @param base The base to set.
     */
    public void setBase(String base)
    {
        this.base = base;
    }

    /**
     * @param context The context to set.
     */
    public void setContext(Context[] context)
    {
        this.context = context;
    }

    /**
     * @param gui The gui to set.
     */
    public void setGui(String gui)
    {
        this.gui = gui;
    }

    /**
     * @param id The id to set.
     */
    public void setId(String id)
    {
        this.id = id;
    }

    public void wire()
    {
        for (int i = 0; i < this.context.length; i++)
        {
            Context c = this.context[i];
            c.setParentAttributable(this);
            c.wire();
        }
    }

    public String getRootModuleRef()
    {
        return rootModuleRef;
    }
    
    public void setRootModuleRef(String rootModuleRef)
    {
        this.rootModuleRef = rootModuleRef;
    }

	/**
	 * @return
	 */
	public boolean hasRootModuleRef()
	{
		return getRootModuleRef() != null && getRootModuleRef().length() != 0;
	}
}

package de.x4technology.application.model;

import de.x4technology.application.X4Module;

/**
 * @author uwe
 */
public class Module extends ApplicationConfigurationElement
{
    /**
     * @return Returns the ref.
     */
    public String getModuleRef()
    {
        return moduleRef;
    }

    /**
     * @param ref The ref to set.
     */
    public void setModuleRef(String moduleRef)
    {
        this.moduleRef = moduleRef;
    }
    private String moduleRef;
    private String id;

    /**
     * 
     */
    public void wire()
    {
       

    }
    public String getId()
    {
        return id;
    }
    public void setId(String id)
    {
        this.id = id;
    }

    /**
     * @return
     */
    public String getClasS()
    {
        // TODO get concrete classname from referenced deployed module 
        return X4Module.class.getName();
    }

	/**
	 * @return
	 */
	public boolean hasModuleRef()
	{
		return getModuleRef() != null && getModuleRef().length() != 0;
	}

}

