Class	Description
EventSchedule	Handles scheduled recordings and recorded items, and creates and retrieves requests. This class can also be used as an event source.
EventScheduleException	Contains information about an exception raised by the EventSchedule API.
ExtendedPropertyExceededLimitException	This exception is thrown by the ScheduleEvent.GetExtendedProperty method when a property is queried too many times.
ScheduleEvent	Represents a scheduled recording event.
ScheduleEventChangedEventArgs	Contains arguments that are passed to the delegate of the ScheduleEventStateChanged event.
ScheduleRequest	Provides information about a recording request.

The Microsoft.MediaCenter.TV.Scheduling namespace exposes the following structure:
Structure	Description
ScheduleEventChange	Contains information about changes to scheduled recording events.

The Microsoft.MediaCenter.TV.Scheduling namespace exposes the following eumeration types:
Enumeration	Description
ConflictResolutionPolicy	Contains values that indicate how the CreateScheduleRequest method should handle conflicts.
CreateScheduleRequestResult	Contains values that indicate the result of a recording request from the EventSchedule.CreateScheduleRequest method.
ScheduleEventStates	Contains the possible states of a scheduled recording event.

