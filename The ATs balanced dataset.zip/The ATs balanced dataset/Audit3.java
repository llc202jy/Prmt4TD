abstract public class DomainKind implements Handler<String>
{
    abstract public String getKindName();
    abstract public String getTypeLabel(Domain domain);
    abstract public SQLFragment sqlObjectIdsInDomain(Domain domain);

    /**
     * Create a DomainURI for a Domain that may or may not exist yet.
     */
    abstract public String generateDomainURI(String schemaName, String queryName, Container container, User user);

    abstract public ActionURL urlShowData(Domain domain, ContainerUser containerUser);
    abstract public @Nullable ActionURL urlEditDefinition(Domain domain, ContainerUser containerUser);
    abstract public ActionURL urlCreateDefinition(String schemaName, String queryName, Container container, User user);

    abstract public boolean canCreateDefinition(User user, Container container);

    abstract public boolean canEditDefinition(User user, Domain domain);

    // Override to customize the nav trail on shared pages like edit domain
    abstract public void appendNavTrail(NavTree root, Container c, User user);

    // Do any special handling before a PropertyDescriptor is deleted -- do nothing by default
    abstract public void deletePropertyDescriptor(Domain domain, User user, PropertyDescriptor pd);

    /**
     * Return the set of names that should not be allowed for properties. E.g.
     * the names of columns from the hard table underlying this type
     * @return set of strings containing the names. This will be compared ignoring case
     */
    abstract public Set<String> getReservedPropertyNames(Domain domain);

    /**
     * Return the set of names that are always required and cannot subsequently
     * be deleted.
     * @return set of strings containing the names. This will be compared ignoring case
     */
    abstract public Set<String> getMandatoryPropertyNames(Domain domain);

    // CONSIDER: have DomainKind supply and IDomainInstance or similiar
    // so that it can hold instance data (e.g. a DatasetDefinition)

    /**
     * Create a Domain appropriate for this DomainKind.
     * @param domain The domain design.
     * @param arguments Any extra arguments.
     * @param container Container
     * @param user User
     * @return The newly created Domain.
     */
    abstract public Domain createDomain(GWTDomain domain, Map<String, Object> arguments, Container container, User user);

    /**
     * Update a Domain definition appropriate for this DomainKind.
     * @param original The original domain definition.
     * @param update The updated domain definition.
     * @param container Container
     * @param user User
     * @return A list of errors collected during the update.
     */
    abstract public List<String> updateDomain(GWTDomain original, GWTDomain update, Container container, User user);

    abstract public Set<PropertyStorageSpec> getBaseProperties();

    /**
     * If domains of this kind should get hard tables automatically provisioned, this returns
     * the db schema where they reside. If it is null, hard tables are not to be provisioned for doamins of this kind.
     */
    abstract public DbScope getScope();
    abstract public String getStorageSchemaName();
    abstract public Set<PropertyStorageSpec.Index> getPropertyIndices();

    /**
     * Need to be able to tell if a domain has rows.
     * Perhaps DomainKind should have getTableInfo() method.
     */
    abstract public boolean hasNullValues(Domain domain, DomainProperty prop);

    /** ask the domain to clear caches related to this domain */
    abstract public void invalidate(Domain domain);

    /**
     * Set of hard table names in this schema that are not provision tables
     * @return
     */
    abstract public Set<String> getNonProvisionedTableNames();

    abstract public PropertyStorageSpec getPropertySpec(PropertyDescriptor pd, Domain domain);
}