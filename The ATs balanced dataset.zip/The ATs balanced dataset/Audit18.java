public class TrialActivityChange {

	// ==========================================
	// Section Constants
	// ==========================================
	public static final SimpleDateFormat DATE_FORMAT 
		= new SimpleDateFormat("dd-MMM-yyyy-HH:mm:ss");
	
	// ==========================================
	// Section Properties
	// ==========================================
	private String trialSubjectIdentifier;
	private Date date;
	private String changeDescription;	
	private String changeAuthor;
	
	// ==========================================
	// Section Construction
	// ==========================================
	public TrialActivityChange() {
		trialSubjectIdentifier = "";
		date = new Date();
		date.setTime(System.currentTimeMillis());
		changeDescription = "";
		changeAuthor = "";
	}
	
	// ==========================================
	// Section Accessors and Mutators
	// ==========================================

	/**
	 * @return the subjectIdentifier
	 */
	public String getTrialSubjectIdentifier() {
		return trialSubjectIdentifier;
	}

	/**
	 * @param trialSubjectIdentifier the trialSubjectIdentifier to set
	 */
	public void setTrialSubjectIdentifier(String trialSubjectIdentifier) {
		this.trialSubjectIdentifier = trialSubjectIdentifier;
	}

	/**
	 * @return the date
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * @return the changeComment
	 */
	public String getChangeDescription() {
		return changeDescription;
	}

	/**
	 * @param changeDescription the changeDescription to set
	 */
	public void setChangeDescription(String changeDescription) {
		this.changeDescription = changeDescription;
	}

	/**
	 * @return the userID of the change author
	 */
	public String getChangeAuthor() {
		return changeAuthor;
	}

	/**
	 * @param changeAuthor the changeAuthor to set
	 */
	public void setChangeAuthor(String changeAuthor) {
		this.changeAuthor = changeAuthor;
	}
		
	// ==========================================
	// Section Errors and Validation
	// ==========================================

	// ==========================================
	// Section Interfaces
	// ==========================================

	// ==========================================
	// Section Override
	// ==========================================

}
public class TrialSubjectModelFactory {

	// ==========================================
	// Section Constants
	// ==========================================

	// ==========================================
	// Section Properties
	// ==========================================
	private TrialSubjectModel templateTrialSubjectModel;
	private final TrialSubjectModel nullTrialSubjectModel;
	
	// ==========================================
	// Section Construction
	// ==========================================
	public TrialSubjectModelFactory(TrialSubjectModel templateTrialSubjectModel) {
		this.templateTrialSubjectModel = templateTrialSubjectModel;
		nullTrialSubjectModel
			= (TrialSubjectModel) templateTrialSubjectModel.clone();
		nullTrialSubjectModel.setIdentifier("NULL");
	}
	
	// ==========================================
	// Section Accessors and Mutators
	// ==========================================

	public ArrayList<String> getActivityDataStorageNames() {
		ArrayList<String> activityDataStorageNames = new ArrayList<String>();
		
		ArrayList<TrialActivityModel> trialActivityModels
			= templateTrialSubjectModel.getTrialActivityModels();
		for (TrialActivityModel trialActivityModel : trialActivityModels) {
			activityDataStorageNames.add(trialActivityModel.getDataStorageName());
		}
		
		return activityDataStorageNames;
	}
	
	
	
	public ArrayList<String> getActivityStepDataStorageNames(String activityDataStorageName) {
		ArrayList<String> activityStepDataStorageNames 
			= new ArrayList<String>();
		TrialActivityModel templateTrialActivityModel
			= templateTrialSubjectModel.getTrialActivityFromDataStorageName(activityDataStorageName);
		ArrayList<DateFieldModel> dateFieldModels
			= templateTrialActivityModel.getDateFieldModels();
		
		for (DateFieldModel dateFieldModel : dateFieldModels) {
			activityStepDataStorageNames.add(dateFieldModel.getDataStorageName());
		}
		
		return activityStepDataStorageNames;
	}
	
	
	public int getNumberOfActivities() {
		ArrayList<TrialActivityModel> trialActivityModels
			= templateTrialSubjectModel.getTrialActivityModels();
		return trialActivityModels.size();
	}
		
	public String getPrimaryKeyDisplayName() {
		TextFieldModel primaryKeyFieldModel
			= templateTrialSubjectModel.getPrimaryKeyFieldModel();
		return primaryKeyFieldModel.getDisplayName();
	}

	public String getPrimaryKeyDataStorageName() {
		TextFieldModel primaryKeyFieldModel
			= templateTrialSubjectModel.getPrimaryKeyFieldModel();
		return primaryKeyFieldModel.getDataStorageName();
	}
	
	public String[] getActivityDisplayNames() {
		ArrayList<TrialActivityModel> trialActivityModels
			= templateTrialSubjectModel.getTrialActivityModels();
		String[] results = new String[trialActivityModels.size()];
		for (int i = 0; i < results.length; i++) {
			TrialActivityModel currentTrialActivityModel
				= trialActivityModels.get(i);
			results[i] = currentTrialActivityModel.getDisplayName();			       
		}
		
		return results;
	}
	
	public String getActivityDisplayName(String activityDataStorageName) {
		ArrayList<TrialActivityModel> trialActivityModels
			= templateTrialSubjectModel.getTrialActivityModels();
		for (TrialActivityModel trialActivityModel : trialActivityModels) {
			String currentDataStorageName 
				= trialActivityModel.getDataStorageName();
			if (currentDataStorageName.equals(activityDataStorageName) == true) {
				return trialActivityModel.getDisplayName();
			}
		}	
		return null;
	}
	
	public String getCoreFieldDataStorageName(String coreFieldDisplayName) {
		ArrayList<TextFieldModel> otherCoreFieldModels
			= templateTrialSubjectModel.getFilterFieldModels();
		for (TextFieldModel currentCoreFieldModel : otherCoreFieldModels) {
			String currentCoreFieldDisplayName
				= currentCoreFieldModel.getDisplayName();
			if (coreFieldDisplayName.equals(currentCoreFieldDisplayName) == true) {
				return currentCoreFieldModel.getDataStorageName();
			}
		}
		return null;
	}
	
	public String getActivityDataStorageName(String activityDisplayName) {
		ArrayList<TrialActivityModel> trialActivityModels
			= templateTrialSubjectModel.getTrialActivityModels();
		for (TrialActivityModel currentTrialActivityModel : trialActivityModels) {
			String currentDisplayName = currentTrialActivityModel.getDisplayName();
			if (activityDisplayName.equals(currentDisplayName) == true) {
				return currentTrialActivityModel.getDataStorageName();
			}
		}
	
		return null;		
	}
	
	public String getActivityFieldDataStorageName(String activityDataStorageName,
												  String activityFieldDisplayName) {
	
		TrialActivityModel trialActivityModel
			= templateTrialSubjectModel.getTrialActivityFromDataStorageName(activityDataStorageName);
		ArrayList<DateFieldModel> dateFieldModels = trialActivityModel.getDateFieldModels();

		for (DateFieldModel currentDateFieldModel : dateFieldModels) {
			if (currentDateFieldModel.getDisplayName().equals(activityFieldDisplayName) == true) {
				return currentDateFieldModel.getDataStorageName();
			}
		}
		
		return null;		
	}
	
	public boolean isValidCoreFieldName(String coreFieldName) {
		ArrayList<TextFieldModel> coreFieldModels
			= templateTrialSubjectModel.getFilterFieldModels();
		for (TextFieldModel coreFieldModel : coreFieldModels) {
			if (coreFieldModel.getDataStorageName().equals(coreFieldName) == true) {
				return true;
			}
		}
		return false;
	}

	
	public boolean isValidActivityName(String activityDataStorageName) {
		TrialActivityModel trialActivityModel
			= templateTrialSubjectModel.getTrialActivityFromDataStorageName(activityDataStorageName);
		if (trialActivityModel == null) {
			return false;
		}
		
		return true;
	}

	public boolean isValidActivityStepName(String activityDataStorageName,
										   String activityStepDataStorageName) {
		TrialActivityModel trialActivityModel
			= templateTrialSubjectModel.getTrialActivityFromDataStorageName(activityDataStorageName);
		if (trialActivityModel == null) {
			return false;
		}

		ArrayList<DateFieldModel> dateFieldModels = trialActivityModel.getDateFieldModels();
		
		for (DateFieldModel currentDateFieldModel : dateFieldModels) {
			String currentStepName = currentDateFieldModel.getDataStorageName();
			if (currentStepName.equals(activityStepDataStorageName) == true) {
				return true;
			}
		}
				
		return false;
	}

	public String[] getCommentAndActivityFieldNames(String activityDataStorageName) {
		ArrayList<String> fieldNames = new ArrayList<String>();
		
		TrialActivityModel trialActivityModel
			= templateTrialSubjectModel.getTrialActivityFromDataStorageName(activityDataStorageName);
		ArrayList<DateFieldModel> dateFieldModels = trialActivityModel.getDateFieldModels();
		
		for (DateFieldModel currentDateFieldModel : dateFieldModels) {
			fieldNames.add(currentDateFieldModel.getDisplayName());
		}
		
		String[] results
			= fieldNames.toArray(new String[0]);
		
		return results;
	}

	public ArrayList<String> getCoreFieldDataStorageNames() {
		ArrayList<String> allCoreFieldDataStorageNames = new ArrayList<String>();	
		ArrayList<TextFieldModel> otherCoreFieldModels
			= templateTrialSubjectModel.getFilterFieldModels();
		for (TextFieldModel currentCoreFieldModel : otherCoreFieldModels) {
			allCoreFieldDataStorageNames.add(currentCoreFieldModel.getDataStorageName());
		}		
		
		return allCoreFieldDataStorageNames;		
	}
	
	public String[] getCoreFieldNames() {
		ArrayList<String> allCoreFieldNames = new ArrayList<String>();	
		ArrayList<TextFieldModel> otherCoreFieldModels
			= templateTrialSubjectModel.getFilterFieldModels();
		for (TextFieldModel currentCoreFieldModel : otherCoreFieldModels) {
			allCoreFieldNames.add(currentCoreFieldModel.getDisplayName());
		}		
		
		String[] results
			= allCoreFieldNames.toArray(new String[0]);
		return results;
	}
	
	public TrialSubjectModel createTrialSubjectModel() {
		return createTrialSubjectModel(null);		
	}
	
	public TrialActivityModel createTemplateActivityModel(String activityDataStorageName) {
		TrialSubjectModel templateSubjectModel
			= createTrialSubjectModel();
		TrialActivityModel templateActivityModel
			= templateSubjectModel.getTrialActivityFromDataStorageName(activityDataStorageName);
		return templateActivityModel;
	}
	
	public TrialSubjectModel createTrialSubjectModel(String identifier) {
		//assume the template model is not null
		
		TrialSubjectModel clonedTrialSubjectModel
			= (TrialSubjectModel) templateTrialSubjectModel.clone();
		if (identifier != null) {
			clonedTrialSubjectModel.setIdentifier(identifier);
		}
		return clonedTrialSubjectModel;
	}
		
	public TrialSubjectModel getNullTrialSubjectModel() {
		return nullTrialSubjectModel;
	}
	
	public boolean isNullObject(TrialSubjectModel trialSubjectModel) {
		if (nullTrialSubjectModel == trialSubjectModel) {
			return true;
		}
		return false;
	}
	
	public boolean isNullActivity(TrialActivityModel trialActivityModel) {
		return nullTrialSubjectModel.containsActivity(trialActivityModel);
	}
	
	// ==========================================
	// Section Errors and Validation
	// ==========================================

	// ==========================================
	// Section Interfaces
	// ==========================================

	// ==========================================
	// Section Override
	// ==========================================

}