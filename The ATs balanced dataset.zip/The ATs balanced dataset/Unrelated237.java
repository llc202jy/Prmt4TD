package com.oncecorp.visa3d.bridge.listening;

import javax.naming.Context;
import javax.naming.InitialContext;

import javax.jms.TopicConnection;
import javax.jms.TopicSession;
import javax.jms.Topic;
import javax.jms.Session;
import javax.jms.TopicConnectionFactory;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;
import javax.jms.TopicPublisher;
import javax.jms.MessageListener;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.jms.Session;

import java.util.Properties;
import java.util.List;
import java.util.Collections;
import java.util.ArrayList;
import java.util.Map;
import java.util.Hashtable;
import java.util.Iterator;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.oncecorp.visa3d.bridge.listening.ListeningUtils;
import com.oncecorp.visa3d.bridge.utility.XMLUtils;
import com.oncecorp.visa3d.bridge.utility.Utils;
import com.oncecorp.visa3d.bridge.security.TripleDESEncrypter;
import com.oncecorp.visa3d.bridge.beans.ListeningMessageBean;
import com.oncecorp.visa3d.bridge.startup.StartupProxy;
import com.oncecorp.visa3d.bridge.beans.BeansHelper;

import org.apache.log4j.Logger;
import com.oncecorp.visa3d.bridge.logging.DataBridgeLoger;

/**
 * <p>Title: ListeningThread</p>
 * <p>Description: Call JMS methods to create connection, session and subscriber.
 *  Register itself as a message listener to receive the JMS message. Transform
 * the message according to the configue definition( such as field filter, encryption,
 * and mask), then call the registered MPI message listener( auditing logger or plugin
 * channel). Start/stop/Register/Unregister/GetStatus etc functions are also provided for
 * JMX related control.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: ONCE Corporation</p>
 * @author Gang Wu ( gwu@oncecorp.com )
 * @version 1.0
 */

public class ListeningThread implements MessageListener
{
    protected static final String TOPIC_CONNECTION_FACTORY =
                        "databridge.tcf";
    protected static final String TOPIC = 			"databridge.topic";

    protected TopicConnection m_connection = null;
    protected TopicSession m_session = null;
    protected String m_listener = null;
    protected String m_clientID = null;
    protected String m_channel = null;
    protected Topic m_topic = null;
    protected TopicSubscriber m_sub = null;

    protected String m_status = Utils.LISTENING_STOP;
    protected boolean m_running = false;

    protected List m_merchantIDs = Collections.synchronizedList( new ArrayList() );
    protected Map m_messages = null;

    protected MPIMessageListener m_plugin = null;

    private static Logger m_logger = DataBridgeLoger.getLogger(
            ListeningThread.class.getName() );


    protected static Hashtable m_jmsProps = null;
    protected static String m_factoryJndi = null;
    protected static String m_topicJndi = null;

    protected boolean m_initFlag = false;

	protected long    startStopTime = System.currentTimeMillis();
	protected String  startStopReason = null;

    /**
     * Init with the listening name, channel name and startup status
     * @param name - listening name
     * @param channel - channel name
     * @param status - initialize status, start or stop
     */
    public void init( String name, String channel, String status )
    {
        m_listener = name;
        m_channel = channel;
        setStatus( status );
		if ( status != null && status.equals(ListeningUtils.PLUGIN_CLASS_NOT_INIT) )
	            setStartStopReason( Utils.PLUGIN_CLASS_NOT_INIT );
        m_clientID = this.generateClientID();
    }

    /**
     * Set JMS related configurable attributes which include JNDI server, Connection
     * Factory JNDI name and topic JNDI name.
     * @param props - hashtable contains JMS related attributes
     * @param factoryJndi - connection factory JNDI name
     * @param topicJndi - connection topic JNDI name
     */
    public static void setJMSContextAttributes( Hashtable props,
            String factoryJndi,  String topicJndi )
    {
        m_logger.debug("Do setJMSContext");
        m_jmsProps = props;
        m_factoryJndi = factoryJndi;
        m_topicJndi = topicJndi;

    }

    /**
     * JMS server maybe run on different environment, this method return the JNDI
     * context which is created from the configurable properties.
     * @return - JMS JNDI context
     */
    public static Context getJMSContext()
    {
        m_logger.debug("Begin getJMSContext");

        if ( m_jmsProps != null )
        {

            try {
                Context ctx = new InitialContext( m_jmsProps );
                m_logger.debug("Success getJMSContext with jms attributes");
                return ctx;
            } catch ( Exception e )
            {
                m_logger.warn("Can't get with JMS properties, use default.", e);
            }

        }

        return StartupProxy.getContext();
    }

    /**
     * @return - connection factory JNDI name
     */
    public static String getConnectionFactoryJNDI()
    {
        if ( m_factoryJndi == null )
            return TOPIC_CONNECTION_FACTORY;
        else
            return m_factoryJndi;
    }

    /**
     *
     * @return - connection topic JNDI name
     */
    public static String getConnectionTopic()
    {
        if ( m_topicJndi == null )
            return TOPIC;
        else
            return m_topicJndi;
    }

    /**
     * Initialize JMS related resources, create connection, session and subscriber.
     * @return - success or not
     */
    public boolean initializeJMS()
    {

        m_logger.debug("Begin initializeJMS with status:" + m_status);

        if ( m_initFlag )
            return true;

        if ( m_plugin == null || !m_plugin.isInitialized() )
        {
            m_logger.debug( "The listener [ " + m_listener
                            + "] hasn't been initialized, don't start listening service for it.");
            setStatus( ListeningUtils.INITIALIZE_ERROR );
			setStartStopReason( Utils.LISTENING_INITIAL_ERROR );
            m_logger.debug("Exit initializeJMS");
            return false;
        }

        try {
              Context context = getJMSContext();

              TopicConnectionFactory tcf = (TopicConnectionFactory)
                          context.lookup( getConnectionFactoryJNDI() );

              if (tcf == null) {
                m_logger.error("Topic connection factory not found!");
				setStartStopReason( Utils.CONNECTION_FACTORY_NOT_FOUND );
                return false;
              }

              // Create a connection
              m_logger.debug("creating connection");
              m_connection = tcf.createTopicConnection();
              m_connection.setExceptionListener( new ConnectionExceptionListener( this ) );
              try {
                  m_connection.setClientID( m_clientID );
              } catch ( Exception cex )
              {
                  m_logger.warn("Client ID alreadt exist", cex);
              }
              m_logger.debug("setting clientid [" + m_clientID + "]");

              // Create a session
              m_session = m_connection.createTopicSession(true,
                      Session.AUTO_ACKNOWLEDGE);

              m_logger.debug("looking up topic");
              m_topic = (Topic) context.lookup( getConnectionTopic() );

              // Get around the problem of publish before subscribe by
              // using a durable subscription.
              m_logger.debug("creating durable subscriber");
              String sstr = getSelectorString();
              m_logger.debug("Selector String is [" + sstr + "]");
//              m_sub = m_session.createDurableSubscriber(m_topic, m_clientID );
              m_sub = m_session.createDurableSubscriber(m_topic, m_clientID,
                     sstr, true );
              m_sub.setMessageListener(this);

              m_initFlag = true;

              if ( !ListeningUtils.isStopAction( m_status ) )
                  this.start();

              m_logger.debug("End initializeJMS");
              return true;

        } catch (Throwable t) {
              m_initFlag = false;
              m_logger.error("In initializeJMS", t);
			  setStartStopReason( Utils.JMS_SETUP_EXCEPTION );
              return false;
        }

    }

    /**
     * Implemente the MessageListener interface, which is automatically called by
     * JMS server when message comes. It decrypt the received message first if needed.
     * Transform it then and delivery it the MPI message listener finnally. If exception
     * is caught or the MPI message listener return false, a ListeningMessageException will
     * be throwed and the message will rollbakc to the queue for the later handler.
     * @param message - JMS message
     * @see MessageListener#onMessage(Message)
     */
    public void onMessage(Message message)
    {
        boolean isOk = true;
        String str = "";

        try {
            m_logger.debug( m_clientID + "Get a Message.");
            TextMessage text = (TextMessage) message;
            String encryptStr = message.getStringProperty( ListeningUtils.JMS_ENCRYPTION_MODE );
            m_logger.debug("Msg is=["
               + message.getStringProperty( ListeningUtils.JMS_MESSAGE_TYPE) + "]["
               + message.getStringProperty( ListeningUtils.JMS_MERCHANT_PROPERTY) + "]["
               + message.getStringProperty( ListeningUtils.JMS_MESSAGE_PROTOCOL) + "]["
               + message.getStringProperty( ListeningUtils.JMS_MESSAGE_VERSION) + "]["
               + encryptStr + "]");
            String body = text.getText();

            // If message is encrypted, decrypt it
            if ( encryptStr != null && encryptStr.trim().equalsIgnoreCase("true") )
            {
                TripleDESEncrypter decrypter = TripleDESEncrypter.getInstance();
                String ivstr = message.getStringProperty( ListeningUtils.JMS_ENCRYPTION_IV );
                body = decrypter.decrypt( body, ivstr );
            }


            String type = message.getStringProperty( ListeningUtils.JMS_MESSAGE_TYPE);
            String version = message.getStringProperty( ListeningUtils.JMS_MESSAGE_VERSION);

            Map messages = null;
            try
            {
                messages = MessageFieldsFilter.getMessageMappingBean().getMessages();
            } catch ( Exception e )
            {
                messages = null;
            }

            if ( messages != null && !messages.containsKey( BeansHelper.getMessageMappingKey( type, version ) ) )
            {
                /*
                for ( Iterator lt = messages.keySet().iterator(); lt.hasNext(); )
                {
                    m_logger.debug("message key=" + lt.next() );
                }
                */
                m_logger.debug("Message type [" +  type + "] version ["
                                  + version + "] not defined, ignore it.");
            }
            else
            {

                Properties props = ListeningUtils.getMessageProperties( message );

				Document fromdoc = getXmlDoc( body );
				Element root = MessageFieldsFilter.getMessageTypeRoot(
						fromdoc, type, version );
				if ( root == null )
				{
					m_logger.debug("Message type [" +  type + "] version ["
									  + version + "] not defined correctly, "
		                              + "please check xpath in mpi-messages.xml for the root. "
									  + "The message is ignored.");
				}
				else
				{
					Document doc = transformMsg(type, version, fromdoc, props );

					/**
					 * Call MPI message listener to handler the pre-handled messages.
					 */
					if ( m_plugin != null )
					{
						synchronized ( m_plugin )
						{
							m_logger.debug("Before call plugin handleMsg");

							isOk = m_plugin.handleMsg(
									props, doc );
							if ( !isOk )
                      		     str = " return by listener.";
 	                        m_logger.debug("After call plugin handleMsg");
						}
					}
				}
            }

        } catch (Throwable t) {
            m_logger.error("Exception in onMessage", t);
            str = " as exception happened.";
            isOk = false;
        }

        //Tell JMS to rollback the message
        try {
            if ( !isOk )
            {
//            throw new ListeningMessageException(m_clientID + " onMessageException ["
//                 + str + "]" );
                m_session.rollback();
                m_logger.error(m_clientID + " [" + str + "] is rolled back.");
            }
            else
            {
                m_session.commit();
                m_logger.debug(m_clientID + " message is successfully committed.");
            }
        } catch ( Exception e )
        {
            if ( !isOk )
                m_logger.error("rollback error", e);
            else
                m_logger.error("commit error", e);
        }
    }

    /**
     * Set the current status to exception status
     */
    protected void setExceptionStatus( )
    {
		if ( m_running )
	       startStopTime = System.currentTimeMillis();
        m_status = Utils.LISTENING_EXCEPTION;
		setStartStopReason( Utils.RUNNING_EXCEPTION );
        m_running = false;
    }

	/**
	 * Stop message listening
	 */
	public void stop()
	{
		this.stop( "" );
	}

    /**
     * Stop message listening
     */
    public void stop( String msg )
    {
        m_logger.debug("Enter stop " +  msg);
		setStartStopReason( msg );
        if ( !m_initFlag )
        {
            m_logger.warn("Not initialized, do nothing.");
            return ;
        }

        if ( !m_running && !m_status.equals( Utils.LISTENING_EXCEPTION ))
             return;
        try {
            m_connection.stop();
            if ( m_plugin != null )
            {
                synchronized ( m_plugin )
                {
                     m_plugin.stop();
                }
            }
            m_running = false;
		   startStopTime = System.currentTimeMillis();
        } catch ( Exception e )
        {
            m_status = Utils.LISTENING_EXCEPTION;
            m_logger.error("In stop", e);
        }

        m_status = Utils.LISTENING_STOP;
        m_logger.debug("Exit stop");
    }

    /**
     * Get the current listening thread status
     * @return - the status of current listening thread
     */
    public String getStatus()
    {
        return m_status;
    }

    /**
     *
     * @param aStatus - the new value for status
     */
    public void setStatus(String aStatus){
        m_status = aStatus;
    }


	/**
	 * Start listening thread
	 */
	public void start()
	{
		this.start( "" );
	}

    /**
     * Start listening thread
     */
    public void start( String msg )
    {
        m_logger.debug("Enter start " + msg );
		setStartStopReason( msg );
        if ( m_status.equals( Utils.LISTENING_EXCEPTION ) || !m_initFlag )
        {
            try {
                if ( m_sub != null )
                    m_sub.close();
                m_connection.close();
            } catch ( Exception e )
            {
                m_logger.warn("Try recreate JMS connection.", e);
            }

            m_logger.warn("Exception status or not initialized, do initialize again.");
            m_initFlag = false;
            m_running = false;
            m_status = Utils.LISTENING_STOP; // make initializeJMS not call this again.
            initializeJMS();
            return ;
        }

        if ( m_running )
        {
            m_status = Utils.LISTENTING_START;
             return;
        }
        try {
            if ( m_plugin != null )
            {
                synchronized ( m_plugin )
                {
                    m_plugin.start();
                }
            }
            m_connection.start();
            m_running = true;
			startStopTime = System.currentTimeMillis();
        } catch ( Exception e )
        {
            m_running = false;
            m_status = Utils.LISTENING_EXCEPTION;
			setStartStopReason( Utils.JMS_START_EXCEPTION );
            m_logger.error("In start", e);
        }
        m_status = Utils.LISTENTING_START;
        m_logger.debug("Exit start");

    }

    /**
     * Register this thread
     */
    public void register()
    {
        m_logger.debug("Enter register");

        if ( m_plugin == null )
            return;

        if ( m_connection != null )
        {
            try {
                if ( m_sub != null )
                    m_sub.close();
                m_connection.close();
            } catch ( Exception e )
            {
                m_logger.warn("Try recreate JMS connection.", e);
            }
        }

//        m_status = ListeningUtils.REGISTER;
        m_plugin.register();
        m_initFlag = false;
        this.initializeJMS();
    }

    /**
     * Unregister this thread
     */
    public void unregister()
    {
        m_logger.debug("Enter unregister");
        if ( m_plugin == null || m_connection == null )
            return;

        try {
            m_sub.close();
            m_session.unsubscribe( m_clientID );
            m_connection.stop();
            m_connection.close();
            m_plugin.unregister();

        } catch ( Exception e )
        {
            m_logger.error("Exception during [ListeningThread.unregister]", e);
        }
        m_logger.debug("Exit unregister");
    }

    /**
     * Generate unique client identify for each channel
     * @return - the generated identify
     */
    protected String generateClientID()
    {
        if ( m_channel == null )
            return m_listener;
        else
            return m_listener + "__C__" + m_channel;
    }

    /**
     *
     * @return - current listening thread's client identify
     */
    public String getClientID()
    {
        return m_clientID;
    }

    /**
     *
     * @return - current listening thread's listener name
     */
    public String getListenerName()
    {
        return m_listener;
    }

    /**
     *
     * @return - cureent listening thread's channel name
     */
    public String getChannelName()
    {
        return m_channel;
    }

    /**
     *
     * @return - the JMS message selector string from the registered listening list
     */
    protected String getSelectorString()
    {
        // Check merchant id
        String mstr = ListeningUtils.JMS_MERCHANT_PROPERTY + " in (";
        boolean mflag = false;
        String sid;
        String pstr ="";

        m_logger.debug("Enter getSelectorString");

        for ( Iterator lt = m_merchantIDs.iterator(); lt.hasNext(); )
        {
            sid = (String)lt.next();
            mstr = mstr.concat( pstr + "'" + sid + "'" );
            if ( !mflag )
            {
                pstr = ", ";
                mflag = true;
            }
        }
        if ( mflag )
            mstr = mstr.concat(")");

        // Just check message type without version
        String tstr = ListeningUtils.JMS_MESSAGE_TYPE + " in (";
        boolean tflag = false;
        ListeningMessageBean msg;
        String version, type;

        if ( m_messages == null || m_messages.size() == 0
             || ListeningUtils.containAllMessages( m_messages ) )
        {
            if ( mflag )
                return mstr;
            else
                return "";
        }

        ArrayList msgList = new ArrayList();
        pstr = "";
        for ( Iterator lt = m_messages.values().iterator(); lt.hasNext(); )
        {
            msg = (ListeningMessageBean)lt.next();
            version = msg.getVersion();
            if ( version != null && !version.trim().equals("") )
                continue;

            type = msg.getType();
            msgList.add( type );
            tstr = tstr.concat( pstr + "'" + type + "'");
            if ( !tflag )
            {
                tflag = true;
                pstr = ", ";
            }
        }
        if ( tflag )
            tstr = tstr.concat(")");
        m_logger.debug("mstr=["+mstr+"] tstr=["+tstr+"]");

        // Check messageType && version
        String vstr = "";
        boolean vflag = false;
        pstr = "";
        for ( Iterator lt = m_messages.values().iterator(); lt.hasNext(); )
        {
            msg = (ListeningMessageBean)lt.next();
            version = msg.getVersion();
            type = msg.getType();
            if ( version == null || version.trim().equals("") || msgList.contains(type) )
                continue;

            vstr = vstr.concat( pstr + " (" + ListeningUtils.JMS_MESSAGE_TYPE
                               + " = '" + type + "' AND "
                               + ListeningUtils.JMS_MESSAGE_VERSION
                               + " = '" + version + "') " );
            if ( !vflag )
            {
                vflag = true;
                pstr = " OR";
            }

        }

        m_logger.debug("vstr=["+vstr+"]");

        boolean sflag = false;
        String sstr = "";

        if ( tflag && vflag )
        {
            sflag = true;
            sstr = tstr + " OR " + vstr ;
        }
        else if ( tflag )
        {
            sflag = true;
            sstr = tstr;
        }
        else if ( vflag )
        {
            sflag = true;
            sstr = vstr ;
        }


        if ( mflag && sflag )
            return mstr.concat(" AND (").concat(sstr).concat(")");
        else if (mflag)
            return mstr;
        else if (sflag)
            return sstr;
        return null;
    }

    /**
     * Get XML document from the given string
     * @param msg - message string
     * @return - XML document
     */
    protected Document getXmlDoc( String msg )
    {
        return XMLUtils.getDocumentFromString(msg);
    }

    /**
     * Transform message body to XML document and encrypt/mask its fields.
     * @param type - message type
     * @param version - message version
     * @param doc - XML document
     * @param props - message data that will be saved directly into the database
     */
    protected Document transformMsg( String type, String version,
                                     Document doc, Properties props )
    {
        m_logger.debug("Enter transformMsg");

        MessageColumnDataExtract.getMessageColumnData( props,
                type, version, doc );

        List items = null;
        ListeningMessageBean bean = BeansHelper.retriveMessage( m_messages, type, version );
        if ( bean != null )
            items = bean.getFields();

        List encryptedList = Collections.synchronizedList( new ArrayList() );
        List maskedList = Collections.synchronizedList( new ArrayList() );

        if ( items != null )
        {
            if ( m_plugin == null || m_plugin.acceptFilter() )
                MessageFieldsFilter.extractFields( type, version, items, doc );
            MessageFieldsFilter.maskFields( type, version, items, doc );
            MessageFieldsFilter.encryptFields( type, version, items, doc );
        }

        MessageFieldsFilter.doMustEncrypt( items, doc, type, version );
        MessageColumnDataExtract.checkCardNumberField( props, type, version,
                doc, items );

        m_logger.debug("Exit transformMsg");
        return doc;
    }

    /**
     * This happened after the listener is stopped and the new messages map
     * and merchant ids are set
     */
    protected void changeFilter()
    {
        m_logger.debug("Enter changeFilter");

        if ( m_plugin != null && ( m_plugin.acceptFilterChange() || m_plugin.acceptDynamicFilterChange()) )
        {
            try {
                if ( !m_plugin.acceptDynamicFilterChange() )
                    m_session.unsubscribe( m_clientID );

                m_connection.close();
                m_initFlag = false;
                initializeJMS();

                m_plugin.setFilter( ListeningUtils.createFilterProperties(
                        m_messages, m_merchantIDs) );

//                String sstr = getSelectorString();
//                m_logger.debug("Selector String is [" + sstr + "]");
//              m_sub = m_session.createDurableSubscriber(m_topic, m_clientID );
//                m_sub = m_session.createDurableSubscriber(m_topic, m_clientID,
//                        sstr, true );
//                m_sub.setMessageListener(this);
                m_logger.debug("ChangeFilter successfully.");

            } catch (Throwable t) {
                m_logger.error("In changeFilter", t);
            }

        }

        m_logger.debug("Exit changeFilter");
    }

    /**
     * Set messages map list
     * @param messages - messages map list
     */
    public void setMessagesMap( Map messages )
    {
        m_messages = BeansHelper.cloneListeningMessageMap( messages );
    }

    /**
     *
     * @return - messages map list
     */
    public Map getMessagesMap()
    {
        return m_messages;
    }

    /**
     * set merchant ID list
     * @param ids - merchant ID list.
     */
    public void setMerchantIDs( List ids )
    {
        m_merchantIDs = BeansHelper.cloneMerchantList( ids );
    }

    /**
     *
     * @return - merchant ID list
     */
    public List getMerchantIDs()
    {
        return m_merchantIDs;
    }

	/**
	*
	* @return the long value of startStopTime.
	*/
	public long getStartStopTime(){
		return startStopTime;
	}

	/**
	*
	* @param aStartStopTime - the new value for startStopTime
	*/
	public void setStartStopTime(long aStartStopTime){
		startStopTime = aStartStopTime;
	}


	/**
	*
	* @return the String value of startStopReason.
	*/
	public String getStartStopReason(){
		return startStopReason;
	}

	/**
	*
	* @param aStartStopReason - the new value for startStopReason
	*/
	public void setStartStopReason(String aStartStopReason){
		setStartStopReason( Utils.LISTENING_START_STOP_BY_SERVER,
						   aStartStopReason );
	}

	/**
	*
	* @param aStartStopReason - the new value for startStopReason
	*/
	public void setStartStopReason( int id, String aStartStopReason){
		startStopReason = id + Utils.REASON_SUFFIX + aStartStopReason;
	}

	/**
	*
	* @param aStartStopReason - the  startStopReason ID
	*/
	public void setStartStopReason( int aStartStopReason ){
		startStopReason = aStartStopReason + Utils.REASON_SUFFIX;
	}
}

package com.oncecorp.visa3d.bridge.logging;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.oncecorp.visa3d.bridge.configure.ConfigurationManager;
/**
 * <p>Title: ONCE MPI Data Bridge</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Once Corporation</p>
 * @author yge@oncecorp.com
 * @version 1.0
 */

public class DataBridgeLoger {
  private static final PropertyConfigurator  configurator     = new PropertyConfigurator();
  static final   Properties           props            = new Properties();
  private static Properties           backupProps      = null;;
  private static final String         CONFIG_FILE_NAME = "log4j.properties";
  private static boolean              isConfigured     = false;
  private static String               OK = "OK";
  private static Logger               log4j;

  static {
    initConfig();
  }

  /**
   * This method returns the logger with the particular name.
   * @param name The logger name.
   * @return The logger instance.
   */
  public static Logger getLogger(String name) {
    if ( !isConfigured ) {
      //config();
      initConfig();
    }
    return Logger.getLogger(name);
  }

  /**
   * This method returns the logger whose name is the full name of the given class.
   * @param clazz The given class.
   * @return The logger instance.
   */
  public static Logger getLogger(Class clazz) {
    return DataBridgeLoger.getLogger(clazz.getName());
  }

  /**
   * This method returns the logger whose name is the full name of the class
   * name of the given object instance.
   * @param obj The given object instance.
   * @return The logger instance.
   */
  public static Logger getLogger(Object obj) {
    return DataBridgeLoger.getLogger(obj.getClass().getName());
  }

  /**
   * This method initializes the log4j.
   */
  private static void initConfig() {
    isConfigured = true;
    props.clear();
    props.setProperty("log4j.rootCategory", "DEBUG, dest0");
    props.setProperty("log4j.appender.dest0", "org.apache.log4j.ConsoleAppender");
    props.setProperty("log4j.appender.dest0.layout", "org.apache.log4j.PatternLayout");
    props.setProperty("log4j.appender.dest0.layout.ConversionPattern", "%d{dd MMM yyyy HH:mm:ss,SSS} %-5p [%t] (%F:%L) - %m%n");
    //configure(false);
    PropertyConfigurator.configure(props);
    log4j = Logger.getLogger(DataBridgeLoger.class);
  }

  /**
   * This method initializes the log4j from the config properties faile.
   */
  public static void initConfigFromFile() {
    backupValue();
    props.clear();
    try {
      //props.load(DataBridgeLoger.class.getResourceAsStream(CONFIG_FILE_NAME));
      log4j.debug("Start initConfigFromFile() call.");
      load();
      configure(false, false);
      Logger.getRootLogger().removeAppender("dest0");
    }
    catch (Exception e) {
      //throw new LoggingException("Loggign configuring error.", e);
      e.printStackTrace();
      log4j.error("Loggign configuring error.", e);
    }
  }

  /**
   * This method use properties data in the momery to config the log4j.  It does
   * no save config data into the config file.
   * @return The operation result message.
   */
   /*
  public static String doConfigure(Properties addProps) {
    Logger rootLogget = Logger.getRootLogger();
    try {
      log4j.debug("call configurator.doConfigure()");
      configurator.doConfigure(addProps, rootLogget.getLoggerRepository());
      log4j.debug("call props.putAll()");
      props.putAll(addProps);
      log4j.debug("call save()");
      save();
      log4j.debug("return OK");
      return OK;
      //return configure(true);
    }
    catch (Exception e) {
      log4j.error("Config data is not valid.", e);
      return "Config data is not valid.";
    }
  }*/

  /*
  public static void resetConfiguration() {
    BasicConfigurator.resetConfiguration();
    backupValue();
    props.clear();
  }*/

  public static String configure() {
    return configure(true);
  }

  public static String configure(boolean changeAppend) {
    return configure(true, changeAppend);
  }

  /**
   * This method use properties data in the momery to config the log4j.
   * @param saveFlag <tt>ture</tt> save the config data into the file, otherwise
   * not save.
   * @return The operation result message.
   */
  private static String configure(boolean saveFlag, boolean changeAppend) {
    try {
      PropertyConfigurator.configure(modifyFileProperty(props, changeAppend));
      if ( saveFlag ) {
        save();
      }
      return OK;
    }
    catch (Exception e) {
      PropertyConfigurator.configure(modifyFileProperty(backupProps, changeAppend));
      return "Config data is not valid.";
    }
  }

  /*
  private static Properties modifyFileProperty(Properties p) {
    return modifyFileProperty(p, false);
  }*/
  /**
   * This method converts the config properties object.  It checks the "File"
   * property value to see if it is absolute, if
   * not, put the log file into the default working directory.
   * @param p the Properties object to be converted.
   * @param changeAppend If <tt>true</tt>, set Append property to <tt>false</tt>.
   * @return The result properties object.
   */
  private static Properties modifyFileProperty(Properties p, boolean changeAppend) {
    Properties newProps = new Properties();
    newProps.putAll(p);
    for (Iterator i = newProps.keySet().iterator(); i.hasNext(); ) {
      String name = (String)i.next();
      if ( name.endsWith(".File") ) {
        String value = newProps.getProperty(name);
        File file = new File(value);
        if ( !file.isAbsolute() ) {
          String path = ConfigurationManager.getInstance().getDatabridgeWorkingDirectory() + "/logs";
          if ( value.startsWith("/") ) {
            path = path + value;
          }
          else {
            path = path + "/" + value;
          }
          File newPath = new File(path);
          File parent = newPath.getParentFile();
          if ( parent != null && !parent.exists() ) {
            parent.mkdirs();
          }
          newProps.setProperty(name, path);
        }
        else {
        }
      }
      else if ( changeAppend && name.endsWith(".Append") ) {
        newProps.setProperty(name, "true");
      }
    }
    return newProps;
  }

  /**
   * This method backup the config properties object.
   */
  public static void backupValue() {
    backupProps = new Properties();
    backupProps.putAll(props);
  }

  /**
   * This method set new config properties object to the log4j object.
   * @param p The new config properties object.
   */
  public static void setConfigProperties(Properties p) {
    props.clear();
    props.putAll(p);
  }

  /**
   * This method load properties data form the file.
   * @throws IOException If file operating failed.
   */
  private static void load() throws IOException {
    log4j.debug("Enter load log4j properties file.");
    String configFileFullName =
      ConfigurationManager.getInstance().getDatabridgeWorkingDirectory() + File.separator + CONFIG_FILE_NAME;
    InputStream is = null;
    try {
      is = new FileInputStream( configFileFullName );
    }
    catch ( Exception e ) {
      log4j.warn(configFileFullName + " doesn't exist. ");
      if ( CONFIG_FILE_NAME.indexOf( File.separator ) == -1 ) {
        log4j.debug(CONFIG_FILE_NAME + " is a relative path. Try class path");
        is =  ConfigurationManager.class.getResourceAsStream( CONFIG_FILE_NAME );
      }
    }

    if ( is != null ) {
      log4j.debug("Get the xml string");
      props.clear();
      props.load(is);
    }
    else {
      log4j.error("Can't load log4j properties from file.");
      return;
    }
  }

  /**
   * This method saves the log4j config data into the file.
   */
  private static void save() {
    log4j.debug("Enter save log4j properties file.");
    String configFileFullName =
      ConfigurationManager.getInstance().getDatabridgeWorkingDirectory() + "/" + CONFIG_FILE_NAME;
    File file = null;
    File saveFile = null;
    try {
      file = new File( configFileFullName );
      if ( !file.exists() || !file.canRead() || !file.canWrite() ) {
        log4j.debug(configFileFullName + " doesn't exist. ");
        if ( CONFIG_FILE_NAME.indexOf( File.separator ) == -1 ) {
          log4j.debug(CONFIG_FILE_NAME + " is a relative path. Try class path");
          URL url = ConfigurationManager.class.getResource( CONFIG_FILE_NAME );
          if ( url != null ) {
            String path = url.getFile();
            if ( path != null ) {
              saveFile = new File(path);
              if ( !file.exists() || !file.canRead() || !file.canWrite() ) {
                saveFile = null;
              }
            }
          }
        }
      }
      else {
        saveFile = file;
      }
      if ( saveFile != null ) {
        file = saveFile;
      }

    }
    catch ( Exception e ) {
      log4j.error("Exception during geting configuration file name.");
      file = null;
    }

    if ( file != null ) {

      log4j.debug("Save log4j properties name is:"+ file.getName());

      String apath = file.getAbsolutePath();
      File tmpDir = new File( apath );
      String ppath = tmpDir.getParent();
      String oname = file.getName();

      SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");

      String tmpFile = ppath + File.separator + sdf.format( new Date() ) + "_" + oname;

      log4j.debug( "Save the old file to: [" +  tmpFile + "]" );
      file.renameTo( new File ( tmpFile ) );

      try {
        OutputStream out = new FileOutputStream(apath, false);
        props.store(out, "");
      }
      catch (IOException e) {
        log4j.error("Write log4j properties file exception.", e);
      }
      log4j.debug("Saved log4j properties");
    }
    else {
      log4j.error("Can't save log4j properties file.");
    }

    log4j.debug("Exit save log4j properties.");
  }

  /**
   * This method is used for testing purpose.
   * @param args
   */
  public static void main(String[] args) {
    initConfig();
  }
}

package com.oncecorp.visa3d.bridge.security;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Map;
import java.security.Key;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.Security;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;

import com.oncecorp.visa3d.bridge.logging.DataBridgeLoger;
import org.apache.log4j.Logger;

import com.ibm.xml.dsig.util.Base64;

/**
 * Provides support for Triple-DES encryption.
 * This class is from mpi core and modified the config and logger mechanism by Gang Wu
 *
 * Add databridge related configuration functions by Gang Wu
 *
 * @version 0.1 Nov 28, 2002
 * @author	Alan Zhang
 */
public class TripleDESEncrypter {

    private static Logger m_logger = DataBridgeLoger.getLogger(
            TripleDESEncrypter.class.getName() );

    public final static String CIPHER_TEXT_IV_DELIMITER  =         "___";

	final static String CIPHER_TRANS = "DESede/CBC/PKCS5Padding";
	final static String KEY_GEN_TRANS = "DESede";

	private static SecretKey secretKey;
	private static TripleDESEncrypter encrypter;

    public final static String JCE_PROVIDER =  "JCEProvider";
    public final static String KEY_STORE_LOCATION = "KeystoreLocation";
    public final static String KEY_STORE_PASSWORD = "KeystorePwd";
    public final static String RAW_KEY_ALIAS = "RawkeyAlias";
    public final static String RAW_KEY_PASSWORD = "RawkeyPwd";

	private static String m_jceName = null;
	private static KeyStore m_keyStore = null;
	private static String  m_keyStroreFileName = null;

    private static Map m_props = null;

	/**
	 * Constructor
	 */
	private TripleDESEncrypter() {
        try {
            // Retreive Triple-DES configuration data
            String jceProvider = (String)m_props.get( JCE_PROVIDER );
            String keystoreLocation = (String)m_props.get( KEY_STORE_LOCATION );
            String keystorePwd = (String)m_props.get( KEY_STORE_PASSWORD );
            String rawkeyAlias = (String)m_props.get( RAW_KEY_ALIAS );
            String rawkeyPwd = (String)m_props.get( RAW_KEY_PASSWORD );

//            m_logger.debug("jceProvider=" + jceProvider);
//            m_logger.debug("keystoreLocation=" + keystoreLocation);
//            m_logger.debug("keystorePwd=" + keystorePwd);
//            m_logger.debug("rawkeyAlias=" + rawkeyAlias);
//            m_logger.debug("RAW_KEY_PASSWORD=" + rawkeyPwd);

            // Add JCE Provider
			if ( ( m_jceName == null || !m_jceName.equals( jceProvider ) )
				&& jceProvider != null )
			{
				Security.addProvider(
						(Provider) Class.forName(jceProvider).newInstance());
				m_jceName = jceProvider;
			}

            // Load keystore
            m_keyStore = loadKeystore(keystoreLocation, keystorePwd);
			m_keyStroreFileName = keystoreLocation;

            // Get private key
            Key key = getPrivateKey( m_keyStore, rawkeyAlias, rawkeyPwd);

            // Generate secret key
            setSecretKey(genSecretKey(key));

            m_logger.info("Triple-DES Encrypter init finished.");

        } catch (Exception e) {
            m_logger.error("Failed to init TripleDESEncrypter.", e);
        }
	}

    /**
     * Initialize the encrypter with the configuration data
     * @param props -  properties name/value pairs
     */
    public synchronized static void initialize( Map props )
    {
        m_props = props;
        encrypter = new TripleDESEncrypter();
    }

	/**
	 * Get singleton reference of this class
	 */
	public synchronized static TripleDESEncrypter getInstance() {
		if (encrypter == null) {
			encrypter = new TripleDESEncrypter();
		}

		return encrypter;
	}

	/**
	 * Get private key from keystore
	 *
	 * @param alias The key alias
	 * @param pwd The key password
	 * @return The private key
	 */
	public PrivateKey getPrivateKey(
		KeyStore keystore,
		String alias,
		String pwd) {
		try {
			// Get private key
			return (PrivateKey) keystore.getKey(alias, pwd.toCharArray());
		} catch (Exception e) {
			m_logger.error("Failed to get private key: " + alias, e);
			return null;
		}
	}

	/**
	 * Get public key from keystore
	 *
	 * @param alias The key alias
	 * @param pwd The key password
	 * @return The public key
	 */
	public PublicKey getPublicKey(
		KeyStore keystore,
		String alias,
		String pwd) {
		try {
			// Get private key
			Key key = keystore.getKey(alias, pwd.toCharArray());
			if (key instanceof PrivateKey) {
				// Get certificate of public key
				java.security.cert.Certificate cert =
					keystore.getCertificate(alias);

				// Get public key
				return cert.getPublicKey();
			} else {
				return null;
			}
		} catch (Exception e) {
			m_logger.error("Failed to get public key: " + alias, e);
			return null;
		}
	}

	/**
	 * load keystore
	 *
	 * @param location The keystore location
	 * @param pwd The keystore password
	 * @return The keystore
	 */
	private KeyStore loadKeystore(String location, String pwd) {
		KeyStore keystore = null;
		FileInputStream is = null;
		try {
			// Load the keystore in the user's home directory
			File file = new File(location);
			is = new FileInputStream(file);
			keystore = KeyStore.getInstance(KeyStore.getDefaultType());
			keystore.load(is, pwd.toCharArray());
			is.close();
		} catch (Exception e) {
			m_logger.error("Failed to load keystore from: " + location, e);
		} finally {
			try {
				if (is != null)
					is.close();
			} catch (IOException ioe) {
				m_logger.error(
					"Failed to close FileInputStream after loading keystore.");
			}
		}

		return keystore;
	}

	/**
	 * Generate secret key
	 *
	 * @param key The private key
	 * @return The secret key
	 */
	private SecretKey genSecretKey(Key key) throws Exception {
		byte[] rawkey = key.getEncoded();
        /*
		System.out.println(
			"Raw key (encoded): "
				+ com.ibm.xml.dsig.util.Base64.encode(rawkey));
        */

		DESedeKeySpec keyspec = new DESedeKeySpec(rawkey);
		SecretKeyFactory keyfactory = SecretKeyFactory.getInstance("DESede");
		SecretKey secretKey = keyfactory.generateSecret(keyspec);
		return secretKey;
	}

	/**
	 * Encrypt data
	 *
	 * @param msg The data to be encrypted
	 * @return The encrypted text and it's initialization vector
	 */
	public String[] encrypt(String msg) throws Exception {

		Cipher cipher = Cipher.getInstance(CIPHER_TRANS);
		cipher.init(Cipher.ENCRYPT_MODE, getSecretKey());

		// get the initialization vector
		byte[] iv = cipher.getIV();
		byte[] buffer = cipher.doFinal(msg.getBytes());

		String[] result = new String[2];
		result[0] = Base64.encode(buffer);
		result[1] = Base64.encode(iv);

		m_logger.info("Encryption finished.");
//		m_logger.debug("Result: " + result[0]);
		return result;
	}

	/**
	 * Decrypt data
	 *
	 * @param msg The data to be decrypted
	 * @param ivStr The initialization vector
	 * @return The decrypted text
	 */
	public String decrypt(String msg, String ivStr) throws Exception {
		Cipher cipher = Cipher.getInstance(CIPHER_TRANS);

		IvParameterSpec ivp = new IvParameterSpec(Base64.decode(ivStr));
		cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), ivp);

		String result = new String(cipher.doFinal(Base64.decode(msg)));
        m_logger.debug("Decryption finished.");
//		m_logger.debug("Decryption result: " + result);
		return result;
	}

    /**
     * Decrypt data
     *
     * @param msg The data to be decrypted, which include cipher text and IV
     * @return The decrypted text
     */
    public String decrypt( String msg ) throws Exception
    {

        if ( msg == null || msg.indexOf( CIPHER_TEXT_IV_DELIMITER ) == -1 )
        {
            m_logger.warn(" Not combined encrypt string, return orignal string.");
            return msg;
        }
        int place = msg.indexOf( CIPHER_TEXT_IV_DELIMITER );
        String ctext = msg.substring(0, place);
        String ivStr = msg.substring( place + CIPHER_TEXT_IV_DELIMITER.length() );
        Cipher cipher = Cipher.getInstance(CIPHER_TRANS);

        IvParameterSpec ivp = new IvParameterSpec(Base64.decode(ivStr));
        cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), ivp);

        String result = new String(cipher.doFinal(Base64.decode(ctext)));
        m_logger.debug("Decryption finished.");
//		m_logger.debug("Decryption result: " + result);
        return result;
    }

	/**
	 * Returns the secretKey.
	 * @return SecretKey
	 */
	public synchronized static SecretKey getSecretKey() {
		return secretKey;
	}

	/**
	 * Sets the secretKey.
	 * @param secretKey The secretKey to set
	 */
	public synchronized static void setSecretKey(SecretKey secretKey) {
		TripleDESEncrypter.secretKey = secretKey;
	}

	/**
	 *
	 * @return - the security setting's
	 */
	public static Map getSettings()
	{
		return m_props;
	}

	/**
	 *
	 * @return - key store instance
	 */
	public synchronized static KeyStore getKeyStore()
	{
		return m_keyStore;
	}

	/**
	 *
	 * @return - key store file name
	 */
	public static String getKeyStoreFileName()
	{
		return m_keyStroreFileName;
	}
}

package com.oncecorp.visa3d.mpi.messaging;

import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Vector;

import org.apache.log4j.Logger;
import org.apache.xerces.validators.schema.XUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.oncecorp.visa3d.mpi.domain.CardRange;
import com.oncecorp.visa3d.mpi.domain.payment.ErrorCodes;
import com.oncecorp.visa3d.mpi.logging.MPILogger;
import com.oncecorp.visa3d.mpi.messaging.meta.BindingMetaInfo;
import com.oncecorp.visa3d.mpi.messaging.meta.MessageMetaInfo;
import com.oncecorp.visa3d.mpi.messaging.meta.MessageUID;
import com.oncecorp.visa3d.mpi.utility.XMLUtil;

/**
 * DOM Document to Message converter. This class enables the conversion of
 * XML DOM object to an associated Java Message instances with all the proper
 * attributes and properties correctly initialized.
 *
 * The content of the MessageDefinition.xml file found within the package gives the
 * proper direction as to the mechanism and structure of each message. XPath
 * expressions are used to properly extract XML element and method reflection and
 * invocation are then executed to set all the proper attributes.
 *
 * @version $Revision: 53 $
 * @author	Alan Zhang
 *
 * Patented optimization strategies by
 * @author Martin Dufort (mdufort@oncecorp.com)
 */
public class DomToMsgConverter {
	/**
	 * Definition of all the binding types
	 */
	public final static String BINDING_TYPE_SIMPLE = "simple";
	public final static String BINDING_TYPE_COMPLEX = "complex";
	public final static String BINDING_TYPE_PROFILE = "profile";
	public final static String BINDING_TYPE_EXTENSION = "extension";
	public final static String BINDING_TYPE_ATTRVALUE = "attr";
	public final static String BINDING_TYPE_PROFILE_REQUEST = "profileRequest";
	public final static String BINDING_TYPE_SIGNATURE = "signature";
	public final static String BINDING_TYPE_CR = "cr";

	/**
	 * Local Log4J logger
	 */
	protected static Logger logger = MPILogger.getLogger(DomToMsgConverter.class.getName());

	/**
	 * Caching of method instances to imporve performance
	 */
	private static HashMap messageMethodCache = new HashMap();

	/**
	 * VISA 3-D message root
	 */
	protected final static String THREED_SECURE = "ThreeDSecure";

	/**
	 * MPI Interface message root
	 */
	protected final static String MPI_INTERFACE = "MPI_Interface";

	/**
	 * Element version
	 */
	protected final static String MSG_VERSION = "version/text()";

	/**
	 * MPI Message Attribute id
	 */
	protected final static String MPI_MSG_ID = "id";

	/**
	 * ThreeDSecure Message Attribute id
	 */
	protected final static String THREED_MSG_ID = "id";

	/**
	 * Message Extension attribute: critical
	 */
	protected final static String EXTENSION_CRITICAL = "critical";

	/**
	 * Message Signature tag name
	 */
	protected final static String SIGNATURE_TAG_NAME = "Signature";

	/**
	 * ProfileName element
	 */
	protected final static String PROFILE_NAME = "profileName/text()";

	/**
	 * ProfileScope element
	 */
	protected final static String PROFILE_SCOPE = "profileData/profileScope";

	/**
	 * Profile scopeid attribute
	 */
	protected final static String PROFILE_SCOPE_ID = "scopeid";

	/**
	 * ProfileDataItem element
	 */
	protected final static String PROFILE_DATA_ITEM = "profileDataItem";

	/**
	 * Profile uid attribute
	 */
	protected final static String PROFILE_UID = "uid";

	/**
	 * ProfileRequestItem element
	 */
	protected final static String PROFILE_REQUEST_ITEM = "profileRequestItem";

	/**
	 * Defined 3D-Secure message elements
	 */
	protected static Vector MSG_ELEMENTS;

	/**
	 * Mapping of defined message elements
	 * <ul>
	 * <li>key: element</li>
	 * <li>value: defined elements for key</li>
	 * </ul>
	 */
	protected static HashMap MSG_MAPPING;

	static {
		//Initialize MSG_ELEMENTS and MSG_MAPPING
		MSG_ELEMENTS = new Vector();
		MSG_ELEMENTS.add("CRReq");
		MSG_ELEMENTS.add("CRRes");
		MSG_ELEMENTS.add("VEReq");
		MSG_ELEMENTS.add("VERes");
		MSG_ELEMENTS.add("PAReq");
		MSG_ELEMENTS.add("PARes");
		MSG_ELEMENTS.add("Error");

		//Only CRRes, VERes, PARes, Error element mapping defined
		MSG_MAPPING = new HashMap();

		Vector temp = new Vector();
		temp.add("version");
		temp.add("CR");
		temp.add("serialNumber");
		temp.add("IReq");
		MSG_MAPPING.put("CRRes", temp);

		temp = new Vector();
		temp.add("version");
		temp.add("CH");
		temp.add("url");
		temp.add("protocol");
		temp.add("IReq");
		temp.add("Extension");
		MSG_MAPPING.put("VERes", temp);

		temp = new Vector();
		temp.add("version");
		temp.add("Merchant");
		temp.add("Purchase");
		temp.add("pan");
		temp.add("TX");
		temp.add("IReq");
		temp.add("Extension");
		MSG_MAPPING.put("PARes", temp);

		temp = new Vector();
		temp.add("version");
		temp.add("errorCode");
		temp.add("errorMessage");
		temp.add("errorDetail");
		temp.add("vendorCode");
		MSG_MAPPING.put("Error", temp);
	}

	/**
	 * Convert DOM document to MPI message.
	 */
	public Message convert(Document doc) throws Exception {

		//Prepare message id, type & version
		String msgId = null;
		String msgType = null;
		String msgVersion = null;
		Element root = null, e = null;

		if (doc == null) {
			throw new MessagingException(
				"UNKNOWN",
				ErrorCodes.ERROR_CODE_1,
				ErrorCodes.ERROR_MESSAGE_1,
				"ThreeDSecure",
				"Root element missing.",
				"Root element missing.");
		}

		//Get message root
		root = doc.getDocumentElement();

		//Get root name
		String name = root.getTagName();
		logger.debug("Message root element: " + name);

		try {
			if (name.equalsIgnoreCase(DomToMsgConverter.THREED_SECURE)) {
				//Get 'Message' element
				e = (Element) XMLUtil.getFirstNodeByXPath(root, "Message");
				if (e == null) {
					logger.error("Message element missing.");
					throw new MessagingException(
						"UNKNOWN",
						ErrorCodes.ERROR_CODE_3,
						ErrorCodes.ERROR_MESSAGE_3,
						"Message",
						"Message element missing.",
						"Message element missing..");
				}

				//Get message id
				if (e.getAttributeNode(THREED_MSG_ID) == null) {
					//id attribute missing
					logger.error("Message missing id attribute.");
					throw new MessagingException(
						"UNKNOWN",
						ErrorCodes.ERROR_CODE_3,
						ErrorCodes.ERROR_MESSAGE_3,
						"Message.id",
						"Message missing id attribute.",
						"Message missing id attribute.");
				}

				msgId = e.getAttribute(THREED_MSG_ID);
				if ((msgId == null) || (msgId.length() == 0)) {
					//no value
					throw new MessagingException(
						"UNKNOWN",
						ErrorCodes.ERROR_CODE_5,
						ErrorCodes.ERROR_MESSAGE_5,
						"Message.id",
						"Message has id attribute with no value.",
						"Message has id attribute with no value.");
				}

				//No checking for undefined elements
				//checkUndefinedElements(e);

				//Get message type element
				//e = XUtil.getFirstChildElement(e);

				//Check first child of Message element
				e = findDefinedMessageElement(msgId, e);

				//Get message type
				msgType = e.getTagName();

				//Get message version
				msgVersion = XMLUtil.getValueByXPath(e, MSG_VERSION);
				if (msgVersion == null) {
					//id attribute missing
					logger.error("Message missing version element.");
					throw new MessagingException(
						msgId,
						ErrorCodes.ERROR_CODE_3,
						ErrorCodes.ERROR_MESSAGE_3,
						"version",
						"version element missing.",
						"version element missing.");

				}
				else {
					if (msgVersion.length() == 0) {
						//no value
						throw new MessagingException(
							msgId,
							ErrorCodes.ERROR_CODE_5,
							ErrorCodes.ERROR_MESSAGE_5,
							"version",
							"version element has no value.",
							"version element has no value.");
					}
				}

			}
			else if (name.equalsIgnoreCase(DomToMsgConverter.MPI_INTERFACE)) {
				//Get message type element
				e = XUtil.getFirstChildElement(root);

				//Get message id
				msgId = e.getAttribute(MPI_MSG_ID);
				if ((msgId == null) || (msgId.length() == 0)) {
					//no value
					throw new MessagingException(
						"UNKNOWN",
						ErrorCodes.ERROR_CODE_5,
						ErrorCodes.ERROR_MESSAGE_5,
						"id",
						"MPI_Interface message has id attribute with no value.",
						"MPI_Interface message has id attribute with no value.");
				}

				//Get message type
				msgType = e.getTagName();

				//Get message version
				msgVersion = XMLUtil.getValueByXPath(e, MSG_VERSION);
				if (msgVersion == null) {
					//id attribute missing
					logger.error("Message missing version element.");
					throw new MessagingException(
						msgId,
						ErrorCodes.ERROR_CODE_3,
						ErrorCodes.ERROR_MESSAGE_3,
						"version",
						"version element missing.",
						"version element missing.");

				}
				else {
					if (msgVersion.length() == 0) {
						//no value
						throw new MessagingException(
							msgId,
							ErrorCodes.ERROR_CODE_5,
							ErrorCodes.ERROR_MESSAGE_5,
							"version",
							"version element has no value.",
							"version element has no value.");
					}
				}
			}
			else {
				logger.error("Root element of message is not recognized.");
				throw new MessagingException(
					"UNKNOWN",
					ErrorCodes.ERROR_CODE_1,
					ErrorCodes.ERROR_MESSAGE_1,
					name,
					"Root element:" + name + "is not recognized.",
					"Root element:" + name + "is not recognized.");
			}
		}
		catch (NullPointerException npe) {
			logger.error("Element missed.", npe);
			throw new MessagingException(
				msgId,
				ErrorCodes.ERROR_CODE_3,
				ErrorCodes.ERROR_MESSAGE_3,
				"Element missed. Message id: " + msgId + ", type: " + msgType + ": version: " + msgVersion,
				"Element missed",
				npe.getMessage());
		}

		//Logging
		logger.debug("Message ID: " + msgId);
		logger.debug("Message Type: " + msgType);
		logger.debug("Message Version: " + msgVersion);

		return makeConversion(doc, msgId, msgType, msgVersion);
	}

	/**
	 * This method performs the actual conversion from DOM to the Java instance.
	 *
	 * @param doc			The XML document we are converting from
	 * @param msgId			The messageID of this request
	 * @param msgType		The message type associated with this conversion
	 * @param msgVersion	The version that we must used, if supported
	 * @return Message		Return the appropriate Java instance message
	 * @throws MessagingException
	 */
	private Message makeConversion(Document doc, String msgId, String msgType, String msgVersion)
		throws MessagingException {
		// Check support for specific message type/version
		MessageUID msgUID = new MessageUID(msgType, msgVersion);
		if (!MessageMetaInfo.isVersionSupported(msgUID)) {
			throw new MessagingException(
				msgId,
				ErrorCodes.ERROR_CODE_5,
				ErrorCodes.ERROR_MESSAGE_5,
				"version",
				"Version: " + msgVersion + " is not supported by this software release.",
				"[MessageType:"
					+ msgType
					+ "] Version: "
					+ msgVersion
					+ " is not supported by this software release.)");
		}

		// Get message binding
		BindingMetaInfo binding = MessageMetaInfo.getBindingInfo(msgUID);
		String[] paths = binding.getPaths();
		String[] attributes = binding.getAttributes();
		String[] types = binding.getTypes();
		String[] javatypes = binding.getJavatypes();

		// Check binding info
		if ((paths == null) || (attributes == null) || (paths.length != attributes.length)) {
			logger.error("Message binding error.");
			throw new MessagingException("Binding error.");
		}

		//Get new message
		Message msg = MessageGenerator.create(msgType, msgVersion);

		//Set id first
		msg.setId(msgId);

		//Get underlying message class
		Class msgClass = msg.getClass();

		// Check if we have already cached the proper method information
		HashMap methodCache = (HashMap) messageMethodCache.get(msgUID);
		if (methodCache == null) {
			// No caching info. Saving it for next time
			methodCache = new HashMap();
			for (int i = 0; i < paths.length; i++) {
				String pathKey = paths[i];
				Method setterMethod = extractMethod(msgClass, paths[i], attributes[i], types[i], javatypes[i]);
				if (setterMethod == null) {
					// If method was not found, we cannot continue
					logger.error("Unable to located proper setter method information.");
					throw new MessagingException("Unable to located proper setter method information.");
				}

				// Add the proper setter method for the corresponding path
				methodCache.put(pathKey, setterMethod);
			}

			// Assigned all method caches to proper methodCache structure
			messageMethodCache.put(msgUID, methodCache);
		}


		//Set message attribute values
		Method setterMethod = null;
		Object[] arguments;
		for (int i = 0; i < paths.length; i++) {
			try {
				logger.debug("Entry[" + i + "]: ");

				//Get argument value
				Object value = getValue(doc, paths[i], types[i]);
				logger.debug("  value: " + value);

				// First fetch the proper method from the cache area
				setterMethod = (Method) methodCache.get(paths[i]);

				// then invoke method
				arguments = new Object[] { value };
				setterMethod.invoke(msg, arguments);
			}
			catch (NullPointerException npe) {
				logger.error("Element missed.", npe);
				throw new MessagingException(
					msgId,
					ErrorCodes.ERROR_CODE_3,
					ErrorCodes.ERROR_MESSAGE_3,
					"Element missed. Message id: "
						+ msgId
						+ ", type: "
						+ msgType
						+ ": version: "
						+ msgVersion,
					"Element missed",
					npe.getMessage());
			}
			catch (MessagingException me) {
				logger.error("MessagingException caught by Converter: ", me);
				throw new MessagingException(
					msgId,
					me.getErrorCode(),
					me.getErrorMsg(),
					me.getErrorDetail(),
					me.getVendorCode(),
					me.getMessage());
			}
			catch (InvocationTargetException ite) {
				if (ite.getTargetException() instanceof MessagingException) {
					MessagingException me = (MessagingException) ite.getTargetException();
					logger.error("Relecting invocation target exception: ", me);
					throw new MessagingException(
						msgId,
						me.getErrorCode(),
						me.getErrorMsg(),
						me.getErrorDetail(),
						me.getVendorCode(),
						me.getMessage());
				}
				else {
					logger.error("Unexpected Converting Error.", ite);
					throw new MessagingException(ite.getMessage());
				}
			}
			catch (Exception exception) {
				logger.error("Unexpected Converting Error.", exception);
				throw new MessagingException(exception.getMessage());
			}
		}

		//We are done.
		return msg;
	}

	/**
	 * Convenient method to get setter method name
	 */
	protected String getSetterName(String attr) {
		char[] charArray = attr.toCharArray();
		charArray[0] = Character.toUpperCase(charArray[0]);
		return ("set" + String.valueOf(charArray));
	}

	private Method extractMethod(Class msgClass, String path, String attribute, String type, String javaType) {
		Method setterMethod = null;
		try {

			//Logging
			logger.debug("  path: " + path);
			logger.debug("  attr: " + attribute);
			logger.debug("  type: " + type);
			logger.debug("  javatype: " + javaType);

			//Set up parameter type
			Class[] parameterTypes = new Class[] { getJavatypeClass(javaType)};

			//Get method
			setterMethod = msgClass.getMethod(getSetterName(attribute), parameterTypes);
		}
		catch (Exception e) {
			return null;
		}

		return setterMethod;
	}

	/**
	 * Convenient method to get setter attribute value
	 *
	 * @param doc The message document
	 * @param xpath The XPath to retrieve element value or nodelist
	 * @param type The binding type. Either "simple" or "complex"
	 * @return The attribute value.
	 */
	protected Object getValue(Document doc, String xpath, String type) throws Exception {
		//Check binding type
		if (type.equalsIgnoreCase(BINDING_TYPE_SIMPLE)) {
			return getSimpleValue(doc, xpath);

		}
		else if (type.equalsIgnoreCase(BINDING_TYPE_COMPLEX)) {
			return getComplexValue(doc, xpath);

		}
		else if (type.equalsIgnoreCase(BINDING_TYPE_PROFILE)) {
			return getProfileValue(doc, xpath);

		}
		else if (type.equalsIgnoreCase(BINDING_TYPE_EXTENSION)) {
			return getExtensionValue(doc, xpath);

		}
		else if (type.equalsIgnoreCase(BINDING_TYPE_ATTRVALUE)) {
			return getAttrValue(doc, xpath);

		}
		else if (type.equalsIgnoreCase(BINDING_TYPE_PROFILE_REQUEST)) {
			return getProfileRequestValue(doc, xpath);

		}
		else if (type.equalsIgnoreCase(BINDING_TYPE_SIGNATURE)) {
			return getSignatureValue(doc, xpath);

		}
		else if (type.equalsIgnoreCase(BINDING_TYPE_CR)) {
			return getCrValue(doc, xpath);

		}
		else {
			logger.error("Unknown binding type.");
			throw new MessagingException("Unknown binding type.");
		}
	}

	/**
	 * Convenient method to get simple type attribute value
	 *
	 * @param doc The message document
	 * @param xpath The XPath to retrieve element value or nodelist
	 * @return The attribute value.
	 */
	private Object getSimpleValue(Document doc, String xpath) throws Exception {
		//Simple type: Get value
		return XMLUtil.getValueByXPath(doc, xpath);
	}

	/**
	 * Convenient method to get complex type attribute value
	 *
	 * @param doc The message document
	 * @param xpath The XPath to retrieve element value or nodelist
	 * @return The String[] object
	 */
	private Object getComplexValue(Document doc, String xpath) throws Exception {
		//Complex type: multiple values could be existed.
		NodeList nl = XMLUtil.getNodeListByXPath(doc, xpath);

		if (nl.getLength() == 0)
			return null;

		//Prepare container
		String[] value = new String[nl.getLength()];

		//Get all the values
		for (int i = 0; i < value.length; i++) {
			value[i] = XMLUtil.getValueByXPath(nl.item(i), "text()");
		}

		//return result
		return value;
	}

	/**
	 * Convenient method to get profile type attribute value
	 *
	 * @param doc The message document
	 * @param xpath The XPath to retrieve element value or nodelist
	 * @return The Profile[] object.
	 */
	private Object getProfileValue(Document doc, String xpath) throws Exception {
		//Profile type: need return an array of type Profile
		NodeList nl = XMLUtil.getNodeListByXPath(doc, xpath);

		if (nl.getLength() == 0)
			return null;

		//Prepare container
		Profile[] value = new Profile[nl.getLength()];
		logger.debug("    Profile no.: " + value.length);

		//Get all the profile values
		for (int i = 0; i < nl.getLength(); i++) {
			//Get Profile element
			Element profileElement = (Element) nl.item(i);

			//Prepare individual profile object
			Profile profile = new Profile();

			//Set attribute values
			profile.setProfileName(XMLUtil.getValueByXPath(profileElement, PROFILE_NAME));

			//Get profile scope elements
			NodeList profileScopes = XMLUtil.getNodeListByXPath(profileElement, PROFILE_SCOPE);
			logger.debug("    Profile[" + i + "] scope no.: " + profileScopes.getLength());

			//Prepare prepare data container (key: scopeid, value: data item collection)
			HashMap profileData = new HashMap();

			//Set profile data
			for (int j = 0; j < profileScopes.getLength(); j++) {
				//Get individual profileScope element
				Element profileScope = (Element) profileScopes.item(j);

				//Get all data item elements
				NodeList profileDataItems = XMLUtil.getNodeListByXPath(profileScope, PROFILE_DATA_ITEM);

				//Prepare data itme container (key: uid, value: data item value)
				HashMap dataItems = new HashMap();
				logger.debug(
					"    Profile[" + i + "] scope[" + j + "] Item no.: " + profileDataItems.getLength());

				//Set data item values
				for (int k = 0; k < profileDataItems.getLength(); k++) {
					//Get individual data item element
					Element profileDataItem = (Element) profileDataItems.item(k);

					//add data item value to container
					dataItems.put(
						profileDataItem.getAttribute(PROFILE_UID),
						XMLUtil.getValueByXPath(profileDataItem, "text()"));
				}

				//Add data item collection to contatiner
				profileData.put(profileScope.getAttribute(PROFILE_SCOPE_ID), dataItems);
			}

			//Set profile data to profile object
			profile.setProfileData(profileData);

			//Add profile to container
			value[i] = profile;
		}

		//return result
		return value;
	}

	