class AuditTrailInterceptor extends EmptyInterceptor {
02. 
03.boolean onFlushDirty(Object entity, Serializable id, Object[] currentState,
04.Object[] previousState, String[] propertyNames,
05.Type[] types) {
06.setValue(currentState, propertyNames, "updatedBy", UserUtils.getCurrentUsername())
07.setValue(currentState, propertyNames, "updatedOn", new Date())
08.true
09.}
10. 
11.boolean onSave(Object entity, Serializable id, Object[] state,
12.String[] propertyNames, Type[] types) {
13.setValue(state, propertyNames, "createdBy", UserUtils.getCurrentUsername())
14.setValue(state, propertyNames, "createdOn", new Date())
15.true
16.}
17. 
18.private void setValue(Object[] currentState, String[] propertyNames,
19.String propertyToSet, Object value) {
20.def index = propertyNames.toList().indexOf(propertyToSet)
21.if (index >= 0) {
22.currentState[index] = value
23.}
24.}
25.}

So what did we do? First, we implemented the onFlushDirty and onSave methods because they are called for SQL updates and inserts, respectively. For example, when a new entity is first saved, the onSave method is called, at which point we want to set the createdBy and properties. And if an existing entity is updated, onFlushDirty is called and we set the updatedBy and updatedOn.

Second, we are using the setValue helper method to do the real work. Specfically, the only way to modify the state in a Hibernate Interceptor (that I am aware of anyway) is to dig into the currentState array and change the appropriate value. In order to do that, you first need to trawl through the propertyNames array to find the index of the property you are trying to set. For example, if you are updating a blog entry you need to set the updatedBy and updatedOn properties within the currentState array. For a BlogEntry object, the currentState array might look like this before the update (the updated by and on propertes are both null in this case because the entity was created by Bob but has not been updated yet):
view source
print?
01.{
02."Bob",
03.2008-08-27 10:57:19.0,
04.null,
05.null,
06.2008-08-27 10:57:19.0,
07."Lorem ipsum...",
08."My First Blog Entry",
09.0
10.}

You then need to look at the propertyNames array to provide context for what the above data represents:
view source
print?
01.{
02."createdBy",
03."createdOn",
04."updatedBy",
05."updatedOn",
06."publishedOn",
07."text",
08."title",
09."version"
10.}

So in the above updatedBy is at index 2 and updatedOn is located at index 3. setValue() works by finding the index of the property it needs to set, e.g. "updatedBy," and if the property was found, it changes the value at that index in the currentState array. So for updatedBy at index 2, the following is the equivalent code if we had actually hardcoded the implementation to always expect the audit fields as the first four properties (which is obviously not a great idea):
view source
print?
1.// Equivalent hard-coded code to change "updatedBy" in above example
2.// Don't use in production!
3.currentState[2] = UserUtils.getCurrentUsername()

To actually make your interceptor do something, you need to enable it on the Hibernate Session. You can do this in one of several ways. If you are using plain Hibernate (i.e. not with Spring or another framework) you can set the interceptor globally on the SessionFactory, or you can enable it for each Session as in the following example code:
view source
print?
01.// Configure interceptor globally (applies to all Sessions)
02.sessionFactory =
03.new AnnotationConfiguration()
04..configure()
05..setNamingStrategy(ImprovedNamingStrategy.INSTANCE)
06..setInterceptor(new AuditTrailInterceptor())
07..buildSessionFactory()
08. 
09.// Enable per Session
10.Session session = getSessionFactory().openSession(new AuditTrailInterceptor())

If you enable the interceptor globally, it must be thread-safe. If you are using Spring you can easily configure a global interceptor on your session factory bean:
view source
print?
1.<bean id="sessionFactory"
2.class="org.springframework.orm.hibernate3.annotation.AnnotationSessionFactoryBean">
3.<property name="entityInterceptor">
4.<bean class="com.nearinfinity.hibernate.interceptor.AuditTrailInterceptor"/>
5.</property>
6.<!-- additional Hibernate configuration properties -->