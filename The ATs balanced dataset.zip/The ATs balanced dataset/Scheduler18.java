 * Importance is an additional scheduling metric that may be used by
 * some priority-based scheduling algorithms during overload
 * conditions to differentiate execution order among threads of the
 * same priority. In some real-time systems an external physical
 * process determines the period of many threads. If rate-monotonic
 * priority assignment is used to assign priorities many of the
 * threads in the system may have the same priority because their
 * periods are the same. However, it is conceivable that some threads
 * may be more important than others and in an overload situation
 * importance can help the scheduler decide which threads to execute
 * first. The base scheduling algorithm represented by {@link
 * PriorityScheduler} is not required to use importance. However, the
 * RTSJ strongly suggests to implementers that a fairly simple
 * subclass of {@link PriorityScheduler} that uses importance can
 * offer value to some real-time applications.
 *
 * @author <a href="mailto:corsaro@cse.wustl.edu">Angelo Corsaro</a>
 * @author <a href="mailto:mdeters@morgandeters.com">Morgan Deters</a>
 * @version 1.0
 */
public class ImportanceParameters extends PriorityParameters {

    private int importance;

    /**
     * Create an instance of {@link ImportanceParameters}.
     *
     * @param priority The priority assigned to a thread. This value
     * is used in place of the value returned by
     * java.lang.Thread.setPriority(int)
     * @param importance The importance value assigned to a thread.
     */
    public ImportanceParameters(int priority, int importance) {
        super(priority);
        setImportance(importance);
    }

    /**
     * Gets the importance value.
     *
     * @return the importance value
     */
    public int getImportance() {
        return importance;
    }

    /**
     * Sets the importance value.
     *
     * @param importance the new importance value
     * @throws IllegalArgumentException if the given importance value
     * is incompatible with the {@link Scheduler} for any of the
     * {@link Schedulable} objects currently sharing this {@link
     * SchedulingParameters} object
     */
    public void setImportance(int importance) {
        // jRate's Scheduler supports any integer as an importance value
        this.importance = importance;
        notifyChanged();
    }

    /**
     * Get a {@link String} representation of this {@link
     * ImportanceParameters}.
     *
     * @return a {@link String} representation of this {@link
     * ImportanceParameters}
     */
    public String toString() {
        return "Importance Parameters: " + priority + ", " + importance;
    }
}