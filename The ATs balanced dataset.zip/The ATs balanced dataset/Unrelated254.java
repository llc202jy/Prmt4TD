
        remove = conn.prepareStatement("delete"
               +" from"
               +" clients"
               +" where threadid = ?");

        removeMods = conn.prepareStatement("delete"
               +" from"
               +" clientmodules"
               +" where threadid = ?");
        removeArgs = conn.prepareStatement("delete"
               +" from"
               +" arguements"
               +" where threadid = ?");
       remove.setInt(1,threadID);
       removeMods.setInt(1,threadID);
       removeArgs.setInt(1,threadID);

       remove.executeUpdate();
       removeMods.executeUpdate();
       removeArgs.executeUpdate();
      }

    } catch (Exception ex) {
      logProxy.log(ex);
    } finally {
      try {select.close();} catch (Exception ex) {}
      try {remove.close();} catch (Exception ex) {}
      try {removeMods.close();} catch (Exception ex) {}
      try {removeArgs.close();} catch (Exception ex) {}
      try {rset.close();} catch (Exception ex) {}
    }
  }


  public int createNewClient(int threadID, String clientName, String clientIP, Enumeration modlist) throws Exception{
      validateConnection();
      PreparedStatement exist = null;
      PreparedStatement insert = null;
      PreparedStatement getClientID = null;
      PreparedStatement insertMod = null;
      PreparedStatement selectModID = null;
      PreparedStatement insertArg = null;
      ResultSet rset = null;
      int result = NACK;
      try {
        validateConnection();
        exist = conn.prepareStatement("select"
                +" clientname"
                +" from"
                +" clients"
                +" where"
                +" clientname = ?");
        insert = conn.prepareStatement("insert"
                +" into"
                +" clients(threadid, clientname,clientip,onlinetime)"
                +" values(?,?,?,?)");
        exist.setString(1,clientName);
        rset = exist.executeQuery();
        if(!rset.next()){
          rset.close();
          insert.setInt(1, threadID);
          insert.setString(2, clientName);
          insert.setString(3, clientIP);
          insert.setString(4, new java.util.Date().toString());
          insert.executeUpdate();
//          getClientID = conn.prepareStatement("select"
//                                              + " clientid"
//                                              + " from"
//                                              + " clients"
//                                              + " where"
//                                              + " clientname = ?"
//                                              + " and threadid = ?");
//          getClientID.setString(1, clientName);
//          getClientID.setInt(2, threadID);
//          rset = getClientID.executeQuery();