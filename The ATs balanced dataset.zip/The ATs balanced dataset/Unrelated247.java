	private void loadBuddyListResources()
	{
		//load the buddy icons
		buddyOfflineIcon = UIHelper.readImageIcon("images/buddylist/offline.png");
		buddyOnlineIcon = UIHelper.readImageIcon("images/buddylist/online.png");
		buddyCoolIcon = UIHelper.readImageIcon("images/buddylist/cool.png");
		buddyBlockedOnlineIcon = UIHelper.readImageIcon("images/buddylist/blockedonline.png");
		buddyAwayIcon = UIHelper.readImageIcon("images/buddylist/away.png");
		
		//create the fonts
		groupFont = new Font("Tahoma",Font.BOLD,11);
		
		//get the buddy list stuff
		String face = null;
		int size = 0;
		int styles = 0;
		

		treeModel = new DefaultTreeModel(treeRoot);
		
		//create the buddy list tree
		buddyListTree = new JTree(treeModel)
		{
			//JToolTip Fix
			public String getToolTipText(MouseEvent e)
			);
			
		//we're done	
	}
	
	private Buddy createBuddy()
	{
		return new Buddy();
	}
	
	private Group createGroup()
	{
		return new Group();
	}
	
	/*
		parse Buddy LIst
		
		read in the xml that comes in
	
		the structure of a BuddyList coming in looks like this:
		
		<service type="buddylist">
			<buddylist>
				<groups>
					
				group.buddySignedOff();
				
			}
		}		
		
		buddy.setStatus(st,stmsg);	//done
		
		if (time != null)
		{
			long t = Long.parseLong(time);
			
			buddy.setTime(t);	
		}
		
		//notify the buddy list panel
		BuddyListPanel.buddyStatusChanged(buddy);
		
		//let the conversation manager know
		ConversationManager.updateBuddyStatus(buddy);
		
	}
	
	
	
	/*
	
		retrieval functions
		
	*/
	
	public static Map getGroups() throws Exception
	{
		if (instance == null)
			throw new Exception("BuddyList.getGroups(): instance not created yet!");
			
		return instance.groups;
	
	}
	
	public static Map getBuddies() throws Exception
	{
		if (instance == null)
			throw new Exception("BuddyList.getBuddies(): instance not created yet!");
			
		return instance.buddies;
	}
			
	public static Buddy getBuddy(String username)
	{
		if (instance == null)
			return null;
