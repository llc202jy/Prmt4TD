 public int getInt(String name)
    {
        try
        {
            return TypeConversionHelper.string2int(getString(name));
        }
        catch (TypeConversionException e)
        {
            throw new RuntimeException(e);
        }
    }

    /* (non-Javadoc)
     * @see de.x4technology.registry.Registry#getDouble(java.lang.String)
     */
    public double getDouble(String name)
    {
        try
        {
            return TypeConversionHelper.string2double(getString(name));
        }
        catch (TypeConversionException e)
        {
            throw new RuntimeException(e);
        }
    }

    /* (non-Javadoc)
     * @see de.x4technology.registry.Registry#getBoolean(java.lang.String)
     */
    public boolean getBoolean(String name)
    {
        try
        {
            return TypeConversionHelper.string2boolean(getString(name));
        }
        catch (TypeConversionException e)
        {
            throw new RuntimeException(e);
        }
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        try
        {
            StringWriter sw = new StringWriter();
            XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
            outputter.output(doc, sw);
            return sw.toString();
        }
        catch (Exception ex)
        {
            return ex.toString();
        }
    }

    protected void store()
    {
        try
        {
            File f = new File(path);
            OutputStream os = new BufferedOutputStream(new FileOutputStream(f));
            XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
            outputter.output(doc, os);
        }
        catch (IOException e)
        {
            log().error(ExceptionHelper.dump(e));
        }
    }

    public void load()
    {
        try
        {
            File f = new File(path);
            if (f.exists())
            {
                SAXBuilder builder = new SAXBuilder();
                Document doc = builder.build(f);
                this.doc = doc;
            }
        }
        catch (Exception e)
        {
            log().error(ExceptionHelper.dump(e));
            throw new RuntimeException(e);
        }
    }

    /*
     * 
     */
    public void setPath(String path)
    {
        if (path == null) throw new NullPointerException("path");
        this.path = path;
    }

    protected String path = null;

    private static transient de.x4technology.logging.LogFacility __log = null;

    private static de.x4technology.logging.LogFacility log()
    {
        if (__log == null) __log = de.x4technology.logging.LogFactory.getFacility(RegistryImpl.class);
        return __log;
    }
    
  
    public void validate()
    {
        if (path==null)
            throw new IllegalStateException("Not yet configured (path)");
    }

}

package de.x4technology.hibernate.ehcache;

import java.io.IOException;
import java.io.Serializable;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import net.sf.hibernate.cache.CacheException;
import net.sf.hibernate.cache.Timestamper;

/**
 * @author martin
 */
public class EHCachePlugin implements net.sf.hibernate.cache.Cache
{
    private static String pathToConfigFile = null;
    
    public static void setPathToConfigFile(String path)
    {
        if (pathToConfigFile != null) throw new IllegalArgumentException("Path to config file has already been set. You cannot set it twice.");
        pathToConfigFile = path;
    }
    
    private static transient de.x4technology.logging.LogFacility __log = null;

    private static de.x4technology.logging.LogFacility log()
    {
        if (__log == null) __log = de.x4technology.logging.LogFactory.getFacility(EHCachePlugin.class);
        return __log;
    }
    private static final int MS_PER_MINUTE = 60000;

    private Cache cache;

    /**
     * Creates a new Hibernate pluggable cache based on a cache name.
     * <p>
     * @param name the name of the cache. This cache must have already been configured.
     * @throws CacheException If there is no cache with the given name.
     */
    public EHCachePlugin(String name) throws CacheException
    {
        try
        {
            CacheManager manager = null;
            if (pathToConfigFile != null)
            {
                manager = CacheManager.create(pathToConfigFile);
            }
            else
            {
                manager = CacheManager.getInstance();
            }
            cache = manager.getCache(name);
            if (cache == null)
            {
                log().warn(
                        "Could not find configuration for " + name + ". Configuring using the defaultCache settings.");
                manager.addCache(name);
                cache = manager.getCache(name);
            }
        }
        catch (net.sf.ehcache.CacheException e)
        {
            throw new CacheException(e);
        }
    }

    /**
     * Gets a value of an element which matches the given key.
     * @param key the key of the element to return.
     * @return The value placed into the cache with an earlier put, or null if not found or expired
     * @throws CacheException
     */
    public Object get(Object key) throws CacheException
    {
        try
        {
            if (log().isDebugEnabled())
            {
                log().debug("key: " + key);
            }
            if (key == null)
            {
                return null;
            }
            else
            {
                Element element = cache.get((Serializable) key);
                if (element == null)
                {
                    if (log().isDebugEnabled())
                    {
                        log().debug("Element for " + key + " is null");
                    }
                    return null;
                }
                else
                {
                    return element.getValue();
                }
            }
        }
        catch (net.sf.ehcache.CacheException e)
        {
            throw new CacheException(e);
        }
    }

    /**
     * Puts an object into the cache.
     * @param key a {@link Serializable} key
     * @param value a {@link Serializable} value
     * @throws CacheException if the parameters are not {@link Serializable}, the {@link CacheManager}
     * is shutdown or another {@link Exception} occurs.
     */
    public void put(Object key, Object value) throws CacheException
    {
        try
        {
            Element element = new Element((Serializable) key, (Serializable) value);
            cache.put(element);
        }
        catch (IllegalArgumentException e)
        {
            throw new CacheException(e);
        }
        catch (IllegalStateException e)
        {
            throw new CacheException(e);
        }

    }

    /**
     * Removes the element which matches the key.
     * <p>
     * If no element matches, nothing is removed and no Exception is thrown.
     * @param key the key of the element to remove
     * @throws CacheException
     */
    public void remove(Object key) throws CacheException
    {
        try
        {
            cache.remove((Serializable) key);
        }
        catch (ClassCastException e)
        {
            throw new CacheException(e);
        }
        catch (IllegalStateException e)
        {
            throw new CacheException(e);
        }
    }

    /**
     * Remove all elements in the cache, but leave the cache
     * in a useable state.
     * @throws CacheException
     */
    public void clear() throws CacheException
    {
        try
        {
            cache.removeAll();
        }
        catch (IllegalStateException e)
        {
            throw new CacheException(e);
        }
        catch (IOException e)
        {
            throw new CacheException(e);
        }
    }

    /**
     * Remove the cache and make it unuseable.
     * @throws CacheException
     */
    public void destroy() throws CacheException
    {
        try
        {
            CacheManager.getInstance().removeCache(cache.getName());
        }
        catch (IllegalStateException e)
        {
            throw new CacheException(e);
        }
        catch (net.sf.ehcache.CacheException e)
        {
            throw new CacheException(e);
        }
    }

    /**
     * Calls to this method should perform there own synchronization.
     * It is provided for distributed caches. Because EHCache is not distributed
     * this method does nothing.
     */
    public void lock(Object key) throws CacheException
    {
    }

    /**
     * Calls to this method should perform there own synchronization.
     * It is provided for distributed caches. Because EHCache is not distributed
     * this method does nothing.
     */
    public void unlock(Object key) throws CacheException
    {
    }

    /**
     * Gets the next timestamp;
     */
    public long nextTimestamp()
    {
        return Timestamper.next();
    }

    /**
     * Returns the lock timeout for this cache.
     */
    public int getTimeout()
    {
        // 60 second lock timeout
        return Timestamper.ONE_MS * MS_PER_MINUTE;
    }
}
package de.x4technology.naming;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import javax.naming.CompositeName;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.NameAlreadyBoundException;
import javax.naming.NameNotFoundException;
import javax.naming.NameParser;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;

import de.x4technology.helper.exception.NotImplementedYetException;

/**
 * @author martin
 */
public class InitialContextInMemoryImpl implements Context, Serializable
{

    private Hashtable environment = null;

    private Map map = new HashMap();

    /**
     * 
     */
    public InitialContextInMemoryImpl()
    {
    }

    /**
     * @param environment2
     */
    public InitialContextInMemoryImpl(Hashtable aEnvironment)
    {
        this();
        this.environment = aEnvironment;
    }

    public void close() throws NamingException
    {
        map.clear();
    }

    public String getNameInNamespace() throws NamingException
    {
        throw new NotImplementedYetException();

    }

    public void destroySubcontext(String name) throws NamingException
    {
        throw new NotImplementedYetException();

    }

    public void unbind(String name) throws NamingException
    {
        unbind(new CompositeName(name));
    }

    /**
     * @param name
     */
    private void doUnbind(String name)
    {
        map.remove(name);
    }

    public Hashtable getEnvironment() throws NamingException
    {
        return environment;
    }

    public void destroySubcontext(Name name) throws NamingException
    {
        throw new NotImplementedYetException();

    }

    public void unbind(Name name) throws NamingException
    {
        String msName = name.get(0);
        Name suffix = name.getSuffix(1);
        if (suffix.size() == 0)
        {
            // this is the last name, so object must be found in this context
            doUnbind(msName);
        }
        else
        {
            // traverse deeper contexts
            Context c = (Context) map.get(msName);
            if (c != null)
            {
                c.unbind(suffix);
            }
        }
    }

    public Object lookup(String name) throws NamingException
    {
        return lookup(new CompositeName(name));
    }

    public Object lookupLink(String name) throws NamingException
    {
        throw new NotImplementedYetException();

    }

    public Object removeFromEnvironment(String propName) throws NamingException
    {
        throw new NotImplementedYetException();

    }

    public void bind(String name, Object obj) throws NamingException
    {
        bind(new CompositeName(name), obj);
    }

    /**
     * @param obj
     * @throws InvalidAttributesException
     */
    private void validateObject(Object obj) throws NamingException
    {
        if (null == obj)
        {
            throw new NamingException();
        }
    }

    /**
     * @param name
     * @throws InvalidNameException
     */
    private void validateName(String name) throws NamingException
    {
        if (null == name)
        {
            throw new NamingException(name);
        }
    }

    public void rebind(String name, Object obj) throws NamingException
    {
        rebind(new CompositeName(name), obj);
    }

    public Object lookup(Name name) throws NamingException
    {
        String msName = name.get(0);
        Name suffix = name.getSuffix(1);
        if (suffix.size() == 0)
        {
            // this is the last name, so object must be found in this context
            Object o = map.get(msName);
            if (null == o)
            {
                throw new NameNotFoundException(msName);
            }
            return o;
        }
        else
        {
            // traverse deeper contexts
            if (!map.containsKey(msName))
            {
                throw new NameNotFoundException(msName);
            }
            Context c = (Context) map.get(msName);
            return c.lookup(suffix);
        }
    }

    public Object lookupLink(Name name) throws NamingException
    {
        throw new NotImplementedYetException();

    }

    public void bind(Name name, Object obj) throws NamingException
    {
        String msName = name.get(0);
        Name suffix = name.getSuffix(1);
        if (suffix.size() == 0)
        {
            // this is the last name, so object must be found in this context
            doBind(msName, obj);
        }
        else
        {
            // traverse deeper contexts
            if (!map.containsKey(msName))
            {
                throw new NameNotFoundException(msName);
            }
            Context c = (Context) map.get(msName);
            c.bind(suffix, obj);
        }
    }

    /**
     * @param obj
     * @param msName
     * @throws NamingException
     */
    private void doBind(String msName, Object obj) throws NamingException
    {
        if (map.containsKey(msName))
        {
            throw new NameAlreadyBoundException(msName);
        }
        validateObject(obj);
        validateName(msName);
        map.put(msName, obj);
    }

    public void rebind(Name name, Object obj) throws NamingException
    {
        unbind(name);
        bind(name, obj);
    }

    public void rename(String oldName, String newName) throws NamingException
    {
        rename(new CompositeName(oldName), new CompositeName(newName));
    }

    public Context createSubcontext(String name) throws NamingException
    {
        return createSubcontext(new CompositeName(name));
    }

    public Context createSubcontext(Name name) throws NamingException
    {
        String msName = name.get(0);
        Name suffix = name.getSuffix(1);
        if (suffix.size() == 0)
        {
            // this is the last name, so new context has to be created here
            if (map.containsKey(msName))
            {
                throw new NameAlreadyBoundException(name.toString());
            }
            validateName(msName);
            Context c = new InitialContextInMemoryImpl();
            doBind(msName, c);
            return c;
        }
        else
        {
            // traverse deeper contexts
            if (!map.containsKey(msName))
            {
                throw new NameNotFoundException(msName);
            }
            Context c = (Context) map.get(msName);
            return c.createSubcontext(suffix);
        }
    }

    public void rename(Name oldName, Name newName) throws NamingException
    {
        Object old = lookup(oldName);
        bind(newName, old);
        unbind(oldName);
    }

    public NameParser getNameParser(String name) throws NamingException
    {
        throw new NotImplementedYetException();

    }

    public NameParser getNameParser(Name name) throws NamingException
    {
        throw new NotImplementedYetException();

    }

    public NamingEnumeration list(String name) throws NamingException
    {
        throw new NotImplementedYetException();

    }

    public NamingEnumeration listBindings(String name) throws NamingException
    {
        throw new NotImplementedYetException();

    }

    public NamingEnumeration list(Name name) throws NamingException
    {
        throw new NotImplementedYetException();

    }

    public NamingEnumeration listBindings(Name name) throws NamingException
    {
        throw new NotImplementedYetException();

    }

    public Object addToEnvironment(String propName, Object propVal) throws NamingException
    {
        throw new NotImplementedYetException();

    }

    public String composeName(String name, String prefix) throws NamingException
    {
        throw new NotImplementedYetException();

    }

    public Name composeName(Name name, Name prefix) throws NamingException
    {
        throw new NotImplementedYetException();

    }

}

