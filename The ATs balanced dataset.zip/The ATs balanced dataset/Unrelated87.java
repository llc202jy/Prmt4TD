
    /**
     * calls the Referent's deref() method.
     * If the release() method is already called before finalization, the referent will be a nil referent, and the deref() will be no-op.
     */
	protected final void finalize(){
		refee.deref();
	}
    /**
     * the aggregated Referent object     
     */
	protected Referent refee;
    /**
     * constructs the AbstractRef using a Referent.     
     */
	protected AbstractRef(final Referent ref){
		this.refee = ref;
	}
}	
	private final class Init implements State{
		public final void start(final Runnable r){
			state = Dead.instance();
			proc.start(new Runnable(){
				public final void run(){
					try{
						r.run();
					}
					catch(RuntimeException e){
						handler.handle(e);
					}
				}
			});			
		}

		public final void dismiss(){
package edu.my.util.worker;
import edu.my.util.ref.RefCountable;

final class AtomicWorkerProc implements WorkerProc{
//this class calls a RefCountable to enforce the thread does not get collected before the user worker finishes.
	public final void start(final Runnable r){
		try{
			counter.enref();
		}
		catch(RuntimeException re){
			counter.deref();
			throw re;
		}
	This facade class provides methods user can call to install security to the System and get the ThreadConstructor they can use to get around the security.
 * the ThreadConstructor methods will create a edu.my.util.thread.Thread object
 * 
 *
 * @see edu.my.util.thread.security.ThreadSecurity
 * @see edu.my.util.thread.ThreadConstructor
 * @see edu.my.util.thread.Thread
 * @see edu.my.util.thread.security.ThreadGuard
 *
 * @author Ben Yu 
 * @version 1.0, 09/09/02
 * 
 */
public final class ThreadSecurityFacade{
	/**
	* install the ThreadGuard object into the security system.
	* @param sec the ThreadGuard object that's responsible for checking the thread objects.	
	* If a installSecurity method is already called, this will throw IllegalStateException out.
	* If there's already a SecurityManager installed in the system, and the SecurityManager allows itself to be replaced,
	* it'll chain the SecurityManager after the ThreadGuard. So that, a thread can only pass the security check when both the ThreadGuard and the existing SecurityManager allow it.
	* and all other resources are still managed by the old SecurityManager object.
	* If the existent SecurityManager does not allow itself to be changed, a SecurityException will be thrown.
	* @exception IllegalStateException
	* @exception SecurityManager
	*/
	static void installSecurity(final ThreadGuard sec){		
		final SecurityManager man = System.getSecurityManager();
		if(man instanceof Protected){
			//already protected
			throw new IllegalStateException("SecurityManager already installed");
		}
		installSecurity(sec, man);		
	}
	static void installSecurity(final ThreadGuard sec, final SecurityManager next){
	//to chain a SecurityManager after this thread check.
		if(next == null){			
			System.setSecurityManager(DefaultThreadProtector.instance(sec));
		}
		else{			
			System.setSecurityManager(DelegateThreadProtector.instance(next, sec));
		}			
	}
	static ThreadConstructor getThreadConstructor(){
		return getThreadSecurity();
	}
	static ThreadGuard getThreadGuard(){
		return getThreadSecurity();
	}
	/**
	* it returns a ThreadSecurity object with which you can construct Thread objects and manage the security of those objects.
	* @return the ThreadSecurity object.
	*/
	public static ThreadSecurity getThreadSecurity(){
		return ThreadSecurityImpl.instance();
	}
	/**
	* installs protection for threads constructed by the returned ThreadConstructor to the system security. 
	* Ad-hoc access to the underlying thread of the edu.my.util.thread.Thread object constructed by the ThreadConstructor will be disallowed.
	* All access must go through the wrapping edu.my.util.thread.Thread object.	
	* for example: <code>
	* edu.my.util.thread.ThreadConstructor tcon = ThreadSecurityFacade.installSecurity();<br>
	* edu.my.util.thread.Thread th = tcon.newThread(new Runnable(){<br>
