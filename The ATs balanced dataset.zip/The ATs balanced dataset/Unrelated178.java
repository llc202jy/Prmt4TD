 public static boolean validateArrayOfWebsiteDictionaries(User currentUser,
                                                              NSArray dictArray,
                                                              EOEditingContext ec) {
        boolean valid = true;
        Enumeration e = dictArray.objectEnumerator();

        while(e.hasMoreElements())
        {
            // grab each dictionary in the array
            NSMutableDictionary newWebsiteDict = (NSMutableDictionary)e.nextElement();

            // get the associated org unit name and make it into an object
            String assocOrgUnitName = (String)newWebsiteDict.objectForKey(Website.ASSOC_UNIT_NAME);
            OrgUnit assocOrgUnit = OrgUnit.unitForUnitName(assocOrgUnitName, ec);

            String ownerID = (String)newWebsiteDict.objectForKey(Website.OWNER_ID_KEY);
            Website website = websiteFromDictionary(newWebsiteDict);
            NSMutableDictionary errors = validateWebsite(website.siteID(),
                                                         website.redirectURL(),
                                                         assocOrgUnit,
                                                         ownerID,
                                                         website.megQuota(),
                                                         website.fileSizeUsage(),
                                                         ec);

            if ( ! assocOrgUnit.userIsAdmin(currentUser))
            {
                errors.setObjectForKey("Cannot create unit: you are not a admin for the requested parent unit.",
                                        WEBSITE_OUT_OF_ADMIN_SCOPE_ERROR_KEY);
            }

            if (errors.count() > 0)
            {
                newWebsiteDict.setObjectForKey(errors, ERROR_MESSAGE_KEY);
                valid = false;
            }
        }

        return valid;
    }


    
    public static void createWebsitesFromArrayOfWebsiteDictionaries(NSArray dictArray,
                                                                     EOEditingContext ec) {
        Enumeration e = dictArray.objectEnumerator();

        while(e.hasMoreElements()) {
            // grab each dictionary in the array
            NSMutableDictionary newWebsiteDict = (NSMutableDictionary)e.nextElement();

            // get the associated org unit name and make it into an object
            String assocOrgUnitName = (String)newWebsiteDict.objectForKey(Website.ASSOC_UNIT_NAME);
            OrgUnit assocOrgUnit = OrgUnit.unitForUnitName(assocOrgUnitName, ec);

            String ownerID = (String)newWebsiteDict.objectForKey(Website.OWNER_ID_KEY);

            //TODO need to check for example site ID
// Commented out until batch creation is fixed
//            Website.createWebsite(websiteFromDictionary(newWebsiteDict),
//                                  assocOrgUnit,
//                                  ownerID,
//                                  ec);


        }
    }


    
    protected static Website websiteFromDictionary(NSDictionary dict) {
        String fileSizeQuota = (String)dict.objectForKey(Website.QUOTA_KEY);

        Website newWebsite = newWebsite();

        newWebsite.setSiteID((String)dict.objectForKey(Website.SITE_ID_KEY));
        try {
            newWebsite.setMegQuota(new Integer(fileSizeQuota));
        }
        catch (NumberFormatException e) {
            newWebsite.setMegQuota(new Integer(SMApplication.appProperties().intPropertyForKey("DefaultQuotaInMegabytes")));
        }

        // If the redirectURL is missing, the empty string is in the dictionary.  Don't set this into the website as it does not validate correctly.
        if ((dict.objectForKey(Website.REDIRECT_URL_KEY) != null) &&
             (((String)dict.objectForKey(Website.REDIRECT_URL_KEY)).length() > 0))
        {
            newWebsite.setRedirectURL((String)dict.objectForKey(Website.REDIRECT_URL_KEY));
        }

        return newWebsite;
    }


    
    /**
     * Searches for and returns the Website with a siteID of aSiteID.  Returns null if such a Website can not be found.
     *
     * @param aSiteID- Website siteID to search for
     * @param ec editing context to fetch Website in
     *
     * @return the corresponding Website, or null if not found.
     */
    public static Website websiteForSiteID(String aSiteID, EOEditingContext ec)
    {
        /** require [valid_siteID] aSiteID != null;  [valid_ec] ec != null;  **/

        DebugOut.println(15, " = = = = = Fetching Website with ID: " + aSiteID);

        EOQualifier qualifier = new EOKeyValueQualifier("siteID", EOQualifier.QualifierOperatorCaseInsensitiveLike, aSiteID);
        EOFetchSpecification fetchSpec = new EOFetchSpecification("Website", qualifier, null);
        NSArray siteResults = ec.objectsWithFetchSpecification(fetchSpec);

        if (siteResults.count() > 1)
        {
            throw new RuntimeException("Found multiple Websites with a siteID of " + aSiteID);
        }

        return (siteResults.count() == 0) ? null : (Website) siteResults.objectAtIndex(0);
    }



    /**
     * Returns a list of all published Websites, orderd by their banner text.
     *
     * @return a list of all published Websites, orderd by their banner text.
     */
    public static NSArray publishedWebsites(EOEditingContext ec)
    {
        NSArray sortOrdering = new NSArray(new EOSortOrdering ("banner.bannerText", EOSortOrdering.CompareCaseInsensitiveAscending));

        EOFetchSpecification fetchSpec = new EOFetchSpecification("Website", canBeDisplayedQualifier(), sortOrdering);
        NSArray publishedWebsites = ec.objectsWithFetchSpecification(fetchSpec);

        return publishedWebsites;
    }



    /**
     * Returns an <code>EOQualifier</code> that determines if a Website can be displayed.  This is the case if it is both marked as published by the Website's configuration group and has permission to be published from Website's administrator.  This should when fetching Websites for public display (as opposed to configuration or administration).  See also canBeDisplayed().
     *
     * @return an <code>EOQualifier</code> that determines if a Website can be displayed
     */
    static public EOQualifier canBeDisplayedQualifier()
    {
        return EOQualifier.qualifierWithQualifierFormat("published = 'Y' AND publicationPermitted = 'Y'", new NSArray());
    }

   
    
    /* *************** DELETEABLE INTERFACE ********** */
    public boolean canBeDeleted() {
        return (errorMessages() == null);
    }


    
    public NSArray errorMessages()
    {
        NSMutableArray errorArray = new NSMutableArray();

        // Don't allow a Website to be deleted if it contains one of the special groups (public or internal users).  At present this is only true for the Admin website.  If the design is ever changed so that these groups are removed from the Admin Website then this restriction can also be removed.
        Enumeration groupEnumerator = childGroups().objectEnumerator();
        while (groupEnumerator.hasMoreElements())
        {
            Group aGroup = (Group)groupEnumerator.nextElement();
            if (aGroup.isSystemGroup())
            {
                errorArray.addObject("Website contains special Access Group " + aGroup.name());
            }
        }

        // TODO check any conditions that need to be met before a website is deleted and add an error message to an NSArray for any that have not been satisfied.

        if (errorArray.count() < 1)
            errorArray = null;

        return errorArray;
    }


    /* *************** INSTANCE METHODS ************** */


    public void awakeFromInsertion(EOEditingContext ec)
    {
        super.awakeFromInsertion(ec);

        if (megQuota() == null)
        {
            setMegQuota(new Integer(SMApplication.appProperties().intPropertyForKey("DefaultQuotaInMegabytes")));
        }

        if (showBanner() == null)
        {
            setIsBannerVisible(true);
        }

        if (showNavbar() == null)
        {
            setIsNavbarVisible(true);
        }

        if (showFooter() == null)
        {
            setIsFooterVisible(true);
        }

        if (published() == null)
        {
            setIsPublished(true);
        }

        if (publicationPermitted() == null)
        {
            setHasPermissionToPublish(true);
        }

        if (canReplicate() == null)
        {
            setIsReplicable(false);
        }

        if (fileSizeUsage() == null)
        {
            setFileSizeUsage(new Integer(0));
        }

        if (sectionStyle() == null)
        {
            setSectionStyle(SectionStyle.defaultSectionStyle(ec));
        }

        if (dateLastModified() == null)
        {
            setDateLastModified(new NSTimestamp());
        }

        if (dateCreated() == null)
        {
            setDateCreated(new NSTimestamp());
        }
    }



    /**
     * Creates a new SiteFileFolder in this Website named folderName.  If parentFolder is not null the new folder is made a child of this folder.  Websites are not allowed to contain two folders with the same name at the root level or under a parent folder.
     *
     * @param parentFolder null if this is to be a root level folder, or the direct parent folder if this is a child folder.
     * @param folderName the name of the folder to be created.
     * @return the newly created SiteFileFolder
     */
    public SiteFileFolder createFolder(SiteFileFolder parentFolder, String folderName)
    {
        /** require
        [folder_name_not_null] folderName != null;
        [parent_folder_valid] (parentFolder == null) || (parentFolder.editingContext().equals(editingContext()));
         **/
        
        SiteFileFolder newFolder = SiteFileFolder.createFolder(editingContext(), parentFolder, folderName);
        addObjectToBothSidesOfRelationshipWithKey(newFolder, "folders");

        return newFolder;

        /** ensure
        [result_not_null] Result != null;
        [name_matches] Result.name().equals(folderName);
        [editing_context_matches] Result.editingContext().equals(editingContext());
        [parent_folder_matches] Result.parentFolder() == parentFolder; **/
    }



    /**
     * Returns the SiteFileFolder from this Website which is named aName.  If parentFolder is null, then only root level folders are checked for a matching name.  If parentFolder is not null, only that folder is checked for a matching name.  Folder names are not case sensitive.
     *
     * @param aName the name of the folder to search for
     * @return the named folder or null if it is not found.
     */
    public SiteFileFolder folderNamed(SiteFileFolder parentFolder, String aName)
    {
        return null;
    }



    /**
     * Returns true if this Website contains a folder named aName.  If parentFolder is null, then only root level folders are checked for a matching name.  If parentFolder is not null, only that folder is checked for a matching name.  Folder names are not case sensitive.
     *
     * @param aName the name of the folder to search for
     * @return true if this folder directly contains a folder named aName.
     */
    public boolean hasFolderNamed(SiteFileFolder parentFolder, String aName)
    {
        return false;
    }



    /**
     * Returns the root level folder for SiteFiles uploaded to this Website.
     *
     * @return the root level folder for SiteFiles uploaded to this Website.
     */
     public SiteFileFolder uploadedFilesFolder()
    {
         return null;

         /** ensure
         [result_not_null] Result != null;
         [resulting_name_correct] Result.name().equalsIgnoreCase(DEFAULT_UPLOADED_FILES_FOLDER_NAME); **/
    }



    /**
     * Returns the root level folder for SiteFiles uploaded to Database Tables in this Website.
     *
     * @return the root level folder for SiteFiles uploaded to Database Tables in this Website.
     */
    public SiteFileFolder databaseTablesFolder()
    {
        return null;

        /** ensure
        [result_not_null] Result != null;
        [resulting_name_correct] Result.name().equalsIgnoreCase(DEFAULT_DATABASE_TABLES_FOLDER_NAME); **/
    }



    /**
     * Returns folders() sorted by the folder name.
     */
    public NSArray foldersByName()
    {
        return NSArrayAdditions.sortedArrayUsingComparator(folders(), SiteFileFolder.NameComparator);

        /** ensure
        [result_not_null] Result != null;
        [correct_number_of_folders] Result.count() == folders().count(); **/
    }


    
    /**
     * Returns <code>true</code> if aSection is the home section of this website.
     * 
     * @param aSection the section to test to see if it is the home section.
     * @return <code>true</code> if aSection is the home section of this website
     */
    public boolean isHomeSection(Section aSection) {
        return orderedSections().objectAtIndex(0).equals(aSection);
    }
    
    
    
    /**
     * Creates a default home page for a new Website.  This allows the Website to be immediately viewable removing the need to have the owner configure it before viewing it.
     *
     * TODO: make this protected and call from awakeFromInsertion after refactoring to remove spurious saveChanges()
     */
    public void createDefaultHomeSection()
    {
        /** require [home_section_is_null] homeSection() == null; **/
        
        SectionType sectionType = TextImageSectionType.getInstance(editingContext());
        createHomeSectionOfType(sectionType);
        ((TextImageLayout)homeSection().component()).textComponent().setText("<div align=\"center\">Under Construction</div>");

        /** ensure
        [home_section_not_null] homeSection() != null;
        [home_section_type_correct] homeSection().type() instanceof TextImageSectionType;
        **/
    }



    /**
     * Creates a new home page for this Website of the specified type.
   