static int
_ascend_parse_ip_clause(struct ascend_parse_buf *pb)
{
	int n;

	if (_get_direction_type(pb, "ip", 1) == ASCEND_DIR_NONE) 
		return 0;
	n = _get_ip(pb);
	if (n == ASCEND_DIR_NONE)
		return 1;
	if (_get_direction_type(pb, "ip", 1) != ASCEND_DIR_NONE) {
		int n1 = _get_ip(pb);
		if (n1 == n) {
			ascend_errprint(pb,
					_("Duplicate IP specification"), NULL);
			return 1;
		}
	}
	return 0;
}

static int
_get_op(struct ascend_parse_buf *pb)
{
	char *s = _get_token(pb, 1);
	if (!s)
		return ascend_cmp_none;
	switch (s[0]) {
	case '>':
		return ascend_cmp_gt;
	case '<':
		return ascend_cmp_lt;
	case '=':
		return ascend_cmp_eq;
	case '!':
		if (s[1] == '=')
			return ascend_cmp_ne;
	}
	ascend_errprint(pb, _("Invalid operation"), s);
	return ascend_cmp_none;
}

static int
_get_port(struct ascend_parse_buf *pb)
{
	int dir = _get_direction_type(pb, "port", 0);
	char *tok;
	char *p;
	int num;
	int op;
	
	if (dir == ASCEND_DIR_NONE)
		return ASCEND_DIR_NONE;

	if ((op = _get_op(pb)) == ascend_cmp_none)
		return ASCEND_DIR_NONE;

	tok = _get_token(pb, 1);
	if (!tok)
		return ASCEND_DIR_NONE;
	
	num = strtoul(tok, &p, 0);
	if (*p == 0) 
		num = htons(num);
	else {
		struct servent *sp;
		struct protoent *pp = getprotobynumber(pb->flt->v.ip.proto);

		if (!pp) {
			/* Shouldn't happen */
			ascend_errprint(pb,
				      _("Cannot map back the protocol number"),
				      NULL);
			return ASCEND_DIR_NONE;
		}
		sp = getservbyname(tok, pp->p_name);
		if (!sp) {
			ascend_errprint(pb, _("Unknown service"), tok);
			return 1;
		}
		num = sp->s_port;
	}

	switch (dir) {
	case ASCEND_DIR_SRC:
		pb->flt->v.ip.src_port = num;
		pb->flt->v.ip.src_cmp = op;
		break;
		
	case ASCEND_DIR_DST:
		pb->flt->v.ip.dst_port = num;
		pb->flt->v.ip.dst_cmp = op;
		break;
	}

	return dir;
}

/* Return value:
   0 - No port specification found
   1 - Port specification is found and processed
   -1 - Parse error pb->errmsg *might* contain diagnostics */
static int
_ascend_parse_port_clause(struct ascend_parse_buf *pb)
{
	int n;
	
	if (_get_direction_type(pb, "port", 1) == ASCEND_DIR_NONE)
		return 0;
	
	n = _get_port(pb);

	if (n == ASCEND_DIR_NONE)
		return -1;
	if (_get_direction_type(pb, "port", 1) != ASCEND_DIR_NONE) {
		int n1 = _get_port(pb);
		if (n1 == ASCEND_DIR_NONE)
			return -1;
		if (n1 == n) {
			ascend_errprint(pb,
					_("Duplicate port specification"),
					NULL);
			return -1;
		}
	}
	return 1;
}

/* IP filter specification is

   "ip" dir action [ "dstip" IP "/" NUM] [ "srcip" IP "/" NUM ]
   	        [ PROTO [ "dstport" cmp PORT ] [ "srcport" cmp PORT ]
                [ "est" ] ]

   where dir    is {"in"|"out"}
         action is {"forward"|"drop"}
	 cmp    is {">"|"<"|"="|"!="}
	 IP     is IP address in dotted-quad
	 NUM    is the decimal number, 0 <= NUM <= 32.
	 PROTO  is either the protocol number or its name from /etc/protocols
	 PORT   is either the port number or its name from /etc/services */

static int
_ascend_parse_ip(struct ascend_parse_buf *pb)
{
	if (!_moreinput(pb))
		return 0;
	
	if (_ascend_parse_ip_clause(pb))
		return 1;
	
	if (_moreinput(pb)) {
		if (_get_protocol(pb))
			return 1;
		if (_moreinput(pb)) {
			char *tok;
			int have_port = _ascend_parse_port_clause(pb);
			if (have_port == -1)
				return 1;
			tok = _get_token(pb, 0);
			if (!tok)
				return 0;
			if (strcmp(tok, "est") == 0)
				pb->flt->v.ip.established = 1;
			else {
				ascend_errprints(pb,
					 have_port ?
					 _("Expected `est' but found `%s'") :
					 _("Expected `{src|dst}port' or `est', but found `%s'"),
					 tok);
				return 1;
			}
		}
	}
	return 0;
}

/* ************************************************************************* */
/* IPX filter parsing */

/* IPX filter is:

   "ipx" dir action [ "srcipxnet" NETADDR "srcipxnode" NODE
                     [ "srcipxsoc" cmp HEXNUM ]]
                    [ "dstipxnet" NETADDR "dstipxnode" NODE
  		     [ "dstipxsoc" cmp HEXNUM ]] */
static int
_ascend_parse_ipx(struct ascend_parse_buf *pb)
{
	ascend_errprint(pb, "IPX filters are not yet supported", NULL);
	return 1;
}
 
static int
_ascend_parse(struct ascend_parse_buf *pb)
{
	memset(pb->flt, 0, sizeof(pb->flt[0]));
	
	if (_get_type(pb)
	    || _get_dir(pb)
	    || _get_action(pb))
		return 1;
	switch (pb->flt->type) {
	case ascend_filter_generic:
		return _ascend_parse_generic(pb);
	case ascend_filter_ip:
		return _ascend_parse_ip(pb);
	case ascend_filter_ipx:
		return _ascend_parse_ipx(pb);
	}
	return 1;
}

/* Parse a single ascend filter specification.
   Return 0 and fill flt[0] if the specification is correct.
   Return !0 and return diagnostics in errp otherwise.
   NOTE: errp is malloced and should be freed using usual free() */
static int
_ascend_parse_filter(const char *input, ASCEND_FILTER *flt, char **errp)
{
	struct ascend_parse_buf pb;
	int rc;

	*errp = NULL;
	if (grad_argcv_get(input, "/", NULL, &pb.tokc, &pb.tokv)) {
		grad_argcv_free(pb.tokc, pb.tokv);
		ascend_errprint(&pb, _("Failed to tokenize"), NULL);
		return 1;
	}

	pb.tokn = 0;
	pb.flt = flt;
	pb.errmsg = errp;
	rc = _ascend_parse(&pb);
	grad_argcv_free(pb.tokc, pb.tokv);
	if (rc && !*errp) 
		ascend_errprint(&pb, _("Malformed attribute value"), NULL);
	return rc;
}

int
grad_ascend_parse_filter(grad_avp_t *pair, char **errp)
{
	ASCEND_FILTER flt;
	
	if (_ascend_parse_filter(pair->avp_strvalue, &flt, errp)) 
		return 1;
	grad_free(pair->avp_strvalue);
	pair->avp_strlength = sizeof(flt);
	pair->avp_strvalue = grad_emalloc(pair->avp_strlength);
	memcpy(pair->avp_strvalue, &flt, sizeof(flt));
	return 0;
}

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>

#include <stdio.h>
#include <stdlib.h>
#include <netdb.h>
#include <pwd.h>
#include <ctype.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <pwd.h>
#include <grp.h>
#include <radlib.h>

/* Memory allocation interface */

grad_avp_t *
grad_avp_alloc()
{
        return grad_emalloc(sizeof(grad_avp_t));
}

void
grad_avp_free(grad_avp_t *p)
{
        if (!p)
                return;
        if (p->type == GRAD_TYPE_STRING || p->eval_type != grad_eval_const) 
                grad_free(p->avp_strvalue);
        grad_free(p);
}

/* A/V pair functions */

/* Create a copy of a pair */
grad_avp_t *
grad_avp_dup(grad_avp_t *vp)
{
        grad_avp_t *ret = grad_avp_alloc();

        memcpy(ret, vp, sizeof(grad_avp_t));
        ret->next = NULL;
        if (ret->type == GRAD_TYPE_STRING || ret->eval_type != grad_eval_const) {
		ret->avp_strlength = vp->avp_strlength;
                ret->avp_strvalue = grad_emalloc(ret->avp_strlength+1);
		memcpy(ret->avp_strvalue, vp->avp_strvalue,
		       ret->avp_strlength);
		ret->avp_strvalue[ret->avp_strlength] = 0;
	}
        return ret;
}

/* Create a pair with given attribute */
grad_avp_t *
grad_avp_create(int attr)
{
        grad_avp_t *pair;
        grad_dict_attr_t  *dict;

        dict = grad_attr_number_to_dict(attr);
        if (!dict) {
                grad_log(L_ERR,
                         _("make_pair(): attribute %d not found in dictionary"),
                         attr);
                return NULL;
        }
        pair = grad_avp_alloc();
        pair->name = dict->name;
        pair->attribute = attr;
        pair->type = dict->type;
        pair->prop = dict->prop;
	return pair;
}

grad_avp_t *
grad_avp_create_integer(int attr, grad_uint32_t value)
{
	grad_avp_t *pair = grad_avp_create(attr);

	if (pair) 
		pair->avp_lvalue = value;
	return pair;
}

grad_avp_t *
grad_avp_create_string(int attr, char *value)
{
	grad_avp_t *pair = grad_avp_create(attr);
	if (pair) {
		pair->avp_strvalue = grad_estrdup(value);
                pair->avp_strlength = strlen(value);
	}
	return pair;
}

grad_avp_t *
grad_avp_create_binary(int attr, int length, u_char *value)
{
	grad_avp_t *pair = grad_avp_create(attr);
	if (pair) {
                pair->avp_strlength = length;
                pair->avp_strvalue = grad_emalloc(length + 1);
		memcpy(pair->avp_strvalue, value, length);
		pair->avp_strvalue[length] = 0;
	}
	return pair;
}

/* Add a pair to the end of a grad_avp_t list. */
grad_avp_t *
grad_avp_move(grad_avp_t **first, grad_avp_t *new)
{
        grad_avp_t *pair, *prev = NULL;

        if (*first == NULL) {
                new->next = NULL;
                *first = new;
                return 0;
        }

        switch (GRAD_GET_ADDITIVITY(new->prop)) {
        case GRAD_AP_ADD_NONE:
                for (pair = *first; pair; prev = pair, pair = pair->next)
                        if (pair->attribute == new->attribute)
                                return new;
                prev->next = new;
                new->next = NULL;
                return NULL;

        case GRAD_AP_ADD_REPLACE:
                if ((*first)->attribute == new->attribute) {
                        prev = *first;
                        new->next = prev->next;
                        *first = new;
                        grad_avp_free(prev);
                        return NULL;
                }
                for (pair = *first; pair; prev = pair, pair = pair->next)
                        if (pair->attribute == new->attribute) {
                                new->next = pair->next;
                                prev->next = new;
                                grad_avp_free(pair);
                                return NULL;
                        }
                new->next = NULL;
                prev->next = new;
                return NULL;

        case GRAD_AP_ADD_APPEND:
                for (pair = *first; pair->next; pair = pair->next)
                        ;
                new->next = NULL;
                pair->next = new;
                return NULL;
        }
        return new;
}

int
grad_avp_cmp(grad_avp_t *a, grad_avp_t *b)
{
	int rc = 1;
	
	if (a->attribute != b->attribute || a->type != b->type)
		return 1;
	
	switch (a->type) {
	case GRAD_TYPE_STRING:
		if (a->avp_strlength != b->avp_strlength)
			rc = 1;
		else
			rc = memcmp(a->avp_strvalue, b->avp_strvalue, 
                                    a->avp_strlength);
		break;

	case GRAD_TYPE_INTEGER:
	case GRAD_TYPE_IPADDR:
		rc = a->avp_lvalue != b->avp_lvalue;
		break;
	}
	return rc;
}

int
grad_avp_null_string_p(grad_avp_t *pair)
{
	if (!pair)
		return 1;
	if (pair->type != GRAD_TYPE_STRING)
		return 1;
	return strlen(pair->avp_strvalue) == 0;
}

/* A/V pairlist functions */

/* Release the memory used by a list of attribute-value pairs.
 */
void 
grad_avl_free(grad_avp_t *pair)
{
        grad_avp_t *next;

        while (pair != NULL) {
                next = pair->next;
                grad_avp_free(pair);
                pair = next;
        }
}


/* Find the pair with the matching attribute
 */
grad_avp_t * 
grad_avl_find(grad_avp_t *first, int attr)
{
        while (first && first->attribute != attr)
                first = first->next;
        return first;
}

/* Find nth occurrence of a pair with the matching attribute. */
grad_avp_t * 
grad_avl_find_n(grad_avp_t *first, int attr,	int n)
{
	for ( ; first; first = first->next) {
		if (first->attribute == attr && n-- == 0)
			break;
	}
	return first;
}

/* Delete the pairs with the matching attribute
 */
void 
grad_avl_delete(grad_avp_t **first, int attr)
{
        grad_avp_t *pair, *next, *last = NULL;

        for (pair = *first; pair; pair = next) {
                next = pair->next;
                if (pair->attribute == attr) {
                        if (last)
                                last->next = next;
                        else
                                *first = next;
                        grad_avp_free(pair);
                } else
                        last = pair;
        }
}

/* Delete Nth pair with the matching attribute */
void 
grad_avl_delete_n(grad_avp_t **first, int attr, int n)
{
	grad_avp_t *pair, *next, *last = NULL;

	for (pair = *first; pair; pair = next) {
		next = pair->next;
		if (pair->attribute == attr && n-- == 0) {
			if (last)
				last->next = next;
			else
				*first = next;
			grad_avp_free(pair);
			break;
		} else
			last = pair;
	}
}


/* Move all attributes of a given type from one list to another */
void
grad_avl_move_pairs(grad_avp_t **to,
		    grad_avp_t **from,
		    int (*fun)(void *, grad_avp_t *),
		    void *closure)
{
        grad_avp_t *to_tail, *i, *next;
        grad_avp_t *iprev = NULL;

        /*
         *      Find the last pair in the "to" list and put it in "to_tail".
         */
        if (*to != NULL) {
                to_tail = *to;
                for(i = *to; i; i = i->next)
                        to_tail = i;
        } else
                to_tail = NULL;

        for(i = *from; i; i = next) {
                next = i->next;

                if ((*fun)(closure, i) == 0) {
                        iprev = i;
                        continue;
                }

                /*
                 *      Remove the attribute from the "from" list.
                 */
                if (iprev)
                        iprev->next = next;
                else
                        *from = next;

                /*
                 *      Add the attribute to the "to" list.
                 */
                if (to_tail)
                        to_tail->next = i;
                else
                        *to = i;
                to_tail = i;
                i->next = NULL;
        }
}

static int
cmp_attr(void *data, grad_avp_t *pair)
{
	int *valp = data; 
        return *valp == pair->attribute;
}

/* Move all attributes of a given type from one list to another */
void
grad_avl_move_attr(grad_avp_t **to, grad_avp_t **from, int attr)
{
        grad_avl_move_pairs(to, from, cmp_attr, &attr);
}

/* Move attributes from one list to the other honoring their additivity 
 */
void
grad_avl_merge(grad_avp_t **dst_ptr, grad_avp_t **src_ptr)
{
        grad_avp_t *src, *next, *src_head, *src_tail;

        if (*dst_ptr == NULL) {
                *dst_ptr = *src_ptr;
                *src_ptr = NULL;
                return;
        }

        src_head = src_tail = NULL;
        src = *src_ptr;
        while (src) {
                next = src->next;
                src = grad_avp_move(dst_ptr, src);
                if (src) {
                        if (src_tail)
                                src_tail->next = src;
                        else
                                src_head = src;
                        src_tail = src;
                }
                src = next;
        }
        *src_ptr = src_head;
}

/* Append the list `new' to the end of the list `*first' */
void
grad_avl_add_list(grad_avp_t **first, grad_avp_t *new)
{
        grad_avp_t *pair;
        
        if (*first == NULL) {
                *first = new;
                return;
        }
        for (pair = *first; pair->next; pair = pair->next)
                ;
        pair->next = new;
}

/* Add a single pair to the list */
void
grad_avl_add_pair(grad_avp_t **first, grad_avp_t *new)
{
        if (!new)
                return;
        new->next = NULL;
        grad_avl_add_list(first, new);
}


/* Create a copy of a pair list. */
grad_avp_t *
grad_avl_dup(grad_avp_t *from)
{
        grad_avp_t *first = NULL;
        grad_avp_t *last = NULL;
        grad_avp_t *temp;

        for ( ; from; from = from->next) {
                temp = grad_avp_alloc();
                memcpy(temp, from, sizeof(grad_avp_t));
                if (temp->type == GRAD_TYPE_STRING || temp->eval_type != grad_eval_const) {
			char *p = grad_emalloc(temp->avp_strlength+1);
			memcpy(p, temp->avp_strvalue, temp->avp_strlength);
			p[temp->avp_strlength] = 0;
			temp->avp_strvalue = p;
		}
                temp->next = NULL;
                if (last)
                        last->next = temp;
                else
                        first = temp;
                last = temp;
        }

        return first;
}

/* write a pairlist to the file */
void
grad_avl_fprint(FILE *fp, char *prefix, int typeflag, grad_avp_t *avl)
{
        char *save;
	if (!prefix)
		prefix = "";
        for (;avl; avl = avl->next) {
                fprintf(fp, "%s%s\n", prefix,
			grad_format_pair(avl, typeflag, &save));
                free(save);
        }
}

int
grad_avl_cmp(grad_avp_t *a, grad_avp_t *b, int prop)
{
	int cmp_count = 0;
	
	for (; a; a = a->next) {
		if (a->prop & prop) {
			grad_avp_t *p = grad_avl_find(b, a->attribute);
			if (!p || grad_avp_cmp(a, p))
				return 1;
			cmp_count++;
		}
	}
	return cmp_count == 0;
}

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <ctype.h>

#include <radlib.h>

void
grad_client_random_authenticator(char *authenticator)
{
        int randno;
        int i;

        for (i = 0; i < GRAD_AUTHENTICATOR_LENGTH; ) {
                randno = rand();
                memcpy(authenticator, &randno, sizeof(int));
                authenticator += sizeof(int);
                i += sizeof(int);
        }
}

#define PERM S_IRUSR|S_IWUSR|S_IROTH|S_IRGRP

unsigned
grad_client_message_id(grad_server_t *server)
{
	grad_server_id_t sid;
	int fd;
	unsigned id;
	
	fd = open(grad_msgid_file, O_RDWR|O_CREAT, PERM);
	if (fd != -1) {
		struct stat st;
		
		fstat(fd, &st);
		if (server->id_offset != (off_t) -1
		    && server->id_offset + sizeof(sid) <= st.st_size) {
			grad_lock_file(fd, sizeof(sid),
				       server->id_offset, SEEK_SET);
			lseek(fd, server->id_offset, SEEK_SET);
			read(fd, &sid, sizeof(sid));
			id = sid.id++;
			lseek(fd, server->id_offset, SEEK_SET);
			write(fd, &sid, sizeof(sid));
			grad_unlock_file(fd, sizeof(sid),
					 server->id_offset, SEEK_SET);

		} else {
			off_t off = 0;
			lseek(fd, 0, SEEK_SET);
			grad_lock_file(fd, st.st_size + sizeof(sid),
				       0, SEEK_SET);
			while (read(fd, &sid, sizeof(sid)) == sizeof(sid)) {
				if (sid.addr == server->addr) {
					id = sid.id++;
					lseek(fd, off, SEEK_SET);
					write(fd, &sid, sizeof(sid));
					break;
				}
				off += sizeof(sid);
			}
			if (off == st.st_size) {
				/* Entry not found. */
				sid.addr = server->addr;
				sid.id = 1;
				write(fd, &sid, sizeof(sid));
				server->id_offset = off;
				id = 0;
			} 
			grad_unlock_file(fd, st.st_size + sizeof(sid),
					 0, SEEK_SET);
		}
		close(fd);
	} else {
		id = random() % 256;
	}
	return id;
}
	
grad_request_t *
grad_client_recv(grad_uint32_t host, u_short udp_port, char *secret,
		 char *authenticator, char *buffer, int length)
{
        grad_packet_header_t *auth;
        int totallen;
        u_char reply_digest[GRAD_AUTHENTICATOR_LENGTH];
        u_char calc_digest[GRAD_AUTHENTICATOR_LENGTH];
        int  secretlen;
	grad_request_t *req;
	
        auth = (grad_packet_header_t *)buffer;
        totallen = ntohs(auth->length);

        if (totallen != length) {
                grad_log(L_ERR,
           _("Actual request length does not match reported length (%d, %d)"),
                         totallen, length);
                return NULL;
        }

        /* Verify the reply digest */
        secretlen = strlen(secret);
        memcpy(reply_digest, auth->authenticator, GRAD_AUTHENTICATOR_LENGTH);
        memcpy(auth->authenticator, authenticator, GRAD_AUTHENTICATOR_LENGTH);
        memcpy(buffer + length, secret, secretlen);
        grad_md5_calc(calc_digest, (unsigned char *)auth, length + secretlen);
        
	GRAD_DEBUG1(1, "received %s", grad_request_code_to_name(auth->code));
        if (memcmp(reply_digest, calc_digest, GRAD_AUTHENTICATOR_LENGTH) != 0) {
                grad_log(L_WARN, _("Received invalid reply digest from server"));
        }

        req = grad_decode_pdu(host, udp_port, buffer, length);
	req->secret = secret;
		
	return req;
}

grad_avp_t *
grad_client_encrypt_pairlist(grad_avp_t *plist, u_char *authenticator, u_char *secret)
{
	grad_avp_t *p;
	
	for (p = plist; p; p = p->next) {
		if (p->prop & GRAD_AP_ENCRYPT_RFC2138) {
			char *pass = p->avp_strvalue;
			grad_encrypt_password(p, pass, authenticator, secret);
			grad_free(pass);
		} else if (p->prop & GRAD_AP_ENCRYPT_RFC2868) {
			char *pass = p->avp_strvalue;
			grad_encrypt_tunnel_password(p, 0, pass,
						     authenticator, secret);
			grad_free(pass);
		}
	}
	return plist;
}	

grad_avp_t *
grad_client_decrypt_pairlist(grad_avp_t *plist, u_char *authenticator, u_char *secret)
{
	grad_avp_t *p;
	char password[GRAD_STRING_LENGTH+1];
	
	for (p = plist; p; p = p->next) {
		if (p->prop & GRAD_AP_ENCRYPT_RFC2138) {
			grad_decrypt_password(password, p, authenticator, secret);
			grad_free(p->avp_strvalue);
			p->avp_strvalue = grad_estrdup(password);
			p->avp_strlength = strlen(p->avp_strvalue);
		} else if (p->prop & GRAD_AP_ENCRYPT_RFC2868) {
			u_char tag;
			
			grad_decrypt_tunnel_password(password,
						     &tag,
						     p,
						     authenticator,
						     secret);
			grad_free(p->avp_strvalue);
			p->avp_strvalue = grad_estrdup(password);
			p->avp_strlength = strlen(p->avp_strvalue);
		}
	}
	return plist;
}


grad_request_t *
grad_client_send0(grad_server_queue_t *config, int port_type, int code,
		  grad_avp_t *pairlist,
		  int flags,
		  int *authid, u_char *authvec)
{
	struct sockaddr salocal;
	struct sockaddr saremote;
	struct sockaddr_in *sin;
        int local_port;
        int sockfd;
        int salen;
        int i;
        grad_request_t *req = NULL;
        grad_server_t *server;
        char ipbuf[GRAD_IPV4_STRING_LENGTH];
	char *recv_buf;
	grad_iterator_t *itr;
	int id;
	
        if (port_type < 0 || port_type > 2) {
                grad_log(L_ERR, _("invalid port type"));
                return NULL;
        }
        sockfd = socket(PF_INET, SOCK_DGRAM, 0);
        if (sockfd < 0) {
                grad_log(L_ERR|L_PERROR, "socket");
                return NULL;
        }

        sin = (struct sockaddr_in *) &salocal;
        memset (sin, 0, sizeof (salocal));
        sin->sin_family = AF_INET;
        sin->sin_addr.s_addr = config->source_ip ?
                                   htonl(config->source_ip) : INADDR_ANY;

	/*FIXME: not necessary?*/
        local_port = 1025;
        do {
                local_port++;
                sin->sin_port = htons((u_short)local_port);
        } while ((bind(sockfd, &salocal, sizeof (struct sockaddr_in)) < 0)
		 && local_port < 65535);
        if (local_port >= 65535) {
                grad_log(L_ERR|L_PERROR, "bind");
                close(sockfd);
                return NULL;
        }

	GRAD_DEBUG1(1, "sending %s", grad_request_code_to_name(code));
	recv_buf = grad_emalloc(config->buffer_size);
        itr = grad_iterator_create(config->servers);
        server = grad_iterator_first(itr);
        do {
		fd_set readfds;
		struct timeval tm;
		int result;
		u_char authenticator[GRAD_AUTHENTICATOR_LENGTH];
		void *pdu;
		size_t size;
		grad_avp_t *pair;

                if (server->port[port_type] <= 0)
                        continue;
                
                GRAD_DEBUG2(10, "server %s:%d",
                                 grad_ip_iptostr(server->addr, ipbuf),
                                 server->port[port_type]);

                if (authid && (flags & RADCLT_AUTHENTICATOR))
			memcpy(authenticator, authvec, sizeof authenticator);
		else
			grad_client_random_authenticator(authenticator);
		if (authid && (flags & RADCLT_ID))
			id = *authid;
		else
			id = grad_client_message_id(server);
		pair = grad_client_encrypt_pairlist(grad_avl_dup(pairlist),
						    authenticator, server->secret);
		size = grad_create_pdu(&pdu, code,
				       id,
				       authenticator,
				       server->secret,
				       pair,
				       NULL);
		if (authid && !(flags & RADCLT_ID))
			*authid = id;
		if (authvec && !(flags & RADCLT_AUTHENTICATOR))
			memcpy(authvec, authenticator, sizeof authenticator);
		
