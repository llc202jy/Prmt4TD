/*
 * GroupPac - Copyright (C) 2000-2002 LCMI
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
package edu.lcmi.grouppac.ns;

/*
 * Original copyright notice:
 *
 *        JacORB - a free Java ORB
 *
 *   Copyright (C) 1997-2001  Gerald Brose.
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Library General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

import org.omg.CosNaming.Binding;
import org.omg.CosNaming.BindingIteratorPOA;
import org.omg.CosNaming.BindingListHolder;
	}

	/**
	 * @see org.omg.CosNaming.BindingIteratorOperations#next_one(BindingHolder)
	 */
	public boolean next_one(org.omg.CosNaming.BindingHolder b) {
		if (iterator_pos < bindings.length) {
			b.value = bindings[iterator_pos++];

			return true;
		} else {
			b.value = new Binding(new NameComponent[0], BindingType.nobject);

			return false;
		}
	}
}/*
 * GroupPac - Copyright (C) 2000-2002 LCMI
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
package edu.lcmi.grouppac.ns;

/*
 * Original copyright notice:
 *
 *        JacORB - a free Java ORB
 *
 *   Copyright (C) 1997-2001  Gerald Brose.
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Library General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

import java.io.Serializable;
import java.util.Vector;

import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextPackage.InvalidName;

/**
 * A convenience class for names and converting between Names and their string representation.
 * 
 * @version $Revision: 1.11 $
 * @author Gerald Brose, FU Berlin
 * @author <a href="mailto:padilha@das.ufsc.br">Ricardo Sangoi Padilha</a>, <a
 *         href="http://www.das.ufsc.br/">UFSC, Florian?polis, SC, Brazil</a>
 */
public class Name implements Serializable {

	private NameComponent baseName;
	/** context part of this Name */
	private NameComponent[] ctxName;
	private NameComponent[] fullName;

	/**
	 * Creates a new Name object.
	 */
	public Name() {
		fullName = null;
		baseName = null;
		ctxName = null;
	}

	/**
	 * create a name from an array of NameComponents
	 * 
	 * @param n n
	 * @throws InvalidName
	 */
	public Name(NameComponent[] n) throws InvalidName {
		if ((n == null) || (n.length == 0))
			throw new InvalidName();

		fullName = n;
		baseName = n[n.length - 1];
		if (n.length > 1) {
			ctxName = new NameComponent[n.length - 1];
			for (int i = 0; i < (n.length - 1); i++)
				ctxName[i] = n[i];
		} else
			ctxName = null;
	}

	/**
	 * create a name from a stringified name
	 * 
	 * @param string_name structured_name
	 * @exception InvalidName if string_name is in some way invalid
	 */
	public Name(String string_name) throws InvalidName {
		this(toName(string_name));
	}

	/**
	 * create a name from a singleNameComponent
	 * 
	 * @param n n
	 * @exception InvalidName if n is <code>null</code>
	 */
	public Name(NameComponent n) throws InvalidName {
		if (n == null)
			throw new InvalidName();

		baseName = n;
		fullName = new NameComponent[1];
		fullName[0] = n;
		ctxName = null;
	}

	/**
	 * @param sn
	 * @return an a array of NameComponents
	 * @exception InvalidName if sn starts with "/"
	 */
	public static NameComponent[] toName(String sn) throws InvalidName {
		if (sn.startsWith("/"))
			throw new InvalidName();
		Vector v = new Vector();
		int start = 0;
		int i = 0;
		for (; i < sn.length(); i++) {
			if ((sn.charAt(i) == '/') && (sn.charAt(i - 1) != '\\')) {
				if ((i - start) == 0)
					throw new InvalidName();

				v.addElement(getComponent(sn.substring(start, i)));
				start = i + 1;
			}
		}
		if (start < i)
			v.addElement(getComponent(sn.substring(start, i)));
		NameComponent[] result = new NameComponent[v.size()];
		for (int j = 0; j < result.length; j++)
			result[j] = (NameComponent) v.elementAt(j);

		return result;
	}

	/**
	 * @param n
	 * @return the string representation of this NameComponent array
	 * @exception InvalidName if n is <code>null</code> or empty
	 */
	public static String toString(NameComponent[] n) throws InvalidName {
		if ((n == null) || (n.length == 0))
			throw new InvalidName();
		StringBuffer b = new StringBuffer();
		for (int i = 0; i < n.length; i++) {
			if (i > 0)
				b.append("/");
			if (n[i].id.length() > 0)
				b.append(escape(n[i].id));
			if ((n[i].kind.length() > 0) || (n[i].id.length() == 0))
				b.append(".");
			if (n[i].kind.length() > 0)
				b.append(escape(n[i].kind));
		}
		return b.toString();
	}

	/**
	 * @return a NameComponent object representing the unstructured base name of this structured
	 *         name
	 */
	public NameComponent baseNameComponent() {
		return baseName;
	}

	/**
	 * @return this name as an array of org.omg.CosNaming.NameComponent, neccessary for a number of
	 *         operations on naming context
	 */
	public NameComponent[] components() {
		return fullName;
	}

	/**
	 * @return a Name object representing the name of the enclosing context
	 */
	public Name ctxName() {
		// null if no further context
		if (ctxName != null) {
			try {
				return new Name(ctxName);
			} catch (InvalidName in) {
				in.printStackTrace();

				return null;
			}
		} else
			return null;
	}

	/**
	 * @param obj
	 * @return equality based on string representation
	 */
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (!(obj instanceof Name))
			return false;

		return (toString().equals(obj.toString()));
	}

	/**
	 * Description
	 * 
	 * @return Name
	 * @throws InvalidName
	 */
	public Name fullName() throws InvalidName {
		return new Name(fullName);
	}

	/**
	 * @return hash code of the string representation
	 */
	public int hashCode() {
		return toString().hashCode();
	}

	/**
	 * @return kind of base name
	 */
	public String kind() {
		return baseName.kind;
	}

	/**
	 * @return the string representation of this name
	 */
	public String toString() {
		try {
			return toString(fullName);
		} catch (InvalidName in) {
			return "<invalid>";
		}
	}

	/**
	 * @param sn
	 * @return a single NameComponent, parsed from sn
	 * @throws InvalidName
	 */
	private static NameComponent getComponent(String sn) throws InvalidName {
		NameComponent result = new NameComponent("", "");
		int start = 0;
		for (int i = 0; i < sn.length(); i++) {
			if (sn.charAt(i) == '.') {
				if ((i == (sn.length() - 1)) && (i > 0))
					throw new InvalidName();
				if ((i > 0) && (sn.charAt(i - 1) != '\\')) {
					/* not an escaped dot */
					if (start < i)
						result.id = sn.substring(start, i);
					if (i < sn.length())
						result.kind = sn.substring(i + 1);

					return result;
				} else {
					/* leading '.' */
					if (i < sn.length())
						result.kind = sn.substring(i + 1);

					return result;
				}
			}
		}
		/* no dot found */
		result.id = sn;
		return result;
	}

	/**
	 * @param s
	 * @return a string escaped in any occurrence of "/", "." and "\"
	 */
	private static String escape(String s) {
		StringBuffer sb = new StringBuffer(s);
		for (int i = 0; i < sb.length(); i++) {
			if ((sb.charAt(i) == '/') || (sb.charAt(i) == '\\') || (sb.charAt(i) == '.')) {
				sb.insert(i, '\\');
				i++;
			}
		}
		return sb.toString();
	}
}/*
 * GroupPac - Copyright (C) 2000-2002 LCMI
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
package edu.lcmi.grouppac.gui;

import javax.swing.JOptionPane;

import org.omg.CosNaming.NameComponent;

/**
 * Removes a replica from a group, if it's application controlled membership.  Creation date:
 * (08/04/2002 11:39:47)
 * 
 * @version $Revision: 1.3 $
 * @author <a href="mailto:padilha@das.ufsc.br">Ricardo Sangoi Padilha</a>, <a
 *         href="http://www.das.ufsc.br/">UFSC, Florian?polis, SC, Brazil</a>
 */
public class DeleteMemberAction extends AbstractGroupPacAction {
	private JFTAdmin2 admin;

	/**
	 * Creates a new DeleteMemberAction object.
	 * 
	 * @param admin
	 */
	public DeleteMemberAction(JFTAdmin2 admin) {
		super("Remove...", null, 'r', null, "Remove a replica from the application-controlled membership group");
		this.admin = admin;
	}

	/**
	 * @see AbstractGroupPacAction#execute()
	 */
	public void execute() throws Exception {
		int selected = admin.getJListGroupKnown().getSelectedIndex();
		NameComponent[] nc = (NameComponent[]) admin.getGroupList().get(selected);
		int selected_member = admin.getJListMemberKnown().getSelectedIndex();
		NameComponent[] location = (NameComponent[]) admin.getMemberList().get(selected_member);
		org.omg.CORBA.Object group = getNS().resolve(nc);
		Object[] o = { "Do you really want to remove the replica at:", location[0].id };
		int result =
			JOptionPane.showConfirmDialog(admin, o, "Remove replica", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		if (result == JOptionPane.YES_OPTION) {
			admin.getRM().remove_member(group, location);
			new RefreshMembersAction(admin).execute();
		}
	}
}/*
 * GroupPac - Copyright (C) 2000-2002 LCMI
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
package edu.lcmi.grouppac.gui;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.border.EtchedBorder;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellEditor;
import javax.swing.tree.DefaultTreeCellRenderer;

import org.omg.CORBA.FT.CONS_APP_CTRL;
import org.omg.CORBA.FT.MEMB;
import org.omg.CORBA.FT.MEMB_APP_CTRL;
import org.omg.CORBA.FT.NOT_MONITORED;
import org.omg.CORBA.FT.STATELESS;

/**
 * A tree node for displaying FT CORBA properties.  Creation date : (24/02/2002 01:28:41)
 * 
 * @version $Revision: 1.5 $
 * @author <a href="mailto:padilha@das.ufsc.br">Ricardo Sangoi Padilha</a>, <a
 *         href="http://www.das.ufsc.br/">UFSC, Florian?polis, SC, Brazil</a>
 */
public class GPTreeNode extends DefaultMutableTreeNode {

	public static class Editor extends DefaultTreeCellEditor {
		private Holder active;
		private JTextField editor;
		private JLabel label;
		private JPanel panel;

		/**
		 * Creates a new Editor object.
		 * 
		 * @param tree
		 */
		public Editor(JTree tree) {
			super(tree, (DefaultTreeCellRenderer) tree.getCellRenderer());
			init();
		}

		/**
		 * @see javax.swing.CellEditor#getCellEditorValue()
		 */
		public Object getCellEditorValue() {
			if (active != null) {
				String ret = active.label + ": " + editor.getText();
				active = null;

				return ret;
			} else
				return editor.getText();
		}

		/**
		 * @see javax.swing.tree.TreeCellEditor#getTreeCellEditorComponent(JTree, Object, boolean, boolean, boolean, int)
		 */
		public Component getTreeCellEditorComponent(
			JTree tree,
			Object value,
			boolean isSelected,
			boolean expanded,
			boolean leaf,
			int row) {
			Component ret;
			if (value instanceof GPTreeNode) {
				GPTreeNode node = (GPTreeNode) value;
				if (node.getUserObject() instanceof Holder) {
					active = (Holder) node.getUserObject();
					label.setFont(tree.getFont());
					label.setText(active.label + ": ");
					//editor.setFont(tree.getFont());
					editor.setText(active.value.toString());
					ret = panel;
				} else {
					editor.setText(value.toString());
					ret = editor;
				}
			} else {
				editor.setText(value.toString());
				ret = editor;
			}
			int tw =
				(int) editor.getFontMetrics(editor.getFont()).getStringBounds(editor.getText(), editor.getGraphics()).getWidth();
			tw += 10;
			Dimension d = editor.getPreferredSize();
			d.width = ((tw < 50) ? 50 : tw);
			editor.setPreferredSize(d);

			return ret;
		}

		/**
		 * Description
		 */
		private void init() {
			panel = new JPanel();
			//panel.setBackground(Color.YELLOW);
			panel.setBorder(new EtchedBorder());
			panel.setLayout(new FlowLayout());
			label = new JLabel();
			panel.add(label);
			editor = new JTextField();
			panel.add(editor);
		}
	}

	public static class Holder {
		public String label;
		public Object value;

		/**
		 * Creates a new Holder object.
		 * 
		 * @param label
		 * @param value
		 */
		public Holder(String label, Object value) {
			this.label = label;
			this.value = value;
		}

		/**
		 * @see Object#toString()
		 */
		public String toString() {
			if (value != null)
				return label + ": " + value.toString();
			else
				return label;
		}
	}

	/**
	 * Creates a root node.
	 */
	public GPTreeNode() {
		setUserObject("GroupPac properties");
		init();
	}

	/**
	 * Create a parent node (that has children).
	 * @param label
	 */
	public GPTreeNode(String label) {
		setUserObject(label);
	}

	/**
	 * Create a child node (that has no children).
	 * @param label
	 * @param value
	 */
	public GPTreeNode(String label, Object value) {
		setUserObject(new Holder(label, value));
	}

	/**
	 * Description
	 * 
	 * @param label
	 * @return GPTreeNode
	 */
	public GPTreeNode getTreeNode(String label) {
		return new GPTreeNode(label);
	}

	/**
	 * Description
	 * 
	 * @param label
	 * @param value
	 * @return GPTreeNode
	 */
	public GPTreeNode getTreeNode(String label, Object value) {
		return new GPTreeNode(label, value);
	}

	/**
	 * Description
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		JFrame f = new JFrame();
		JTree t = new JTree(new GPTreeNode());
		t.setEditable(true);
		t.setCellEditor(new Editor(t));
		f.getContentPane().add(t);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.pack();
		f.show();
	}

	/**
	 * Description
	 */
	private void init() {
		GPTreeNode rsroot = getTreeNode("Replication");
		GPTreeNode rs = getTreeNode("Style", new Integer(STATELESS.value));
		rsroot.add(rs);
		GPTreeNode csroot = getTreeNode("Consistency");
		GPTreeNode cs = getTreeNode("Style", new Integer(CONS_APP_CTRL.value));
		csroot.add(cs);
		GPTreeNode ci = getTreeNode("Checkpoint interval", new Integer(10));
		csroot.add(ci);
		rsroot.add(csroot);
		add(rsroot);
		GPTreeNode msroot = getTreeNode("Membership");
		GPTreeNode ms = getTreeNode("Style", new Integer(MEMB_APP_CTRL.value));
		msroot.add(ms);
		GPTreeNode inr = getTreeNode("Initial number", new Integer(1));
		msroot.add(inr);
		GPTreeNode mnr = getTreeNode("Minimum number", new Integer(1));
		msroot.add(mnr);
		GPTreeNode cn = getTreeNode("Class name", "");
		msroot.add(cn);
		add(msroot);
		GPTreeNode fmsroot = getTreeNode("Fault Monitoring");
		GPTreeNode fms = getTreeNode("Style", new Integer(NOT_MONITORED.value));
		fmsroot.add(fms);
		GPTreeNode fmg = getTreeNode("Granularity", new Integer(MEMB.value));
		fmsroot.add(fmg);
		GPTreeNode fmi = getTreeNode("Interval", new Integer(2));
		fmsroot.add(fmi);
		GPTreeNode fmt = getTreeNode("Timeout", new Integer(1));
		fmsroot.add(fmt);
		add(fmsroot);
		GPTreeNode fctroot = getTreeNode("Factories", "");
		add(fctroot);
	}
}