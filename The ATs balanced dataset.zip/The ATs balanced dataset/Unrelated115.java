/*
* Created on Jul 19, 2004
*
* The Open SLEE Project
*
* The source code contained in this file is in in the public domain.          
* It can be used in any project, or product without prior permission, 	      
* license or royalty payments. There is no claim of correctness and
* NO WARRANTY OF ANY KIND provided with this code.
*/
package org.mobicents.slee.container;

import javax.slee.Address;
import org.mobicents.slee.container.management.*;
import org.mobicents.slee.resource.SleeActivityHandle;

import javax.slee.EventTypeID;

/**
 * 
 * Implements the InitialEventSelector interface
 * 
 * @author F.Moggia
 * 
 * 
 */
public class InitialEventSelectorImpl implements javax.slee.InitialEventSelector{
    private EventTypeID eventTypeID;
    private String eventName;
    private Object event;
    private Object activity;
    private Address address;
    private String customName;

    int[] select;
    private boolean isSelectMethod = false;
    private boolean isActivityContextSelected= false;
    private boolean isAddressProfileSelected= false;
    private boolean isAddressSelected= false;
    private boolean isEventSelected= false;
    private boolean isEventTypeSelected= false;
    
    
    private boolean isInitialEvent= false;
    
    
    private String selectMethodName;
    

    
    
    
    public InitialEventSelectorImpl(EventTypeID type, Object event, Object activity,  int[] select, String methodName, Address address) {
        eventTypeID = type;
        this.event = event;
        this.address = address;
        if ( activity instanceof SleeActivityHandle ) {
            SleeActivityHandle sah = (SleeActivityHandle) activity;
            this.activity = sah.getActivity();
        } else this.activity = activity;
        
        for(int i=0; i<select.length;i++){
            switch(select[i]){ 
            	case SbbEventEntry.ACTIVITY_CONTEXT_INITIAL_EVENT_SELECT: this.isActivityContextSelected = true;break;
            	case SbbEventEntry.ADDRESS_INITIAL_EVENT_SELECT:this.isAddressSelected=true;break;
            	case SbbEventEntry.ADDRESS_PROFILE_INITIAL_EVENT_SELECT:this.isAddressProfileSelected=true;break;
            	case SbbEventEntry.EVENT_INITIAL_EVENT_SELECT:this.isEventSelected=true;break;
            	case SbbEventEntry.EVENT_TYPE_INITIAL_EVENT_SELECT:this.isEventTypeSelected=true;break;
           
         
            
            }
        }
        
        if (methodName == null){
            isSelectMethod = false;
        } else {
            isSelectMethod = true;
            selectMethodName = methodName;
        }
        
        
    }
    
    
    public String toString() {
        return new StringBuffer()
        			.append("InitialEventSelector = { ")
        			.append("eventTypeID " + eventTypeID + "eventName " + eventName + " event " + event + " activity " + activity + " address " + address )
        			.append("\n activityContextSelected = "  + isActivityContextSelected)
        			.append("\n isAddressSelected " + this.isAddressSelected)
        			.append("\n isAddressProfileSelected " + this.isAddressProfileSelected)
        			.append("\n isEventSelected " + this.isEventSelected)
        			.append("\n customName " + this.customName)
        			.append("\n selectMethodName " + this.selectMethodName)
        			.append("\n }").toString();
    }
    
    /**
     * @return Returns the isActivityContextSelected.
     */
    public boolean isActivityContextSelected() {
        return this.isActivityContextSelected;
    }
    /**
     * @return Returns the isAddressProfileSelected.
     */
    public boolean isAddressProfileSelected() {
        return this.isAddressProfileSelected;
    }
    /**
     * @return Returns the isAddressSelected.
     */
    public boolean isAddressSelected() {
        return this.isAddressSelected;
    }
    /**
     * @return Returns the isEventTypeSelected.
     */
    public boolean isEventTypeSelected() {
        return this.isEventTypeSelected;
    }
    /**
     * @return Returns the eventType.
     */
    public EventTypeID getEventTypeID() {
        return eventTypeID;
    }
    /**
     * @param eventType The eventType to set.
     */
    public void setEventType(EventTypeID eventTypeID) {
        this.eventTypeID = eventTypeID;
    }
    /**
     * @return Returns the isEventSelected.
     */
    public boolean isEventSelected() {
        return this.isEventSelected;
    }
    /**
     * @param isEventSelected The isEventSelected to set.
     */
    
    /**
     * @param isAddressProfileSelected The isAddressProfileSelected to set.
     */
    public void setAddressProfileSelected(boolean isAddressProfileSelected) {
        this.isAddressProfileSelected = isAddressProfileSelected;
    }
    /**
     * @param isAddressSelected The isAddressSelected to set.
     */
    public void setAddressSelected(boolean isAddressSelected) {
        this.isAddressSelected = isAddressSelected;
    }
    /**
     * @param isEventTypeSelected The isEventTypeSelected to set.
     */
    public void setEventTypeSelected(boolean isEventTypeSelected) {
        this.isEventTypeSelected = isEventTypeSelected;
    }
    /**
     * @return Returns the isSelectMethod.
     */
    public boolean isSelectMethod() {
        return isSelectMethod;
    }
    /**
     * @param isSelectMethod The isSelectMethod to set.
     */
    public void setSelectMethod(boolean isSelectMethod) {
        this.isSelectMethod = isSelectMethod;
    }
    /**
     * @return Returns the selectMethodName.
     */
    public String getSelectMethodName() {
        return selectMethodName;
    }
    /**
     * @param selectMethodName The selectMethodName to set.
     */
    public void setSelectMethodName(String selectMethodName) {
        this.selectMethodName = selectMethodName;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#getEventName()
     */
    public String getEventName() {
        return eventName;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#getEvent()
     */
    public Object getEvent() {
        return event;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#getActivity()
     */
    public Object getActivity() {
        return activity;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#getAddress()
     */
    public Address getAddress() {
        
        return address;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#setAddress(javax.slee.Address)
     */
    public void setAddress(Address address) {
        
        this.address = address;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#getCustomName()
     */
    public String getCustomName() {
        
        return customName;
    }

    public void setCustomName(String customName) {
        this.customName = customName;
    }
    
    public void setActivityContextSelected(boolean isActivityContextSelected) {
        this.isActivityContextSelected = isActivityContextSelected;
    }
    
    public void setEventSelected(boolean isEventSelected) {
        this.isEventSelected = isEventSelected;
    }
    
    public boolean isInitialEvent() {
        return isInitialEvent;
    }
    
    public void setInitialEvent(boolean isInitialEvent) {
        this.isInitialEvent = isInitialEvent;
    }
}
*
 * Created on Jul 14, 2004
 *
 * The source code contained in this file is in in the public domain.          
 * It can be used in any project, or product without prior permission, 	      
 * license or royalty payments. There is no claim of correctness and
 * NO WARRANTY OF ANY KIND provided with this code.
 */
package org.mobicents.slee.container;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import javax.slee.ChildRelation;
import javax.slee.CreateException;
import javax.slee.SLEEException;
import javax.slee.SbbID;
import javax.slee.SbbLocalObject;
import javax.slee.TransactionRequiredLocalException;
import javax.transaction.SystemException;

import org.jboss.logging.Logger;
import org.mobicents.slee.runtime.SbbEntity;
import org.mobicents.slee.runtime.SbbLocalObjectConcrete;
import org.mobicents.slee.runtime.SbbLocalObjectImpl;

/**
 * 
 * Implements the ChildRelation interface
 * 
 * @author F.Moggia
 * @author M. Ranganathan
 * @author Ralf Siedow
 * 
 *  
 */
public class ChildRelationImpl implements ChildRelation {

    volatile private static Logger logger;

    private HashSet children;

    private SbbEntity parentEntity;

    volatile private SleeContainer container;

    private SbbID sbbid;

    private byte defaultPriority;

    static {
        logger = Logger.getLogger(ChildRelationImpl.class);
    }


         
    private void checkTransaction() throws TransactionRequiredLocalException {
        SleeContainer.getTransactionManager().mandateTransaction();
    }

    private HashSet getLocalObjects() {
        HashSet localObjects = new HashSet();
        for (Iterator it = this.children.iterator(); it.hasNext();) {
            String sbbEntityId = (String) it.next();
            localObjects.add( this.createSbbLocalObject(sbbEntityId));
            //.add(new SbbLocalObjectImpl(this.container, sbbEntityId));
        }
        return localObjects;
    }

    /*
     * JAIN SLEE 1.0 Specification, Final Release Page 62 The iterator method
     * and the Iterator objects returned by this method. Chapter 6 The SBB
     * Abstract Class
     * 
     * The SLEE must implement the methods of the Iterator objects returned by
     * the iterator method by following the contract defined by the
     * java.util.Iterator interface. o The next method of the Iterator object
     * returns an object that implements the SBB local interface of the child
     * SBB of the child relation. Java typecast can be used to narrow the
     * returned object reference to the SBB local interface of the child SBB. o
     * The remove method of the Iterator object removes the SBB entity that is
     * represented by the last SBB local object returned by the next method of
     * the Iterator object from the child relation. Removing an SBB entity from
     * a child relation by invoking this remove method initiates a cascading
     * removal of the SBB entity tree rooted by the SBB entity, similar to
     * invoking the remove method on an SBB local object that represents the SBB
     * entity. The behavior of the Iterator object is unspecified if the
     * underlying child relation is modified while the iteration is in progress
     * in any way other than by calling this remove method.
     */
    class ChildRelationIterator implements Iterator {
        private HashSet sbbEntities;

        private Iterator myIterator;

        private String nextEntity;

        private SbbLocalObject nextSbbLocalObject;

        public ChildRelationIterator(SleeContainer container, HashSet entities) {
            this.sbbEntities = entities;
            this.myIterator = this.sbbEntities.iterator();

        }
      
        /*
         * public ChildRelationIterator(HashSet entities) { this.sbbEntities =
         * new HashSet(); for (Iterator it = entities.iterator(); it.hasNext(); ) {
         * SbbEntity sbbe = (SbbEntity) it.next(); SbbLocalObjectImpl
         * sbbLocalObject = (SbbLocalObjectImpl) sbbe.getSbbLocalObject(); if (!
         * sbbLocalObject.isRemoved()) this.sbbEntities.add(sbbe); }
         * 
         * this.myIterator = this.sbbEntities.iterator(); }
         */
        
        public void remove() {
            myIterator.remove();
            nextSbbLocalObject.remove();
            //TODO -- add an action here to actually remove the entity from the
            // child relation.
            
            // container.removeSbbEntityTree(nextEntity);
        }

        /*
         * (non-Javadoc)
         * 
         * @see java.util.Iterator#hasNext()
         */
        public boolean hasNext() {
            return myIterator.hasNext();
        }

        /*
         * (non-Javadoc)
         * 
         * @see java.util.Iterator#next()
         */
        public Object next() {
            nextEntity = (String) myIterator.next();
            this.nextSbbLocalObject = createSbbLocalObject(nextEntity);
            return nextSbbLocalObject;
        }

    }

    public ChildRelationImpl(SbbID sbbid, byte defaultPriority,
             SbbEntity sbbe, HashSet children) {
    	if ( logger.isDebugEnabled()) {
    	    logger.debug("Creating child relation. children = " + children);
    	}

        if (sbbid == null)
            throw new NullPointerException(" null sbb id");
        if ( children == null )
            throw new NullPointerException ("Internal Error! null children passed in");
        this.parentEntity = sbbe;
        this.container = SleeContainer.lookupFromJndi();
        this.sbbid = sbbid;
        this.defaultPriority = defaultPriority;
        this.children = children;
    }

    public Iterator iterator() {
        return new ChildRelationIterator(this.container,children);
    }

    /**
     * The contains method. This method returns true if the SBB entity
     * represented by the SBB local object specified by the input argument is a
     * member of this child relation. If the method argument is not an SBB local
     * object, is an invalid SBB local object, or is an SBB local object whose
     * underlying SBB entity is not a member of this child relation, then this
     * method returns false.
     *  
     */
    public boolean contains(Object object) {
        if (!(object instanceof SbbLocalObject))
            return false;
        SbbLocalObjectImpl sbblocal = (SbbLocalObjectImpl) object;
        String sbbEntityId = sbblocal.getSbbEntityId();
        return this.children.contains(sbbEntityId);
    }

    /*
     * (non-Javadoc)
     * 
     * @see javax.slee.ChildRelation#create()
     */
    public SbbLocalObject create() throws CreateException,
            TransactionRequiredLocalException, SLEEException {
        SleeContainer.getTransactionManager().mandateTransaction();

        if (logger.isDebugEnabled())
            logger.debug("ChildRelation.create() : Creating Sbb Entity: " + sbbid);

        SbbEntity sbbEntity = this.container.getSbbEntityFactory().createSbbEntity(this.sbbid, 
                this.parentEntity.getService().getServiceID(), this.parentEntity.getSbbEntityId(),
                this.parentEntity.getServiceConvergenceName());
      
       
		//TODO: shuold be remove
        sbbEntity.setPriority(this.defaultPriority);
        //sbbEntity.setRootSbbId(this.parentEntity.getRootSbbId());
        //sbbEntity.setParentSbbEntity(this.parentEntity.getSbbEntityId());

        
        
        /*
         * Exception handling here must follow Sec. 9.12.1 of spec
         * This is a non-slee originated method invocation
         * 
         * If a non-SLEE originated method invocation returns by throwing a checked exception, then the following
		 *	occurs:
		 *	 The state of the transaction is unaffected
		 *	 The checked exception is propagated to the caller.
		 *	It is expected that the caller will have the appropriate logic to handle the exception.
		 *	If a non-SLEE originated method invocation returns by throwing a RuntimeException, then:
		 *	 The transaction is marked for rollback.
		 *	 The SBB object that was invoked is discarded, i.e. is moved to the Does Not Exist state.
		 *	 A javax.slee.TransactionRolledBackLocalException is propagated to the caller.
		 *	The transaction will eventually be rolled back when the highest level SLEE originated invocation re-turns
		 *	as described in Section 9.12.2.
		 *	The sbbRolledBack method is not invoked for an SBB originated method transaction because the
		 *	transa ction is only marked for rollback and will only be rolled back when the highest level SLEE
		 *	originated invocation returns. The sbbRolledBack method is only invoked on the SBB entity in-voked
		 *	by the highest level SLEE originated invocation.
		 *	If the RuntimeException propagates to the highest level (i.e. the SLEE originated method invocation
		 *	returns by throwing a RuntimeException) the SLEE originated method invocation exception handling
		 *	mechanism is init iated.		
		*/
        
        try {            
        	//All checked exceptions (i.e. CreateException) are propagated to the caller
            if(sbbEntity.getSbbObject() == null){
                sbbEntity.assignSbbObject(true);
            }
        	        	        	
        	
            //sbbEntity.getSbbObject().sbbCreate();
            //sbbEntity.getSbbObject().setState(SbbObjectState.READY);
            //sbbEntity.getSbbObject().sbbPostCreate();
        } catch ( CreateException e) {
            //          All RuntimeExceptions are dealt with here
            if ( logger.isDebugEnabled())
                logger.error("Caught CreateException in creating child entity", e);
            /*try {
                SleeContainer.getTransactionManager().setRollbackOnly();
            } catch (SystemException e1) {
            	logger.error("Failed to set rollbackonly", e);
            }*/
            sbbEntity.trashObject();
            // Propagate exception to caller.
            throw e;
        } catch ( Exception e) {
        	//All RuntimeExceptions are dealt with here
            logger.error("Caught RuntimeException in creating child entity", e);
            try {
                SleeContainer.getTransactionManager().setRollbackOnly();
            } catch (SystemException e1) {
            	logger.error("Failed to set rollbackonly", e);
            }
            sbbEntity.trashObject();
        } 
        
        children.add(sbbEntity.getSbbEntityId()); // Ralf Siedow: added this
        logger.debug("Children is: " + children);
        logger.debug("sbbEntity is: " + sbbEntity);
        return sbbEntity.createSbbLocalObject();
    }

   
    
    private SbbLocalObject createSbbLocalObject(String sbbeId) {
        SbbEntity sbbEntity = container.getSbbEntityFactory().getSbbEntity(sbbeId);
        return sbbEntity.createSbbLocalObject();
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.util.Collection#size()
     */
    public int size() {

        return this.children.size();
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.util.Collection#clear()
     */
    public void clear() {
        checkTransaction();
        for ( Iterator it = this.iterator(); it.hasNext() ; ) {
            it.next();
            it.remove();
        }
        

    }

    /*
     * (non-Javadoc)
     * 
     * @see java.util.Collection#isEmpty()
     */
    public boolean isEmpty() {
        checkTransaction();
        return this.children.isEmpty();
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.util.Collection#toArray()
     */
    public Object[] toArray() {

        checkTransaction();

        return this.getLocalObjects().toArray();
    }

    /**
     * This operation is not supported ( see page 62 ) of the spec. The add
     * methods add and addAll. Any attempts to add to the child relation using
     * these methods result in a java.lang. UnsupportedOperationException. For
     * example, the SLEE must throw the UnsupportedOperationException when these
     * methods are invoked with arguments that add to the collection. o An
     * invocation of an add method that has no effect on the collection, such as
     * invoking the addAll method with an empty collection may or may not throw
     * an UnsupportedOperationException . The create method of the ChildRelation
     * interface should be used to create a child SBB entity. This causes the
     * SLEE to automatically add an SBB local object that represents the newly
     * created SBB entity to the collection.
     */
    public boolean add(Object object) {
        if (object == null)
            throw new NullPointerException("null arg! ");
        else
            throw new UnsupportedOperationException("Operation not supported !");
    }

    /**
     * Spec page 62 The remove methods: clear, remove, removeAll, and retainAll.
     * o These methods may remove SBB entities from the child relation. The
     * input argument specifies which SBB entities will be removed from the
     * child relation or retained in the child relation by specifying the SBB
     * local object or collection of SBB local objects that represent the SBB
     * entities to be removed or retained. o Removing an SBB entity from a child
     * relation initiates a cascading removal of the SBB entity tree rooted by
     * the SBB entity, similar to invoking the remove method on an SBB local
     * object that represents the SBB entity.
     *  
     */
    public boolean remove(Object object) {
        checkTransaction();
        logger.debug("removing " + object);
        if (object == null)
            throw new NullPointerException("Null arg for remove ");
        if (!(object instanceof SbbLocalObject))
            return false;
        String target = ((SbbLocalObjectImpl)object).getSbbEntityId();
        boolean retval = this.children.remove(target);
        if (retval) {
            logger.debug("removing entity tree !");
            ((SbbLocalObjectImpl) object).remove();
            retval = false;
        }
        return retval;
    }

    /**
     * This operation is not supported ( see page 62 ) of the spec. The add
     * methods add and addAll. Any attempts to add to the child relation using
     * these methods result in a java.lang. UnsupportedOperationException. For
     * example, the SLEE must throw the UnsupportedOperationException when these
     * methods are invoked with arguments that add to the collection. o An
     * invocation of an add method that has no effect on the collection, such as
     * invoking the addAll method with an empty collection may or may not throw
     * an UnsupportedOperationException . The create method of the ChildRelation
     * interface should be used to create a child SBB entity. This causes the
     * SLEE to automatically add an SBB local object that represents the newly
     * created SBB entity to the collection.
     */
    public boolean addAll(Collection c) {
        if (c == null)
            throw new NullPointerException("Null arg!");
        else
            throw new UnsupportedOperationException("Operation not supported !");
    }

    /**
     * This method returns true if all SBB entities represented by the SBB local
     * objects in the collection specified by the input argument are members of
     * this child relation. If the collection contains an object that is not an
     * SBB local object, an SBB local object that is invalid, or an SBB local
     * object whose underlying SBB entity is not a member of this child
     * relation, then this method returns false.
     */
    public boolean containsAll(Collection c) {
        if (c == null)
            throw new NullPointerException("null collection!");
        HashSet localInterfaces = getLocalObjects();
        logger.debug("containsAll : collection = " + c + " sbbLocalObject = " + localInterfaces);
        boolean retval  = true;
        for ( Iterator it = c.iterator(); it.hasNext(); ) {
            SbbLocalObjectConcrete sbbLocalInterface = ( SbbLocalObjectConcrete) it.next();
            logger.debug("Checking membership for : "  + sbbLocalInterface.getSbbEntityId());
            if ( ! children.contains(sbbLocalInterface.getSbbEntityId())) {
                retval = false;
                break;
            }
        }
        
        return retval;
    }

    /**
     * Removing an SBB entity from a child relation initiates a cascading
     * removal of the SBB entity tree rooted by the SBB entity, similar to
     * invoking the remove method on an SBB local object that represents the SBB
     * entity.
     *  
     */
    public boolean removeAll(Collection c) {
        boolean flag = true;
        if (c == null)
            throw new NullPointerException(" null collection ! ");
        for ( Iterator it = c.iterator(); it.hasNext();	) {
           flag &= this.remove( it.next());
            
        }
        return flag;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.util.Collection#retainAll(java.util.Collection)
     */
    public boolean retainAll(Collection c) {
        boolean flag = false;
        if (c == null)
            throw new NullPointerException(" null arg! ");
        //Iterator it = this.iterator();
        for ( Iterator it = this.iterator(); it.hasNext();) {
            if ( ! c.contains(it.next())) {
                flag = true;
                it.remove();
            }
            
        }
        return flag;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.util.Collection#toArray(java.lang.Object[])
     */
    public Object[] toArray(Object[] a) {
        if (a == null)
            throw new NullPointerException("null arg!");
        HashSet localObjects = this.getLocalObjects();
        return localObjects.toArray(a);
    }

    /**
     * Mark all the entities that are part of this child relation as being in a
     * rolledback state so that if any transactional method is invoked on the
     * associated entity, you will get an exception
     */
    /*
     * public void markRolledBack() { for ( Iterator it =
     * this.children.iterator(); it.hasNext();) { SbbEntity sbbEntity =
     * (SbbEntity) it.next(); sbbEntity.markRolledBack(); }
     *  }
     */
          
    /**
     * return an iterator containing the child entities.
     * 
     * @return
     */
    public Iterator getChildEntities() {
        return this.children.iterator();
    }
    
    /**
     * Remove an entity ( this is for cascading removal only )
     *
     */
     public void removeSbbEntity(String sbbeId) {
         this.children.remove(sbbeId);
     }
     
     public HashSet getSbbEntitySet(){
         return this.children;
     }
     
//     public void setSbbEntitySet(HashSet set){ // Ralf Siedow: removed and forced setting of children in constructor
//         this.children = set;
//     }

}ackage org.mobicents.util;

public class XMLException extends java.io.IOException {
    /**
     * Construct an exception with the specified detail message.
     * @param message a meaningful message which explains the exceptional situation
     */
    public XMLException(String message) {
        super(message);
    }
    
    public XMLException(String message, Throwable cause) {
	super(message);
        initCause(cause);
    }
}


/***************************************************
 *                                                 *
 *  Mobicents: The Open Source VoIP Platform       *
 *                                                 *
 *  Distributable under LGPL license.              *
 *  See terms of license at gnu.org.               *
 *                                                 *
 ***************************************************/
package org.mobicents.ant.sbbconfigurator;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.tools.ant.BuildException;
import org.mobicents.util.XMLParser;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;

import org.mobicents.ant.SleeDTDResolver;

/**
 * Ant subtask for SbbConfigurator that configures sbb descriptor's env entry elements.
 * @author Eduardo Martins / 2006 PT Inovao (www.ptinovacao.pt)
 */
public class SetEnvEntrySubTask implements SubTask {
	
	// Obtain a suitable logger.
    private static Logger logger = Logger.getLogger(org.mobicents.ant.sbbconfigurator.SetEnvEntrySubTask.class.getName());
    
    // Does all the work, that is, sets a new type and/or new value on a existent env-entry.
    public void run(File sbbDescriptor) {
    	
    	if (envEntryType == null && envEntryValue == null) {
    		// Log the warning
    		logger.log(Level.WARNING, "Skiping sbb description configuration of env-entry with name "+envEntryName+". Reason: new Type and new Value not defined.");
    	}
    	else {	
    		try {    			
    			try {
    				Document sbbjarDoc = XMLParser.getDocument(sbbDescriptor.toURL(), entityResolver);
    				Element sbbRoot = sbbjarDoc.getDocumentElement(); // <sbb-jar>
    				List sbbNodes = XMLParser.getElementsByTagName(sbbRoot, "sbb"); // <sbb>
    				boolean updateXml = false;
    				for (Iterator i = sbbNodes.iterator(); i.hasNext(); ) {    					
    					// get sbb node
    					Element sbbNode = (Element)i.next();    					
    					// check sbb node 
    					if (sbbName != null) {
    						Element sbbNameNode = XMLParser.getUniqueElement(sbbNode, "sbb-name"); // <sbb-name>
    						if (!sbbNameNode.getFirstChild().getNodeValue().equals(sbbName))
    							continue;
    					};    				
    					if (sbbVendor != null) {
    						Element sbbVendorNode = XMLParser.getUniqueElement(sbbNode, "sbb-vendor"); // <sbb-vendor>
    						if (!sbbVendorNode.getFirstChild().getNodeValue().equals(sbbVendor))
    							continue;
    					};    				
    					if (sbbVersion != null) {
    						Element sbbVersionNode = XMLParser.getUniqueElement(sbbNode, "sbb-version"); // <sbb-version>
    						if (!sbbVersionNode.getFirstChild().getNodeValue().equals(sbbVersion))
    							continue;
    					};    					
    					List envEntries = XMLParser.getElementsByTagName(sbbNode, "env-entry"); // <env-entry>
    					for (Iterator j = envEntries.iterator(); j.hasNext(); ) {    						
    						// get env entry node
    						Element envEntryNode = (Element)j.next();    						
    						// check env entry node
    						Element envEntryNameNode = XMLParser.getUniqueElement(envEntryNode, "env-entry-name"); // <env-entry-name>    					
    						if (!envEntryNameNode.getFirstChild().getNodeValue().equals(envEntryName))
    							continue;    						
    						// set env entry type?
    						if (envEntryType != null) {
    							Element envEntryTypeNode = XMLParser.getUniqueElement(envEntryNode, "env-entry-type"); // <env-entry-type>    							
    							if (!envEntryTypeNode.hasChildNodes()) {
    								envEntryTypeNode.appendChild(sbbjarDoc.createTextNode(envEntryType));
    							}
    							else {
    								envEntryTypeNode.getFirstChild().setNodeValue(envEntryType);
    							}
    							updateXml = true;
    						}    						
    						// set env entry value?
    						if (envEntryValue != null) {
    							Element envEntryValueNode = XMLParser.getUniqueElement(envEntryNode, "env-entry-value"); // <env-entry-value>
    							if (!envEntryValueNode.hasChildNodes()) {
    								envEntryValueNode.appendChild(sbbjarDoc.createTextNode(envEntryValue));
    							}
    							else {
    								envEntryValueNode.getFirstChild().setNodeValue(envEntryValue);
    							}
    							updateXml = true;
    						}    						
    					}
    				}    				    				
    				// write updated descriptor file?
    				if (updateXml) {
    					Source source = new DOMSource(sbbjarDoc);
    					Result result = new StreamResult(sbbDescriptor);
    					Transformer xformer = TransformerFactory.newInstance().newTransformer();
    					DocumentType docType = sbbjarDoc.getDoctype();    					
    					if (docType != null) {    						        					
    						String publicId = docType.getPublicId();    						
    						if(publicId != null) {
    							xformer.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, publicId);    							
    						}
    						String systemId = docType.getSystemId();    						
    						if(systemId != null) {
    							xformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, systemId);    							
    						}
    						//FIXME should we check more properties? 
    					}    	
    					else {
        					logger.warning("sbb descriptor with null doctype");
    					}
    					xformer.transform(source, result);
    				}
    			} catch (IOException e) {
    				throw new BuildException(e);
    			}
    		}
    		catch (Exception ex) {
    			// Log the error
    			logger.log(Level.WARNING, "Bad result: " + ex.getCause().toString());
    		}
    	}
    }
	    
	// The setter for the "name" attribute	
	public void setName(String name) {
		this.envEntryName = name;
	}
	
	// The setter for the "newType" attribute	
	public void setNewType(String newType) {
		this.envEntryType = newType;
	}
	
	// The setter for the "newValue" attribute	
	public void setNewValue(String newValue) {
		this.envEntryValue = newValue;
	}
	
	// The setter for the "sbbName" attribute	
	public void setSbbName(String sbbName) {
		this.sbbName = sbbName;
	}
	
	// The setter for the "sbbVendor" attribute	
	public void setSbbVendor(String sbbVendor) {
		this.sbbVendor = sbbVendor;
	}
	
	// The setter for the "sbbVersion" attribute	
	public void setSbbVersion(String sbbVersion) {
		this.sbbVersion = sbbVersion;
	}
	
	private String envEntryName = null;	
	private String envEntryType = null;
	private String envEntryValue = null;
	private String sbbName = null;	
	private String sbbVendor = null;
	private String sbbVersion = null;
	
	private static final SleeDTDResolver entityResolver = new SleeDTDResolver();
       
}public class RemoteSleeServiceImpl implements RemoteSleeService {
	private NullActivityFactory naf;

	private ActivityContextFactory acf;

	private SleeInternalEndpoint endpoint;

	private EventLookup eventLookup;

	private static Logger log = Logger.getLogger(RemoteSleeServiceImpl.class);

	class DeferredFireEventAction implements
			Runnable {
		ArrayList eventList;

		public DeferredFireEventAction(ArrayList alist) {
			this.eventList = new ArrayList(alist);
		}




		public void run() {
			log.debug("afterCompletion called -- fireEventQueue Again!");
			Iterator iter = eventList.iterator();
			while (iter.hasNext()) {
				EventInvocation ei = (EventInvocation) iter.next();
				fireEvent(ei.event, ei.eventTypeId, ei.externalActivityHandle,
						ei.address);
			}
		}

	}

	public RemoteSleeServiceImpl(NullActivityFactory naf,
			SleeInternalEndpoint endpoint, EventLookup eventLookup,
			ActivityContextFactory acf) {
		log.debug("Creating RemoteSleeServiceImpl");
		this.naf = naf;
		this.endpoint = endpoint;
		this.eventLookup = eventLookup;
		this.acf = acf;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.mobicents.slee.connector.server.RemoteSleeService#createActivityHandle()
	 */
	public ExternalActivityHandle createActivityHandle() {

		log.debug("createActivityHandle() called current " );
		SleeTransactionManager txmgr = SleeContainer.getTransactionManager();
		boolean b = false;
		try {
			b  = txmgr.requireTransaction();
			NullActivityImpl na = (NullActivityImpl) (((NullActivityFactoryImpl) naf)
					.createNullActivityNoTx());
			ActivityContext ac = acf.getActivityContext(na);

			return new ActivityHandleImpl(ac.getActivityContextId());
		} catch (Exception ex) {
			try {
				if (b)
				txmgr.setRollbackOnly();
			} catch (Exception e) {
				log.error("createActivityHandle(): exception occured", ex);
			}
			return null;
		} finally {
			try {
				if(b)
					txmgr.commit();
			} catch (Exception ex) {
				log.error("createActivityHandle(): exception occured", ex);
			}

		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.mobicents.slee.connector.server.RemoteSleeService#fireEvent(java.lang.Object,
	 *      javax.slee.EventTypeID,
	 *      org.mobicents.slee.connector.server.ActivityHandleImpl,
	 *      javax.slee.Address)
	 */
	public void fireEvent(Object event, EventTypeID eventType,
			ExternalActivityHandle activityHandle, Address address) {
		if (event == null)
			throw new NullPointerException("event is null");
		if (eventType == null)
			throw new NullPointerException("eventType is null");
		SleeTransactionManager txmgr = SleeContainer.getTransactionManager();
		boolean b = false;
		try {
			log.debug("fireEvent() called " + txmgr.isInTx());
			if(!txmgr.isInTx())
				txmgr.begin();

			// fire an event on the slee endpoint using the right null activity
			NullActivityImpl na = null;
			if (activityHandle != null) {

				ActivityHandleImpl handle = (ActivityHandleImpl) activityHandle;
				ActivityContext ac = acf.getActivityContextById(handle
						.getKey());
				if (ac == null) {
					log.error("Invalid activity handle!");
					return;
				}
				na = (NullActivityImpl) ac.getActivity();

			} else {
				log.debug("Creating new null activity");
				na = (NullActivityImpl) ((NullActivityFactoryImpl) naf)
						.createNullActivityNoTx();
			}

			endpoint.enqueueEvent(eventType, event, na, address);
			log.debug("Queued event");
		} catch (Exception ex) {
			try {
				if ( txmgr.isInTx())
					txmgr.setRollbackOnly();
			} catch (Exception e) {
				log.error("Exception committing tx", e);
			}
			log.error("Exception in fireEvent!", ex);
		} finally {
			try {
				if ( txmgr.isInTx())
					txmgr.commit();
			} catch (Exception e) {
				log.error("Exception committing tx", e);
			}
		}
	}

	public void fireEventQueue(ArrayList queue) {
		if (queue == null)
			throw new NullPointerException("queue is null");
		try {
			log.debug("fireEventQueue() called");
			DeferredFireEventAction daf = new DeferredFireEventAction(queue);
			// The following needs to run in its own tx because 
			// it has to start transactions.
			new ThreadedExecutor().execute(daf);
			
		} catch (Exception ex) {
			throw new RuntimeException("Unexpected error", ex);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.mobicents.slee.connector.server.RemoteSleeService#getEventTypeID(java.lang.String,
	 *      java.lang.String, java.lang.String)
	 */
	public EventTypeID getEventTypeID(String name, String vendor, String version) {
		if (name == null)
			throw new NullPointerException("name is null");
		if (vendor == null)
			throw new NullPointerException("vendor is null");
		if (version == null)
			throw new NullPointerException("version is null");

		log.debug("getEventTypeID() called");
		int eventId = eventLookup.getEventID(name, vendor, version);
		log.debug("eventId is:" + eventId);
		if (eventId == -1) {
			/*
			 * The SLEE spec. does not define what to return if the event type
			 * is not found but we're going to return null
			 */
			return null;
		}
		EventTypeID eventTypeID = eventLookup.getEventTypeID(eventId);
		log.debug("Event type id is:" + eventTypeID);
		return eventTypeID;
	}
}