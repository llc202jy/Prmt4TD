package net.assimilator.resources.client;

import net.jini.lookup.ServiceDiscoveryEvent;
import net.jini.lookup.ServiceDiscoveryListener;

/**
 * The adapter which receives ServiceDiscoveryEvents. The methods in this class are empty; 
 * this class is provided as a convenience for easily creating listeners by extending 
 * this class and overriding only the methods of interest. 
 */
public class ServiceDiscoveryAdapter implements ServiceDiscoveryListener {
    
    /**
     * @see net.jini.lookup.ServiceDiscoveryListener#serviceAdded
     */
    public void serviceAdded(ServiceDiscoveryEvent sdEvent) {
    }
    
    /**
     * @see net.jini.lookup.ServiceDiscoveryListener#serviceChanged
     */
    public void serviceChanged(ServiceDiscoveryEvent sdEvent) {
    }
    
    /**
     * @see net.jini.lookup.ServiceDiscoveryListener#serviceRemoved
     */
    public void serviceRemoved(ServiceDiscoveryEvent sdEvent) {
    } import java.util.Comparator;
import net.jini.core.lookup.ServiceItem;
import net.assimilator.entry.ComputeResourceUtilization;

/**
 * A comparator that orders client Service Items by their ComputeResourceUtilization
 * 
 * Note: this comparator imposes orderings that are inconsistent with equals.
 */
public class ComputeResourceUtilizationComparator implements Comparator {    

    /**
     * Compares its two arguments for order.  Returns a negative integer,
     * zero, or a positive integer as the first argument is less than, equal
     * to, or greater than the second.
     *
     * Each service item must have a ComputeResourceUtilization attribute else an exception 
     * will be thrown.
     *     
     * @throws NullPointerException any of the services does not have a 
     * ComputeResourceUtilization attribute.
     */
    public int compare(Object o1, Object o2) {
        ServiceItem serviceItem1 = (ServiceItem)o1;
        ServiceItem serviceItem2 = (ServiceItem)o2;         

        ComputeResourceUtilization computeResourceEntry1 = getComputeResourceUtilization(serviceItem1);
        ComputeResourceUtilization computeResourceEntry2 = getComputeResourceUtilization(serviceItem2);
        // lower cost is better
        return(computeResourceEntry1.compareTo(computeResourceEntry2));
    }

    private ComputeResourceUtilization getComputeResourceUtilization(ServiceItem item) {
        for(int i =0; i < item.attributeSets.length; i++) {
            if(item.attributeSets[i] instanceof ComputeResourceUtilization)
                return(ComputeResourceUtilization)item.attributeSets[i];
        }
        return(null);
    }
}