#include "php.h"
#include "zend_ini.h"
#include <radius/radius.h>


ZEND_BEGIN_MODULE_GLOBALS(radius)
	grad_list_t *resources;
ZEND_END_MODULE_GLOBALS(radius)	

#ifdef ZTS
# define MRADG(v) TSRMG(radius_globals_id, zend_radius_globals *, v)
#else
# define MRADG(v) (radius_globals.v)
#endif
	
ZEND_DECLARE_MODULE_GLOBALS(radius);

typedef void (*mod_destroy_resource_t)(void *ptr);

struct mod_resource {
	void *ptr;
	mod_destroy_resource_t destr;
};

static void	
mod_register_resource(void *ptr, mod_destroy_resource_t destr)
{
	struct mod_resource *mr;
	if (!MRADG(resources))
		MRADG(resources) = grad_list_create();
	mr = malloc(sizeof(*mr));
	if (!mr)
		zend_error(E_ERROR, "Not enough memory");
	mr->ptr = ptr;
	mr->destr = destr;
	grad_list_append(MRADG(resources), mr);
}

static int
mod_res_cmp(const void *a, const void *b)
{
	const struct mod_resource *ma = a;
	const struct mod_resource *mb = b;
	return ma->ptr != mb->ptr;
}

static void
mod_destroy_resource(void *ptr)
{
	struct mod_resource *res = grad_list_remove(MRADG(resources), ptr,
						    mod_res_cmp);
	if (res) {
		res->destr(res->ptr);
		free(res);
	}
}

static int
mod_free_res(void *item, void *data)
{
	struct mod_resource *res = item;
	if (res) {
		res->destr(res->ptr);
		free(res);
	}
	return 0;
}

static void
mod_destroy_all_resources()
{
	grad_list_destroy(&MRADG(resources), mod_free_res, NULL);
}
		


static void
mod_destroy_queue(void *ptr)
{
	grad_client_destroy_queue((grad_server_queue_t *)ptr);
}

	

ZEND_MINFO_FUNCTION(radauthmod);
ZEND_MINIT_FUNCTION(radauthmod);
ZEND_MSHUTDOWN_FUNCTION(radauthmod);
ZEND_RSHUTDOWN_FUNCTION(radauthmod);

ZEND_FUNCTION(radius_auth_user);
ZEND_FUNCTION(radius_query);
ZEND_FUNCTION(radius_set_debug);
ZEND_FUNCTION(radius_clear_debug);
ZEND_FUNCTION(radius_lookup_value);
ZEND_FUNCTION(radius_attribute_type);

static unsigned char radius_query_args_force_ref[]  = { 5, BYREF_NONE, BYREF_NONE, BYREF_NONE, BYREF_FORCE, BYREF_FORCE };

/* compiled function list so Zend knows what's in this module */
zend_function_entry radauthmod_functions[] = {
	ZEND_FE(radius_auth_user, NULL)
	ZEND_FE(radius_query, radius_query_args_force_ref)
	ZEND_FE(radius_set_debug, NULL)
	ZEND_FE(radius_clear_debug, NULL)
	ZEND_FE(radius_lookup_value, NULL) 
	ZEND_FE(radius_attribute_type, NULL)
	{NULL, NULL, NULL}
};

zend_module_entry radauthmod_module_entry = {
	STANDARD_MODULE_HEADER,
	"RADIUS auth module",
	radauthmod_functions,
	ZEND_MINIT(radauthmod),
	ZEND_MSHUTDOWN(radauthmod),
	NULL,
	ZEND_RSHUTDOWN(radauthmod),
	ZEND_MINFO(radauthmod),
	NO_VERSION_YET,
	STANDARD_MODULE_PROPERTIES
};

ZEND_MINIT_FUNCTION(radauthmod)
{
	REGISTER_LONG_CONSTANT("RT_ACCESS_REQUEST", RT_ACCESS_REQUEST,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("RT_ACCESS_ACCEPT", RT_ACCESS_ACCEPT,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("RT_ACCESS_REJECT", RT_ACCESS_REJECT,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("RT_ACCOUNTING_REQUEST",
			       RT_ACCOUNTING_REQUEST,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("RT_ACCOUNTING_RESPONSE",
			       RT_ACCOUNTING_RESPONSE,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("RT_ACCOUNTING_STATUS",
			       RT_ACCOUNTING_STATUS,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("RT_PASSWORD_REQUEST", RT_PASSWORD_REQUEST,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("RT_PASSWORD_ACK", RT_PASSWORD_ACK,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("RT_PASSWORD_REJECT", RT_PASSWORD_REJECT,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("RT_ACCOUNTING_MESSAGE",
			       RT_ACCOUNTING_MESSAGE,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("RT_ACCESS_CHALLENGE", RT_ACCESS_CHALLENGE,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("RT_STATUS_SERVER", RT_STATUS_SERVER,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("RT_STATUS_CLIENT", RT_STATUS_CLIENT,
			       CONST_CS | CONST_PERSISTENT);

	/* Not implemented in GNU Radius, but have place in radius.h */
	REGISTER_LONG_CONSTANT("RT_ASCEND_TERMINATE_SESSION",
			       RT_ASCEND_TERMINATE_SESSION,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("RT_ASCEND_EVENT_REQUEST",
			       RT_ASCEND_EVENT_REQUEST,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("RT_ASCEND_EVENT_RESPONSE",
			       RT_ASCEND_EVENT_RESPONSE,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("RT_ASCEND_ALLOCATE_IP",
			       RT_ASCEND_ALLOCATE_IP,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("RT_ASCEND_RELEASE_IP",
			       RT_ASCEND_RELEASE_IP,
			       CONST_CS | CONST_PERSISTENT);

	REGISTER_LONG_CONSTANT("PORT_AUTH", GRAD_PORT_AUTH,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("PORT_ACCT", GRAD_PORT_ACCT,
			       CONST_CS | CONST_PERSISTENT);

	REGISTER_LONG_CONSTANT("TYPE_INVALID", GRAD_TYPE_INVALID,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("TYPE_INTEGER", GRAD_TYPE_INTEGER,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("TYPE_IPADDR", GRAD_TYPE_IPADDR,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("TYPE_STRING", GRAD_TYPE_STRING,
			       CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("TYPE_DATE", GRAD_TYPE_DATE,
			       CONST_CS | CONST_PERSISTENT);
	
	grad_path_init();
	srand(time(NULL));

	if (grad_dict_init())
		zend_error(E_ERROR, "Can't read RADIUS dictionaries");

	return SUCCESS;
}

ZEND_MSHUTDOWN_FUNCTION(radauthmod)
{
	UNREGISTER_INI_ENTRIES();
	/* deallocate the dictionary entries */
	grad_dict_free();
	grad_path_free();
	return SUCCESS;
}

ZEND_RSHUTDOWN_FUNCTION(radauthmod)
{
	mod_destroy_all_resources();
}

ZEND_MINFO_FUNCTION(radauthmod)
{
	php_info_print_table_start();
	php_info_print_table_header(2, "Function", "Support");
	php_info_print_table_row(2, "Checking user", "Enabled");
	php_info_print_table_row(2, "Passing additional parameters",
				 "Enabled");
	php_info_print_table_row(2, "Build ", __DATE__ "  " __TIME__);

	php_info_print_table_end();
}

#if COMPILE_DL_FIRST_MODULE
ZEND_GET_MODULE(radauthmod)
#endif

static void
put_string(grad_avp_t ** plist, int attrnum, zval * data)
{
	zval dcopy = *data;

	zval_copy_ctor(&dcopy);
	convert_to_string(&dcopy);
	grad_avl_add_pair(plist,
			  grad_avp_create_string(attrnum,
						 Z_STRVAL(dcopy)));
	zval_dtor(&dcopy);
}

static void
put_long(grad_avp_t ** plist, int attrnum, zval * data)
{
	long longval;
	grad_dict_value_t *val = grad_value_name_to_value(Z_STRVAL(*data),
							  attrnum);

	if (val)
		longval = val->value;
	else {
		zval dcopy = *data;
		
		zval_copy_ctor(&dcopy);
		convert_to_long(&dcopy);
		longval = Z_LVAL(dcopy);
		zval_dtor(&dcopy);
	}
	grad_avl_add_pair(plist,
			  grad_avp_create_integer(attrnum, longval));
}

static void
put_ipaddr(grad_avp_t ** plist, int attrnum, zval * data)
{
	zval dcopy = *data;

	zval_copy_ctor(&dcopy);
	convert_to_string(&dcopy);
	grad_avl_add_pair(plist,
			  grad_avp_create_integer(attrnum,
						  grad_ip_strtoip(Z_STRVAL
								  (dcopy))));
	zval_dtor(&dcopy);
}

static void
put_data(grad_avp_t ** plist, grad_dict_attr_t * attr, zval * data)
{
	switch (attr->type) {
	case GRAD_TYPE_STRING:
		put_string(plist, attr->value, data);
		break;
		
	case GRAD_TYPE_INTEGER:
		put_long(plist, attr->value, data);
		break;
		
	case GRAD_TYPE_IPADDR:
		put_ipaddr(plist, attr->value, data);
		break;

	default:
		zend_error(E_ERROR,
			   "Unhadled data type for 3rd argument");
	}
}

int
convert_pair_list(grad_avp_t ** plist, zval * obj)
{
	zval          **data;
	char           *key_str;
	ulong           key_num;

	int             i = 0;

	if (obj != NULL) {
		while (zend_hash_get_current_data(Z_ARRVAL(*obj),
						  (void **) &data)
		       == SUCCESS) {
			grad_dict_attr_t *attr;
			grad_avp_t     *pair;

			key_str = NULL;
			zend_hash_get_current_key(Z_ARRVAL(*obj),
						  &key_str, &key_num,
						  0);
			if (key_str)
				attr = grad_attr_name_to_dict(key_str);
			else
				attr = grad_attr_number_to_dict(key_num);
			if (!attr) {
				zend_error(E_ERROR, "Wrong 3rd parameter");
			}

			if (Z_TYPE_PP(data) == IS_ARRAY) {
				zval          **data2;
				
				while (zend_hash_get_current_data
				       (Z_ARRVAL(**data),
					(void **) &data2) == SUCCESS) {
					
					put_data(plist, attr, *data2);
					zend_hash_move_forward(Z_ARRVAL(**data));
				}
			} else
				put_data(plist, attr, *data);
			zend_hash_move_forward(Z_ARRVAL(*obj));
		}
	}
}

int
convert_from_pair_list(zval * obj, grad_avp_t * plist)
{
	grad_avp_t     *p;
	char            ipaddr[GRAD_IPV4_STRING_LENGTH];

	if (array_init(obj) == FAILURE) {
		zend_error(E_ERROR, "Can't initialize array");
	}

	for (p = plist; p; p = p->next) {
		zval          **found;

		if (zend_hash_find(Z_ARRVAL(*obj), p->name,
				   strlen(p->name) + 1,
				   (void **) &found) == SUCCESS) {
			char           *str;
			long            lval;
			
			switch ((*found)->type) {
			case IS_STRING:
				str = Z_STRVAL(**found);
				array_init(*found);
				add_next_index_string(*found, str, 0);
				break;

			case IS_LONG:
				lval = Z_LVAL(**found);
				array_init(*found);
				add_next_index_long(*found, lval);
				break;
			}

			switch (p->type) {
			case GRAD_TYPE_STRING:
			case GRAD_TYPE_DATE:
				add_next_index_string(*found, p->avp_strvalue,
						      1);
				break;

			case GRAD_TYPE_INTEGER:
			case GRAD_TYPE_IPADDR:
				add_next_index_long(*found, p->avp_lvalue);
				break;
			}
		} else
			switch (p->type) {
			case GRAD_TYPE_STRING:
			case GRAD_TYPE_DATE:
				add_assoc_string(obj, p->name, p->avp_strvalue,
						 1);
				break;
				
			case GRAD_TYPE_INTEGER:
			case GRAD_TYPE_IPADDR:
				add_assoc_long(obj, p->name, p->avp_lvalue);
				break;
			}
	}

}

char *
get_reply_message(grad_avp_t * plist)
{
	grad_avp_t     *p;
	size_t          len;
	char           *str, *s;

	for (len = 0, p = plist; p; p = p->next)
		if (p->attribute == DA_REPLY_MESSAGE)
			len += p->avp_strlength;

	str = emalloc(len + 1);
	
	for (s = str, p = plist; p; p = p->next)
		if (p->attribute == DA_REPLY_MESSAGE) {
			strcpy(s, p->avp_strvalue);
			s += strlen(s);
		}
	
	*s = 0;
	return str;
}

ZEND_FUNCTION(radius_query)
{
	int             port_type;
	int             request_type;
	zval           *pair_list = NULL;
	zval           *reply_pairs = NULL;
	zval           *reply_string = NULL;
	int             reply_code;

	grad_server_queue_t *queue;
	grad_avp_t     *plist = NULL, *p;
	grad_request_t *reply = NULL;
	
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC,
				  "lla|zz",
				  &port_type,
				  &request_type,
				  &pair_list,
				  &reply_pairs,
				  &reply_string) == FAILURE) {
		return;
	}

	if (reply_pairs && !PZVAL_IS_REF(reply_pairs)) {
		zend_error(E_ERROR, "Argument 4 is not passed by reference");
	}

	if (reply_string && !PZVAL_IS_REF(reply_string)) {
		zend_error(E_ERROR, "Argument 5 is not passed by reference");
	}
	
	queue = grad_client_create_queue(1, 0, 0);
	mod_register_resource(queue, mod_destroy_queue);
	
	convert_pair_list(&plist, pair_list);
	reply = grad_client_send(queue, port_type, request_type, plist);
	
	if (!reply) {
		zend_error(E_ERROR, "No reply from servers");
	}

	reply_code = reply->code;
	if (reply_string) {
		ZVAL_STRING(reply_string, get_reply_message(reply->avlist),
			    0);
	}
	if (reply_pairs) {
		convert_from_pair_list(reply_pairs, reply->avlist);
	}

	grad_avl_free(plist);
	grad_request_free(reply);
	mod_destroy_resource(queue);
	
	RETURN_LONG(reply_code);
}

ZEND_FUNCTION(radius_set_debug)
{
	char           *levels;
	int             levels_len;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC,
				  "s",
				  &levels,
				  &levels_len) == FAILURE)
		return;

	grad_set_debug_levels(levels);
}

ZEND_FUNCTION(radius_clear_debug)
{
	grad_clear_debug();
}

ZEND_FUNCTION(radius_lookup_value)
{
	char           *attribute;
	int             attribute_len;

	char           *return_name;
	grad_dict_value_t *vp;
	int             value;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC,
				  "sl",
				  &attribute,
				  &attribute_len,
				  &value) == FAILURE)
		return;

	vp = grad_value_lookup(value, attribute);
	if (!vp) {
		  RETURN_NULL();
	} 
	RETURN_STRING(vp->name, 1);
}

ZEND_FUNCTION(radius_auth_user)
{
	long            return_code;
	char           *username;
	int             username_len;
	char           *password;
	int             passwd_len;
	zval           *pair_list = NULL;

	grad_server_queue_t *queue;
	grad_avp_t     *plist = NULL, *p;
	grad_request_t *reply;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC,
				  "ss|a",
				  &username,
				  &username_len,
				  &password,
				  &passwd_len,
				  &pair_list) == FAILURE) {
		return;
	}

        /* main auth proc */

	queue = grad_client_create_queue(1, 0, 0);
	mod_register_resource(queue, mod_destroy_queue);
	
	/*      */
	convert_pair_list(&plist, pair_list);
	/* 1. : */
	grad_avl_add_pair(&plist,
			  grad_avp_create_string(DA_USER_NAME, username));
	/* 2. : */
	grad_avl_add_pair(&plist,
			  grad_avp_create_string(DA_USER_PASSWORD,
						 password));

	/*  : */
	reply = grad_client_send(queue, GRAD_PORT_AUTH, RT_ACCESS_REQUEST, plist);

	/*  : */
	if (!reply) {
		zend_printf("No reply from servers");
	}

	switch (reply->code) {
	case RT_ACCESS_ACCEPT:
		return_code = 0;
		break;

	case RT_ACCESS_REJECT:
		return_code = 1;
		break;
		
	default:
		return_code = 1;
		zend_printf("Authentication filed with code %s\n",
			    grad_request_code_to_name(reply->code));
	}

	grad_avl_free(plist);
	grad_request_free(reply);
	mod_destroy_resource(queue);
	RETURN_BOOL(return_code == 0);
}

ZEND_FUNCTION(radius_attribute_type)
{
	char *attrname;
	int attrname_len;
	grad_dict_attr_t *attr;
	int type;
	
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC,
				  "s",
				  &attrname,
				  &attrname_len) == FAILURE) 
		return;

	attr = grad_attr_name_to_dict(attrname);
	if (!attr)
		type = GRAD_TYPE_INVALID;
	else
		type = attr->type;
	RETURN_LONG(type);
}

#ifdef __DEBUG
/* Guess what we're using it for */
wd()
{
	int volatile    _st = 0;

	printf("PID %lu\n", getpid());
	while (!_st)
		sleep(1);
}
#endif

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <ctype.h>
#include <unistd.h>
#include <stdlib.h>
#include <netdb.h>
#include <radlib.h>
#include <radius/argcv.h>

enum ascend_filter_type {
	ascend_filter_generic,      /* 0 */
	ascend_filter_ip,           /* 1 */
	ascend_filter_ipx           /* 2 */
};

/* Maximum compare length for Generic filters. */
#define ASCEND_MAX_CMP_LENGTH 6

enum ascend_filter_cmp_op {
	ascend_cmp_none,
	ascend_cmp_lt,
	ascend_cmp_eq,
	ascend_cmp_gt,
	ascend_cmp_ne
};

/* The format of an IP filter attribute value. Fields are in netorder */
typedef struct {
	grad_uint32_t    src_ip;       /* The source IP address.  */
	grad_uint32_t    dst_ip;       /* The destination IP address.  */
	u_char   src_masklen;  /* The source netmask length */
	u_char   dst_masklen;  /* The destination netmask length */
	u_char   proto;        /* The IP protocol number */
	u_char   established;  /* True if the filter matches only packets
				  with established state of a TCP
				  connection. */
	u_short  src_port;     /* The source port number */
	u_short  dst_port;     /* The destination port number */
	u_char   src_cmp;      /* Comparison operator for source port */
	u_char   dst_cmp;      /* Comparison operator for dest port */
} ASCEND_FILTER_IP;

/* IPX stuff. Not used at the moment */
#define IPX_NODE_ADDR_LEN 6

typedef grad_uint32_t   IPXADDR;
typedef char    IPXNODE[IPX_NODE_ADDR_LEN];
typedef u_short IPXSOCKET;

typedef struct {
	IPXADDR   src_addr;    /* Source IPX Net address */ 
	IPXNODE   src_node;    /* Source IPX Node address */
	IPXSOCKET src_socket;  /* Source IPX socket address */
	IPXADDR   dst_addr;    /* Destination Net address */   
	IPXNODE   dst_node;    /* Destination Node address */  
	IPXSOCKET dst_socket;  /* Destination socket address */
	u_char    src_cmp;     /* Comparison operator for source socket */
	u_char    dst_cmp;     /* Comparison operator for dest socket */
} ASCEND_FILTER_IPX;

/* generic filter */
typedef struct {
	u_short   offset;      /* Offset in the packet to start comparison
				  from */
	u_short   len;         /* Number of bytes to compare */
	u_short   more;        /* If true, the next filter is also to be
				  applied to the packet */
	u_char    mask[ASCEND_MAX_CMP_LENGTH];
                               /* A bitmask specifying the bits to compare */
	        
	u_char    value[ASCEND_MAX_CMP_LENGTH];
                               /* A value to compare against the masked
				  bits in the packet */
	u_char    neq;         /* True if comparison op is != */
} ASCEND_FILTER_GENERIC;

typedef struct {
	u_char type;           /* Filter type from ascend_filter_type */ 
	u_char forward;        /* True if the matching packet is to be
				  forwarded. */
	u_char input;          /* True if this is an input filter */
	u_char unused;
	union {                /* A filter itself: */
		ASCEND_FILTER_IP  ip;
		ASCEND_FILTER_IPX ipx;
		ASCEND_FILTER_GENERIC generic;
		u_char fill[26];
	} v;
} ASCEND_FILTER;


struct ascend_parse_buf {
	int tokc;        /* Number of tokens */
	char **tokv;     /* List of tokens */
	int tokn;        /* Index of the current token */
	ASCEND_FILTER *flt; /* Pointer to filter structure to be filled */
	char **errmsg;   /* Error message */
};

/* Error printing */
static void
ascend_errprint(struct ascend_parse_buf *pb, const char *msg, const char *arg)
{
	if (arg)
		grad_astrcat(pb->errmsg, msg, ": ", arg);
	else
		grad_astrcat(pb->errmsg, msg);
}

static void
ascend_errprints(struct ascend_parse_buf *pb, const char *fmt, const char *arg)
{
	size_t size = strlen(fmt) + strlen(arg) + 1;
	*pb->errmsg = malloc(size);
	if (*pb->errmsg)
		sprintf(*pb->errmsg, fmt, arg);
}

/* generic (more or less) calls */
#define _moreinput(pb) ((pb)->tokn < (pb)->tokc)

static char *
_get_token(struct ascend_parse_buf *pb, int require)
{
	if (!_moreinput(pb)) {
		if (require) {
			ascend_errprint(pb, _("Unexpected end of string"),
					NULL);
			return NULL;
		}
		return NULL;
	}
	return pb->tokv[pb->tokn++];
}

static char *
_lookahead(struct ascend_parse_buf *pb)
{
	if (_moreinput(pb))
		return pb->tokv[pb->tokn];
	return NULL;
}


static int
_get_type(struct ascend_parse_buf *pb)
{
	char *tok = _get_token(pb, 1);
	if (!tok)
		return 1;
	if (strcmp(tok, "ip") == 0)
		pb->flt->type = ascend_filter_ip;
	else if (strcmp(tok, "ipx") == 0)
		pb->flt->type = ascend_filter_ip;
	else if (strcmp(tok, "generic") == 0)
		pb->flt->type = ascend_filter_generic;
	else {
		ascend_errprint(pb, _("Unknown filter type"), tok);
		return 1;
	}
	return 0;
}

static int
_get_dir(struct ascend_parse_buf *pb)
{
	char *tok;
	if ((tok = _get_token(pb, 1)) == NULL)
		return 1;
	if (strcmp(tok, "in") == 0)
		pb->flt->input = 1;
	else if (strcmp(tok, "out") == 0)
		pb->flt->input = 0;
	else {
		ascend_errprint(pb, _("Invalid direction"), NULL);
		return 1;
	}
	return 0;
}

static int
_get_action(struct ascend_parse_buf *pb)
{
	char *tok;
	if ((tok = _get_token(pb, 1)) == NULL)
		return 1;
	if (strcmp(tok, "forward") == 0)
		pb->flt->forward = 1;
	else if (strcmp(tok, "drop") == 0)
		pb->flt->forward = 0;
	else {
		ascend_errprint(pb, _("Unknown action"), tok);
		return 1;
	}
	return 0;
}

/* ************************************************************************* */
/* GENERIC filter parsing */

static int
_get_hex_string(struct ascend_parse_buf *pb, u_char *buf)
{
	u_char tmp[2*ASCEND_MAX_CMP_LENGTH], *p;
	char *tok = _get_token(pb, 1);
	int len, rc, i;
	
	if (!tok)
		return -1;

	len = strlen(tok);
	if (len > 2*ASCEND_MAX_CMP_LENGTH) {
		ascend_errprint(pb, _("Octet string too long"), NULL);
		return -1;
	}

	rc = len / 2;
	if (len % 2)
		rc++;

	memset(tmp, 0, sizeof tmp);

	for (p = tmp; len; len--, p++, tok++) {
		if (*tok >= 0 && *tok <= 9)
			*p = *tok - '0';
		else if (isxdigit(*tok)) {
			if (*tok > 'Z')
				*p = *tok - 'a' + 10;
			else
				*p = *tok - 'A' + 10;
		} else {
			ascend_errprints(pb,
					 _("Invalid hex character (near %s)"),
					 tok);
			return -1;
		}
	}

	for (i = 0; i < 2*ASCEND_MAX_CMP_LENGTH; i++)
		*buf++ = (tmp[i] << 4) | tmp[i+1];
	return rc;
}

/* Generic filter is:

  "generic" dir action offset mask ["=="|"!="] value [ "more" ]
  where dir    is {"in"|"out"}
        action is {"forward"|"drop"}
	offset is number
	mask and value are hex strings */
   
static int
_ascend_parse_generic(struct ascend_parse_buf *pb)
{
	char *p;
	int num;
	char *tok = _get_token(pb, 1);
	int len;
	
	if (!tok)
		return 1;
	num = strtoul(tok, &p, 0);
	if (*p) {
		ascend_errprint(pb, _("Invalid offset"), tok);
		return 1;
	}
	pb->flt->v.generic.offset = ntohs(num);
	if ((len = _get_hex_string(pb, pb->flt->v.generic.mask)) < 0)
		return 1;
	pb->flt->v.generic.len = htons(len);

	tok = _lookahead(pb);
	if (!tok) 
		return 1;

	if (strcmp(tok, "==") == 0) {
		pb->flt->v.generic.neq = 0;
		_get_token(pb, 1);
	} else if (strcmp(tok, "!=") == 0) {
		pb->flt->v.generic.neq = 1;
		_get_token(pb, 1);
	}
	
	if ((num = _get_hex_string(pb, pb->flt->v.generic.value)) < 0)
		return 1;
	if (num != len) {
		ascend_errprint(pb, _("Value and mask are not of same size"),
				NULL);
		return 1;
	}
	
	tok = _get_token(pb, 0);
	if (!tok)
		return 0;

	if (strcmp(tok, "more") == 0)
		pb->flt->v.generic.more = 1;
	else {
		ascend_errprints(pb,
				 _("Expected `more', but found `%s'"),
				 tok);
		return 1;
	}
	return 0;
}


/* ************************************************************************* */
/* IP filter parsing */
static int
_get_protocol(struct ascend_parse_buf *pb)
{
	char *tok = _get_token(pb, 1);
	char *p;
	int num;
	
	num = strtoul(tok, &p, 0);
	if (*p == 0) 
		pb->flt->v.ip.proto = num;
	else {
		/* Try /etc/protocols */
		struct protoent *p = getprotobyname(tok);
		if (!p) {
			ascend_errprint(pb, _("Unknown protocol"), tok);
			return 1;
		}
		pb->flt->v.ip.proto = p->p_proto;
	}
	return 0;
}

#define ASCEND_DIR_NONE -1
#define ASCEND_DIR_SRC 0
#define ASCEND_DIR_DST 1

static int
_get_direction_type(struct ascend_parse_buf *pb, char *suffix, int lookahead)
{
	char *tok = lookahead ? _lookahead(pb) : _get_token(pb, 1);

	if (!tok && lookahead) 
		return ASCEND_DIR_NONE;
	if (tok && strlen(tok) > 3 && strcmp(tok+3, suffix) == 0) {
		if (strncmp(tok, "dst", 3) == 0)
			return ASCEND_DIR_DST;
		else if (strncmp(tok, "src", 3) == 0)
			return ASCEND_DIR_SRC;
	}
	if (!lookahead)
		ascend_errprints(pb,
				 _("Expected `{src|dst}port', but found `%s'"),
				 tok);
	return ASCEND_DIR_NONE;
}


static int
_get_ip(struct ascend_parse_buf *pb)
{
	int dir = _get_direction_type(pb, "ip", 0);
	char *tok;
	grad_uint32_t ip, mask;
	
	if (dir == ASCEND_DIR_NONE)
		return ASCEND_DIR_NONE;
	tok = _get_token(pb, 1);
	if (!tok)
		return ASCEND_DIR_NONE;
	ip = grad_ip_strtoip(tok); /*FIXME: no error checking */

	if (_moreinput(pb) && _lookahead(pb)[0] == '/') {
		char *p;
		
		_get_token(pb, 1);
		tok = _get_token(pb, 1);
		if (!tok)
			return ASCEND_DIR_NONE;
		mask = strtoul(tok, &p, 0);
		if (*p || mask > 32) {
			ascend_errprint(pb, _("Invalid netmask length"), tok);
			return ASCEND_DIR_NONE;
		}
	} else
		mask = 32;

	ip = htonl(ip);
	switch (dir) {
	case ASCEND_DIR_SRC:
		pb->flt->v.ip.src_ip = ip;
		pb->flt->v.ip.src_masklen = mask;
		break;
		
	case ASCEND_DIR_DST:
		pb->flt->v.ip.dst_ip = ip;
		pb->flt->v.ip.dst_masklen = mask;
		break;
	}
	return dir;
}


