package org.esfinge.business.security;

import org.esfinge.business.security.credential.UserCredential;
import org.esfinge.domain.Report;


public class DefaultSecurityProvider extends SecurityProvider {

	@Override
	public UserCredential authenticate(UserCredential credential) {
		return credential;
	}

	@Override
	public boolean authorizeAction(UserCredential credential, Object domain, String actionName) {
		return true;
	}

	@Override
	public boolean authorizeReport(UserCredential credential, Report report) {
		return true;
	}

	@Override
	public void sessionFinish(UserCredential credential) {
	}

}
package org.esfinge.business.security.credential;

import org.esfinge.business.security.SecurityProvider;
import org.esfinge.exception.ApplicationException;
import org.esfinge.exception.AuthenticationException;


public class SingleCredentialProvider extends CredentialProvider {

	private static UserCredential registeredCredential;
	
	public void registerCredential(UserCredential credential) throws ApplicationException,AuthenticationException{
		registeredCredential = SecurityProvider.getProvider().authenticate(credential);
	}

	public UserCredential getCredential() {
		return registeredCredential;
	}

	@Override
	public void removeCredential() throws ApplicationException {
		SecurityProvider.getProvider().sessionFinish(registeredCredential);
		registeredCredential = null;
	}

}
 public Object getObjById(Object obj, UserCredential credential) throws ApplicationException{
		  try {
			CredentialProvider.getProvider().registerCredential(credential);
			return crudBusiness.getObjById(obj);
		} catch (ApplicationException e) {
			if(e.isRollbackTransaction())
				context.setRollbackOnly();
			throw e;
		} 
	  }
		
		/** 
		 * <!-- begin-xdoclet-definition --> 
		 * @ejb.interface-method view-type="remote"
		 * @ejb.transaction type = "Required"
		 * <!-- end-xdoclet-definition --> 
		 */
		public Object getCompleteObjById(Object obj, UserCredential credential) throws ApplicationException{
			try {
				CredentialProvider.getProvider().registerCredential(credential);
				return crudBusiness.getCompleteObjById(obj);
			} catch (ApplicationException e) {
				if(e.isRollbackTransaction())
					context.setRollbackOnly();
				throw e;
			} 
		}
		
		/** 
		 * <!-- begin-xdoclet-definition --> 
		 * @throws ApplicationException 
		 * @ejb.interface-method view-type="remote"
		 * @ejb.transaction type = "Required"
		 * <!-- end-xdoclet-definition --> 
		 */
		public Object insert(Object obj, UserCredential credential) throws ApplicationException {
			try {
				CredentialProvider.getProvider().registerCredential(credential);
				return crudBusiness.insert(obj);
			} catch (ApplicationException e) {
				if(e.isRollbackTransaction())
					context.setRollbackOnly();
				throw e;
			}
		}
		
		/** 
		 * <!-- begin-xdoclet-definition --> 
		 * @ejb.interface-method view-type="remote"
		 * @ejb.transaction type = "Required"
		 * <!-- end-xdoclet-definition --> 
		 */
		public void update(Object obj, UserCredential credential) throws ApplicationException {
			try {
				CredentialProvider.getProvider().registerCredential(credential);
				crudBusiness.update(obj);
			} catch (ApplicationException e) {
				if(e.isRollbackTransaction())
					context.setRollbackOnly();
				throw e;
			}
		}
		
		/** 
		 * <!-- begin-xdoclet-definition --> 
		 * @ejb.interface-method view-type="remote"
		 * @ejb.transaction type = "Required"
		 * <!-- end-xdoclet-definition --> 
		 */
		public void delete(Object obj, UserCredential credential) throws ApplicationException{
			try {
				CredentialProvider.getProvider().registerCredential(credential);
				crudBusiness.delete(obj);
			} catch (ApplicationException e) {
				if(e.isRollbackTransaction())
					context.setRollbackOnly();
				throw e;
			}
		}
		
		/** 
		 * <!-- begin-xdoclet-definition --> 
		 * @ejb.interface-method view-type="remote"
		 * @ejb.transaction type = "Required"
		 * <!-- end-xdoclet-definition --> 
		 */
		public List getList(Object obj, UserCredential credential) throws ApplicationException{
			try {
				CredentialProvider.getProvider().registerCredential(credential);
				return crudBusiness.getList(obj);
			} catch (ApplicationException e) {
				if(e.isRollbackTransaction())
					context.setRollbackOnly();
				throw e;
			} 
		}
		
		/** 
		 * <!-- begin-xdoclet-definition --> 
		 * @ejb.interface-method view-type="remote"
		 * @ejb.transaction type = "Required"
		 * <!-- end-xdoclet-definition --> 
		 */
		public List search(Object obj, UserCredential credential) throws ApplicationException{
			try {
				CredentialProvider.getProvider().registerCredential(credential);
				return crudBusiness.search(obj);
			} catch (ApplicationException e) {
				if(e.isRollbackTransaction())
					context.setRollbackOnly();
				throw e;
			} 
		}
		
		/** 
		 * <!-- begin-xdoclet-definition --> 
		 * @ejb.interface-method view-type="remote"
		 * @ejb.transaction type = "Required"
		 * <!-- end-xdoclet-definition --> 
		 */
		public Object executeGenericAction(Object obj, String actionName, UserCredential credential) throws ApplicationException{
			try {
				CredentialProvider.getProvider().registerCredential(credential);
				return crudBusiness.executeGenericAction(obj,actionName);
			} catch (ApplicationException e) {
				if(e.isRollbackTransaction())
					context.setRollbackOnly();
				throw e;
			}
