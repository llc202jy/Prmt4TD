namespace SSOBase1
{    
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    
    public class Authenticator : System.Web.Services.WebService
    {
        string _userId;
        public Authenticator(string UserId)
        {
            _userId = UserId;
        }

        [WebMethod]
        public bool AuthenticateUser(string password)
        {            
            SSODBDataContext db = new SSODBDataContext();
            var psw = (from c in db.MainAppCredentials
                      where c.Userid == _userId
                      select c.Password).ToList();
            string strPsw = psw[0].ToString();
            return strPsw == password ? true : false;                    
        }

        [WebMethod]
        public DataTable GetAppAccessDetails()
        {
            SSODBDataContext db = new SSODBDataContext();
            var results=(from a in db.Apps
                             join ua in db.UserAppMaps on a.AppId equals ua.AppId
                             where ua.MUserId == _userId
                             select a).ToList();
            
            DataTable dtRes=new DataTable();
            dtRes.Columns.Add("ApplicationName");        
            dtRes.Columns.Add("ApplicationURL");
            foreach(var c in results)
            {
                DataRow dr=dtRes.NewRow();
                dr[0]=c.AppName;
                dr[1]=c.AppUrl;
                dtRes.Rows.Add(dr);
            }
            return dtRes;
        }

        [WebMethod]
        public string AuthenticateClientUrl(string clientUrl)
        {
            return clientUrl + "?UserId=" + _userId + 
                     "&IsAuthenticatedBySSO=1";
        }

    }
}

Client Home Page
Collapse | Copy Code

namespace SSOTestClientApp1
{
    public partial class Client1MainPage : System.Web.UI.Page
    {
        string struser;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["UserId"] == null && 
                      Session["FromClient1Login"] == null)
                FormsAuthentication.RedirectToLoginPage();
            else
            {
                if (Session["FromClient1Login"] != null)
                {
                    struser = Session["Userid"].ToString();
                    lblMessage.Text = "Welcome " + struser + 
                      System.Environment.NewLine + " This Login is from Client 1 login";
                }
                else if (Request.QueryString["IsAuthenticatedBySSO"].ToString()== "1")
                {
                    struser = Request.QueryString["UserId"].ToString();
                    SSOClient1DBDataContext db = new SSOClient1DBDataContext();
                    var _appSpecificUserName = (from u in db.Client1Maps
                                                where u.MainAppUserId == struser
                                                select u.C1AppUserId).ToList();
                    struser = _appSpecificUserName[0].ToString();
                    lblMessage.Text = "Welcome " + struser + 
                      System.Environment.NewLine + " This Login is from SSO";
                }
            }
        }
    }
}
namespace SSOBase1
{
    public partial class MainAppPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserId"] == null)                
                FormsAuthentication.RedirectToLoginPage();
            else
            {

                string _userId = Session["UserId"].ToString();
                lblMessage.Text = "Welcome " + _userId + " to Main Application.";
                Authenticator svc = new Authenticator(_userId);
                DataTable dtResult = svc.GetAppAccessDetails();
                foreach (DataRow dr in dtResult.Rows)
                {
                    HyperLink _hyperlink = new HyperLink();
                    _hyperlink.Text = dr["ApplicationName"].ToString();
                    _hyperlink.NavigateUrl = svc.AuthenticateClientUrl(dr["ApplicationURL"].ToString());
                    divLinks.Controls.Add(_hyperlink);
                    divLinks.Controls.Add(new LiteralControl("<BR>"));
                }
            }
        }
    }
}