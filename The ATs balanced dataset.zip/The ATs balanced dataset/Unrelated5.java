#ifndef INCLUDED_SharedObject_h
#define INCLUDED_SharedObject_h

#include "RCRegion.h"
#include <stdexcept>

//! It's nice to have a parent class of SharedObject (which is what you probably want to be reading) so that you can pass around the data structure without worrying about what type is inside the shared memory region.
/*! See MotionManager for an example on how to use this. */
class SharedObjectBase {
public:
	void* data() const { return rcr->Base(); } //!< returns a pointer to the data region
	RCRegion * getRegion() const { return rcr; } //!< returns the OPEN-R memory region, should you need it
	
	virtual ~SharedObjectBase() {} //!< destructor
	
#ifndef PLATFORM_APERIOS
	//! return the next region serial number -- doesn't actually increment it though, repeated calls will return the same value until the value is actually used
	static unsigned int getNextKey() { return serialNumber+1; }
#endif

protected:
	//! constructor, protected because you shouldn't need to create this directly, just a common interface to all templates of SharedObject
	SharedObjectBase() : rcr(NULL) {}
	//! copy constructor, adds a reference to the existing region (shallow copy)
	SharedObjectBase(const SharedObjectBase& sob) : rcr(sob.rcr) {
		rcr->AddReference();
	}
	//! assignment, adds a reference to the existing region (shallow copy)
	SharedObjectBase& operator=(const SharedObjectBase& sob) {
		if(rcr==sob.rcr)
			return *this;
		removeRef();
		rcr=sob.rcr;
		rcr->AddReference();
	}

	//!removes a reference from #rcr, and if necessary, destructs its data
	virtual void removeRef()=0;
	
	RCRegion * rcr; //!< the pointer to the shared memory region this is in charge of
	
#ifndef PLATFORM_APERIOS
	static unsigned int serialNumber;
#endif
};	


//! This templated class allows convenient creation of any type of class wrapped in a shared memory region
/*! @see MotionManager for an example on how to use this.*/
template<class MC>
class SharedObject : public SharedObjectBase {
public:
	//!if you really need more than 5 arguments for your class, well, you're one crazy puppy but if you really want to, just make more like shown... (yay templates!)
	//!@name templated contructors - allows you to pass constructor arguments on to the object being created

	//! Creates the class with the default constructor
	SharedObject() : SharedObjectBase() {
		rcr=createRCRegion();
		new (rcr->Base()) MC;
	}
	//! Creates the class, passing its constructor t1
	template<class T1> explicit SharedObject(const T1& t1) : SharedObjectBase() {
		rcr=createRCRegion();
		new (rcr->Base()) MC(t1);
	}
	//! Creates the class, passing its constructor t1 and t2
	template<class T1, class T2> SharedObject(const T1& t1, const T2& t2) : SharedObjectBase(){
		rcr=createRCRegion();
		new (rcr->Base()) MC(t1,t2);
	}
	//! Creates the class, passing its constructor t1, t2, and t3
	template<class T1, class T2, class T3> SharedObject(const T1& t1, const T2& t2, const T3& t3) : SharedObjectBase(){
		rcr=createRCRegion();
		new (rcr->Base()) MC(t1,t2,t3);
	}
	//! Creates the class, passing its constructor t1, t2, t3 and t4
	template<class T1, class T2, class T3, class T4> SharedObject(const T1& t1, const T2& t2, const T3& t3, const T4& t4) : SharedObjectBase(){
		rcr=createRCRegion();
		new (rcr->Base()) MC(t1,t2,t3,t4);
	}
	//! Creates the class, passing its constructor t1, t2, t3, t4 and t5 - if you need more arguments, just add them
	template<class T1, class T2, class T3, class T4, class T5> SharedObject(const T1& t1, const T2& t2, const T3& t3, const T4& t4, const T5& t5) : SharedObjectBase(){
		rcr=createRCRegion();
		new (rcr->Base()) MC(t1,t2,t3,t4,t5);
	}

	//! Constructs from a pre-existing region, laying claim to the caller's reference to the region - region's creator is responsible for initialization
	/*! In other words, this SharedObject doesn't AddReference, but will
	 *  RemoveReference when the time is right (upon destruction).  If
	 *  you want to maintain an reference of your own to the region, you
	 *  will need to call AddReference yourself. */
	explicit SharedObject(RCRegion * r) : SharedObjectBase() {
		rcr=r;
		if(rcr->Size()!=sizeof(MC)) {
#ifdef PLATFORM_APERIOS
			std::cerr << "ERROR: SharedObject(RCRegion* r) region size ("<<rcr->Size()<<") does not match size of SharedObject type ("<<sizeof(MC)<<")" << std::endl;
#else
			std::cerr << "ERROR: SharedObject(RCRegion* r) region "<<rcr->ID().key<<" size ("<<rcr->Size()<<") does not match size of SharedObject type ("<<sizeof(MC)<<")" << std::endl;
#endif
			throw std::invalid_argument("SharedObject(RCRegion* r): region size does not match sizeof(type)");
		}
	}
	//@}
	
	//! destructor, removes reference to shared region
	virtual ~SharedObject() { removeRef(); }
	
	MC* operator->() const { return dataCasted(); } //!< smart pointer to the underlying class
	MC& operator*() const { return *dataCasted(); } //!< smart pointer to the underlying class
	MC& operator[](int i) const { return dataCasted()[i]; } //!< smart pointer to the underlying class

protected:
	MC* dataCasted() const { return static_cast<MC*>(data()); } //!< returns a correctly typed pointer to the object's memory
	
	//!removes a reference from #rcr, and if necessary, destructs its data
	virtual void removeRef() {
		if(rcr) {
			//std::cout << "~SharedObjectBase(): rcr->NumberOfReference()==" << rcr->NumberOfReference() << std::endl;
			if(rcr->NumberOfReference()>0) {
				if(rcr->NumberOfReference()==1)
					dataCasted()->~MC(); //call destructor
				rcr->RemoveReference();
			} else
				std::cerr << "WARNING: SharedObjectBase destructed without reference" << std::endl;
			rcr=NULL;
		}
	}
	
	//! creates and returns RCRegion of correct size for current class.  Adds a reference (which is removed in the destructor)
	static RCRegion * createRCRegion() {
#ifdef PLATFORM_APERIOS
		RCRegion * r = new RCRegion(calcsize());
#else
		char name[RCRegion::MAX_NAME_LEN];
		unsigned int suffixlen=snprintf(name,RCRegion::MAX_NAME_LEN,".%d.%d",ProcessID::getID(),++serialNumber);
		if(suffixlen>RCRegion::MAX_NAME_LEN)
			suffixlen=RCRegion::MAX_NAME_LEN;
		snprintf(name,RCRegion::MAX_NAME_LEN,"Sh.%.*s.%d.%d",RCRegion::MAX_NAME_LEN-suffixlen-3,typeid(MC).name(),ProcessID::getID(),++serialNumber);
		name[RCRegion::MAX_NAME_LEN-1]='\0';
		RCRegion * r = new RCRegion(name,calcsize());
#endif
		//cout << "SIZE is " << r->Size() << endl;
		//cout << "BASE is " << (void*)r->Base() << endl;
		//std::cout << "createRCRegion(): rcr->NumberOfReference()==" << r->NumberOfReference() << std::endl;
		//r->AddReference();
		//std::cout << "createRCRegion()NOW: rcr->NumberOfReference()==" << r->NumberOfReference() << std::endl;
		return r;
	}

	//!Calculates the size of the memory region to be used, (on Aperios, rounding up to the nearest page size)
	/*! Not sure this is completely necessary, but may be nice.  Of course, this also means even
	 *  small regions are going to be at least 4K (current page size)  If memory gets tight or we
	 *  get a lot of little regions floating around, this might be worth checking into */
	static unsigned int calcsize() {
#ifndef PLATFORM_APERIOS
		return sizeof(MC);
#else
		size_t size = sizeof(MC);
		sError error;
		size_t page_size;
		error = GetPageSize(&page_size);
		if (error != sSUCCESS) {
			cout << "error: " << error << " getting page size in SharedMem" << endl;
			page_size = 4096;
		}
		
		int new_size,num_pages;
		num_pages = (size+page_size-1)/page_size;
		new_size = num_pages*page_size;
		//cout << "req" << size << "new" << new_size << "ps" << page_size << endl;
		/*
		cout << "data size is " << sizeof(MC) << endl;
		cout << "PAGE is " << page_size << endl;
		cout << "reserved " << new_size << " bytes" << endl;
		*/
		return new_size;
#endif //!PLATFORM_APERIOS
	}
};

/*! @file
 * @brief Defines SharedObject, a wrapper for objects in order to facilitate sending them between processes
 * @author ejt (Creator)
 *
 * $Author: ejt $
 * $Name:  $
 * $Revision: 1.7 $
 * $State: Exp $
 * $Date: 2006/09/16 20:11:52 $
 */

#endif //INCLUDED_SharedObject_h
#ifndef PLATFORM_APERIOS
#include "MessageQueueStatusThread.h"
#include "MessageQueue.h"
#include "Shared/debuget.h"
#include <algorithm>

using namespace std; 

MessageQueueStatusThread::~MessageQueueStatusThread() {
	if(isRunning()) {
		stop();
		//join(); // join turns out to be a bad idea here -- the thread being stopped may be waiting on a lock we currently hold
	}
}

void MessageQueueStatusThread::addStatusListener(StatusListener* l) {
	if(l==NULL)
		return;
	if(find(statusListeners.begin(),statusListeners.end(),l)==statusListeners.end()) {
		//not already added
		statusListeners.push_back(l);
		if(!isRunning()) {
			if(queue==NULL)
				return;
			semid=queue->addReadStatusListener();
			if(semid==queue->getSemaphoreManager()->invalid()) {
				std::cerr << "ERROR: could not start MessageQueueStatusThread -- out of semaphore IDs" << std::endl;
				return;
			}
			//cout << "MessageQueueStatusThread added MessageQueue read listener" << endl;
			numRead=queue->getMessagesRead();
			start();
		}
	}
}

void MessageQueueStatusThread::removeStatusListener(StatusListener* l) {
	std::list<StatusListener*>::iterator it=find(statusListeners.begin(),statusListeners.end(),l);
	if(it!=statusListeners.end())
		statusListeners.erase(it);
	if(isRunning() && statusListeners.size()==0) {
		stop();
		//join(); // join turns out to be a bad idea here -- the thread being stopped may be waiting on a lock we currently hold
	}
}

void MessageQueueStatusThread::setMessageQueue(MessageQueueBase& mq) {
	if(running) {
		stop();
		//join(); // join turns out to be a bad idea here -- the thread being stopped may be waiting on a lock we currently hold
	}
	queue=&mq;
	if(statusListeners.size()!=0)
		start();
	/*
	MessageQueueBase* oldqueue=queue;
	SemaphoreManager::semid_t oldsem=semid;
	queue=&mq;
	semid=queue->addReadStatusListener();
	if(semid==queue->getSemaphoreManager()->invalid()) {
		std::cerr << "ERROR: could not switch MessageQueue -- new queue out of semaphores, stopping thread" << std::endl;
		queue=oldqueue;
		semid=oldsem;
		if(running)
			stop();
		return;
	}
	numRead=queue->getMessagesRead();
	if(oldqueue!=NULL && oldsem!=queue->getSemaphoreManager()->invalid()) {
		if(running)
			oldqueue->getSemaphoreManager()->raise(oldsem,1); //so run will notice the switchover
		oldqueue->removeReadStatusListener(oldsem);
	}*/
}

MessageQueueBase* MessageQueueStatusThread::getMessageQueue() {
	return queue;
}

bool MessageQueueStatusThread::launched() {
	return Thread::launched();
}

void * MessageQueueStatusThread::run() {
	for(;;) {
		queue->getSemaphoreManager()->lower(semid,1,true);
		//there might be a few reads, handle them as a group
		unsigned int more=queue->getSemaphoreManager()->getValue(semid);
		if(more>0)
			if(!queue->getSemaphoreManager()->lower(semid,more,false))
				std::cerr << "WARNING: MessageQueueStatusThread had a message notification disappear (is someone else using the semaphore?  Get your own!)" << std::endl;
		testCancel();
#ifdef DEBUG
		// This part just for sanity checking -- could do away with numRead altogether otherwise
		unsigned int nowRead=queue->getMessagesRead();
		unsigned int read=nowRead-numRead;
		numRead=nowRead;
		ASSERT(read==more+1,"WARNING: MessageQueueStatusThread's semaphore count does not match queue's read count ("<< (more+1) << " vs " << read<<")");
#endif
		//ok, notify the listeners
		fireMessagesRead(more+1);
	}
	return NULL; // not going to happen, just to make compiler happy
}

void MessageQueueStatusThread::stop() {
	Thread::stop();
	if(semid!=queue->getSemaphoreManager()->invalid()) //if semid is still invalid, probably canceling before the launch got off
		queue->getSemaphoreManager()->raise(semid,1); //so run will notice the stop request
}

void MessageQueueStatusThread::cancelled() {
	if(queue==NULL)
		return;
	//cout << "MessageQueueStatusThread removing MessageQueue read listener" << endl;
	queue->removeReadStatusListener(semid);
	semid=queue->getSemaphoreManager()->invalid();
}

void MessageQueueStatusThread::fireMessagesRead(unsigned int howmany) {
	if(howmany==0)
		return;
	std::list<StatusListener*>::iterator it=statusListeners.begin();
	while(it!=statusListeners.end()) {
		std::list<StatusListener*>::iterator cur=it++; //increment early in case the listener changes subscription
		(*cur)->messagesRead(*queue,howmany);
	}
}


/*! @file
 * @brief 
 * @author Ethan Tira-Thompson (ejt) (Creator)
 *
 * $Author: ejt $
 * $Name:  $
 * $Revision: 1.9 $
 * $State: Exp $
 * $Date: 2007/03/15 05:01:43 $
 */
//-*-c++-*-
#ifndef INCLUDED_SemaphoreManager_h_
#define INCLUDED_SemaphoreManager_h_

#ifdef PLATFORM_APERIOS
#  warning SemaphoreManager is not Aperios compatable, this is not going to compile
#else

#include "ListMemBuf.h"
#include "Shared/attributes.h"

#ifndef SYSTEM_MAX_SEM
//! Ideally, this would be SEMMSL, but that is hard to portably determine at compile time
/*! If you can't increase your system's SEMMSL (and possibly SEMMNS), you
 *  may want to consider decreasing this. */
#define SYSTEM_MAX_SEM 250
#endif

//! initializes, manages, and releases a set of System V style semaphores
/*! Should be initialized pre-fork into a shared region */
class SemaphoreManager {
protected:
	typedef ListMemBuf<bool,SYSTEM_MAX_SEM> sems_t; //!< shorthand for the type of #sems
	
public:
	//! wouldn't want to claim the entire system's worth, even if we could
	static const unsigned int MAX_SEM=SYSTEM_MAX_SEM;

	//! shorthand for the semaphore indexing type
	typedef sems_t::index_t semid_t;
	//! specify options for how to handle EINTR (signal occurred) error condition during a semaphore operation, see setInterruptPolicy()
	enum IntrPolicy_t {
		INTR_CANCEL_VERBOSE, //!< give up, return failure, display error message on console
		INTR_CANCEL, //!< give up, return failure
		INTR_RETRY_VERBOSE, //!< just repeat semaphore operation, display error message on console
		INTR_RETRY, //!< just repeat semaphore operation
		INTR_THROW_VERBOSE, //!< throw a std::runtime_error exception, display error message on console
		INTR_THROW, //!< throw a std::runtime_error exception
		INTR_EXIT, //!< kill process, with error message
	};
	
	//! Creates a SemaphoreManager with room for sems_t::MAX_ENTRIES entries
	/*! 2 of these entries are reserved for internal use, so user code
	 *  will actually only have access to sems_t::MAX_ENTRIES-2 entries.
	 *  Use available() to determine this value at runtime. */
	SemaphoreManager();
	
	//! Creates a SemaphoreManager with room for @a numRequest entries
	/*! adds 2 for SemaphoreManager's own reference count and mutex lock,
	 *  so you'll actually have @a numRequest semaphores available */
	explicit SemaphoreManager(unsigned int numRequest);
	
	SemaphoreManager(const SemaphoreManager& mm); //!< copy supported
	SemaphoreManager& operator=(const SemaphoreManager& mm); //!< assignment supported
	~SemaphoreManager(); //!< destructor
	
	//! call this on semaphores in shared memory regions if a fork is about to occur so reference counts can be updated for the other process
	void aboutToFork();
	//! call this if semaphores need to be released during an emergency shutdown (otherwise semaphore sets can leak past process shutdown -- bad system design IMHO!)
	void faultShutdown();
	//! returns true if #semid is invalid, indicating further semaphore operations are bogus
	bool hadFault() const { return semid==-1; }

	//! returns a new semaphore id, or invalid() if none are available
	semid_t getSemaphore() ATTR_must_check;
	//! marks a semaphore as available for reassignment
	void releaseSemaphore(semid_t id); 

	//! return the semaphore's interrupt policy (doesn't check @a id validity)
	IntrPolicy_t getInterruptPolicy(semid_t id) const { return intrPolicy[id]; }
	//! set the semaphore's interrupt policy (doesn't check @a id validity)
	void setInterruptPolicy(semid_t id, IntrPolicy_t p) { intrPolicy[id]=p; }
	
	//! lowers a semaphore's value by @a x, optionally blocking if the value would go negative until it is raised enough to succeed
	/*! returns true if the semaphore was successfully lowered.*/
	bool lower(semid_t id, unsigned int x, bool block=true) const;
	//! raises a semaphore's value by @a x
	void raise(semid_t id, unsigned int x) const;

	int getValue(semid_t id) const; //!< returns the semaphore's value
	void setValue(semid_t id, int x) const; //!< sets the semaphore's value
	
	//! tests if the semaphore's value is zero, optionally blocking until it is
	/*! returns true if the semaphore's value is zero.
	 *  @see testZero_add(), add_testZero() */
	bool testZero(semid_t id, bool block=true) const;
	//! tests if the semaphore's value is zero, optionally blocking until it is, and then adding @a x
	/*! If @a x is negative, then @a addblock will cause it to block
	 *  again until someone else raises the semaphore.  Otherwise, the
	 *  add should be performed as an atomic unit with the test.  If @a
	 *  x is non-negative, then the add should never block.
	 *  @see add_testZero(), testZero() */
	bool testZero_add(semid_t id, unsigned int x, bool testblock=true, bool addblock=true) const;
	//! adds @a x to the semaphore's value, optionally blocking in the case that @a x is negative and larger than the semaphore's value.  After adding, test whether the semaphore is zero, optionally blocking again until it is.
	/*! If no blocking is required (e.g. @a x is positive) then the add
	 *  and test should be an atomic pair.
	 *  @see testZero_add(), testZero() */
	bool add_testZero(semid_t id, unsigned int x, bool addblock=true, bool testblock=true) const;
	
	//! returns the number of semaphores currently available in the set
	unsigned int available() const { return sems_t::MAX_ENTRIES-sems.size(); }
	//! returns the number of semaphores which have been used
	/*! the SemaphoreManager requires 2 semaphores from the set, one for
	 *  reference counting and one for mutual exclusion during function
	 *  calls */
	unsigned int used() const { return sems.size()-(sems_t::MAX_ENTRIES-nsem); }
	//! returns the "invalid" id value, for testing against getSemaphore
	semid_t invalid() const { return sems.end(); }

protected:
	void init(); //!< basic initialization called by the constructor -- don't call twice

	sems_t sems; //!< tracks which semaphores have been handed out; the bool value isn't actually used
	unsigned int nsem; //!< number of real semaphores in the set obtained from the system
	int semid; //!< the system's identifier for the set
	semid_t mysem; //!< a lock semaphore for management operations on the set (handing out or taking back semaphores from clients)
	semid_t refc; //!< a reference count of this semaphore set -- when it goes back to 0, the set is released from the system
	IntrPolicy_t intrPolicy[sems_t::MAX_ENTRIES]; //!< interrupt policy for each semaphore
};

/*! @file
 * @brief Defines SemaphoreManager, which initializes, manages, and releases a set of System V style semaphores
 * @author ejt (Creator)
 *
 * $Author: ejt $
 * $Name:  $
 * $Revision: 1.13 $
 * $State: Exp $
 * $Date: 2007/03/17 17:06:25 $
 */

#endif //Aperios check

#endif //INCLUDED

