package com.otv.task;
02	  
03	import org.apache.log4j.Logger;
04	  
05	/**
06	 * First Task
07	 *
08	 * @author  onlinetechvision.com
09	 * @since   24 Feb 2012
10	 * @version 1.0.0
11	 *
12	 */
13	public class FirstTask {
14	  
15	    private static Logger log = Logger.getLogger(FirstTask.class);
16	  
17	    /**
18	     * Execute this task
19	     *
20	     */
21	    public void execute() {
22	        log.debug("FirstTask runs successfully...");
23	    }
24	}

A SecondTask Class is created.
01	package com.otv.task;
02	  
03	import org.apache.log4j.Logger;
04	  
05	/**
06	 * Second Task
07	 *
08	 * @author  onlinetechvision.com
09	 * @since   24 Feb 2012
10	 * @version 1.0.0
11	 *
12	 */
13	public class SecondTask {
14	  
15	    private static Logger log = Logger.getLogger(SecondTask.class);
16	  
17	    /**
18	     * Execute this task
19	     *
20	     */
21	    public void execute() {
22	        log.debug("SecondTask runs successfully...");
23	    }
24	}

STEP 4 : CREATE ISchedulerService INTERFACE
ISchedulerService Interface is created.
01	package com.otv.service;
02	  
03	/**
04	 * Scheduler Service Interface
05	 *
06	 * @author  onlinetechvision.com
07	 * @since   24 Feb 2012
08	 * @version 1.0.0
09	 *
10	 */
11	public interface ISchedulerService {
12	  
13	    /**
14	     * Execute First Task
15	     *
16	     * @param
17	     * @throws
18	     * @return
19	     */
20	    public void executeFirstTask();
21	  
22	    /**
23	     * Execute Second Task
24	     *
25	     * @param
26	     * @throws
27	     * @return
28	     */
29	    public void executeSecondTask();
30	}

STEP 5 : CREATE SchedulerService CLASS
SchedulerService Class is created by implementing ISchedulerService Interface. This service schedules tasks.
01	package com.otv.service;
02	  
03	import com.otv.task.FirstTask;
04	import com.otv.task.SecondTask;
05	  
06	/**
07	 * Scheduler Service Implementation
08	 *
09	 * @author  onlinetechvision.com
10	 * @since   24 Feb 2012
11	 * @version 1.0.0
12	 *
13	 */
14	public class SchedulerService implements ISchedulerService {
15	  
16	    private FirstTask  firstTask;
17	    private SecondTask secondTask;
18	  
19	    /**
20	     * Execute First Task
21	     *
22	     */
23	    public void executeFirstTask() {
24	        getFirstTask().execute();
25	    }
26	  
27	    /**
28	     * Execute Second Task
29	     *
30	     */
31	    public void executeSecondTask() {
32	        getSecondTask().execute();
33	    }
34	  
35	    /**
36	     * Get First Task
37	     *
38	     * @return FirstTask
39	     */
40	    public FirstTask getFirstTask() {
41	        return firstTask;
42	    }
43	  
44	    /**
45	     * Set First Task
46	     *
47	     * @param  firstTask First Task
48	     */
49	    public void setFirstTask(FirstTask firstTask) {
50	        this.firstTask = firstTask;
51	    }
52	  
53	    /**
54	     * Get Second Task
55	     *
56	     * @return SecondTask
57	     */
58	    public SecondTask getSecondTask() {
59	        return secondTask;
60	    }
61	  
62	    /**
63	     * Set Second Task
64	     *
65	     * @param  secondTask Second Task
66	     */
67	    public void setSecondTask(SecondTask secondTask) {
68	        this.secondTask = secondTask;
69	    }
70	}

STEP 6 : CREATE Application CLASS
Application Class is created. This class runs the application.
01	package com.otv.starter;
02	  
03	import org.springframework.context.support.ClassPathXmlApplicationContext;
04	  
05	/**
06	 * Application Starter Class
07	 *
08	 * @author  onlinetechvision.com
09	 * @since   24 Feb 2012
10	 * @version 1.0.0
11	 *
12	 */
13	public class Application {
14	  
15	    /**
16	     * Main method of the Application
17	     *
18	     */
19	    public static void main(String[] args) {
20	        new ClassPathXmlApplicationContext("applicationContext.xml");
21	    }
22	}

STEP 7 : DEFINE Job Detail CONFIGURATIONS
Job Details can be defined via two ways in Spring. By using MethodInvokingJobDetailFactoryBean or by extending QuartzJobBean. In this example, MethodInvokingJobDetailFactoryBean method has been used. targetObject and targetMethod properties are given to MethodInvokingJobDetailFactoryBean.
01	<!-- Job Details-->
02	<bean id="FirstTaskJobDetail" class="org.springframework.scheduling.quartz.MethodInvokingJobDetailFactoryBean">
03	    <property name="targetObject" ref="SchedulerService" />
04	    <property name="targetMethod" value="executeFirstTask" />
05	</bean>
06	  
07	<bean id="SecondTaskJobDetail" class="org.springframework.scheduling.quartz.MethodInvokingJobDetailFactoryBean">
08	    <property name="targetObject" ref="SchedulerService" />
09	    <property name="targetMethod" value="executeSecondTask" />
10	</bean>

STEP 8 : DEFINE Trigger CONFIGURATIONS
Triggers can also be defined via two ways in Spring. By defining SimpleTriggerBean or CronTriggerBean . When SimpleTriggerBean is used, jobDetail, repeatInterval and startDelay properties are defined. When CronTriggerBean is used, jobDetail and cronExpression properties are defined. In this example, repeat interval of first task has been set 5 secs and repeat interval of second task has been set 12 secs .
01	<!-- Simple Trigger -->
02	<bean id="FirstSimpleTrigger" class="org.springframework.scheduling.quartz.SimpleTriggerBean">
03	    <property name="jobDetail" ref="FirstTaskJobDetail" />
04	    <property name="repeatInterval" value="5000" />
05	    <property name="startDelay" value="1000" />
06	</bean>
07	  
08	<!-- <bean id="SecondSimpleTrigger" class="org.springframework.scheduling.quartz.SimpleTriggerBean">
09	        <property name="jobDetail" ref="SecondTaskJobDetail" />
10	        <property name="repeatInterval" value="12000" />
11	        <property name="startDelay" value="1000" />
12	    </bean> -->   
13	  
14	<!-- Cron Trigger -->
15	<bean id="SecondSimpleTrigger" class="org.springframework.scheduling.quartz.CronTriggerBean">
16	    <property name="jobDetail" ref="SecondTaskJobDetail" />
17	    <property name="cronExpression" value="0/12 * * * * ?" />
18	</bean>

STEP 9 : DEFINE SchedulerFactoryBean CONFIGURATION
Finally, Job Details and Triggers are configured by creating SchedulerFactoryBean.
01	<bean class="org.springframework.scheduling.quartz.SchedulerFactoryBean">
02	    <property name="jobDetails">
03	       <list>
04	          <ref bean="FirstTaskJobDetail" />
05	          <ref bean="SecondTaskJobDetail" />
06	       </list>
07	    </property>
08	    <property name="triggers">
09	       <list>
10	          <ref bean="FirstSimpleTrigger" />
11	          <ref bean="SecondSimpleTrigger" />
12	       </list>
13	    </property>
14	</bean>

STEP 10 : CREATE applicationContext.xml
All applicationContext.xml content is shown as below.
view source
print?
01	<beans xmlns="http://www.springframework.org/schema/beans"
02	    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
03	    xsi:schemaLocation="http://www.springframework.org/schema/beans
04	  
05	http://www.springframework.org/schema/beans/spring-beans-3.0.xsd">
06	  
07	    <!-- Beans Declaration -->
08	    <bean id="FirstTask" class="com.otv.task.FirstTask"></bean>
09	    <bean id="SecondTask" class="com.otv.task.SecondTask"></bean>
10	  
11	    <bean id="SchedulerService" class="com.otv.service.SchedulerService">
12	        <property name="firstTask" ref="FirstTask" />
13	        <property name="secondTask" ref="SecondTask" />
14	    </bean>
15	  
16	    <!-- Job Details-->
17	    <bean id="FirstTaskJobDetail" class="org.springframework.scheduling.quartz.MethodInvokingJobDetailFactoryBean">
18	        <property name="targetObject" ref="SchedulerService" />
19	        <property name="targetMethod" value="executeFirstTask" />
20	    </bean>
21	  
22	    <bean id="SecondTaskJobDetail" class="org.springframework.scheduling.quartz.MethodInvokingJobDetailFactoryBean">
23	        <property name="targetObject" ref="SchedulerService" />
24	        <property name="targetMethod" value="executeSecondTask" />
25	    </bean>
26	  
27	    <!-- Simple Trigger -->
28	    <bean id="FirstSimpleTrigger" class="org.springframework.scheduling.quartz.SimpleTriggerBean">
29	        <property name="jobDetail" ref="FirstTaskJobDetail" />
30	        <property name="repeatInterval" value="5000" />
31	        <property name="startDelay" value="1000" />
32	    </bean>
33	<!--
34	    <bean id="SecondSimpleTrigger" class="org.springframework.scheduling.quartz.SimpleTriggerBean">
35	        <property name="jobDetail" ref="SecondTaskJobDetail" />
36	        <property name="repeatInterval" value="12000" />
37	        <property name="startDelay" value="1000" />
38	    </bean>
39	-->
40	    <!-- Cron Trigger -->
41	    <bean id="SecondSimpleTrigger" class="org.springframework.scheduling.quartz.CronTriggerBean">
42	        <property name="jobDetail" ref="SecondTaskJobDetail" />
43	        <property name="cronExpression" value="0/12 * * * * ?" />
44	    </bean>
45	  
46	    <bean class="org.springframework.scheduling.quartz.SchedulerFactoryBean">
47	        <property name="jobDetails">
48	           <list>
49	              <ref bean="FirstTaskJobDetail" />
50	              <ref bean="SecondTaskJobDetail" />
51	           </list>
52	        </property>
53	        <property name="triggers">
54	           <list>
55	              <ref bean="FirstSimpleTrigger" />
56	              <ref bean="SecondSimpleTrigger" />
57	           </list>
58	        </property>
59	    </bean>
60	  
61	</beans>

