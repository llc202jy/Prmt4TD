     * @return this website's parent org unit and all parent org units up to the root org unit
     */
    public NSArray allParentOrgUnits()
    {
        return parentOrgUnit().orgUnitPath();

        /** ensure [valid_result] Result != null;  **/
     }


    /**
     * Returns the Sections in this Website (less the homeSection() and previousHomeSection()), sorted by the section order.
     *
     * @return the Sections in this Website (less the homeSection() and previousHomeSection()), sorted by the section order.
     * @deprecated Don't use this!
     */
    public NSMutableArray nonHomeSections()
    {
        NSMutableArray nonHomeSections = sortSections(new NSMutableArray(sections()));
        nonHomeSections.removeObject(homeSection());


        DebugOut.println(30,"====Returning non-home Sections: " + nonHomeSections.valueForKey("name"));

        return nonHomeSections;

        /** ensure
        [return_valid] Result != null;
        [home_not_included] ! Result.containsObject(homeSection());
        [all_non_home_sections_included] (forall i : {0 .. sections().count() - 1} #
                                          ((Section)sections().objectAtIndex(i)).isHomeSection() ||
                                          Result.containsObject(sections().objectAtIndex(i)) );    **/
    }





    /**
     * Returns the Sections in this Website, sorted by the section order.
     *
     * @return the Sections in this Website, sorted by the section order
     */
    public NSArray orderedSections()
    {
        return sortSections(new NSMutableArray(sections()));

        /** ensure
        [return_valid] Result != null;
        [all_non_home_sections_included] (forall i : {0 .. sections().count() - 1} #
                                          Result.containsObject(sections().objectAtIndex(i)) );    **/
    }



    /**
     * Returns the Sections in this Website (including the homeSection() but not previousHomeSection()), which are of a Section Type which can be embedded.  The returned Sections are sorted by the section order.
     *
     * @return the Sections in this Website, which are of a Section Type which can be embedded, sorted by the section order.
     */
    public NSArray embeddableSections()
    {
        NSMutableArray embeddableSections = new NSMutableArray();
        NSMutableArray sortedSections = nonHomeSections();
        sortedSections.insertObjectAtIndex(homeSection(), 0);
        
        Enumeration sectionEnum = sortedSections.objectEnumerator();
        while (sectionEnum.hasMoreElements())
        {
            Section aSection = (Section) sectionEnum.nextElement();
            if (aSection.canBeEmbedded())
            {
                embeddableSections.addObject(aSection);
            }
        }

        DebugOut.println(30,"====Returning embeddableSections Sections: " + embeddableSections.valueForKey("name"));

        return embeddableSections;

        /** ensure
        [return_valid] Result != null;
        [all_embeddable_sections_included] (forall i : {0 .. sections().count() - 1} #
                                             ( ! ((Section)sections().objectAtIndex(i)).canBeEmbedded()) ||
                                             Result.containsObject(sections().objectAtIndex(i)) );
        [non_embeddable_sections_excluded] (forall i : {0 .. Result.count() - 1} #
                                            ((Section)Result.objectAtIndex(i)).canBeEmbedded());       **/
    }

    
    
    public NSMutableArray sortSections(NSMutableArray sections) {
        DebugOut.println(30, siteID() + "Unsorted Sections: " + sections.valueForKey("name"));
        
        EOSortOrdering sectionOrdering =
        EOSortOrdering.sortOrderingWithKey("sectionOrder", EOSortOrdering.CompareAscending);

        NSArray sortOrdering = new NSArray(sectionOrdering);

        EOSortOrdering.sortArrayUsingKeyOrderArray(sections, sortOrdering);

        DebugOut.println(30, siteID() + "Sorted Sections: " + sections.valueForKey("name"));

        return sections;
    }



    /**
     * Returns true if otherWebsite is already linked below the current site.  This test is used to prevent creating an infinite recursive loop of sites linked within each other.
     *
     * @return true if otherWebsite is already linked below the current site.
     */
    public boolean containsSite(Website otherWebsite)
    {

        /** require
        [otherWebsite_valid] otherWebsite != null;
        [otherWebsite_not_this] otherWebsite != this;
        [otherWebsite_in_same_ec] editingContext().equals(otherWebsite.editingContext());
         **/

        DebugOut.println(16, " = = = = = Testing to see if " + siteID() + " contains: [" + otherWebsite.siteID() + "]");
        boolean contains = false;
        Enumeration sectionEnum = sections().objectEnumerator();

        while(( !  contains) && sectionEnum.hasMoreElements())
        {
            Section aSection = (Section) sectionEnum.nextElement();

            if (aSection.hasLinkedSite())
            {
                contains = (aSection.linkedSite().equals(otherWebsite) ||
                            aSection.linkedSite().containsSite(otherWebsite));
            }
        }

        DebugOut.println(16, " = = = = = " + siteID() + " contains: [" + otherWebsite.siteID() + "]: [" + contains + "]");

        return contains;
    }



    /**
     * Returns true if theSection is in this Website or can be reached by navigating the linkedSite() of sections.
     *
     * @return true if theSection is in this Website or can be reached by navigating the linkedSite() of sections.
     */
    public boolean containsSection(Section theSection)
    {
        /** require
        [theSection_valid] theSection != null;
        [theSection_in_same_ec] editingContext().equals(theSection.editingContext());
         **/

        boolean contains = false;
        Enumeration sectionEnum = sections().objectEnumerator();

        while( ( ! contains) && sectionEnum.hasMoreElements())
        {
            Section aSection = (Section) sectionEnum.nextElement();

            if (aSection.equals(theSection))
            {
                contains = true;
            }
            else if (aSection.hasLinkedSite())
            {
                contains = aSection.linkedSite().containsSection(theSection);
            }
        }

        return contains;
    }



    /**
     * Returns the section with the passed name or null if it cannot be found.  If the section name is Section.HomeSectionName returns the current home section.
     *
     * @param sectionName the normalized name (lower case) for the section to return
     * @return the section with the passed name or null if it cannot be found.
     */
    public Section sectionForNormalizedName(String sectionName)
    {
        /** require
        [section_name_not_null] sectionName != null;
        [section_name_is_lower_case] sectionName.toLowerCase().equals(sectionName); **/
        
        Section sectionForNormalizedName = null;

        // Handle special case where two sections can both be named home.
        if (sectionName.equalsIgnoreCase("Home"))
        {
            sectionForNormalizedName = homeSection();
        }
        else // Search through the list
        {
            Enumeration sectionEnum = sections().objectEnumerator();

            while(sectionEnum.hasMoreElements())
            {
                Section aSection = (Section)sectionEnum.nextElement();
                if (aSection.normalName().equals(sectionName))
                {
                    sectionForNormalizedName = aSection;
                    break;
                }
            }
        }

        return sectionForNormalizedName;
    }

    

    public boolean hasSectionWithNormalizedName(String sectionNormalName) {
        Enumeration sectionEnum = sections().objectEnumerator();

        while(sectionEnum.hasMoreElements()) {
            Section aSection = (Section)sectionEnum.nextElement();
            if (aSection.normalName().equals(sectionNormalName))
                return true;
        }
        return false;
    }



    /**
     * Removes aSection from this Website and updates any Websites embedding this Section (via delete rule).  The Home sections can not be removed.
     *
     * @param aSection the Section to remove
     */
    public void removeSection(Section aSection)
    {
        /** require
        [valid_section] aSection != null;
        [section_exists] sections().containsObject(aSection);
        [not_home_section] ! aSection.isHomeSection();     **/

        DebugOut.println(3,"Removing section " + aSection.name() + " from site " + siteID());
        removeObjectFromBothSidesOfRelationshipWithKey(aSection, "sections");

        DebugOut.println(3,"Deleting section from ec " + aSection.name());
        editingContext().deleteObject(aSection);

        editingContext().processRecentChanges();  // Needed for post condition

        /** ensure [section_has_been_removed] ! sections().containsObject(aSection); **/
    }



    /**
     * Returns the Local Groups for this Website sorted by name.
     *  
     * @return the Local Groups for this Website sorted by name
     */
    public NSArray orderedLocalGroups()
    {
        NSMutableArray localGroups = new NSMutableArray(childGroups().count());
        Enumeration groupEnumerator = childGroups().objectEnumerator();
        while (groupEnumerator.hasMoreElements())
        {
            Group aGroup = (Group) groupEnumerator.nextElement();
            if (aGroup instanceof LocalGroup)
            {
                localGroups.addObject(aGroup);
            }
        }
       
        NSArray orderedLocalGroups;
        
        try
        {
            orderedLocalGroups = localGroups.sortedArrayUsingComparator(
                new KeyValueComparator("name", NSComparator.OrderedAscending));
        }
        catch (ComparisonException e)
        {
            throw new ExceptionConverter(e);
        }
        
        return orderedLocalGroups;
    }



    /**
     * Returns the group named <code>name</code> from this Website, or null if a group with that name is not found.
     *
     * @return the group named <code>name</code> from this Website, or null if a group with that name is not found.
     *
     * @param name the name of the group to return
     */
    public Group groupNamed(String name)
    {
        /** require
        [name_not_null] name != null;
        [editing_context_not_null] editingContext() != null; **/
        
        Group fetchedGroup;

        NSMutableArray qualifierArgs = new NSMutableArray();
        qualifierArgs.addObject(name);
        qualifierArgs.addObject(this);

        // BUG SQL is 'parent_website is null' when Website unsaved.
        EOQualifier qualifier = EOQualifier.qualifierWithQualifierFormat("name caseInsensitiveLike %@ AND parentWebsite = %@",qualifierArgs);
        EOFetchSpecification fetchSpec = new EOFetchSpecification("Group", qualifier, null);

        NSArray groupResult = editingContext().objectsWithFetchSpecification(fetchSpec);

        if (groupResult.count() == 1)
        {
            DebugOut.println(1,"Fetched group named " + name + " for site " + siteID());
            fetchedGroup =  (Group)groupResult.objectAtIndex(0);
        }
        else if (groupResult.count() == 0)
        {
            DebugOut.println(1,"Failed to fetch group named " + name + " for site " + siteID());
            fetchedGroup =  null;
        }
        else
        {
            // Panic!
            throw new RuntimeException("Got " + groupResult.count() + " groups for key " + name + " from fetch.");
        }

        return fetchedGroup;

        /** ensure [valid_returned_group] (Result == null) || (Result.name().equalsIgnoreCase(name));  **/
    }



    /**
     * Creates and returns a new LocalGroup, named aGroupName, attached to this Website with the Website owner as the Group's only member.
     *
     * @param aGroupName the name to give to the created Group.
     *
     * @return the newly created Group
     */
    public LocalGroup newLocalGroupNamed(String aGroupName)
    {
        /** require [valid_name] aGroupName != null;  [not_duplicate_name] groupNamed(aGroupName) == null;  **/
        
        LocalGroup newGroup = (LocalGroup)LocalGroup.newGroup();
        editingContext().insertObject(newGroup);
        newGroup.setName(aGroupName);

        addObjectToBothSidesOfRelationshipWithKey(newGroup, "childGroups");

        // The site owner is a mandatory member of all groups in a Website
        newGroup.addObjectToBothSidesOfRelationshipWithKey(owner(), "users");

        return newGroup;
        
        /** ensure
        [valid_new_group] (Result != null) && (Result.name().equals(aGroupName));
        [website_set] Result.parentWebsite() == this;
        [owner_added] Result.users().containsObject(owner());
        [group_added] childGroups().containsObject(Result);      **/
    }



 

    /**
     * Removes aGroup from this Website.  The configureGroup() cannot be removed.
     *
     * @param aGroup the Group to remove
     */
    public void removeGroup(Group aGroup)
    {
        /** require
        [valid_group] aGroup != null;
        [group_exists] childGroups().containsObject(aGroup);
        [not_configure_group] ! aGroup.equals(configureGroup());     **/
        
        removeObjectFromBothSidesOfRelationshipWithKey(aGroup, "childGroups");
        editingContext().deleteObject(aGroup);
        editingContext().processRecentChanges();  // Needed for post condition

        /** ensure [group_has_been_removed] ! childGroups().containsObject(aGroup); **/
    }


    
    public NSArray groupsSansSpecialGroups()
    {
        NSMutableArray groupsSansSpecialGroups = new NSMutableArray(childGroups().count());

        Enumeration groupEnum = childGroups().objectEnumerator();
        while (groupEnum.hasMoreElements())
        {
            Group aGroup = (Group)groupEnum.nextElement();
            if ( !  aGroup.isSystemGroup())
            {
                groupsSansSpecialGroups.addObject(aGroup);
            }
        }

        return groupsSansSpecialGroups;
    }
