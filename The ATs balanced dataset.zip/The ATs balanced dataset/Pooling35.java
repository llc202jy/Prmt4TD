namespace ObjectPooling
{
public class EmployeeFactory
{
//Defining Max pool size of Objects as two
static int _intMaxPoolSize = 2;

//Collection class to hold objects
static readonly Queue objPool = new Queue(_intMaxPoolSize);

//Creates new employee only when the count of objects is more than two
//Otherwise served from pool
public Employee GetEmployee()
{
Employee objEmployee;
if (Employee._intCounter >= 2 && objPool.Count > 1)
{
objEmployee = GetEmployeeFromPool();
}
else
{
objEmployee = CreateNewEmployee();
}
return objEmployee;
}

private Employee GetEmployeeFromPool()
{
Employee objEmp;
if (objPool.Count > 1)
{
objEmp = (Employee)objPool.Dequeue();
Employee._intCounter--;
}
else
{
objEmp = new Employee();
}
return objEmp;
}
private Employee CreateNewEmployee()
{
Employee objEmp = new Employee();
objPool.Enqueue(objEmp);
return objEmp;
}
}
}



Employee.cs

using System;

namespace ObjectPooling
{
public class Employee
{
public static int _intCounter = 0;

public Employee()
{
_intCounter = _intCounter + 1;
_FirstName = "FirstName" + _intCounter.ToString();
_LastName = "LastName" + _intCounter.ToString();
}

private string _FirstName;

public string FirstName
{
get { return _FirstName; }
set { _FirstName = value; }
}
private string _LastName;

public string LastName
{
get { return _LastName; }
set { _LastName = value; }
}
}
}

Default.aspx.cs

protected void btnCreate_Click(object sender, EventArgs e)
{
EmployeeFactory objEFact = new EmployeeFactory();

Employee obj1 = objEFact.GetEmployee();
Employee obj2 = objEFact.GetEmployee();
Employee obj3 = objEFact.GetEmployee();
Employee obj4 = objEFact.GetEmployee();

Response.Write("Object 1 Values are-----" + obj1.FirstName +"--"+obj1.LastName+"--");
Response.Write("Object 2 Values are-----" + obj2.FirstName +"--"+obj2.LastName+"--");
Response.Write("Object 3 Values are-----" + obj3.FirstName +"--"+obj3.LastName+"--");
Response.Write("Object 4 Values are-----" + obj4.FirstName + "--" + obj4.LastName + "--");
}
