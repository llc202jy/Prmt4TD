static bool mounted = false;

static int flags;

int
fred_cmd_help(int argc, FredArg *args)
{
	kprintf("FreD Shell (Freedows Development Shell) v" FRED_VERSION "\n\n");
	kprintf("Commands:\n");
	kprintf("\thelp       Shows this help screen.\n");
	kprintf("\tversion    Shows the version of FreD and Freedows.\n");
	kprintf("\treboot     Reboots the computer.\n");
	kprintf("\tcls        Clears the screen.\n");
	kprintf("\tuptime     Displays the uptime.\n\n");

	kprintf("Filesystem:\n");
	kprintf("\tdrives     Shows all available drives.\n");
	kprintf("\tmount      Mounts the specified drive.\n");
	kprintf("\tunmount    Unmounts the specified drive.\n");
	kprintf("\tchdrv      Changed the active drive.\n");
	kprintf("\tcd         Changes the active directory.\n");
	kprintf("\tdir        Displays the active directory's entries.\n");
	kprintf("\tls         Identical to dir.\n");
	kprintf("\tcat        Outputs the contents of a file.\n");

	kprintf("\n");

	return 0;
}

int
fred_cmd_version(int argc, FredArg *args)
{
	kprintf("Freedows v" VERSION "\n");
	kprintf("FreD Shell (Freedows Development Shell) v" FRED_VERSION "\n");

	return 0;
}

int
fred_cmd_reboot(int argc, FredArg *args)
{
	reboot(0);

	return 0;
}

int
fred_cmd_cls(int argc, FredArg *args)
{
	console_clear();

	return 0;
}

int
fred_cmd_uptime(int argc, FredArg *args)
{
	unsigned long uptime = timer_get_uptime();
	unsigned int seconds, minutes, hours, days, temp;

	seconds = uptime % 60;
	temp    = uptime / 60;
	
	minutes = temp % 60;
	temp    = temp / 60;

	hours = temp % 24;
	days  = temp / 24;
	
	kprintf("\nUptime: %d days, %d hours, %d minutes, %d seconds\n",
			days, hours, minutes, seconds);
	
	return 0;
}

int
fred_cmd_drives(int argc, FredArg *args)
{
	kprintf("Available drives: fd0\n");

	return 0;
}

int
fred_cmd_mount(int argc, FredArg *args)
{
	if (argc == 0)
	{
		kprintf("You must specify a drive to mount.\n");
		
		return -1;
	}

	if (!fat_fs_init())
	{
		kprintf("Unable to initialize the filesystem.\n");
		return -1;
	}

	mounted = true;
	
	return 0;
}

int
fred_cmd_unmount(int argc, FredArg *args)
{
	if (argc == 0)
	{
		kprintf("You must specify a drive to unmount.\n");

		return -1;
	}
	
	return 0;
}

int
fred_cmd_chdrv(int argc, FredArg *args)
{
	if (argc == 0)
	{
		kprintf("You must specify a drive to change to.\n");
		
		return -1;
	}
	
	return 0;
}

int
fred_cmd_cd(int argc, FredArg *args)
{
	FredArg *arg;


	if (!mounted)
	{
		kprintf("MOUNT!\n");
		return 0;
	}
	
	if (argc > 0)
	{
		arg = args;

		while (arg != NULL)
		{
			kprintf("%d: %s\n", arg->index, arg->value);

			arg = arg->next;
		}
	}
	
	return 0;
}

int
fred_cmd_dir(int argc, FredArg *args)
{
	if (!mounted)
	{
		kprintf("How badly do you want to crash me? Just mount!\n");
		return 0;
	}

	fat_dump();

	return 0;
}

int
fred_cmd_cat(int argc, FredArg *args)
{
	int fp;
	unsigned char buffer[2048];
	int length;

	if (argc == 0)
	{
		kprintf("You must specify a file to cat!\n");
		
		return -1;
	}

	if (!mounted)
	{
		kprintf("Please mount first, and have a nice day.\n");
		return 0;
	}
	
	fp = fat_file_open(args->value, FAT_FILE_READ);
	if (fp == -1)
	{
		kprintf("Unable to open %s!\n", args->value);
	}
	else
	{
		while ((length = fat_file_read(fp, buffer, 1024)) > 0)
		{
			buffer[length] = '\0';
			kprintf("%s", buffer);
//			console_write_str(buffer);
		}

		kprintf("\n");

		fat_file_close(fp);
	}
	
	return 0;
}

extern void int21_ISR(void);

typedef struct
{
	/* Pushed by pusha */
	unsigned int edi, esi, ebp, dummy_esp, ebx, edx, ecx, eax;

	unsigned int vector, error;

	unsigned int eip, cs, eflags, esp, ss;

} __attribute__ ((packed)) regs_t;

void
int21(regs_t regs)
{
	kprintf("Interrupt 0x21! EAX = 0x%02X, EAH = 0x%02X\n",
			regs.eax, ((regs.eax & 0xFF00) >> 8));
}

void
app_return(void)
{
	__asm__ __volatile__ ("pushl %0 ; popfl" : : "g" (flags) : "memory");
}

__asm__ (
