using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.Specialized;
using System.Text.RegularExpressions;
using System.Collections;

namespace CCNetConfig.Updater.Core {
  /// <summary>
  /// Command line parser.  
  /// </summary>
  public class CommandLineArguments {
    // Variables
    private new Dictionary<string,string> namedParameters;
    private List<string> unnamedParameters;
    /// <summary>
    /// Creates a <see cref="CommandLineArguments"/> object to parse
    /// command lines.
    /// </summary>
    /// <param name="args">The command line to parse.</param>
    public CommandLineArguments ( string[] args ) {
      namedParameters = new Dictionary<string,string> ();
      unnamedParameters = new List<string> ();
      Regex splitter = new Regex ( Properties.Strings.ArgumentsSplitterRegex, RegexOptions.IgnoreCase | RegexOptions.Compiled );
      Regex remover = new Regex ( Properties.Strings.ArgumentsRemoverRegex, RegexOptions.IgnoreCase | RegexOptions.Compiled );
      string parameter = null;
      string[] parts;

      foreach ( string str in args ) {
        // Do we have a parameter (starting with -, /, or --)?
        if ( str.StartsWith ( "-" ) || str.StartsWith ( "/" ) ) {
          // Look for new parameters (-,/ or --) and a possible
          // enclosed value (=,:)
          parts = splitter.Split ( str, 3 );
          switch ( parts.Length ) {
            // Found a value (for the last parameter found
            // (space separator))
            case 1:
              if ( parameter != null ) {
                if ( !namedParameters.ContainsKey ( parameter ) ) {
                  parts[0] =
                      remover.Replace ( parts[0], "$1" );
                  namedParameters.Add (
                      parameter, parts[0] );
                }
                parameter = null;
              }
              // else Error: no parameter waiting for a value
              // (skipped)
              break;
            // Found just a parameter
            case 2:
              // The last parameter is still waiting. With no
              // value, set it to true.
              if ( parameter != null ) {
                if ( !namedParameters.ContainsKey ( parameter ) )
                  namedParameters.Add ( parameter, "true" );
              }
              parameter = parts[1];
              break;
            // parameter with enclosed value
            case 3:
              // The last parameter is still waiting. With no
              // value, set it to true.
              if ( parameter != null ) {
                if ( !namedParameters.ContainsKey ( parameter ) )
                  namedParameters.Add ( parameter, "true" );
              }
              parameter = parts[1];
              // Remove possible enclosing characters (",')
              if ( !namedParameters.ContainsKey ( parameter ) ) {
                parts[2] = remover.Replace ( parts[2], "$1" );
                namedParameters.Add ( parameter, parts[2] );
              }
              parameter = null;
              break;
          }
        } else {
          unnamedParameters.Add ( str );
        }
      }
      // In case a parameter is still waiting
      if ( parameter != null ) {
        if ( !namedParameters.ContainsKey ( parameter ) )
          namedParameters.Add ( parameter, "true" );
      }
    }

    /// <summary>
    /// Retrieves the parameter with the specified name.
    /// </summary>
    /// <param name="name">
    /// The name of the parameter. The name is case insensitive.
    /// </param>
    /// <returns>
    /// The parameter or <c>null</c> if it can not be found.
    /// </returns>
    public string this[string name] {
      get {
        return ( namedParameters[name] );
      }
    }

    /// <summary>
    /// Retrieves an unnamed parameter (that did not start with '-'
    /// or '/').
    /// </summary>
    /// <param name="index">The index of the unnamed parameter.</param>
    /// <returns>The unnamed parameter or <c>null</c> if it does not
    /// exist.</returns>
    /// <remarks>
    /// Primarily used to retrieve filenames which extension has been
    /// associated to the application.
    /// </remarks>
    public string this[int index] {
      get {
        return (string)( index < unnamedParameters.Count ?
            unnamedParameters[index] :
        null );
      }
    }

    /// <summary>
    /// Gets the keys.
    /// </summary>
    /// <value>The keys.</value>
    public Dictionary<string, string>.KeyCollection Keys {
      get { return namedParameters.Keys; }
    }

    /// <summary>
    /// Gets the values.
    /// </summary>
    /// <value>The values.</value>
    public Dictionary<string, string>.ValueCollection Values {
      get { return this.namedParameters.Values; }
    }

    /// <summary>
    /// Gets the count.
    /// </summary>
    /// <value>The count.</value>
    public int Count { get { return this.UnnamedParametersCount + this.NamedParametersCount; } }

    /// <summary>
    /// Gets the unnamed parameters count.
    /// </summary>
    /// <value>The unnamed parameters count.</value>
    public int UnnamedParametersCount { get { return this.unnamedParameters.Count; } }

    /// <summary>
    /// Gets the named parameters count.
    /// </summary>
    /// <value>The named parameters count.</value>
    public int NamedParametersCount { get { return this.namedParameters.Count; } }

    /// <summary>
    /// Converts unnamed parameters to array.
    /// </summary>
    /// <returns></returns>
    public string[] UnnamedParametersToArray(  ) {
      return this.unnamedParameters.ToArray ();
    }

    /// <summary>
    /// Determines whether this contains specified param.
    /// </summary>
    /// <param name="param">The param.</param>
    /// <returns>
    /// 	<c>true</c> if this contains specified param; otherwise, <c>false</c>.
    /// </returns>
    public bool ContainsParam ( string param ) {
      return this.namedParameters.ContainsKey ( param );
    }
  }
}
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.ComponentModel;
using CCNetConfig.Core.Enums;

namespace CCNetConfig.Updater.Core {
  

  /// <summary>
  /// Update information
  /// </summary>
  [XmlRoot ( "UpdateInfo", IsNullable = false )]
  public class UpdateInfo {

    private List<UpdateFile> _files;
    private Version _version = null;
    private List<string> _commands = null;
    private UpdateMode _updateMode = UpdateMode.UNKNOWN;
    private DateTime _updateDate = DateTime.Now;
    private string _updateComments = string.Empty;
    private int _changeSet = 0;


    /// <summary>
    /// Initializes a new instance of the <see cref="UpdateInfo"/> class.
    /// </summary>
    public UpdateInfo () {
      this._files = new List<UpdateFile> ();
      _commands = new List<string> ();
    }

    /// <summary>
    /// Gets or sets the comments.
    /// </summary>
    /// <value>The comments.</value>
    [XmlElement ( "Comments" )]
    public string Comments {
      get { return this._updateComments; }
      set { this._updateComments = value; }
    }

    /// <summary>
    /// Gets or sets the updated date. When being deserialized, the date must be formated in the following
    /// format string 'yyyy-MM-ddTHH:mm:ss.fffffzzz'
    /// </summary>
    /// <value>The updated date.</value>
    [XmlAttribute ( "UpdatedDate" )]
    public DateTime UpdatedDate { get { return this._updateDate; } set { this._updateDate = value; } }

    /// <summary>
    /// Gets the files.
    /// </summary>
    /// <value>The files.</value>
    [XmlArray ( "Files" ),
    XmlArrayItem ( "File" )]
    public List<UpdateFile> Files { get { return this._files; } set { this._files = value; } }

    /// <summary>
    /// Gets or sets the update mode.
    /// </summary>
    /// <value>The mode string.</value>
    [XmlAttribute ( "Mode" )]
    public string ModeString { get { return this.UpdateMode.ToString (); } set { this.UpdateMode = StringToMode ( value ); } }
    /// <summary>
    /// Gets or sets the update mode.
    /// </summary>
    /// <value>The update mode.</value>
    [XmlIgnore]
    public UpdateMode UpdateMode { get { return this._updateMode; } set { this._updateMode = value; } }
    /// <summary>
    /// Gets or sets the commands.
    /// </summary>
    /// <value>The commands.</value>
    [XmlArray ( "Commands" ),
    XmlArrayItem ( "Command" )]
    public List<string> Commands { get { return this._commands; } set { this._commands = value; } }
    /// <summary>
    /// Gets or sets the version.
    /// </summary>
    /// <value>The version.</value>
    [XmlIgnore]
    public Version Version { get { return this._version; } set { this._version = value; } }
    /// <summary>
    /// Gets or sets the version string.
    /// </summary>
    /// <value>The version string.</value>
    [XmlAttribute ( "Version" ), Browsable ( false ), EditorBrowsable ( EditorBrowsableState.Never ), Description ( "Used for the serializer, use Version instead." )]
    public string VersionString { get { return this.Version.ToString (); } set { this.Version = new Version ( value ); } }

    /// <summary>
    /// Gets or sets the change set.
    /// </summary>
    /// <value>The change set.</value>
    [ XmlAttribute( "ChangeSet" ) ]
    public int ChangeSet {
      get { return this._changeSet; }
      set { this._changeSet = value; }
    }
    /// <summary>
    /// String to mode.
    /// </summary>
    /// <param name="val">The val.</param>
    /// <returns></returns>
    private UpdateMode StringToMode ( string val ) {
      object obj = Enum.Parse ( typeof ( UpdateMode ), val );
      if ( obj != null )
        return (UpdateMode)obj;
      else
        return UpdateMode.UNKNOWN;
    }
  }
}

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using CCNetConfig.Core;

namespace CCNetConfig.Components {
  /// <summary>
  /// A Custom TreeNode
  /// </summary>
  public class TriggersTreeNode : TreeNode {
    /// <summary>
    /// Initializes a new instance of the <see cref="TriggersTreeNode"/> class.
    /// </summary>
    /// <param name="imgIndex">Index of the img.</param>
    public TriggersTreeNode ( int imgIndex )
      : base ( "Triggers", imgIndex, imgIndex ) {

    }
  }
  /// <summary>
  /// A Custom TreeNode
  /// </summary>
  public class TasksTreeNode : TreeNode {
    /// <summary>
    /// Initializes a new instance of the <see cref="TasksTreeNode"/> class.
    /// </summary>
    /// <param name="imgIndex">Index of the img.</param>
    public TasksTreeNode ( int imgIndex )
      : base ( "Tasks", imgIndex, imgIndex ) {

    }
  }
  /// <summary>
  /// A Custom TreeNode
  /// </summary>
  public class PublishersTreeNode : TreeNode {
    /// <summary>
    /// Initializes a new instance of the <see cref="PublishersTreeNode"/> class.
    /// </summary>
    /// <param name="imgIndex">Index of the img.</param>
    public PublishersTreeNode ( int imgIndex )
      : base ( "Publishers", imgIndex, imgIndex ) {

    }
  }

  /// <summary>
  /// A Custom TreeNode
  /// </summary>
  public class PrebuildTreeNode : TreeNode {
    /// <summary>
    /// Initializes a new instance of the <see cref="PrebuildTreeNode"/> class.
    /// </summary>
    /// <param name="imgIndex">Index of the img.</param>
    public PrebuildTreeNode ( int imgIndex )
      : base ( "Prebuild", imgIndex, imgIndex ) {

    }
  }
  /// <summary>
  /// A Custom TreeNode
  /// </summary>
  public class ExtensionTreeNode : TreeNode {
    /// <summary>
    /// Initializes a new instance of the <see cref="ExtensionTreeNode"/> class.
    /// </summary>
    /// <param name="imgIndex">Index of the img.</param>
    public ExtensionTreeNode (int imgIndex) : base ("Project Extensions",imgIndex,imgIndex) {
    }
  }

  /// <summary>
  /// A Custom TreeNode
  /// </summary>
  public class ExtensionItemTreeNode : TreeNode {
    private ProjectExtension extension;
    /// <summary>
    /// Initializes a new instance of the <see cref="ExtensionItemTreeNode"/> class.
    /// </summary>
    /// <param name="extension">The extension.</param>
    /// <param name="imgIndex">Index of the img.</param>
    public ExtensionItemTreeNode (ProjectExtension extension, int imgIndex ) : base (extension.ToString(),imgIndex,imgIndex) {
      this.extension = extension;
    }

    /// <summary>
    /// Gets or sets the project extension.
    /// </summary>
    /// <value>The project extension.</value>
    public ProjectExtension ProjectExtension { get { return this.extension; } set { this.extension = value; } }
  }

  /// <summary>
  /// A Custom TreeNode
  /// </summary>
  public class ProjectTreeNode : TreeNode {
    private Project proj;
    /// <summary>
    /// Initializes a new instance of the <see cref="ProjectTreeNode"/> class.
    /// </summary>
    /// <param name="proj">The proj.</param>
    /// <param name="imgIndex">Index of the img.</param>
    public ProjectTreeNode ( Project proj, int imgIndex )
      : base ( proj.Name, imgIndex, imgIndex ) {
      this.Tag = proj.GetHashCode ();
      this.proj = proj;
    }

    /// <summary>
    /// Gets the project.
    /// </summary>
    /// <value>The project.</value>
    public Project Project { get { return this.proj; } }
  }
  /// <summary>
  /// A Custom TreeNode
  /// </summary>
  public class PublisherTaskItemTreeNode : TreeNode {
    private PublisherTask _pub = null;
    /// <summary>
    /// Initializes a new instance of the <see cref="PublisherTaskItemTreeNode"/> class.
    /// </summary>
    /// <param name="pt">The pt.</param>
    /// <param name="imgIndex">Index of the img.</param>
    public PublisherTaskItemTreeNode ( PublisherTask pt, int imgIndex )
      : base ( pt.GetType ().Name, imgIndex, imgIndex ) {
      this._pub = pt;
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="PublisherTaskItemTreeNode"/> class.
    /// </summary>
    public PublisherTaskItemTreeNode () {

    }

    /// <summary>
    /// Gets the publisher task.
    /// </summary>
    /// <value>The publisher task.</value>
    public PublisherTask PublisherTask { get { return this._pub; } set { this._pub = value; } }
  }
  /// <summary>
  /// A Custom TreeNode
  /// </summary>
  public class TriggerItemTreeNode : TreeNode {
    private Trigger _trig = null;
    /// <summary>
    /// Initializes a new instance of the <see cref="TriggerItemTreeNode"/> class.
    /// </summary>
    /// <param name="trig">The trig.</param>
    /// <param name="imgIndex">Index of the img.</param>
    public TriggerItemTreeNode ( Trigger trig, int imgIndex )
      : base ( trig.GetType ().Name, imgIndex, imgIndex ) {
      this._trig = trig;
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="TriggerItemTreeNode"/> class.
    /// </summary>
    public TriggerItemTreeNode () {

    }

    /// <summary>
    /// Gets the trigger.
    /// </summary>
    /// <value>The trigger.</value>
    public Trigger Trigger { get { return this._trig; } set { this._trig = value; } }
  }

  /// <summary>
  /// A Custom TreeNode
  /// </summary>
  public class ProjectQueuesTreeNode : TreeNode {
    /// <summary>
    /// Initializes a new instance of the <see cref="ProjectQueuesTreeNode"/> class.
    /// </summary>
    public ProjectQueuesTreeNode ( ) : base("Integration Queues") {

    }
    /// <summary>
    /// Refreshes the queue.
    /// </summary>
    public void RefreshQueue ( ) { 
    
    }

    public void CreateQueue ( Project project ) {

    }
  }

  public class IntegrationQueueTreeNode : TreeNode {
    public IntegrationQueueTreeNode ( string name ) : base(name) {

    }
  }
}

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace CCNetConfig.Components {
  /// <summary>
  /// A Tool Strip Menu Item that takes a <see cref="CCNetConfig.Core.PublisherTask"/>
  /// </summary>
  public class TaskToolStripMenuItem : ToolStripMenuItem {
    PublisherTaskItemTreeNode ptit = null;
    ProjectTreeNode ptn = null;
    /// <summary>
    /// Initializes a new instance of the <see cref="TaskToolStripMenuItem"/> class.
    /// </summary>
    /// <param name="textFormat">The text format.</param>
    /// <param name="ptit">The PublisherTaskItemTreeNode.</param>
    /// <param name="parentProject">The parent project.</param>
    public TaskToolStripMenuItem( string textFormat, PublisherTaskItemTreeNode ptit, ProjectTreeNode parentProject ) : base(string.Format(textFormat,ptit.PublisherTask.ToString(),parentProject.Project.ToString())) {
      ptn = parentProject;
      this.ptit = ptit;
    }

    /// <summary>
    /// Gets the project tree node.
    /// </summary>
    /// <value>The project tree node.</value>
    public ProjectTreeNode ProjectTreeNode { get { return this.ptn; } }
    /// <summary>
    /// Gets the publisher task item tree node.
    /// </summary>
    /// <value>The publisher task item tree node.</value>
    public PublisherTaskItemTreeNode PublisherTaskItemTreeNode { get { return this.ptit; } }
  }
  /// <summary>
  /// A Tool Strip Menu Item that takes a <see cref="CCNetConfig.Core.PublisherTask"/>
  /// </summary>
  public class PublisherToolStripMenuItem : TaskToolStripMenuItem {
    /// <summary>
    /// Initializes a new instance of the <see cref="PublisherToolStripMenuItem"/> class.
    /// </summary>
    /// <param name="textFormat">The text format.</param>
    /// <param name="ptit">The PublisherTaskItemTreeNode.</param>
    /// <param name="parentProject">The parent project.</param>
    public PublisherToolStripMenuItem ( string textFormat, PublisherTaskItemTreeNode ptit, ProjectTreeNode parentProject )
      : base ( textFormat, ptit, parentProject ) {

    }
  }
  /// <summary>
  /// A Tool Strip Menu Item that takes a <see cref="CCNetConfig.Core.Trigger"/>
  /// </summary>
  public class TriggerToolStripMenuItem : ToolStripMenuItem {
    ProjectTreeNode ptn = null;
    TriggerItemTreeNode titn = null;
    /// <summary>
    /// Initializes a new instance of the <see cref="TriggerToolStripMenuItem"/> class.
    /// </summary>
    /// <param name="textFormat">The text format.</param>
    /// <param name="titn">The titn.</param>
    /// <param name="parentProject">The parent project.</param>
    public TriggerToolStripMenuItem (string textFormat, TriggerItemTreeNode titn, ProjectTreeNode parentProject ) : base(string.Format(textFormat,titn.Trigger.ToString(), parentProject.Project.Name) ) {
      this.ptn = parentProject;
      this.titn = titn;
    }

    /// <summary>
    /// Gets the trigger tree node.
    /// </summary>
    /// <value>The trigger tree node.</value>
    public TriggerItemTreeNode TriggerTreeNode { get { return this.titn; } }
    /// <summary>
    /// Gets the project tree node.
    /// </summary>
    /// <value>The project tree node.</value>
    public ProjectTreeNode ProjectTreeNode { get { return this.ptn; } }

  }
}
