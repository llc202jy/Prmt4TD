/*
 * Copyright (c) 2002, The Keel Group, Ltd. All rights reserved.
 *
 * This software is made available under the terms of the license found
 * in the LICENSE file, included with this source code. The license can
 * also be found at:
 * http://www.keelframework.net/LICENSE
 */
package org.keel.services.authentication.kerb5;
import java.security.Principal;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.security.auth.Subject;
import javax.security.auth.kerberos.KerberosPrincipal;
import javax.security.auth.login.AccountExpiredException;
import javax.security.auth.login.CredentialExpiredException;
import javax.security.auth.login.FailedLoginException;
import javax.security.auth.login.LoginException;

import org.apache.avalon.framework.configuration.Configuration;
import org.apache.avalon.framework.configuration.ConfigurationException;
import org.keel.services.authentication.AbstractAuthenticationManager;
import org.keel.services.authentication.DomainPrincipal;
import org.keel.services.authentication.LoginPrincipal;
import org.keel.services.authentication.UserDescripPrincipal;
import org.keel.services.authentication.UserEnvironment;

/**
 *
 * @avalon.component
 * @avalon.service type=org.keel.services.authentication.AuthenticationManager
 * @x-avalon.info name=kerb5-authentication
 * @x-avalon.lifestyle type=transient
 *
 * @version	$Revision: 1.3 $	$Date: 2005/05/14 15:56:25 $
 * @author Shash Chatterjee modified by Gene McCullough
 * Created on Jun 9, 2003
 */
public class Kerb5AuthenticationManager extends AbstractAuthenticationManager {

    private String loginModule = "Kerb5Login";

	/**
	 * @see org.keel.services.authentication.AuthenticationManager#login()
	 */
	public void login(UserEnvironment ue) throws LoginException {
		try {
			// attempt authentication

			super.login(ue);
		} catch (SecurityException se) {
			throw new LoginException("Cannot create LoginContext. "
				+ se.getMessage());
		} catch (AccountExpiredException aee) {
			throw new LoginException(
				"Account has expired for user - "
					+ getDomain()
					+ "/"
					+ getUsername()
					+ ". "
					+ "Please notify your administrator.");
		} catch (CredentialExpiredException cee) {
			throw new LoginException(
				"Credentials have expired for user - "
					+ getDomain()
					+ "/"
					+ getUsername());
		} catch (FailedLoginException fle) {
			throw new LoginException(
				"Authentication Failed for user - "
					+ getDomain()
					+ "/"
					+ getUsername());
		} catch (Exception e) {
			throw new LoginException("Unexpected Exception - unable to continue:\n" + e.getMessage());
		}
	}

	/**
	 *
	 */
	protected Subject addKeelCredentials(Subject subject) {

		Set s = subject.getPrincipals();
		//Can't modify Set while iterating over it....so here's a trick
		Iterator i = new HashSet(s).iterator();
		Principal newPrincipal = null;
		String loginName = null;
		while (i.hasNext()) {
			Principal p = (Principal) i.next();
			if (p instanceof KerberosPrincipal) {
				loginName = p.getName();
				newPrincipal = new LoginPrincipal(loginName);

			} else {
				//Ignore for now....
			}
			s.add(newPrincipal);
		}

		newPrincipal = new DomainPrincipal(domain);
		s.add(newPrincipal);

		if (loginName != null) {
			newPrincipal = new UserDescripPrincipal(loginName);
			s.add(newPrincipal);
		}

		return subject;
	}

	/* (non-Javadoc)
	 * @see org.keel.services.authentication.AbstractAuthenticationManager#getDefaultLoginModuleName()
	 */
	protected String getDefaultLoginModuleName() {
		return loginModule;
	}

	/**
	 * @see org.apache.avalon.framework.configuration.Configurable#configure(org.apache.avalon.framework.configuration.Configuration)
	 */
	public void configure(Configuration cfg)
		throws ConfigurationException {
		super.configure(cfg);

		domain = cfg.getAttribute("domain", "default");
		loginModule = cfg.getAttribute("login-module", "Kerb5Login");
	}

}
