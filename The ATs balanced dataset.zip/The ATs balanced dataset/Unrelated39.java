import java.rmi.RemoteException;
import org.smartfrog.sfcore.prim.Prim;
import org.smartfrog.sfcore.common.SmartFrogException;

/**
 * Emailer Interface. 
 * @author Ashish Awasthi
 */ 
public interface Emailer extends Prim {
    
    //SmartFrog attributes for the emailer component
    public static String TO = "to";
    public static String CC = "cc";
    public static String FROM = "from";
    public static String SUBJECT = "subject";
    public static String MESSAGE = "message";
    public static String ATTACHMENTS = "attachments";
    public static String SMTP_HOST = "smtpHost";
    public static String CHARSET = "charset";
    public static String RUNASWFCOMPONENT = "runAsWorkFlowComponent";
    public static String SEND_ON_STARTUP = "sendOnStartup";
    public static String SEND_ON_SHUTDOWN = "sendOnShutdown";

     /**
     * Sends a single part message using to, from subject attributes defined in
     * the Emailer component
     * @param message Message body
     * @throws SmartFrogException if any error while sending the email
     * @throws RemoteException if any rmi or network error
     */
    public void sendEmail(String message) 
                                throws SmartFrogException, RemoteException;
    /**
     * Sends a single part message using to, from attributes defined in
     * the Emailer component
     * @param subject The subject text that overrides the default value
     * @param message Message body
     * @throws SmartFrogException if any error while sending the email
     * @throws RemoteException if any rmi or network error
     */
    public void sendEmail(String subject, String message) 
                                throws SmartFrogException, RemoteException;
    /**
     * Sends a single part message.
     * @param to comma separated list of email ids
     * @param cc comma separated list of email ids
     * @param from from address
     * @param subject The subject text that overrides the default value
     * @param message Message body
     * @throws SmartFrogException if any error while sending the email
     * @throws RemoteException if any rmi or network error
     */
    public void sendEmail(String to, String cc, String from, 
        String subject, String message)
                                throws SmartFrogException, RemoteException;

    /**
     * send the message we are configured to send.
     *
     * @throws SmartFrogException
     * @throws RemoteException
     */
    public void sendConfiguredMessage() throws SmartFrogException, RemoteException;
}
/** (C) Copyright 1998-2005 Hewlett-Packard Development Company, LP

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

For more information: www.smartfrog.org

*/
package org.smartfrog.services.anubis.basiccomms.connectiontransport;





import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;

import org.smartfrog.services.anubis.partition.wire.WireSizes;



/**
 * ConnectionAddress is a class used to represent an endpoint for a
 * tcp connection. Its for convienience.
 */
public class ConnectionAddress implements Cloneable, WireSizes {

    public InetAddress   ipaddress;
    public int           port;

    static final private int nullAddress = 0;
    static final private int lengthIdx   = 0;
    static final private int addressIdx  = intSz;
    static final private int portIdx     = addressIdx + maxInetAddressSz;
    static final public int connectionAddressWireSz = portIdx + intSz;

    /**
     * constructing from given parameters
     */
    public ConnectionAddress(InetAddress address, int port) {

        this.ipaddress  = address;
        this.port       = port;
    }


    public static ConnectionAddress readWireForm(ByteBuffer bytes, int idx) {

        int length = bytes.getInt(idx + lengthIdx);
        if( length == nullAddress )
            return null;

        byte[] address = new byte[length];
        for(int i = 0; i < address.length; i++)
            address[i] = bytes.get(idx + addressIdx + i);
        InetAddress inetAddress = null;
        try {
            inetAddress = InetAddress.getByAddress(address);
        } catch (UnknownHostException ex) {
            return null;
        }

        int port = bytes.getInt(idx + portIdx);
        return new ConnectionAddress(inetAddress, port);
    }

    public static void writeNullWireForm(ByteBuffer bytes, int idx) {
        bytes.putInt(idx, nullAddress);
    }

    public void writeWireForm(ByteBuffer bytes, int idx) {
        byte[] address = ipaddress.getAddress();
        bytes.putInt(idx + lengthIdx, address.length);
        for(int i = 0; i < address.length; i++)
            bytes.put(idx + addressIdx + i, address[i]);
        bytes.putInt(idx + portIdx, port);
    }



    /**
     * toString for debug purposes
     */
    public String toString() {
        return ipaddress.toString() + ":" + port;
    }



    /**
     * test to see if this is a null address
     */
    public boolean isNullAddress() {
        return ipaddress == null;
    }


    public Object clone() {
        try {
            ConnectionAddress addr = (ConnectionAddress)super.clone();
            return addr;
        }
        catch (CloneNotSupportedException ex) {
            return null;
        }
    }
}
