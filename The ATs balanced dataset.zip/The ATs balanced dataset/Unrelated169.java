  public void updateCache(CacheInvalidationInfo cacheInfo) {
        Iterator iter = null;

        lastAccessTime = System.currentTimeMillis();
        synchronized (lockObject) {
            iter = cacheInfo.getDeletedOids();
            while (iter.hasNext()) {
                Oid oid = null;
                
                oid = (Oid) iter.next();
                dataObjects.remove(oid.toString());
                if (log.isDebugEnabled()) {
                    log.debug("UPDATE_CACHE: removing " + oid);
                }
            }
            
            iter = cacheInfo.getModifiedOids();
            while (iter.hasNext()) {
                Oid oid = null;
                DataShell shell = null;
                
                oid = (Oid) iter.next();
                shell = (DataShell) dataObjects.get(oid.toString());
                if (shell != null) {
                    if (!shell.getData().isDirty()) {
                        
                        /*
                         * Only make it hollow if the object isn't dirty
                         * in the local persistent manager.
                         */

                        shell.getData().setHollow();
                        if (log.isDebugEnabled()) {
                            log.debug("UPDATE_CACHE: making hollow " + oid);
                        }
                    }
                }
            }
            
            iter = cacheInfo.getListInvalidators();
            while (iter.hasNext()) {
                ListInvalidator li = null;
                
                li = (ListInvalidator) iter.next();
                invalidateList(li.getOwningPrimaryKey(),
                               li.getForeignKeyColumnName(),
                               li.getOwnedTableName());
                if (log.isDebugEnabled()) {
                    log.debug("UPDATE_CACHE: invalidating list " + li);
                }
            }
            
            if (queryCache != null) {
                queryCache.invalidateCache(cacheInfo);
            }
        }
    }

    /**
     * Purge any objects that were created by then set to
     * be invalid.
     */
    public void purgeNewInvalidPersists() {
        lastAccessTime = System.currentTimeMillis();
        synchronized (lockObject) {
            Iterator iter = null;

            iter = createdObjects.iterator();
            while (iter.hasNext()) {
                DataShell shell = null;

                shell = (DataShell) iter.next();
                if (shell.getData().isInvalid()) {
                    iter.remove();
                }
            }

            iter = dataObjects.keySet().iterator();
            while (iter.hasNext()) {
                DataShell shell = null;

                shell = (DataShell) iter.next();
                if (shell.getData().isNew() && shell.getData().isInvalid()) {
                    iter.remove();
                }
            }
        }            
    }

    /**
     * Revert back to the state of the <code>PersistentManager</code>
     * at the time immediately after that last <code>save</code>
     * operation (or after the creation of the <code>PersistentManager</code>).
     */
    public void revert() {
        Iterator iter = null;
        LinkedList deleteObjects = null;

        lastAccessTime = System.currentTimeMillis();
        synchronized (lockObject) {
            iter = modifiedLists.iterator();
            while (iter.hasNext()) {
                ((OneToManyList) iter.next()).invalidate();
            } // end of while ()
            modifiedLists.clear();

            iter = createdObjects.iterator();
            while (iter.hasNext()) {
                DataShell shell = null;

                shell = (DataShell) iter.next();
                if (shell.getData().isValid()) {
                    iter.remove();
                }
            }
            
            /*
             * Iterate through the removed objects and "unremove"
             * them.  We do this by setting the state to hollow
             * for each item in the removedObjects list.  We 
             * blindly set them to hollow because since the state 
             * is removed we don't know if it was once Dirty.
             * After we're done clear the removed objects list.
             */
            
            iter = removedObjects.iterator();
            while (iter.hasNext()) {
                DataShell shell = null;
                
                shell = (DataShell) iter.next();
                shell.getData().setHollow();
                shell.getData().setValid();
            }
            removedObjects.clear();
            
            /*
             * Finally, let's set all of the Dirty objects to 
             * Hollow so that the next time data is accessed 
             * a database hit will be required.
             */
            
            iter = dataObjects.keySet().iterator();
            deleteObjects = new LinkedList();
            while (iter.hasNext()) {
                DataShell shell = null;
                String key = null;
                
                key = (String) iter.next();
                shell = (DataShell) dataObjects.get(key);
                
                if (shell.getData().isNew()) {
                    if (shell.getData().isValid()) {
                        
                        /*
                         * Just add to the temporary list.  These will be 
                         * removed at the end of this method.
                         */
                        
                        deleteObjects.add(key);
                    }
                } else {
                    shell.getData().setValid();
                    if (shell.getData().isDirty()) {
                        shell.getData().setHollow();
                    }
                }
            }
            
            /*
             * Finally, remove the objects from the HashMap.
             */
            
            iter = deleteObjects.iterator();
            while (iter.hasNext()) {
                String key = null;
                
                key = (String) iter.next();
                dataObjects.remove(key);
            }
        }
    }

    /**
     * Execute a raw query against the data source pointed by this
     * <code>PersistentManager</code>.  A <code>Collection</code>
     * of <code>DataRow</code> objects is returned.
     *
     * @param  query  The SQL Select statement to execute.
     *
     * @return A <code>Collection</code> of <code>DataRow</code> 
     *         objects is returned.
     */
    public Collection rawQuery(String query) throws PersistException  {
        lastAccessTime = System.currentTimeMillis();
        try {
            if (connectionMode == EJB) {
                return mdmSession.rawQuery(query, dataSourceJNDIName);
            } else if (connectionMode == LOCAL) {
                return beanInstance.rawQuery(query, dataSourceJNDIName);
            } else {
                return servletClient.rawQuery(query);
            }
        } catch (RemoteException e) {
            log.error("Error doing raw query", e);
            if (e.detail != null) {
                throw new PersistException(e.detail.getMessage());
            } else {
                throw new PersistException(e.getMessage());
            }
        }
    }

    public Collection findBy(String jndiDataSource, 
                             TableRow data, 
                             Query query) throws RemoteException {
        lastAccessTime = System.currentTimeMillis();
        query.setEscapeWhereClause(true);
        if (connectionMode == EJB) {
            return mdmSession.findBy(classInfo.getDba(), 
                                     jndiDataSource, data, 
                                     query);
        } else if (connectionMode == LOCAL) {
            return beanInstance.findBy(classInfo.getDba(), 
                                       jndiDataSource, data, 
                                       query);
        } else {
            try {
                return servletClient.findBy(classInfo.getDba(), 
                                            data, query);
            } catch (PersistException e) {
                throw new RemoteException("Error accessing servlet", e);
            }
        }
    }
}
ublic static void build() throws Exception {
        String clusterListStr = null;
        String enabledStr = null;

        if (initialized) return;

        enabledStr = System.getProperties().getProperty("org.openware.job.cache.enabled");
        if (enabledStr != null &&
            (enabledStr.toLowerCase().startsWith("t") ||
             enabledStr.toLowerCase().startsWith("y"))) {
            clusterListStr = System.getProperties().getProperty("org.openware.job.cache.nodelist");
            if (clusterListStr != null) {
                build(clusterListStr);
            }
        }
    }

    public static void build(String clusterListStr) throws Exception {
        String url = null;

        if (initialized) return;

        url = System.getProperties().getProperty("org.openware.job.cache.url");
        if (url == null) {
            throw new Exception("No URL specified");
        }
        build(clusterListStr, url);
    }


    public static void build(String clusterListStr, String url) throws Exception {
        String maxIdleTimeStr = null;
        int maxIdleTime = DEFAULT_MAX_IDLE_TIME;

        if (initialized) return;

        maxIdleTimeStr = System.getProperties().getProperty("org.openware.job.cache.maxidletime");
        if (maxIdleTimeStr != null) {
            maxIdleTime = (new Integer(maxIdleTimeStr)).intValue();
        }

        build(clusterListStr, url, maxIdleTime);
    }

   initialized = true;

        JDFServer.start(url);

        try {
            
            /*
             * Create the local cache manager.
             */

            cmanager = CacheManager.getLocalInstance();
            cmanager.setMaxIdleTime(maxIdleTime);

            /*
             * Register the local cache manager with the JDF.
             */

            JDFServer.getInstance().addObject(ICacheManager.JDF_ALIAS, cmanager);
            log.debug("Created local instance on url " + url);
        } catch (Exception e) {
            log.error("Can't create CacheManager locally", e);
        }

        /*
         * Register the urls with the local cache manager
         * to create the cluster.
         */

        if (clusterListStr != null) {
            StringTokenizer strtok = null;
            
            strtok = new StringTokenizer(clusterListStr, ",");
            while (strtok.hasMoreTokens()) {
                Location location = null;

                url = strtok.nextToken();
                if (!url.endsWith("/")) {
                    url = new String(url + "/");
                }
                cmanager.addUrl(url);
                log.debug("Added " + url + " to cluster");
            }
        }
    }
}
public class LastUsedInfo
{
    private String tableName = null;
    private String query = null;

    LastUsedInfo(String tableName, String query) {
        this.tableName = tableName;
        this.query = query;
    }

    String getTableName() {
        return tableName;
    }
    
    String getQuery() {
        return query;
    }
    
    public boolean equals(Object obj) {
        LastUsedInfo lui = null;
        boolean retvalue = false;

        if (obj == this) {
            retvalue = true;
        } else {
            try {
                lui = (LastUsedInfo) obj;
                retvalue = (lui.tableName.equals(this.tableName) &&
                            lui.query.equals(this.query));
            } catch (ClassCastException e) {

                /*
                 * This means the object is not a LastUsedInfo object
                 * and can't be equal to this LastUsedInfo object.
                 * So, just fall through and we will return false.
                 */

            }
        }

        //        System.out.println("[" + this.tableName + "][" + this.query + "] == [" + lui.tableName + "][" + lui.query + "] = " + retvalue);
        return retvalue;
    }

    public String toString() {
        return new String("[" + this.tableName + "]" +
                          "[" + this.query + "]");
    }
}

public class CacheManagerServlet extends HttpServlet {
    private static Category log = Category.getInstance(CacheManagerServlet.class.getName());
    private static boolean initialized = false;

    public void init() throws ServletException {
        String enabledStr = null;
        String clusterListStr = null;
        String maxIdleTimeStr = null;
        String url;
        int maxIdleTime;
        boolean enabled = true;

        if (initialized) return;

        enabledStr = System.getProperties().getProperty("org.openware.job.cache.enabled");
        if (enabledStr == null) {
            enabledStr = getInitParameter("enabled");
        }
        if (enabledStr != null) {
            if (enabledStr.toLowerCase().startsWith("t") ||
                enabledStr.toLowerCase().startsWith("y")) {
                enabled = true;
            } else {
                enabled = false;
            }
        }

        url = System.getProperties().getProperty("org.openware.job.cache.url");
        if (url == null) {
            url = getInitParameter("url");
            log.debug("url(servlet) = " + url);
        } else {
            log.debug("url(property) = " + url);
        }

        maxIdleTime = CacheManagerBuilder.DEFAULT_MAX_IDLE_TIME;
        maxIdleTimeStr = System.getProperties().getProperty("org.openware.job.cache.maxidletime");
        if (maxIdleTimeStr == null) {
            maxIdleTimeStr = getInitParameter("max-idle-time");
            log.debug("maxIdleTime(servlet) = " + maxIdleTimeStr);
        } else {
            log.debug("maxIdleTime(property) = " + maxIdleTimeStr);
        }

        if (maxIdleTimeStr != null) {
            maxIdleTime = (new Integer(maxIdleTimeStr)).intValue();
        }

        clusterListStr = System.getProperties().getProperty("org.openware.job.cache.nodelist");
        if (clusterListStr == null) {
            clusterListStr = getInitParameter("cluster-urls");
            log.debug("clusterListStr(servlet) = " + clusterListStr);
        } else {
            log.debug("clusterListStr(property) = " + clusterListStr);
        }
        
        try {
            if (enabled) {
                CacheManagerBuilder.build(clusterListStr, url, maxIdleTime);
                log.debug("Built the cache manager");
            }
        } catch (Exception e) {
            log.error("Can't create the CacheManager", e);
            throw new ServletException("Can't create the CacheManager: " + e);
        }
    }

    public void doPost(HttpServletRequest request, 
                       HttpServletResponse response) 
        throws ServletException, IOException {
    }

    public void doGet(HttpServletRequest request, 
                      HttpServletResponse response) 
        throws ServletException, IOException {
        doPost(request, response);
    }
}
public synchronized Collection getFromCache(TableRow tableRow, 
                                                String query) throws PersistException {
        HashMap cacheByQuery = null;
        Collection cachedResults = null;

        if (query == null) {
            return null;
        }

        cacheByQuery = (HashMap) cacheByTableName.get(tableRow.getTableName());
        if (cacheByQuery == null) {
            cacheByQuery = new HashMap();
        }

        cachedResults = (Collection) cacheByQuery.get(query);
        if (cachedResults != null) {
            LastUsedInfo lui = null;

            lui = new LastUsedInfo(tableRow.getTableName(), query);

            /*
             * Move this oid from its position to the head of the 
             * list.
             */
            
            lastUsedList.remove(lui);
            lastUsedList.addFirst(lui);
        }

        return cachedResults;
    }

