namespace Pulsatrix.Framework.Services.Scheduler
{
    public class ScheduleTask
    {
        #region Delegates

        public delegate void NoArgumentsReturningVoid();

        #endregion

        private readonly List<ScheduleTask> dependencies = new List<ScheduleTask>();
        private readonly string name;
        private readonly DispatcherPriority priority;
        private readonly List<ScheduleTask> reverseDependencies = new List<ScheduleTask>();
        private readonly ScheduleService scheduleManager;
        private readonly NoArgumentsReturningVoid updateHandler;
        private bool isScheduled;

        internal ScheduleTask(ScheduleService scheduleManager, string name, DispatcherPriority priority,
                              NoArgumentsReturningVoid updateHandler)
        {
            this.scheduleManager = scheduleManager;
            this.name = name;
            this.priority = priority;
            this.updateHandler = updateHandler;
        }

        internal List<ScheduleTask> Dependencies
        {
            get { return dependencies; }
        }

        public bool IsScheduled
        {
            get { return isScheduled; }
        }

        public string Name
        {
            get { return name; }
        }

        public DispatcherPriority Priority
        {
            get { return priority; }
        }

        internal List<ScheduleTask> ReverseDependencies
        {
            get { return reverseDependencies; }
        }

        public void ForceUpdate()
        {
            foreach (ScheduleTask task in Dependencies)
                task.ForceUpdate();
            if (isScheduled)
                Update();
        }

        public void Schedule()
        {
            if (!isScheduled)
            {
                isScheduled = true;
                scheduleManager.ScheduleInternal(this);
            }
        }

        internal void Update()
        {
            PerformanceUtility.LogInfoEvent("Start ScheduleTask.Update");
            isScheduled = false;
            scheduleManager.SetUpdatingTaskInternal(this);
            updateHandler();
            scheduleManager.SetUpdatingTaskInternal(null);
            PerformanceUtility.LogInfoEvent("End ScheduleTask.Update");
        }
    }
}using System;
using System.Collections.Generic;
using System.Windows.Threading;
using Pulsatrix.Framework.Properties;

namespace Pulsatrix.Framework.Services.Scheduler
{
    public class ScheduleService : IScheduleService
    {
        private readonly DispatcherToken[] dispatcherTokens = new DispatcherToken[11];
        private readonly Dictionary<string, ScheduleTask> taskDictionary = new Dictionary<string, ScheduleTask>();
        private readonly List<ScheduleTask> taskList = new List<ScheduleTask>();
        private ScheduleTask updatingTask;

        #region IScheduleService Members

        public ScheduleTask RegisterTask(string name, DispatcherPriority priority,
                                         ScheduleTask.NoArgumentsReturningVoid updateHandler, string[] dependencyNames)
        {
            ScheduleTask item = new ScheduleTask(this, name, priority, updateHandler);
            if (taskDictionary.ContainsKey(item.Name))
                throw new ArgumentException(Resources.CantRegisterTwoTasksWithSameName);
            if (dependencyNames != null)
            {
                foreach (string str in dependencyNames)
                {
                    if (!taskDictionary.ContainsKey(str))
                        throw new ArgumentException(Resources.CantRegisterADependencyOnANonexistentTask);
                    ScheduleTask task2 = taskDictionary[str];
                    if (task2.Priority < item.Priority)
                        throw new ArgumentException(Resources.CantRegisterADependencyOnATaskAtALowerPriorityThanYourself);
                }
                foreach (string str2 in dependencyNames)
                {
                    ScheduleTask task3 = taskDictionary[str2];
                    item.Dependencies.Add(task3);
                    task3.ReverseDependencies.Add(item);
                }
            }
            taskDictionary.Add(item.Name, item);
            taskList.Add(item);
            return item;
        }

        public void UnregisterTask(ScheduleTask task)
        {
            if (task.ReverseDependencies.Count > 0)
                throw new ArgumentException(Resources.CantRemoveATaskThatOtherTasksDependOn);
            foreach (ScheduleTask task2 in task.Dependencies)
                task2.ReverseDependencies.Remove(task);
            task.Dependencies.Clear();
            taskDictionary.Remove(task.Name);
            taskList.Remove(task);
        }

        #endregion

        private void DispatchTasksAtPriority(DispatcherPriority priority)
        {
            dispatcherTokens[(int)priority] = null;
            foreach (ScheduleTask task in taskList)
                if ((task.Priority == priority) && task.IsScheduled)
                {
                    task.Update();
                    if (priority <= DispatcherPriority.Background)
                        break;
                }
        }

        internal void ScheduleInternal(ScheduleTask task)
        {
            if (dispatcherTokens[(int)task.Priority] == null)
            {
                DispatcherToken token = new DispatcherToken(this, task.Priority);
                dispatcherTokens[(int)task.Priority] = token;
            }
        }

        internal void SetUpdatingTaskInternal(ScheduleTask task)
        {
            updatingTask = task;
        }

        #region Nested type: DispatcherToken

        private class DispatcherToken
        {
            private readonly ScheduleService manager;
            private readonly DispatcherPriority priority;

            public DispatcherToken(ScheduleService manager, DispatcherPriority priority)
            {
                this.manager = manager;
                this.priority = priority;
                Dispatcher.CurrentDispatcher.BeginInvoke(priority, new DispatcherOperationCallback(Dispatch), null);
            }

            public object Dispatch(object arg)
            {
                manager.DispatchTasksAtPriority(priority);
                return null;
            }
        }

        #endregion
    }
}