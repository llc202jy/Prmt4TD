//@license@
package net.wimpi.webmail.plugin.std.model;

import net.wimpi.text.Processor;
import net.wimpi.webmail.mail.JwmaKernel;
import net.wimpi.webmail.mail.model.JwmaMailIdentity;
import net.wimpi.webmail.mail.model.JwmaMailIdentityImpl;
import net.wimpi.webmail.mail.model.JwmaPreferencesImpl;
import net.wimpi.webmail.plugin.std.util.AbstractIdentifiable;
import net.wimpi.webmail.plugin.std.util.AssociatedAbstractIdentifiable;
import net.wimpi.webmail.plugin.std.util.Associator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.exolab.castor.jdo.Database;
import org.exolab.castor.jdo.PersistenceException;
import org.exolab.castor.jdo.TimeStampable;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Class implementing a specialized <tt>JwmaPreferencesImpl</tt>
 * for being persisted with the Castor Plugins.
 *
 * @author Dieter Wimberger
 * @version @version@ (@date@)
 */
public class CastorPreferences
    extends AbstractIdentifiable
    implements JwmaPreferencesImpl, Associator, TimeStampable {

  //logging
  private static Log log = LogFactory.getLog(CastorPreferences.class);

  //instance attributes
  private String m_UserIdentity;
  private String m_Firstname = "firstname";
  private String m_Lastname = "lastname";
  private String m_LastLogin = "Never.";
  private String m_QuoteChar = ">";
  private boolean m_AutoQuote = false;

  //Folders
  private String m_RootFolder = "";
  private String m_SentMailArchive = "sent-mail";
  private String m_ReadMailArchive = "read-mail";
  private String m_TrashFolder = "trash";
  private String m_DraftFolder = "draft";

  //Auto features
  private boolean m_AutoArchiveSent = false;
  private boolean m_AutoMoveRead = false;
  private boolean m_AutoEmpty = false;

  private String m_MessageProcessor;
  private Locale m_Locale = new Locale("en", "");

  private String m_ContactDatabase;
  private SimpleDateFormat m_DateFormat =
      (SimpleDateFormat) DateFormat.getDateInstance(DateFormat.SHORT, m_Locale);

  private String m_DefaultMailIdentity;
  private List m_MailIdentities;
  private boolean m_Expert = false;
  private boolean m_DisplayingInlined;
  private String m_Style = "";
  public int m_MessageSortCriteria;
  private int m_MessagesPerPage = 25;


  private List m_RemovedAssociations;
  private boolean m_Update = false;
  private long m_Timestamp = TimeStampable.NO_TIMESTAMP;


  /**
   * Constructs a JwmaPreferences instance.
   */
  public CastorPreferences() {
    super();
    //ensure default processor to be set
    setMessageProcessorName("");
    m_MailIdentities =
        Collections.synchronizedList(new ArrayList(5));
    m_RemovedAssociations =
        Collections.synchronizedList(new ArrayList(5));
  }//constructor

  public String getUserIdentity() {
    return m_UserIdentity;
  }//getUserIdentity

  /**
   * Sets the identity of this <tt>JwmaPreferences</tt>.
   * <p/>
   * <em>Note</em>:<br>
   * The format of the string has to be
   * <tt>&lt;username&gt;@&lt;postofficehost&gt;</tt>.
   * <br>
   *
   * @param userid the identity to be set as <tt>String</tt>.
   */
  public void setUserIdentity(String userid) {
    m_UserIdentity = userid;
  }//setUserIdentity

  public String getFirstname() {
    return m_Firstname;
  }//getFirstname

  /**
   * Sets the firstname of the owner of this
   * <tt>JwmaPreferences</tt>.
   *
   * @param firstname the owner's firstname.
   */
  public void setFirstname(String firstname) {
    m_Firstname = firstname;
  }//setFirstname

  public String getLastname() {
    return m_Lastname;
  }//getLastname

  /**
   * Sets the lastname of the owner of this
   * <tt>JwmaPreferences</tt>.
   *
   * @param lastname the owner's lastname.
   */
  public void setLastname(String lastname) {
    m_Lastname = lastname;
  }//setLastname

  public String getLastLogin() {
    return m_LastLogin;
  }//getLastLogin

  /**
   * Sets the the user's last login date and originating host.
   *
   * @param lastlogin the internet address of the last login.
   */
  public void setLastLogin(String lastlogin) {
    m_LastLogin = lastlogin;
  }//setLastLogin

  public String getQuoteChar() {
    return m_QuoteChar;
  }//getQuoteChars

  /**
   * Sets the quoting character.
   * <p/>
   * <i><b>Note</b>:
   * only the first character is taken from the String.</i>
   */
  public void setQuoteChar(String qc) {
    m_QuoteChar = "" + qc.charAt(0);
  }//setQuoteChars

  public boolean isAutoQuote() {
    return m_AutoQuote;
  }//isAutoQuote

  /**
   * Sets the flag that controls wheter messages should be automatically
   * quoted on reply.
   *
   * @param doquote true if messages being replied to  should be automatically
   *                quoted, false otherwise.
   */
  public void setAutoQuote(boolean doquote) {
    m_AutoQuote = doquote;
  }//setAutoQuote

  public String getRootFolder() {
    return m_RootFolder;
  }//getRootFolder

  /**
   * Sets the path of the mail root folder.
   *
   * @param path the path of root mail folder as
   *             <tt>String</tt>.
   */
  public void setRootFolder(String path) {
    m_RootFolder = path;
  }//setRootFolder

  public String getSentMailArchive() {
    return m_SentMailArchive;
  }//getSentMailArchive

  /**
   * Sets the path of the sent-mail-archive.
   *
   * @param path the path of the sent-mail-archive as <tt>String</tt>.
   */
  public void setSentMailArchive(String path) {
    m_SentMailArchive = path;
  }//setSentMailArchive

  public String getReadMailArchive() {
    return m_ReadMailArchive;
  }//getReadMailArchive

  /**
   * Sets the path of the read-mail-archive.
   *
   * @param path the path of the read-mail-archive as <tt>String</tt>.
   */
  public void setReadMailArchive(String path) {
    m_ReadMailArchive = path;
  }//setReadMailArchive

  public String getTrashFolder() {
    return m_TrashFolder;
  }//getTrashFolder

  /**
   * Sets the path of the trashfolder.
   *
   * @param path the path of the trashfolder as <tt>String</tt>.
   */
  public void setTrashFolder(String path) {
    m_TrashFolder = path;
  }//setTrashFolder

  public String getDraftFolder() {
    return m_DraftFolder;
  }//getDraftFolder

  /**
   * Sets the path of the draft folder.
   *
   * @param path the path of the draft folder as <tt>String</tt>.
   */
  public void setDraftFolder(String path) {
    m_DraftFolder = path;
  }//setDraftFolder

  /**
   * Sets the flag that controls wheter messages should be automatically
   * archived when sent.
   *
   * @param doarchive true if messages being sent should be automatically
   *                  archived, false otherwise.
   */
  public void setAutoArchiveSent(boolean doarchive) {
    m_AutoArchiveSent = doarchive;
  }//setAutoArchiveSent

  public boolean isAutoArchiveSent() {
    return m_AutoArchiveSent;
  }//isAutoArchiveSent

  /**
   * Sets the flag that controls wheter messages should be automatically
   * moved when read.
   *
   * @param domoveread true if read messages should be automatically
   *                   moved, false otherwise.
   */
  public void setAutoMoveRead(boolean domoveread) {
    m_AutoMoveRead = domoveread;
  }//setAutoMoveRead

  public boolean isAutoMoveRead() {
    return m_AutoMoveRead;
  }//isAutoMoveRead

  public boolean isAutoEmpty() {
    return m_AutoEmpty;
  }//isAutoEmptying

  /**
   * Sets the flag that controls wheter messages should be automatically
   * deleted from the trash on logout.
   *
   * @param b true if messages in trash should be automatically
   *          deleted on logout, false otherwise.
   */
  public void setAutoEmpty(boolean b) {
    m_AutoEmpty = b;
  }//setAutoEmpty

  public String getLanguage() {
    return m_Locale.getLanguage();
  }//getLanguage

  /**
   * Sets the language of this <tt>JwmaPreferences</tt>.
   *
   * @param str the language locale as <tt>String</tt>.
   */
  public void setLanguage(String str) {
    m_Locale = new Locale(str, "");
  }//setLanguage

  public Locale getLocale() {
    return m_Locale;
  }//getLocale

  public void setLocale(Locale locale) {
    m_Locale = locale;
    m_DateFormat =
        (SimpleDateFormat) DateFormat.getDateInstance(DateFormat.SHORT, m_Locale);
  }//setLocale


  public String getContactDatabaseID() {
    return m_ContactDatabase;
  }//getContactDatabaseID

  public void setContactDatabaseID(String dbid) {
    m_ContactDatabase = dbid;
  }//setContactDatabaseID

  public void setMessageProcessorName(String name) {
    m_MessageProcessor = name;
  }//setMessageProcessorName

  public String getMessageProcessorName() {
    if (m_MessageProcessor == null) {
      return "";
    } else {
      return m_MessageProcessor;
    }
  }//getMessageProcessorName

  public Processor getMessageProcessor() {
    return JwmaKernel.getReference().getMessageProcessor(m_MessageProcessor);
  }//getMessageProcessor

  public void setMessageProcessor(Processor processor) {
    if (processor != null) {
      m_MessageProcessor = processor.getName();
    }
  }//getMessageProcessor

  public DateFormat getDateFormat() {
    return m_DateFormat;
  }//getDateFormat

  public void setDateFormat(SimpleDateFormat dateformat) {
    m_DateFormat = dateformat;
  }//setDateFormat

  public String getDateFormatPattern() {
    return m_DateFormat.toPattern();
  }//getDateFormatPattern

  public void setDateFormatPattern(String pattern) {
    try {
      m_DateFormat.applyPattern(pattern);
    } catch (Exception ex) {
      //stick with the default
    }
  }//setDateFormatPattern

  public void setDefaultMailIdentity(String uid) {
    m_DefaultMailIdentity = uid;
    //log.debug("Set default mail identity="+uid);
  }//setDefaultMailIdentity

  public String getDefaultMailIdentity() {

    //log.debug("Get default mail identity="+m_DefaultMailIdentity);
    return m_DefaultMailIdentity;
  }//getDefaultMailIdentity

  public JwmaMailIdentity getMailIdentity() {
    return getMailIdentity(m_DefaultMailIdentity);
  }//getMailIdentity

  public Collection getMailIdentityCollection() {
    //log.debug("Getting mail identities.");
    return m_MailIdentities;
  }//getMailIdentityCollection

  public void setMailIdentityCollection(Collection collection) {
    //log.debug("Setting mail identities.");
    m_MailIdentities = Collections.synchronizedList(new ArrayList(collection));
    //ensure order
    //Collections.sort(m_MailIdentities,SortingUtil.INDEX_INCREASING);
  }//setMailIdentityCollection

  public List getMailIdentities() {
    return m_MailIdentities;
  }//getMailIdentities

  public JwmaMailIdentity[] listMailIdentities() {
    JwmaMailIdentity[] addr = new JwmaMailIdentity[m_MailIdentities.size()];
    return (JwmaMailIdentity[]) m_MailIdentities.toArray(addr);
  }//listMailIdentities

  public boolean existsMailIdentity(String uid) {
    for (Iterator iter = m_MailIdentities.iterator(); iter.hasNext();) {
      CastorMailIdentity mid = (CastorMailIdentity) iter.next();
      if (mid.equals(uid)) {
        return true;
      }
    }
    return false;
  }//existsMailIdentity

  public JwmaMailIdentity getMailIdentity(String uid) {
    for (Iterator iter = m_MailIdentities.iterator(); iter.hasNext();) {
      CastorMailIdentity mid = (CastorMailIdentity) iter.next();
      if (mid.equals(uid)) {
        return mid;
      }
    }
    return getMailIdentity(m_DefaultMailIdentity);
  }//getMailIdentity

  public void addMailIdentity(JwmaMailIdentity identity) {
    m_MailIdentities.add(identity);
    ((CastorMailIdentity) identity).setAssociatorUID(this.getUID());
  }//addMailIdentity

  public void removeMailIdentity(String uid) {
    for (Iterator iter = m_MailIdentities.iterator(); iter.hasNext();) {
      CastorMailIdentity mid = (CastorMailIdentity) iter.next();
      if (mid.equals(uid)) {
        iter.remove();
        mid.resetAssociatorUID();
        m_RemovedAssociations.add(mid);
      }
    }
  }//removeMailIdentity

  public int getMailIdentityCount() {
    return m_MailIdentities.size();
  }//getMailIdentityCount

  public boolean isExpert() {
    return m_Expert;
  }//isExpert

  public void setExpert(boolean b) {
    m_Expert = b;
  }//setExpert

  public void setStyle(String style) {
    m_Style = style;
  }//setStyle

  public String getStyle() {
    return m_Style;
  }//getStyle

  public boolean isDisplayingInlined() {
    return m_DisplayingInlined;
  }//isDisplayingInlined

  public void setDisplayingInlined(boolean b) {
    m_DisplayingInlined = b;
  }//setDisplayingInlined

  public int getMessageSortCriteria() {
    return m_MessageSortCriteria;
  }//getMessageSortCriteria

  public void setMessageSortCriteria(int messageSortCriteria) {
    m_MessageSortCriteria = messageSortCriteria;
  }//setMessageSortCriteria

  public int getMessagesPerPage() {
    return m_MessagesPerPage;
  }//getMessagesPerPage

  public void setMessagesPerPage(int num) {
    m_MessagesPerPage = num;
  }//setMessagesPerPage


  public JwmaMailIdentityImpl createMailIdentity() {
    return new CastorMailIdentity();
  }//createMailIdentity

  /**
   * Returns a clone of this preferences.
   *
   * @return the clone, or null if the cloning process failed.
   */
  public JwmaPreferencesImpl getClone() {
    try {
      CastorPreferences prefs = new CastorPreferences();
      prefs.setUserIdentity(new String(this.getUserIdentity()));
      prefs.setFirstname(new String(this.getFirstname()));
      prefs.setLastname(new String(this.getLastname()));
      prefs.setLanguage(new String(this.getLanguage()));
      prefs.setQuoteChar(new String(this.getQuoteChar()));
      prefs.setMessageProcessorName(new String(this.getMessageProcessorName()));
      prefs.setTrashFolder(new String(this.getTrashFolder()));
      prefs.setDraftFolder(new String(this.getDraftFolder()));
      prefs.setSentMailArchive(new String(this.getSentMailArchive()));
      prefs.setReadMailArchive(new String(this.getReadMailArchive()));
      prefs.setStyle(new String(this.getStyle()));
      prefs.setDateFormatPattern(new String(this.getDateFormatPattern()));
      prefs.setLastLogin(new String(this.getLastLogin()));
      prefs.setRootFolder(new String(this.getRootFolder()));

      prefs.setMessageSortCriteria(this.getMessageSortCriteria());
      prefs.setExpert(this.isExpert());
      prefs.setAutoQuote(this.isAutoQuote());
      prefs.setAutoArchiveSent(this.isAutoArchiveSent());
