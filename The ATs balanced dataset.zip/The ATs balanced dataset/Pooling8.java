package uk.ac.gla.cmt.animatics.util.pool ;

/**
 * Resource Pool interface.
 * This interface defines a reousrce pool which may be queried for is state, size and capacity
 * Classes which provide a resource pooling scheme should implement this interface
 *
 * @todo need to add basic pool accessors
 */
public interface PreLoadablePool
{
	/**
	 * Returns the current state of this PreLoadablePool.
	 * The state may be one of the predefined PoolState objects.
	 *
	 * @return the state of this PreLoadablePool
	 * @see PoolState
	 */
	public PoolState getPoolState() ;

	/**
	 * Returns the capacity of this PreLoadablePool.
	 * The capacity is a measure of the maximum number of items that this
	 * PreLoadablePool may contain.
	 *
	 * @return the capacity of this PreLoadablePool
	 * @see getSize
	 */
	public int getPoolCapacity() ;

	/**
	 * Returns the current size of this PreLoadablePool.
	 * The size is a measure of how many items this PreLoadablePool may contain.
	 * This value may never increase beyond the capacity of the pool
	 *
	 * @return the current size of this PreLoadablePool
	 */
	public int getPoolSize() ;

	//public Object popFirst() ;
	//public Object popLast() ;
}
