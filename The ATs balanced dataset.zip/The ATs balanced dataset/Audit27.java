 * Service for accessing a Requirement's audit trail (ie the Requirement's audit events).
 * 
 * @author Gregory Fouquet
 * 
 */
@Transactional(readOnly = true)
public interface RequirementAuditTrailService {
	RequirementLargePropertyChange findLargePropertyChangeById(long eventId);
	
	PagedCollectionHolder<List<RequirementAuditEvent>> findAllByRequirementVersionIdOrderedByDate(long requirementVersionId, Paging paging);

} * This interceptor transparently logs creation / last modification data of any {@link Auditable} entity.
 *
 * @author Gregory Fouquet
 *
 */
@Component("squashtest.tm.persistence.hibernate.AuditLogInterceptor")
@SuppressWarnings("serial")
public class AuditLogInterceptor extends EmptyInterceptor {
	@Override
	public boolean onFlushDirty(Object entity, Serializable id, Object[] currentState, Object[] previousState,
			String[] propertyNames, Type[] types) {
		if (isAuditable(entity)) {
			logModificationData(entity, currentState);
			return true;
		}
		return false;
	}

	private boolean isAuditable(Object entity) {
		return AnnotationUtils.findAnnotation(entity.getClass(), Auditable.class) != null;
	}

	private void logModificationData(Object entity, Object[] currentState) {
		try {
			AuditableSupport audit = findAudit(currentState);
			audit.setLastModifiedBy(getCurrentUser());
			audit.setLastModifiedOn(new Date());
		} catch (IllegalArgumentException e) {
			throw new IllegalArgumentException("Non Auditable entity is : " + entity, e);
		}
	}

	private AuditableSupport findAudit(Object[] state) {
		for (Object field : state) {
			if (field != null && field.getClass().isAssignableFrom(AuditableSupport.class)) {
				return (AuditableSupport) field;
			}
		}
		throw new IllegalArgumentException("Could not find property of type '" + AuditableSupport.class + "'");
	}

	@Override
	public boolean onSave(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
		if (isAuditable(entity)) {
			logCreationData(entity, state);
			return true;
		}
		return false;
	}

	private void logCreationData(Object entity, Object[] state) {
		try {
			AuditableSupport audit = findAudit(state);
			
			//one sets defaults only if they aren't provided at creation time
			if ( (audit.getCreatedBy() ==null) && (audit.getCreatedOn()==null)){
				
				audit.setCreatedBy(getCurrentUser());
				audit.setCreatedOn(new Date());
				
			}
			
		} catch (IllegalArgumentException e) {
			throw new IllegalArgumentException("Non Auditable entity is : " + entity, e);
		}
	}

	private String getCurrentUser() {
		return UserContextHolder.getUsername();
	}
}