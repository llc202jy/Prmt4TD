/**
 *      "Long",
        "Null",
        "UninitializedThis",
        "Object",
        "Uninitialized" };

    private int type;
	
	/**
	 * Called when text data is encountered, usually between tags.
	 *
	 * @param ch a character array of the encountered text content
	 * @param start the index in the array at which the content starts
	 * @param length the length of the data stored in the character array
	 * @since 1.0
	 */
	public void characters(char[] ch, int start, int length)
	{
		if (length > 0)
		{
			mCharacterData.append(String.copyValueOf(ch, start, length));
		}
	}
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.uwyn.rife.asm.attrs;

import com.uwyn.rife.asm.Label;

/**
 * Verification type info used by {@link StackMapAttribute}.
 * 
 * @see <a href="http://www.jcp.org/en/jsr/detail?id=139">JSR 139 : Connected
 *      Limited Device Configuration 1.1</a>
 * 
 * @see "ClassFileFormat-Java6.fm Page 138 Friday, April 15, 2005 3:22 PM"
 * 
 * @author Eugene Kuleshov
 */

public class StackMapType {

    public static final int ITEM_Top = 0;
    public static final int ITEM_Integer = 1;
    public static final int ITEM_Float = 2;
    public static final int ITEM_Double = 3;
    public static final int ITEM_Long = 4;
    public static final int ITEM_Null = 5;
    public static final int ITEM_UninitializedThis = 6;
    public static final int ITEM_Object = 7;
    public static final int ITEM_Uninitialized = 8;

    public static final String[] ITEM_NAMES = {
        "Top",
        "Integer",
        "Float",
        "Double",
        "Long",
        "Null",
        "UninitializedThis",
        "Object",
        "Uninitialized" };

    private int type;
    private Label offset;
    private String object;

    private StackMapType(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }
public class StackMapType {

    public static final int ITEM_Top = 0;
    public static final int ITEM_Integer = 1;
    public static final int ITEM_Float = 2;
    public static final int ITEM_Double = 3;
    public static final int ITEM_Long = 4;
    public static final int ITEM_Null = 5;
    public static final int ITEM_UninitializedThis = 6;
    public static final int ITEM_Object = 7;
    public static final int ITEM_Uninitialized = 8;

    public static final String[] ITEM_NAMES = {
        "Top",
        "Integer",
        "Float",
        "Double",
  
 * ASM: a very small and fast Java bytecode manipulation framework
 * Copyright (c) 2000-2005 INRIA, France Telecom
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.uwyn.rife.asm.attrs;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.uwyn.rife.asm.Attribute;
import com.uwyn.rife.asm.ByteVector;
import com.uwyn.rife.asm.ClassReader;
import com.uwyn.rife.asm.ClassWriter;
import com.uwyn.rife.asm.Label;

/**
 * StackMapAttribute is used by CDLC preverifier. Definition is given in
 * appendix "CLDC Byte Code Typechecker Specification" from CDLC 1.1
 * specification. <p> <i>Note that this implementation does not calculate
 * StackMapFrame structures from the method bytecode. If method code is changed
 * or generated from scratch, then developer is responsible to prepare a correct
 * StackMapFrame structures.</i> <p> The format of the stack map in the class
 * file is given below. In the following, <ul> <li>if the length of the
 * method's byte code1 is 65535 or less, then <tt>uoffset</tt> represents the
 * type u2; otherwise <tt>uoffset</tt> represents the type u4.</li> <li>If
 * the maximum number of local variables for the method is 65535 or less, then
 * <tt>ulocalvar</tt> represents the type u2; otherwise <tt>ulocalvar</tt>
 * represents the type u4.</li> <li>If the maximum size of the operand stack
 * is 65535 or less, then <tt>ustack</tt> represents the type u2; otherwise
 * ustack represents the type u4.</li> </ul>
 * 
 * <pre>
 * stack_map { // attribute StackMap
 *   u2 attribute_name_index;
 *   u4 attribute_length
 *   uoffset number_of_entries;
 *   stack_map_frame entries[number_of_entries];
 * }
 * </pre>
 * 
 * Each stack map frame has the following format:
 * 
 * <pre>
 * stack_map_frame {
 *   uoffset offset;
 *   ulocalvar number_of_locals;
 *   verification_type_info locals[number_of_locals];
 *   ustack number_of_stack_items;
 *   verification_type_info stack[number_of_stack_items];
 * }
 * </pre>
 * 
 * The <tt>verification_type_info</tt> structure consists of a one-byte tag
 * followed by zero or more bytes, giving more information about the tag. Each
 * <tt>verification_type_info</tt> structure specifies the verification type
 * of one or two locations.
 * 
 * <pre>
 * union verification_type_info {
 *   Top_variable_info;
 *   Integer_variable_info;
 *   Float_variable_info;
 *   Long_variable_info;
 *   Double_variable_info;
 *   Null_variable_info;
 *   UninitializedThis_variable_info;
 *   Object_variable_info;
 *   Uninitialized_variable_info;
 * }
 *      
 * Top_variable_info {
 *   u1 tag = ITEM_Top; // 0
 * }
 *      
 * Integer_variable_info {
 *   u1 tag = ITEM_Integer; // 1
 * }
 *      
 * Float_variable_info {
 *   u1 tag = ITEM_Float; // 2
 * }
 *      
 * Long_variable_info {
 *   u1 tag = ITEM_Long; // 4
 * }
 *      
 * Double_variable_info {
 *   u1 tag = ITEM_Double; // 3
 * }
 *      
 * Null_variable_info {
 *  u1 tag = ITEM_Null; // 5
 * }
 *      
 * UninitializedThis_variable_info {
 *   u1 tag = ITEM_UninitializedThis; // 6
 * }
 *      
 * Object_variable_info {
 *   u1 tag = ITEM_Object; // 7
 *   u2 cpool_index;
 * }
 *      
 * Uninitialized_variable_info {
 *   u1 tag = ITEM_Uninitialized // 8
 *   uoffset offset;
 * }
 * </pre>
 * 
 * @see <a href="http://www.jcp.org/en/jsr/detail?id=139">JSR 139 : Connected
 *      Limited Device Configuration 1.1</a>
 * 
 * @author Eugene Kuleshov
 */
public class StackMapAttribute extends Attribute {

    static final int MAX_SIZE = 65535;

    /**
     * A List of <code>StackMapFrame</code> instances.
     */
    public List frames = new ArrayList();

    public StackMapAttribute() {
        super("StackMap");
    }

    public StackMapAttribute(List frames) {
        this();
        this.frames = frames;
    }

    public List getFrames() {
        return frames;
    }

    public StackMapFrame getFrame(Label label) {
        for (int i = 0; i < frames.size(); i++) {
            StackMapFrame frame = (StackMapFrame) frames.get(i);
            if (frame.label == label) {
                return frame;
            }
        }
        return null;
    }

    public boolean isUnknown() {
        return false;
    }

    public boolean isCodeAttribute() {
        return true;
    }

    protected Attribute read(
        ClassReader cr,
        int off,
        int len,
        char[] buf,
        int codeOff,
        Label[] labels)
    {
        StackMapAttribute attr = new StackMapAttribute();
        // note that this is not the size of Code attribute
        boolean isExtCodeSize = cr.readInt(codeOff + 4) > MAX_SIZE;
        boolean isExtLocals = cr.readUnsignedShort(codeOff + 2) > MAX_SIZE;
        boolean isExtStack = cr.readUnsignedShort(codeOff) > MAX_SIZE;

        int size = 0;
        if (isExtCodeSize) {
            size = cr.readInt(off);
            off += 4;
        } else {
            size = cr.readUnsignedShort(off);
            off += 2;
        }
        for (int i = 0; i < size; i++) {
            int offset;
            if (isExtCodeSize) {
                offset = cr.readInt(off);
                off += 4;
            } else {
                offset = cr.readUnsignedShort(off);
                off += 2;
            }

            Label label = getLabel(offset, labels);
            List locals = new ArrayList();
            List stack = new ArrayList();

            off = readTypeInfo(cr,
                    off,
                    locals,
                    labels,
                    buf,
                    isExtLocals,
                    isExtCodeSize);
            off = readTypeInfo(cr,
                    off,
                    stack,
                    labels,
                    buf,
                    isExtStack,
                    isExtCodeSize);

            attr.frames.add(new StackMapFrame(label, locals, stack));
        }
        return attr;
    }

    private int readTypeInfo(
        ClassReader cr,
        int off,
        List info,
        Label[] labels,
        char[] buf,
        boolean isExt,
        boolean isExtCode)
    {
        int n = 0;
        if (isExt) {
            n = cr.readInt(off);
            off += 4;
        } else {
            n = cr.readUnsignedShort(off);
            off += 2;
        }
        for (int j = 0; j < n; j++) {
            int itemType = cr.readByte(off++);
            StackMapType typeInfo = StackMapType.getTypeInfo(itemType);
            info.add(typeInfo);
            switch (itemType) {
                case StackMapType.ITEM_Object: //
                    typeInfo.setObject(cr.readClass(off, buf));
                    off += 2;
                    break;
                case StackMapType.ITEM_Uninitialized: //
                    int offset;
                    if (isExtCode) {
                        offset = cr.readInt(off);
                        off += 4;
                    } else {
                        offset = cr.readUnsignedShort(off);
                        off += 2;
                    }
                    typeInfo.setLabel(getLabel(offset, labels));
                    break;
            }
        }
        return off;
    }

    private void writeTypeInfo(ByteVector bv, ClassWriter cw, List info, int max)
    {
        if (max > StackMapAttribute.MAX_SIZE) {
            bv.putInt(info.size());
        } else {
            bv.putShort(info.size());
        }
        for (int j = 0; j < info.size(); j++) {
            StackMapType typeInfo = (StackMapType) info.get(j);
            bv.putByte(typeInfo.getType());
            switch (typeInfo.getType()) {
                case StackMapType.ITEM_Object: //
                    bv.putShort(cw.newClass(typeInfo.getObject()));
                    break;

                case StackMapType.ITEM_Uninitialized: //
                    bv.putShort(typeInfo.getLabel().getOffset());
                    break;

            }
        }
    }

    private Label getLabel(int offset, Label[] labels) {
        Label l = labels[offset];
        if (l != null) {
            return l;
        }
        return labels[offset] = new Label();
    }
    }

    protected Label[] getLabels() {
        HashSet labels = new HashSet();
        for (int i = 0; i < frames.size(); i++) {
            getFrameLabels((StackMapFrame) frames.get(i), labels);
        }
        return (Label[]) labels.toArray(new Label[labels.size()]);
    }

    private void writeFrame(
        StackMapFrame frame,
        ClassWriter cw,
        int maxStack,
        int maxLocals,
        ByteVector bv)
    {
        bv.putShort(frame.label.getOffset());
        writeTypeInfo(bv, cw, frame.locals, maxLocals);
        writeTypeInfo(bv, cw, frame.stack, maxStack);
    }

    private void getFrameLabels(StackMapFrame frame, Set labels) {
        labels.add(frame.label);
        getTypeInfoLabels(labels, frame.locals);
        getTypeInfoLabels(labels, frame.stack);
    }

    private void getTypeInfoLabels(Set labels, List info) {
        for (Iterator it = info.iterator(); it.hasNext();) {
            StackMapType typeInfo = (StackMapType) it.next();
            if (typeInfo.getType() == StackMapType.ITEM_Uninitialized) {
                labels.add(typeInfo.getLabel());
            }
        }
    }

    public String toString() {
        StringBuffer sb = new StringBuffer("StackMap[");
        for (int i = 0; i < frames.size(); i++) {
            sb.append('\n').append('[').append(frames.get(i)).append(']');
        }
        sb.append("\n]");
        return sb.toString();*
 * Copyright 2001-2007 Geert Bevin <gbevin[remove] at uwyn dot com>
 * Licensed under the Apache License, Version 2.0 (the "License")
 * $Id: DbResultSetHandler.java 3877 2007-08-03 19:48:10Z gbevin $
 */
package com.uwyn.rife.database;

import com.uwyn.rife.database.queries.Query;
import com.uwyn.rife.tools.ExceptionUtils;
import java.sql.SQLException;
import java.util.logging.Logger;

/**
 * By extending this class it's possible to easily customize the behaviour of
 * some methods in the {@link DbQueryManager} class.
 * <p>You're able to perform custom logic with the resultset of a query by
 * overriding the {@link #concludeResults(DbResultSet) concludeResults} method
 * and returning an object.
 * <p>You're not supposed to close the resultset in this method.
 * 
 * @author Geert Bevin (gbevin[remove] at uwyn dot com)
 * @version $Revision: 3877 $
 * @see DbResultSet
 * @see DbQueryManager
 * @since 1.0
 */
public abstract class DbResultSetHandler implements Cloneable
{
	public DbStatement createStatement(DbConnection connection)
	{
		return connection.createStatement();
	}

	public DbPreparedStatement getPreparedStatement(Query query, DbConnection connection)
	{
		return connection.getPreparedStatement(query);
	}

	public Object concludeResults(DbResultSet resultset)
	throws SQLException
	{
		return null;
	}

	/**
	 * Simply clones the instance with the default clone method since this
	 * class contains no member variables.
	 * 
	 * @since 1.0
	 */
	public Object clone()
	{
		try
		{
			return super.clone();
		}
		catch (CloneNotSupportedException e)
		{
			// this should never happen
			Logger.getLogger("com.uwyn.rife.database").severe(ExceptionUtils.getExceptionStackTrace(e));
			return null;
		}
	}

 * This class parses an XML file to create a set of {@link Datasource}
 * objects.
 * <p>An example of the parsable datasource file:
 * <pre>&lt;datasources&gt;
 *  &lt;datasource name="postgres"&gt;
 *    &lt;driver&gt;org.postgresql.Driver&lt;/driver&gt;
 *    &lt;url&gt;jdbc:postgres://localhost/database&lt;/url&gt;
 *    &lt;user&gt;username&lt;/user&gt;
 *    &lt;password&gt;password&lt;/user&gt;
 *    &lt;poolsize&gt;5&lt;/poolsize&gt;
 *  &lt;/datasource&gt;
 *&lt;/datasources&gt;</pre>
 * <p>An explaination of terms:
 * <ul>
 * <li>datasource name: used to uniquely identify the datasource
 * <li>driver: the classname of the driver to use to connect
 * <li>url: the connection url used to connect
 * <li>user: the username needed for authentication
 * <li>password: the password needed for authentication
 * <li>poolsize: the number of connections to always keep connected
 * </ul>
 * Multiple datasource definitions are supported and can be used at anytime.
 *
 * @author JR Boyens (jboyens[remove] at uwyn dot com)
 * @author Geert Bevin (gbevin[remove] at uwyn dot com)
 * @version $Revision: 3884 $
 * @since 1.0
 */
public class Xml2Datasources extends Xml2Data
{
	private Datasource					mDatasource = null;
	private HashMap<String, Datasource>	mDatasources = null;
	private String						mNameAttribute = null;
	private StringBuilder				mCharacterData = null;

	/**
	 * Return the created datasources.
	 *
	 * @return the datasources created after parsing
	 * @since 1.0
	 */
	public HashMap<String, Datasource> getDatasources()
	{
		return mDatasources;
	}

	/**
	 * Clears the information in this datasource.
	 *
	 * @since 1.0
	 */
	protected void clear()
	{
		mDatasource = null;
		mDatasources = new HashMap<String, Datasource>();
		mNameAttribute = null;
		mCharacterData = null;
	}

	/**
	 * Called when the beginng of the document to be parsed is found
	 *
	 * @since 1.0
	 */
	public void startDocument()
	{
		clear();
	}

	/**
	 * Called when the start tag of an XML element is encountered
	 *
	 * @param namespaceURI the URI of the namespace of the start tag
	 * @param localName the local name of the starting element
	 * @param qName the qualified name of the starting element
	 * @param atts the attributes of the starting element
	 * @since 1.0
	 */
	public void startElement(String namespaceURI, String localName, String qName, Attributes atts)
	{
		if (qName.equals("datasource"))
		{
			mNameAttribute = atts.getValue("name");

			mDatasource = new Datasource();
		}
		else if (qName.equals("driver") ||
				 qName.equals("url") ||
				 qName.equals("user") ||
				 qName.equals("password") ||
				 qName.equals("poolsize") ||
				 qName.equals("jndi"))
		{
			mCharacterData = new StringBuilder();
		}
		else if (qName.equals("config"))
		{
			if (mCharacterData != null &&
				Config.hasRepInstance())
			{
				mCharacterData.append(Config.getRepInstance().getString(atts.getValue("param"), ""));
			}
		}
		else if (qName.equals("datasources"))
		{
			// do nothing
		}
		else
		{
			throw new XmlErrorException("Unsupport element name '"+qName+"'.");
		}
	}

	/**
	 * Called when the end tag of an XML element is encountered
	 *
	 * @param namespaceURI the URI of the namespace of the ending element
	

    protected ByteVector write(
        ClassWriter cw,
        byte[] code,
        int len,
        int maxStack,
        int maxLocals)
    {
        ByteVector bv = new ByteVector();
        if (code != null && code.length > MAX_SIZE) { // TODO verify value
            bv.putInt(frames.size());
        } else {
            bv.putShort(frames.size());
        }
        for (int i = 0; i < frames.size(); i++) {
            writeFrame((StackMapFrame) frames.get(i),
                    cw,
                    maxStack,
                    maxLocals,
                    bv);
        }
        return bv;


    public static StackMapType getTypeInfo(int itemType) {
        if (itemType < ITEM_Top || itemType > ITEM_Uninitialized) {
            throw new IllegalArgumentException("" + itemType);
        }
        return new StackMapType(itemType);
    }

    public void setLabel(Label offset) {
        this.offset = offset;
    }

    public void setObject(String object) {
        this.object = object;

		
    private Label offset;
    private String object;

    private StackMapType(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public static StackMapType getTypeInfo(int itemType) {
        if (itemType < ITEM_Top || itemType > ITEM_Uninitialized) {
            throw new IllegalArgumentException("" + itemType);
        }
        return new StackMapType(itemType);
    }

    public void setLabel(Label offset) {
        this.offset = offset;
    }

    public void setObject(String object) {
        this.object = object;
    }

    public Label getLabel() {
        return offset;
    }

    public String getObject() {
        return object;
    }

    public String toString() {
        StringBuffer sb = new StringBuffer(ITEM_NAMES[type]);
        if (type == ITEM_Object) {
            sb.append(":").append(object);
        }
        if (type == ITEM_Uninitialized) {
            sb.append(":L").append(System.identityHashCode(offset));
        }
        return sb.toString();
    }t (c) 2000-2005 INRIA, France Telecom
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.uwyn.rife.asm.attrs;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.uwyn.rife.asm.Attribute;
import com.uwyn.rife.asm.ByteVector;
import com.uwyn.rife.asm.ClassReader;
import com.uwyn.rife.asm.ClassWriter;
import com.uwyn.rife.asm.Label;

/**
 * StackMapAttribute is used by CDLC preverifier. Definition is given in
 * appendix "CLDC Byte Code Typechecker Specification" from CDLC 1.1
 * specification. <p> <i>Note that this implementation does not calculate
 * StackMapFrame structures from the method bytecode. If method code is changed
 * or generated from scratch, then developer is responsible to prepare a correct
 * StackMapFrame structures.</i> <p> The format of the stack map in the class
 * file is given below. In the following, <ul> <li>if the length of the
 * method's byte code1 is 65535 or less, then <tt>uoffset</tt> represents the
 * type u2; otherwise <tt>uoffset</tt> represents the type u4.</li> <li>If
 * the maximum number of local variables for the method is 65535 or less, then
 * <tt>ulocalvar</tt> represents the type u2; otherwise <tt>ulocalvar</tt>
 * represents the type u4.</li> <li>If the maximum size of the operand stack
 * is 65535 or less, then <tt>ustack</tt> represents the type u2; otherwise
 * ustack represents the type u4.</li> </ul>
 * 
 * <pre>
 * stack_map { // attribute StackMap
 *   u2 attribute_name_index;
 *   u4 attribute_length
 *   uoffset number_of_entries;
 *   stack_map_frame entries[number_of_entries];
 * }
 * </pre>
 * 
 * Each stack map frame has the following format:
 * 
 * <pre>
 * stack_map_frame {
 *   uoffset offset;
 *   ulocalvar number_of_locals;
 *   verification_type_info locals[number_of_locals];
 *   ustack number_of_stack_items;
 *   verification_type_info stack[number_of_stack_items];
 * }
 * </pre>
 * 
 * The <tt>verification_type_info</tt> structure consists of a one-byte tag
 * followed by zero or more bytes, giving more information about the tag. Each
 * <tt>verification_type_info</tt> structure specifies the verification type
 * of one or two locations.
 * 
 * <pre>
 * union verification_type_info {
 *   Top_variable_info;
 *   Integer_variable_info;
 *   Float_variable_info;
 *   Long_variable_info;
 *   Double_variable_info;
 *   Null_variable_info;
 *   UninitializedThis_variable_info;
 *   Object_variable_info;
 *   Uninitialized_variable_info;
 * }
 *      
 * Top_variable_info {
 *   u1 tag = ITEM_Top; // 0
 * }
 *      
 * Integer_variable_info {
 *   u1 tag = ITEM_Integer; // 1
 * }
 *      
 * Float_variable_info {
 *   u1 tag = ITEM_Float; // 2
 * }
 *      
 * Long_variable_info {
 *   u1 tag = ITEM_Long; // 4
 * }
 *      
 * Double_variable_info {
 *   u1 tag = ITEM_Double; // 3
 * }
 *      
 * Null_variable_info {
 *  u1 tag = ITEM_Null; // 5
 * }
 *      
 * UninitializedThis_variable_info {
 *   u1 tag = ITEM_UninitializedThis; // 6
 * }
 *      
 * Object_variable_info {
 *   u1 tag = ITEM_Object; // 7
 *   u2 cpool_index;
 * }
 *      
 * Uninitialized_variable_info {
 *   u1 tag = ITEM_Uninitialized // 8
 *   uoffset offset;
 * }
 * </pre>
 * 
 * @see <a href="http://www.jcp.org/en/jsr/detail?id=139">JSR 139 : Connected
 *      Limited Device Configuration 1.1</a>
 * 
 * @author Eugene Kuleshov
 */
public class StackMapAttribute extends Attribute {

    static final int MAX_SIZE = 65535;

    /**
     * A List of <code>StackMapFrame</code> instances.
     */
    public List frames = new ArrayList();

    public StackMapAttribute() {
        super("StackMap");
    }

    public StackMapAttribute(List frames) {
        this();
        this.frames = frames;
    }

    public List getFrames() {
        return frames;
    }

    public StackMapFrame getFrame(Label label) {
        for (int i = 0; i < frames.size(); i++) {
            StackMapFrame frame = (StackMapFrame) frames.get(i);
            if (frame.label == label) {
                return frame;
            }
        }
        return null;
    }

    public boolean isUnknown() {
        return false;
    }

    public boolean isCodeAttribute() {
        return true;
    }

    protected Attribute read(
        ClassReader cr,
        int off,
        int len,
        char[] buf,
        int codeOff,
        Label[] labels)
    {
        StackMapAttribute attr = new StackMapAttribute();
        // note that this is not the size of Code attribute
        boolean isExtCodeSize = cr.readInt(codeOff + 4) > MAX_SIZE;
        boolean isExtLocals = cr.readUnsignedShort(codeOff + 2) > MAX_SIZE;
        boolean isExtStack = cr.readUnsignedShort(codeOff) > MAX_SIZE;

        int size = 0;
        if (isExtCodeSize) {
            size = cr.readInt(off);
            off += 4;
        } else {
            size = cr.readUnsignedShort(off);
            off += 2;
        }
        for (int i = 0; i < size; i++) {
            int offset;
            if (isExtCodeSize) {
                offset = cr.readInt(off);
                off += 4;
            } else {
                offset = cr.readUnsignedShort(off);
                off += 2;
            }

            Label label = getLabel(offset, labels);
            List locals = new ArrayList();
            List stack = new ArrayList();

            off = readTypeInfo(cr,
                    off,
                    locals,
                    labels,
                    buf,
                    isExtLocals,
                    isExtCodeSize);
            off = readTypeInfo(cr,
                    off,
                    stack,
                    labels,
                    buf,
                    isExtStack,
                    isExtCodeSize);

            attr.frames.add(new StackMapFrame(label, locals, stack));
        }
        return attr;
    }

    private int readTypeInfo(
        ClassReader cr,
        int off,
        List info,
        Label[] labels,
        char[] buf,
        boolean isExt,
        boolean isExtCode)
    {
        int n = 0;
        if (isExt) {
            n = cr.readInt(off);
            off += 4;
        } else {
            n = cr.readUnsignedShort(off);
            off += 2;
        }
        for (int j = 0; j < n; j++) {
            int itemType = cr.readByte(off++);
            StackMapType typeInfo = StackMapType.getTypeInfo(itemType);
            info.add(typeInfo);
            switch (itemType) {
                case StackMapType.ITEM_Object: //
                    typeInfo.setObject(cr.readClass(off, buf));
                    off += 2;
                    break;
                case StackMapType.ITEM_Uninitialized: //
                    int offset;
                    if (isExtCode) {
                        offset = cr.readInt(off);
                        off += 4;
                    } else {
                        offset = cr.readUnsignedShort(off);
                        off += 2;
                    }
                    typeInfo.setLabel(getLabel(offset, labels));
                    break;
            }
        }
        return off;
    }

    private void writeTypeInfo(ByteVector bv, ClassWriter cw, List info, int max)
    {
        if (max > StackMapAttribute.MAX_SIZE) {
            bv.putInt(info.size());
        } else {
            bv.putShort(info.size());
        }
        for (int j = 0; j < info.size(); j++) {
            StackMapType typeInfo = (StackMapType) info.get(j);
            bv.putByte(typeInfo.getType());
            switch (typeInfo.getType()) {
                case StackMapType.ITEM_Object: //
                    bv.putShort(cw.newClass(typeInfo.getObject()));
                    break;

                case StackMapType.ITEM_Uninitialized: //
                    bv.putShort(typeInfo.getLabel().getOffset());
                    break;

            }
        }
    }

    private Label getLabel(int offset, Label[] labels) {
        Label l = labels[offset];
        if (l != null) {
            return l;
        }
        return labels[offset] = new Label();
    }

    protected ByteVector write(
        ClassWriter cw,
        byte[] code,
        int len,
        int maxStack,
        int maxLocals)
    {
        ByteVector bv = new ByteVector();
        if (code != null && code.length > MAX_SIZE) { // TODO verify value
            bv.putInt(frames.size());
        } else {
            bv.putShort(frames.size());
        }
        for (int i = 0; i < frames.size(); i++) {
            writeFrame((StackMapFrame) frames.get(i),
                    cw,
                    maxStack,
                    maxLocals,
                    bv);
        }
        return bv;
    }

    protected Label[] getLabels() {
        HashSet labels = new HashSet();
        for (int i = 0; i < frames.size(); i++) {
            getFrameLabels((StackMapFrame) frames.get(i), labels);
        }
        return (Label[]) labels.toArray(new Label[labels.size()]);
    }

    private void writeFrame(
        StackMapFrame frame,
        ClassWriter cw,
        int maxStack,
        int maxLocals,
        ByteVector bv)
    {
        bv.putShort(frame.label.getOffset());
        writeTypeInfo(bv, cw, frame.locals, maxLocals);
        writeTypeInfo(bv, cw, frame.stack, maxStack);
    }

    private void getFrameLabels(StackMapFrame frame, Set labels) {
        labels.add(frame.label);
        getTypeInfoLabels(labels, frame.locals);
        getTypeInfoLabels(labels, frame.stack);
    }

    private void getTypeInfoLabels(Set labels, List info) {
        for (Iterator it = info.iterator(); it.hasNext();) {
            StackMapType typeInfo = (StackMapType) it.next();
            if (typeInfo.getType() == StackMapType.ITEM_Uninitialized) {
                labels.add(typeInfo.getLabel());
            }
        }
    }

    public String toString() {
        StringBuffer sb = new StringBuffer("StackMap[");
        for (int i = 0; i < frames.size(); i++) {
            sb.append('\n').append('[').append(frames.get(i)).append(']');
        }
        sb.append("\n]");
        return sb.toString();