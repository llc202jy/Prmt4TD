 import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

 

/**

* Authentication interface to be implemented by appliations wanting to provide custom

* authentication connectors.

*/

public interface Authentication {

/**

* The KEY to use when storing the authenticated user token.

*/

public final static String HTTP_SESSION_TOKEN_KEY = "httpSessionTokenKey";

 

/**

* Generic possitive/negative authentication.

*

* @param username The username.

* @param password The password.

* @throws AuthenticationException Invalid authentication, unable to authenticate the request.

*/

public void authenticate(String username, char[] password) throws AuthenticationException;

 

/**

* Generic possitive/negativae authentication. With this method, the request and reponse object

* are used to set any specific request information during the authentication, such as the SSO

* token key. The token key could be added to the session or to the user cookie for other

* applications to access when validating a user.

*

* @param username The username.

* @param password The password.

* @param request The http request object.

* @param response The http response object.

* @throws AuthenticationException Invalid authentication, unable to authenticate the request.

*/

public void authenticate(String username, char[] password, HttpServletRequest request,

HttpServletResponse response) throws AuthenticationException;

 

/**

* Validates an existing authentication for SSO. The implementation should check the session or

* the user cookies for an existing token and then verify that token.

*

* @param request The http request object.

* @param response The http response object.

* @throws AuthenticationException Invalid authentication, unable to validate the token.

*/

public void isValidSSO(HttpServletRequest request, HttpServletResponse response)

throws AuthenticationException;

}

 * Management interface to be implemented by appliations wanting to provide identity management

* capabilities.

*/

public interface Management {

/**

* Adds a user to the identify management server.

*

* @param username The username.

* @param password The password.

* @throws InvalidUserException Unable to add the user.

*/

public void addUser(String username, char[] password) throws InvalidUserException;

 

/**

* Removes a user from the identity management server.

*

* @param username The username.

* @throws InvalidUserException Unable to remove the user.

*/

public void removeUser(String username) throws InvalidUserException;

 

/**

* Changes the password for the user.

*

* @param username The username.

* @param password The password.

* @throws InvalidUserException Unable to change the password for the user.

*/

public void changePassword(String username, char[] password) throws InvalidUserException;

 

/**

* Adds a user to a group.

*

* @param username The username.

* @param group The group.

* @throws InvalidUserException Unable to add the user to the group.

*/

public void addToGroup(String username, String group) throws InvalidUserException;

 

/**

* Adds a user to a role.

*

* @param username The username.

* @param role The group.

* @throws InvalidUserException Unable to add the user to the role.

*/

public void addToRole(String username, String role) throws InvalidUserException;

 

/**

* Removes a user from a group.

*

* @param username The username.

* @param group The group.

* @throws InvalidUserException Unable to remove the user from the group.

*/

public void removeFromGroup(String username, String group) throws InvalidUserException;

 

/**

* Removes a user from a role.

*

* @param username The username.

* @param group The group.

* @throws InvalidUserException Unable to remove the user from the group.

*/

public void removeFromRole(String username, String group) throws InvalidUserException;

}