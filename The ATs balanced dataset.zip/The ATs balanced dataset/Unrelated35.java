public class HtmlAdaptor extends PrimImpl implements Prim, HtmlAdaptorMBean, MBeanRegistration, NotificationBroadcaster {

    MBeanServer server;
    ObjectName objectName;
    HttpAdaptor httpAdaptor;
    String mbeanServerId = null;

    private NotificationBroadcasterSupport broadcaster = new NotificationBroadcasterSupport();

    private long sequenceNumber = 0;

    /**
     *  Constructor for the HtmlAdaptor object
     *
     *@exception  RemoteException  Description of the Exception
     */
    public HtmlAdaptor() throws RemoteException {
        httpAdaptor = new HttpAdaptor();
    }

    /**
     *  Allows configuring the port and to be started when the MBeanServer has
     *  registered this MBean succesfully
     *
     * @param port network port
     */
    public HtmlAdaptor(int port) throws RemoteException {
        setPort(port);
    }


// MBeanRegistration interface

    /**
     *  Keep a reference to the MBeanServer and assigned ObjectName
     *
     *@param  server                   Description of the Parameter
     *@param  name                     Description of the Parameter
     *@return                          Description of the Return Value
     *@exception  java.lang.Exception  Description of the Exception
     */

    public ObjectName preRegister(MBeanServer server, ObjectName name) throws java.lang.Exception {
        this.server = server;
        objectName = name;
        mbeanServerId = (String) server.getAttribute(new ObjectName("JMImplementation:type=MBeanServerDelegate"), "MBeanServerId");
        return httpAdaptor.preRegister(server, name);
    }

    /**
     *  If registration has not been succesfull, set reference to MBeanServer to
     *  null.
     *
     *@param  registrationDone  Description of the Parameter
     */
    public void postRegister(Boolean registrationDone) {
        if (!registrationDone.booleanValue()) {
            synchronized (this) {
                server = null;
            }
        }
        httpAdaptor.postRegister(registrationDone);
    }

    /**
     *  Stops this server
     *
     *@exception  java.lang.Exception  Description of the Exception
     */
    public void preDeregister() throws java.lang.Exception {
        httpAdaptor.preDeregister();
    }


    /**
     *  Does nothing
     */
    public void postDeregister() {
        httpAdaptor.postDeregister();
    }


// NotificationBroadcaster interface

    /**
     * Adds a listener to a registered MBean.
     *
     * @param listener The listener object which will handle the notifications emitted by the registered MBean.
     * @param filter The filter object. If filter is null, no filtering will be performed before handling notifications.
     * @param handback An opaque object to be sent back to the listener when a notification is emitted. This object
     * cannot be used by the Notification broadcaster object. It should be resent unchanged with the notification
     * to the listener.
     *
     * @exception IllegalArgumentException Listener parameter is null.
     */
    public void addNotificationListener(NotificationListener listener, NotificationFilter filter, Object handback)
        throws java.lang.IllegalArgumentException {
        broadcaster.addNotificationListener(listener, filter, handback);
    }

    /**
     * Removes a listener from a registered MBean.
     *
     * @param listener The listener object which will handle the notifications emitted by the registered MBean.
     * This method will remove all the information related to this listener.
     *
     * @exception ListenerNotFoundException The listener is not registered in the MBean.
     */
    public void removeNotificationListener(NotificationListener listener)
        throws ListenerNotFoundException {
        broadcaster.removeNotificationListener(listener);
    }

    /**
     * Returns a NotificationInfo object contaning the name of the Java class of the notification
     * and the notification types sent.
     */
    public MBeanNotificationInfo[] getNotificationInfo() {
        return new MBeanNotificationInfo[]{
            new MBeanNotificationInfo(new String[]{AttributeChangeNotification.ATTRIBUTE_CHANGE},
                                      AttributeChangeNotification.ATTRIBUTE_CHANGE,
                                      "Notify a change of state")
        };
    }

    private void sendStateNotification(boolean newState) {
        String message = "";
        if (newState == true) message = "Service started";
        else message = "Service stopped";

        Boolean newValue = new Boolean(newState);
        Boolean oldValue = new Boolean(!newState);

        broadcaster.sendNotification(
                    new AttributeChangeNotification(
                        this.objectName,
                        sequenceNumber++,
                        System.currentTimeMillis(),
                        message,
                        "Active",
                        "java.lang.Boolean",
                        oldValue,
                        newValue));
    }




// CommunicatorMBean interface

    /**
     *  Returns protocol that this Adaptor uses. Always HTTP.
     *
     *@return    HTTPServer's port
     */
    public String getProtocol() {
        return "HTTP";
    }
