* A database uses a {@link org.helidb.backend.DatabaseBackend} object for
 * reading and writing data to its backing storage. There are different backend
 * implementations that store their data differently. One implementation may be
 * optimized for fast searches and another for efficient storage. The
 * performance test results should be a good guide for selecting an appropriate
 * backend implementation depending on the expected size of the data and how the
 * database is planned to be used.
 * <p>
 * The {@link org.helidb.backend.DatabaseBackend} uses one
 * {@link org.helidb.lang.serializer.Serializer} object for serializing keys to
 * and interpreting keys in the backing storage and another {@code Serializer}
 * object for the values.
 * <p>
 * Be careful not to modify objects that are used as keys or values in the
 * database if you use a {@code Database} or a
 * {@link org.helidb.backend.DatabaseBackend} implementation that cache data.
 * Preferably, both key and value objects should be immutable.
 * <p>
 * After deleting data from the database, its backend may become fragmented. It
 * can be defragmented by calling {@link #compact()}.
 * <p>
 * The requirements for database keys are the same as for keys in a {@link Map}.
 * Specifically, the keys must have {@code equals} and {@code hashCode} methods
 * that follow {@code Map}'s contract.
 * <p>
 * If an I/O error occurs when the database accesses the backing storage, the
 * invoked database method throws an
 * {@link org.entityfs.support.exception.WrappedIOException}. This includes
 * methods inherited from {@link Map} and {@link Iterable}.
 * <p>
 * Implementations may or may not be thread safe. See each implementation class
 * for details.
 * @author Karl Gustafsson
 * @since 1.0
 * @see org.helidb.backend.DatabaseBackend
 * @see org.helidb.lang.serializer.Serializer
 * @param <K> The type of keys in the database.
 * @param <V> The type of values in the database.
 */
public interface Database<K, V> extends Map<K, V>, Iterable<Record<K, V>>
{
	/**
	 * Insert a new record in the database. The record's key must not exist
	 * already in the database.
	 * <p>
	 * This method makes sure that the supplied key is unique before the record
	 * is inserted. The {@link #fasterInsert(Object, Object)} can be used
	 * instead when the client is absolute sure that the key is unique. It
	 * should be significantly faster for large databases.
	 * @param key The record's key
	 * @param value The record's value
	 * @throws KeyExistsException If the record's key already exists in the
	 * database.
	 * @throws IllegalStateException If this database is closed.
	 * @throws ReadOnlyException If the database is read only.
	 * @see #insertOrUpdate(Object, Object)
	 * @see #update(Object, Object)
	 * @see Map#put(Object, Object)
	 * @see #fasterInsert(Object, Object)
	 */
	void insert(K key, V value) throws KeyExistsException, IllegalStateException, ReadOnlyException;

	/**
	 * This is a faster version of {@link #insert(Object, Object)} that does not
	 * check if the key already exists in the database. It is the client's
	 * responsibility to avoid key collisions.
	 * <p>
	 * The database's behavior if duplicate keys are inserted is unspecified,
	 * and it probably varies between different
	 * {@link org.helidb.backend.DatabaseBackend} implementations.
	 * @param key The record's key.
	 * @param value The record's value.
	 * @throws IllegalStateException If this database is closed.
	 * @throws ReadOnlyException If the database is read only.
	 * @see #insert(Object, Object)
	 * @see #insertOrUpdate(Object, Object)
	 * @see Map#put(Object, Object)
	 */
	void fasterInsert(K key, V value) throws IllegalStateException, ReadOnlyException;

	/**
	 * If the record's key already exists in the database, update the existing
	 * record. If not, insert a new record.
	 * <p>
	 * This method is quite similar to {@link Map#put(Object, Object)}, but its
	 * implementation should be slightly more efficient since it does not return
	 * the record's old value.
	 * @param key The record's key.
	 * @param value The record's value.
	 * @return {@code true} if an existing record was updated, {@code false} if
	 * a new record was inserted.
	 * @throws IllegalStateException If this database is closed.
	 * @throws ReadOnlyException If the database is read only.
	 * @see #insert(Object, Object)
	 * @see #update(Object, Object)
	 * @see Map#put(Object, Object)
	 * @see #fasterInsert(Object, Object)
	 */
	boolean insertOrUpdate(K key, V value) throws IllegalStateException, ReadOnlyException;

	/**
	 * Update an existing record in the database with a new value.
	 * @param key The record's key.
	 * @param value The record's new value.
	 * @throws KeyNotFoundException If no record with the key {@code key} exists
	 * in the database.
	 * @throws IllegalStateException If this database is closed.
	 * @throws ReadOnlyException If the database is read only.
	 * @see #insert(Object, Object)
	 * @see #fasterInsert(Object, Object)
	 * @see #insertOrUpdate(Object, Object)
	 * @see Map#put(Object, Object)
	 */
	void update(K key, V value) throws KeyNotFoundException, IllegalStateException, ReadOnlyException;

	/**
	 * Delete the record with the supplied key from the database. If the key
	 * does not exist in the database, this method returns {@code false}.
	 * <p>
	 * This method should be slightly more efficient than
	 * {@link Map#remove(Object)} since it does not return the record's previous
	 * value.
	 * @param key The key of the record to delete.
	 * @return {@code true} if a record was deleted, {@code false} if there was
	 * no record with the supplied key to delete.
	 * @throws IllegalStateException If this database is closed.
	 * @throws ReadOnlyException If the database is read only.
	 * @see Map#remove(Object)
	 */
	boolean delete(K key) throws IllegalStateException, ReadOnlyException;

	/**
	 * This method returns an iterator over the keys in the database. The order
	 * that the keys are returned in is dependent on the
	 * {@link org.helidb.backend.DatabaseBackend} implementation used by the
	 * database and whether the database uses an index or not. (See the class
	 * documentation above.)
	 * <p>
	 * If the database is modified after calling this method, the methods of the
	 * {@link Iterator} returned will throw
	 * {@link java.util.ConcurrentModificationException} on subsequent
	 * invocations.
	 * @return An {@link Iterator} over the database's keys.
	 * @throws IllegalStateException If this database is closed.
	 */
	Iterator<K> keyIterator() throws IllegalStateException;

	/**
	 * Get an iterator over the values in the database. The order that the
	 * values are returned in is dependent on the
	 * {@link org.helidb.backend.DatabaseBackend} implementation used by the
	 * database and whether the database uses an index or not. (See the class
	 * documentation above.)
	 * <p>
	 * If the database is modified after calling this method, the methods of the
	 * {@link Iterator} returned will throw
	 * {@link java.util.ConcurrentModificationException} on subsequent
	 * invocations.
	 * @return An {@link Iterator} over the database's values.
	 * @throws IllegalStateException If this database is closed.
	 */
	Iterator<V> valueIterator() throws IllegalStateException;

	/**
	 * Defragment the database backend. How this is done is up to the backend
	 * implementation that is used.
	 * <p>
	 * Since defragmenting a database potentially involves modifying the entire
	 * database, this method may take a long time to complete depending on the
	 * size of the database.
	 * @return {@code true} if the database was compacted, or {@code false} if
	 * there was nothing to compact.
	 * @throws IllegalStateException If this database is closed.
	 * @throws ReadOnlyException If the database is read only.
	 * @see org.helidb.backend.DatabaseBackend#compact()
	 */
	boolean compact() throws IllegalStateException, ReadOnlyException;

	/**
	 * Search for the supplied key in the database and return a {@link Cursor}
	 * at the found record.
	 * <p>
	 * The returned {@link Cursor} is valid until the database is updated.
	 * @param key The key to search for.
	 * @return A {@link Cursor} at the found record, or {@code null} if the key
	 * was not in the database.
	 * @throws IllegalStateException If this database is closed.
	 * @since 1.1
	 * @see #find(Object, SearchMode)
	 * @see #find(Object, SearchMode, Comparator)
	 */
	Cursor<K, V> find(K key) throws IllegalStateException;

	/**
	 * Search for the key in the database using the supplied {@link SearchMode}.
	 * The natural ordering of the database keys, which must be
	 * {@link Comparable}, is used to find closest matches.
	 * <p>
	 * The returned {@link Cursor} is valid until the database is updated.
	 * @param key The key to search for.
	 * @param mode The search mode. This should be a mode that is supported by
	 * the database and its backend.
	 * @return A {@link Cursor} at the found record, or {@code null} if no
	 * matching key was found.
	 * @throws IllegalStateException If this database is closed.
	 * @throws UnsupportedOperationException If the supplied search mode is not
	 * supported by the database or its backend.
	 * @since 1.1
	 * @see #find(Object)
	 * @see #find(Object, SearchMode, Comparator)
	 */
	Cursor<K, V> find(K key, SearchMode mode) throws IllegalStateException, UnsupportedOperationException;

	/**
	 * Search for the key in the database using the supplied {@link SearchMode}.
	 * The supplied {@link Comparator} is used to find closest matches.
	 * <p>
	 * The returned {@link Cursor} is valid until the database is updated.
	 * @param key The key to search for.
	 * @param mode The search mode. This should be a mode that is supported by
	 * the database and its backend.
	 * @param cmp A {@link Comparator} used for finding closest matches between
	 * the search key and the keys in the database.
	 * @return A {@link Cursor} at the found record, or {@code null} if no
	 * matching key was found.
	 * @throws IllegalStateException If this database is closed.
	 * @throws UnsupportedOperationException If the supplied search mode is not
	 * supported by the database or its backend.
	 * @since 1.1
	 * @see #find(Object)
	 * @see #find(Object, SearchMode)
	 */
	Cursor<K, V> find(K key, SearchMode mode, Comparator<? super K> cmp) throws IllegalStateException;

	/**
	 * Get a {@link Cursor} at the first record in the database. Which record
	 * that is and how the {@link Cursor} will navigate through the database is
	 * determined by the database backend's search order.
	 * <p>
	 * The returned {@link Cursor} is valid until the database is updated.
	 * @return A {@link Cursor} at the database's first record, or {@code null}
	 * if the database is empty.
	 * @throws IllegalStateException If this database is closed.
	 * @since 1.1
	 * @see #lastRecord()
	 */
	Cursor<K, V> firstRecord() throws IllegalStateException;

	/**
	 * Get a {@link Cursor} at the last record in the database. Which record
	 * that is and how the {@link Cursor} will navigate through the database is
	 * determined by the database backend's search order.
	 * <p>
	 * The returned {@link Cursor} is valid until the database is updated.
	 * @return A {@link Cursor} at the database's last record, or {@code null}
	 * if the database is empty.
	 * @throws IllegalStateException If this database is closed.
	 * @throws UnsupportedOperationException If the database backend does not
	 * support iteration backwards.
	 * @since 1.1
	 * @see #lastRecord()
	 */
	Cursor<K, V> lastRecord() throws IllegalStateException, UnsupportedOperationException;

	/**
	 * Close this database and release all resources associated with it. This
	 * method also closes the the database backend.
	 */
	void close();

	/**
	 * Is this database closed?
	 * @return {@code true} if this database is closed.
	 */
	boolean isClosed();
public class CheckAttributeSelection 
  extends CheckScheme {

    public void setSource(URL url) throws IOException {
    m_structure = null;
    setRetrieval(NONE);
    
    setSource(url.openStream());

    m_URL = url.toString();
  }
   This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 
     protected double[] libsvmToArray(String row) {
    double[]		result;
    StringTokenizer	tok;
    int			index;
	
  /**
   * Gets the results for a specified run number. Different run
   * numbers correspond to different randomizations of the data. Results
   * produced should be sent to the current ResultListener
   *
   * @param run the run number to get results for.
   * @throws Exception if a problem occurs while getting the results
   */
  public void doRun(int run) throws Exception {

    if (m_ResultProducer == null) {
      throw new Exception("No ResultProducer set");
    }
    if (m_ResultListener == null) {
      throw new Exception("No ResultListener set");
    }
    if (m_Instances == null) {
      throw new Exception("No Instances set");
    }

    // Randomize on a copy of the original dataset
    Instances runInstances = new Instances(m_Instances);
    runInstances.randomize(new Random(run));
    if (runInstances.classAttribute().isNominal()) {
      runInstances.stratify(m_StepSize);
    }

    // Tell the resultproducer to send results to us
    m_ResultProducer.setResultListener(this);

    // For each subsample size
    if (m_LowerSize == 0) {
      m_CurrentSize = m_StepSize;
    } else {
      m_CurrentSize = m_LowerSize;
    }
    while (m_CurrentSize <= m_Instances.numInstances() &&
           ((m_UpperSize == -1) ||
            (m_CurrentSize <= m_UpperSize))) {
      m_ResultProducer.setInstances(new Instances(runInstances, 0, 
                                                  m_CurrentSize));
      m_ResultProducer.doRun(run);
      m_CurrentSize += m_StepSize;
    }
  }

  
  
  /**
   * Prepare for the results to be received.
   *
   * @param rp the ResultProducer that will generate the results
   * @throws Exception if an error occurs during preprocessing.
   */
  public void preProcess(ResultProducer rp) throws Exception {

    if (m_ResultListener == null) {
      throw new Exception("No ResultListener set");
    }
    m_ResultListener.preProcess(this);
  }

  /**
   * Prepare to generate results. The ResultProducer should call
   * preProcess(this) on the ResultListener it is to send results to.
   *
   * @throws Exception if an error occurs during preprocessing.
   */
  public void preProcess() throws Exception {
    
    if (m_ResultProducer == null) {
      throw new Exception("No ResultProducer set");
    }
    // Tell the resultproducer to send results to us
    m_ResultProducer.setResultListener(this);
    m_ResultProducer.preProcess();
  }
  


  public void setOptions(String[] options) throws Exception {
    
    String stepSize = Utils.getOption('S', options);
