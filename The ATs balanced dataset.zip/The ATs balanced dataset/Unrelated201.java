/*
 * GroupPac - Copyright (C) 2000-2002 LCMI
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
package edu.lcmi.grouppac;

import org.omg.CORBA.Context;
import org.omg.CORBA.ContextList;
import org.omg.CORBA.DomainManager;
import org.omg.CORBA.ExceptionList;
import org.omg.CORBA.InterfaceDef;
import org.omg.CORBA.NO_IMPLEMENT;
import org.omg.CORBA.NVList;
import org.omg.CORBA.NamedValue;
import org.omg.CORBA.Policy;
import org.omg.CORBA.Request;
import org.omg.CORBA.SetOverrideType;
import org.omg.PortableInterceptor.ORBInitInfo;
import org.omg.PortableInterceptor.ORBInitializer;

import edu.lcmi.grouppac.util.Debug;

/**
 * This class's purpose is to "initialize" the orb, creating and activating both client and server
 * IOGR support.
 * 
 * @version $Revision: 1.12 $
 * @author <a href="mailto:padilha@das.ufsc.br">Ricardo Sangoi Padilha</a>, <a
 *         href="http://www.das.ufsc.br/">UFSC, Florian?polis, SC, Brazil</a>
 * @author <a href="mailto:luciana@das.ufsc.br">Luciana Moreira S? de Souza</a>, <a
 *         href="http://www.das.ufsc.br/">UFSC, Florian?polis, SC, Brazil</a>
 */
public class GrouppacInterceptorsInitializer implements ORBInitializer {

	/**
	 * Default Constructor.
	 */
	public GrouppacInterceptorsInitializer() {
	}

	/**
	 * @see org.omg.PortableInterceptor.ORBInitializerOperations#post_init(ORBInitInfo)
	 */
	public void post_init(ORBInitInfo orbinitinfo) {
	}

	/**
	 * @see org.omg.PortableInterceptor.ORBInitializerOperations#pre_init(ORBInitInfo)
	 */
	public void pre_init(ORBInitInfo orbinitinfo) {
		ClientIOGRSupport cis = null;
		ServerIOGRSupport sis = null;
		//LoggingMessageClientInterceptor lmci = null;
/*
 * GroupPac - Copyright (C) 2000-2002 LCMI
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
package edu.lcmi.grouppac.scg;

import java.io.IOException;
import java.util.Vector;

import org.omg.CORBA.FT.Property;
import org.omg.CORBA.FT.RequestInfo;
import org.omg.CORBA.FT.ResponseInfo;
import org.omg.CORBA.FT.scg.FIRST_RESPONSE;
import org.omg.CORBA.portable.ApplicationException;
import org.omg.CORBA.portable.Delegate;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.RemarshalException;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.InvalidName;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import org.omg.GIOP.ReplyStatusType_1_2;

import edu.lcmi.grouppac.Main;
import edu.lcmi.grouppac.ParsedIOGR;
import edu.lcmi.grouppac.util.Debug;

/**
 * This adaptor is an encapsulated, self-contained implementation for a simple TCP/IP unicast
 * diffusion. This is always shipped with GroupPac, and doesn't rely on any group communication
 * tools. It only relies on the Name Service/Replication Manager to obtain the list of members of
 * the group to open a "bunch" of plain TCP/IP connections to each one of the members.  Creation
 * date: (24/03/2002 00:01:26)
 * 
 * @version $Revision: 1.13 $
 * @author <a href="mailto:luciana@das.ufsc.br">Luciana Moreira S? de Souza</a>, <a
 *         href="http://www.das.ufsc.br/">UFSC, Florian?polis, SC, Brazil</a>
 * @author <a href="mailto:padilha@das.ufsc.br">Ricardo Sangoi Padilha</a>, <a
 *         href="http://www.das.ufsc.br/">UFSC, Florian?polis, SC, Brazil</a>
 */
public class TCPUnicastAdaptor extends AbstractSCGAdaptor {

	protected Vector results;

	public class TCPUnicastSender implements Runnable {

		private RequestInfo msg;
		private org.omg.CORBA.Object target;

		/**
		 * Creates a new TCPUnicastSender object.
		 * 
		 * @param target
		 * @param msg
		 */
		public TCPUnicastSender(org.omg.CORBA.Object target, RequestInfo msg) {
			this.target = target;
			this.msg = msg;
		}

		/**
		 * Description
		 */
		public void run() {
			Delegate deleg = getDelegate(target);
			OutputStream ros = deleg.request(target, msg.operation, msg.reply_needed);
			ros.write_octet_array(msg.args, 0, msg.args.length);
			try {
				InputStream ris = deleg.invoke(target, ros);
				byte[] result = getBuffer(ris);
				results.add(new ResponseInfo(ReplyStatusType_1_2._NO_EXCEPTION, result));
			} catch (ApplicationException e) {
				/* some user exception */
				byte[] result = getBuffer(e.getInputStream());
				results.add(new ResponseInfo(ReplyStatusType_1_2._USER_EXCEPTION, result));
			} catch (RemarshalException e) {
				/* this exception is raised when the request has to be reinvoked */
				run();
			}
			Debug.output(2, "TCPUnicastAdaptor: Method " + msg.operation + " - id: " + msg.message_id + " invoked successfully.");
		}

		/**
		 * Convenience method to return the delegate from it's reference. Contains potencially ORB
		 * dependant code.
		 * 
		 * @param o the reference
		 * @return the delegate associated to the reference
		 */
		protected Delegate getDelegate(org.omg.CORBA.Object o) {
			return ((org.omg.CORBA.portable.ObjectImpl) o)._get_delegate();
		}
	}

	/**
	 * Creates a new TCPUnicastAdaptor object.
	 */
	public TCPUnicastAdaptor() {
		super();
		init();
	}

	/**
	 * Creates a new TCPUnicastAdaptor object.
	 * 
	 * @param the_criteria
	 */
	public TCPUnicastAdaptor(Property[] the_criteria) {
		super(the_criteria);
		init();
	}

	/**
	 * @see SCGAdaptor#getResponse(RequestInfo)
	 */
	public ResponseInfo getResponse(RequestInfo msg) throws IOException {
		ResponseInfo ret = null;
		if (getResponsePolicy() == FIRST_RESPONSE.value)
			ret = (ResponseInfo) results.get(0);
		else
			ret = chooseByAverage((ResponseInfo[]) results.toArray());
		removePendingRequest(msg);
		return ret;
	}

	/**
	 * @see SCGAdaptor#close()
	 */
	public void close() {
		results.clear();
	}

	/**
	 * @see SCGAdaptor#sendRequest(RequestInfo)
	 */
	public void sendRequest(RequestInfo msg) throws IOException {
		org.omg.CORBA.Object group_ref = getReference(msg.type_id);
		ParsedIOGR p = new ParsedIOGR(group_ref);
		int k = p.getNumberOfObjects();
		if (k == 0) {
			Debug.output(2, "TCPUnicastAdaptor: There are no targets avaiable for " + msg.type_id + ". Empty IOGR.");
			return;
		}

		Debug.output(2, "TCPUnicastAdaptor: Invoking method " + msg.operation + " - id: " + msg.message_id);
		if (msg.reply_needed)
			addPendingRequest(msg);
		org.omg.CORBA.Object target;
		Runnable r;
		for (int i = 0; i < k; i++) {
			target = p.getObjectReference(i);
			r = new TCPUnicastSender(target, msg);
			new Thread(r, "Invoking " + msg.operation + " on " + msg.type_id + " : " + i).start();
		}
	}

	/**
	 * @see SCGAdaptor#startup(String)
	 */
	public void startup(String group_id) {
	}

	/**
	 * Obtains the byte[] of the request. JacORB dependant code.
	 * 
	 * @param ri InputStream from the client
	 * @return byte[] containing the request buffer
	 */
	protected byte[] getBuffer(InputStream ri) {
		org.jacorb.orb.connection.ReplyInputStream r = (org.jacorb.orb.connection.ReplyInputStream) ri;
		// get only the interesting, not the headers
		int pos = r.get_pos();
		byte[] buffer = r.getBuffer();
		byte[] ret = new byte[buffer.length - pos];
		System.arraycopy(buffer, pos, ret, 0, ret.length);
		return ret;
	}

	/**
	 * Tries to find the group from it's type_id. It's based on the assumption that a group binding
	 * name is based on it's type_id.
	 * 
	 * @param type_id
	 * @return Object
	 * @throws IOException
	 * @see ParsedIOGR#toName(String)
	 */
	protected org.omg.CORBA.Object getReference(String type_id) throws IOException {
		org.omg.CORBA.Object group_ref = null;
		String name = ParsedIOGR.toName(type_id);
		NameComponent[] nc = { new NameComponent(name, "service")};
		try {
			group_ref = Main.getNS().resolve(nc);
		} catch (NotFound e) {
		} catch (CannotProceed e) {
		} catch (InvalidName e) {
		}
		if (group_ref == null)
			throw new IOException("Group reference not available.");
		return group_ref;
	}

	/**
	 * Initialize this adaptor
	 */
	private void init() {
		results = new Vector();
	}
}/*
 * GroupPac - Copyright (C) 2000-2002 LCMI
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
package edu.lcmi.grouppac.cp;

import org.omg.CORBA.Context;
import org.omg.CORBA.ContextList;
import org.omg.CORBA.DomainManager;
import org.omg.CORBA.ExceptionList;
import org.omg.CORBA.InterfaceDef;
import org.omg.CORBA.NO_IMPLEMENT;
import org.omg.CORBA.NVList;
import org.omg.CORBA.NamedValue;
import org.omg.CORBA.Object;
import org.omg.CORBA.Policy;
import org.omg.CORBA.Request;
import org.omg.CORBA.SetOverrideType;
import org.omg.CORBA.FT.FTRecoveryRequestServiceContext;
import org.omg.CORBA.FT.FTRecoveryRequestServiceContextHelper;
import org.omg.IOP.ServiceContext;
import org.omg.PortableInterceptor.ClientRequestInfo;
import org.omg.PortableInterceptor.ClientRequestInterceptor;
import org.omg.PortableInterceptor.ForwardRequest;

import edu.lcmi.grouppac.ParsedIOGR;

/**
 * Provides IOGR support for clients. This interceptor tries each one of the profiles in the IOGR
 * before returning a definitive reference for the client. Creation date: (01/04/00 13:10:28)
 * <p>DEPRECATED: Do NOT use this class</p>
 * 
 * @version $Revision: 1.10 $
 * @author <a href="mailto:padilha@lcmi.ufsc.br">Ricardo Sangoi Padilha</a>, <a
 *         href="http://www.lcmi.ufsc.br/">UFSC, Florian?polis, SC, Brazil</a>
 */
class LoggingMessageClientInterceptor implements ClientRequestInterceptor {

	private static final boolean endianness = false;

	/**
	 * Construtor.
	 * 
	 */
	public LoggingMessageClientInterceptor() {
	}

	/*
	 * @see InterceptorOperations#destroy()
	 */
	/**
	 * Description
	 */
	public void destroy() {
	}

	/**
	 * name method comment.
	 * @return String
	 */
	public java.lang.String name() {
		return "";
	}

	/**
	 * receive_exception method comment.
	 * @param clientrequestinfo
	 * @throws org.omg.PortableInterceptor.ForwardRequest
	 */
	public void receive_exception(ClientRequestInfo clientrequestinfo) throws ForwardRequest {
	}

	/**
	 * receive_other method comment.
	 * @param clientrequestinfo
	 * @throws org.omg.PortableInterceptor.ForwardRequest
	 */
	public void receive_other(ClientRequestInfo clientrequestinfo) throws ForwardRequest {
	}

	/**
	 * receive_reply method comment.
	 * @param clientrequestinfo
	 */
	public void receive_reply(ClientRequestInfo clientrequestinfo) {
	}

	/**
	 * send_poll method comment.
	 * @param clientrequestinfo
	 */
	public void send_poll(ClientRequestInfo clientrequestinfo) {
	}

	/**
	 * send_request method comment.
	 * @param cri
	 * @throws org.omg.PortableInterceptor.ForwardRequest
	 */
	public void send_request(ClientRequestInfo cri) throws ForwardRequest {
		org.omg.CORBA.Object target = cri.target();
		edu.lcmi.grouppac.ParsedIOGR pior = new ParsedIOGR(target);
		if (pior.isRecovery()) {
			// add service context for recovery service
			FTRecoveryRequestServiceContext sc = new FTRecoveryRequestServiceContext(true);
			ServiceContext rec_sc = makeRecoverySC(sc);
			cri.add_request_service_context(rec_sc, true);
		}
	}

	/**
	 * Create a ServiceContext from the FTRecoveryRequestServiceContext.
	 * 
	 * @param sc org.omg.CORBA.FT.FTRecoveryRequestServiceContext
	 * @return org.omg.IOP.ServiceContext
	 */
	private static final ServiceContext makeRecoverySC(FTRecoveryRequestServiceContext sc) {
		org.jacorb.orb.CDROutputStream tgDataStream = new org.jacorb.orb.CDROutputStream();
		tgDataStream.write_boolean(endianness);
		FTRecoveryRequestServiceContextHelper.write(tgDataStream, sc);

		return new ServiceContext(org.omg.IOP.FT_RECOVERY_REQUEST.value, tgDataStream.getBufferCopy());
	}

	/**
	 * @see Object#_create_request(Context, String, NVList, NamedValue, ExceptionList, ContextList)
	 */
	public Request _create_request(
		Context ctx,
		String operation,
		NVList arg_list,
		NamedValue result,
		ExceptionList exclist,
		ContextList ctxlist) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see Object#_create_request(Context, String, NVList, NamedValue)
	 */
	public Request _create_request(Context ctx, String operation, NVList arg_list, NamedValue result) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see Object#_duplicate()
	 */
	public Object _duplicate() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see Object#_get_domain_managers()
	 */
	public DomainManager[] _get_domain_managers() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see Object#_get_interface_def()
	 */
	public Object _get_interface_def() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see Object#_get_interface()
	 * @deprecated
	 */
	public InterfaceDef _get_interface() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see Object#_get_policy(int)
	 */
	public Policy _get_policy(int policy_type) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see Object#_hash(int)
	 */
	public int _hash(int maximum) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see Object#_is_a(String)
	 */
	public boolean _is_a(String repositoryIdentifier) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see Object#_is_equivalent(Object)
	 */
	public boolean _is_equivalent(Object other) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see Object#_non_existent()
	 */
	public boolean _non_existent() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see Object#_release()
	 */
	public void _release() {
	}

	/**
	 * @see Object#_request(String)
	 */
	public Request _request(String operation) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see Object#_set_policy_override(Policy[], SetOverrideType)
	 */
	public Object _set_policy_override(Policy[] policies, SetOverrideType set_add) {
		throw new NO_IMPLEMENT();
	}
}package net.xmlrouter.mod_pubsub.client;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/**
 * @author msg
 * Event router that uses mod-pubsub compliant server for network messaging.
 * The openConnection() method opens a persistent connection that can deliver messages to the client 
 */
public class EventServer {
	private static String ROUTES_STR = "/kn_routes/";
	String serverURI;
	String basePath;

	/**
	 * @param server URI of message server (ex. http://localhost/kn/)
	 */
	public EventServer(String uri) throws MalformedURLException {
		this.serverURI = uri;

		try { listener the listener
	 * @param options
	 * @return a route id
	 */
	public String subscribe(String from, String to, Map options) {
		String route_id = null;
		String msg_id = getMessageId();

		// generate an id for the route we will create so we can delete it later
		route_id = getRouteId(from, msg_id);

		Map msg = new HashMap();
		java.net.HttpURLConnection conn;
		try {
			String uri;
			uri = serverURI + basePath;
			URL url = new URL(uri);

			// add some things
			msg.put("do_method", "route");
			msg.put("kn_from", from);
			msg.put("kn_to", to);
			//msg.put("kn_id",route_id);	// should we do this or not??
			//msg.put("do_max_age","3600");
			if (null != options) msg.putAll(options);
	}
}
import java.lang.*;

public class CommandRoute
{
    public String	agentID;
    public String 	routerURI;
    public String	sourceTopic;
    public String	journalTopic;
    public int		seqStart;
    public int		seqEnd;
    public int		numPublishers;

    //
    // CommandRoute::CommandRoute -
    //
    //		Constructors.
    //

    CommandRoute()
    {
	agentID       = new String();
	routerURI     = new String();
	sourceTopic   = new String();
	journalTopic  = new String();
	seqStart      = 0;
	seqEnd        = 0;
	numPublishers = 0;
    }

import java.lang.*;
import java.util.*;
import com.knownow.common.*;
import com.knownow.microserver.*;

public class RouterMap
{
    // Class variables
    private static HashMap	routerMap = new HashMap();

    //
    // RouterMap::getRouter -
    //
    //		Return a KNJServer for the given RouterURI, creating
    //		a new KNJServer instance if necessary. 
    //

    static KNJServer getRouter(String routerURI)
	throws Exception
    {
	try
	{
	    if (routerMap.containsKey(routerURI))
	    {
		return (KNJServer) routerMap.get(routerURI);
	    }
	    else
	    {
		KNJServer router = new KNJServer(routerURI);
		routerMap.put(routerURI, router);

		return router;
	    }
	}
	catch (Exception Ex)
	{
	    Common.DumpException("RouterMap", Ex);
	    return null;
	}
    }
}


