
#define COMMAND_CHECK_AUDIT_STREAM (255)

// a flag used only in this module to refer to the self player (we don't really track our own pid)
#define SELF_PSEUDOPID (-1)

//// our interface
Audit au;

//// other interfaces
ModuleManager* mm = 0;
Net* net = 0;
GameSettings* gs = 0;
SelfShip* ss = 0;
StatusModifier* status = 0;
Utilities* util = 0;
Shipman* sm = 0;
Level* level = 0;
Physics* physics = 0;
SettingsHandler* sh = 0;
SS_Items* ssi = 0;
Playerman* pm = 0;
OtherShips* os = 0;
Particles* par = 0;
Graphics* g = 0;
UniqueImage* ui = 0;
Chat* chat = 0;
Flash* flash = 0;

// prototypes
struct AuditableShip;
struct AuditableState;
BOOL particleHitAShip(Particle* p, void* param);
void pushU8(vector <u8>* vec, u8 data);
void pushU16(vector <u8>* vec, u16 data);
void pushU32(vector <u8>* vec, u32 data);
u8 popU8(vector <u8>* vec);
u16 popU16(vector <u8>* vec);
u32 popU32(vector <u8>* vec);
const char* getGameSettingsErrorMessage(int lineNum);
const char* findNextValidDumpFilename();
void checkDumpFile(const char* dumpFileName);

void pushAuditableShip(AuditableState* state, vector <u8>* vec, AuditableShip* as);
void pushParticle(vector <u8>* vec, Particle* p);

int popAuditableShip(AuditableShip* storeHere, u8* data, int len);
int popParticle(Particle** store, u8* data, int len); // the Particle* is allocated with Particles->newUnmanagedParticle, remember to Particles->disposeUnmanagedParticle

// data
StatusModification* defaultSpawn = 0;
u16 violationMilliseconds = 65000;
u8 maxIteration = 100;
u16 maxBetweenPackets = 200;
int maxMillisecondsInStream = 5000;
const int AUDITABLE_EVENT_MAXSIZE = 32;
bool disconnected = false;
bool initialized = false;
bool initialSync = false;
vector <int> initialTicks;
UpdatedSyncParam initialSyncParam;
u16 mapForcesIterationTime = 15;

struct AuditableShip
{
	ShipPhysicsData physics;
	u16 pid;
	i16 lastPositionUpdate; // server time in centiseconds
	u16 freq;
};

// types
enum EventType
{
	TYPE_SHIP_CHANGE = 0, // player changed his ship
	TYPE_NEW_KEY_STATE, // player pressed / released some keys
	TYPE_TICK, // advance time
	TYPE_SENT_POSITION_PACKET, // position packet sent
	TYPE_TIMER_SYNC, // server <-> client timer synchronization
	TYPE_SHIP_CHANGE_REQUEST, // player requested ship change
	TYPE_OTHER_PLAYER_ENTERING,
	TYPE_OTHER_PLAYER_LEAVING,
	TYPE_OTHER_PLAYER_CHANGE_SHIP,
	TYPE_OTHER_PLAYER_CHANGE_FREQ,
	TYPE_OTHER_PLAYER_POSITION,
	TYPE_OTHER_PLAYER_WEAPON,
	TYPE_FREQ_CHANGE,
	TYPE_SELF_DIED,
	TYPE_OTHER_PLAYER_DIED,
	TYPE_GOT_SERVER_SETTINGS,
	TYPE_FREQ_CHANGE_REQUEST, // player requested freq change
	TYPE_AUDITABLE_STATE,
};

const int auditableEventSize[] =
{
	3, // player changed his ship
	2, // player pressed / released some keys
	2, // advance time
	16, // position packet sent
	17, // server <-> client timer synchronization
	3, // player requested ship change
	3,
	3,
	5,
	5,
	18,
	20,
	3,
	3,
	3,
	1,
	3,
	9999999, // auditable state length is variable, don't use this
};

const char* auditableEventName[] =
{
	"TYPE_SHIP_CHANGE", // player changed his ship
	"TYPE_NEW_KEY_STATE", // player pressed / released some keys
	"TYPE_TICK", // advance time
	"TYPE_SENT_POSITION_PACKET", // position packet sent
	"TYPE_TIMER_SYNC", // server <-> client timer synchronization
	"TYPE_SHIP_CHANGE_REQUEST", // player requested ship change
	"TYPE_OTHER_PLAYER_ENTERING",
	"TYPE_OTHER_PLAYER_LEAVING",
	"TYPE_OTHER_PLAYER_CHANGE_SHIP",
	"TYPE_OTHER_PLAYER_CHANGE_FREQ",
	"TYPE_OTHER_PLAYER_POSITION",
	"TYPE_OTHER_PLAYER_WEAPON",
	"TYPE_FREQ_CHANGE",
	"TYPE_SELF_DIED",
	"TYPE_OTHER_PLAYER_DIED",
	"TYPE_GOT_SERVER_SETTINGS",
	"TYPE_FREQ_CHANGE_REQUEST",
	"TYPE_AUDITABLE_STATE",
};

struct AuditableState
{
	AuditableState()
	{
		shipIndex = freq = keys = violationTimeout = reloadingMilliseconds = packetTimeoutMilliseconds = 0; processedServerSettings = 0;
		hideMilliseconds = x = y = xvel = yvel = rot = serverTimeOffset = localMilliseconds = 0;
		shouldSendDeathPacket = sentDeathPacket = energy = killerPid = 0;
		energy = 0; shipIterationOffset = 0;

		shipIndex = ss ? ss->getSpecShipIndex() : 8;
	}

	~AuditableState()
	{
		// free particle memory
		for (list <Particle*>::iterator i = weapons.begin(); i != weapons.end(); ++i)
			par->disposeUnmanagedParticle(*i);

		weapons.clear();
	}

	u16 shipIndex;
	u16 freq;
	u8 keys;
	u8 processedServerSettings;
	u16 violationTimeout; // a violation occurred if violationTimeout > 0
	u16 reloadingMilliseconds;
	u16 packetTimeoutMilliseconds; // time until violation

	i32 hideMilliseconds;
	i32 x, y, xvel, yvel; // there are in internal units (pixels / 10000)
	i32 rot;
	i32 serverTimeOffset;
	i32 localMilliseconds; // local time, add to serverTimeOffset to get server time
	u16 shipIterationOffset;

	// we need both of these since we don't know if audit will detect it first or we'll die first
	u8 shouldSendDeathPacket;
	u8 sentDeathPacket;
	u16 killerPid;

	i32 energy;
	list <AuditableShip> ships;
	list <Particle*> weapons;

	AuditableState& operator=(const AuditableState& rhs)
	{
		shipIndex = rhs.shipIndex;
		freq = rhs.freq;
		keys = rhs.keys;
		processedServerSettings = rhs.processedServerSettings;
		violationTimeout = rhs.violationTimeout;
		reloadingMilliseconds = rhs.reloadingMilliseconds;
		packetTimeoutMilliseconds = rhs.packetTimeoutMilliseconds;

		hideMilliseconds = rhs.hideMilliseconds;
		x = rhs.x;
		y = rhs.y;
		xvel = rhs.xvel;
		yvel = rhs.yvel;
		rot = rhs.rot;
		serverTimeOffset = rhs.serverTimeOffset;
		localMilliseconds = rhs.localMilliseconds;
		shipIterationOffset = rhs.shipIterationOffset;

		shouldSendDeathPacket = rhs.shouldSendDeathPacket;
		sentDeathPacket = rhs.sentDeathPacket;
		killerPid = rhs.killerPid;

		energy = rhs.energy;
		ships = rhs.ships;

		// deep copy weapons
		// free old particle memory
		for (list <Particle*>::iterator i = weapons.begin(); i != weapons.end(); ++i)
			par->disposeUnmanagedParticle(*i);

		weapons.clear();

		// allocate new particle memory
		for (list <Particle*>::const_iterator i = rhs.weapons.begin(); i != rhs.weapons.end(); ++i)
		{
			Particle* right = *i;

			Particle* p = par->newUnmanagedParticle(right->name, &right->pos, &right->vel);

			*p = *right;

			weapons.push_back(p);
		}

		return *this;
	}

	// can't just compare structures because of strings (ships[x].physics.name) and pointers(weapons[x])
	// returns 0 if same state, or violation otherwise
	char isSameState(AuditableState* other)
	{
		int rv = 0;

		if (rv == 0 && shipIndex != other->shipIndex) rv = MISMATCH_SHIPINDEX;
		if (rv == 0 && freq != other->freq) rv = MISMATCH_FREQ;
		if (rv == 0 && keys != other->keys) rv = MISMATCH_KEYS;
		if (rv == 0 && processedServerSettings != other->processedServerSettings) rv = MISMATCH_PROCESSEDSERVERSETTINGS;
		if (rv == 0 && violationTimeout != other->violationTimeout)	rv = MISMATCH_VIOLATIONTIMEOUT;
		if (rv == 0 && reloadingMilliseconds != other->reloadingMilliseconds) rv = MISMATCH_RELOADING;
		if (rv == 0 && packetTimeoutMilliseconds != other->packetTimeoutMilliseconds) rv = MISMATCH_PACKETTIMEOUT;

		if (rv == 0 && hideMilliseconds != other->hideMilliseconds) rv = MISMATCH_HIDEMILLI;
		if (rv == 0 && x != other->x) rv = MISMATCH_X;
		if (rv == 0 && y != other->y) rv = MISMATCH_Y;
		if (rv == 0 && xvel != other->xvel) rv = MISMATCH_XVEL;
		if (rv == 0 && yvel != other->yvel) rv = MISMATCH_YVEL;
		if (rv == 0 && rot != other->rot) rv = MISMATCH_ROT;
		if (rv == 0 && serverTimeOffset != other->serverTimeOffset) rv = MISMATCH_SERVERTIMEOFFSET;
		if (rv == 0 && localMilliseconds != other->localMilliseconds) rv = MISMATCH_LOCALMILLISECONDS;
		if (rv == 0 && shipIterationOffset != other->shipIterationOffset) rv = MISMATCH_SELFSHIPITERATIONOFFSET;

		if (rv == 0 && shouldSendDeathPacket != other->shouldSendDeathPacket) rv = MISMATCH_SHOULDSENDDEATHPACKET;
		if (rv == 0 && sentDeathPacket != other->sentDeathPacket) rv = MISMATCH_SENTDEATHPACKET;
		if (rv == 0 && killerPid != other->killerPid) rv = MISMATCH_KILLERPID;

		if (rv == 0 && energy != other->energy) rv = MISMATCH_ENERGY;

		if (rv == 0 && ships.size() != other->ships.size()) rv = MISMATCH_OTHERSHIPS_SIZE;
		if (rv == 0 && weapons.size() != other->weapons.size()) rv = MISMATCH_WEAPONS_SIZE;

		if (rv == 0)
		{
			// check each ship; we already checked that sizes are same
			list <AuditableShip>::iterator i = ships.begin();
			list <AuditableShip>::iterator j = other->ships.begin();

			while (true)
			{
				if (i == ships.end())
					break;

				if (rv == 0 && i->physics.hideMilliseconds != j->physics.hideMilliseconds) rv = MISMATCH_SHIPS_HIDEMILLI;
				if (rv == 0 && i->freq != j->freq) rv = MISMATCH_SHIPS_FREQ;
				if (rv == 0 && i->lastPositionUpdate != j->lastPositionUpdate) rv = MISMATCH_SHIPS_LASTPOS;
				if (rv == 0 && i->pid != j->pid) rv = MISMATCH_SHIPS_PID;
				if (rv == 0 && i->physics.loc.x != j->physics.loc.x) rv = MISMATCH_SHIPS_LOCX;
				if (rv == 0 && i->physics.loc.y != j->physics.loc.y) rv = MISMATCH_SHIPS_LOCY;
				if (rv == 0 && i->physics.rot != j->physics.rot) rv = MISMATCH_SHIPS_ROT;
				if (rv == 0 && i->physics.vel.x != j->physics.vel.x) rv = MISMATCH_SHIPS_VELX;
				if (rv == 0 && i->physics.vel.y != j->physics.vel.y) rv = MISMATCH_SHIPS_VELY;
				if (rv == 0 && i->physics.physicsIterationOffset != j->physics.physicsIterationOffset) rv = MISMATCH_SHIPS_ITERATION_OFFSET;
				if (rv == 0 && i->physics.adjustMills != j->physics.adjustMills) rv = MISMATCH_SHIPS_ADJUST_MILLS;
				if (rv == 0 && i->physics.adjustVel.x != j->physics.adjustVel.x) rv = MISMATCH_SHIPS_ADJUST_VELX;
				if (rv == 0 && i->physics.adjustVel.y != j->physics.adjustVel.y) rv = MISMATCH_SHIPS_ADJUST_VELY;


				if (rv == 0 && strcmp(i->physics.shipName, j->physics.shipName) != 0) rv = MISMATCH_SHIPS_SHIPNAME;

				// increment
				++i;
				++j;
			}

			// check each particle; we already checked that sizes are same
			list <Particle*>::iterator i2 = weapons.begin();
			list <Particle*>::iterator j2 = other->weapons.begin();

			while (true)
			{
				if (i2 == weapons.end())
					break;

				Particle* p1 = *i2;
				Particle* p2 = *j2;

				if (rv == 0 && strcmp(p1->name, p2->name) != 0) rv = MISMATCH_WEAPONS_NAME;
				if (rv == 0 && p1->bouncesRemaining != p2->bouncesRemaining) rv = MISMATCH_WEAPONS_BOUNCES;
				if (rv == 0 && p1->collideWithPlayers != p2->collideWithPlayers) rv = MISMATCH_WEAPONS_COLLIDES;
				if (rv == 0 && p1->firedByPid != p2->firedByPid) rv = MISMATCH_WEAPONS_FIREDPID;
				if (rv == 0 && p1->freq != p2->freq) rv = MISMATCH_WEAPONS_FREQ;
				if (rv == 0 && p1->millExisted != p2->millExisted) rv = MISMATCH_WEAPONS_MILLEXISTED;
				if (rv == 0 && p1->millisecondsLeftAlive != p2->millisecondsLeftAlive) rv = MISMATCH_WEAPONS_MILLSLEFTALIVE;
				if (rv == 0 && p1->pos.x != p2->pos.x) rv = MISMATCH_WEAPONS_POSX;
				if (rv == 0 && p1->pos.y != p2->pos.y) rv = MISMATCH_WEAPONS_POSY;
				if (rv == 0 && p1->vel.x != p2->vel.x) rv = MISMATCH_WEAPONS_VELX;
				if (rv == 0 && p1->vel.y != p2->vel.y) rv = MISMATCH_WEAPONS_VELY;

				// increment
				++i2;
				++j2;
			}

		}

		return rv;
	}

	void serialize(vector <u8>* vec)
	{
		pushU8(vec,TYPE_AUDITABLE_STATE);
		pushU16(vec,shipIndex);
		pushU16(vec,freq);
		pushU8(vec,keys);
		pushU8(vec,processedServerSettings);

		pushU16(vec,violationTimeout);
		pushU16(vec,reloadingMilliseconds);
		pushU16(vec,packetTimeoutMilliseconds);

		pushU32(vec,hideMilliseconds);
		pushU32(vec,x);
		pushU32(vec,y);
		pushU32(vec,xvel);
		pushU32(vec,yvel);
		pushU32(vec,rot);
		pushU32(vec,serverTimeOffset);
		pushU32(vec,localMilliseconds);
		pushU16(vec,shipIterationOffset);

		pushU8(vec,shouldSendDeathPacket);
		pushU8(vec,sentDeathPacket);
		pushU16(vec,killerPid);

		pushU32(vec,energy);

		pushU32(vec, ships.size()); // push size of ships vector
		for (list <AuditableShip>::iterator i = ships.begin(); i != ships.end(); ++i)
			pushAuditableShip(this, vec, &(*i));

		pushU32(vec, weapons.size()); // push size of weapons vector

		for (list <Particle*>::iterator i = weapons.begin(); i != weapons.end(); ++i)
			pushParticle(vec, *i);
	}
};

// returns number of bytes processed, or negative if deserialize failed (negation of error code)
int deserializeAuditableState(AuditableState* store, u8* data, int len)
{
	const int minSize = 11*4 + 7*2 + 5;
	int curByte = 0;

	if (len < minSize)
		curByte = - PARSING_STATE_TOO_SHORT;
	else if (data[0] != TYPE_AUDITABLE_STATE)
		curByte = - PARSING_STATE_ID_BYTE_MISMATCH;
	else
	{
		curByte = 1;

		store->shipIndex = getU16(data + curByte);
		curByte += 2;

		store->freq = getU16(data + curByte);
		curByte += 2;

		store->keys = data[curByte++];
		store->processedServerSettings = data[curByte++];

		store->violationTimeout = getU16(data + curByte);
		curByte += 2;

		store->reloadingMilliseconds = getU16(data + curByte);
		curByte += 2;

		store->packetTimeoutMilliseconds = getU16(data + curByte);
		curByte += 2;

		store->hideMilliseconds = getU32(data + curByte);
		curByte += 4;

		store->x = getU32(data + curByte);
		curByte += 4;

		store->y = getU32(data + curByte);
		curByte += 4;

		store->xvel = getU32(data + curByte);
		curByte += 4;

		store->yvel = getU32(data + curByte);
		curByte += 4;

		store->rot = getU32(data + curByte);
		curByte += 4;

		store->serverTimeOffset = getU32(data + curByte);
		curByte += 4;

		store->localMilliseconds = getU32(data + curByte);
		curByte += 4;

		store->shipIterationOffset = getU16(data + curByte);
		curByte += 2;

		store->shouldSendDeathPacket = data[curByte++];
		store->sentDeathPacket = data[curByte++];

		store->killerPid = getU16(data + curByte);
		curByte += 2;

		store->energy = getU32(data + curByte);
		curByte += 4;

		int numShips = getU32(data + curByte);
		curByte += 4;

		for (int x = 0; x < numShips; ++x)
		{
			AuditableShip as;
			int processed = popAuditableShip(&as, data + curByte, len - curByte);

			if (processed <= 0) // error
			{
				curByte = processed;
				break;
			}

			curByte += processed;
			store->ships.push_back(as);
		}

		if (curByte > 0)
		{
			if (len - curByte < 4)
				curByte = - PARSING_STATE_TOO_SHORT_AFTER_SHIPS;
			else
			{
				int numParticles = getU32(data + curByte);
				curByte += 4;

				for (int x = 0; x < numParticles; ++x)
				{
					Particle* p = 0;
					int processed = popParticle(&p, data + curByte, len - curByte);

					if (processed <= 0) // error
					{
						curByte = processed;
						break;
					}

					curByte += processed;
					store->weapons.push_back(p);
				}
			}
		}
	}

	return curByte;
}

struct OtherPlayerDiedEvent;
void deserializeOtherPlayerDiedEvent(OtherPlayerDiedEvent* store, u8* buf);

struct OtherPlayerDiedEvent
{
	u8 type;
	u16 pid;

	OtherPlayerDiedEvent(u16 _pid) { type = TYPE_OTHER_PLAYER_DIED; pid = _pid; }
	OtherPlayerDiedEvent(u8* buf) { deserializeOtherPlayerDiedEvent(this, buf); }

	bool operator==(const OtherPlayerDiedEvent &rhs)
	{
		return type == rhs.type && pid == rhs.pid;
	}

	void serialize(u8 buf[32], u8* len)
	{
		buf[0] = type;
		putU16(buf+1, pid);
		*len = 3;
	}

	bool checkThenProcess(AuditableState* state) // check if a violation occurs with this event, iff not update state and return true
	{
		bool found = false;

		// find the ship of the player who fired this particle
		for (list <AuditableShip>::iterator i = state->ships.begin(); i != state->ships.end(); ++i)
		{
			AuditableShip* as = (AuditableShip*)(&(*i));

			if (as->pid == pid)
			{
				//
				found = true;
				as->physics.hideMilliseconds = gs->getIntGameSetting("Death Respawn Milliseconds", as->physics.shipName, getGameSettingsErrorMessage(__LINE__));
				as->physics.loc.x = as->physics.loc.y = 0;

				break;
			}
		}

		if (!found)
			LOG_ERROR("Received OtherPlayerDied event but can't find the AuditableShip");

		return true;
	}
};

void deserializeOtherPlayerDiedEvent(OtherPlayerDiedEvent* store, u8* buf)
{
	store->type = TYPE_OTHER_PLAYER_DIED;
	store->pid = getU16(buf + 1);
}

struct SelfDiedEvent;
void deserializeSelfDiedEvent(SelfDiedEvent* store, u8* buf);

struct SelfDiedEvent
{
	u8 type;
	u16 killerPid;

	SelfDiedEvent(u16 _killerPid) { type = TYPE_SELF_DIED; killerPid = _killerPid; }
	SelfDiedEvent(u8* buf) { deserializeSelfDiedEvent(this, buf); }

	bool operator==(const SelfDiedEvent &rhs)
	{
		return type == rhs.type && killerPid == rhs.killerPid;
	}

	void serialize(u8 buf[32], u8* len)
	{
		buf[0] = type;
		putU16(buf+1, killerPid);
		*len = 3;
	}

	bool checkThenProcess(AuditableState* state) // check if a violation occurs with this event, iff not update state and return true
	{
		if (state->shouldSendDeathPacket)
		{
			state->shouldSendDeathPacket = 0;

			if (state->killerPid != killerPid)
			{
				LOG_ERROR("Killer pid being sent is not the player's pid that acutally killed us");
				state->violationTimeout = violationMilliseconds;
			}
		}
		else
		{
			state->sentDeathPacket = 1;
			state->killerPid = killerPid;
		}

		return true;
	}
};

void deserializeSelfDiedEvent(SelfDiedEvent* store, u8 *buf)
{
	store->type = TYPE_SELF_DIED;
	store->killerPid = getU16(buf + 1);
}

struct OtherPlayerWeaponEvent;
void deserializeOtherPlayerWeaponEvent(OtherPlayerWeaponEvent* store, u8* buf);

struct OtherPlayerWeaponEvent
{
	u8 type;
	i32 xpos, ypos;
	i16 xvel, yvel;
	u16 pid;
	u8 rot;
	i16 sentServerTime;
	u16 wep;

	OtherPlayerWeaponEvent(i32 x, i32 y, i16 xVel, i16 yVel, u16 hisPid, u8 hisRot, i16 sentServerTimestamp, u16 weapon) { type = TYPE_OTHER_PLAYER_WEAPON;
		xpos = x; ypos = y; xvel = xVel; yvel = yVel; pid = hisPid; rot = hisRot; sentServerTime = sentServerTimestamp; wep = weapon; }
	OtherPlayerWeaponEvent(u8* buf) { deserializeOtherPlayerWeaponEvent(this, buf); }

	bool operator==(const OtherPlayerWeaponEvent &rhs)
	{
		return type == rhs.type && xpos == rhs.xpos && ypos == rhs.ypos &&
			xvel == rhs.xvel && yvel == rhs.yvel && pid == rhs.pid && rot == rhs.rot &&
			sentServerTime == rhs.sentServerTime && wep == rhs.wep;
	}

	void serialize(u8 buf[32], u8* len)
	{
		buf[0] = type;
		buf[1] = rot;
		putU16(buf+2, pid);
		putU16(buf+4, xvel);
		putU16(buf+6, yvel);
		putU16(buf+8, sentServerTime);
		putU32(buf+10, xpos);
		putU32(buf+14, ypos);
		putU16(buf+18, wep);
		*len = 20;
	}

	bool checkThenProcess(AuditableState* state) // check if a violation occurs with this event, iff not update state and return true
	{
		// create Particle
		i16 nowServer = (i16)((state->localMilliseconds/10 + state->serverTimeOffset) & 0x0FFFF);

		i16 centisecondsAgo = (sentServerTime - nowServer);
		i32 millisecondsAgo = 10 * centisecondsAgo;

		const char* particleName = ssi->mapWeaponToName(wep)->c_str();
		const char* shipName = 0;
		int freq = -1;

		// find the ship of the player who fired this particle
		for (list <AuditableShip>::iterator i = state->ships.begin(); i != state->ships.end(); ++i)
		{
			AuditableShip* as = (AuditableShip*)(&(*i));

			if (as->pid == pid)
			{
				shipName = as->physics.shipName;
				freq = as->freq;
				break;
			}
		}

		if (!shipName)
		{
			LOG_ERROR2("weapon fired but can't find player with associated pid=%i", pid);
		}
		else
		{
			Point pos(xpos, ypos);

			char buf[128];
			snprintf(buf, sizeof(buf), "%sSpeed", particleName);
			int speed = gs->getIntGameSetting(buf, shipName, getGameSettingsErrorMessage(__LINE__));

			if (strcmp(shipName, "spec") == 0)
			{
				LOG_ERROR("Shipname is spec!");
			}

			FixedPointNumber rad = sm->getRadians(sm->frameToRot(rot, shipName), shipName);

			Vector vel(0,0);
			util->getVector(rad, speed, &vel);

			vel.x += xvel;
			vel.y += yvel;

			Particle* p = par->newUnmanagedParticle2(particleName, &pos, &vel, millisecondsAgo);
			p->firedByPid = pid;
			p->freq = freq;
			p->collideWithPlayers = true;

			state->weapons.push_back(p);
		}

		return true;
	}
};

void deserializeOtherPlayerWeaponEvent(OtherPlayerWeaponEvent* store, u8* buf)
{
	store->type = TYPE_OTHER_PLAYER_WEAPON;
	store->rot = buf[1];
	store->pid = getU16(buf+2);
	store->xvel = getU16(buf+4);
	store->yvel = getU16(buf+6);
	store->sentServerTime = getU16(buf+8);
	store->xpos = getU32(buf+10);
	store->ypos = getU32(buf+14);
	store->wep = getU16(buf+18);
}

struct OtherPlayerPositionEvent;
void deserializeOtherPlayerPositionEvent(OtherPlayerPositionEvent* store, u8* buf);

struct OtherPlayerPositionEvent
{
	u8 type;
	i32 xpos, ypos;
	i16 xvel, yvel;
	u16 pid;
	i16 sentServerTime; // centiseconds, from packet
	u8 rot;

	OtherPlayerPositionEvent(i32 x, i32 y, i16 xVel, i16 yVel, u16 hisPid, i16 timePacket, u8 rotation)
		{ type = TYPE_OTHER_PLAYER_POSITION; xpos = x; ypos = y; xvel = xVel; yvel = yVel; pid = hisPid; sentServerTime = timePacket; rot = rotation; }
	OtherPlayerPositionEvent(u8* buf) { deserializeOtherPlayerPositionEvent(this, buf); }

	bool operator==(const OtherPlayerPositionEvent &rhs)
	{
		return type == rhs.type && xpos == rhs.xpos && ypos == rhs.ypos &&
			xvel == rhs.xvel && yvel == rhs.yvel && pid == rhs.pid && rot == rhs.rot &&
			sentServerTime == rhs.sentServerTime;
	}

	void serialize(u8 buf[32], u8* len)
	{
		buf[0] = type;
		putU16(buf+1, pid);
		putU16(buf+3, sentServerTime);
		putU16(buf+5, xvel);
		putU16(buf+7, yvel);
		putU32(buf+9, xpos);
		putU32(buf+13, ypos);
		buf[17] = rot;
		*len = 18;
	}

	bool checkThenProcess(AuditableState* state) // check if a violation occurs with this event, iff not update state and return true
	{
		bool found = false;

		for (list <AuditableShip>::iterator i = state->ships.begin(); i != state->ships.end(); ++i)
		{
			if (i->pid == pid)
			{
				if (i->physics.hideMilliseconds == -1) // if this is the first position packet
					i->physics.hideMilliseconds = 0; // show ship

				i16 nowServer = (i16)((state->localMilliseconds/10 + state->serverTimeOffset) & 0x0FFFF);

				i16 centisecondsAgo = (sentServerTime - nowServer);
				i32 millisecondsAgo = 10 * centisecondsAgo;

				char buf[256];
				snprintf(buf, sizeof(buf), "updateShipPrediction for pid=%i(ship name %s)\n", pid,
						i->physics.shipName);

				os->updateShipPrediction(&i->physics, xpos, ypos, xvel, yvel, rot, millisecondsAgo);

				found = true;
				break;
			}
		}

		if (!found)
		{
			LOG_ERROR2("got player position packet but pid doesn't exist (%i)", pid);
		}

		return true;
	}
};

void deserializeOtherPlayerPositionEvent(OtherPlayerPositionEvent* store, u8* buf)
{
	store->type = TYPE_OTHER_PLAYER_POSITION;
	store->pid = getU16(buf + 1);
	store->sentServerTime = getU16(buf + 3);
	store->xvel = getU16(buf + 5);
	store->yvel = getU16(buf + 7);
	store->xpos = getU16(buf + 9);
	store->ypos = getU16(buf + 13);
	store->rot = buf[17];
}

struct OtherPlayerShipChangeEvent;
void deserializeOtherPlayerShipChangeEvent(OtherPlayerShipChangeEvent* store, u8* buf);

struct OtherPlayerShipChangeEvent
{
	u8 type;
	u16 pid;
	u16 shipIndex;

	OtherPlayerShipChangeEvent(u16 hisPid, u16 hisShip) { type = TYPE_OTHER_PLAYER_CHANGE_SHIP; shipIndex = hisShip;
																						pid = hisPid; }
	OtherPlayerShipChangeEvent(u8* buf) { deserializeOtherPlayerShipChangeEvent(this, buf); }

	bool operator==(const OtherPlayerShipChangeEvent &rhs)
	{
		return type == rhs.type && pid == rhs.pid && shipIndex == rhs.shipIndex;
	}

	void serialize(u8 buf[32], u8* len)
	{
		buf[0] = type;
		putU16(buf+1, pid);
		putU16(buf+3, shipIndex);
		*len = 5;
	}

	bool checkThenProcess(AuditableState* state, bool logErrors) // check if a violation occurs with this event, iff not update state and return true
	{
		bool found = false;
		bool rv = true;

		for (list <AuditableShip>::iterator i = state->ships.begin(); i != state->ships.end(); ++i)
		{
			if (i->pid == pid)
			{
				if (state->processedServerSettings)
				{
					const char* shipType = ss->shipIndexToTemplateName(shipIndex);
					snprintf(i->physics.shipName, 63, "%s", shipType);
				}
				else
				{
					i->physics.shipName[0] = shipIndex & 0xFF;
					i->physics.shipName[1] = (shipIndex & 0xFF00) >> 8;
					i->physics.shipName[2] = 0;
				}

				i->lastPositionUpdate = state->serverTimeOffset + state->localMilliseconds / 10;
				i->physics.hideMilliseconds = -1; // hide until first position packet
				i->physics.loc.x = i->physics.loc.y = i->physics.vel.x = i->physics.vel.y = 0;
				i->physics.physicsIterationOffset = 0;
				i->physics.adjustMills = 0;
				i->physics.adjustVel.x = i->physics.adjustVel.y = 0;

				found = true;
				break;
			}
		}

		if (!found && logErrors)
		{
			LOG_ERROR2("player changed ship but pid doesn't exist (%i)", pid);
		}

		return rv;
	}
};

void deserializeOtherPlayerShipChangeEvent(OtherPlayerShipChangeEvent* store, u8* buf)
{
	store->type = TYPE_OTHER_PLAYER_CHANGE_SHIP;
	store->pid = getU16(buf + 1);
	store->shipIndex = getU16(buf + 3);
}

struct OtherPlayerFreqChangeEvent;
void deserializeOtherPlayerFreqChangeEvent(OtherPlayerFreqChangeEvent* store, u8* buf);

struct OtherPlayerFreqChangeEvent
{
	u8 type;
	u16 pid;
	u16 freq;

	OtherPlayerFreqChangeEvent(u16 hisPid, u16 hisFreq) { type = TYPE_OTHER_PLAYER_CHANGE_FREQ; freq = hisFreq; pid = hisPid; }
	OtherPlayerFreqChangeEvent(u8* buf) { deserializeOtherPlayerFreqChangeEvent(this, buf); }

	bool operator==(const OtherPlayerFreqChangeEvent &rhs)
	{
		return type == rhs.type && pid == rhs.pid && freq == rhs.freq;
	}

	void serialize(u8 buf[32], u8* len)
	{
		buf[0] = type;
		putU16(buf+1, pid);
		putU16(buf+3, freq);
		*len = 5;
	}

	bool checkThenProcess(AuditableState* state) // check if a violation occurs with this event, iff not update state and return true
	{
		bool found = false;

		for (list <AuditableShip>::iterator i = state->ships.begin(); i != state->ships.end(); ++i)
		{
			if (i->pid == pid)
			{
				i->freq = freq;
				// we might need to fill in more here like x and y if freq change is not accompanied by ship change

				found = true;
				break;
			}
		}

		if (!found)
		{
			LOG_ERROR2("player changed freq but pid doesn't exist (%i)", pid);
		}

		return true;
	}
};


void deserializeOtherPlayerFreqChangeEvent(OtherPlayerFreqChangeEvent* store, u8* buf)
{
	store->type = TYPE_OTHER_PLAYER_CHANGE_FREQ;
	store->pid = getU16(buf + 1);
	store->freq = getU16(buf + 3);
}

struct OtherPlayerLeavingEvent;
void deserializeOtherPlayerLeavingEvent(OtherPlayerLeavingEvent* store, u8* buf);

struct OtherPlayerLeavingEvent
{
	u8 type;
	u16 pid;

	OtherPlayerLeavingEvent(u16 hisPid) { type = TYPE_OTHER_PLAYER_LEAVING; pid = hisPid; }
	OtherPlayerLeavingEvent(u8* buf) { deserializeOtherPlayerLeavingEvent(this, buf); }

	bool operator==(const OtherPlayerLeavingEvent &rhs)
	{
		return type == rhs.type && pid == rhs.pid;
	}

	void serialize(u8 buf[32], u8* len)
	{
		buf[0] = type;
		putU16(buf+1, pid);
		*len = 3;
	}

	bool checkThenProcess(AuditableState* state) // check if a violation occurs with this event, iff not update state and return true
	{
		bool found = false;

		for (list <AuditableShip>::iterator i = state->ships.begin(); i != state->ships.end(); ++i)
		{
			if (i->pid == pid)
			{
				state->ships.erase(i);
				found = true;
				break;
			}
		}

		if (!found)
		{
			LOG_ERROR2("player left but pid doesn't exist (%i)", pid);
		}

		// erase all his particles
		for (list <Particle*>::iterator i = state->weapons.begin(); i != state->weapons.end(); )
		{
			list <Particle*>::iterator next = i;
			++next; // preiterate in case we delete

			if ((*i)->firedByPid == pid)
			{
				par->disposeUnmanagedParticle(*i);
				state->weapons.erase(i);
			}

			i = next;
		}

		return true;
	}
};

void deserializeOtherPlayerLeavingEvent(OtherPlayerLeavingEvent* store, u8* buf)
{
	store->type = TYPE_OTHER_PLAYER_LEAVING;
	store->pid = getU16(buf + 1);
}

struct OtherPlayerEnteringEvent;
void deserializeOtherPlayerEnteringEvent(OtherPlayerEnteringEvent* store, u8* buf);

struct OtherPlayerEnteringEvent
{
	u8 type;
	u16 pid;

	OtherPlayerEnteringEvent(u16 hisPid) { type = TYPE_OTHER_PLAYER_ENTERING; pid = hisPid; }
	OtherPlayerEnteringEvent(u8* buf) { deserializeOtherPlayerEnteringEvent(this, buf); }

	bool operator==(const OtherPlayerEnteringEvent &rhs)
	{
		return type == rhs.type && pid == rhs.pid;
	}

	void serialize(u8 buf[32], u8* len)
	{
		buf[0] = type;
		putU16(buf+1, pid);
		*len = 3;
	}

	bool checkThenProcess(AuditableState* state) // check if a violation occurs with this event, iff not update state and return true
	{
		bool found = false;

		for (list <AuditableShip>::iterator i = state->ships.begin(); i != state->ships.end(); ++i)
		{
			if (i->pid == pid)
			{
				LOG_ERROR2("player entered but pid already is used by another player (%i)", pid);
				found = true;
				break;
			}
		}

		if (!found)
		{
			AuditableShip as;

			as.pid = pid;
			as.lastPositionUpdate = (state->localMilliseconds / 10 + state->serverTimeOffset);
			as.physics.hideMilliseconds = -1;
			as.physics.physicsIterationOffset = 0;
			as.physics.adjustMills = 0;
			as.physics.adjustVel.x = as.physics.adjustVel.y = 0;

			// put in some default values so it's determinisitic, these should eventually get overridden
			as.freq = as.physics.loc.x = as.physics.loc.y = as.physics.rot = as.physics.vel.x = as.physics.vel.y = -1;
			as.physics.shipName[0] = 0;

			state->ships.push_back(as);
		}

		return true;
	}
};

void deserializeOtherPlayerEnteringEvent(OtherPlayerEnteringEvent* store, u8* buf)
{
	store->type = TYPE_OTHER_PLAYER_ENTERING;
	store->pid = getU16(buf + 1);
}

struct FreqChangeRequestEvent;
void deserializeFreqChangeRequestEvent(FreqChangeRequestEvent* store, u8* buf);

struct FreqChangeRequestEvent
{
	u8 type;
	u16 freq;

	FreqChangeRequestEvent(int theFreq) { type = TYPE_FREQ_CHANGE_REQUEST; freq = theFreq; }
	FreqChangeRequestEvent(u8* buf) { deserializeFreqChangeRequestEvent(this, buf); }

	bool operator==(const FreqChangeRequestEvent &rhs)
	{
		return type == rhs.type && freq == rhs.freq;
	}

	void serialize(u8 buf[32], u8* len)
	{
		buf[0] = type;
		putU16(buf+1, freq);
		*len = 3;
	}

	bool checkThenProcess(AuditableState* state, bool log) // check if a violation occurs with this event, iff not update state and return true
	{
		int specIndex = ss->getSpecShipIndex();
		bool rv = true;

		if (state->shipIndex != specIndex) // we are currently not in spec
		{
			int maxEnergy = gs->getIntGameSetting("Max Energy", ss->shipIndexToTemplateName(state->shipIndex), getGameSettingsErrorMessage(__LINE__)) * 10000;

			if (state->energy < maxEnergy && !(state->violationTimeout > 0)) // allow changes to spec if there was a violation
			{
				if (log)
				{
					char buf[128];
					snprintf(buf, sizeof(buf), "Freq change without full energy, cur (%i) < max (%i)", state->energy, maxEnergy);
					LOG_ERROR(buf);
				}

				rv = false;
			}
		}

		if (rv && state->freq == freq)
		{
			if (log)
				LOG_ERROR("Attempted Freq change request into current freq");

			rv = false;
		}

		return rv;
	}
};

void deserializeFreqChangeRequestEvent(FreqChangeRequestEvent* store, u8* buf)
{
	store->type = TYPE_SHIP_CHANGE_REQUEST;
	store->freq = getU16(buf + 1);
}

struct ShipChangeRequestEvent;
void deserializeShipChangeRequestEvent(ShipChangeRequestEvent* store, u8* buf);

struct ShipChangeRequestEvent
{
	u8 type;
	u16 shipIndex;

	ShipChangeRequestEvent(int ship) { type = TYPE_SHIP_CHANGE_REQUEST; shipIndex = ship; }
	ShipChangeRequestEvent(u8* buf) { deserializeShipChangeRequestEvent(this, buf); }

	bool operator==(const ShipChangeRequestEvent &rhs)
	{
		return type == rhs.type && shipIndex == rhs.shipIndex;
	}

	void serialize(u8 buf[32], u8* len)
	{
		buf[0] = type;
		putU16(buf+1, shipIndex);
		*len = 3;
	}

	bool checkThenProcess(AuditableState* state, bool log) // check if a violation occurs with this event, iff not update state and return true
	{
		int specIndex = ss->getSpecShipIndex();
		bool rv = true;

		if (state->shipIndex != specIndex) // we are currently not in spec
		{
			int maxEnergy = gs->getIntGameSetting("Max Energy", ss->shipIndexToTemplateName(state->shipIndex), getGameSettingsErrorMessage(__LINE__)) * 10000;

			if (state->energy < maxEnergy && !(state->violationTimeout > 0 && shipIndex == ss->getSpecShipIndex())) // allow changes to spec if there was a violation
			{
				if (log)
				{
					char buf[128];
					snprintf(buf, sizeof(buf), "Ship change without full energy, cur (%i) < max (%i)", state->energy, maxEnergy);
					LOG_ERROR(buf);
				}

				rv = false;
			}
		}

		if (rv && state->shipIndex == shipIndex)
		{
			if (log)
				LOG_ERROR("Attempted Ship change request into current ship");

			rv = false;
		}

		return rv;
	}
};

void deserializeShipChangeRequestEvent(ShipChangeRequestEvent* store, u8* buf)
{
	store->type = TYPE_SHIP_CHANGE_REQUEST;
	store->shipIndex = getU16(buf + 1);
}

struct ShipChangeEvent;
void deserializeShipChangeEvent(ShipChangeEvent* store, u8* buf);

struct ShipChangeEvent
{
	u8 type;
	u16 newShipIndex;

	ShipChangeEvent(u16 ship) { type = TYPE_SHIP_CHANGE; newShipIndex = ship; }
	ShipChangeEvent(u8* buf) { deserializeShipChangeEvent(this, buf); }

	bool operator==(const ShipChangeEvent &rhs)
	{
		return type == rhs.type && newShipIndex == rhs.newShipIndex;
	}

	void serialize(u8 buf[32], u8* len)
	{
		buf[0] = type;
		putU16(buf+1, newShipIndex);
		*len = 3;
	}

	bool checkThenProcess(AuditableState* state) // check if a violation occurs with this event, iff not update state and return true
	{
		int specIndex = ss->getSpecShipIndex();
		int intShipIndex = newShipIndex;

		if (intShipIndex != specIndex) // we're changing into nonspec ship
		{
			// apply spawn status modification
			status->modifyStatusNoAnim(defaultSpawn, &state->x, &state->y, &state->xvel, &state->yvel, NULL);
			state->rot = 0;

			int maxEnergy = gs->getIntGameSetting("Max Energy", ss->shipIndexToTemplateName(intShipIndex), getGameSettingsErrorMessage(__LINE__)) * 10000;
			state->energy = maxEnergy;
			state->hideMilliseconds = 0;
		}
		else // into spec
			state->hideMilliseconds = -1;

		state->shipIterationOffset = 0;
		state->packetTimeoutMilliseconds = maxBetweenPackets;
		state->shipIndex = intShipIndex;
		state->reloadingMilliseconds = 0;
		state->sentDeathPacket = state->shouldSendDeathPacket = 0;

		return true;
	}
};

void deserializeShipChangeEvent(ShipChangeEvent* store, u8* buf)
{
	store->type = TYPE_SHIP_CHANGE;
	store->newShipIndex = getU16(buf + 1);
}

struct FreqChangeEvent;
void deserializeFreqChangeEvent(FreqChangeEvent* store, u8* buf);

struct FreqChangeEvent
{
	u8 type;
	u16 freq;

	FreqChangeEvent(u16 newFreq) { type = TYPE_FREQ_CHANGE; freq = newFreq; }
	FreqChangeEvent(u8* buf) { deserializeFreqChangeEvent(this, buf); }

	bool operator==(const FreqChangeEvent &rhs)
	{
		return type == rhs.type && freq == rhs.freq;
	}

	void serialize(u8 buf[32], u8* len)
	{
		buf[0] = type;
		putU16(buf+1, freq);
		*len = 3;
	}

	bool checkThenProcess(AuditableState* state) // check if a violation occurs with this event, iff not update state and return true
	{
		state->freq = freq;

		if (state->shipIndex != ss->getSpecShipIndex())
		{ // do a respawn
			// apply spawn status modification
			status->modifyStatusNoAnim(defaultSpawn, &state->x, &state->y, &state->xvel, &state->yvel, NULL);
			state->rot = 0;

			int maxEnergy = gs->getIntGameSetting("Max Energy", ss->shipIndexToTemplateName(state->shipIndex), getGameSettingsErrorMessage(__LINE__)) * 10000;
			state->energy = maxEnergy;
			state->hideMilliseconds = 0;
		}

		state->shipIterationOffset = 0;
		state->packetTimeoutMilliseconds = maxBetweenPackets;
		state->reloadingMilliseconds = 0;
		state->sentDeathPacket = state->shouldSendDeathPacket = 0;

		return true;
	}
};

void deserializeFreqChangeEvent(FreqChangeEvent* store, u8* buf)
{
	store->type = TYPE_FREQ_CHANGE;
	store->freq = getU16(buf + 1);
}

struct KeyStateChangeEvent;
void deserializeKeyStateChangeEvent(KeyStateChangeEvent* store, u8* buf);

struct KeyStateChangeEvent
{
	u8 type;
	u8 keys[4];

	KeyStateChangeEvent(int newkeys[4]) { type = TYPE_NEW_KEY_STATE; keys[0] = newkeys[0]; keys[1] = newkeys[1]; keys[2] = newkeys[2]; keys[3] = newkeys[3]; }
	KeyStateChangeEvent(u8* buf) { deserializeKeyStateChangeEvent(this, buf); }

	bool operator==(const KeyStateChangeEvent &rhs)
	{
		return type == rhs.type && keys[0] == rhs.keys[0]
						&& keys[1] == rhs.keys[1]
						&& keys[2] == rhs.keys[2]
						&& keys[3] == rhs.keys[3];
	}

	void serialize(u8 buf[32], u8* len)
	{
		buf[0] = type;
		buf[1] = (u8)(keys[0] | keys[1] << 1 | keys[2] << 2 | keys[3] << 3);
		*len = 2;
	}

	bool checkThenProcess(AuditableState* state) // check if a violation occurs with this event, iff not update state and return true
	{
		state->keys = keys[0] | (keys[1] << 1) | (keys[2] << 2) | (keys[3] << 3);

		return true;
	}
};

void deserializeKeyStateChangeEvent(KeyStateChangeEvent* store, u8* buf)
{
	store->type = TYPE_NEW_KEY_STATE;
	store->keys[0] = (buf[1] & 0x01);
	store->keys[1] = (buf[1] & 0x02) >> 1;
	store->keys[2] = (buf[1] & 0x04) >> 2;
	store->keys[3] = (buf[1] & 0x08) >> 3;
}

struct TickEvent;
void deserializeTickEvent(TickEvent* store, u8* buf);

struct TickEvent
{
	u8 mills;
	u8 type;

	TickEvent(int mill) { type = TYPE_TICK; if (mill > 256) LOG_ERROR("Tickevent, mill > 256");   mills = (u8)mill; }
	TickEvent(u8* buf) { deserializeTickEvent(this, buf); }

	bool operator==(const TickEvent &rhs)
	{
		return type == rhs.type && mills == rhs.mills;
	}

	void serialize(u8 buf[32], u8* len)
	{
		buf[0] = type;
		buf[1] = mills;
		*len = 2;
	}

	bool checkThenProcess(AuditableState* state, bool logErrors) // check if a violation occurs with this event, iff not update state and return true
	{
		if (state->processedServerSettings)
		{
			// first conditionally respawn if necessary
			if (state->hideMilliseconds > mills)
				state->hideMilliseconds -= mills;
			else if (state->hideMilliseconds > 0)
			{
				// respawn
				state->hideMilliseconds = 0;

				status->modifyStatusNoAnim(defaultSpawn, &state->x, &state->y, &state->xvel, &state->yvel, NULL);
				state->rot = 0; // todo statusModification should set rot & energy!!

				int maxEnergy = gs->getIntGameSetting("Max Energy", ss->shipIndexToTemplateName(state->shipIndex), getGameSettingsErrorMessage(__LINE__)) * 10000;
				state->energy = maxEnergy;
			}

			if (state->shipIndex != ss->getSpecShipIndex())
			{
				// update self position

				if (state->hideMilliseconds == 0)
				{
					int accel = gs->getIntGameSetting("Acceleration", ss->shipIndexToTemplateName(state->shipIndex), getGameSettingsErrorMessage(__LINE__));
					int maxRotVel = gs->getIntGameSetting("RotationalVelocity", ss->shipIndexToTemplateName(state->shipIndex), getGameSettingsErrorMessage(__LINE__));
					int maxVel = gs->getIntGameSetting("MaxPositionalVelocity", ss->shipIndexToTemplateName(state->shipIndex), getGameSettingsErrorMessage(__LINE__));

					int curRotVel = 0;
					int keys[4] = {(state->keys & 0x01), (state->keys >> 1 & 0x01),
									(state->keys >> 2 & 0x01), (state->keys >> 3 & 0x01)};

					// update velocity based on keys
					ss->setVelocity(mills, accel, maxRotVel, maxVel, state->shipIndex, state->x, state->y, state->rot,
							&state->xvel, &state->yvel, &curRotVel, keys);

					state->rot += curRotVel * mills;

					while (state->rot < 0)
						state->rot += FULL_ROTATION;

					while (state->rot >= FULL_ROTATION)
						state->rot -= FULL_ROTATION;
				}

				ShipPhysicsData curData;
				strncpy(curData.shipName, ss->shipIndexToTemplateName(state->shipIndex), sizeof(curData.shipName));
				curData.hideMilliseconds = state->hideMilliseconds;
				curData.rot = state->rot;
				curData.loc.x = state->x;
				curData.loc.y = state->y;
				curData.vel.x = state->xvel;
				curData.vel.y = state->yvel;
				curData.physicsIterationOffset = state->shipIterationOffset;
				curData.adjustMills = 0;
				curData.adjustVel.x = 0;
				curData.adjustVel.y = 0;

				sm->advanceShip(&curData, mills, true, false);

				// copy back
				state->rot = curData.rot;
				state->x = curData.loc.x;
				state->y = curData.loc.y;
				state->xvel = curData.vel.x;
				state->yvel = curData.vel.y;
				state->shipIterationOffset = curData.physicsIterationOffset;


				/////////////// update energy /////////////////
				int maxEnergy = gs->getIntGameSetting("Max Energy", ss->shipIndexToTemplateName(state->shipIndex), getGameSettingsErrorMessage(__LINE__)) * 10000;
				int recharge = gs->getIntGameSetting("Recharge Energy Per Ten Seconds", ss->shipIndexToTemplateName(state->shipIndex), getGameSettingsErrorMessage(__LINE__));

				state->energy += recharge * mills;

				if (state->energy > maxEnergy)
					state->energy = maxEnergy;
			}

			/////////////// update other player positions ////////
			for (list <AuditableShip>::iterator i = state->ships.begin(); i != state->ships.end(); ++i)
			{
				AuditableShip* as = (AuditableShip*)(&(*i));

				if (ss->templateNameToShipIndex(as->physics.shipName) != ss->getSpecShipIndex() )
				{
					sm->advanceShip(&as->physics, mills, false, false);

					if (as->physics.hideMilliseconds > mills)
						as->physics.hideMilliseconds -= mills;
					else if (as->physics.hideMilliseconds > 0)
						as->physics.hideMilliseconds = 0 ;
				}
			}

			/////////////// update weapons //////////////////
			for (list <Particle*>::iterator i = state->weapons.begin(); i != state->weapons.end(); ) // increment done inside loop
			{
				Particle* p = *i;
				BOOL exploded = FALSE, expired = FALSE;

				par->advanceParticle(p, mills, particleHitAShip, (void*)state, &exploded, &expired);

				if (exploded || expired)
				{ // remove particle
					list <Particle*>::iterator next = i;
					++next;

					par->disposeUnmanagedParticle(p);

					state->weapons.erase(i);
					i = next;
				}
				else
					++i;
			}

			if (mills > maxIteration)
			{
				char buf[128];
				snprintf(buf, sizeof(buf), "Main Loop Iteration Time (%i) Exceeds Maximum Allowed (%i)", mills, maxIteration);

				if (logErrors)
					LOG_ERROR(buf);

				state->violationTimeout = violationMilliseconds;
			}
		}

		// update time
		state->localMilliseconds += mills;

		// update violationTimeout
		if (state->violationTimeout > mills)
			state->violationTimeout -= mills;
		else
			state->violationTimeout = 0;

		// update reloadingMilliseconds
		if (state->reloadingMilliseconds > mills)
			state->reloadingMilliseconds -= mills;
		else
			state->reloadingMilliseconds = 0;

		// update packetTimeoutMilliseconds
		if (state->packetTimeoutMilliseconds > mills)
			state->packetTimeoutMilliseconds -= mills;
		else
			state->packetTimeoutMilliseconds = 0;

		return true;
	}
};

void deserializeTickEvent(TickEvent* store, u8* buf)
{
	store->type = TYPE_TICK;
	store->mills = buf[1];
}

struct SendPositionEvent;
void deserializeSendPositionEvent(SendPositionEvent* store, u8* buf);

struct SendPositionEvent
{
	u8 type;
	i16 x, y, xvel, yvel, wep;
	u8 dir;
	u32 time;

	SendPositionEvent(u16 _x, u16 _y, u16 _xvel, u16 _yvel, u16 _wep, u8 _dir, u32 _time)
		{ type = TYPE_SENT_POSITION_PACKET; x = _x; y = _y; xvel = _xvel, yvel = _yvel; wep = _wep; dir = _dir; time = _time;
		}
	SendPositionEvent(u8* buf) { deserializeSendPositionEvent(this, buf); }

	bool operator==(const SendPositionEvent &rhs)
	{
		return type == rhs.type && x == rhs.x && y == rhs.y && xvel == rhs.xvel && yvel == rhs.yvel && wep == rhs.wep &&
			dir == rhs.dir && time == rhs.time;
	}

	void serialize(u8 buf[32], u8* len)
	{
		buf[0] = type;
		buf[1] = dir;

		putU16(buf + 2,x);
		putU16(buf + 4,y);
		putU16(buf + 6,xvel);
		putU16(buf + 8,yvel);
		putU16(buf + 10,wep);
		putU32(buf + 12,time);

		*len = 16;
	}

	// check if a violation occurs with this event, if not updates state and returns true, also sets negation of error code
	bool checkThenProcess(AuditableState* state, bool logErrors, int* errorCode)
	{
		// check if position sent is same as position in state
		bool rv = true;

		if (state->shipIndex != ss->getSpecShipIndex()) // no violations if you're in spec mode
		{
			u32 packetTime = time;
			u32 calcTime = ((state->localMilliseconds/10 + state->serverTimeOffset));

			// location is incorrect
			if (x != state->x/10000 || y != state->y/10000 || xvel != state->xvel || yvel != state->yvel ||
					dir != sm->rotToFrame(state->rot, ss->shipIndexToTemplateName(state->shipIndex))
					|| packetTime != calcTime)
			{
				if (logErrors)
				{
					LOG_ERROR3("Player Position Was Not Correctly Calculated; "
							"packetTime = %i; calctime = %i", packetTime, calcTime);
				}

				*errorCode = -INCORRECT_POSITION_UPDATE;

				rv = false;
			}

			// initial state is set and we're not in spec, violation
			if (!state->processedServerSettings)
			{
				if (logErrors)
					LOG_ERROR("We haven't processed server settings but we're in a ship!");

				*errorCode = -DIDNT_PROCESS_SETTINGS_BUT_IN_A_SHIP;

				rv = false;
			}

			if (state->violationTimeout > 0)
			{
				if (logErrors)
					LOG_ERROR2("Violation Timeout > 0 (%i)", state->violationTimeout);

				*errorCode = -VIOLATION_TIMEOUT_POSITIVE_BUT_NOT_IN_SPEC;

				rv = false;
			}

			// check state->packetTimeoutMilliseconds
			if (state->packetTimeoutMilliseconds == 0)
			{
				if (logErrors)
					LOG_ERROR("Too long between position packets!");

				*errorCode = -TOO_LONG_BETWEEN_POSITION_PACKETS;
				rv = false;
			}
			else if (rv)
				state->packetTimeoutMilliseconds = maxBetweenPackets;

			// check reloadingMilliseconds

			if (rv && (wep & 0x1f) != 0) // weapon type is not "none"
			{
				// check reloading time
				if (state->reloadingMilliseconds > 0)
				{
					if (logErrors)
						LOG_ERROR2("Weapon Rate Too Fast (reloadingMilliseconds nonzero = %i)", state->reloadingMilliseconds);

					*errorCode = -WEAPON_RATE_TOO_FAST;

					rv = false;
				}
				else
				{
					const char* wepName = ssi->mapWeaponToName(wep)->c_str();
					const char* shipName = ss->shipIndexToTemplateName(state->shipIndex);
					char buf[64];

					snprintf(buf,sizeof(buf), "%sReloadMilliseconds", wepName);

					// assign new reloadTime
					state->reloadingMilliseconds = gs->getIntGameSetting(buf, shipName, getGameSettingsErrorMessage(__LINE__));

					// now check energy
					snprintf(buf, sizeof(buf), "%s Fire Energy", wepName);
					int energyNeeded = 10000 * gs->getIntGameSetting(buf, shipName, getGameSettingsErrorMessage(__LINE__));

					if (state->energy < energyNeeded)
					{
						if (logErrors)
						{
							char buf[128];
							snprintf(buf, sizeof(buf), "Weapon(%s) Fired but not enough energy(%i), energy needed=%i", wepName,
									state->energy / 10000, energyNeeded/10000);
							LOG_ERROR(buf);
						}

						*errorCode = -NOT_ENOUGH_ENERGY_TO_FIRE_WEAPON;

						rv = false;
					}
					else
					{
						state->energy -= energyNeeded;

						// add it to weapons
						Point loc(state->x / 10000, state->y / 10000);
						snprintf(buf, sizeof(buf), "%sSpeed", wepName);
						int speed = gs->getIntGameSetting(buf, shipName, getGameSettingsErrorMessage(__LINE__));

						FixedPointNumber rad = sm->getRadians(sm->frameToRot(dir, shipName), shipName);

						Vector vel(0,0);
						util->getVector(rad, speed, &vel);


						vel.x += xvel;
						vel.y += yvel;

						Particle* p = par->newUnmanagedParticle(wepName, &loc, &vel);
						p->firedByPid = SELF_PSEUDOPID;
						p->freq = state->freq;

						state->weapons.push_back(p);
					}
				}
			}

			// if we're supposed to send a death packet
			if (state->sentDeathPacket)
			{
				if (logErrors)
					LOG_ERROR("Sent death packet when we didn't actually die!");

				*errorCode = -SENT_DEATH_PACKET_WITHOUT_DYING;

				rv = false;
			}
			else if (state->shouldSendDeathPacket)
			{
				if (logErrors)
					LOG_ERROR("Player died but didn't send a death packet!");

				*errorCode = -DIED_WITHOUT_SENDING_DEATH_PACKET;

				rv = false;
			}
		}

		if (rv == false)
		{ // violation occurred
			state->violationTimeout = violationMilliseconds;
		}

		return rv;
	}
};

void deserializeSendPositionEvent(SendPositionEvent* store, u8* buf)
{
	store->type = TYPE_SENT_POSITION_PACKET;
	store->dir = buf[1];
	store->x = getU16(buf + 2);
	store->y = getU16(buf + 4);
	store->xvel = getU16(buf + 6);
	store->yvel = getU16(buf + 8);
	store->wep = getU16(buf + 10);
	store->time = getU32(buf + 12);
}

struct SyncEvent;
void deserializeSyncEvent(SyncEvent* store, u8* buf);

struct SyncEvent
{
	u8 type;
	u32 sentTime;
	u32 receivedTime;
	u32 serverTime;
	i32 serverTimeOffset;

	SyncEvent(u32 sent, u32 receieved, u32 serverTimestamp, u32 serverOffset)
		{ type = TYPE_TIMER_SYNC; sentTime = sent; receivedTime = receieved; serverTime = serverTimestamp; serverTimeOffset = serverOffset; }
	SyncEvent(u8* buf) { deserializeSyncEvent(this, buf); }

	bool operator==(const SyncEvent &rhs)
	{
		return type == rhs.type && sentTime == rhs.sentTime && receivedTime == rhs.receivedTime && serverTime == rhs.serverTime
				&& serverTimeOffset == rhs.serverTimeOffset;
	}

	void serialize(u8 buf[32], u8* len)
	{
		buf[0] = type;
		putU32(buf + 1,sentTime);
		putU32(buf + 5,receivedTime);
		putU32(buf + 9,serverTime);
		putU32(buf + 13,serverTimeOffset);

		*len = 17;
	}

	bool checkThenProcess(AuditableState* state, bool logErrors) // check if a violation occurs with this event, iff not update state and return true
	{
		if (state->processedServerSettings && state->shipIndex != ss->getSpecShipIndex())
		{
			int maxDrift = sh->getServerSettingAsInt2("Security", "MaxTimerDriftMilliseconds",750);
			int dif = state->serverTimeOffset - serverTimeOffset;
			dif = dif >= 0 ? dif : -dif; // abs

			if (dif > maxDrift)
			{
				if (logErrors)
				{
					char buf[256];

					snprintf(buf,sizeof(buf), "Maximum Allowed Timer Drift Exceeded, state->serverTimeOffset = %i, serverTimeOffset = %i; dif(%i) > max(%i)",
							state->serverTimeOffset, serverTimeOffset, dif, maxDrift);

					LOG_ERROR(buf);
				}

				// the violation won't occur until we send a positon packet
				state->violationTimeout = violationMilliseconds; // the violation doesn't occur until we send a position packet
			}
		}

		//printf("resync to '%i', drift = '%i'\n", serverTimeOffset, dif);

		state->serverTimeOffset = serverTimeOffset;

		return true;
	}
};

void deserializeSyncEvent(SyncEvent* store, u8* buf)
{
	store->type = TYPE_TIMER_SYNC;
	store->sentTime = getU32(buf + 1);
	store->receivedTime = getU32(buf + 5);
	store->serverTime = getU32(buf + 9);
	store->serverTimeOffset = getU32(buf + 13);
}

struct GotServerSettingsEvent;
void deserializeGotServerSettingsEvent(GotServerSettingsEvent* store, u8* buf);

struct GotServerSettingsEvent
{
	u8 type;

	GotServerSettingsEvent() { type = TYPE_GOT_SERVER_SETTINGS; }
	GotServerSettingsEvent(u8* buf) { deserializeGotServerSettingsEvent(this, buf); }

	bool operator==(const GotServerSettingsEvent &rhs)
	{
		return true;
	}

	void serialize(u8 buf[32], u8* len)
	{
		buf[0] = type;
		*len = 1;
	}

	bool checkThenProcess(AuditableState* state, bool logErrors) // check if a violation occurs with this event, iff not update state and return true
	{
		if (logErrors && state->processedServerSettings)
			LOG_ERROR("Got Server Settings twice?"); // not really an error but I want to know if it happens

		state->processedServerSettings = true;

		// update all ships to the correct index
		for (list <AuditableShip>::iterator i = state->ships.begin(); i != state->ships.end(); ++i)
		{
			u16 shipIndex = (u16)(((u32)i->physics.shipName[1] << 8) & (u32)i->physics.shipName[0]);

			const char* shipType = ss->shipIndexToTemplateName(shipIndex);
			snprintf(i->physics.shipName, 63, "%s", shipType);
		}

		return true;
	}
};

void deserializeGotServerSettingsEvent(GotServerSettingsEvent* store, u8* buf)
{
	store->type = TYPE_GOT_SERVER_SETTINGS;
}

// memory manamgenet is done manually
struct AuditableEvent
{
	u8 type;
	void* data;

	AuditableEvent(u8 eventType)
	{
		type = eventType;
		data = 0;
	}

	~AuditableEvent()
	{
		static bool errored = false;

		if (data && !errored)
		{
			errored = true;

			LOG_ERROR2("Incomplete cleanup, data is not null, type = '%s'", auditableEventName[type]);
			LOG_ERROR("Suppressing further such warnings; this error may happen when Discretion unexpectedly quits (but is unlikely the cause of the issue).");
		}
	}
};


// data
AuditableState beginningState; // start state
list <AuditableEvent> eventList;
AuditableState currentState; // checked & updated continuously

int millisecondsInStream = 0;
bool drawingAuditData = false;

// functions
void deleteEventData(u8 type, void* data)
{
	switch (type)
	{
		case TYPE_SHIP_CHANGE:
		{
			delete (ShipChangeEvent*)data;
		} break;

		case TYPE_NEW_KEY_STATE:
		{
			delete (KeyStateChangeEvent*)data;
		} break;

		case TYPE_TICK:
		{
			delete (TickEvent*)data;
		} break;

		case TYPE_SENT_POSITION_PACKET:
		{
			delete (SendPositionEvent*)data;

		} break;

		case TYPE_TIMER_SYNC:
		{
			delete (SyncEvent*)data;

		} break;

		case TYPE_SHIP_CHANGE_REQUEST:
		{
			delete (ShipChangeRequestEvent*)data;

		} break;

		case TYPE_FREQ_CHANGE_REQUEST:
		{
			delete (FreqChangeRequestEvent*)data;
		} break;

		case TYPE_OTHER_PLAYER_ENTERING:
		{
			delete (OtherPlayerEnteringEvent*)data;

		} break;

		case TYPE_OTHER_PLAYER_LEAVING:
		{
			delete (OtherPlayerLeavingEvent*)data;
		} break;

		case TYPE_OTHER_PLAYER_CHANGE_SHIP:
		{
			delete (OtherPlayerShipChangeEvent*)data;
		} break;

		case TYPE_OTHER_PLAYER_CHANGE_FREQ:
		{
			delete (OtherPlayerFreqChangeEvent*)data;
		} break;

		case TYPE_OTHER_PLAYER_POSITION:
		{
			delete (OtherPlayerPositionEvent*)data;
		} break;

		case TYPE_OTHER_PLAYER_WEAPON:
		{
			delete (OtherPlayerWeaponEvent*)data;
		} break;

		case TYPE_FREQ_CHANGE:
		{
			delete (FreqChangeEvent*)data;
		} break;

		case TYPE_SELF_DIED:
		{
			delete (SelfDiedEvent*)data;
		} break;

		case TYPE_OTHER_PLAYER_DIED:
		{
			delete (OtherPlayerDiedEvent*)data;
		} break;

		case TYPE_GOT_SERVER_SETTINGS:
		{
			delete (GotServerSettingsEvent*)data;

		} break;
		default:
		{
			LOG_ERROR2("type %i not found, couldn't free memory", type);
		} break;
	}
}

void emptyEventList()
{
	while (eventList.size() > 0)
	{
		AuditableEvent* ae = &(*eventList.begin());

		deleteEventData(ae->type, ae->data);
		ae->data = 0;

		eventList.pop_front();
	}
}

void pushU8(vector <u8>* vec, u8 data)
{
	vec->push_back(data);
}

void pushU16(vector <u8>* vec, u16 data)
{
	u8 buf[2];

	putU16(buf,data);
	vec->push_back(buf[0]);
	vec->push_back(buf[1]);
}

void pushU32(vector <u8>* vec, u32 data)
{
	u8 buf[4];

	putU32(buf,data);
	vec->push_back(buf[0]);
	vec->push_back(buf[1]);
	vec->push_back(buf[2]);
	vec->push_back(buf[3]);
}

u8 popU8(vector <u8>* vec)
{
	u8 rv = *vec->rbegin();
	vec->pop_back();

	return rv;
}

u16 popU16(vector <u8>* vec)
{
	u8 buf[2];
	buf[1] = *vec->rbegin();
	vec->pop_back();
	buf[0] = *vec->rbegin();
	vec->pop_back();

	return getU16(buf);
}

u32 popU32(vector <u8>* vec)
{
	u8 buf[4];

	buf[3] = *vec->rbegin();
	vec->pop_back();
	buf[2] = *vec->rbegin();
	vec->pop_back();
	buf[1] = *vec->rbegin();
	vec->pop_back();
	buf[0] = *vec->rbegin();
	vec->pop_back();

	return getU32(buf);
}

void pushAuditableShip(AuditableState* state, vector <u8>* vec, AuditableShip* as)
{
	// shipIndex gets special handling depending on whether the settings are loaded or not
	u16 shipIndex;

	if (state->processedServerSettings)
		shipIndex = ss->templateNameToShipIndex(as->physics.shipName);
	else
	{
		shipIndex = (u16)((u32)(as->physics.shipName[1] << 8) & ((u32)as->physics.shipName[0]));
	}

	pushU8(vec, shipIndex);
	pushU16(vec, as->physics.hideMilliseconds);
	pushU32(vec, as->physics.rot);
	pushU32(vec, as->physics.loc.x);
	pushU32(vec, as->physics.loc.y);
	pushU32(vec, as->physics.vel.x);
	pushU32(vec, as->physics.vel.y);
	pushU16(vec, as->pid);
	pushU16(vec, as->lastPositionUpdate);
	pushU16(vec, as->freq);
	pushU16(vec, as->physics.physicsIterationOffset);
	pushU16(vec, as->physics.adjustMills);
	pushU32(vec, as->physics.adjustVel.x);
	pushU32(vec, as->physics.adjustVel.y);
}

const char* getGameSettingsErrorMessage(int line)
{
	static string msg;
	char buf[128];

	snprintf(buf, sizeof(buf), "File %s, line %i", __FILE__, line);
	msg = buf;

	return msg.c_str();
}

// return 0 on error, similar to the selfShip function
const char* failableShipIndexToTemplateName(unsigned int shipIndex)
{
	static vector <string> shipTypes;

	if (shipTypes.size() == 0)
	{
		list <string> types;
		const string* s = sh->getServerSettingAsString("Ships", "Types");

		stringToList(&types,s);

		if (!IS_VALID_LIST_SETTING(types))
			LOG_ERROR("ships::types undefined");
		else
		{
			int cur = 0;

			for (list<string>::iterator i = types.begin(); i != types.end(); ++i)
			{
				if (cur++ == ss->getSpecShipIndex())
					shipTypes.push_back("spec");

				shipTypes.push_back(*i);
			}
		}
	}

	const char* rv = 0;

	if (shipIndex <= shipTypes.size())
		rv = shipTypes[shipIndex].c_str();

	return rv;
}

// returns number of bytes processed, negative if error (negation of error code)
int popAuditableShip(AuditableShip* storeHere, u8* data, int len)
{
	const int actualLength = 41;
	int rv = actualLength;

	if (len < actualLength)
		rv = -PARSING_STATE_LENGTH_TOO_SHORT_TO_BE_AUDITABLE_SHIP_LENGTH;
	else
	{
		u8 shipIndex = data[0];
		storeHere->physics.hideMilliseconds = getU16(data + 1);
		storeHere->physics.rot = getU32(data + 3);
		storeHere->physics.loc.x = getU32(data + 7);
		storeHere->physics.loc.y = getU32(data + 11);
		storeHere->physics.vel.x = getU32(data + 15);
		storeHere->physics.vel.y = getU32(data + 19);
		storeHere->pid = getU16(data + 23);
		storeHere->lastPositionUpdate = getU16(data + 25);
		storeHere->freq = getU16(data + 27);
		storeHere->physics.physicsIterationOffset = getU16(data + 29);
		storeHere->physics.adjustMills = getU16(data + 31);
		storeHere->physics.adjustVel.x = getU32(data + 33);
		storeHere->physics.adjustVel.y = getU32(data + 37);

		const char* ship = failableShipIndexToTemplateName(shipIndex);

		if (ship)
			snprintf(storeHere->physics.shipName, sizeof(storeHere->physics.shipName), "%s", ship);
		else
			rv = -PARSING_STATE_AUDITABLE_SHIP_INDEX_INVALID;
	}

	return rv;
}

void pushParticle(vector <u8>* vec, Particle* p)
{
	int len = strlen(p->name);
	for (int i = 0; i <= len; ++i)
		vec->push_back((u8)p->name[i]);

	pushU32(vec, p->pos.x);

	pushU32(vec, p->pos.y);
	pushU32(vec, p->vel.x);
	pushU32(vec, p->vel.y);
	pushU32(vec, p->freq);

	u8 collides = 0;
	if (p->collideWithPlayers)
		collides = 1;

	pushU8(vec, collides);

	pushU32(vec, p->bouncesRemaining);
	pushU32(vec, p->millExisted);
	pushU32(vec, p->millisecondsLeftAlive);
	pushU32(vec, p->firedByPid);
	pushU16(vec, p->physicsIterationOffset);

}

// the Particle* is allocated with Particles->newUnmanagedParticle, remember to Particles->disposeUnmanagedParticle
// returns the number of bytes , or negative if error (negation of error code), particle is not allocated on errors
int popParticle(Particle** store, u8* data, int len)
{
	const int baseLength = 9 * 4 + 3;
	int curByte = 0;

	// extract the name
	string particleName;

	while (true)
	{
		if (curByte > len)
		{
			curByte = -PARSING_STATE_PARTICLE_LENGTH_TOO_SHORT;
			break;
		}

		u8 letter = data[curByte++];

		if (letter == 0)
			break;

		particleName += letter;
	}

	if (curByte > 0)
	{
		if (curByte + baseLength > len)
			curByte = -PARSING_STATE_PARTICLE_LENGTH_TOO_SHORT2;
		else
		{
			Vector vel;
			Point pos;

			pos.x = getU32(data + curByte);
			curByte += 4;

			pos.y = getU32(data + curByte);
			curByte += 4;

			vel.x = getU32(data + curByte);
			curByte += 4;

			vel.y = getU32(data + curByte);
			curByte += 4;

			u32 freq = getU32(data + curByte);
			curByte += 4;

			bool collideWithPlayers = data[curByte++] != 0;

			u32 bouncesRemaining = getU32(data + curByte);
			curByte += 4;

			u32 millExisted = getU32(data + curByte);
			curByte += 4;

			u32 millisecondsLeftAlive = getU32(data + curByte);
			curByte += 4;

			u32 firedByPid = getU32(data + curByte);
			curByte += 4;

			u16 iterationOffset = getU16(data + curByte);
			curByte += 2;

			Particle* p = par->newUnmanagedParticle(particleName.c_str(), &pos, &vel);
			*store = p;
			p->firedByPid = firedByPid;
			p->millisecondsLeftAlive = millisecondsLeftAlive;
			p->millExisted = millExisted;
			p->bouncesRemaining = bouncesRemaining;
			p->collideWithPlayers = collideWithPlayers;
			p->freq = freq;
			p->physicsIterationOffset = iterationOffset;

			// overwrite position because there's no interface for exact position, only pixels
			p->pos.x = pos.x;
			p->pos.y = pos.y;
			p->vel.x = vel.x;
			p->vel.y = vel.y;

		}
	}

	return curByte;
}

void checkEventSerialization(u8 type, void* data)
{
	u8 buf[AUDITABLE_EVENT_MAXSIZE + 4];
	memset(buf, 0x7a, sizeof(buf));

	u8 len = 0;
	static bool printed = false;

	if (!printed)
	{
		printed = true;
		LOG_ERROR("checkEventSerialization was called; this should only be the case while testing/debugging");
	}

	switch (type)
	{
		case TYPE_SHIP_CHANGE: // player changed his ship
		{
			((ShipChangeEvent*)data)->serialize(buf + 2, &len);

			if (!(ShipChangeEvent(buf+ 2) == *((ShipChangeEvent*)data)))
				LOG_ERROR2("Serialize then deserialize is bugged for event of type %s", auditableEventName[type]);
		}
		break;
		case TYPE_NEW_KEY_STATE: // player pressed / released some keys
			((KeyStateChangeEvent*)data)->serialize(buf + 2, &len);

			if (!(KeyStateChangeEvent(buf + 2) == *((KeyStateChangeEvent*)data)))
				LOG_ERROR2("Serialize then deserialize is bugged for event of type %s", auditableEventName[type]);
		break;
		case TYPE_TICK: // advance time
			((TickEvent*)data)->serialize(buf + 2, &len);

			if (!(TickEvent(buf + 2) == *((TickEvent*)data)))
				LOG_ERROR2("Serialize then deserialize is bugged for event of type %s", auditableEventName[type]);
			break;
		case TYPE_SENT_POSITION_PACKET: // position packet sent
			((SendPositionEvent*)data)->serialize(buf + 2, &len);

			if (!(SendPositionEvent(buf + 2) == *((SendPositionEvent*)data)))
				LOG_ERROR2("Serialize then deserialize is bugged for event of type %s", auditableEventName[type]);
			break;
		case TYPE_TIMER_SYNC: // server <-> client timer synchronization
			((SyncEvent*)data)->serialize(buf + 2, &len);

			if (!(SyncEvent(buf + 2) == *((SyncEvent*)data)))
				LOG_ERROR2("Serialize then deserialize is bugged for event of type %s", auditableEventName[type]);
			break;
		case TYPE_SHIP_CHANGE_REQUEST: // player requested ship change
			((ShipChangeRequestEvent*)data)->serialize(buf + 2, &len);

			if (!(ShipChangeRequestEvent(buf + 2) == *((ShipChangeRequestEvent*)data)))
				LOG_ERROR2("Serialize then deserialize is bugged for event of type %s", auditableEventName[type]);
			break;
		case TYPE_FREQ_CHANGE_REQUEST: // player requested ship change
			((FreqChangeRequestEvent*)data)->serialize(buf + 2, &len);

			if (!(FreqChangeRequestEvent(buf + 2) == *((FreqChangeRequestEvent*)data)))
				LOG_ERROR2("Serialize then deserialize is bugged for event of type %s", auditableEventName[type]);
			break;
		case TYPE_OTHER_PLAYER_ENTERING:
			((OtherPlayerEnteringEvent*)data)->serialize(buf + 2, &len);

			if (!(OtherPlayerEnteringEvent(buf + 2) == *((OtherPlayerEnteringEvent*)data)))
				LOG_ERROR2("Serialize then deserialize is bugged for event of type %s", auditableEventName[type]);
			break;
		case TYPE_OTHER_PLAYER_LEAVING:
			((OtherPlayerLeavingEvent*)data)->serialize(buf + 2, &len);

			if (!(OtherPlayerLeavingEvent(buf + 2) == *((OtherPlayerLeavingEvent*)data)))
				LOG_ERROR2("Serialize then deserialize is bugged for event of type %s", auditableEventName[type]);
			break;
		case TYPE_OTHER_PLAYER_CHANGE_SHIP:
			((OtherPlayerShipChangeEvent*)data)->serialize(buf + 2, &len);

			if (!(OtherPlayerShipChangeEvent(buf + 2) == *((OtherPlayerShipChangeEvent*)data)))
				LOG_ERROR2("Serialize then deserialize is bugged for event of type %s", auditableEventName[type]);
			break;
		case TYPE_OTHER_PLAYER_CHANGE_FREQ:
			((OtherPlayerFreqChangeEvent*)data)->serialize(buf + 2, &len);

			if (!(OtherPlayerFreqChangeEvent(buf + 2) == *((OtherPlayerFreqChangeEvent*)data)))
				LOG_ERROR2("Serialize then deserialize is bugged for event of type %s", auditableEventName[type]);
			break;
		case TYPE_OTHER_PLAYER_POSITION:
			((OtherPlayerPositionEvent*)data)->serialize(buf + 2, &len);

			if (!(OtherPlayerPositionEvent(buf + 2) == *((OtherPlayerPositionEvent*)data)))
				LOG_ERROR2("Serialize then deserialize is bugged for event of type %s", auditableEventName[type]);
			break;
		case TYPE_OTHER_PLAYER_WEAPON:
			((OtherPlayerWeaponEvent*)data)->serialize(buf + 2, &len);

			if (!(OtherPlayerWeaponEvent(buf + 2) == *((OtherPlayerWeaponEvent*)data)))
				LOG_ERROR2("Serialize then deserialize is bugged for event of type %s", auditableEventName[type]);
			break;
		case TYPE_FREQ_CHANGE:
			((FreqChangeEvent*)data)->serialize(buf + 2, &len);

			if (!(FreqChangeEvent(buf + 2) == *((FreqChangeEvent*)data)))
				LOG_ERROR2("Serialize then deserialize is bugged for event of type %s", auditableEventName[type]);
			break;
		case TYPE_SELF_DIED:
			((SelfDiedEvent*)data)->serialize(buf + 2, &len);

			if (!(SelfDiedEvent(buf + 2) == *((SelfDiedEvent*)data)))
				LOG_ERROR2("Serialize then deserialize is bugged for event of type %s", auditableEventName[type]);
			break;
		case TYPE_OTHER_PLAYER_DIED:
			((OtherPlayerDiedEvent*)data)->serialize(buf + 2, &len);

			if (!(OtherPlayerDiedEvent(buf + 2) == *((OtherPlayerDiedEvent*)data)))
				LOG_ERROR2("Serialize then deserialize is bugged for event of type %s", auditableEventName[type]);
			break;
		case TYPE_GOT_SERVER_SETTINGS:
			((GotServerSettingsEvent*)data)->serialize(buf + 2, &len);

			if (!(GotServerSettingsEvent(buf + 2) == *((GotServerSettingsEvent*)data)))
				LOG_ERROR2("Serialize then deserialize is bugged for event of type %s", auditableEventName[type]);
			break;
		default:
			LOG_ERROR2("type not found in checkAuditableEvent: %i", type);
			LOG_ERROR2("eventName that wasn't found was name = '%s'", auditableEventName[type]);
			break;
	}

	if (buf[0] != 0x7a || buf[1] != 0x7a || buf[2+len] != 0x7a || buf[2+len + 1] != 0x7a)
	{
		LOG_ERROR2("serialize deserialize writes past buffer for type = '%s'", auditableEventName[type]);
	}

	if (len != auditableEventSize[type])
	{
		LOG_ERROR2("len != auditableEventSize[eventNum] for type = '%s'", auditableEventName[type]);
	}
}

void pushAuditableEvent(vector<u8>* vec, u8 type, void* data)
{
	u8 buf[AUDITABLE_EVENT_MAXSIZE];
	u8 len = 0;

	switch (type)
	{
		case TYPE_SHIP_CHANGE: // player changed his ship
			((ShipChangeEvent*)data)->serialize(buf, &len);
		break;
		case TYPE_NEW_KEY_STATE: // player pressed / released some keys
			((KeyStateChangeEvent*)data)->serialize(buf, &len);
		break;
		case TYPE_TICK: // advance time
			((TickEvent*)data)->serialize(buf, &len);
			break;
		case TYPE_SENT_POSITION_PACKET: // position packet sent
			((SendPositionEvent*)data)->serialize(buf, &len);
			break;
		case TYPE_TIMER_SYNC: // server <-> client timer synchronization
			((SyncEvent*)data)->serialize(buf, &len);
			break;
		case TYPE_SHIP_CHANGE_REQUEST: // player requested ship change
			((ShipChangeRequestEvent*)data)->serialize(buf, &len);
			break;
		case TYPE_FREQ_CHANGE_REQUEST: // player requested ship change
			((FreqChangeRequestEvent*)data)->serialize(buf, &len);
			break;
		case TYPE_OTHER_PLAYER_ENTERING:
			((OtherPlayerEnteringEvent*)data)->serialize(buf, &len);
			break;
		case TYPE_OTHER_PLAYER_LEAVING:
			((OtherPlayerLeavingEvent*)data)->serialize(buf, &len);
			break;
		case TYPE_OTHER_PLAYER_CHANGE_SHIP:
			((OtherPlayerShipChangeEvent*)data)->serialize(buf, &len);
			break;
		case TYPE_OTHER_PLAYER_CHANGE_FREQ:
			((OtherPlayerFreqChangeEvent*)data)->serialize(buf, &len);
			break;
		case TYPE_OTHER_PLAYER_POSITION:
			((OtherPlayerPositionEvent*)data)->serialize(buf, &len);
			break;
		case TYPE_OTHER_PLAYER_WEAPON:
			((OtherPlayerWeaponEvent*)data)->serialize(buf, &len);
			break;
		case TYPE_FREQ_CHANGE:
			((FreqChangeEvent*)data)->serialize(buf, &len);
			break;
		case TYPE_SELF_DIED:
			((SelfDiedEvent*)data)->serialize(buf, &len);
			break;
		case TYPE_OTHER_PLAYER_DIED:
			((OtherPlayerDiedEvent*)data)->serialize(buf, &len);
			break;
		case TYPE_GOT_SERVER_SETTINGS:
			((GotServerSettingsEvent*)data)->serialize(buf, &len);
			break;
		default:
			LOG_ERROR2("type not found in pushAuditableEvent: %i", type);
			break;
	}

	if (len > sizeof(buf))
		LOG_ERROR2("outgoing memory overflow: len(%i) > sizeof(buf)", len);

	if (len != auditableEventSize[type])
		LOG_ERROR2("size of serialized data is not equal to auditableEventSize[type] for event = '%s'", auditableEventName[type]);

	for (int x = 0; x < len; ++x)
		vec->push_back(buf[x]);
}

void updateStream(int mils)
{
	if (!disconnected && millisecondsInStream + mils > maxMillisecondsInStream)
	{
		// dump events and state
		vector <u8> data;

		// push start state
		beginningState.serialize(&data);

		// push each event
		for (list <AuditableEvent>::iterator i = eventList.begin(); i != eventList.end(); ++i)
		{
			// debug check if serializing then deserializing results in same event
			// checkEventSerialization(i->type, i->data);

			pushAuditableEvent(&data, i->type, i->data);
		}

		// push final state
		currentState.serialize(&data);

		u8* dataCopy = (u8*)util->amalloc(data.size(), I_AUDIT);

		for (int x = 0; x < (int)data.size(); ++x)
			dataCopy[x] = data[x];

		int decompressedSize = data.size();
		int compressedSize = (decompressedSize+(((decompressedSize)/1000)+1)+12);
		u8* compresssedData = (u8*)util->amalloc(compressedSize, I_AUDIT);

		util->zlibCompress(dataCopy, decompressedSize, compresssedData, &compressedSize);

		//printf(": About to net->sendAuditStream; decompressed = %i(%08x), compressed = %i(%08x)\n",
		//		decompressedSize, decompressedSize, compressedSize, compressedSize);

		mm->addTraceMessage(">> Started net->sendAuditStream");
		u8 header = COMMAND_CHECK_AUDIT_STREAM;

		net->sendAuditStream(&header, 1); // COMMAND_CHECK_AUDIT_STREAM for check

		u8 buf[4];
		putU32(buf, compressedSize);
		net->sendAuditStream(buf,4);

		putU32(buf, decompressedSize);
		net->sendAuditStream(buf,4);

		net->sendAuditStream(compresssedData, compressedSize);
		mm->addTraceMessage("<< Finished net->sendAuditStream");

		util->afree((void**)&compresssedData, compressedSize, I_AUDIT);
		util->afree((void**)&dataCopy, data.size(), I_AUDIT);

		// reset data
		millisecondsInStream = 0;

		beginningState = currentState;

		emptyEventList();

		mm->addTraceMessage("<- Finished creating and sending Audit Stream");
	}

	millisecondsInStream += mils;
}

BOOL particleHitAShip(Particle* particle, void* param)
{
	AuditableState* currentlyCheckedState = (AuditableState*)param;
	BOOL hit = 0;

	// check self player first
	if (currentlyCheckedState->hideMilliseconds == 0) // ship is visible
	{
		Point loc(currentlyCheckedState->x / 10000, currentlyCheckedState->y / 10000);

		const char* shipName = ss->shipIndexToTemplateName(currentlyCheckedState->shipIndex);
		int radius = gs->getIntGameSetting("radius", shipName, getGameSettingsErrorMessage(__LINE__));

		par->checkParticlePlayerCollision(particle, &loc, radius, currentlyCheckedState->freq, &hit);

		if (hit)
		{
			if (level->getTileType(currentlyCheckedState->x / (16 * 10000), currentlyCheckedState->y / (16 * 10000)) != TILE_SAFE)
			{ // if we're not in a safe zone
				char buf[128];
				snprintf(buf, sizeof(buf), "%s Damage Energy", particle->name);

				int damageEnergy = gs->getIntGameSetting(buf, shipName, getGameSettingsErrorMessage(__LINE__)) * 10000;

				if (currentlyCheckedState->energy < damageEnergy)
				{
					if (currentlyCheckedState->sentDeathPacket == 1)
					{
						currentlyCheckedState->sentDeathPacket = 0; // okay we just sent a death packet

						if (currentlyCheckedState->killerPid != particle->firedByPid)
						{
							LOG_ERROR("Killer pid sent is not the player's pid that acutally killed us");
							currentlyCheckedState->violationTimeout = violationMilliseconds;
						}
					}
					else
					{
						currentlyCheckedState->shouldSendDeathPacket = 1;
						currentlyCheckedState->killerPid = particle->firedByPid;
					}

					// do this here instead of on self_death event we won't ignore the ship until we've calculated it's died
					int time = gs->getSelfIntGameSetting("Death Respawn Milliseconds", getGameSettingsErrorMessage(__LINE__));
					currentlyCheckedState->hideMilliseconds = time;
				}
				else
				{
					currentlyCheckedState->energy -= damageEnergy;
				}
			}
		}
	}

	// then check other players if it didn't hit us
	if (!hit)
	{
		for (list <AuditableShip>::iterator i = currentlyCheckedState->ships.begin(); i != currentlyCheckedState->ships.end(); ++i)
		{
			AuditableShip* as = (AuditableShip*)(&(*i));

			if (as->physics.hideMilliseconds == 0)
			{
				Point loc(as->physics.loc.x / 10000, as->physics.loc.y / 10000);

				const char* shipName = as->physics.shipName;
				int radius = gs->getIntGameSetting("radius", shipName, getGameSettingsErrorMessage(__LINE__));

				par->checkParticlePlayerCollision(particle, &loc, radius, as->freq, &hit);

				if (hit)
					break;
			}
		}
	}

	return hit;
}

void init()
{
	if (net->isOffline())
		au.resetAuditStream();

	// sanity check
	if (sizeof(AuditErrorCodeName) != (NUM_EVENT_ERROR_CODES + 1) * 4)
	{
		LOG_ERROR3("Size mismatch between sizeof(AuditErrorCodeName)=%i and (NUM_EVENT_ERROR_CODES+1)*4=%i", sizeof(AuditErrorCodeName), (NUM_EVENT_ERROR_CODES+1) * 4);
	}
}

void deinit()
{
	emptyEventList();

	status->freeStatusModification(defaultSpawn);
}

void printMemoryUsage(void* p)
{
	char buf[128];

	snprintf(buf, sizeof(buf), __FILE__ ", eventList.size() = %i", eventList.size());
	chat->chatMessage(buf,"green");
}

void serverSettingsLoaded(void* p)
{
	defaultSpawn = status->getStatusModification("Default Ship Settings", "SpawnStatus");
	violationMilliseconds = sh->getServerSettingAsInt2("Security","ViolationSpecMilliseconds", 65000);
	maxIteration = sh->getServerSettingAsInt2("Security", "MaxMainLoopIterationMilliseconds", 50);
	mapForcesIterationTime = sh->getServerSettingAsInt2("Physics", "Apply Map Forces Iteration Milliseconds", 15);

	maxBetweenPackets = maxIteration + sh->getServerSettingAsInt2("Net", "SendPositionDelay", 100);
	maxMillisecondsInStream = sh->getServerSettingAsInt2("Security", "Max Milliseconds Per Audit", 5000);

	AuditableEvent ae(TYPE_GOT_SERVER_SETTINGS);

	ae.data = new GotServerSettingsEvent();

	GotServerSettingsEvent* se = (GotServerSettingsEvent*)ae.data;
	se->checkThenProcess(&currentState, true);

	eventList.push_back(ae);
	ae.data = 0; // this is okay since data state is maintained in event list
}

void selfViolation(const char* type)
{
	LOG_ERROR2("Security violation of type '%s'; disconnecting.",type);
	LOG_ERROR("This is probably a bug, but if you were to continue playing other players may think you were cheating.");

	// we may want to change this to disconnect later, since speccing without full energy is not allowed
	emptyEventList();
	net->disconnect();
	disconnected = true;

	if (net->isOffline())
	{
		LOG_ERROR("Exiting because we're in an offline server");
		mm->fatalError();
	}
}

// callbacks

void sendingPositionPacket(void* param)
{
	SendingPositionPacketParam* spp = (SendingPositionPacketParam*)param;
	const PacketInstance* pi = spp->pi;

	AuditableEvent ae(TYPE_SENT_POSITION_PACKET);

	ae.data = new SendPositionEvent(pi->getValue("xpos"), pi->getValue("ypos"),
			pi->getValue("xvel"), pi->getValue("yvel"), pi->getValue("weapon info"),
				pi->getValue("direction"), pi->getValue("timestamp"));

	SendPositionEvent* spe = (SendPositionEvent*)ae.data;
	int errorCode = 0;

	if (!disconnected && !spe->checkThenProcess(&currentState, true, &errorCode))
	{
		LOG_ERROR("Dumping violation");

		const char* dumpFileName = findNextValidDumpFilename();

		FILE* f = fopen(dumpFileName, "wb");

		if (f)
		{
			// construct audit data
			// dump events and state
			vector <u8> data;

			// push start state
			beginningState.serialize(&data);

			// add current event (since it's a violation)
			eventList.push_back(ae);

			// push each event
			for (list <AuditableEvent>::iterator i = eventList.begin(); i != eventList.end(); ++i)
			{
				// debug check if serializing then deserializing results in same event
				// checkEventSerialization(i->type, i->data);

				pushAuditableEvent(&data, i->type, i->data);
			}

			// push final state (this will be a violation since we didn't update it, but we can tell where it is)
			currentState.serialize(&data);

			fwrite(&(data[0]), (int)data.size(), 1, f);
			fclose(f);

			char buf[128];
			snprintf(buf, sizeof(buf), "Dumped Violation to '%s'", dumpFileName);

			flash->flashMessage(buf);
			printf("%s", buf); // debug
		}
		else
			LOG_ERROR2("fopen failed on dumpFileName='%s'", dumpFileName);

		// CHECK violations
		LOG_ERROR("checking dumped file");
		checkDumpFile(dumpFileName);

		////////////////////////////////////////

		char buf[128];
		snprintf(buf, sizeof(buf), "sendingPositionPacket: %s", AuditErrorCodeName[-errorCode]);
		selfViolation(buf);
	}

	if (disconnected)
		*(spp->abort) = 1;

	eventList.push_back(ae);
	ae.data = 0; // this is okay since data state is maintained in event list
}

void updatedTimerSync(void* param)
{
	UpdatedSyncParam* usp = (UpdatedSyncParam*)param;

	if (!initialized)
	{
		if (initialSync)
			LOG_ERROR("Multiple Initial Syncs before audit stream was initialized");
		else
		{
			util->updateMilliseconds(0);
			initialSync = true;
			initialSyncParam = *usp;
		}
	}
	else
	{
		AuditableEvent ae(TYPE_TIMER_SYNC);

		ae.data = new SyncEvent(usp->localSentCentiseconds, usp->localReceivedCentiseconds,
				usp->serverCentiseconds, usp->newServerTimeOffsetCentiseconds);

		SyncEvent* se = (SyncEvent*)ae.data;

		se->checkThenProcess(&currentState, true);

		eventList.push_back(ae);
		ae.data = 0; // this is okay since data state is maintained in event list
	}
}

void updateShips(void* param)
{
	int mils = *(int*)param;

	if (!initialized && initialSync)
	{
		initialTicks.push_back(mils);
	}
	else if (initialized)
	{
		// first update stream in case we dump it
		updateStream(mils);

		// tick events are ignored until server settings are loaded
		int cur[4] = { 0, 0, 0, 0};

		ss->getArrowKeyState(&cur[0], &cur[1], &cur[2], &cur[3]);

		if ((cur[0] != (currentState.keys & 0x01)) || (cur[1] != ((currentState.keys >> 1) & 0x01))
				|| (cur[2] != ((currentState.keys >> 2) & 0x01)) || (cur[3] != ((currentState.keys >> 3) & 0x01)))
		{
			AuditableEvent ae(TYPE_NEW_KEY_STATE);

			ae.data = new KeyStateChangeEvent(cur);

			KeyStateChangeEvent* ksce = (KeyStateChangeEvent*)ae.data;

			ksce->checkThenProcess(&currentState);
			eventList.push_back(ae);
			ae.data = 0; // this is okay since data state is maintained in event list
		}

		////////////////////// now do tick event //////////////////////////

		AuditableEvent ae(TYPE_TICK);

		ae.data = new TickEvent(mils);

		TickEvent* te = (TickEvent*)ae.data;

		te->checkThenProcess(&currentState, true);

		eventList.push_back(ae);
		ae.data = 0; // this is okay since data state is maintained in event list
	}
}

void selfFreqChangeRequest(void* param)
{
	SelfFreqChangeParam* sfcp = (SelfFreqChangeParam*)param;

	AuditableEvent ae(TYPE_FREQ_CHANGE_REQUEST);
	ae.data = new FreqChangeRequestEvent(sfcp->newFreq);

	FreqChangeRequestEvent* fcre = (FreqChangeRequestEvent*)ae.data;

	if (!fcre->checkThenProcess(&currentState,true))
	{
		LOG_ERROR("FreqChangeRequestEvent->checkThenProcess failed, dropping request");

		deleteEventData(ae.type, ae.data);
		ae.data = 0;
	}
	else
	{
		eventList.push_back(ae);
		ae.data = 0; // this is okay since data state is maintained in event list
	}
}

void selfShipChangeRequest(void* param)
{
	SelfShipChangeParam* sscp = (SelfShipChangeParam*)param;
	int shipIndex = ss->templateNameToShipIndex(sscp->newShip->c_str());

	AuditableEvent ae(TYPE_SHIP_CHANGE_REQUEST);
	ae.data = new ShipChangeRequestEvent(shipIndex);

	ShipChangeRequestEvent* scre = (ShipChangeRequestEvent*)ae.data;

	if (!scre->checkThenProcess(&currentState,true))
	{
		LOG_ERROR("ShipChangeRequestEvent->checkThenProcess failed, dropping request");

		deleteEventData(ae.type, ae.data);
		ae.data = 0;
	}
	else
	{
		eventList.push_back(ae);
		ae.data = 0; // this is okay since data state is maintained in event list
	}
}


void selfShipChange(void* param)
{
	SelfShipChangeOccuredParam* ssp = ((SelfShipChangeOccuredParam*)param);
	const char* newShip = ssp->shipName;
	int shipIndex = ss->templateNameToShipIndex(newShip);

	AuditableEvent ae(TYPE_SHIP_CHANGE);

	ae.data = new ShipChangeEvent(shipIndex);

	ShipChangeEvent* sce = (ShipChangeEvent*)ae.data;

	sce->checkThenProcess(&currentState);

	eventList.push_back(ae);
	ae.data = 0; // this is okay since data state is maintained in event list
}

void playerEntering(void* param)
{
	int pid = *((int*)param);

	if (pid != pm->getSelfPID())
	{
		AuditableEvent ae(TYPE_OTHER_PLAYER_ENTERING);
		ae.data = new OtherPlayerEnteringEvent(pid);

		OtherPlayerEnteringEvent* opee = (OtherPlayerEnteringEvent*)ae.data;
		opee->checkThenProcess(&currentState);

		eventList.push_back(ae);
		ae.data = 0; // this is okay since data state is maintained in event list
	}
}

void playerLeaving(void* param)
{
	int pid = *((int*)param);

	if (pid != pm->getSelfPID())
	{
		AuditableEvent ae(TYPE_OTHER_PLAYER_LEAVING);
		ae.data = new OtherPlayerLeavingEvent(pid);

		OtherPlayerLeavingEvent* ople = (OtherPlayerLeavingEvent*)ae.data;
		ople->checkThenProcess(&currentState);

		eventList.push_back(ae);
		ae.data = 0; // this is okay since data state is maintained in event list
	}
}

void playerChangeFreq(void* param)
{
	FreqChangeParam* fcp = (FreqChangeParam*)param;
	int pid = fcp->pid;
	int freq = fcp->freq;

	if (pid != pm->getSelfPID())
	{
		AuditableEvent ae(TYPE_OTHER_PLAYER_CHANGE_FREQ);
		ae.data = new OtherPlayerFreqChangeEvent(pid, freq);

		OtherPlayerFreqChangeEvent* e = (OtherPlayerFreqChangeEvent*)ae.data;
		e->checkThenProcess(&currentState);

		eventList.push_back(ae);
		ae.data = 0; // this is okay since data state is maintained in event list
	}
	else // self freq change
	{
		AuditableEvent ae(TYPE_FREQ_CHANGE);
		ae.data = new FreqChangeEvent(freq);

		FreqChangeEvent* e = (FreqChangeEvent*)ae.data;

		e->checkThenProcess(&currentState);

		eventList.push_back(ae);
		ae.data = 0; // this is okay since data state is maintained in event list
	}
}

void playerChangeShip(void* param)
{
	ShipChangeParam* scp = (ShipChangeParam*)param;
	int pid = scp->pid;
	int ship = scp->ship;

	if (pid != pm->getSelfPID())
	{
		AuditableEvent ae(TYPE_OTHER_PLAYER_CHANGE_SHIP);
		ae.data = new OtherPlayerShipChangeEvent(pid, ship);

		OtherPlayerShipChangeEvent* e = (OtherPlayerShipChangeEvent*)ae.data;

		e->checkThenProcess(&currentState, true);

		eventList.push_back(ae);
		ae.data = 0; // this is okay since data state is maintained in event list
	}
}

void receivedPositionPacket(void* param)
{
	ReceivedPositionPacketParam* rppp = (ReceivedPositionPacketParam*)param;

	AuditableEvent ae(TYPE_OTHER_PLAYER_POSITION);
	ae.data = new OtherPlayerPositionEvent(rppp->pos.x, rppp->pos.y, rppp->vel.x, rppp->vel.y, rppp->pid, rppp->timestamp, rppp->rotFrame);

	OtherPlayerPositionEvent* e = (OtherPlayerPositionEvent*)ae.data;
	e->checkThenProcess(&currentState);

	eventList.push_back(ae);
	ae.data = 0; // this is okay since data state is maintained in event list
}

void receivedWeapon(void* param)
{
	ReceivedWeaponPacketParam* rwpp = (ReceivedWeaponPacketParam*)param;

	AuditableEvent ae(TYPE_OTHER_PLAYER_WEAPON);

	ae.data = new OtherPlayerWeaponEvent(rwpp->pos.x, rwpp->pos.y, rwpp->vel.x, rwpp->vel.y, rwpp->pid, rwpp->rotFrame, rwpp->timestamp, rwpp->wep);

	OtherPlayerWeaponEvent* e = (OtherPlayerWeaponEvent*)ae.data;
	e->checkThenProcess(&currentState);

	eventList.push_back(ae);
	ae.data = 0; // this is okay since data state is maintained in event list
}

void internalCommand(void* param)
{
	InternalCommandParam* icp = (InternalCommandParam*)param;

	const char* params = 0;

	if (icp->isCommand("drawauditdata", 0))
	{
		drawingAuditData = !drawingAuditData;

		if (drawingAuditData)
			chat->chatMessage("Drawing Audit Data. Use ?drawauditdata to disable.", "green");
		else
			chat->chatMessage("Stopped Drawing Audit Data. Use ?drawauditdata to reenable.", "green");
	}
	else if (icp->isCommand("replaydump", &params))
	{
		checkDumpFile(params);
	}
}

void preRender(void* param)
{
	if (drawingAuditData)
	{
		int weaponHandle = ui->getLocalImageHandle("audit weapon");
		int shipHandle = ui->getLocalImageHandle("audit ship");

		for (list<AuditableShip>::iterator i = currentState.ships.begin(); i != currentState.ships.end(); ++i)
		{
			AuditableShip* s = (AuditableShip*)(&(*i));

			if (s->physics.hideMilliseconds == 0)
				g->drawImage2(shipHandle, s->physics.loc.x / 10000 - 16, s->physics.loc.y / 10000 - 16, L_TopMost);
		}

		if (currentState.shipIndex != ss->getSpecShipIndex() && currentState.hideMilliseconds == 0)
			g->drawImage2(shipHandle, currentState.x / 10000 - 16, currentState.y / 10000 - 16, L_TopMost);


		// now particles
		for (list<Particle*>::iterator i = currentState.weapons.begin(); i != currentState.weapons.end(); ++i)
		{
			Particle* p = *i;

			g->drawImage2(weaponHandle, p->pos.x / 10000 - 2, p->pos.y / 10000 - 2, L_TopMost);
		}
	}
}

void selfDeath(void* param)
{
	SelfDeathParam* sdp = (SelfDeathParam*)param;

	AuditableEvent ae(TYPE_SELF_DIED);

	ae.data = new SelfDiedEvent(sdp->killerPid);

	SelfDiedEvent* e = (SelfDiedEvent*)ae.data;
	e->checkThenProcess(&currentState);

	eventList.push_back(ae);
	ae.data = 0; // this is okay since data state is maintained in event list
}

void otherPlayerDied(void* param)
{
	// OtherPlayerDiedEvent pid

	OtherPlayerDiedParam* o = (OtherPlayerDiedParam*)param;

	AuditableEvent ae(TYPE_OTHER_PLAYER_DIED);

	ae.data = new OtherPlayerDiedEvent(o->pid);

	OtherPlayerDiedEvent* e = (OtherPlayerDiedEvent*)ae.data;
	e->checkThenProcess(&currentState);

	eventList.push_back(ae);
	ae.data = 0; // this is okay since data state is maintained in event list
}

// return value is # bytes processed, or negation of error code
int pumpAllEvents(AuditableState* state, u8* data, int len)
{
	int rv = 0;

	while (true) // we'll break when appropriate
	{
		if (len <= 0)
		{
			rv = -NO_FINAL_STATE_AFTER_EVENTS;
			break;
		}

		u8 type = data[rv];

		if (type == TYPE_AUDITABLE_STATE)
			break;
		else if (type > TYPE_AUDITABLE_STATE)
		{
			rv = -UNKNOWN_EVENT_TYPE;
			break;
		}

		if (len < auditableEventSize[type])
		{
			rv = -REMAINING_DATA_LENGTH_LESS_THAN_NECESSARY_FOR_EVENT;
			break;
		}

		//dumpBytes(data + rv, auditableEventSize[type]);

		switch (type)
		{
			case TYPE_SHIP_CHANGE:
			{
				ShipChangeEvent sce(data + rv);

				if (!sce.checkThenProcess(state))
					rv = -PUMP_EVENT_FAILED_SHIP_CHANGE;

			} break;

			case TYPE_NEW_KEY_STATE:
			{
				KeyStateChangeEvent ksce(data + rv);

				if (!ksce.checkThenProcess(state))
					rv = -PUMP_EVENT_FAILED_KEY_STATE_CHANGE;
			} break;

			case TYPE_TICK:
			{
				TickEvent te(data + rv);

				if (!te.checkThenProcess(state, false))
					rv = -PUMP_EVENT_FAILED_TICK_EVENT;
			} break;

			case TYPE_SENT_POSITION_PACKET:
			{
				SendPositionEvent e(data + rv);

				e.checkThenProcess(state, false, &rv); // fail is allowed if they set violation timeout

			} break;

			case TYPE_TIMER_SYNC:
			{
				SyncEvent e(data + rv);

				if (!e.checkThenProcess(state,false))
					rv = -PUMP_EVENT_FAILED_TIMER_SYNC;

			} break;

			case TYPE_SHIP_CHANGE_REQUEST:
			{
				ShipChangeRequestEvent e(data + rv);

				if (!e.checkThenProcess(state,false))
					rv = -PUMP_EVENT_FAILED_SHIP_CHANGE_REQUEST;

			} break;

			case TYPE_FREQ_CHANGE_REQUEST:
			{
				FreqChangeRequestEvent e(data + rv);

				if (!e.checkThenProcess(state,false))
					rv = -PUMP_EVENT_FAILED_FREQ_CHANGE_REQUEST;

			} break;

			case TYPE_OTHER_PLAYER_ENTERING:
			{
				OtherPlayerEnteringEvent e(data + rv);

				if (!e.checkThenProcess(state))
					rv = -PUMP_EVENT_FAILED_OTHER_PLAYER_ENTERING;

			} break;

			case TYPE_OTHER_PLAYER_LEAVING:
			{
				OtherPlayerLeavingEvent e(data + rv);

				if (!e.checkThenProcess(state))
					rv = -PUMP_EVENT_FAILED_OTHER_PLAYER_LEAVING;
			} break;

			case TYPE_OTHER_PLAYER_CHANGE_SHIP:
			{
				OtherPlayerShipChangeEvent e(data + rv);

				if (!e.checkThenProcess(state, false))
					rv = -PUMP_EVENT_FAILED_OTHER_PLAYER_SHIP_CHANGE;
			} break;

			case TYPE_OTHER_PLAYER_CHANGE_FREQ:
			{
				OtherPlayerFreqChangeEvent e(data + rv);

				if (!e.checkThenProcess(state))
					rv = -PUMP_EVENT_FAILED_OTHER_PLAYER_FREQ_CHANGE;
			} break;

			case TYPE_OTHER_PLAYER_POSITION:
			{
				OtherPlayerPositionEvent e(data + rv);

				if (!e.checkThenProcess(state))
					rv = -PUMP_EVENT_FAILED_OTHER_PLAYER_POSITION;
			} break;

			case TYPE_OTHER_PLAYER_WEAPON:
			{
				OtherPlayerWeaponEvent e(data + rv);

				if (!e.checkThenProcess(state))
					rv = -PUMP_EVENT_FAILED_OTHER_PLAYER_WEAPON;
			} break;

			case TYPE_FREQ_CHANGE:
			{
				FreqChangeEvent e(data + rv);

				if (!e.checkThenProcess(state))
					rv = -PUMP_EVENT_FAILED_FREQ_CHANGE;
			} break;

			case TYPE_SELF_DIED:
			{
				SelfDiedEvent e(data + rv);

				if (!e.checkThenProcess(state))
					rv = -PUMP_EVENT_FAILED_SELF_DIED;
			} break;

			case TYPE_OTHER_PLAYER_DIED:
			{
				OtherPlayerDiedEvent e(data + rv);

				if (!e.checkThenProcess(state))
					rv = -PUMP_EVENT_FAILED_OTHER_PLAYER_DIED;
			} break;

			case TYPE_GOT_SERVER_SETTINGS:
			{
				GotServerSettingsEvent e(data + rv);

				// this one never fails
				if (!e.checkThenProcess(state, false))
					LOG_ERROR("GotServerSettingsEvent failed but shouldn't");

			} break;
		}

		if (rv < 0)
			break;

		len -= auditableEventSize[type];
		rv += auditableEventSize[type];

	}

	return rv;
}

const char* findNextValidDumpFilename()
{
	static string rv;
	struct stat s;

	for (int x = 0; x < 10000; ++x)
	{
		char buf[128];

		snprintf(buf, sizeof(buf), "./auditdump%i.bin", x);

		// check if it exists
		if(stat(buf, &s) != 0)
		{ // doesn't exist
			rv = buf;
			break;
		}
	}

	return rv.c_str();
}

char checkRawAuditStream(u8* data, int len, bool shouldDumpViolations)
{
	char rv = 0;
	u8* originalData = data;
	int originalLen = len;

	if (!disconnected)
	{
		// The format is <Start Auditable State> <Events>* <End Auditable State>
		AuditableState start;

		mm->addTraceMessage("-> Started checkRawAuditStream");

		int processed = deserializeAuditableState(&start, data, len);

		if (processed < 0)
			rv = -processed;
		else
		{
			data += processed;
			len -= processed;

			// pump all events on start
			int processed = pumpAllEvents(&start, data, len);

			if (processed < 0)
				rv = -processed;
			else
			{
				data += processed;
				len -= processed;

				// check if end matches start after pumping all events
				AuditableState end;

				processed = deserializeAuditableState(&end, data, len);

				if (processed <= 0)
					rv = -processed;
				else if (processed != len)
					rv = EXTRA_DATA_AFTER_END_STATE;
				else
					rv = start.isSameState(&end);
			}
		}

		if (rv != 0 && shouldDumpViolations)
		{
			LOG_ERROR("Dumping violation");

			const char* dumpFileName = findNextValidDumpFilename();

			FILE* f = fopen(dumpFileName, "wb");

			if (f)
			{
				fwrite(originalData, originalLen, 1, f);
				fclose(f);

				char buf[128];
				snprintf(buf, sizeof(buf), "Dumped Violation to '%s'", dumpFileName);

				flash->flashMessage(buf);
				printf("%s",buf); // debug
			}
			else
				LOG_ERROR2("fopen failed on dumpFileName='%s'", dumpFileName);

			// CHECK violations
			LOG_ERROR("checking dumped file!!");
			checkDumpFile(dumpFileName);

			//LOG_ERROR("EXITING");
			//exit(1);
		}
		else if (rv != 0)
			LOG_ERROR("Not dumping violation because shouldDumpViolations is false!\n");

		if (net->isOffline() && rv != 0)
		{
			LOG_ERROR2("Checking raw audit stream error = '%s'\n", AuditErrorCodeName[(u32)rv]);
		}

		mm->addTraceMessage("<- Ended checkRawAuditStream");
	}

	return rv;
}

char checkRawAuditStreamWithDump(u8* data, int len)
{
	if (!currentState.processedServerSettings) // read only, so its multithreaded ok
		return 0; // if no settings have been loaded, just reeturn that it's okay
	else
		return checkRawAuditStream(data, len, true);
}

void checkDumpFile(const char* dumpFileName)
{
	if (!dumpFileName || !dumpFileName[0])
		dumpFileName = "./auditdump0.bin";

	// get file size
	struct stat s;
	if(stat(dumpFileName, &s) < 0)
	{
		char buf[128];
		snprintf(buf, sizeof(buf), "Could not locate file '%s'.", dumpFileName);

		chat->chatMessage(buf,"green");
	}
	else
	{
		int size = s.st_size;

		FILE* f = fopen(dumpFileName, "rb");

		if (!f)
		{
			char buf[128];
			snprintf(buf, sizeof(buf), "Could not open file '%s' for reading.", dumpFileName);

			chat->chatMessage(buf,"green");
		}
		else
		{
			u8* buf = (u8*)util->amalloc(size, __FILE__);
			size_t read = fread(buf, size, 1, f);
			fclose(f);

			if (read != 1)
			{
				char buffer[128];
				snprintf(buffer, sizeof(buffer), "Error reading file '%s'.", dumpFileName);

				chat->chatMessage(buffer,"green");
			}
			else
			{
				int rv = checkRawAuditStream(buf, size, false);

				char text[128];
				snprintf(text, sizeof(text), "Audit Result on file '%s' is %s(%i)",
						dumpFileName, AuditErrorCodeName[rv], rv);
				chat->chatMessage(text,"green");
			}

			util->afree((void**)&buf, size, __FILE__);
		}
	}
}

void reset()
{
	AuditableState blank;

	beginningState = currentState = blank; // there may be better ways to do this

	millisecondsInStream = 0;

	emptyEventList();

	// run-time sanity check; check buffer size
	for (int x = 0; x < TYPE_AUDITABLE_STATE; ++x)
	{
		if (auditableEventSize[x] > AUDITABLE_EVENT_MAXSIZE)
		{
			LOG_ERROR2("Auditable Event size for event %i is greater than AUDITABLE_EVENT_MAXSIZE. Increase AUDITABLE_EVENT_MAXSIZE to prevent memory overflows.", x);
			mm->fatalError();
		}
	}

	if (!initialized)
	{
		initialized = true;

		if (initialSync)
		{
			// fake a sync right now
			updatedTimerSync((void*)&initialSyncParam);

			for (unsigned int x = 0; x < initialTicks.size(); ++x)
				updateShips((void*)&initialTicks[x]);

			// don't need them anymore, free memory
			initialTicks.clear();
		}

		mm->regCallback(I_AUDIT, CB_SELFSHIPCHANGEOCCURRED, CB_SELFSHIPCHANGEOCCURRED_VERSION, selfShipChange);
		mm->regCallback(I_AUDIT, CB_SENDINGPOSITIONPACKET, CB_SENDINGPOSITIONPACKET_VERSION, sendingPositionPacket);
		mm->regCallback(I_AUDIT, CB_SELFSHIPCHANGE, CB_SELFSHIPCHANGE_VERSION, selfShipChangeRequest);
		mm->regCallback(I_AUDIT, CB_SELFFREQCHANGE, CB_SELFFREQCHANGE_VERSION, selfFreqChangeRequest);
		mm->regCallback(I_AUDIT, CB_PLAYERENTERING, CB_PLAYERENTERING_VERSION, playerEntering);
		mm->regCallback(I_AUDIT, CB_PLAYERLEAVING, CB_PLAYERLEAVING_VERSION, playerLeaving);
		mm->regCallback(I_AUDIT, CB_FREQCHANGE, CB_FREQCHANGE_VERSION, playerChangeFreq);
		mm->regCallback(I_AUDIT, CB_UNBUFFEREDSHIPCHANGE, CB_UNBUFFEREDSHIPCHANGE_VERSION, playerChangeShip);
		mm->regCallback(I_AUDIT, CB_RECEIVEDPOSITIONPACKET, CB_RECEIVEDPOSITIONPACKET_VERSION, receivedPositionPacket);
		mm->regCallback(I_AUDIT, CB_RECEIVEDWEAPONPACKET, CB_RECEIVEDWEAPONPACKET_VERSION, receivedWeapon);
		mm->regCallback(I_AUDIT, CB_SELFDEATH, CB_SELFDEATH_VERSION, selfDeath);
		mm->regCallback(I_AUDIT, CB_OTHERPLAYER_DIED, CB_OTHERPLAYER_DIED_VERSION, otherPlayerDied);
	}
}

//// interface communication
void* getClassInstance(void* _mm, LoadMode lm)
{
	void * rv = 0;

	mm = (ModuleManager*)_mm;

	if (lm == LOADMODE_Init)
	{
		mm->regCallback(I_AUDIT, CB_READ_SERVER_SETTINGS, CB_READ_SERVER_SETTINGS_VERSION, serverSettingsLoaded);
		mm->regCallback(I_AUDIT, CB_PRERENDER, CB_PRERENDER_VERSION, preRender);
		mm->regCallback(I_AUDIT, CB_INTERNALCOMMAND, CB_INTERNALCOMMAND_VERSION, internalCommand);
		mm->regCallback(I_AUDIT, CB_PRINTMEMORYUSAGE, CB_PRINTMEMORYUSAGE_VERSION, printMemoryUsage);
		mm->regCallback(I_AUDIT, CB_UPDATEDSYNC, CB_UPDATEDSYNC_VERSION, updatedTimerSync);
		mm->regCallback(I_AUDIT, CB_UPDATESHIPS, CB_UPDATESHIPS_VERSION, updateShips);

		au.version = I_AUDIT;
		au.checkRawAuditStream = checkRawAuditStreamWithDump;
		au.resetAuditStream = reset;

		rv = (void*)&au;
	}
	else if (lm == LOADMODE_LoadInterfaces)
	{
		net = (Net*)mm->getInterface(I_AUDIT, I_NET);
		ss = (SelfShip*)mm->getInterface(I_AUDIT, I_SELFSHIP);
		status = (StatusModifier*)mm->getInterface(I_AUDIT, I_STATUSMODIFIER);
		util = (Utilities*)mm->getInterface(I_AUDIT, I_UTILITIES);
		gs = (GameSettings*)mm->getInterface(I_AUDIT, I_GAMESETTINGS);
		sm = (Shipman*)mm->getInterface(I_AUDIT, I_SHIPMAN);
		physics = (Physics*)mm->getInterface(I_AUDIT, I_PHYSICS);
		level = (Level*)mm->getInterface(I_AUDIT, I_LEVEL);
		sh = (SettingsHandler*)mm->getInterface(I_AUDIT, I_SETTINGSHANDLER);
		ssi = (SS_Items*)mm->getInterface(I_AUDIT, I_SSITEMS);
		pm = (Playerman*)mm->getInterface(I_AUDIT, I_PLAYERMAN);
		os = (OtherShips*)mm->getInterface(I_AUDIT, I_OTHERSHIPS);
		par = (Particles*)mm->getInterface(I_AUDIT, I_PARTICLES);
		g = (Graphics*)mm->getInterface(I_AUDIT, I_GRAPHICS);
		ui = (UniqueImage*)mm->getInterface(I_AUDIT, I_UNIQUEIMAGE);
		chat = (Chat*)mm->getInterface(I_AUDIT, I_CHAT);
		flash = (Flash*)mm->getInterface(I_AUDIT, I_FLASH);
	}
	else if (lm == LOADMODE_PostLoadInterfaces)
	{
		init();
	}
	else if (lm == LOADMODE_Unload)
	{
		deinit();
	}

	return rv;
}

extern "C"
{
	EXPORT void* getInstance(void* mm, LoadMode lm)
	{
		return getClassInstance(mm,lm);
	}
}