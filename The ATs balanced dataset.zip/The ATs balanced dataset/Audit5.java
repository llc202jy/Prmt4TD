public partial class admin_admin_setup : System.Web.UI.Page
{
    String redirect_page = "home.aspx";
    SecurityModule security;
    LoginUserInfo userInfo;
    #region Events

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["security"] == null)
            {
                //Response.Redirect(Common.sLoginPage);
                //return;
                Response.Redirect(Common.sLoginPage);
            }

            //CHECK FOR SECURITY
            userInfo = (LoginUserInfo)Session["security"];
            security = userInfo.getModuleSecurity("System Parameter Management");
            if (security == null)
                Response.Redirect(redirect_page);
            else
            {
                if (security.getView() == 0)
                    Response.Redirect(redirect_page);
                if (security.getEdit() == 0)
                {
                    btnSave.Visible = false;
                    txtNoOfRows.Enabled = false;
                    txtQuestions.Enabled = false;
                    ddlDTFormat.Enabled = false;
                }
            }

            Page.Title = "Public Service Division - Setup";
            this.Master.setHeader("setup");
            this.Master.setHeaderText("Setup");
            this.Master.setBreadcrumb("<img src='../images/white_arrow_2.jpg' width='10px' height='10px' />&nbsp;Setup");

            if (!Page.IsPostBack)
            {
                //Call loadData function
                loadData();

                ddlDTFormat.Focus();
            }
        }
        catch (Exception ex)
        {
            //Insert into Audit Trail
            string msg = ex.Message.Replace("'", " ");
            LoginUserInfo userInfo = (LoginUserInfo)Session["security"];
            try
            {
                SqlDbClass.insertAudit("System Parameter Edit", userInfo.getName(), userInfo.getLoginName(),
                    "Error(" + msg + ") in loading Systme Parameter");
            }
            catch (Exception exc)
            { }
            lblErrorMessage.Text = "System cannot load the page successfully.";
            Common.MessageBox(lblErrorMessage.Text, this);
        }

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            String dtFormat = ddlDTFormat.Text;
            int noOfRows = int.Parse(txtNoOfRows.Text);
            string q = txtQuestions.Text;
            int noOfQuestions = int.Parse(q);

            String query = "UPDATE [Setup] SET setup_dtformat=";
            query += "'" + dtFormat + "',";
            query += " setup_gvrcount=" + noOfRows+ ",";
            query += " setup_qperpage=" + noOfQuestions + "";
            query += " WHERE setup_id = 1";

            SqlDbClass.ExecuteNonQuery(query);

            //Insert into Audit Trail
            LoginUserInfo userInfo = (LoginUserInfo)Session["security"];
            SqlDbClass.insertAudit("System Parameter Edit", userInfo.getName(), userInfo.getLoginName(),
                "Updated System Parameter");

            //redirect to the GROUP list page
            //Response.Redirect("home.aspx");
            lblErrorMessage.Text = "System updated the data into the database successfully.";
        }
        catch (Exception ex)
        {
            //Insert into Audit Trail
            string msg = ex.Message.Replace("'", " ");
            LoginUserInfo userInfo = (LoginUserInfo)Session["security"];
            SqlDbClass.insertAudit("System Parameter Edit", userInfo.getName(), userInfo.getLoginName(),
                "Error(" + msg + ") in updating Systme Parameter");

            lblErrorMessage.Text = "System cannot add the data into the database.";
            Common.MessageBox(lblErrorMessage.Text, this);
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
    
    #endregion

    #region User Defined Functions

    //This function retrieves data from setup tabel to controls
    private void loadData()
    {
        String query = "SELECT * from [Setup] WHERE setup_id=1";
        DataSet ds = new DataSet();
        ds = SqlDbClass.ExecuteDataSet(query);

        ddlDTFormat.Text = ds.Tables[0].Rows[0]["setup_dtformat"].ToString().Trim();
        txtNoOfRows.Text = ds.Tables[0].Rows[0]["setup_gvrcount"].ToString();
        txtQuestions.Text = ds.Tables[0].Rows[0]["setup_qperpage"].ToString();
                
    }
    #endregion


