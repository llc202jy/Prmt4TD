    /**
     * Appends and returns a new empty "purchase-order" element
     */
    public na.learn.java.xmlbean.bom.PurchaseOrderDocument.PurchaseOrder addNewPurchaseOrder()
    {
        synchronized (monitor())
        {
            check_orphaned();
            na.learn.java.xmlbean.bom.PurchaseOrderDocument.PurchaseOrder target = null;
            target = (na.learn.java.xmlbean.bom.PurchaseOrderDocument.PurchaseOrder)get_store().add_element_user(PURCHASEORDER$0);
            return target;
        }
    }
    /**
     * An XML purchase-order(@http://xmlbean.java.learn.na/BOM).
     *
     * This is a complex type.
     */
    public static class PurchaseOrderImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements na.learn.java.xmlbean.bom.PurchaseOrderDocument.PurchaseOrder
    {
        
        public PurchaseOrderImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CUSTOMER$0 = 
            new javax.xml.namespace.QName("http://xmlbean.java.learn.na/BOM", "customer");
        private static final javax.xml.namespace.QName DATE$2 = 
            new javax.xml.namespace.QName("http://xmlbean.java.learn.na/BOM", "date");
        private static final javax.xml.namespace.QName LINEITEM$4 = 
            new javax.xml.namespace.QName("http://xmlbean.java.learn.na/BOM", "line-item");
        private static final javax.xml.namespace.QName SHIPPER$6 = 
            new javax.xml.namespace.QName("http://xmlbean.java.learn.na/BOM", "shipper");
        
        
        /**
         * Gets the "customer" element
         */
        public na.learn.java.xmlbean.bom.Customer getCustomer()
        {
            synchronized (monitor())
            {
                check_orphaned();
                na.learn.java.xmlbean.bom.Customer target = null;
                target = (na.learn.java.xmlbean.bom.Customer)get_store().find_element_user(CUSTOMER$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "customer" element
         */
        public void setCustomer(na.learn.java.xmlbean.bom.Customer customer)
        {
            synchronized (monitor())
            {
                check_orphaned();
                na.learn.java.xmlbean.bom.Customer target = null;
                target = (na.learn.java.xmlbean.bom.Customer)get_store().find_element_user(CUSTOMER$0, 0);
                if (target == null)
                {
                    target = (na.learn.java.xmlbean.bom.Customer)get_store().add_element_user(CUSTOMER$0);
                }
                target.set(customer);
            }
        }
        
        /**
         * Appends and returns a new empty "customer" element
         */
        public na.learn.java.xmlbean.bom.Customer addNewCustomer()
        {
            synchronized (monitor())
            {
                check_orphaned();
                na.learn.java.xmlbean.bom.Customer target = null;
                target = (na.learn.java.xmlbean.bom.Customer)get_store().add_element_user(CUSTOMER$0);
                return target;
            }
        }
        
        /**
         * Gets the "date" element
         */
        public java.util.Calendar getDate()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATE$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getCalendarValue();
            }
        }
        
        /**
         * Gets (as xml) the "date" element
         */
        public org.apache.xmlbeans.XmlDateTime xgetDate()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDateTime target = null;
                target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATE$2, 0);
                return target;
            }
        }
        
        /**
         * Sets the "date" element
         */
        public void setDate(java.util.Calendar date)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATE$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATE$2);
                }
                target.setCalendarValue(date);
            }
        }
        
        /**
         * Sets (as xml) the "date" element
         */
        public void xsetDate(org.apache.xmlbeans.XmlDateTime date)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDateTime target = null;
                target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATE$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATE$2);
                }
                target.set(date);
            }
        }
        
        /**
         * Gets array of all "line-item" elements
         */
        public na.learn.java.xmlbean.bom.LineItem[] getLineItemArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(LINEITEM$4, targetList);
                na.learn.java.xmlbean.bom.LineItem[] result = new na.learn.java.xmlbean.bom.LineItem[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "line-item" element
         */
        public na.learn.java.xmlbean.bom.LineItem getLineItemArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                na.learn.java.xmlbean.bom.LineItem target = null;
                target = (na.learn.java.xmlbean.bom.LineItem)get_store().find_element_user(LINEITEM$4, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "line-item" element
         */
        public int sizeOfLineItemArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LINEITEM$4);
            }
        }
        
        /**
         * Sets array of all "line-item" element
         */
        public void setLineItemArray(na.learn.java.xmlbean.bom.LineItem[] lineItemArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(lineItemArray, LINEITEM$4);
            }
        }
        
        /**
         * Sets ith "line-item" element
         */
        public void setLineItemArray(int i, na.learn.java.xmlbean.bom.LineItem lineItem)
        {
            synchronized (monitor())
            {
                check_orphaned();
                na.learn.java.xmlbean.bom.LineItem target = null;
                target = (na.learn.java.xmlbean.bom.LineItem)get_store().find_element_user(LINEITEM$4, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(lineItem);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "line-item" element
         */
        public na.learn.java.xmlbean.bom.LineItem insertNewLineItem(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                na.learn.java.xmlbean.bom.LineItem target = null;
                target = (na.learn.java.xmlbean.bom.LineItem)get_store().insert_element_user(LINEITEM$4, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "line-item" element
         */
        public na.learn.java.xmlbean.bom.LineItem addNewLineItem()
        {
            synchronized (monitor())
            {
                check_orphaned();
                na.learn.java.xmlbean.bom.LineItem target = null;
                target = (na.learn.java.xmlbean.bom.LineItem)get_store().add_element_user(LINEITEM$4);
                return target;
            }
        }
        
        /**
         * Removes the ith "line-item" element
         */
        public void removeLineItem(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LINEITEM$4, i);
            }
        }
        
        /**
         * Gets the "shipper" element
         */
        public na.learn.java.xmlbean.bom.Shipper getShipper()
        {
            synchronized (monitor())
            {
                check_orphaned();
                na.learn.java.xmlbean.bom.Shipper target = null;
                target = (na.learn.java.xmlbean.bom.Shipper)get_store().find_element_user(SHIPPER$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "shipper" element
         */
        public boolean isSetShipper()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SHIPPER$6) != 0;
            }
        }
        
        /**
         * Sets the "shipper" element
         */
        public void setShipper(na.learn.java.xmlbean.bom.Shipper shipper)
        {
            synchronized (monitor())
            {
                check_orphaned();
                na.learn.java.xmlbean.bom.Shipper target = null;
                target = (na.learn.java.xmlbean.bom.Shipper)get_store().find_element_user(SHIPPER$6, 0);
                if (target == null)
                {
                    target = (na.learn.java.xmlbean.bom.Shipper)get_store().add_element_user(SHIPPER$6);
                }
                target.set(shipper);
            }
        }
        
        /**
         * Appends and returns a new empty "shipper" element
         */
        public na.learn.java.xmlbean.bom.Shipper addNewShipper()
        {
            synchronized (monitor())
            {
                check_orphaned();
                na.learn.java.xmlbean.bom.Shipper target = null;
                target = (na.learn.java.xmlbean.bom.Shipper)get_store().add_element_user(SHIPPER$6);
                return target;
            }
        }
        
        /**
         * Unsets the "shipper" element
         */
        public void unsetShipper()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SHIPPER$6, 0);
            }
        }
    }