public class ManagedThread extends Thread
{
   private volatile boolean  bQuit, bActive;
   private Thread            myself;
   private Object            oParam;
   private ThreadConsumerI consumer;
   private ThreadCallbackI callback;
   private String            sDefaultName;
   private BooleanLock     suspend;
   private BooleanLock     lock;

   /**
    * Creates a new thread for use with ThreadManager.
    *
    * @param group the thread group for this thread.
    * @param sName the name of the new thread.
    */
   ManagedThread ( FlexThreadGroup group, String sName )
   {
      super ( group, sName );
      sDefaultName = sName;
      setPriority( NORM_PRIORITY );
      bQuit   = false;
      bActive = false;
      Diagnostic.trace ( Diagnostic.CAT_THREAD_MGR, "New thread allocated: " + sName );
      suspend = new BooleanLock(false);
      lock = new BooleanLock(false);
      start();
   }

   /**
    * Runs a request in this thread.
    *
    * @param consumer the class that the request will be run in.
    * @param callback the class to be notified as this request begins and completes.
    * @param nPriority the trear priority
    * @param o the object to pass to IConsumer.processService()
    */
   void requestService ( ThreadConsumerI consumer, ThreadCallbackI callback, int nPriority, Object o )
   {
      requestService( null, consumer, callback, nPriority, o );
   }

   /**
    * Runs a request in this thread.
    *
    * @param name the temporary name given to this thread while perfomring a task
    * @param consumer the class that the request will be run in.
    * @param callback the class to be notified as this request begins and completes.
    * @param nPriority the trear priority
    * @param o the object to pass to IConsumer.processService()
    */
   void requestService ( String sName, ThreadConsumerI consumer, ThreadCallbackI callback, int nPriority, Object o )
   {
      try
      {
         synchronized (suspend)
         {
            // Wait until this thread is suspended
            suspend.waitUntilTrue();

            // Set all information required for performing the requested service
            if ( sName != null )
               setName( sName );
            this.bActive  = true;
            this.oParam   = o;
            this.consumer = consumer;
            this.callback = callback;
            setPriority ( nPriority );

            // Wake up this thread an perform the requested service
            suspend.setValue(false);
         }
      }
      catch ( InterruptedException ie )
      {
         Thread.currentThread().interrupt(); // reassert
      }
   }

   public void run ( )
   {
      myself = Thread.currentThread();
      while ( !bQuit )
      {
         try
         {
            synchronized (suspend)
            {
               suspend.setValue(true);
               suspend.waitUntilFalse();
            }
         }
         catch ( InterruptedException ie )
         {
            // Reassert interrupt so the remaining of the code
            // sees that an interrupt has been requested
            Thread.currentThread().interrupt();
         }

         if ( bActive )
         {
            // lock this thread so nobody has access to it until done processing service
            lock.setValue(true);

            if ( callback != null )
            {
               Diagnostic.trace ( Diagnostic.CAT_THREAD_MGR, "Notifing callback about task start on thread " + getName() );
               callback.threadTaskStart ( consumer, oParam );
            }

            if ( consumer != null )
            {
               Diagnostic.trace ( Diagnostic.CAT_THREAD_MGR, "Begining task on thread " + getName() );
               consumer.processService ( oParam );
               Diagnostic.trace ( Diagnostic.CAT_THREAD_MGR, "Task completed on thread " + getName() );
            }

            if ( callback != null )
            {
               Diagnostic.trace ( Diagnostic.CAT_THREAD_MGR, "Notifing callback about task end on thread " + getName() );
               callback.threadTaskEnd ( consumer, oParam );
            }

            // Cleanup after task is completed.
            setPriority( NORM_PRIORITY );
            setName( sDefaultName );
            bActive = false;
            oParam   = null;
            consumer = null;
            callback = null;

            // Call ThreadManager to notify this thread is done
            ThreadManager.returnThread( this.getThreadGroup().getName(), this );

            // release lock for this thread
            lock.setValue(false);
         }
      }

      // Cleanup after this thread completes.
      Diagnostic.trace ( Diagnostic.CAT_THREAD_MGR, "Thread " + getName() + " finished." );
      bActive  = false;
      bQuit    = true;
      oParam   = null;
      consumer = null;
      callback = null;
   }

   /**
    * Terminates this thread.  If bForced is true then the current task is interrupted,
    * otherwise the task is allowed to complete before this thread is terminated.
    *
    * @param bForced force quits this task.
    */
   void quitTasks ( boolean bForced )
   {
      try
      {
         if ( bForced  && (consumer != null) )
         {
            // Interrupt the current task.
            if ( myself != null )
            {
               Diagnostic.trace ( Diagnostic.CAT_THREAD_MGR, "Interrupting task on thread " + myself.getName() );
               bQuit = true;
               bActive = false;
               myself.interrupt();
               myself = null;
            }
         }
         else
         {
            // Make sure that this thread terminates.
            if ( bActive )
               Diagnostic.trace ( Diagnostic.CAT_THREAD_MGR, "Stopping task on thread " + myself.getName() );

            synchronized (suspend)
            {
               // Now kill it
               bQuit = true;
               bActive = false;
               suspend.setValue(false);
            }
         }
      }
      catch ( Exception e ) { e.printStackTrace(); }
   }

   boolean isActive ( )
   {
      return bActive;
   }

   synchronized void setActive ( boolean bActive )
   {
      this.bActive = bActive;
   }

   void waitToFinish()
      throws InterruptedException
   {
      lock.waitUntilFalse();
   }

   boolean isAborted()
   {
      return bQuit;
   }
}