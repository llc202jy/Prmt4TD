public interface InterestProperties {

	/**
	 * The time between heartbeat requests used by the failure detector. It should be
	 * provided in seconds
	 */
	public static final String PROP_WAN_HEARTBEAT_DELAY = "commune.fd.wan.heartbeatdelay";
	
	/**
	 * The detection time that will be used by the failure detector to detect a
	 * failure or recovery of a component. It should be provided in seconds
	 */
	public static final String PROP_WAN_DETECTION_TIME = "commune.fd.wan.detectiontime";

	public static final String PROP_LAN_HEARTBEAT_DELAY = "commune.fd.lan.heartbeatdelay";
	public static final String PROP_LAN_DETECTION_TIME = "commune.fd.lan.detectiontime";
	
	public static final String PROP_LOCAL_HEARTBEAT_DELAY = "commune.fd.localhost.heartbeatdelay";
	public static final String PROP_LOCAL_DETECTION_TIME = "commune.fd.localhost.detectiontime";

}package br.edu.ufcg.lsd.commune.processor.interest;

import java.lang.reflect.Method;

import br.edu.ufcg.lsd.commune.container.ObjectDeployment;

public class Monitor {

	private final ObjectDeployment monitorDeployment;
	private final Method recoveryNotification;
	private final Method failureNotification;

	public Monitor(ObjectDeployment monitorDeployment, Method recoveryNotification, Method failureNotification) {
		this.monitorDeployment = monitorDeployment;
		this.recoveryNotification = recoveryNotification;
		this.failureNotification = failureNotification;
	}

	protected ObjectDeployment getMonitorDeployment() {
		return monitorDeployment;
	}

	protected Method getRecoveryNotification() {
		return recoveryNotification;
	}

	protected Method getFailureNotification() {
		return failureNotification;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((monitorDeployment == null) ? 0 : monitorDeployment.getDeploymentID().getServiceID().hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final Monitor other = (Monitor) obj;
		if (monitorDeployment == null) {
			if (other.monitorDeployment != null)
				return false;
		} else if (!monitorDeployment.getDeploymentID().getServiceID().equals(
				other.monitorDeployment.getDeploymentID().getServiceID()))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return this.monitorDeployment.getDeploymentID().toString();
	}
}private Monitor createMonitor(Class<?> monitorableType, String monitorServiceName) {
		ObjectDeployment monitorDeployment = this.interestProcessor.getMonitorDeployment(monitorServiceName);
		Method recoveryNotification = getRecoveryNotification(monitorDeployment, monitorableType);
		Method failureNotification = getFailureNotification(monitorDeployment, monitorableType);
		return new Monitor(monitorDeployment, recoveryNotification, failureNotification);
	}
	
	private Method getRecoveryNotification(ObjectDeployment monitorDeployment, Class<?> monitorableType) {
		return getNotificationMethod(monitorDeployment, monitorableType, RecoveryNotification.class, "recovery");
	}

	private Method getFailureNotification(ObjectDeployment monitorDeployment, Class<?> monitorableType) {
		return getNotificationMethod(monitorDeployment, monitorableType, FailureNotification.class, "failure");
	}
	
	private Method getNotificationMethod(ObjectDeployment monitorDeployment, Class<?> monitorableType, 
			Class<? extends Annotation> annotationType, String name) {
		
		Class<?> monitorType = monitorDeployment.getObject().getClass();
		Method notificationMethod = null;
		
		for (Method method : monitorType.getMethods()) {
			
			if (method.getAnnotation(annotationType) != null) {
				Class<?>[] parameterTypes = method.getParameterTypes();
				
				if (parameterTypes[0].isAssignableFrom(monitorableType)) {
					notificationMethod = method;
				}
			}
		}

		if (notificationMethod == null) {
			throw new InvalidMonitoringException("There is not " + name + " notification method for '" + 
					monitorableType + "' in the monitor '" + monitorDeployment.getDeploymentID().getServiceName() + 
					"'");
		}
		
		return notificationMethod;
	}

	public void registerInterest(String monitorName, Class<?> monitorableType, ServiceID stubServiceID, 
			InterestRequirements requirements) {
		
		Monitor monitor = createMonitor(monitorableType, monitorName);
		registerInterest(stubServiceID, monitor, requirements);
	}

	private Interest registerInterest(ServiceID stubServiceID, Monitor monitor, InterestRequirements requirements) {
		
		try {
			interestLock.lock();
			
			Interest interest = new Interest(monitor, stubServiceID, requirements);
			Interest origInterest = interests.get(stubServiceID);
			
			if (origInterest == null || origInterest.getInterested().getDeploymentID() == null) {
				setNewInterest(interest);
 			
			} else {
				DeploymentID origInterestedID = origInterest.getInterested().getDeploymentID();
				DeploymentID newInterestedID = interest.getInterested().getDeploymentID();

				if (!origInterestedID.equals(newInterestedID)) {
					origInterest.cancelScheduledExecution();
					setNewInterest(interest);
				}
 			}
			return interest;
			
		} finally {
			interestLock.unlock();
		}
	}

	private void setNewInterest(Interest interest) {
		interests.put(interest.getStubServiceID(), interest);
		scheduleHBRequest(interest);
	}
	
	protected void scheduleHBRequest(final Interest interest) {
		Runnable hbRequest = createRunnable(interest);
		
		ScheduledFuture<?> future = executor.scheduleAtFixedRate(hbRequest, DEFAULT_INTEREST_DELAY, interest.getHeartbeatDelay(), 
				TimeUnit.MILLISECONDS);
		interest.setScheduledExecution(future);
	}

	protected Runnable createRunnable(final Interest interest) {
		Runnable hbRequest = new Runnable() {
			public void run() {
				process(interest);
			}
		};
		return hbRequest;
	}

	void process(Interest interest) {
		
		try {
			interestLock.lock();

			if (!interestProcessor.getContainer().isStubUp(interest.getStubServiceID())) {
				sendIsItAliveMessage(interest);
				
			} else {
				
				if (interest.isTimedOut()) {
					sendNotifyFailureMessage(interest);
					
				} else {
					sendIsItAliveMessage(interest);
				}
			}
		} finally {
			interestLock.unlock();
		}
	}
	
	private void sendNotifyFailureMessage(Interest interest) {
		ObjectDeployment interested = interest.getInterested();
		Message message = 
			new Message(interested.getContainer().getContainerID(), interested.getDeploymentID(), 
					interest.getFailureNotificationMethod().getName());
		
		DeploymentID stubDeploymentID = 
			interestProcessor.getContainer().getStubDeploymentID(interest.getStubServiceID());
		Class<?> stubType = interest.getFailureNotificationMethod().getParameterTypes()[0];
		
		StubParameter stubParameter = new StubParameter(stubDeploymentID);
		message.addParameter(stubType, stubParameter);
		
		if (interest.hasFailureNotificationMethodDeploymentID()) {
			message.addParameter(DeploymentID.class, stubDeploymentID);
		}

		if (interest.hasFailureNotificationMethodCertificate()) {
			message.addParameter(X509CertPath.class, interest.getInterestCertPath());
		}
		
		this.interestProcessor.sendMessage(message);
	}

	private void sendIsItAliveMessage(Interest interest) {
		Message message = interest.createIsItAliveMessage();
		this.interestProcessor.sendMessage(message);
	}

	public void isItAlive(ServiceID monitoredID, DeploymentID sourceID) {
		if (monitoredID == null) {
			return;
		}
		
		Container myContainer = this.interestProcessor.getContainer();
		ContainerID monitoredContainerID = monitoredID.getContainerID();
		String serviceName = monitoredID.getServiceName();
		
		if (monitoredContainerID == null || !monitoredContainerID.equals(myContainer.getContainerID()) ||
				serviceName == null) {
			return;
		}
		
		ObjectDeployment monitoredDeployment = myContainer.getObjectRepository().get(serviceName);
		
		
		Message message = null; 
		
		if ( monitoredDeployment == null ) {
			ServiceID validMonitoredID = new ServiceID(myContainer.getContainerID(), monitoredID.getServiceName());
			message = createUpdateStatusMessage(sourceID, validMonitoredID);
			message.addParameter(MonitorableStatus.class, MonitorableStatus.UNAVAILABLE);
		} else {
			message = createUpdateStatusMessage(sourceID, monitoredDeployment.getDeploymentID());
			message.addParameter(MonitorableStatus.class, MonitorableStatus.AVAILABLE);
		}
		
		this.interestProcessor.sendMessage(message);
	}
	
	private Message createUpdateStatusMessage(DeploymentID sourceID, CommuneAddress monitoredID) {
		String processorType = InterestProcessor.class.getName();
		return new Message(monitoredID, sourceID, InterestProcessor.UPDATE_STATUS_MESSAGE, processorType);
	}

	void updateStatus(CommuneAddress targetID, MonitorableStatus status, X509CertPath certPath) {
		if (MonitorableStatus.AVAILABLE.equals(status)) {
			updateStatusAvailable(targetID, certPath);
		} else {
			updateStatusUnavailable(targetID, certPath);
		}
	}

	private void updateStatusAvailable(CommuneAddress targetID, X509CertPath certPath) {
		DeploymentID targetDeploymentID = (DeploymentID) targetID; 
		
		try {
			interestLock.lock();
			//TODO validate
			Interest interest = interests.get(targetDeploymentID.getServiceID());
			
			
			if (interest == null) {
				return;//TODO
			}

			interest.setLastHeartbeat();
			
			interest.setInterestCertPath(certPath);
			
			if (!interestProcessor.getContainer().isStubUp(interest.getStubServiceID())) {
				
				interestProcessor.getContainer().setStubDeploymentID(targetDeploymentID);
				sendNotifyRecoveryMessage(interest);

			} 
			
			
			
		} finally {
			interestLock.unlock();
		}
	}
	
	private void sendNotifyRecoveryMessage(Interest interest) {
		ObjectDeployment interested = interest.getInterested();
		Message message = 
			new Message(interested.getContainer().getContainerID(), interested.getDeploymentID(), 
					interest.getRecoveryNotificationMethod().getName());
		
		DeploymentID stubDeploymentID = 
			interestProcessor.getContainer().getStubDeploymentID(interest.getStubServiceID());
		Class<?> stubType = interest.getRecoveryNotificationMethod().getParameterTypes()[0]; 

		message.addStubParameter(stubType, stubDeploymentID);
		
		if (interest.hasRecoveryNotificationMethodDeploymentID()) {
			message.addParameter(DeploymentID.class, stubDeploymentID);
		}
		
		if (interest.hasRecoveryNotificationMethodCertificate()) {
			message.addParameter(X509CertPath.class, interest.getInterestCertPath());
		}
		
		this.interestProcessor.sendMessage(message);
	}
	
	private void updateStatusUnavailable(CommuneAddress targetID, X509CertPath certPath) {
		try {
			interestLock.lock();
			ServiceID targetServiceID = (ServiceID) targetID; 
			//TODO validate
			Interest interest = interests.get(targetServiceID);
			
			if (interest != null) {
				interest.setInterestCertPath(certPath);
				if (interestProcessor.getContainer().isStubUp(interest.getStubServiceID())) {
					sendNotifyFailureMessage(interest);
				}
			}
			
		} finally {
			interestLock.unlock();
		}
	}
	
	public void shutdown() {
		this.executor.shutdownNow();
		try {
			this.executor.awaitTermination( DEFAULT_TIMEOUT, TimeUnit.MILLISECONDS );
		} catch ( InterruptedException e ) {
			// TODO
		}
	}

	
	private class InterestThreadFactory implements ThreadFactory {

		public Thread newThread(Runnable r) {
			Thread thread = new Thread(r);
			thread.setName("EXECUTOR-Interest" + thread.getId());
			return thread;
		}
	}

	
	public void registerParameterInterest(ObjectDeployment objectDeployment, Method method, int parameterIndex, 
			Class<?> parameterType, ServiceID stubServiceID) {

		Monitor monitor = null;
		MonitoredParameter monitoredParameter = null;
		
		try {
			interestLock.lock();
			monitoredParameter = findMonitoredParameter(objectDeployment.getObject(), method, parameterIndex);
			monitor = parameter2Monitor.get(monitoredParameter);
			
			if (monitor != null) {
				Interest interest = registerInterest(stubServiceID, monitor, monitoredParameter.getRequirements());
				interest.setLastHeartbeat();
			}
			
		} finally {
			interestLock.unlock();
		}
	}
	
	private MonitoredParameter findMonitoredParameter(Object deployedObject, Method method, int parameterIndex) {
		Set<MonitoredParameter> parameters = parameter2Monitor.keySet();
		
		for (MonitoredParameter monitoredParameter : parameters) {
			
			if (monitoredParameter.getDeployedObject().equals(deployedObject) && 
				monitoredParameter.getMethod().equals(method) && 
				monitoredParameter.getParameterIndex() == parameterIndex) {
				
				return monitoredParameter;
			}
		}
		
		return null;
	}

	public void removeInterest(Object stub) {
		try {
			interestLock.lock();

			ServiceID stubServiceID = interestProcessor.getContainer().getStubServiceID(stub);
			Interest removedInterest = interests.remove(stubServiceID);
			if(removedInterest != null){
				removedInterest.cancelScheduledExecution();
			}
			
			
		} finally {
			interestLock.unlock();
		}
	}

	public boolean isInterested(DeploymentID interestedID, ServiceID monitorableID) {
		try {
			interestLock.lock();

			Interest interest = interests.get(monitorableID);
			
			if (interest == null) {
				return false;
			}
			
			return interestedID.equals(interest.getInterested().getDeploymentID());
			
		} finally {
			interestLock.unlock();
		}
	}
	
	public Interest getInterest(ServiceID monitorableID) {
		try {
			interestLock.lock();

			return interests.get(monitorableID);
			
		} finally {
			interestLock.unlock();
		}
	}