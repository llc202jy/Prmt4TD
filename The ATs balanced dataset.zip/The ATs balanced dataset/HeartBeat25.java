/**
 * This operation will be used to dispense a drink. It will :
 * 1 Instruct the Drinks Store to dispense the drink. It will also instruct the Can 
 *   Collection Box to display a can shape.
 * 2 Instruct the Store Controller to update the Drinks Store Display on the 
 *   Machinery Simulator Panel. 
 * 3 In case of fault detection, it will send a "fault detected" response 
 *   to the Transaction Controller
 * @param selection Integer value
 * @return boolean state
 * @throws VMCSException Exception for dispense drinks
 */	
	public boolean dispenseDrink(int selection) throws VMCSException{
		try {
			transCtrl.getMainController().getMachineryController().dispenseDrink(selection);
		} catch (VMCSException e) {
			transCtrl.terminateFault(this);
			throw new VMCSException("Dispense Drinks",e.getMessage());
		}
		DrinksStore drinksStore =(DrinksStore)transCtrl.getStoreController().getStore(Store.DRINK);
		DrinksStoreItem drinksStoreItem = (DrinksStoreItem)drinksStore.getStoreItem(selection);
		DrinksBrand drinksBrand = (DrinksBrand)drinksStoreItem.getContent();
		transCtrl.getCustomerPanel().getCollectCan().setValue(drinksBrand.getName());
		
		updateDrinkSelection(selection);
		return true;
	}

/**
 * This operation is used to display the latest stock and
 * price information on the Drink Selection Box. 
 * @param selection Integer value 
 */	
	private void updateDrinkSelection(int selection){
		DrinksStore drinksStore =(DrinksStore)transCtrl.getStoreController().getStore(Store.DRINK);
		DrinksStoreItem drinksStoreItem = (DrinksStoreItem)drinksStore.getStoreItem(selection);
		DrinksBrand drinksBrand = (DrinksBrand)drinksStoreItem.getContent();
		int qty = drinksStoreItem.getQuantity();
		int price = drinksBrand.getPrice();
		String name = drinksBrand.getName();
		transCtrl.getCustomerPanel().getDrinkInput().update(selection, qty, price, name) ;
	}

	public void updateDrinkPanel(){
		
	}
}