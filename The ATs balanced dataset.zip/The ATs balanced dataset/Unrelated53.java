*/
package org.ourgrid.deployer;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.ourgrid.common.config.Configuration;
import org.ourgrid.common.config.LogConfiguration;
import org.ourgrid.common.config.UserAgentConfiguration;
import org.ourgrid.common.spec.GumSpec;
import org.ourgrid.common.spec.main.CommonCompiler;
import org.ourgrid.common.spec.main.CompilerException;

public class Deployer {

	/** directory where UA.properties files will be stored */
	public static final String UASCONF_DIR = "uasconf";

	private List<GumSpec> gumsList;


	/**
	 * Creates a Deployer object that uses the gums described in the SDF file
	 * 
	 * @param siteDescriptionFile The SDF path
	 * @throws CompilerException If any error occurs during SDF compilation
	 */
	public Deployer( String siteDescriptionFile ) throws CompilerException {

		/** get GUMPSpec from SDF */
		CommonCompiler compiler = new CommonCompiler();

		/** tries to compile GDF */
		compiler.compile( siteDescriptionFile, CommonCompiler.SDF_TYPE );

		gumsList = compiler.getResult();
	}


	/**
	 * Main.
	 * 
	 * @param args First argument is the command to execute and the second is
	 *        GDF path
	 */
	public static void main( String[ ] args ) {

		/** **** Configuring Log4j ******* */
		/**
		 * setting to write 'uaadmin log' in a diferent file of 'peer log'. For
		 * all others log properties configuration, uaadmin log is equivalent to
		 * peer
		 */

		/** log file path for uaadmin log */
		final String UAADMIN_LOG_FILE_PATH = Configuration.getInstance( Configuration.PEER ).getRootDir()
				+ "/log/uaadmin.log";

		/** xml log file path for uaadmin xml log */
		final String UAADMIN_XML_LOG_FILE_PATH = UAADMIN_LOG_FILE_PATH + ".xml";

		String logfile = UAADMIN_LOG_FILE_PATH;
		String xmlLogFile = UAADMIN_XML_LOG_FILE_PATH;
		String logPropertiesfile = Configuration.getInstance().getLogPropertiesPath();

		String parents = new File( logfile ).getParent();

		if ( parents != null )
			(new File( parents )).mkdirs();

		LogConfiguration.configure( logPropertiesfile, logfile, xmlLogFile );

		Configuration.reset();

		/** ****** */

		Configuration.getInstance( Configuration.MYGRID );

		/** holds the command to execute */
		String command = args[0];

		/** holds the gdf path */
		String sdf = args[1];

		checkEnv( sdf );

		Deployer deployer;
		try {
			/** creates a new deployer */
			deployer = new Deployer( sdf );

			/** run deployer commmand */
			if ( command.equalsIgnoreCase( "start" ) || command.equalsIgnoreCase( "restart" ) ) {
				deployer.config();
			}
			deployer.startThreads( command );
		} catch ( CompilerException e ) {
			String message = "Error compiling the " + sdf + " file.";
			System.out.println( message );
			System.exit( ErrorCode.ERROR_COMPILING_THE_SDF_FILE );
		}
	}


	/**
	 * Checks if the environment is ok. If the gdf file not exists the program
	 * will exit.
	 * 
	 * @param file A file that must exist.
	 */
	private static void checkEnv( String file ) {

		int exitCode = ErrorCode.OK;

		if ( !fileExists( file ) ) {
			System.out.println( "The file \'" + file + "\' does not exist." );
			exitCode = ErrorCode.THE_FILE_NOT_EXIST;
		}

		if ( exitCode != ErrorCode.OK ) {
			System.exit( exitCode );
		}

	}


	/**
	 * Check if the gdf file exists.
	 * 
	 * @param fileName The file name.
	 * @return If the file exists or not.
	 */
	private static boolean fileExists( String fileName ) {

		if ( fileName == null ) {
			return false;
		}
		File file = new File( fileName );
		return file.exists();
	}


	/**
	 * Generates configuration files for user agents in localGuMP;
	 */
	private void config() {

		/** iterating on gum in localGuMP */
		for ( GumSpec currentGumSpec : gumsList ) {
			if ( gumIsUserAgent( currentGumSpec ) ) {
				generateUAProperties( currentGumSpec );
			}
		}
	}


	/**
	 * Verifies whether the specified GuM is a User Agent public static boolean
	 * gumIsUserAgent(GuMSpec currentGuMSpec) {
	 * 
	 * @param currentGuMSpec The remote Gum specification
	 * @return <b>true </b> if the GuM is a User Agent, <b>false </b> otherwise.
	 */
	public static boolean gumIsUserAgent( GumSpec currentGuMSpec ) {

		return currentGuMSpec.getAttribute( GumSpec.ATT_TYPE ).equalsIgnoreCase( GumSpec.TYPE_UA_LINUX )
				|| currentGuMSpec.getAttribute( GumSpec.ATT_TYPE ).equalsIgnoreCase( GumSpec.TYPE_UA_WINDOWS )
				|| currentGuMSpec.getAttribute( GumSpec.ATT_TYPE ).equalsIgnoreCase( GumSpec.TYPE_UA_SWAN );
	}


	/**
	 * Generates UA.properties file to a specific GuM
	 * 
	 * @param currentGuMSpec The GuM description
	 */
	private void generateUAProperties( GumSpec currentGuMSpec ) {

		/** create "uaproperties" directory */
		File fileUAPropertiesDir = new File( UASCONF_DIR );

		if ( !fileUAPropertiesDir.exists() ) {
			fileUAPropertiesDir.mkdir();
		}

		/** create a UA.properties file with GuM name */
		File fileUAPropertiesFile = defineUAPropertiesFile( currentGuMSpec );

		/** write UA.properties contents */
		writePropertiesToUAPropertiesFile( currentGuMSpec, fileUAPropertiesFile );
	}


	/**
	 * Reads user agent properties' defaults and, then, replace them with
	 * properties in the GuM description object (GuMSpec)
	 * 
	 * @param currentGuMSpec The GuM description
	 * @return A Map object that contains up to date user agent properties
	 *         values
	 */
	private Map readAndReplaceDefaultProperties( GumSpec currentGuMSpec ) {

		/** loading default values * */
		Map<String,String> uaPropertiesContents = UserAgentConfiguration.getDefaults();

		/** replacing default values with user-defined values * */

		Configuration.getInstance();

		// this if-clause wouldn't be necessary here, since we have decided that
		// UA_ATT_PORT is mandatory for User Agents (03/08/2004)
		// defensive programming is applied here
		if ( currentGuMSpec.hasAttribute( GumSpec.ATT_PORT ) ) {
			uaPropertiesContents.put( UserAgentConfiguration.PREFIX + Configuration.PROP_PORT, currentGuMSpec
					.getAttribute( GumSpec.ATT_PORT ) );
		}
		if ( currentGuMSpec.hasAttribute( GumSpec.ATT_NAME ) ) {
			uaPropertiesContents.put( UserAgentConfiguration.PREFIX + Configuration.PROP_NAME, currentGuMSpec
					.getAttribute( GumSpec.ATT_NAME ) );
		}
		if ( currentGuMSpec.hasAttribute( GumSpec.ATT_PLAYPEN_ROOT ) ) {
			uaPropertiesContents.put( UserAgentConfiguration.PREFIX + UserAgentConfiguration.PROP_PLAYPEN_ROOT,
					currentGuMSpec.getAttribute( GumSpec.ATT_PLAYPEN_ROOT ) );
		}
		if ( currentGuMSpec.hasAttribute( GumSpec.ATT_STORAGE_DIR ) ) {
			uaPropertiesContents.put( UserAgentConfiguration.PREFIX + UserAgentConfiguration.PROP_STORAGE_DIR,
					currentGuMSpec.getAttribute( GumSpec.ATT_STORAGE_DIR ) );
		}
		if ( currentGuMSpec.hasAttribute( GumSpec.ATT_PLAYPEN_SIZE ) ) {
			uaPropertiesContents.put( UserAgentConfiguration.PREFIX + UserAgentConfiguration.PROP_PLAYPEN_SIZE,
					currentGuMSpec.getAttribute( GumSpec.ATT_PLAYPEN_SIZE ) );
		}
		if ( currentGuMSpec.hasAttribute( GumSpec.ATT_STORAGE_SIZE ) ) {
			uaPropertiesContents.put( UserAgentConfiguration.PREFIX + UserAgentConfiguration.PROP_STORAGE_SIZE,
					currentGuMSpec.getAttribute( GumSpec.ATT_STORAGE_SIZE ) );
		}
		if ( currentGuMSpec.hasAttribute( GumSpec.ATT_SECURITY ) ) {
			uaPropertiesContents.put( UserAgentConfiguration.PREFIX + UserAgentConfiguration.PROP_SECURITY,
					currentGuMSpec.getAttribute( GumSpec.ATT_SECURITY ) );
		}

		if ( currentGuMSpec.hasAttribute( UserAgentConfiguration.PROP_IDLENESS_DETECTOR ) ) {
			uaPropertiesContents.put( UserAgentConfiguration.PREFIX + UserAgentConfiguration.PROP_IDLENESS_DETECTOR,
					currentGuMSpec.getAttribute( UserAgentConfiguration.PROP_IDLENESS_DETECTOR ) );
		}
		if ( currentGuMSpec.hasAttribute( UserAgentConfiguration.PROP_IDLENESS_TIME ) ) {
			uaPropertiesContents.put( UserAgentConfiguration.PREFIX + UserAgentConfiguration.PROP_IDLENESS_TIME,
					currentGuMSpec.getAttribute( UserAgentConfiguration.PROP_IDLENESS_TIME ) );
		}

		return uaPropertiesContents;
	}


	/**
	 * Writes user agent properties to UA.properties file. User agent properties
	 * come from a GuMSpec object
	 * 
	 * @param currentGuMSpec The GuM description
	 * @param uaPropertiesFile A reference object to the UA.properties file
	 */
	private void writePropertiesToUAPropertiesFile( GumSpec currentGuMSpec, File uaPropertiesFile ) {

		/** BufferedWriter object to write on UA.properties file */
		BufferedWriter out = null;
		try {
			out = new BufferedWriter( new FileWriter( uaPropertiesFile ) );

			/** a map that contains UA.properties file contents */
			Map uaPropertiesContents = readAndReplaceDefaultProperties( currentGuMSpec );

			/** writing UA.properties contents to the file * */
			Set entrySet = uaPropertiesContents.entrySet();
			Iterator itEntrySet = entrySet.iterator();
			while ( itEntrySet.hasNext() ) {
				Map.Entry mapEntry = (Map.Entry) itEntrySet.next();
				out.write( mapEntry.getKey() + " = " + mapEntry.getValue() );
				out.write( System.getProperty( "line.separator" ) );

			}
		} catch ( IOException e ) {
			String message = "Error when trying to write ua.properties file for gum "
					+ currentGuMSpec.getAttribute( GumSpec.ATT_NAME ) + ": " + e.getMessage();
			System.out.println( message );
		} finally {
			try {
				if ( out != null ) {
					out.close();
				}
			} catch ( IOException e ) {
				String message = "Error when trying to write ua.properties file for gum "
						+ currentGuMSpec.getAttribute( GumSpec.ATT_NAME ) + ": " + e.getMessage();
				System.out.println( message );
			}
		}
	}


	/**
	 * Defines the name of the UA.properties file, composing it with the GuM
	 * name and asserting it autoinstallable or not. It is autoinstallable if it
	 * is possible to use this Deployer to install and start it.
	 * 
	 * @param currentGuMSpec The GuM descritpion
	 * @return A reference to the UA.properties file
	 */
	private File defineUAPropertiesFile( GumSpec currentGuMSpec ) {

		/** get GuM name from GuMSpec */
		String gumName = currentGuMSpec.getAttribute( GumSpec.ATT_NAME ) + "_"
				+ currentGuMSpec.getAttribute( GumSpec.ATT_PORT );

		if ( uaIsAutoInstallable( currentGuMSpec ) ) {
			return new File( UASCONF_DIR + "/ua.properties-" + gumName + "-auto" );
		}
		return new File( UASCONF_DIR + "/ua.properties-" + gumName );

	}


	/**
	 * Verifies whether it is possible to install User Agent through deployer.
	 * 
	 * @param currentGuMSpec The remote Gum specification
	 * @return <b>true </b> if it is possible to automatically install, <b>false
	 *         </b> otherwise.
	 */
	public static boolean uaIsAutoInstallable( GumSpec currentGuMSpec ) {

		/**
		 * some conditions must be satisfied for the user agent to be
		 * autoinstallable
		 */
		return currentGuMSpec.getAttribute( GumSpec.ATT_TYPE ).equalsIgnoreCase( GumSpec.TYPE_UA_LINUX );
	}


	/**
	 * Verifies whether the gum spec has the attributes that are mandatory to
	 * use uaadmin.
	 * 
	 * @param currentGuMSpec The remote Gum specification
	 * @return <b>true </b> if the gum has the mandatory attributes, <b>false
	 *         </b> otherwise.
	 */
	public static boolean uaHasMandatoryAttributes( GumSpec currentGuMSpec ) {

		/**
		 * some conditions must be satisfied for the user agent to be
		 * autoinstallable
		 */
		return currentGuMSpec.hasAttribute( GumSpec.ATT_REM_EXEC )
				&& currentGuMSpec.hasAttribute( GumSpec.ATT_COPY_FROM )
				&& currentGuMSpec.hasAttribute( GumSpec.ATT_COPY_TO );
	}


	/**
	 * Starts all Threads to execute the deployer command.
	 * 
	 * @param command The deployer command.
	 */
	private void startThreads( String command ) {

		System.out.println( "-- Initializing " + command + " execution --" );
		for ( GumSpec currentGuMSpec : gumsList ) {
			String gumName = currentGuMSpec.getAttribute( GumSpec.ATT_NAME );
			if ( uaIsAutoInstallable( currentGuMSpec ) ) {
				if ( uaHasMandatoryAttributes( currentGuMSpec ) ) {
					try {
						Thread t = new Thread( new DeployerRunnable( command, currentGuMSpec ), "DeployerRunnable "
								+ currentGuMSpec.getAttribute( GumSpec.ATT_NAME ) );
						t.start();

					} catch ( Exception e ) {
						System.out.println( "--> " + gumName + " [ Problems when trying to " + command + " ("
								+ e.getMessage() + ") ] " );
					}
				} else {
					System.out.println( "--> " + gumName + " [ Problems (missing mandatory attributes" + "'"
							+ GumSpec.ATT_REM_EXEC.toString() + "' '" + GumSpec.ATT_COPY_TO.toString() + "' '"
							+ GumSpec.ATT_COPY_FROM.toString() + " ) ] " );
				}
			} else {
				System.out.println( "--> " + gumName + " [ Unable to " + command + " (not ualinux) ] " );
			}
		}
	}
}
*/
package org.ourgrid.deployer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.UnmarshalException;

import org.ourgrid.common.config.Configuration;
import org.ourgrid.common.executor.Executor;
import org.ourgrid.common.executor.ExecutorException;
import org.ourgrid.common.executor.ExecutorFactory;
import org.ourgrid.common.executor.ExecutorHandle;
import org.ourgrid.common.executor.ExecutorResult;
import org.ourgrid.common.gum.GumClient;
import org.ourgrid.common.spec.GumSpec;
import org.ourgrid.common.spec.exception.GumSpecificationException;
import org.ourgrid.common.url.UserAgentURLProvider;
import org.ourgrid.common.util.SimpleZip;
import org.ourgrid.common.util.StringUtil;
import org.ourgrid.gridmachine.services.GumSpecServices;
import org.ourgrid.gridmachine.useragent.ShutdownManager;
import org.ourgrid.gridmachine.useragent.UserAgentClient;

/**
 * The deployer Thread. It is responsible for initializing, installing,
 * testing... User Agents.
 */
public class DeployerRunnable implements Runnable {

	public static final String flagMachine = "$machine";

	public static final String flagLocalFile = "$localfile";

	public static final String flagRemoteFile = "$remotefile";

	public static final String flagCommand = "$command";

	/** mygrid home directory */
	private String mgroot;

	/** directory where UA.properties files will be stored */
	private String uaPropertiesDir;

	/** The deployer command */
	private String command;

	/** The GuMSpec */
	private GumSpec currentGuMSpec;

	/** The tar package extension */
	private static final String ZIP_EXTENSION = ".zip";

	/** Logger (log4j) object to store log events */
	private static transient final org.apache.log4j.Logger LOG = org.apache.log4j.Logger
			.getLogger( DeployerRunnable.class );

	// grid machine rem_exec field
	private String gumRemExec;

	// grid machine copy_to field
	private String gumCopyTo;

	// grid machine name field
	private String dirName, gumName;

	Executor executor;

	ExecutorHandle eh;

	ExecutorResult execResult;


	/**
	 * Constructor.
	 * 
	 * @param uaadminCommand The command the Thread will execute.
	 * @param currentGuMSpec The GuMSpec.
	 */
	public DeployerRunnable( String uaadminCommand, GumSpec currentGuMSpec ) {

		this.command = uaadminCommand;
		this.currentGuMSpec = currentGuMSpec;

		gumRemExec = currentGuMSpec.getAttribute( GumSpec.ATT_REM_EXEC );
		gumCopyTo = currentGuMSpec.getAttribute( GumSpec.ATT_COPY_TO );
		gumName = currentGuMSpec.getAttribute( GumSpec.ATT_NAME );
		dirName = currentGuMSpec.getAttribute( GumSpec.ATT_NAME ) + "_"
				+ currentGuMSpec.getAttribute( GumSpec.ATT_PORT );

		/** mygrid home directory */
		mgroot = Configuration.getInstance().getProperty( Configuration.MGROOT );

		/** directory where UA.properties files will be stored */
		uaPropertiesDir = Deployer.UASCONF_DIR;

		executor = ExecutorFactory.getExecutorInstance();
	}


	private String[ ] getFilesToZip( String uaPropertiesFilePath ) {

		if ( new File( mgroot + "/lib/aspectjrt.jar" ).exists() ) {
			return new String[ ] { mgroot + "/bin/useragent", mgroot + "/lib/log4j.jar", mgroot + "/ua.log.properties",
									mgroot + "/lib/aspectjrt.jar", mgroot + "/LICENSE",
									uaPropertiesFilePath + File.separator + "ua.properties" };
		}
		return new String[ ] { mgroot + "/bin/useragent", mgroot + "/lib/log4j.jar", mgroot + "/ua.log.properties",
								uaPropertiesFilePath + File.separator + "ua.properties" };

	}


	/**
	 * The Thread behavior - it will execute the deployer command.
	 */
	public void run() {

		try {
			if ( command.equalsIgnoreCase( "start" ) ) {
				start( currentGuMSpec );
			} else if ( command.equalsIgnoreCase( "status" ) ) {
				status( currentGuMSpec );
			} else if ( command.equalsIgnoreCase( "stop" ) ) {
				stop( currentGuMSpec );
			} else if ( command.equalsIgnoreCase( "restart" ) ) {
				restart( currentGuMSpec );
			} else if ( command.equalsIgnoreCase( "clean" ) ) {
				clean();
			}
			delUasconf();

		} catch ( DeployerException de ) {
			System.err.println( de.getMessage() );
		}
	}


	/**
	 * @throws DeployerException
	 * @throws
	 */
	private void start( GumSpec currentGuMSpec ) throws DeployerException {

		GumClient uaGuM;
		String startCommand = "useragent start -";
		String message;

		try {

			try {
				uaGuM = new UserAgentClient( GumSpecServices.createGum( currentGuMSpec ), currentGuMSpec );
				if ( uaGuM.getStatus().isUp() )
					printGumStatus( currentGuMSpec.getAttribute( GumSpec.ATT_NAME ), currentGuMSpec
							.getAttribute( GumSpec.ATT_PORT ), UAAdminStatus.ALREADY_STARTED );

			} catch ( RemoteException e ) {

				install();

				// command to be executed on the remote gum for starting the
				// useragent
				String execCommand = StringUtil.replace( gumRemExec, flagMachine, gumName );
				String remoteCommand = "'sh " + DeployerRunnable.getUADirName( dirName ) + File.separator
						+ startCommand + "'";
				execCommand = StringUtil.replace( execCommand, flagCommand, remoteCommand );

				// using Executor class for remote execution
				try {
					eh = executor.execute( ".", execCommand );
					execResult = ExecutorFactory.getExecutorInstance().getResult( eh );

					if ( execResult.getExitValue() == 0 ) {
						printGumStatus( currentGuMSpec.getAttribute( GumSpec.ATT_NAME ), currentGuMSpec
								.getAttribute( GumSpec.ATT_PORT ), UAAdminStatus.STARTED );

					} else {
						message = "Could not start useragent at " + currentGuMSpec.getAttribute( GumSpec.ATT_NAME );
						System.out.println( message );
						LOG.info( message );
					}
				} catch ( ExecutorException e1 ) {
					message = "There was a problem during starting on "
							+ currentGuMSpec.getAttribute( GumSpec.ATT_NAME ) + ". User Agent was not started there.";
					LOG.error( message );
				}

			}
		} catch ( GumSpecificationException e ) {
			throw new DeployerException( mgroot, e );

		} catch ( Exception e ) {
			throw new DeployerException( mgroot, e );
		}
	}


	/**
	 * Tries to stop user agents in localGuMP
	 * 
	 * @throws DeployerException
	 */
	private void stop( GumSpec currentGuMSpec ) throws DeployerException {

		try {

			String url = UserAgentURLProvider.shutdownManager( currentGuMSpec.getAttribute( GumSpec.ATT_NAME ),
					currentGuMSpec.getAttribute( GumSpec.ATT_PORT ) );

			ShutdownManager shutdownManager = (ShutdownManager) Naming.lookup( url );

			shutdownManager.shutdown();

			LOG.error( "Cannot stop " + currentGuMSpec.getAttribute( GumSpec.ATT_NAME ) );
			throw new DeployerException( mgroot, new Exception( "Cannot stop "
					+ currentGuMSpec.getAttribute( GumSpec.ATT_NAME ) ) );

		} catch ( UnmarshalException e ) {
			// This exception is expected

			printGumStatus( currentGuMSpec.getAttribute( GumSpec.ATT_NAME ), currentGuMSpec
					.getAttribute( GumSpec.ATT_PORT ), UAAdminStatus.STOPPED );

		} catch ( RemoteException e ) {
			printGumStatus( currentGuMSpec.getAttribute( GumSpec.ATT_NAME ), currentGuMSpec
					.getAttribute( GumSpec.ATT_PORT ), UAAdminStatus.ALREADY_STOPPED );

		} catch ( Exception e ) {
			throw new DeployerException( mgroot, e );
		}

	}


	/**
	 * Checks status of each user agent GuMs from MyGump
	 * 
	 * @throws DeployerException if any problem occurs during the test of the
	 *         user agent.
	 */
	private void status( GumSpec currentGuMSpec ) {

		if ( Deployer.gumIsUserAgent( currentGuMSpec ) ) {

			GumClient ua;

			try {
				ua = new UserAgentClient( GumSpecServices.createGum( currentGuMSpec ), currentGuMSpec );
				printGumStatus( currentGuMSpec.getAttribute( GumSpec.ATT_NAME ), currentGuMSpec
						.getAttribute( GumSpec.ATT_PORT ), ua.getStatus() );
			} catch ( Exception e ) {
				printGumStatus( currentGuMSpec.getAttribute( GumSpec.ATT_NAME ), currentGuMSpec
						.getAttribute( GumSpec.ATT_PORT ), UAAdminStatus.DOWN );
			}

		} else {
			System.out.println( "--> " + currentGuMSpec.getAttribute( GumSpec.ATT_NAME ) + ":"
					+ currentGuMSpec.getAttribute( GumSpec.ATT_PORT ) + " [ Can't verify. Not ualinux type. ] " );
		}

	}


	/**
	 * Tries to restart user agents from localGuMP
	 * 
	 * @throws DeployerException
	 * @throws DeployerException if any error occurs during this initialization.
	 */

	private void restart( GumSpec currentGuMSpec ) throws DeployerException {

		GumClient uaGuM;
		try {

			try {

				uaGuM = new UserAgentClient( GumSpecServices.createGum( currentGuMSpec ), currentGuMSpec );

				if ( uaGuM.getStatus().isUp() ) {
					stop( currentGuMSpec );

				}

			} catch ( RemoteException e ) {
				// Nothing to be done, the gum is already down, just start it

			} finally {

				start( currentGuMSpec );
			}

		} catch ( GumSpecificationException e ) {
			throw new DeployerException( mgroot, e );
		} catch ( Exception e ) {
			throw new DeployerException( mgroot, e );
		}
	}


	/**
	 * Tries to install user agent software at a specific remote GuM
	 * 
	 * @param currentGuMSpec The GuMSpec object that describes the GuM in which
	 *        User Agent software will be installed
	 * @throws DeployerException if could not install the User Agent software.
	 */
	private void install() throws DeployerException {

		String message;
		String finalDirName = getUADirName( dirName );

		String uaPropertiesFilePath = uaPropertiesDir + File.separator + dirName;
		String zipFileName = dirName + ZIP_EXTENSION;
		String zipLocationName = uaPropertiesDir + File.separator + zipFileName;

		try {
			/** getting correct UA.properties file for this GuM */
			File currentUAPropertiesFile = locateUAPropertiesFiles( dirName );

			// command to be executed on the remote gum for creating the
			// .ourgrid/gumName directory at the gum
			String execCommand = StringUtil.replace( gumRemExec, flagMachine, gumName );
			String remoteCommand = "'mkdir -p " + finalDirName + "'";
			execCommand = StringUtil.replace( execCommand, flagCommand, remoteCommand );

			// using Executor class for remote execution
			eh = executor.execute( "/tmp", execCommand );
			execResult = ExecutorFactory.getExecutorInstance().getResult( eh );

			if ( execResult.getExitValue() == 0 ) {
				// dirName succesfully created on gumName

				// renaming local UA.properties file to remove gum name and
				// "auto" flag
				File gumDirectory = new File( uaPropertiesFilePath );
				gumDirectory.mkdir();
				currentUAPropertiesFile.renameTo( new File( uaPropertiesFilePath + File.separator + "ua.properties" ) );
				String currentFilesToZip[] = getFilesToZip( uaPropertiesFilePath );
				File zipFile = createZip( zipLocationName, currentFilesToZip );

				// command for transferring zipName file to the gum
				String destFile = finalDirName;
				String copyCommand = StringUtil.replace( gumCopyTo, flagMachine, gumName );
				copyCommand = StringUtil.replace( copyCommand, flagLocalFile, zipLocationName );
				copyCommand = StringUtil.replace( copyCommand, flagRemoteFile, destFile );

				// Transferring zipFile to the remote gum
				eh = executor.execute( ".", copyCommand );
				execResult = ExecutorFactory.getExecutorInstance().getResult( eh );

				if ( execResult.getExitValue() == 0 ) {
					// zipName succesfully transferred to the gum 'gumName'

					// command for transferring jarFile file to the gum
					destFile = finalDirName + File.separator + "useragent.jar";
					copyCommand = StringUtil.replace( gumCopyTo, flagMachine, gumName );
					copyCommand = StringUtil.replace( copyCommand, flagLocalFile, mgroot + "/lib/useragent.jar" );
					copyCommand = StringUtil.replace( copyCommand, flagRemoteFile, destFile );

					// Transferring jarFile to the remote gum
					eh = executor.execute( "/tmp", copyCommand );
					execResult = ExecutorFactory.getExecutorInstance().getResult( eh );

					if ( execResult.getExitValue() == 0 ) {
						// jarFile succesfully transferred to the gum
						// 'gumName'

						// unzip the zipFile on the remote gum
						execCommand = StringUtil.replace( gumRemExec, flagMachine, gumName );
						String remoteCmd = "'cd " + finalDirName
								+ "; java -cp useragent.jar org.ourgrid.common.util.SimpleZip -x " + zipFileName
								+ " . ; rm -f " + zipFileName + "'";
						execCommand = StringUtil.replace( execCommand, flagCommand, remoteCmd );

						// Unzipping zipName at the 'gumName'
						eh = executor.execute( "/tmp", execCommand );
						execResult = ExecutorFactory.getExecutorInstance().getResult( eh );

						if ( execResult.getExitValue() == 0 ) {
							// unzip was successfully done at the 'gumName'
							// deleting renamed local UA.properties file
							// from "uasconf" directory
							String localCommand = "'/bin/rm -Rf " + uaPropertiesFilePath + "'";
							eh = executor.execute( ".", localCommand );
							execResult = ExecutorFactory.getExecutorInstance().getResult( eh );

							zipFile.delete();
							gumDirectory.delete();

						} else {
							message = "Could not remove local temp file ' " + uaPropertiesFilePath;
							LOG.error( message );
						}
					} else {
						message = "Could not transfer 'useragent.jar' to the gum " + dirName;
						LOG.error( message );
					}
				} else {
					message = "Could not transfer '" + zipLocationName + "' to the gum " + dirName;
					LOG.error( message );
				}
			} else {
				message = "Could not create " + finalDirName + " at " + dirName;
				LOG.error( message );
			}

			// Deleting the UAProperties file.
			currentUAPropertiesFile.delete();

		} catch ( Exception e ) {
			message = "There was a problem during installation on " + dirName + ". User Agent was not installed there.";
			LOG.error( message, e );
		}
	}


	/**
	 * Locates the UA.properties file associated with the specified GuM
	 * 
	 * @param gumName The GuM name
	 * @return A File object that references the UA.properties file associated
	 *         with the specified GuM
	 * @throws FileNotFoundException When it was not possible to find the
	 *         UA.properties file that matches the specified GuM
	 */
	private File locateUAPropertiesFiles( String gumName ) throws FileNotFoundException {

		/** get UA.properties files list */
		File uaPropertiesDirFile = new File( uaPropertiesDir );
		File[ ] uaPropertiesFiles = uaPropertiesDirFile.listFiles();

		/** iterating on UA.properties files */
		if ( uaPropertiesFiles != null ) {

			for ( int i = 0; i < uaPropertiesFiles.length; i++ ) {
				/** getting the correct UA.properties file */
				if ( uaPropertiesFiles[i].getName().equals( "ua.properties-" + gumName + "-auto" ) ) {
					return uaPropertiesFiles[i];
				}
			}
		}

		/** couldn't find the correct UA.properties file */
		String message = "Couldn't find ua.properties file for GuM " + gumName + ".";
		throw new FileNotFoundException( message );
	}


	/**
	 * Creates a zip package containing files to transfer to grid machine.
	 * 
	 * @param zipName The package filename (including the extension)
	 * @param filesToTransfer An array containing the files names that will be
	 *        into the package.
	 * @return A File that is a logical representation of the package created.
	 * @throws IOException In case unable to zip.
	 */
	private File createZip( String zipName, String[ ] filesToTransfer ) throws IOException {

		SimpleZip.zipIt( filesToTransfer, zipName );

		return new File( zipName );
	}


	/**
	 * Compose user agent installation directory with the GuM name
	 * 
	 * @param gumName The remote GuM name
	 * @return A String with a USER AGENT INSTALLATION directory complete path.
	 */
	public static String getUADirName( String gumName ) {

		return ".ourgrid/" + gumName;
	}


	/**
	 * Cleans the environment, deleting the user's <b>.ougrid</b> dir, and the
	 * <b>uasconf</b> dir.
	 */
	private void clean() {

		delOurgrid();

		delUasconf();
