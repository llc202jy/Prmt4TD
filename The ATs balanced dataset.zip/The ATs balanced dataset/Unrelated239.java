package pkiva.validation.ocsp.connectors;

import pkiva.validation.ocsp.OCSPManager;
import pkiva.exceptions.CertificateChainRevocationException;

import java.util.Hashtable;
import java.util.Collection;
import java.util.Date;
import java.beans.PropertyChangeSupport;
import java.security.cert.CRLSelector;
import java.security.cert.X509Certificate;
import javax.naming.Name;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.NameParser;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.DirContext;
import javax.naming.directory.Attributes;
import javax.resource.ResourceException;

/**
 *
 * @author  Scott.Stark@jboss.org
 * @version $Revision: 1.5 $
 */
public class OCSPJBDirContextImpl implements OCSPJBDirContext
{
   OCSPJBManagedConnection mc;

   /** Creates new FSDirContext */
   public OCSPJBDirContextImpl(OCSPJBManagedConnection mc)
   {
      this.mc = mc;
   }

   protected void setManagedConnection(OCSPJBManagedConnection mc)
   {
      this.mc = mc;
   }

   public Attributes getAttributes(Name name, String[] str) throws NamingException
   {
      return null;
   }
   
   public void close() throws NamingException
   {
//      pkiva.log.LogManager.getLogger(this.getClass()).debug("#### %%%% LDAPJBDirContextImpl close");
      mc.close();
   }

   public NamingEnumeration list(String str) throws NamingException
   {
      return null;
   }
   
   public void unbind(Name name) throws NamingException
   {
   }
   
   public DirContext getSchemaClassDefinition(Name name) throws NamingException
   {
      return null;
   }
   
   public DirContext createSubcontext(String str, Attributes attributes) throws NamingException
   {
      return null;
   }
   
   public String getNameInNamespace() throws NamingException
   {
      return null;
   }
   
   public Object addToEnvironment(String str, Object obj) throws NamingException
   {
      return null;
   }
   
   public NamingEnumeration listBindings(Name name) throws NamingException
   {
      return null;
   }
   
   public void bind(Name name, Object obj) throws NamingException
   {
   }
   
   public NamingEnumeration search(String str, Attributes attributes, String[] str2) throws NamingException
   {
      return null;
   }
   
   public void modifyAttributes(Name name, int param, Attributes attributes) throws NamingException
   {
   }
   
   public Hashtable getEnvironment() throws NamingException
   {
      return null;
   }
   
   public void bind(String str, Object obj) throws NamingException
   {
   }
   
   public void rebind(String str, Object obj, Attributes attributes) throws NamingException
   {
   }
   
   public DirContext getSchema(Name name) throws NamingException
   {
      return null;
   }
   
   public DirContext getSchemaClassDefinition(String str) throws NamingException
   {
      return null;
   }
   
   public Object lookup(String str) throws NamingException
   {
      return null;
   }
   
   public void destroySubcontext(String str) throws NamingException
   {
   }
   
   public Context createSubcontext(Name name) throws NamingException
   {
      return null;
   }
   
   public Object lookupLink(String str) throws NamingException
   {
      return null;
   }
   
   public DirContext getSchema(String str) throws NamingException
   {
      return null;
   }
   
   public Object lookup(Name name) throws NamingException
   {
      return null;
   }
   
   public void destroySubcontext(Name name) throws NamingException
   {
   }
   
   public NamingEnumeration listBindings(String str) throws NamingException
   {
      return null;
   }
   
   public void rebind(String str, Object obj) throws NamingException
   {
   }
   
   public Object removeFromEnvironment(String str) throws NamingException
   {
      return null;
   }
   
   public void bind(String str, Object obj, Attributes attributes) throws NamingException
   {
   }
   
   public NamingEnumeration search(Name name, Attributes attributes) throws NamingException
   {
      return null;
   }
   
   public NameParser getNameParser(String str) throws NamingException
   {
      return null;
   }
   
   public void bind(Name name, Object obj, Attributes attributes) throws NamingException
   {
   }
   
   public Attributes getAttributes(String str) throws NamingException
   {
      return null;
   }
   
   public void rename(String str, String str1) throws NamingException
   {
   }
   
   public void rename(Name name, Name name1) throws NamingException
   {
   }
   
   public DirContext createSubcontext(Name name, Attributes attributes) throws NamingException
   {
      return null;
   }
   
   public void rebind(Name name, Object obj, Attributes attributes) throws NamingException
   {
   }
   
   public NamingEnumeration list(Name name) throws NamingException
   {
      return null;
   }
   
   public Context createSubcontext(String str) throws NamingException
   {
      return null;
   }
   
   public void modifyAttributes(String str, int param, Attributes attributes) throws NamingException
   {
   }
   
   public NamingEnumeration search(String str, Attributes attributes) throws NamingException
   {
      return null;
   }
   
   public Name composeName(Name name, Name name1) throws NamingException
   {
      return null;
   }
   
   public String composeName(String str, String str1) throws NamingException
   {
      return null;
   }
   
   public NamingEnumeration search(Name name, Attributes attributes, String[] str) throws NamingException
   {
      return null;
   }
   
   public void rebind(Name name, Object obj) throws NamingException
   {
   }
   
   public void modifyAttributes(Name name, ModificationItem[] modificationItem) throws NamingException
   {
   }
   
   public NamingEnumeration search(Name name, String str, SearchControls searchControls) throws NamingException
   {
      return null;
   }
   
   public NamingEnumeration search(Name name, String str, Object[] obj, SearchControls searchControls) throws NamingException
   {
      return null;
   }
   
   public void unbind(String str) throws NamingException
   {
   }
   
   public void modifyAttributes(String str, ModificationItem[] modificationItem) throws NamingException
   {
   }
   
   public Attributes getAttributes(Name name) throws NamingException
   {
      return null;
   }
   
   public Object lookupLink(Name name) throws NamingException
   {
      return null;
   }
   
   public NameParser getNameParser(Name name) throws NamingException
   {
      return null;
   }
   
   public Attributes getAttributes(String str, String[] str1) throws NamingException
   {
      return null;
   }
   
   public NamingEnumeration search(String str, String str1, SearchControls searchControls) throws NamingException
   {
      return null;
   }
   
   public NamingEnumeration search(String str, String str1, Object[] obj, SearchControls searchControls) throws NamingException
   {
      return null;
   }

    // JCA Specific methods:
    public Object execute(String strOperation) throws ResourceException
    {
        return execute(strOperation, null);
    }

    public Object execute(String strOperation, Object params) throws ResourceException
    {

//        pkiva.log.LogManager.getLogger(this.getClass()).debug("#### %%%% Request to execute. Function Name: " + strOperation);

        Object returnObj = null;

        if (strOperation.equals(VALIDATE_FUNCTION))
        {
            returnObj = validate((X509Certificate[]) params);
        }
        else
        {
          pkiva.log.LogManager.getLogger(this.getClass()).error("Invalid request to execute. Function not supported: " + strOperation);
          throw new ResourceException( "Invalid request to execute. Function not supported: " + strOperation);
        }

      return returnObj;
    }

    // PKIVA Specific methods:
    protected OCSPValidationResponse validate( X509Certificate[] chain )
    {
      OCSPValidationResponse resp;

      try
      {
        resp = OCSPManager.instance().validate( chain );
      }
      catch ( CertificateChainRevocationException e )
      {
        resp = new OCSPValidationResponse( OCSPValidationResponse.REVOKED );
        resp.setCause ( e );
      }
      catch(Throwable t)
      {
        resp = new OCSPValidationResponse( OCSPValidationResponse.ERROR );
        resp.setCause ( t );
      }

      return resp;
    }
}
public class OCSPInteractionImpl implements Interaction
{
  public static final int CHAIN_FIELD = 0;
  private static final String CLOSED_ERROR = "Connection closed";
  private static final String INVALID_FUNCTION_ERROR = "Invalid function";
  private static final String INVALID_INPUT_ERROR = "Invalid input record for function";
  private static final String INVALID_OUTPUT_ERROR = "Invalid output record for function";
  private static final String EXECUTE_WITH_INPUT_RECORD_ONLY_NOT_SUPPORTED = "execute() with input record only not supported";
  
  private Connection connection;
  private boolean valid;
  
  public OCSPInteractionImpl(Connection connection)
  {
    super();
    this.connection = connection;
    valid = true;
  }
  
  public void close() throws ResourceException
  {
    connection = null;
    valid = false;
  }
  
  public Connection getConnection()
  {
    return connection;
  }
  
  public boolean execute(InteractionSpec ispec, Record input, Record output) throws ResourceException
  {
    
    if (valid)
    {
      String strOperation="";
      try
      {
        java.lang.reflect.Method m=ispec.getClass().getMethod("getFunctionName",new Class[0]);
        strOperation=(String)m.invoke(ispec,new Object[0]);
      }
      catch(Exception e)
      {
        pkiva.log.LogManager.getLogger(this.getClass()).error("Exception in resource adapter when invoking getFunctionName", e);
        // javax.resource.ResourceException does not support chained Exceptions
        throw new ResourceException("Exception in resource adapter when invoking getFunctionName:" + e.getMessage());
      }
      
      pkiva.log.LogManager.getLogger(this.getClass()).debug("Request to execute. Function Name: " + strOperation);
      
      if (strOperation.equals(OCSPInteractionSpec.VALIDATE_FUNCTION))
      {
        X509Certificate[] chain = (X509Certificate[])((IndexedRecord)input).get(CHAIN_FIELD);
        OCSPValidationResponse resp = validate(chain);
        addOutputValue(input,output,resp);
      }
      else
      {
        pkiva.log.LogManager.getLogger(this.getClass()).error("Invalid request to execute. Function not supported: " + strOperation);
        throw new ResourceException(INVALID_FUNCTION_ERROR);
      }
    }
    else
    { 
      throw new ResourceException(CLOSED_ERROR);
    }
    return true;
  }
  
  public Record execute(InteractionSpec ispec, Record input) throws ResourceException
  {
    throw new NotSupportedException(EXECUTE_WITH_INPUT_RECORD_ONLY_NOT_SUPPORTED);
  }
  
  public ResourceWarning getWarnings() throws ResourceException
  {
    return null;
  }
  public void clearWarnings() throws ResourceException
  {
  }
  
  protected void addOutputValue(Record input, Record output,Object outval) throws ResourceException
  {
    
    if (input.getRecordName().equals(OCSPIndexedRecord.INPUT))
    {
      if (output.getRecordName().equals(OCSPIndexedRecord.OUTPUT))
      {
        ((OCSPIndexedRecord) output).clear();
        // OCSPIndexedRecord is based on ArrayList, so it's suposed to support null values
        ((OCSPIndexedRecord) output).add(outval); 
      } else
      {
        throw new ResourceException(INVALID_OUTPUT_ERROR);
      }
    } else
    {
      throw new ResourceException(INVALID_INPUT_ERROR);
    }
    
    
  }
  
  protected OCSPValidationResponse validate( X509Certificate[] chain )
  {
    OCSPValidationResponse resp;

    try
    {
      resp = OCSPManager.instance().validate( chain );
    }
    catch ( CertificateChainRevocationException e )
    {
      resp = new OCSPValidationResponse( OCSPValidationResponse.REVOKED );
      resp.setCause ( e );
    }
    catch(Throwable t)
    {
      resp = new OCSPValidationResponse( OCSPValidationResponse.ERROR );
      resp.setCause ( t );
    }

    return resp;
  }
  
}
package pkiva.validation.ocsp.connectors;

import java.util.ArrayList;
import javax.resource.ResourceException;
import javax.resource.spi.LocalTransaction;
import javax.resource.spi.ManagedConnectionMetaData;
import javax.resource.spi.ConnectionRequestInfo;
import javax.resource.spi.ManagedConnection;
import javax.resource.spi.ConnectionEvent;
import javax.resource.spi.ConnectionEventListener;
import javax.security.auth.Subject;
import javax.transaction.xa.XAResource;
import java.io.PrintWriter;

/**
 *
 * @author  Scott.Stark@jboss.org
 * @version $Revision: 1.5 $
 */
public class OCSPJBManagedConnection implements ManagedConnection
{
   ArrayList listeners = new ArrayList();
   OCSPJBDirContextImpl conn;

   /** Creates new FSManagedConnection */
   public OCSPJBManagedConnection(Subject subject,
      OCSPJBRequestInfo fsInfo)
   {
//      pkiva.log.LogManager.getLogger(this.getClass()).debug("#### %%%% ctor, fsInfo="+fsInfo);
   }

   public void addConnectionEventListener(ConnectionEventListener connectionEventListener)
   {
//      pkiva.log.LogManager.getLogger(this.getClass()).debug("#### %%%% addConnectionEventListener, listener="+connectionEventListener);
      listeners.add(connectionEventListener);
   }
   public void removeConnectionEventListener(ConnectionEventListener connectionEventListener)
   {
//      pkiva.log.LogManager.getLogger(this.getClass()).debug("#### %%%% removeConnectionEventListener, listener="+connectionEventListener);
      listeners.remove(connectionEventListener);
   }

   public void associateConnection(Object obj) throws ResourceException
   {
//      pkiva.log.LogManager.getLogger(this.getClass()).debug("#### %%%% associateConnection, obj="+obj);
      conn = (OCSPJBDirContextImpl) obj;
      conn.setManagedConnection(this);
   }

   public void cleanup() throws ResourceException
   {
//      pkiva.log.LogManager.getLogger(this.getClass()).debug("#### %%%% cleanup");
   }
   
   public void destroy() throws ResourceException
   {
//      pkiva.log.LogManager.getLogger(this.getClass()).debug("#### %%%% destroy");
   }
   
   public Object getConnection(Subject subject, ConnectionRequestInfo info)
      throws ResourceException
   {
//      pkiva.log.LogManager.getLogger(this.getClass()).debug("#### %%%% getConnection, subject="+subject+", info="+info);
      if( conn == null )
         conn = new OCSPJBDirContextImpl(this);
      return conn;
   }

   public LocalTransaction getLocalTransaction() throws ResourceException
   {
//      pkiva.log.LogManager.getLogger(this.getClass()).debug("#### %%%% getLocalTransaction");
      return null;
   }
   
   public ManagedConnectionMetaData getMetaData() throws ResourceException
   {
//      pkiva.log.LogManager.getLogger(this.getClass()).debug("#### %%%% getMetaData");
      return new OCSPJBManagedConnectionMetaData();
   }
   
   public XAResource getXAResource() throws ResourceException
   {
//      pkiva.log.LogManager.getLogger(this.getClass()).debug("#### %%%% getXAResource");
      return null;
   }

   public PrintWriter getLogWriter() throws ResourceException
   {
      return null;
   }
   public void setLogWriter(PrintWriter out) throws ResourceException
   {
   }

   protected void close()
   {
      ConnectionEvent ce = new ConnectionEvent(this, ConnectionEvent.CONNECTION_CLOSED);
      ce.setConnectionHandle(conn);
      fireConnectionEvent(ce);
   }

   protected void fireConnectionEvent(ConnectionEvent evt)
   {
      for(int i=listeners.size()-1; i >= 0; i--)
      {
         ConnectionEventListener listener = (ConnectionEventListener) listeners.get(i);
         if(evt.getId() == ConnectionEvent.CONNECTION_CLOSED)
            listener.connectionClosed(evt);
         else if(evt.getId() == ConnectionEvent.CONNECTION_ERROR_OCCURRED)
            listener.connectionErrorOccurred(evt);
      }
   }
}

package pkiva.webservices;

import java.io.ByteArrayOutputStream;

import java.security.PrivateKey;
import java.security.cert.X509Certificate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;

import org.w3c.dom.*;

import org.bouncycastle.cms.*;
import org.bouncycastle.util.encoders.Base64;

import pkiva.CertificateFields;
import pkiva.utils.PKIVAProperties;
import pkiva.webservices.exception.InternalValidatorException;

/**
 * @author rnavalon
 */
public class Response {
	
	public static final int UNDEFINED = -1;
	
	public static final int SUCCESS = 0;
	public static final int FAILURE = 1;
	public static final int REFUSED	= 2;
	
	public static final int VALID	= 0;
	public static final int INVALID	= 1;
	
	
	private int    value 		= UNDEFINED;
	private String codeError;
	private int    status		= UNDEFINED;
	private int    statusReason;
	private String statusReasonDescription;
	private CertificateFields fields;
	

	private static String valueToString( int value ) {
		switch( value ) {
		case SUCCESS: return "Success";
		case FAILURE: return "Failure";
		case REFUSED: return "Refused";
		default:
			return "Undefined";
		}
	}
	
	private static String statusToString( int status ) {
		switch( status ) {
		case VALID: return "Valid";
		case INVALID: return "Invalid";
		default:
			return "Undefined";
		}
	}
	
	
	
	private Element createChild( Element parent , String name ) {
		Element child;
		Document doc = parent.getOwnerDocument();
		
		child = doc.createElement(name);
		parent.appendChild( child );
		
		return child;
	}
	
	private Element createTextChild( Element parent , String name , String value ) {
		Element child;
		Node    valueNode;
		Document doc = parent.getOwnerDocument();
		
		child = createChild(parent,name);
		if ( value != null ) {
			valueNode = doc.createTextNode( value );
			child.appendChild( valueNode );
		}
		
		return child;
	}
	
	private Element createDataChild( Element parent , String name , Object value ) {
		Element child;
		Node    valueNode;
		Document doc = parent.getOwnerDocument();
		
		child = createChild(parent,name);
		if ( value != null ) {
			valueNode = doc.createCDATASection( value.toString() );
			child.appendChild( valueNode );
		}
		
		return child;
	}
	
	
	
	private String sign( byte[] data ) throws InternalValidatorException {	
		try {
			PrivateKey prvKey; 
			X509Certificate[] certChain;

			prvKey = SignatureData.getPrivateKey();
			certChain = SignatureData.getCertificateChain();
		
			CMSProcessable msg = new CMSProcessableByteArray(data);

			CMSSignedDataGenerator gen = new CMSSignedDataGenerator();

			gen.addSigner(prvKey, SignatureData.getEECertificate(certChain), SignatureData.getAlgorithm() );

			gen.addCertificatesAndCRLs(SignatureData.getAllCertificates(certChain));

			CMSSignedData s = gen.generate(msg, true, "BC");

			return new String(Base64.encode(s.getEncoded()));
			
		} catch( InternalValidatorException ive ) {
			throw ive;
		} catch(Exception e) {
			throw new InternalValidatorException(e);
		}		
	}

	
	
	
	protected String serialize(Document doc) throws InternalValidatorException {
		ByteArrayOutputStream baos;
		DOMSource source;
		StreamResult result;

		baos   = new ByteArrayOutputStream();
		source = new DOMSource(doc);
		result = new StreamResult(baos);

		TransformerFactory transFactory = TransformerFactory.newInstance();
		Transformer transformer;
		
		try {
			String encoding = PKIVAProperties.getProperty("pkiva.output.encoding","ISO-8859-1");
			
			transformer = transFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.ENCODING, encoding);
			transformer.transform(source, result);
			
		} catch(Exception e) {
			throw new InternalValidatorException(e);
		}
		
		return baos.toString();
	}	
	
	
	
	
	public int getValue() { return this.value; }
	public void setValue( int value ) { this.value = value; }
	
	public String getCodeError() { return this.codeError; }
	public void setCodeError( String codeError ) { this.codeError = codeError; }
	
	public int getStatus() { return this.status; }
	public void setStatus( int status ) { this.status = status; }
	
	public int getStatusReason() { return this.statusReason; }
	public void setStatusReason( int statusReason ) { this.statusReason = statusReason; }
	
	public String getStatusReasonDescription() { return this.statusReasonDescription; }
	public void setStatusReasonDescription( String statusReasonDescription ) { this.statusReasonDescription = statusReasonDescription; }
	
	public CertificateFields getFields() { return this.fields; }
	public void setFields( CertificateFields fields ) { this.fields = fields; }

	
	
	
	
	public Document toXML() throws InternalValidatorException {
		try {
			DocumentBuilderFactory dbf;
			DocumentBuilder db;
			DOMImplementation di;
			
			Document doc;
			Element  response;
			
			
			dbf = DocumentBuilderFactory.newInstance();
			db  = dbf.newDocumentBuilder();
			di  = db.getDOMImplementation();
			doc = di.createDocument("","response",null);
			response = doc.getDocumentElement();
		

