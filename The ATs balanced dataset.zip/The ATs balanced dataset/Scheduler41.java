public interface ProcessThread extends Runnable
{

    /* Thread priorities */
    public static final int NORM_PRIORITY = Thread.NORM_PRIORITY;

    public static final int MAX_PRIORITY = Thread.MAX_PRIORITY;

    public static final int MIN_PRIORITY = Thread.MIN_PRIORITY;

    /* Different status' that this thread can be in */
    public final static int THREAD_NOT_YET_STARTED = -1;

    public final static int THREAD_COMPLETED = 0;

    public final static int THREAD_STARTED = 1;

    public final static int THREAD_SUSPENDED = 2;

    public final static int THREAD_STOPPED = 3;

    /**
     * For an explanation on implementing safely stoppable and suspendable
     * threads please see
     * 
     * @see http://java.sun.com/products/jdk/1.2/docs/guide/misc/threadPrimitiveDeprecation.html
     */
    public void run();

    /**
     * Stop the job
     */
    public void stop() throws InterruptedException;

    /**
     * Kills the job
     */
    public void kill();

    /**
     * Returns whether or not the job was killed
     */
    public boolean wasKilled();

    /**
     * Starts the job.
     */
    public void start();

    /**
     * Temporarily suspends the job exactly where it is
     */
    public void suspend();

    /**
     * Restarts the job.
     */
    public void resume();

    /**
     * This method allows the user to set the Thread priority of this
     * controllable object. Priorities are:
     */
    public void setPriority(int priority);

    /**
     * This method allows the user to set the interval between each thread loop.
     * Default is 10 (0.001 seconds);
     */
    public void setInterval(int interval);

    /**
     * Set the Process for this UnitisedProcess
     */
    public void setProcess(Process process);

    /**
     * Set the process for this Process
     */
    public Process getProcess();

    /**
     * This method returns the actual thread object upon which this Runnable
     * object is operating.
     */
    public Thread getRunThread();

    /**
     * This method returns status of the thread
     */
    public int getStatus();
    
    /**
     * Performs suspend logic if the thread has been suspended
     */
    public void checkSuspended();

}