import java.util.Properties;

import org.enhydra.shark.api.client.wfmc.wapi.WMFilter;
import org.enhydra.shark.api.client.wfmodel.WfProcessIterator;
import org.enhydra.shark.api.client.wfservice.SharkConnection;
import org.enhydra.shark.api.client.xpil.XPILHandler;
import org.enhydra.shark.api.common.ProcessFilterBuilder;
import org.enhydra.shark.client.utilities.SharkInterfaceWrapper;
import org.enhydra.shark.utilities.MiscUtilities;
import org.enhydra.shark.webclient.spec.utils.ParamConsts;
import org.w3c.dom.Node;

import com.lutris.util.Config;

public class XMLProcessMonitorBuilder extends XMLBuilderImpl {

   public XMLProcessMonitorBuilder(String username,
                                   Config config,
                                   String startElement,
                                   String sortCriterion,
                                   String sortAsc) {

      this.username = username;
      this.config = config;
      this.from_element = startElement;
      this.sortCriterion = sortCriterion;
      this.sortAsc = sortAsc;

   }

   protected Node fillXMLElements() throws Exception {
      SharkConnection sc = SharkInterfaceWrapper.getSharkConnection(username);

      int itemsPerPage = config.getInt("SharkWebClient."
                                       + ParamConsts.PROPERTY_PREFIX_PROCESSMONITOR
                                       + ".max.rows.per.page", 5);

      int startAt = Integer.parseInt(from_element != null ? from_element : "0");

      WfProcessIterator pit = sc.get_iterator_process();
      ProcessFilterBuilder fb = SharkInterfaceWrapper.getProcessFilterBuilder();
      WMFilter filter = fb.createEmptyFilter(sc.getSessionHandle());

      String exp = fb.toIteratorExpression(sc.getSessionHandle(), filter);
      pit.set_query_expression(exp);
      int hm = pit.how_many();
      if (startAt > hm) {
         startAt = (hm / itemsPerPage) * itemsPerPage;
         from_element = Integer.toString(startAt);
      } else if (startAt == hm && hm > 0) {
         startAt = startAt - itemsPerPage;
         from_element = Integer.toString(startAt);
      }
      from_element = Integer.toString(startAt);
      to_element = Integer.toString(startAt + itemsPerPage - 1);
      total_number = Integer.toString(hm);
      filter = fb.setLimit(sc.getSessionHandle(), filter, itemsPerPage);
      filter = fb.setStartPosition(sc.getSessionHandle(), filter, startAt);

      if (this.sortCriterion == null || this.sortCriterion.equals("")) { // search as
         // declared in
         // config file
         String orderByList = config.getString("SharkWebClient."
                                                     + ParamConsts.PROPERTY_PREFIX_PROCESSMONITOR
                                                     + ".fill.xpil.orderbylist",
                                               "");
         String[] obstrs = MiscUtilities.tokenize(orderByList, ";");
         if (obstrs.length > 0) {
            for (int i = 0; i < obstrs.length; i++) {
               String obs = obstrs[i];
               String[] sortinfo = MiscUtilities.tokenize(obs, ",");
               if (sortinfo != null && sortinfo.length == 2) {
                  String orderBy = sortinfo[0];
                  boolean asc = new Boolean(sortinfo[1]).booleanValue();
                  if (orderBy.equals("state")) {
                     fb.setOrderByState(sc.getSessionHandle(), filter, asc);
                  } else if (orderBy.equals("createdtime")) {
                     fb.setOrderByCreatedTime(sc.getSessionHandle(), filter, asc);
                  } else if (orderBy.equals("id")) {
                     fb.setOrderById(sc.getSessionHandle(), filter, asc);
                  } else if (orderBy.equals("priority")) {
                     fb.setOrderByPriority(sc.getSessionHandle(), filter, asc);
                  } else if (orderBy.equals("requester")) {
                     fb.setOrderByResourceRequesterId(sc.getSessionHandle(), filter, asc);
                  } else if (orderBy.equals("name")) {
                     fb.setOrderByName(sc.getSessionHandle(), filter, asc);
                  }
               }
            }
         }
      }
      // user has chosen search criterion
      // can search by state, createdTime, priority, requester, name
      else {
         if (this.sortCriterion.equalsIgnoreCase("state")) {
            fb.setOrderByState(sc.getSessionHandle(),
                               filter,
                               Boolean.valueOf(this.sortAsc).booleanValue());
         } else if (this.sortCriterion.equalsIgnoreCase("createdtime")) {
            fb.setOrderByCreatedTime(sc.getSessionHandle(),
                                     filter,
                                     Boolean.valueOf(this.sortAsc).booleanValue());
         } else if (this.sortCriterion.equalsIgnoreCase("priority")) {
            fb.setOrderByPriority(sc.getSessionHandle(),
                                  filter,
                                  Boolean.valueOf(this.sortAsc).booleanValue());
         } else if (this.sortCriterion.equalsIgnoreCase("requester")) {
            fb.setOrderByResourceRequesterId(sc.getSessionHandle(),
                                             filter,
                                             Boolean.valueOf(this.sortAsc).booleanValue());
         } else if (this.sortCriterion.equalsIgnoreCase("name")) {
            fb.setOrderByName(sc.getSessionHandle(),
                              filter,
                              Boolean.valueOf(this.sortAsc).booleanValue());
         } else if (this.sortCriterion.equalsIgnoreCase("id")) {
            fb.setOrderById(sc.getSessionHandle(), filter, Boolean.valueOf(this.sortAsc)
               .booleanValue());
         }
      }

      Properties props = new Properties();

      String prop = config.getString("SharkWebClient."
                                     + ParamConsts.PROPERTY_PREFIX_PROCESSMONITOR + "."
                                     + XPILHandler.FILL_PACKAGE_EXT_ATTRIBS, "false");
      props.setProperty(XPILHandler.FILL_PACKAGE_EXT_ATTRIBS, prop);
      prop = config.getString("SharkWebClient."
                              + ParamConsts.PROPERTY_PREFIX_PROCESSMONITOR + "."
                              + XPILHandler.FILL_PROCESS_FACTORY_EXT_ATTRIBS, "false");
      props.setProperty(XPILHandler.FILL_PROCESS_FACTORY_EXT_ATTRIBS, prop);
      prop = config.getString("SharkWebClient."
                              + ParamConsts.PROPERTY_PREFIX_PROCESSMONITOR + "."
                              + XPILHandler.FILL_PROCESS_EXT_ATTRIBS, "false");
      props.setProperty(XPILHandler.FILL_PROCESS_EXT_ATTRIBS, prop);
      prop = config.getString("SharkWebClient."
                              + ParamConsts.PROPERTY_PREFIX_PROCESSMONITOR + "."
                              + XPILHandler.FILL_ACTIVITY_EXT_ATTRIBS, "false");
      props.setProperty(XPILHandler.FILL_ACTIVITY_EXT_ATTRIBS, prop);
      config.getString("SharkWebClient."
                       + ParamConsts.PROPERTY_PREFIX_PROCESSMONITOR + "."
                       + XPILHandler.FILL_VARIABLE_EXT_ATTRIBS, "false");
      props.setProperty(XPILHandler.FILL_VARIABLE_EXT_ATTRIBS, prop);
      prop = config.getString("SharkWebClient."
                              + ParamConsts.PROPERTY_PREFIX_PROCESSMONITOR + "."
                              + XPILHandler.FILL_PROCESS_VARIABLES, "false");
      props.setProperty(XPILHandler.FILL_PROCESS_VARIABLES, prop);
      prop = config.getString("SharkWebClient."
                              + ParamConsts.PROPERTY_PREFIX_PROCESSMONITOR + "."
                              + XPILHandler.FILL_ALL_ACTIVITIES, "false");
      props.setProperty(XPILHandler.FILL_ALL_ACTIVITIES, prop);
      prop = config.getString("SharkWebClient."
                              + ParamConsts.PROPERTY_PREFIX_PROCESSMONITOR + "."
                              + XPILHandler.FILL_RUNNING_ACTIVITIES, "false");
      props.setProperty(XPILHandler.FILL_RUNNING_ACTIVITIES, prop);
      prop = config.getString("SharkWebClient."
                              + ParamConsts.PROPERTY_PREFIX_PROCESSMONITOR + "."
                              + XPILHandler.FILL_ACTIVITY_VARIABLES, "false");
      props.setProperty(XPILHandler.FILL_ACTIVITY_VARIABLES, prop);
      prop = config.getString("SharkWebClient."
                              + ParamConsts.PROPERTY_PREFIX_PROCESSMONITOR + "."
                              + XPILHandler.FILL_ACTIVITY_ASSIGNMENTS, "false");
      props.setProperty(XPILHandler.FILL_ACTIVITY_ASSIGNMENTS, prop);

      props.setProperty(XPILHandler.FILL_PROCESS_FACTORIES, "false");

      Node n = SharkInterfaceWrapper.getXPILHandler().getProcessInstanceList(sc.getSessionHandle(),
                                                                  username,
                                                                  filter,
                                                                  props);

      sc.disconnect();

      return n;
   }

}
         this.xformsType = XFORMS_TYPE_FILE;
      } else if (xformsType.equals(SharkParamConsts.EA_XFORMS_XMLC_CLASS)
                 || xformsType.equals(SharkParamConsts.EA_XFORMS_XMLC_CLASS_FOR_VARIABLES)) {
         this.xformsType = XFORMS_TYPE_CLASS;
      } else if (xformsType.equals(SharkParamConsts.EA_XFORMS_EMBEDED)
                 || xformsType.equals(SharkParamConsts.EA_XFORMS_EMBEDED_FOR_VARIABLES)) {
         this.xformsType = XFORMS_TYPE_EMBEDED;
      }
   }

   public XFormsGenerator(String xforms, String xformsType, String xformsFactoryLookup, String defaultPackageName) {

      this.xforms = xforms;
      this.defaultPackageName = defaultPackageName;
      this.xformsFactoryLookup = xformsFactoryLookup;
      if (xformsType.equals(SharkParamConsts.EA_XFORMS_FILE)
          || xformsType.equals(SharkParamConsts.EA_XFORMS_FILE_FOR_VARIABLES)) {
         this.xformsType = XFORMS_TYPE_FILE;
      } else if (xformsType.equals(SharkParamConsts.EA_XFORMS_XMLC_CLASS)
                 || xformsType.equals(SharkParamConsts.EA_XFORMS_XMLC_CLASS_FOR_VARIABLES)) {
         this.xformsType = XFORMS_TYPE_CLASS;
      } else if (xformsType.equals(SharkParamConsts.EA_XFORMS_EMBEDED)
                 || xformsType.equals(SharkParamConsts.EA_XFORMS_EMBEDED_FOR_VARIABLES)) {
         this.xformsType = XFORMS_TYPE_EMBEDED;
      }
   }

   public Node getXHTML(HttpPresentationComms myComms) throws Exception {
      // System.out.println("XFORMSGEN, CLASSIFIEDVARS="+list);
      Document xformsNode = getXFormsDocument(null, myComms);
      return generateXForms(null, xformsNode);

   }

   public Node getXHTML(Node node) throws Exception {

      Document xformsNode = getXFormsDocument(defaultPackageName, null);// default
      // from
      // file=true
      return generateXForms(node, xformsNode);

   }

   protected Document getXFormsDocument(String packagename, HttpPresentationComms myComms) throws Exception {
      Document ret = null;

      if (xformsType == XFormsGenerator.XFORMS_TYPE_FILE) {

         xff = (XFormsFactory) new InitialContext().lookup(xformsFactoryLookup);
         String pkgName = null;

         if (packagename == null) {
            WMEntity procEnt = SharkInterfaceWrapper.getAdminMisc()
               .getProcessDefinitionInfo(SharkInterfaceWrapper.getSessionHandle(username),
                                         procId);
            pkgName = SharkInterfaceWrapper.getPackageAdministration()
               .getPackageEntity(SharkInterfaceWrapper.getSessionHandle(username),
                                 procEnt.getPkgId(),
                                 procEnt.getPkgVer())
               .getName();
         } else {
            pkgName = packagename;
         }
         ret = xff.getXForm(pkgName, xforms);

      } else if (xformsType == XFormsGenerator.XFORMS_TYPE_CLASS) {
         ret = (Document) myComms.xmlcFactory.create(xforms); 
      } else if (xformsType == XFormsGenerator.XFORMS_TYPE_EMBEDED) {
         ret = (Document) xformsEmbededStringToDocument.get(xforms);
         if (ret == null) {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            ret = dbf.newDocumentBuilder()
               .parse(new InputSource(new StringReader(xforms)));
            xformsEmbededStringToDocument.put(xforms, ret);
            if (xformsEmbededStringToDocument.size() % 10 == 0) {
               Log.log("The size of XForms Embeded String->Document map is "
                       + xformsEmbededStringToDocument.size());
            }
         }
         ret = (Document) ret.cloneNode(true);
      }

      return ret;
   }

   private Node generateXForms(Node node, Document xformsNode) throws Exception {
      if (xformsNode != null) {
         NodeList nl = xformsNode.getElementsByTagName("xforms:instance");
         if (nl == null || nl.getLength() == 0) {
            return null;
         }
         Node xFormsInstance = null;
         if (nl.getLength() > 0) {
            xFormsInstance = nl.item(0);
         }
         Node xpilMockupNode = xFormsInstance.getFirstChild().getNextSibling();

         Node xpilNode = null;
         if (node == null) {
            WMSessionHandle shandle = SharkInterfaceWrapper.getSessionHandle(username);
            if (actId == null) {
               xpilNode = SharkInterfaceWrapper.getXPILHandler()
                  .getProcessVariablesForMockupNode(shandle,
                                                    xpilMockupNode,
                                                    procId,
                                                    new Properties());
            } else {
               xpilNode = SharkInterfaceWrapper.getXPILHandler()
                  .getActivityVariablesForMockupNode(shandle,
                                                     xpilMockupNode,
                                                     procId,
                                                     actId,
                                                     new Properties());
            }
         } else {
            xpilNode = node;
         }
         try {
            XObject xo = XPathAPI.eval(xFormsInstance,
                                       "//xpil:ExtendedWorkflowFacilityInstance/xpil:InstanceExtendedAttribute[@Name='"
                                             + SharkParamConsts.EA_HTML_VARIABLE
                                             + "']/@Value");
            htmlVariableName = xo.str();

         } catch (Exception e) {
            // TODO: handle exception
         }
         Node newNode = xformsNode.importNode(xpilNode.getFirstChild(), true);
         xFormsInstance.replaceChild(newNode, xpilMockupNode);

         if (nl.getLength() > 1) {// case when WebRowSet is in use
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);

            for (int i = 1; i < nl.getLength(); i++) {
               Element xFormsInstance1 = (Element) nl.item(i);
               Node n = xFormsInstance1.getFirstChild().getNextSibling();

               if (n == null
                   || (!"wrs:webRowSet".equalsIgnoreCase(n.getNodeName()) && !"webRowSet".equalsIgnoreCase(n.getNodeName()))) {
                  continue;
               }
               // Writer sw = readWebRowSet(xFormsInstance,
               // xFormsInstance1);
               StringWriter sw = new StringWriter();
               xff.readWebRowSet(xFormsInstance,
                                 xFormsInstance1,
                                 sw,
                                 getClass().getClassLoader());
               if (null != sw) {
                  dbf.setNamespaceAware(false);
                  Document doc = dbf.newDocumentBuilder()
                     .parse(new InputSource(new StringReader(sw.toString())));
                  Node fc = doc.getFirstChild();

                  xFormsInstance1.replaceChild(xformsNode.importNode(fc, true),
                                               xFormsInstance1.getFirstChild()
                                                  .getNextSibling());
               }
            }
         }
      }

      return xformsNode;
   }

   public Node getEmbedingNode() {
      if (null != htmlVariableName && htmlVariableName.length() > 0) {
         try {
            WfActivity act = SharkInterfaceWrapper.getSharkConnection(this.username)
               .getActivity(this.procId, this.actId);
            Map vars = act.process_context();
            Object ht = vars.get(htmlVariableName);
            if (ht instanceof byte[]) {
               Transformer t = TransformerFactory.newInstance().newTransformer();
               Document h = DocumentBuilderFactory.newInstance()
                  .newDocumentBuilder()
                  .newDocument();
               Result targ = new DOMResult(h);
               t.transform(new StreamSource(new ByteArrayInputStream((byte[]) ht)), targ);

               return h;
            }
         } catch (Exception e) {
         }
      }
      return null;
   }
}

package org.enhydra.shark.api;

import java.io.PrintStream;
import java.io.PrintWriter;

/**
 * This exception is base for all exceptions defined in Shark. It
 * allows implementation of chain exceptions, and this implementation
 * takes care if JDK1.3 or JDK1.4 is used.
 *
 * @author Vladimir Puskas
 */
public class RootException extends Exception {
   
   private Throwable cause;
   
   /**
    * Constructs a new exception with null as its detail message.
    *
    */
   public RootException() {
      super();
   }
   /**
    * Constructs a new exception with the specified detail message.
    *
    * @param message the detail message.
    *
    */
   public RootException(String message) {
      super(message);
   }
   
   /**
    * Constructs a new exception with the specified cause.
    *
    * @param  t the cause. A null value is permitted, and indicates that
    * the cause is nonexistent or unknown.
    *
    */
   public RootException(Throwable t) {
      super(t.getMessage());
      try {
         initCause(t);
      } catch (Throwable e) {}
   }
   
   /**
    * Constructs a new exception with the specified detail message and cause.
    *
    * @param message the detail message.
    * @param  t the cause. A null value is permitted, and indicates that
    * the cause is nonexistent or unknown.
    */
   public RootException(String message, Throwable t) {
      super(message);
      try {
         initCause(t);
      } catch (Throwable e) {}
   }
   
   /**
    * Initializes the cause of this exception to the specified value.
    *
    * @param t the cause.
    *
    * @return a reference to this instance.
    *
    * @exception   IllegalArgumentException
    * @exception   IllegalStateException
    */
   public Throwable initCause(Throwable t) throws IllegalArgumentException, IllegalStateException {
      cause = t;
      return this;
   }
   
   
   /**
    * Returns the cause of this exception.
    *
    * @return   a cause for this exception if any, null otherwise
    *
    */
   public Throwable getCause() {
      return cause;
   }
   
   /**
    * Method printStackTrace prints the stack trace to the <i>ps</i> PrintStream.
    *
    * @param ps PrintStream used for the output.
    */
   public void printStackTrace(PrintStream ps) {
      if (null != cause) {
         cause.printStackTrace(ps);
      }
      super.printStackTrace(ps);
   }
   
   /**
    * Method printStackTrace prints the stack trace to the <i>pw</i> PrintWriter.
    *
    * @param pw PrintWriter used for the output.
    */
   public void printStackTrace(PrintWriter pw) {
      if (null != cause) {
         cause.printStackTrace(pw);
      }
      super.printStackTrace(pw);
   }
   /**
    * Method printStackTrace prints the stack trace to the standard error stream.
    */
   public void printStackTrace() {
      printStackTrace(System.err);
   }
}

package org.enhydra.shark.api;

import java.io.PrintStream;
import java.io.PrintWriter;

/**
 * This Error allows implementation of chain exceptions, and this implementation
 * takes care if JDK1.3 or JDK1.4 is used.
 *
 * @author Vladimir Puskas
 * @author Sasa Bojanic
 */
public class RootError extends Error {

   private Throwable cause;

   /**
    * Constructs a new exception with null as its detail message.
    *
    */
   public RootError() {
      super();
   }
   /**
      }
      sc.disconnect();
   }

   public static List findRunningActivities(WfProcess proc) throws Exception {
      WfActivity[] acts = proc.get_sequence_step(0);
      List actL = new ArrayList();
      for (int i = 0; i < acts.length; i++) {
         if (acts[i].state().startsWith(SharkConstants.STATEPREFIX_OPEN)) {
            actL.add(acts[i]);
         }
      }
      return actL;
   }
   
   public static String getRunningActivityId(String username, String procId)
      throws Exception {
      SharkConnection sc = SharkInterfaceWrapper.getSharkConnection(username);
      if (sharkEdition.equals(SharkParamConsts.SHARK_EDITION_COMMUNITY)) {
         List l=findRunningActivities(sc.getProcess(procId));
         if (l.size() > 1) {
            throw new Exception("More than 1 running activity in process " + procId);
         }
         if (l.size()>0) {
            return ((WfActivity)l.get(0)).key();
         }
      } else {
         WMActivityInstanceIterator wmai = SharkInterfaceWrapper.getAdminMiscExt()
            .getRunningActivities(sc.getSessionHandle(), procId, true);
         if (wmai.getCount() > 1) {
            throw new Exception("More than 1 running activity in process " + procId);
         }
         if (wmai.hasNext()) {
            return ((WMActivityInstance) wmai.next()).getId();
         }
      }
      return null;
   }

   public static byte[] transformNodeToByteArray (Node n) throws Exception {
      TransformerFactory tFactory = TransformerFactory.newInstance();
      Transformer transformer = tFactory.newTransformer();
      DOMSource source = new DOMSource(n);
      ByteArrayOutputStream bas = new ByteArrayOutputStream();
      StreamResult result = new StreamResult(bas);
      transformer.transform(source, result);
      return bas.toByteArray();
   }
      
}
            String[] ret = new String[2];
            ret[0] = eaName;
            ret[1] = extAttribs[i][1];
            sc.disconnect();
            return ret;
         }
      }
      String[] ret = new String[2];
      ret[0] = null;
      ret[1] = null;

      sc.disconnect();
      return ret;
   }

   /**
    * Completes current activity and return process Id
    */
   public static void goPrevious(String username, String procId, String actId, Map vars)
      throws Exception {
      SharkConnection sc = SharkInterfaceWrapper.getSharkConnection(username);
      filterNonExistingNullVars(vars, sc.getProcess(procId).process_context());
      SharkInterfaceWrapper.getExecutionAdministrationExt()
         .goPrevious(sc.getSessionHandle(), procId, actId, MiscClientUtilities.makeWMAttributeArrayContext(vars));
      sc.disconnect();

   }

   public static void goBack(String username, String procId, String actId, Map vars)
      throws Exception {
      SharkConnection sc = SharkInterfaceWrapper.getSharkConnection(username);
      filterNonExistingNullVars(vars, sc.getProcess(procId).process_context());

      String actDefId = null;
      if (actId != null) {
         WMEntity actDef = SharkInterfaceWrapper.getAdminMisc()
            .getActivityDefinitionInfo(sc.getSessionHandle(), procId, actId);
         actDefId = WMEntityUtilities.findEAAndGetValue(sc.getSessionHandle(),
                                                        SharkInterfaceWrapper.getXPDLBrowser(),
                                                        actDef,
                                                        SharkParamConsts.EA_BACK_ACTIVITY_DEFINITION);
      }
      if (actDefId != null && !actDefId.trim().equals("")) {
         SharkInterfaceWrapper.getExecutionAdministrationExt()
            .goAnywhere(sc.getSessionHandle(), procId, actId, actDefId, MiscClientUtilities.makeWMAttributeArrayContext(vars));
      } else {
         SharkInterfaceWrapper.getExecutionAdministrationExt()
            .goBack(sc.getSessionHandle(), procId, true, MiscClientUtilities.makeWMAttributeArrayContext(vars));
