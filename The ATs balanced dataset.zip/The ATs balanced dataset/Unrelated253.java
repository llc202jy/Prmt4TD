/*  -------------------------------------------------------------

    Rossum's Playhouse  --  a client/server based robot simulator
    Rossum's Playhouse is also known under the name "RP1".
    Copyright (C) 1999  G.W. Lucas

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

----------------------------------------------------------------- */




/*
   The present implementation does not test to see whether the contructor
   parameters are valid specifications.


   Some Names and Meanings of Variables
      (xDetector, yDetector)
         Coordinates of standard reference (unmapped) position
         of sensor relative to the robot's coordinate system.
         A mapped position (see mappedPos below) will be computed
         to reflect robot position and orientation.

      mappedPos
         an RsPoint giving the mapped position of the sensor the last time
         the computeAndSetState() method was invoked

      (vx, vy)
         unit vector giving central axis of the sensor the last time the
         computeAndSetState() method was invoked

       hot
         boolean indicating if there was a detection the last time the
         computeAndSetState() method was invoked.


       range
         range to the detection point, measured along the central axis.
         This value is defined if and only if there is a detection (hot==true)


      stateChange
         indicates that the last call to computeAndSetState resulted in
         a change of sensor status.


*/


package rp1.rossum;

import rp1.rossum.event.*;

import java.awt.Color;
import java.lang.Math;



/**
 * The sensor for measuring distance to objects.
 *
 */

public class RsBodyRangeSensor extends RsBodySensor {

   private static final long serialVersionUID = 1L;

   // elements which describe the sensor

