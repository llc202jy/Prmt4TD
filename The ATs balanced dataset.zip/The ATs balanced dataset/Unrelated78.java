package org.esfinge.config;

import java.io.Serializable;
import java.sql.Connection;

import org.hibernate.CacheMode;
import org.hibernate.Criteria;
import org.hibernate.EntityMode;
import org.hibernate.Filter;
import org.hibernate.FlushMode;
import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.ReplicationMode;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.stat.SessionStatistics;

public class SessionProxy implements Session{
	
	private Session session;
	
	public SessionProxy(Session session) {
		this.session = session;
	}

	public Transaction beginTransaction() throws HibernateException {
		return session.beginTransaction();
	}

	public void cancelQuery() throws HibernateException {
		session.cancelQuery();
	}

	public void clear() {
		session.clear();
	}

	public Connection close() throws HibernateException {
		session.flush();
		return null;
	}

	public Connection connection() throws HibernateException {
		return session.connection();
	}

	public boolean contains(Object object) {
		return session.contains(object);
	}

	public Criteria createCriteria(Class persistentClass, String alias) {
		return session.createCriteria(persistentClass, alias);
	}

	public Criteria createCriteria(Class persistentClass) {
		return session.createCriteria(persistentClass);
	}

	public Criteria createCriteria(String entityName, String alias) {
		return session.createCriteria(entityName, alias);
	}

	public Criteria createCriteria(String entityName) {
		return session.createCriteria(entityName);
	}

	public Query createFilter(Object collection, String queryString) throws HibernateException {
		return session.createFilter(collection, queryString);
	}

	public Query createQuery(String queryString) throws HibernateException {
		return session.createQuery(queryString);
	}

	public SQLQuery createSQLQuery(String queryString) throws HibernateException {
		return session.createSQLQuery(queryString);
	}

	public void delete(Object object) throws HibernateException {
		session.delete(object);
	}

	public void delete(String entityName, Object object) throws HibernateException {
		session.delete(entityName, object);
	}

	public void disableFilter(String filterName) {
		session.disableFilter(filterName);
	}

	public Connection disconnect() throws HibernateException {
		return session.disconnect();
	}

	public Filter enableFilter(String filterName) {
		return session.enableFilter(filterName);
	}

	public void evict(Object object) throws HibernateException {
		session.evict(object);
	}

	public void flush() throws HibernateException {
		session.flush();
	}

	public Object get(Class clazz, Serializable id, LockMode lockMode) throws HibernateException {
		return session.get(clazz, id, lockMode);
	}

	public Object get(Class clazz, Serializable id) throws HibernateException {
		return session.get(clazz, id);
	}

	public Object get(String entityName, Serializable id, LockMode lockMode) throws HibernateException {
		return session.get(entityName, id, lockMode);
	}

	public Object get(String entityName, Serializable id) throws HibernateException {
		return session.get(entityName, id);
	}

	public CacheMode getCacheMode() {
		return session.getCacheMode();
	}

	public LockMode getCurrentLockMode(Object object) throws HibernateException {
		return session.getCurrentLockMode(object);
	}

	public Filter getEnabledFilter(String filterName) {
		return session.getEnabledFilter(filterName);
	}

	public EntityMode getEntityMode() {
		return session.getEntityMode();
	}

	public String getEntityName(Object object) throws HibernateException {
		return session.getEntityName(object);
	}

	public FlushMode getFlushMode() {
		return session.getFlushMode();
	}

	public Serializable getIdentifier(Object object) throws HibernateException {
		return session.getIdentifier(object);
	}

	public Query getNamedQuery(String queryName) throws HibernateException {
		return session.getNamedQuery(queryName);
	}

	public Session getSession(EntityMode entityMode) {
		return session.getSession(entityMode);
	}

	public SessionFactory getSessionFactory() {
		return session.getSessionFactory();
	}

	public SessionStatistics getStatistics() {
		return session.getStatistics();
	}

	public Transaction getTransaction() {
		return session.getTransaction();
	}

	public boolean isConnected() {
		return session.isConnected();
	}

	public boolean isDirty() throws HibernateException {
		return session.isDirty();
	}

	public boolean isOpen() {
		return session.isOpen();
	}

	public Object load(Class theClass, Serializable id, LockMode lockMode) throws HibernateException {
		return session.load(theClass, id, lockMode);
	}

	public Object load(Class theClass, Serializable id) throws HibernateException {
		return session.load(theClass, id);
	}

	public void load(Object object, Serializable id) throws HibernateException {
		session.load(object, id);
	}

	public Object load(String entityName, Serializable id, LockMode lockMode) throws HibernateException {
		return session.load(entityName, id, lockMode);
	}

	public Object load(String entityName, Serializable id) throws HibernateException {
		return session.load(entityName, id);
	}

	public void lock(Object object, LockMode lockMode) throws HibernateException {
		session.lock(object, lockMode);
	}
