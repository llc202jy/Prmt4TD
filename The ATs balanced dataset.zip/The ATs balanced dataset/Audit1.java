package org.jfolder.security.audit;

//base classes

//project specific classes

//other classes

public class SecurityAuditQuery {
    
    protected SecurityAuditQuery() {
    }
}
import org.jfolder.security.model.UserIdentity;

//other classes

public class SecurityAuditHelper {
    
    //
    public final static String SECURITY_AUDIT_SEPARATOR = "|";
    public final static String SECURITY_AUDIT_TYPE_START = "[";
    public final static String SECURITY_AUDIT_TYPE_END = "]";
    public final static String SECURITY_AUDIT_TYPE_NAME_VALUE_JUNCTION = "=";
    
    //
    public final static BigDecimal INITIAL_ID = new BigDecimal(1);
    //
    public final static BigDecimal STADARD_CUSTOM_CODE = new BigDecimal(0);
    
    //
    public final static String SYSTEM__WORKFLOW_ENGINE = "WORKFLOW_ENGINE";
    public final static String SYSTEM__WEB_APPLICATION = "WEB_APPLICATION";
    public final static String SYSTEM__COMMAND_LINE = "COMMAND_LINE";
    
    //
    public final static String CATEGORY__DEPLOYMENT = "DEPLOYMENT";
    public final static String CATEGORY__TRANSPORT = "TRANSPORT";
    public final static String CATEGORY__GENERAL = "GENERAL";
    public final static String CATEGORY__EXECUTION = "EXECUTION";
    public final static String CATEGORY__DATABASE_ACCESS = "DATABASE_ACCESS";
    
    //
    public final static String SUB_CATEGORY__APPLICATION = "APPLICATION";
    
    //
    private SecurityAuditHelper() {
    }
    
    //
    public final static String SEVERITY_LEVEL__INFORMATION = "INFORMATION";
    public final static String SEVERITY_LEVEL__WARNING = "WARNING";
    public final static String SEVERITY_LEVEL__ERROR = "ERROR";
    //
    public final static BigDecimal SEVERITY_CODE__INFORMATION =
        new BigDecimal(1);
    public final static BigDecimal SEVERITY_CODE__WARNING = new BigDecimal(2);
    public final static BigDecimal SEVERITY_CODE__ERROR = new BigDecimal(3);
    
    //
    public final static ArrayList getCommonCategoryTypes() {
        
        ArrayList outValue = new ArrayList();
        
        return outValue;
    }
    public final static ArrayList getCommonSourceTypes() {
        
        ArrayList outValue = new ArrayList();
        
        return outValue;
    }
    
    
    //
    public final static ArrayList getSeverityLevels() {
        
        ArrayList outValue = new ArrayList();
        
        outValue.add(SEVERITY_LEVEL__INFORMATION);
        outValue.add(SEVERITY_LEVEL__WARNING);
        outValue.add(SEVERITY_LEVEL__ERROR);
        
        return outValue;
    }
    public final static ArrayList getSeverityCodesAsStrings() {
        
        ArrayList outValue = new ArrayList();
        
        outValue.add(SEVERITY_CODE__INFORMATION.toString());
        outValue.add(SEVERITY_CODE__WARNING.toString());
        outValue.add(SEVERITY_CODE__ERROR.toString());
        
        return outValue;
    }
    
    //
    public final static BigDecimal convertSeverityLevelToNumber(String inSl) {
        
        BigDecimal outValue = null;
        
        if (inSl.equals(SEVERITY_LEVEL__INFORMATION)) {
            outValue = SEVERITY_CODE__INFORMATION;
        }
        else if (inSl.equals(SEVERITY_LEVEL__WARNING)) {
            outValue = SEVERITY_CODE__WARNING;
        }
        else if (inSl.equals(SEVERITY_LEVEL__ERROR)) {
            outValue = SEVERITY_CODE__ERROR;
        }
        else {
            throw new UnexpectedSystemException(
                "Severity Level '" + inSl + "' Is Unknown");
        }
        
        return outValue;
    }
    public final static String convertNumberToSeverityLevel(BigDecimal inSl) {
        
        String outValue = null;
        
        if (inSl.compareTo(SEVERITY_CODE__INFORMATION) == 0) {
            outValue = SEVERITY_LEVEL__INFORMATION;
        }
        else if (inSl.compareTo(SEVERITY_CODE__WARNING) == 0) {
            outValue = SEVERITY_LEVEL__WARNING;
        }
        else if (inSl.compareTo(SEVERITY_CODE__ERROR) == 0) {
            outValue = SEVERITY_LEVEL__ERROR;
        }
        else {
            throw new UnexpectedSystemException(
                "Severity Level '" + inSl + "' Is Unknown");
        }
        
        return outValue;
    }
    
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    public final static HashMap convertStringToAuditType(String inValue) {
        
        HashMap outValue = new HashMap();
        
        String origValue = inValue;
        
        while (inValue.length() > 0) {
            if (inValue.startsWith(SECURITY_AUDIT_TYPE_START)
                && inValue.endsWith(SECURITY_AUDIT_TYPE_END)) {
                //
                int endIndex = inValue.indexOf(SECURITY_AUDIT_TYPE_END);
                //
                String nextPart = inValue.substring(
                    SECURITY_AUDIT_TYPE_END.length(), endIndex);
                inValue = inValue.substring(
                    endIndex + SECURITY_AUDIT_TYPE_END.length());
                //
                int junctionIndex = nextPart.indexOf(
                    SECURITY_AUDIT_TYPE_NAME_VALUE_JUNCTION);
                if (junctionIndex != -1) {
                    //
                    String nextName = nextPart.substring(0, junctionIndex);
                    String nextValue = nextPart.substring(
                        junctionIndex
                            + SECURITY_AUDIT_TYPE_NAME_VALUE_JUNCTION.length());
                    //
                    nextName = nextName.toUpperCase();
                    //
                    if (!outValue.containsKey(nextName)) {
                        validateType(nextName, nextValue);
                        outValue.put(nextName, nextValue);
                    }
                    else {
                        throw new UnexpectedSystemException(
                            "Name '" + nextName + "' in value '" + origValue
                                + "' appears more than once");
                    }
                }
                else {
                    throw new UnexpectedSystemException(
                        "Element '" + nextPart + "' in value '" + origValue
                            + "' does not contain junction '"
                            + SECURITY_AUDIT_TYPE_NAME_VALUE_JUNCTION + "'");
                }
            }
            else {
                throw new UnexpectedSystemException("Value + '" + inValue
                    + "' must start with '" + SECURITY_AUDIT_TYPE_START
                    + "' and end with '" + SECURITY_AUDIT_TYPE_END + "'");
            }
        }
        
        return outValue;
    }
    //
    public final static String convertAuditTypeToString(HashMap inValue) {
        
        StringBuffer outValue = new StringBuffer();
        
        ArrayList names = new ArrayList(inValue.keySet());
        Collections.sort(names);
        //
        for (int i = 0; i < names.size(); i++) {
            String nextName = names.get(i).toString();
            nextName = nextName.toUpperCase();
            names.remove(i);
            names.add(i, nextName);
        }
        //
        for (int i = 0; i < names.size(); i++) {
            String nextName = names.get(i).toString();
            String nextValue = inValue.get(nextName).toString();
            //
            validateType(nextName, nextValue);
            //
            outValue.append(SECURITY_AUDIT_TYPE_START);
            outValue.append(nextName);
            outValue.append(SECURITY_AUDIT_TYPE_NAME_VALUE_JUNCTION);
            outValue.append(nextValue);
            outValue.append(SECURITY_AUDIT_TYPE_END);
        }
        
        return outValue.toString();
    }
    //
    public final static void validateType(
        String inName, String inValue, ArrayList inErrors, String inSection) {
        
        String parts[] = new String[]{inName, inValue};
        for (int i = 0; i < parts.length; i++) {
            String nextPart = parts[i];
            //
            if (nextPart.indexOf(
                SECURITY_AUDIT_TYPE_NAME_VALUE_JUNCTION) != -1) {
                //
                inErrors.add(
                    inSection + "Name '" + inName + "' and Value '" + inValue
                        + "' contains forbidden character '"
                        + SECURITY_AUDIT_TYPE_NAME_VALUE_JUNCTION + "'");
            }
            else if (nextPart.indexOf(SECURITY_AUDIT_TYPE_START) != -1) {
                //
                inErrors.add(
                    inSection + "Name '" + inName + "' and Value '" + inValue
                        + "' contains forbidden character '"
                        + SECURITY_AUDIT_TYPE_START + "'");
            }
            else if (nextPart.indexOf(SECURITY_AUDIT_TYPE_END) != -1) {
                //
                inErrors.add(
                    inSection + "Name '" + inName + "' and Value '" + inValue
                        + "' contains forbidden character '"
                        + SECURITY_AUDIT_TYPE_END + "'");
            }
            else {
                //
            }
        }
public class SecurityAuditSet {
    
    private ArrayList ids = null;
    private ArrayList audits = null;
    
    private SecurityAuditSet() {
        this.ids = new ArrayList();
        this.audits = new ArrayList();
    }
    
    public final static SecurityAuditSet newInstance() {
        return new SecurityAuditSet();
    }
    
    public void addSecurityAudit(BigDecimal inId, SecurityAudit inSa) {
        this.ids.add(inId);
        this.audits.add(inSa);
    }
    public int getSecurityAuditCount() {
        return this.audits.size();
    }
    public SecurityAudit getSecurityAudit(int inIndex) {
        
        SecurityAudit outValue = null;
        
        outValue = (SecurityAudit)this.audits.get(inIndex);
        
        return outValue;
    }
    public BigDecimal getId(int inIndex) {
        
        BigDecimal outValue = null;
        
        outValue = (BigDecimal)this.ids.get(inIndex);
        
        return outValue;
    }
}
ublic class SimpleSecurityAudit extends BaseSecurityAudit {
    
    //
    //private UserIdentity auditUser = null;
    //private int auditCode = 0;
    //private String auditComment = null;
    //private String auditStatus = null;
    //private long auditTimestamp = 0;
    ////private boolean initialized = false;
    //
    ////private boolean auditFaultPresent = false;
    //private String auditFaultMessage = null;
    //private String auditFaultSource = null;
    //private boolean auditFaultPresent = false;
    
    //
    private UserIdentity auditUserIdentity = null;
    private BigDecimal auditSequenceNumber = null;
    private String auditMachineOfOrigin = null;
    private String auditDateTime = null;
    private String auditSeverityLevel = null;
    private HashMap auditCategoryType = null;
    private HashMap auditSourceType = null;
    private String auditServerVersion = null;
    //
    private BigDecimal auditCustomCode = null;
    private HashMap auditCustomCategoryType = null;
    private HashMap auditCustomSourceType = null;
    private String auditCustomMessage = null;
    //
    private boolean auditOpened = false;
    
    protected SimpleSecurityAudit() {
        super();
    }
    
    protected SimpleSecurityAudit(UserIdentity inUi, BigDecimal inSeqNum,
        String inMachineOfOrig, String inDateTime, String inSeverityLevel,
        HashMap inCategoryType, HashMap inSourceType, String inServerVersion,
        BigDecimal inCustomCode, HashMap inCustomCategoryType,
        HashMap inCustomSourceType, String inCustomMessage,
        boolean inOpened) {
        
        //
        //if (!inUser.isValid()) {
        //    throw new UnexpectedSystemException("Invalid user - " + inUser);
        //}
        
        //
        setAuditUserIdentity(inUi);
        setAuditSequenceNumber(inSeqNum);
        setAuditMachineOfOrigin(inMachineOfOrig);
        setAuditDateTime(inDateTime);
        setAuditSeverityLevel(inSeverityLevel);
        setAuditCategoryType(inCategoryType);
        setAuditSourceType(inSourceType);
        setAuditServerVersion(inServerVersion);
        //
        setAuditCustomCode(inCustomCode);
        setAuditCustomCategoryType(inCustomCategoryType);
        setAuditCustomSourceType(inCustomSourceType);
        setAuditCustomMessage(inCustomMessage);
        //
        setAuditOpened(inOpened);
        //this.auditUser = inUser;
        //this.auditCode = inCode;
        //this.auditComment = inComment;
        //this.auditStatus = inStatus;
        //this.auditTimestamp = inTimestamp;
        
        //
        //this.auditFaultMessage = inFaultMessage;
        //this.auditFaultSource = inFaultSource;
        //this.auditFaultPresent = inFaultPresent;
    }
    
    public final static SimpleSecurityAudit newInstance(
        UserIdentity inUi, BigDecimal inSeqNum, String inMachineOfOrig,
        String inDateTime, String inSeverityLevel, HashMap inCategoryType,
        HashMap inSourceType, String inServerVersion, BigDecimal inCustomCode,
        HashMap inCustomCategoryType, HashMap inCustomSourceType,
        String inCustomMessage, boolean inOpened) {
        
        SimpleSecurityAudit outValue = null;
        
        outValue = new SimpleSecurityAudit(
            inUi, inSeqNum, inMachineOfOrig, inDateTime, inSeverityLevel,
            inCategoryType, inSourceType, inServerVersion, inCustomCode,
            inCustomCategoryType, inCustomSourceType, inCustomMessage,
            inOpened);
        
        return outValue;
    }
    
    protected SimpleSecurityAudit(SecurityAudit inSa) {
        refreshSecurityAudit(inSa);
    }
    
    //
    public boolean isAuditUserIdentityPresent() {
        return (this.auditUserIdentity != null);
    }
    public UserIdentity getAuditUserIdentity() {
        return this.auditUserIdentity;
    }
    public BigDecimal getAuditSequenceNumber() {
        return this.auditSequenceNumber;
    }
    public String getAuditMachineOfOrigin() {
        return this.auditMachineOfOrigin;
    }
    public String getAuditDateTime() {
        return this.auditDateTime;
    }
    public String getAuditSeverityLevel() {
        return this.auditSeverityLevel;
    }
    public HashMap getAuditCategoryType() {
        return this.auditCategoryType;
    }
    public HashMap getAuditSourceType() {
        return this.auditSourceType;
    }
    public String getAuditServerVersion() {
        return this.auditServerVersion;
    }
    //
    public BigDecimal getAuditCustomCode() {
        return this.auditCustomCode;
    }
    public HashMap getAuditCustomCategoryType() {
        return this.auditCustomCategoryType;
    }
    public HashMap getAuditCustomSourceType() {
        return this.auditCustomSourceType;
    }
    public String getAuditCustomMessage() {
        return this.auditCustomMessage;
    }
    //
    public boolean isAuditOpened() {
        return this.auditOpened;
    }
    
    
    //
    protected void setAuditUserIdentity(UserIdentity inUi) {
        this.auditUserIdentity = inUi;
    }
    protected void setAuditSequenceNumber(BigDecimal inSeqNum) {
        this.auditSequenceNumber = inSeqNum;
    }
    protected void setAuditMachineOfOrigin(String inMachineOfOrig) {
        this.auditMachineOfOrigin = inMachineOfOrig;
    }
    protected void setAuditDateTime(String inDateTime) {
        this.auditDateTime = inDateTime;
    }
    protected void setAuditSeverityLevel(String inSeverityLevel) {
        this.auditSeverityLevel = inSeverityLevel;
    }
    protected void setAuditCategoryType(HashMap inCategoryType) {
        this.auditCategoryType = inCategoryType;
    }
    protected void setAuditSourceType(HashMap inSourceType) {
        this.auditSourceType = inSourceType;
    }
    protected void setAuditServerVersion(String inServerVersion) {
        this.auditServerVersion = inServerVersion;
    }
    //
    protected void setAuditCustomCode(BigDecimal inCustomCode) {
        this.auditCustomCode = inCustomCode;
    }
    protected void setAuditCustomCategoryType(HashMap inCategoryType) {
        this.auditCustomCategoryType = inCategoryType;
    }
    protected void setAuditCustomSourceType(HashMap inSourceType) {
        this.auditCustomSourceType = inSourceType;
    }
    protected void setAuditCustomMessage(String inCustomMessage) {
        this.auditCustomMessage = inCustomMessage;
    }
    //
    public void setAuditOpened(boolean inOpened) {
        this.auditOpened = inOpened;
    }
