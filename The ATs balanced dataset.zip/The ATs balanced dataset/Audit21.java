public partial class admin_faq_list : System.Web.UI.Page
{
    private SqlConnection conn = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["PSDConnectionString"].ToString());
    String redirect_page="home.aspx";
    SecurityModule security;
    LoginUserInfo userInfo;

    #region Events

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["security"] == null)
            {
                Response.Redirect(Common.sLoginPage);
                return;
            }
            Page.Title = "Public Service Division - FAQ List";
            //CHECK FOR SECURITY
            userInfo = (LoginUserInfo)Session["security"];
            security = userInfo.getModuleSecurity("FAQ Management");
            if (security == null)
                Response.Redirect(redirect_page);
            else
            {
                if (security.getView() == 0)
                    Response.Redirect(redirect_page);
                if (security.getAdd() == 0)
                    btnAdd.Visible = false;
                if (security.getExport() == 0)
                    btnExport.Visible = false;
            }

            if (!Page.IsPostBack)
            {
                this.Master.setHeader("setup");
                this.Master.setHeaderText("FAQ List");
                this.Master.setBreadcrumb("<img src='../images/white_arrow_2.jpg' width='10px' height='10px' /> FAQ");

                //bind grid
                string sGvRowCount = SqlDbClass.getGVRowCount().ToString();
                if (sGvRowCount.Trim() != "")
                    if (Common.isNumeric(sGvRowCount))
                        gvFaq.PageSize = int.Parse(sGvRowCount);
                string u_mcode = userInfo.getMcode();
                if (u_mcode == "PSD")
                    hdSelectCmd.Value = "SELECT faq_id AS Id, question,created FROM faq WHERE deleted=0  ORDER BY question";
                else
                    hdSelectCmd.Value = "SELECT faq_id AS Id, question,created FROM faq   LEFT OUTER JOIN [User] ON createdby=user_login_name WHERE deleted=0 AND user_mistry_code='" + u_mcode + "'   ORDER BY question";
                bindGrid();

                if (gvFaq.PageIndex == gvFaq.PageCount - 1)
                    setPagerBtn(false, false);
                else
                    setPagerBtn(false, true);

            }

            //show/hide search box
            divSearch.Attributes["style"] = "display:" + hdSearch.Value.Trim();
            if (hdSearch.Value.Trim() == "none")
                imgSearch.ImageUrl = "../images/down2.jpg";
            else
                imgSearch.ImageUrl = "../images/up2.jpg";
        }
        catch (Exception ex)
        {
            lblMsg.Text = "System cannot load the page successfully.";
        }
    }

    protected void Page_SaveStateComplete(object sender, EventArgs e)
    {
        try
        {
            GridViewRow gvr = gvFaq.HeaderRow;
            if (gvr != null)
            {

                for (int i = 0; i < gvFaq.Columns.Count; i++)
                {

                    DataControlField field = gvFaq.Columns[i];



                    Image img = new Image();

                    //e.Row.Cells[gvAuditTrail.Columns.IndexOf(field)].CssClass = "headerstyle";



                    if (field.SortExpression == gvFaq.SortExpression)
                    {

                        //iCellIndex = gvAuditTrail.Columns.IndexOf(field);

                        img.ID = i.ToString();

                        img.ImageUrl = gvFaq.SortDirection == SortDirection.Ascending ?

                            "../images/sort_asc.gif" : "../images/sort_desc.gif";

                        gvr.Cells[gvFaq.Columns.IndexOf(field)].Controls.AddAt(0, img);



                        //gvQuestion.Columns[gvQuestion.Columns.IndexOf(field)].HeaderStyle.CssClass = gvQuestion.SortDirection == SortDirection.Ascending ? "asc" : "desc";

                    }

                    else
                    {

                        img.ImageUrl = "../images/arrow_down.gif";

                        gvr.Cells[gvFaq.Columns.IndexOf(field)].Controls.AddAt(0, img);

                        //gvQuestion.Columns[gvQuestion.Columns.IndexOf(field)].HeaderStyle.CssClass = "sort";

                    }

                }
            }
        }
        catch (Exception ex)
        {
            //Insert into Audit Trail 
            string msg = ex.Message.Replace("'", "");
            SqlDbClass.insertAudit("View FAQ List", userInfo.getName(), userInfo.getLoginName(),
                "Error(" + msg + ") in viewing list of FAQ.");

            lblMsg.Text = "System cannot load the page successfully.";
            Common.MessageBox(lblMsg.Text, this);
        }

    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        Response.Redirect("faq_add.aspx");
    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        txtQues.Text = "";
        txtQues.Focus();
    }

    protected void gvFaq_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DateTime dt = DateTime.Parse(e.Row.Cells[1].Text);
                e.Row.Cells[1].Text = dt.ToString(SqlDbClass.getDTFormat().ToString());
                //foreach (Control ctrl in e.Row.Cells[0].Controls)
                //{
                //    if (ctrl is HyperLink)
                //    {
                //        if (security.getView() != 1)
                //            ((HyperLink)ctrl).NavigateUrl = "#";
                //    }
                //}
              }

            ////adding img for sorting
            //if (e.Row.RowType == DataControlRowType.Header)
            //{
            //    int iCellIndex = -1;

            //    for (int i = 0; i <gvFaq.Columns.Count; i++)
            //    {
            //        DataControlField field = gvFaq.Columns[i];

            //        Image img = new Image();
            //        //e.Row.Cells[gvAuditTrail.Columns.IndexOf(field)].CssClass = "headerstyle";

            //        if (field.SortExpression == gvFaq.SortExpression)
            //        {
            //            //iCellIndex = gvAuditTrail.Columns.IndexOf(field);

            //            img.ImageUrl = gvFaq.SortDirection == SortDirection.Ascending ?
            //                "../images/sort_asc.gif" : "../images/sort_desc.gif";
            //            e.Row.Cells[gvFaq.Columns.IndexOf(field)].Controls.AddAt(0, img);
            //        }
            //        else
            //        {
            //            img.ImageUrl = "../images/arrow_down.gif";
            //            e.Row.Cells[gvFaq.Columns.IndexOf(field)].Controls.AddAt(0, img);
            //        }
            //    }

            //    if (iCellIndex > -1)
            //    {
            //        //e.Row.Cells[iCellIndex].CssClass = gvAuditTrail.SortDirection == SortDirection.Ascending ?
            //        //"sortascheaderstyle" : "sortdescheaderstyle";

            //    }
            //}//end of if header

            if (e.Row.RowType == DataControlRowType.Footer)
            {

                //Show Current Row and All Row Count 
                showRowInfo();
            }

        }
        catch (Exception ex)
        {
            lblMsg.Text = "System produced an error in loading data as a list view.";
        }
    }

    protected void gvFaq_Sorting(object sender, GridViewSortEventArgs e)
    {
        try
        {
            //adding sort image to header
            Image img = new Image();
            if (e.SortDirection == SortDirection.Ascending)
            {
                img.ImageUrl = "../images/sort_arrowup.gif";
                img.AlternateText = "Ascending Order";
            }
            else
            {
                img.ImageUrl = "../images/sort_arrowdown.gif";
                img.AlternateText = "Decending Order";
            }

            setPagerBtn(false, true);
            showRowInfo();
            bindGrid();
        }
        catch (Exception ex)
        {
            lblMsg.Text = "System produced error in sorting the list.";
            Common.MessageBox(lblMsg.Text, this);
        }
    }

    protected void SqlDataSource1_Selected(object sender, SqlDataSourceStatusEventArgs e)
    {
        hdRowCount.Value = e.AffectedRows.ToString();
    }

    protected void lbtStart_Click(object sender, EventArgs e)
    {
        try
        {
            gvFaq.PageIndex = 0;
            bindGrid();

            //show row info
            showRowInfo();

            //setting the button
            setPagerBtn(false, true);
        }
        catch (Exception ex)
        {
            //Insert into Audit Trail 
            string msg = ex.Message.Replace("'", "");
            SqlDbClass.insertAudit("View FAQ List", userInfo.getName(), userInfo.getLoginName(),
                "Error(" + msg + ") in clicking the start button.");
            lblMsg.Text = "System produced error in going to start page.";
            Common.MessageBox(lblMsg.Text, this);
        }

    }

    protected void lbtPrevious_Click(object sender, EventArgs e)
    {
        try
        {
            if (gvFaq.PageIndex != 0)
                gvFaq.PageIndex = gvFaq.PageIndex - 1;

            //bind grid
            bindGrid();

            if (gvFaq.PageIndex == 0)
                setPagerBtn(false, true);
            else
                setPagerBtn(true, true);

            //show row info
            showRowInfo();
        }
        catch (Exception ex)
        {
            //Insert into Audit Trail 
            string msg = ex.Message.Replace("'", "");
            SqlDbClass.insertAudit("View FAQ List", userInfo.getName(), userInfo.getLoginName(),
                "Error(" + msg + ") in clicking the previous button.");
            lblMsg.Text = "System produced error in going to previous page.";
            Common.MessageBox(lblMsg.Text, this);
        }
    }

    protected void lbtNext_Click(object sender, EventArgs e)
    {
        try
        {
            if (gvFaq.PageIndex != (gvFaq.PageCount - 1))
                gvFaq.PageIndex = gvFaq.PageIndex + 1;

            bindGrid();

            if (gvFaq.PageIndex == gvFaq.PageCount - 1)
                setPagerBtn(true, false);
            else
                setPagerBtn(true, true);

            //show row info
            showRowInfo();
        }
        catch (Exception ex)
        {
            //Insert into Audit Trail 
            string msg = ex.Message.Replace("'", "");
            SqlDbClass.insertAudit("View FAQ List", userInfo.getName(), userInfo.getLoginName(),
                "Error(" + msg + ") in clicking the next button.");
            lblMsg.Text = "System produced error in going to next page.";
            Common.MessageBox(lblMsg.Text, this);
        }
    }

    protected void lbtEnd_Click(object sender, EventArgs e)
    {
        try
        {
            gvFaq.PageIndex = gvFaq.PageCount - 1;
            bindGrid();

            //setting the button
            setPagerBtn(true, false);

            //show row info
            showRowInfo();
        }
        catch (Exception ex)
        {
            //Insert into Audit Trail 
            string msg = ex.Message.Replace("'", "");
            SqlDbClass.insertAudit("View FAQ List", userInfo.getName(), userInfo.getLoginName(),
                "Error(" + msg + ") in clicking the end button.");
            lblMsg.Text = "System produced error in going to end page.";
            Common.MessageBox(lblMsg.Text, this);
        }

    }

     protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            string u_mcode = userInfo.getMcode();
            string ques = txtQues.Text.Trim();
            ques = ques.Replace("'", "''");
            if (u_mcode == "PSD")
            {
                hdSelectCmd.Value = "SELECT faq_id AS Id, question,created"
                       + " FROM faq WHERE deleted=0";
            }
            else
            {
                hdSelectCmd.Value = "SELECT faq_id AS Id, question,created FROM faq   LEFT OUTER JOIN [User] ON createdby=user_login_name WHERE deleted=0 AND user_mistry_code='" + u_mcode + "'";
            }
            if (txtQues.Text.Trim() != string.Empty && txtQues.Text.Trim() != null)
            {
                hdSelectCmd.Value += " AND question LIKE '%" + ques + "%'";
            }
            hdSelectCmd.Value += "  ORDER BY question";
            bindGrid();

            if (gvFaq.Rows.Count <= 0)
                lblMsg.Text = "No Record Found!";
            else
                lblMsg.Text = gvFaq.Rows.Count + " Record(s) Found!";
            gvFaq.PageIndex = 0;
            setPagerBtn(false, true);
            showRowInfo();
        }
        catch (Exception ex)
        {
            //Insert into Audit Trail 
            string msg = ex.Message.Replace("'", "");
            SqlDbClass.insertAudit("View FAQ List", userInfo.getName(), userInfo.getLoginName(),
                "Error(" + msg + ") in clicking the search button.");
            lblMsg.Text = "System produced error in searching.";
            Common.MessageBox(lblMsg.Text, this);
        }

    }

     protected void btnExport_Click(object sender, EventArgs e)
     {
         try
         {
             StringBuilder sb = new StringBuilder();
             string sFileName = "FaqList_" + DateTime.Today.ToString("ddMMyyyy");

             //Add Response header 
             Response.Clear();
             Response.AddHeader("content-disposition", string.Format("attachment;filename={0}.csv", sFileName));
             Response.Charset = "";
             Response.ContentType = "application/vnd.xls";

             //Add Header to Excel file            
             for (int i = 0; i < gvFaq.Columns.Count; i++)
             {
                 if (i != 0)
                     sb.Append(",");
                 sb.Append(gvFaq.Columns[i].HeaderText.Trim());
             }
             Response.Write(sb.ToString() + "\n");
             Response.Flush();

             //Add Data to Excel file
             //Reterive data from db in order to get all rows since Gridview only have rows for one page
             // if there are many pages in gridview
             DataSet ds = SqlDbClass.ExecuteDataSet(hdSelectCmd.Value.Trim());
             for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
             {
                 sb = new StringBuilder();
                 for (int j = 1; j < ds.Tables[0].Columns.Count; j++)
                 {
                     if (j != 1)
                         sb.Append(",");
                     if (j > 1)
                     {
                         if (ds.Tables[0].Rows[i][j].ToString() != "")
                         {
                             DateTime dt = DateTime.Parse(ds.Tables[0].Rows[i][j].ToString());
                             string sDt = dt.ToString(SqlDbClass.getDTFormat().ToString());
                             sb.Append(sDt);
                         }
                         sb.Append("");
                     }
                     else
                     {
                         Label lbl = new Label();
                         lbl.Text = ds.Tables[0].Rows[i][j].ToString();
                         sb.Append(lbl.Text);
                     }
                 }
                 Response.Write(sb.ToString() + "\n");
                 Response.Flush();
             }

           //  Response.Write(sb.ToString());
             Response.Flush();
             Response.End();
         }
         catch (Exception ex)
         {
             //Insert into Audit Trail 
             string msg = ex.Message.Replace("'", "");
             SqlDbClass.insertAudit("View FAQ List", userInfo.getName(), userInfo.getLoginName(),
                 "Error(" + msg + ") in clicking the export button.");
             lblMsg.Text = "System cannot export Excel file.";
             Common.MessageBox(lblMsg.Text, this);
         }
     }

     protected void btnExportAll_Click(object sender, EventArgs e)
     {
         try
         {
             string sQuery;
             StringBuilder sb = new StringBuilder();
             string sFileName = "FAQList_" + DateTime.Today.ToString("ddMMyyyy");

             //Add Response header 
             Response.Clear();
             string attachment = string.Format("attachment; filename={0}.csv", sFileName);
             Response.ClearContent();
             Response.AddHeader("content-disposition", attachment);
             Response.ContentType = "application/vnd.xls";

             sQuery = "SELECT [question],[answer],[from_date],[to_date],[createdby],[created]"
                     + " FROM [faq] WHERE [deleted] = 0 ORDER BY created DESC";

             //Add Header to Excel file 
             Response.Write("FAQ, Answer, From Date, To Date, Created By, Created" + "\n");
             Response.Flush();

             //Add Data to Excel file
             //Reterive data from db in order to get all rows since Gridview only have rows for one page
             // if there are many pages in gridview
             DataSet ds = SqlDbClass.ExecuteDataSet(sQuery);

             //Removing html tag and sort the question
             for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                 for (int j = 0; j < ds.Tables[0].Columns.Count; j++)
                 {
                     ds.Tables[0].Rows[i][j] = Common.removeHTMLTab(ds.Tables[0].Rows[i][j].ToString());
                     ds.Tables[0].Rows[i][j] = Common.escapeCsvField(ds.Tables[0].Rows[i][j].ToString());
                 }
             DataRow[] rows = ds.Tables[0].Select("question is NOT NULL", "question");


             for (int i = 0; i < rows.Length; i++)
             {
                 sb = new StringBuilder();
                 string tab = "";
                 for (int j = 0; j < ds.Tables[0].Columns.Count; j++)
                 {
                     string sData;
                     DateTime dt;

                     sData = rows[i][j].ToString();                    
                   
                     if (DateTime.TryParse(sData, out dt))
                     {
                         string sDt = dt.ToString(SqlDbClass.getDTFormat().ToString());
                         sb.Append(tab + sDt);
                     }
                     else
                     {                         
                         sb.Append(tab + sData);
                     }

                     tab = ",";
                 }
                 Response.Write(sb.ToString() + "\n");
                 Response.Flush();
             }

            
         }
         catch (Exception ex)
         {
             lblMsg.Text = "System cannot export Excel file.";
             Common.MessageBox(lblMsg.Text, this);
         }

         Response.Flush();
         Response.End();
     }

    #endregion

     #region User Defined Functions

     protected void bindGrid()
    {
        SqlDataSource1.SelectCommand = hdSelectCmd.Value;
        gvFaq.DataBind();
    }

    protected void showRowInfo()
    {
        //Show Current Row and All Row Count
        if (gvFaq.PageIndex == gvFaq.PageCount - 1)
        {           
            lblPage.Text = "(" + (1+(gvFaq.PageSize*gvFaq.PageIndex)) + " - " + hdRowCount.Value + " of " + hdRowCount.Value + ")";
            lblPage1.Text = lblPage.Text;
        }
        else
        {
            lblPage.Text = "(" + (1 + (gvFaq.PageSize * gvFaq.PageIndex)) + " - " + (gvFaq.PageSize * (gvFaq.PageIndex + 1)) + " of " + hdRowCount.Value + ")";
            lblPage1.Text = lblPage.Text;
        }
    }

    protected void setPagerBtn(bool blPrevious,bool blNext)
    {
        lbtPrevious.Enabled = blPrevious;
        lbtPrevious1.Enabled = blPrevious;
        lbtNext.Enabled = blNext;
        lbtNext1.Enabled = blNext;

    }

    #endregion


    
}public partial class admin_admin_my_acc : System.Web.UI.Page
{
    static bool candidate_exist = false;
    static string cand_id;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["security"] == null)
            {
                //Response.Redirect(Common.sLoginPage);
                Response.Redirect(Common.sLoginPage);

            }
            lblPwdError.Text = "";
            lblPwerror2.Text = "";

            if (!Page.IsPostBack)
            {
                lblMsg.Text = "";
                this.Master.setHeader("myaccount");
                this.Master.setBreadcrumb("<img src='../images/white_arrow_2.jpg' width='10px' height='10px' />&nbsp;My Account");
                loadCtrlData();
                loaddata();
                //page setting
                pnlInfoEdit.Visible = false;
                pnlChangePwd.Visible = false;

            }
        }
        catch (Exception ex)
        {
            lblViewMsg.Text = "System cannot load the page successfully.";
        }

    }

    private void loaddata()
    {

        LoginUserInfo userInfo = (LoginUserInfo)Session["security"];
        lblHeader1.Text = userInfo.getName() + "'s Personal Details";
        lblHeader2.Text = userInfo.getName() + "'s Personal Details Edit";
        double id = userInfo.getUserId();
        string userSql = @"SELECT [user_nric],[user_login_name],[user_name],[user_email],[ministry_name],[user_mistry_code]
                        ,[role_name],[user_createdby],[user_created],[user_modified], [user_last_login] 
                        ,[user_option1], [user_option2], [user_option3], [user_option4], [user_option5], [user_status] 
                        FROM [User],Ministry,Role WHERE user_mistry_code=ministry_code AND user_deleted=0"
                       + " AND user_role_id = role_id AND user_id = " + id;
        DataSet ds = SqlDbClass.ExecuteDataSet(userSql);
        if (ds.Tables[0].Rows.Count != 0)
        {
            lblName.Text = txtName.Text = lblName1.Text = ds.Tables[0].Rows[0]["user_name"].ToString();
            lblNric.Text = txtNric.Text = lblNric1.Text = ds.Tables[0].Rows[0]["user_nric"].ToString();
            lblLoginName.Text = txtLoginName.Text = ds.Tables[0].Rows[0]["user_login_name"].ToString();
            lblEmail.Text = txtEmail.Text = ds.Tables[0].Rows[0]["user_email"].ToString();
            lblRole.Text = txtRole.Text = ds.Tables[0].Rows[0]["role_name"].ToString();
            lblMinistry.Text = ds.Tables[0].Rows[0]["ministry_name"].ToString();
            ddlMinistry.Text = ds.Tables[0].Rows[0]["user_mistry_code"].ToString();
            lblOption1.Text = txtOption1.Text = ds.Tables[0].Rows[0]["user_option1"].ToString();
            lblOption2.Text = txtOption2.Text = ds.Tables[0].Rows[0]["user_option2"].ToString();
            lblOption3.Text = txtOption3.Text = ds.Tables[0].Rows[0]["user_option3"].ToString();
            lblOption4.Text = txtOption4.Text = ds.Tables[0].Rows[0]["user_option4"].ToString();
            lblOption5.Text = txtOption5.Text = ds.Tables[0].Rows[0]["user_option5"].ToString();
        }

        string selectSql = "SELECT cand_id, cand_name FROM [Candidate] WHERE cand_nric = '" + userInfo.getNric() + "' AND deleted=0";
        ds = SqlDbClass.ExecuteDataSet(selectSql);
        if (ds.Tables[0].Rows.Count != 0)
        {
            candidate_exist = true;
            cand_id = ds.Tables[0].Rows[0]["cand_id"].ToString();
            lblViewNotification.Text = userInfo.getName() + " has one more account as a candidate. System will update both admin user's and candidate's account information.";
            lblEditNotification.Text = userInfo.getName() + " has one more account as a candidate. System will update both admin user's and candidate's account information.";
        }
        else
        {
            candidate_exist = false;
            lblViewNotification.Text = "";
            lblEditNotification.Text = "";
        }

    }

    protected void loadCtrlData()
    {
        string query;
        DataSet ds;

        //Load data for ddlMinistry
        LoginUserInfo userInfo = (LoginUserInfo)Session["security"];
        string u_mcode = userInfo.getMcode();
        if (u_mcode == "PSD")
        {
            query = "SELECT ministry_name,ministry_code FROM Ministry WHERE ministry_code!='PSD' ORDER BY ministry_name ";
            ds = SqlDbClass.ExecuteDataSet(query);
            ddlMinistry.DataSource = ds.Tables[0];
            ddlMinistry.DataTextField = "ministry_name";
            ddlMinistry.DataValueField = "ministry_code";
            ddlMinistry.DataBind();
            ddlMinistry.Items.Insert(0, new ListItem("PSD (e-Test Admin)", "PSD"));
            ddlMinistry.Items.Insert(0, new ListItem("--Select--", "-1"));
        }
        else
        {
            query = "SELECT ministry_name,ministry_code FROM Ministry WHERE ministry_code='" + u_mcode + "'";
            ds = SqlDbClass.ExecuteDataSet(query);
            ddlMinistry.DataSource = ds.Tables[0];
            ddlMinistry.DataTextField = "ministry_name";
            ddlMinistry.DataValueField = "ministry_code";
            ddlMinistry.DataBind();
            ddlMinistry.Items.Insert(0, new ListItem("--Select--", "-1"));
        }
    }

    #region InfoView
    /** Events **/
    protected void lbtInfo_Click(object sender, EventArgs e)
    {
        showInfoView();
    }

    /** User Defined Functions **/

    public void showInfoView()
    {
        pnlInfoView.Visible = true;
        pnlInfoEdit.Visible = false;
        pnlChangePwd.Visible = false;
    }

    #endregion

    #region InfoEdit
    /** Events **/
    protected void btnInfoEdit_Click(object sender, EventArgs e)
    {
        try
        {
            this.Master.setBreadcrumb("<img src='../images/white_arrow_2.jpg' width='10px' height='10px' />&nbsp;"
                    + "<a class='active_a' href='admin_my_acc.aspx'>My Account</a>&nbsp;<img src='../images/white_arrow_2.jpg' width='10px' height='10px' />"
                    + "&nbsp;Edit Personal Details");

            lblMsg.Text = "";
            pnlInfoView.Visible = false;
            pnlInfoEdit.Visible = true;
            pnlChangePwd.Visible = false;
        }
        catch (Exception ex)
        {
            lblMsg.Text = "System cannot update data into the database.";
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        try
        {
            this.Master.setBreadcrumb("<img src='../images/white_arrow_2.jpg' width='10px' height='10px' />&nbsp;My Account");

            showInfoView();
        }
        catch (Exception ex)
        {
            lblMsg.Text = "System cannot do the requested task.";
        }
    }

    protected void btnInfoSave_Click(object sender, EventArgs e)
    {
        this.Master.setBreadcrumb("<img src='../images/white_arrow_2.jpg' width='10px' height='10px' />&nbsp;"
                + "<a class='active_a' href='my_account.aspx'>My Account</a>&nbsp;");

        LoginUserInfo userInfo = (LoginUserInfo)Session["security"];
        String sUserId = userInfo.getUserId().ToString();
        try
        {
            string query;
            string[] sParaName;
            object[] oParaValue;

            if (!checkValidation())
                return;


            //start transaction
            if (SqlDbClass.sqlTransConn.State == ConnectionState.Open)
                SqlDbClass.sqlTransConn.Close();
            SqlDbClass.sqlTransConn.Open();
            SqlDbClass.sqlTrans = SqlDbClass.sqlTransConn.BeginTransaction();


            //Update into User tabel
            query = "UPDATE [User] SET [user_nric]=@nric,[user_login_name] = @lname,[user_name]=@name,[user_email]=@email"
                  + ",[user_mistry_code]=@mcode,[user_modified]=@now"
                  + ",[user_option1]=@option1, [user_option2]=@option2, [user_option3]=@option3"
                  + ",[user_option4]=@option4, [user_option5]=@option5"
                  + " WHERE user_id = " + sUserId;
            sParaName = new string[] {"@nric","@lname","@name","@email","@mcode","@now",
                                      "@option1", "@option2", "@option3", "@option4", "@option5"};
            oParaValue = new object[11];

            oParaValue[0] = txtNric.Text.Trim().ToUpper();
            oParaValue[1] = txtNric.Text.Trim().ToUpper();
            oParaValue[2] = txtName.Text.Trim();
            oParaValue[3] = txtEmail.Text.Trim();
            oParaValue[4] = ddlMinistry.Text;
            oParaValue[5] = DateTime.Now;
            oParaValue[6] = txtOption1.Text.Trim();
            oParaValue[7] = txtOption2.Text.Trim();
            oParaValue[8] = txtOption3.Text.Trim();
            oParaValue[9] = txtOption4.Text.Trim();
            oParaValue[10] = txtOption5.Text.Trim();

            SqlDbClass.executeNonQueryWithTrans(query, sParaName, oParaValue);

            if (candidate_exist == true)
            {
                //Update into Candidate tabel
                query = @"UPDATE [Candidate] SET [cand_nric]=@nric,[cand_login_name]=@lname,[cand_name]=@name,[cand_email]=@email,[cand_mistry_code]=@mcode,[cand_modified]=@now"
                        + " WHERE cand_id = " + cand_id;
                sParaName = new string[] { "@nric", "@lname", "@name", "@email", "@mcode", "@now" };
                oParaValue = new object[6];

                oParaValue[0] = txtNric.Text.Trim().ToUpper();
                oParaValue[1] = txtNric.Text.Trim().ToUpper();
                oParaValue[2] = txtName.Text.Trim();
                oParaValue[3] = txtEmail.Text.Trim();
                oParaValue[4] = ddlMinistry.SelectedIndex == 0 ? DBNull.Value as object : ddlMinistry.Text as object;
                oParaValue[5] = DateTime.Now;
                SqlDbClass.executeNonQueryWithTrans(query, sParaName, oParaValue);

            }
            //Commit transaction
            SqlDbClass.sqlTrans.Commit();
            SqlDbClass.sqlTransConn.Close();
            
            //---------------------------------------Reset login information ------------------------------------//

            userInfo.setLoginName(txtNric.Text);
            userInfo.setName(txtName.Text);
            Session["security"] = userInfo;

            //---------------------------------------End of Rest userinfo -----------------------//*/


            //Insert into Audit Trail
            SqlDbClass.insertAudit("Edit User", userInfo.getName(), userInfo.getLoginName(),
                "Edit user:" + txtName.Text + "(Login Name:" + txtLoginName.Text + ")");
            Response.Write("<script>window.location='admin_my_acc.aspx';</script>");
        }
        catch (Exception ex)
        {

            //Rollback Transaction
            if (SqlDbClass.sqlTransConn.State == ConnectionState.Open)
            {
                SqlDbClass.sqlTrans.Rollback();
                SqlDbClass.sqlTransConn.Close();
            }
            //Insert into Audit Trail
            string msg = ex.Message.Replace("'", " ");
            SqlDbClass.insertAudit("Edit User", userInfo.getName(), userInfo.getLoginName(),
                "Error(" + msg + ") in editing user:" + txtName.Text + "(Login Name:" + txtLoginName.Text + ")");

            lblMsg.Text = "System cannot add the data into the database.";
            Common.MessageBox(lblMsg.Text, this);
        }

        Session["security"] = userInfo;
        Response.Redirect("admin_my_acc.aspx");
    }

    protected bool checkValidation()
    {
        string query;
        int iCount = 0;
        bool bValid = true;
        lblMsg.Text = "";
        string nric = txtNric.Text.ToUpper();
        //if (nric.Substring(0, 1).ToUpper() == "S" || nric.Substring(0, 1).ToUpper() == "T")
        //{
            bool isNric = Common.IsNricValid(nric);
            bool isFin = Common.IsFinValid(nric);
            if (isNric == false)// && isFin == false)
            {
                lblMsg.Text = "Invalid NRIC/FIN!<br/>";
                iCount++;
                bValid = false;
                txtNric.Focus();
            }
        //}

        //check for gov.sg domain
        string sEmail = txtEmail.Text.Trim().ToLower();
        string sDomain = sEmail.Substring(sEmail.Length - 6, 6);
        if (sDomain != "gov.sg")
        {
            lblMsg.Text += "*Please ensure the domain of your email address is .gov.sg.<br/>";
            iCount++;
            bValid = false;
            txtEmail.Focus();
        }
        LoginUserInfo userInfo = (LoginUserInfo)Session["security"];

        //check for duplicate NIRC
        query = "SELECT user_id FROM [User] WHERE {fn LCASE(user_nric)} = '"
              + txtNric.Text.Trim().ToLower() + "' AND user_id <> " + userInfo.getUserId();
        if (SqlDbClass.recordExists(query))
        {
            lblMsg.Text += "*NRIC number is already existed. Please try another one.<br/>";
            iCount++;
            bValid = false;
            txtNric.Focus();
        }

        if (iCount > 0)
            lblMsg.Height = iCount * 17;

        return bValid;
    }

    protected void lbtAddOptions_Click(object sender, EventArgs e)
    {
        try
        {
            pnlOption.Visible = !pnlOption.Visible;
            if (pnlOption.Visible)
                imgOptions.ImageUrl = "../images/up2.jpg";
            else
                imgOptions.ImageUrl = "../images/down2.jpg";
        }
        catch (Exception ex)
        {
            lblMsg.Text = "System cannot do your request successfully.";
        }
    }


    /** User Defined Functions **/

    #endregion

    #region ChangePwd
    /** Events **/
    protected void btnChangePwd_Click(object sender, EventArgs e)
    {
        this.Master.setBreadcrumb("<img src='../images/white_arrow_2.jpg' width='10px' height='10px' />&nbsp;"
                + "<a class='active_a' href='my_account.aspx'>My Account</a>&nbsp;<img src='../images/white_arrow_2.jpg' width='10px' height='10px' />"
                + "&nbsp;Change Password");

        pnlInfoView.Visible = false;
        pnlInfoEdit.Visible = false;
        pnlChangePwd.Visible = true;
        //LoginUserInfo uinfo = (LoginUserInfo)Session["security"];
        //lblPwUserID.Text = uinfo.getUserId().ToString();
    }

    protected void btnPwdSave_Click(object sender, EventArgs e)
    {
        try
        {
            LoginUserInfo uinfo = (LoginUserInfo)Session["security"];

            lblPwdError.Text = "";
            String en_cur_pwd, en_confirm_pwd, db_cur_pwd, db_old_pwd1, db_old_pwd2, db_old_pwd3, en_new_pwd;
            string u_newpwd = txtNewPwd.Text;
            string u_newpwd2 = txtConfirmPwd.Text;

            /*** 1.get current and old pwds from db ***/
            string query = "SELECT user_pwd, user_old_pwd1, user_old_pwd2 FROM [User] WHERE user_deleted=0 AND user_id = " + uinfo.getUserId();
            object[] obj = SqlDbClass.ExecuteDataReader(query, 3);

            if (obj[0] == null)
                return;
            if (obj[0].ToString() == "")
                return;


            db_cur_pwd = obj[0].ToString();

            /*** 2. encrypt the current pwd and new pwd entered by user ***/
            byte[] en_cur_pwd_b = Common.EncryptPwd(txtCurrPwd.Text.Trim());
            byte[] en_new_pwd_b = Common.EncryptPwd(u_newpwd);
            byte[] en_confirm_pwd_b = Common.EncryptPwd(u_newpwd2);

            en_cur_pwd = HexEncoding.ToString(en_cur_pwd_b);
            en_new_pwd = HexEncoding.ToString(en_new_pwd_b);
            en_confirm_pwd = HexEncoding.ToString(en_confirm_pwd_b);


            /*** 3. validation ***/
            //3.1. match new pwd with confirm pwd
            if (!en_new_pwd.Equals(en_confirm_pwd))
            {
                lblPwdError.Text = "New password and Confirm new password must be the same.";
                lblPwerror2.Text = "New password and Confirm new password must be the same."; 
                return;
            }

            //3.2. match current pwd provided by user with current pwd in db
            if (!db_cur_pwd.Equals(en_cur_pwd))
            {
                lblPwdError.Text = "The current password does not match.";
                lblPwerror2.Text = "The current password does not match.";
                return;
            }

            //3.3. compare new pwd with current pwd
            if (en_new_pwd.Equals(db_cur_pwd))
            {
                lblPwdError.Text = "You are not allowed to use the old password.";
                lblPwerror2.Text = "You are not allowed to use the old password."; 
                return;
            }

            //3.4. compare new pwd with old pwd1
            if (obj[1] != null)
            {
                if (obj[1].ToString() != "")
                {
                    db_old_pwd1 = obj[1].ToString();
                    if (en_new_pwd.Equals(db_old_pwd1))
                    {
                        lblPwdError.Text = "You are not allowed to use the old password.";
                        lblPwerror2.Text = "You are not allowed to use the old password."; 
                        return;
                    }
                }
            }

            //3.5. compare new pwd with old pwd2
            if (obj[2] != null)
            {
                if (obj[2].ToString() != string.Empty)
                {
                    db_old_pwd2 = obj[2].ToString();
                    if (en_new_pwd.Equals(db_old_pwd2))
                    {
                        lblPwdError.Text = "You are not allowed to use the old password.";
                        lblPwerror2.Text = "You are not allowed to use the old password.";
                        return;
                    }
                }
            }

            //3.5. check password must be a combination of characters and numeric
            if (!Common.validPassword(txtNewPwd.Text.Trim()))
            {
                lblPwdError.Text = "Password must be a combination of characters and numbers.";
                lblPwerror2.Text = "Password must be a combination of characters and numbers."; 
                return;
            }

            ////3.5. compare new pwd with old pwd3        
            //if (obj[3] != null)
            //{
            //    if (obj[3].ToString() != string.Empty)
            //    {
            //        db_old_pwd3 = obj[3].ToString();
            //        if(en_new_pwd.Equals(db_old_pwd3))
            //        {
            //            lblPwdError.Text = "You are not allowed to use the old password.";
            //            return;
            //        }
            //    }
            //}
            //String password_str = HexEncoding.ToString(en_new_pwd);

            /*** 4. Update the new password into db ***/
            string pwd_update = "UPDATE [User] SET user_old_pwd2=user_old_pwd1,user_old_pwd1=user_pwd"
                        + ",user_pwd=@pwd,user_pwd_modified= @now WHERE user_id=" + uinfo.getUserId();
            string[] sPara = new string[] { "@pwd","@now" };
            object[] oPara = new object[2];
            oPara[0] = en_new_pwd;
            oPara[1] = DateTime.Now;
            SqlDbClass.ExecuteNonQuery(pwd_update, sPara, oPara);

            lblPwdError.Text = "<b>Your password has been saved successfully</b>";
            lblPwerror2.Text = "<b>Your password has been saved successfully</b>";
        }
        catch (Exception ex)
        {
            lblPwdError.Text = "System cannot change the password.";
            lblPwerror2.Text = "System cannot change the password.";
        }

    }

    /** User Definied Functions **/


    #endregion
