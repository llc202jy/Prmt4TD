 public class HadoopThriftAuthBridge {
   public Client createClient() {
     throw new UnsupportedOperationException(
       "The current version of Hadoop does not support Authentication");
   }

   public Client createClientWithConf(String authType) {
     throw new UnsupportedOperationException(
       "The current version of Hadoop does not support Authentication");
   }
   
   public Server createServer(String keytabFile, String principalConf)
     throws TTransportException {
     throw new UnsupportedOperationException(
       "The current version of Hadoop does not support Authentication");
   }


   public static abstract class Client {
   /**
    *
    * @param principalConfig In the case of Kerberos authentication this will
    * be the kerberos principal name, for DIGEST-MD5 (delegation token) based
    * authentication this will be null
    * @param host The metastore server host name
    * @param methodStr "KERBEROS" or "DIGEST"
    * @param tokenStrForm This is url encoded string form of
    * org.apache.hadoop.security.token.
    * @param underlyingTransport the underlying transport
    * @return the transport
    * @throws IOException
    */
     public abstract TTransport createClientTransport(
       String principalConfig, String host,
       String methodStr,String tokenStrForm, TTransport underlyingTransport)
       throws IOException;
   }

   public static abstract class Server {
     public abstract TTransportFactory createTransportFactory() throws TTransportException;
     public abstract TProcessor wrapProcessor(TProcessor processor);
     public abstract TProcessor wrapNonAssumingProcessor(TProcessor processor);
     public abstract InetAddress getRemoteAddress();
     public abstract void startDelegationTokenSecretManager(Configuration conf,
       Object hmsHandler) throws IOException;
     public abstract String getRemoteUser();
     public abstract String getDelegationToken(String owner, String renewer) 
     throws IOException, InterruptedException;
     public abstract long renewDelegationToken(String tokenStrForm) throws IOException;
     public abstract void cancelDelegationToken(String tokenStrForm) throws IOException;