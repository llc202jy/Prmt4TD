#include "RawCamBehavior.h"
#include "Wireless/Wireless.h"
#include "Events/EventRouter.h"
#include "Vision/RawCameraGenerator.h"
#include "Vision/JPEGGenerator.h"
#include "Events/FilterBankEvent.h"
#include "Behaviors/Controller.h"
#include "Shared/ProjectInterface.h"

RawCamBehavior* RawCamBehavior::theOne=NULL;

RawCamBehavior::RawCamBehavior()
	: CameraStreamBehavior("RawCamBehavior",visRaw), visRaw(NULL), packet(NULL), cur(NULL), avail(0), max_buf(0), lastProcessedTime(0)
{
	ASSERT(theOne==NULL,"there was already a RawCamBehavior running!");
	theOne=this;
}

void
RawCamBehavior::DoStart() {
	BehaviorBase::DoStart();
	setupServer();
	erouter->addListener(this,EventBase::visRawCameraEGID,ProjectInterface::visRawCameraSID,EventBase::deactivateETID);
	erouter->addListener(this,EventBase::visJPEGEGID,ProjectInterface::visColorJPEGSID,EventBase::deactivateETID);
	erouter->addListener(this,EventBase::visJPEGEGID,ProjectInterface::visGrayscaleJPEGSID,EventBase::deactivateETID);
}

void
RawCamBehavior::DoStop() {
	erouter->removeListener(this);
	closeServer();
	BehaviorBase::DoStop();
}

void
RawCamBehavior::processEvent(const EventBase& e) {
	if(!wireless->isConnected(visRaw->sock))
		return;
	if(config->vision.rawcam.transport==0 && visRaw->getTransport()==Socket::SOCK_STREAM
		 || config->vision.rawcam.transport==1 && visRaw->getTransport()==Socket::SOCK_DGRAM) {
		//reset the socket
		closeServer();
		setupServer();
		return;
	}
	try {
		const FilterBankEvent* fbke=dynamic_cast<const FilterBankEvent*>(&e);
		if(fbke==NULL) {
			CameraStreamBehavior::processEvent(e);
			return;
		}
		if ((get_time() - lastProcessedTime) < config->vision.rawcam.interval) {// not enough time has gone by
			return;
		}
		/* // turning these off enables individual channel compression
			if(config->vision.rawcam.compression==Config::vision_config::COMPRESS_NONE && e.getGeneratorID()!=EventBase::visRawCameraEGID)
			return;
			if(config->vision.rawcam.compression==Config::vision_config::COMPRESS_JPEG && e.getGeneratorID()!=EventBase::visJPEGEGID)
			return; */
		if(config->vision.rawcam.encoding==Config::vision_config::RawCamConfig::ENCODE_COLOR) {
			if(!writeColor(*fbke)) {
				if(packet) { //packet was opened, need to close it
					cur=packet; // don't send anything
					closePacket();
				}
				//error message should already be printed in writeColor
				//ASSERTRET(false,"serialization failed");
			}
		} else if(config->vision.rawcam.encoding==Config::vision_config::RawCamConfig::ENCODE_SINGLE_CHANNEL) {
			if(!writeSingleChannel(*fbke)) {
				if(packet) { //packet was opened, need to close it
					cur=packet; // don't send anything
					closePacket();
				}
				//error message should already be printed in writeSingleChannel
				//ASSERTRET(false,"serialization failed");
			}
		} else {
			serr->printf("%s: Bad rawcam.encoding setting\n",getName().c_str());
		}
	} catch(...) {
		if(packet) { //packet was opened, need to close it
			cur=packet; // don't send anything
			closePacket();
		}
		// typically this is a per-frame recurring error, so let's just stop now
		serr->printf("%s: exception generated during image serialization, stopping stream.\n",getName().c_str());
		DoStop();
		throw;
	}
}
