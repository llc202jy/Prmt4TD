public partial class admin_audit_view : System.Web.UI.Page
{
    private SqlConnection conn = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["PSDConnectionString"].ToString());
    private Int64 audit_id;
    String redirect_page = "home.aspx";
    SecurityModule security;
    LoginUserInfo userInfo;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
        if (Session["security"] == null)
        {
            //Response.Redirect(Common.sLoginPage);
            //return;
            Response.Redirect(Common.sLoginPage);
        }
        LoginUserInfo userInfo = (LoginUserInfo)Session["security"];

        //CHECK FOR SECURITY
        userInfo = (LoginUserInfo)Session["security"];
        security = userInfo.getModuleSecurity("Audit Trail Management");
        if (security == null)
            Response.Redirect(redirect_page);
        else
        {
            if (security.getView() == 0)
                Response.Redirect(redirect_page);
        }

        //set master page
        this.Master.setHeader("setup");
        this.Master.setHeaderText("View Audit Trail");
        this.Master.setBreadcrumb("<img src='../images/white_arrow_2.jpg' width='10px' height='10px' />&nbsp;<a class='active_a' href='audits.aspx'>Audit Trail</a>&nbsp;<img src='../images/white_arrow_2.jpg' width='10px' height='10px' />&nbsp;View Audit");
        
        string id = Request.QueryString["Id"].ToString();
       
            audit_id = Int64.Parse(id);

            if (!IsPostBack)
            {
                if (audit_id > 0 && audit_id != null)
                {
                    String qry = "SELECT  * FROM AuditTrail WHERE audit_id=" + audit_id;
                    SqlCommand cmd = new SqlCommand(qry, conn);
                    conn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {   
                            //DISPLAY USER NAME
                            lblUserName.Text = dr["access_user"].ToString();                          

                            //DISPLAY USER'S LOGIN NAME
                            lblLoginName.Text = dr["access_login_name"].ToString();

                            //DISPLAY FUNCTION ACCESSED
                            lblFunc.Text = dr["access_func"].ToString();

                            //DISPLAY FULL DESCRIPTION
                            lblDesc.Text = dr["access_desc"].ToString();

                            //DISPLAY DATE                            
                            String accessdate = dr["access_date"].ToString();
                            if (accessdate != null && accessdate != "")
                            {
                                DateTime d = Convert.ToDateTime(accessdate);
                                String day = d.Date.ToString();
                                day = d.ToString("MM-dd-yyyy");
                                lblDate.Text = day;
                            }
                            else
                            {
                                lblDate.Text = accessdate;
                            }
                        }
                    }
                    conn.Close();
                }
            }
        }
        catch (Exception except)
        {
            Response.Redirect("home.aspx");
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("audits.aspx");
    }
    
}