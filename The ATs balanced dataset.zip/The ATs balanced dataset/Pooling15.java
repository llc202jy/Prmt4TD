package com.gargoylesoftware.base.resource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *  A class that can create instances of specific types of resources, such as
 *  JDBC connections.
 *
 * @version  $Revision: 1.3 $
 * @author <a href="mailto:mbowler@GargoyleSoftware.com">Mike Bowler</a>
 */
public abstract class ResourceFactory {

    private final Map resourceManagerToResourceListMap_ = new HashMap( 89 );


    /**
     *  Create a factory
     */
    public ResourceFactory() {
    }


    /**
     *  Allocate a resource for the specified store
     *
     * @param  resourceManager The object that is managing the resource
     *      allocation
     * @return  The new resource
     * @exception  ResourceException If an error occurs
     */
    public final synchronized ManagedResource getResource(
            final ResourceManager resourceManager )
        throws
            ResourceException {

        if( resourceManager == null ) {
            throw new NullPointerException( "resourceManager" );
        }

        final ManagedResource resource;
        try {
            resource = getResourceImpl( resourceManager );
        }
        catch( final Exception e ) {
            throw new ResourceException( e );
        }

        registerResource( resourceManager, resource );
        return resource;
    }


    /**
     *  Release the specified resource. It must have been allocated by the
     *  specified store
     *
     * @param  resource The resource that we are releasing
     * @param  resourceManager The object that is managing the resource
     *      allocation
     * @exception  ResourceException If an error occurs
     */
    public final synchronized void releaseResource(
            final ResourceManager resourceManager,
            final ManagedResource resource )
        throws
            ResourceException {

        if( resourceManager == null ) {
            throw new NullPointerException( "resourceManager" );
        }
        if( resource == null ) {
            throw new NullPointerException( "resource" );
        }

        deregisterResource( resourceManager, resource );

        try {
            releaseResourceImpl( resourceManager, resource );
        }
        catch( final Exception e ) {
            throw new ResourceException( e );
        }
    }


    /**
     *  Release all the resources that had been allocated by the specified
     *  store.
     *
     * @param  resourceManager The object that is managing the resource
     *      allocation
     * @exception  ResourceException If an error occurs
     */
    public synchronized void releaseAllResources(
            final ResourceManager resourceManager )
        throws
            ResourceException {

        final List list = ( List )resourceManagerToResourceListMap_.get( resourceManager );
        if( list != null ) {
            while( list.size() != 0 ) {
                releaseResource( resourceManager, ( ManagedResource )list.get( 0 ) );
            }
        }
    }


    /**
     *  Reinitialize the resource to a known state. This is required for
     *  resource pooling as all resources being returned from a pool must have
     *  been initialized to a known state.
     *
     * @param  resource the resource to reinitialize
     * @return  true if the resource was successfully reinitialized
     */
    public abstract boolean reinitializeResourceIfPossible( final ManagedResource resource );


    /**
     *  Subclasses will override this to perform the actual allocation of the
     *  resource.
     *
     * @param  resourceManager The object that is managing the resource
     *      allocation
     * @return  The new resource
     * @exception  Exception If an error occurs
     */
    protected abstract ManagedResource getResourceImpl(
            final ResourceManager resourceManager )
        throws
            Exception;


    /**
     *  Subclasses will override this to perform the actual release of the
     *  resource.
     *
     * @param  resource The resource to release
     * @param  resourceManager The object that is managing the resource
     *      allocation
     * @exception  Exception If an error occurs
     */
    protected abstract void releaseResourceImpl(
            final ResourceManager resourceManager,
            final ManagedResource resource )
        throws
            Exception;


    private synchronized void registerResource(
            final ResourceManager resourceManager,
            final ManagedResource resource ) {

        List list = ( List )resourceManagerToResourceListMap_.get( resourceManager );
        if( list == null ) {
            list = new ArrayList();
            resourceManagerToResourceListMap_.put( resourceManager, list );
        }

        list.add( resource );
    }


    private synchronized void deregisterResource(
            final ResourceManager resourceManager,
            final ManagedResource resource )
        throws
            ResourceException {

        final List list = ( List )resourceManagerToResourceListMap_.get( resourceManager );
        if( list == null ) {
            throw new ResourceException(
                    "Resource was not allocated by this resource manager: resource=["
                     + resource
                     + "] resourceManager=[" + resourceManager
                     + "]: No resources are being managed by this manager" );
        }

        if( list.contains( resource ) == false ) {
            throw new ResourceException(
                    "Resource was not allocated by this resource manager: resource=["
                     + resource + "] resourceManager=[" + resourceManager
                     + "]: Resources that are being managed by this manager are ["
                     + list + "]" );
        }

        list.remove( resource );
        if( list.size() == 0 ) {
            resourceManagerToResourceListMap_.remove( resourceManager );
        }
    }
}