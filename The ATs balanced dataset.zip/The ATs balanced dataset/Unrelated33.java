        {
            get { return ResourceManager.GetString("DebugInfo_SchemaHelperAtString", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to 	in {0}: line {1}.
        /// </summary>
        public static string DebugInfo_SchemaHelperLine
        {
            get { return ResourceManager.GetString("DebugInfo_SchemaHelperLine", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to &lt;UnknownType&gt;.
        /// </summary>
        public static string DebugInfo_SchemaHelperUnknownType
        {
            get { return ResourceManager.GetString("DebugInfo_SchemaHelperUnknownType", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to StackTrace.
        /// </summary>
        public static string DebugInfo_StackTrace
        {
            get { return ResourceManager.GetString("DebugInfo_StackTrace", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to Unable to process stack trace..
        /// </summary>
        public static string DebugInfo_StackTraceException
        {
            get { return ResourceManager.GetString("DebugInfo_StackTraceException", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to Insufficient privilege to generate stack trace..
        /// </summary>
        public static string DebugInfo_StackTraceSecurityException
        {
            get { return ResourceManager.GetString("DebugInfo_StackTraceSecurityException", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to AppDomainName.
        /// </summary>
        public static string EnvironmentInfo_AppDomainName
        {
            get { return ResourceManager.GetString("EnvironmentInfo_AppDomainName", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to AppVersion.
        /// </summary>
        public static string EnvironmentInfo_AppVersion
        {
            get { return ResourceManager.GetString("EnvironmentInfo_AppVersion", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to BuildTime.
        /// </summary>
        public static string EnvironmentInfo_BuildTime
        {
            get { return ResourceManager.GetString("EnvironmentInfo_BuildTime", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to CLRVersion.
        /// </summary>
        public static string EnvironmentInfo_CLRVersion
        {
            get { return ResourceManager.GetString("EnvironmentInfo_CLRVersion", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to ExecutingAssemblyName.
        /// </summary>
        public static string EnvironmentInfo_ExecutingAssemblyName
        {
            get { return ResourceManager.GetString("EnvironmentInfo_ExecutingAssemblyName", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to FinalBuild.
        /// </summary>
        public static string EnvironmentInfo_FinalBuild
        {
            get { return ResourceManager.GetString("EnvironmentInfo_FinalBuild", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to MachineName.
        /// </summary>
        public static string EnvironmentInfo_MachineName
        {
            get { return ResourceManager.GetString("EnvironmentInfo_MachineName", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to OSVersion.
        /// </summary>
        public static string EnvironmentInfo_OSVersion
        {
            get { return ResourceManager.GetString("EnvironmentInfo_OSVersion", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to UserName.
        /// </summary>
        public static string EnvironmentInfo_UserName
        {
            get { return ResourceManager.GetString("EnvironmentInfo_UserName", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to Unable to read system property. Error message: {0}.
        /// </summary>
        public static string ExtendedPropertyError
        {
            get { return ResourceManager.GetString("ExtendedPropertyError", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to AuthenticationType.
        /// </summary>
        public static string ManagedSecurity_AuthenticationType
        {
            get { return ResourceManager.GetString("ManagedSecurity_AuthenticationType", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to IdentityName.
        /// </summary>
        public static string ManagedSecurity_IdentityName
        {
            get { return ResourceManager.GetString("ManagedSecurity_IdentityName", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to IsAuthenticated.
        /// </summary>
        public static string ManagedSecurity_IsAuthenticated
        {
            get { return ResourceManager.GetString("ManagedSecurity_IsAuthenticated", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to WindowsIdentityName.
        /// </summary>
        public static string ManagedSecurity_WindowsIdentityName
        {
            get { return ResourceManager.GetString("ManagedSecurity_WindowsIdentityName", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to Permission Denied.
        /// </summary>
        public static string PermissionDenied
        {
            get { return ResourceManager.GetString("PermissionDenied", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to CurrentUser.
        /// </summary>
        public static string UnmanagedSecurity_CurrentUser
        {
            get { return ResourceManager.GetString("UnmanagedSecurity_CurrentUser", resourceCulture); }
        }

        /// <summary>
        ///   Looks up a localized string similar to ProcessAccountName.
        /// </summary>
        public static string UnmanagedSecurity_ProcessAccountName
        {
            get { return ResourceManager.GetString("UnmanagedSecurity_ProcessAccountName", resourceCulture); }
        }
    }
}