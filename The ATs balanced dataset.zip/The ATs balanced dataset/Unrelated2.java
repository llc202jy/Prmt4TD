kage org.openware.job.generator.ant;

import org.apache.tools.ant.Task;
import org.apache.tools.ant.BuildException;

import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;

public class GenerateDeploymentDescriptorTask extends Task
{
    private String metaInfDirectory = null;
    private String dsJndiName = null;
    private String ejbJndiName = null;
    private boolean debug = true;

    public void setMetainfdir(String name) {
        metaInfDirectory = name;
    }

    public void setDsjndiname(String name) {
        dsJndiName = name;
    }

    public void setEjbjndiname(String name) {
        ejbJndiName = name;
    }

    public void setDebug(String name) {
        debug = (new Boolean(name)).booleanValue();
    }

    public void execute() throws BuildException {
        PrintWriter pw = null;

        try {
            pw = new PrintWriter(new FileWriter(metaInfDirectory + File.separator + "ejb-jar.xml"));
        } catch (IOException e) {
            throw new BuildException("Can't open the ejb-jar.xml file: " + e.toString());
        }
        
        pw.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        pw.println("<!DOCTYPE ejb-jar PUBLIC '-//Sun Microsystems, Inc.//DTD Enterprise JavaBeans 1.1//EN' 'http://java.sun.com/j2ee/dtds/ejb-jar_1_1.dtd'>");
        pw.println("<ejb-jar>");
        pw.println("    <enterprise-beans>");
        pw.println("        <session>");
        pw.println("            <description>General purpose session bean for reading MDM data</description>");
        pw.println("            <ejb-name>" + ejbJndiName + "</ejb-name>");
        pw.println("            <home>org.openware.job.ejb.MDMSessionHome</home>");
        pw.println("            <remote>org.openware.job.ejb.MDMSession</remote>");
        pw.println("            <ejb-class>org.openware.job.ejb.MDMSessionBean</ejb-class>");
        pw.println("            <session-type>Stateless</session-type>");
        pw.println("            <transaction-type>Container</transaction-type>");
        pw.println("            <env-entry>");
        pw.println("                <env-entry-name>dataSourceLoc</env-entry-name>");
        pw.println("                <env-entry-type>java.lang.String</env-entry-type>");
        pw.println("                <env-entry-value>" + dsJndiName + "</env-entry-value>");
        pw.println("             </env-entry>");
        pw.println("            <env-entry>");
        pw.println("                <env-entry-name>debugMode</env-entry-name>");
        pw.println("                <env-entry-type>java.lang.Boolean</env-entry-type>");
        pw.println("                <env-entry-value>" + debug + "</env-entry-value>");
        pw.println("             </env-entry>");
        pw.println("         </session>");
        pw.println("    </enterprise-beans>");
        pw.println("    <assembly-descriptor>");
        pw.println("        <container-transaction>");
        pw.println("            <method>");
        pw.println("                <ejb-name>" + ejbJndiName + "</ejb-name>");
        pw.println("                <method-name>create</method-name>");
        pw.println("            </method>");
        pw.println("            <method>");
        pw.println("                <ejb-name>" + ejbJndiName + "</ejb-name>");
        pw.println("                <method-name>ping</method-name>");
        pw.println("            </method>");
        pw.println("            <trans-attribute>Supports</trans-attribute>");
        pw.println("        </container-transaction>");
        pw.println("        <container-transaction>");
        pw.println("            <method>");
        pw.println("                <ejb-name>" + ejbJndiName + "</ejb-name>");
        pw.println("                <method-name>*</method-name>");
        pw.println("            </method>");
        pw.println("            <trans-attribute>Required</trans-attribute>");
        pw.println("        </container-transaction>");
        pw.println("    </assembly-descriptor>");
        pw.println("</ejb-jar>");
        pw.flush();
        pw.close();

        try {
            pw = new PrintWriter(new FileWriter(metaInfDirectory + File.separator + "application-client.xml"));
        } catch (IOException e) {
            throw new BuildException("Can't open the application-client.xml file: " + e.toString());
        }
        
        pw.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        pw.println("<!DOCTYPE application-client PUBLIC \"-//Sun Microsystems, Inc.//DTD J2EE Application Client 1.2//EN\" \"http://java.sun.com/j2ee/dtds/application-client_1_2.dtd\">");
        pw.println("<application-client>");
	pw.println("    <display-name>EJB</display-name>");
	pw.println("    <ejb-ref>");
        pw.println("        <ejb-ref-name>" + ejbJndiName + "</ejb-ref-name>");
        pw.println("        <ejb-ref-type>Session</ejb-ref-type>");
        pw.println("        <home>org.openware.job.ejb.MDMSessionHome</home>");
        pw.println("        <remote>org.openware.job.ejb.MDMSession</remote>");
	pw.println("    </ejb-ref>");
        pw.println("</application-client>");
        pw.flush();
        pw.close();
    }
package org.openware.job.generator.ant;

import org.openware.job.generator.input.xml.MDMXmlLoader;
import org.openware.job.generator.input.mdl.MdlLoader;
import org.openware.job.generator.input.visualparadigm.VPLoader;
import org.openware.job.generator.input.ILoader;
import org.openware.job.generator.output.sql.DBOutput;
import org.openware.job.generator.output.java.TableRowOutput;
import org.openware.job.generator.output.java.PersistOutput;
import org.openware.job.generator.output.java.PersistInterfaceOutput;
import org.openware.job.generator.output.java.PersistTclOutput;
import org.openware.job.generator.output.java.JavaDestination;
import org.openware.job.generator.output.java.ClassInfoOutput;
import org.openware.job.generator.output.java.ApiOutput;
import org.openware.job.generator.output.java.ManagerOutput;
import org.openware.job.generator.metadata.MetaData;
import org.openware.job.generator.metadata.TypeMapping;

import org.apache.tools.ant.Task;
import org.apache.tools.ant.BuildException;

import java.io.File;

public class GeneratorTask extends Task
{
    public static final String VERSION = "0.9.4";

    private static final String [] validDbVendorNames = {
        "postgres",
        "oracle",
        "none"
    };
    private static final String [] validInputTypes = {
        "job",
        "rose2000",
        "visualparadigm"
    };
    protected String metadataFileName = null;
    protected String srcRootDir = null;
    protected String dbGenDir = null;
    protected String packageRoot = null;
    protected String dbName = null;
    protected String dbVendorName = "postgres";
    protected String tablePrefix = null;
    protected String dbNameSeparator = null;
    protected String inputType = "job";
    protected boolean doTcl = true;
    protected String apiName = null;
    protected String datasourceName = null;
    protected String apiPackageRoot = null;

    public void setDoTcl(String value) {
        if (!value.toLowerCase().startsWith("y") &&
            !value.toLowerCase().startsWith("n")) {
            throw new IllegalArgumentException("'DoTcl' must be 'yes' or 'no'");
        }

        doTcl = value.toLowerCase().startsWith("y");
    }

    public void setDbNameSeparator(String value) {
        dbNameSeparator = value;
    }

    public void setTablePrefix(String prefix) {
        tablePrefix = prefix;
    }

    public void setInputType(String type) {
        inputType = type;
    }

    public void setApiName(String name) {
        apiName = name;
    }

    public void setApiPackageRoot(String name) {
        apiPackageRoot = name;
    }

    public void setDatasourceName(String name) {
        datasourceName = name;
    }

    public void setDbGenDir(String name) {
        dbGenDir = name;
    }

    public void setVendorname(String name) {
        dbVendorName = name.trim().toLowerCase();;
    }

    public void setSrcfile(String value) {
        metadataFileName = value;
    }

    public void setSrcrootdir(String value) {
        srcRootDir = value;
    }

    public void setPackageroot(String value) {
        packageRoot = value;
    }

    public void setDbname(String value) {
        dbName = value;
    }

    private String getValidNames(String [] names) {
        StringBuffer buf = null;

        buf = new StringBuffer(256);
        buf.append("'" + names[0] + "'");
        for (int i = 1; i < names.length; i++) {
            buf.append(", '" + names[i] + "'");
        }

        return buf.toString();
    }

    private boolean nameValid(String [] names, String name) {
        boolean valid = false;

        for (int i = 0; i < names.length && !valid; i++) {
            if (name.equals(names[i])) {
                valid = true;
            }
        }

        return valid;
    }

    private String upperCaseFirstChar(String str) {
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }

    private boolean needToGenerate(String metadataFileName, JavaDestination javaDest) {
        boolean retvalue = false;
        File mdfile = null;
        File classInfoFile = null;

        mdfile = new File(metadataFileName);
        classInfoFile = new File(javaDest.getDirectory() + "ClassInfo.java");        
        if (mdfile.lastModified() > classInfoFile.lastModified()) {
            retvalue = true;
        }

        return retvalue;
    }

    public void execute() throws BuildException {
        if (!nameValid(validDbVendorNames, dbVendorName)) {
            throw new BuildException("Database vendor name must be one of " + 
                                     getValidNames(validDbVendorNames));
        }

        if (!nameValid(validInputTypes, inputType)) {
            throw new BuildException("Input type name must be one of " + 
                                     getValidNames(validInputTypes));
        }

        if (srcRootDir == null) {
            throw new BuildException("Must specify a source root for the generated files.");
        }

        if (packageRoot == null) {
            throw new BuildException("Must specify a package root for the Java classes.");
        }

        if (dbName == null) {
            throw new BuildException("Must specify a database name for the database output.");
        }
        
        if (dbGenDir == null) {
            dbGenDir = srcRootDir;
        }

        if (metadataFileName == null) {
            throw new BuildException("Must specify the name of the metadata file.");
        }

        if (needToGenerate(metadataFileName, new JavaDestination(srcRootDir, packageRoot))) {
            MetaData md = null;
            ILoader loader = null;
            ClassInfoOutput mdout = null;
            DBOutput out = null;
            TableRowOutput trout = null;
            PersistOutput pout = null;
            PersistInterfaceOutput piout = null;
            PersistTclOutput tout = null;
        
            log("JOB -- version " + VERSION + " -- Generating from " + metadataFileName + " to " + 
                (new JavaDestination(srcRootDir, packageRoot)).getDirectory());
            try {
                if (inputType.equals("job")) {
                    loader = new MDMXmlLoader();
                } else if (inputType.equals("rose2000")) {
                    loader = new MdlLoader();
                } else {
                    loader = new VPLoader();
                }

                md = loader.load(metadataFileName, 
                                 (TypeMapping) Class.forName("org.openware.job.generator.metadata." + 
                                                             upperCaseFirstChar(dbVendorName) + 
                                                             "TypeMapping").newInstance());
                if (tablePrefix != null) {
                    md.setTableNamePrefix(tablePrefix);
                }

                if (dbNameSeparator != null) {
                    md.setDbNameSeparator(dbNameSeparator);
                }

                if (!dbVendorName.equals("none")) {
                    out = (DBOutput) Class.forName("org.openware.job.generator.output.sql." + 
                                                   upperCaseFirstChar(dbVendorName) + "SqlOutput").newInstance();
                    out.init(dbGenDir, dbName);
                }
                trout = new TableRowOutput(new JavaDestination(srcRootDir, packageRoot), 
                                           dbVendorName);
                mdout = new ClassInfoOutput(new JavaDestination(srcRootDir, packageRoot), 
                                            dbVendorName, doTcl);
                pout = new PersistOutput(new JavaDestination(srcRootDir, packageRoot));
                mdout.output(md);
                if (!dbVendorName.equals("none")) {
                    out.output(md);
                }
                trout.output(md);
                pout.output(md);
                if (doTcl) {
                    tout = new PersistTclOutput(new JavaDestination(srcRootDir, packageRoot));
                    tout.output(md);
                }

                if (apiName != null) {
                    ApiOutput aout = null;
                    ManagerOutput mout = null;

                    if (datasourceName == null) {
                        throw new Exception("Must specify datsourcename if generating API");
                    }

                    if  (apiPackageRoot == null) {
                        throw new Exception("Must specify apipackageroot if generating API");
                    }

                    log("JOB -- version " + VERSION + " -- Generating from " + metadataFileName + " to " + 
                        (new JavaDestination(srcRootDir, apiPackageRoot)).getDirectory());
                    mout = new ManagerOutput(new JavaDestination(srcRootDir, 
                                                                 apiPackageRoot),
                                             apiName, datasourceName, packageRoot);
                    mout.output(md);
                    aout = new ApiOutput(new JavaDestination(srcRootDir, 
                                                             apiPackageRoot),
                                         apiName, datasourceName, packageRoot);
                    aout.output(md);
                }
            } catch (Exception e) {
                e.printStackTrace();
                throw new BuildException(e);
            }
        }
    }
}
    public PersistTableModel(PersistCollectionTable pct) {
        this.pct = pct;
    }

    public void setValues(Collection persists) {
        pct.setPersists(persists);
        pct.sort(sortCol, ignoreCase, ascending);
        this.pctStale = true;
        fireTableChanged(new TableModelEvent(this, TableModelEvent.HEADER_ROW));
    }

    public void setPersistCollectionTable(PersistCollectionTable pct) {
        this.pct = pct;
        this.pctStale = true;
        fireTableChanged(new TableModelEvent(this, TableModelEvent.HEADER_ROW));
    }

    public String getColumnName(int col) { 
        resetModel();
        return columnLabels[col];
    }

    public int getRowNumberForIndexedColumnValue(String value) {
        return pct.getRowForIndexedValue(value);
    }

    public String getIndexedColumnValue(int row) {
        return pct.getIndexedValueForRow(row);
    }

    private void resetModel() {
        if (pctStale && pct != null) {
            LinkedList list = null;
            Iterator rows = null;
            int rownum = 0;
            int colnum = 0;

            list = pct.getColumnLabels();
            columnLabels = new String[list.size()];
            columnLabels = (String []) list.toArray(columnLabels);

            rowCount = pct.getNumRows();
            colCount = pct.getNumCols();
            values = new String[rowCount][colCount];
            try {
                rows = pct.getRows().iterator();
            } catch (Exception e) {
                throw new RuntimeException("Can't read PersistTableModel: " + e);
            }
            while (rows.hasNext()) {
                Iterator cols = null;
                
                colnum = 0;
                cols = ((LinkedList) rows.next()).iterator();
                while (cols.hasNext()) {
                    values[rownum][colnum] = (String) cols.next();
