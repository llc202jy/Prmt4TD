package de.x4technology.filestore;

import java.io.Serializable;

/**
 * @author uwe, ingo
 */
public class FileMetaData implements Serializable
{
    private final String name;
    private final long size;

    public FileMetaData(String name, long size)
    {
        this.name = name;
        this.size = size;
    }

    /**
     * @return Returns the size.
     */
    public long getSize()
    {
        return size;
    }

    /**
     * @return Returns the name.
     */
    public String getName()
    {
        return name;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object arg0)
    {
        if (arg0 == null) return false;
        if (arg0 == this) return true;
        if (arg0 instanceof FileMetaData)
        {
            FileMetaData other = (FileMetaData) arg0;
            boolean retval = true;

            retval &= getName().equals(other.getName());
            retval &= getSize() == other.getSize();

            return retval;
        }
        else
            return false;

    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    public int hashCode()
    {
        return getName().hashCode() + (int) getSize();
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        return getName();
    }
}

package de.x4technology.filestore;

import java.io.InputStream;

/**
 * @author ingo
 *
 */
public interface FileStore
{
    FileDescriptor store(FileCreationData fileCreationData);

    void remove(FileDescriptor fileDescriptor);

    InputStream get(FileDescriptor fileDescriptor);

    FileMetaData getMetaData(FileDescriptor fileDescriptor);

    boolean contains(FileDescriptor fileDescriptor);

}

package de.x4technology.filestore;

import java.io.Serializable;

import de.x4technology.cache.CacheableDescriptor;

/**
 * globally unique identifier for file in Filestore
 * 
 * @author martin
 */
public class FileDescriptor implements Serializable, CacheableDescriptor
{
    private static final long serialVersionUID = 1L;
    private String handle;

    public FileDescriptor(String handle)
    {
        this.handle = handle;
    }

    /**
     * @return Returns the handle.
     */
    public String getHandle()
    {
        return handle;
    }

    protected void setHandle(String handle)
    {
        this.handle = handle;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object arg0)
    {
        if (arg0 == null) return false;
        if (arg0 == this) return true;
        if (arg0 instanceof FileDescriptor)
        {
            FileDescriptor other = (FileDescriptor) arg0;
            boolean retval = true;

            retval &= getHandle().equals(other.getHandle());

            return retval;
        }
        else
            return false;

    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    public int hashCode()
    {
        return getHandle().hashCode();
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        return handle;
    }

}

package de.x4technology.filestore;

import java.io.InputStream;

/**
 * @author martin, ingo
 */
public class FileCreationData
{
    private final String name;
    private final InputStream inputStream;

    public FileCreationData(String name, InputStream inputStream)
    {
        this.name = name;
        this.inputStream = inputStream;
    }

    /**
     * @return Returns the name.
     */
    public String getName()
    {
        return name;
    }

    /**
     * @return Returns the inputStream.
     */
    public InputStream getInputStream()
    {
        return inputStream;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object arg0)
    {
        if (arg0 == null) return false;
        if (arg0 == this) return true;
        if (arg0 instanceof FileCreationData)
        {
            FileCreationData other = (FileCreationData) arg0;
            boolean retval = true;

            retval &= getName().equals(other.getName());
            retval &= getInputStream().equals(other.getInputStream());

            return retval;
        }
        else
            return false;

    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    public int hashCode()
    {
        return getName().hashCode() + getInputStream().hashCode();
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        return getName();
    }
}

package de.x4technology.crawler.result.manager;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import de.x4technology.component.Priority;
import de.x4technology.component.callback.InitializableComponent;
import de.x4technology.helper.io.FileHelper;
import de.x4technology.helper.io.IOHelper;

public class FileResultContentManager implements InitializableComponent, ResultContentManager
{
    private static int ordinal = 0;
    private String tmpDir;
    private File dir = FileHelper.createTempDir(FileResultContentManager.class.getName() + "/"
            + System.currentTimeMillis());

    public byte[] getContent(long l)
    {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        try
        {
            InputStream contentAsInputStream = getContentAsInputStream(l);
            IOHelper.copy(contentAsInputStream, stream);
            contentAsInputStream.close();
            stream.close();

            return stream.toByteArray();
        }
        catch (IOException e)
        {
        }
        return null;
    }

    private File createFile(long l)
    {
        File file = new File(dir.getAbsolutePath() + "/" + String.valueOf(l));
        return file;
    }

    public InputStream getContentAsInputStream(long l)
    {
        try
        {
            return new FileInputStream(createFile(l));
        }
        catch (IOException e)
        {
        }
        return null;
    }

    public long storeContent(byte[] ba)
    {
        try
        {
            long l = createId();
            File file = createFile(l);
            // file.deleteOnExit();
            OutputStream os = new FileOutputStream(file);
            os.write(ba);
            os.close();
            return l;
        }
        catch (IOException e)
        {
            throw new RuntimeException(e);
        }
    }

    private synchronized long createId()
    {
        return ordinal++;
    }

    public void init()
    {
    }

    public void deinit()
    {
        FileHelper.deleteRecursive(dir);
    }

    public Priority getPriority()
    {
        return Priority.ASAP;
    }

}
package de.x4technology.component.container.xmlreader;

import java.io.StringReader;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.jdom.Element;
import org.jdom.output.Format;
import org.jdom.output.Format.TextMode;

import com.wutka.jox.JOXBeanReader;

import de.x4technology.component.ComponentContainer;
import de.x4technology.component.SignedComponent;
import de.x4technology.helper.jdom.JDomHelper;
import de.x4technology.helper.lang.ExceptionHelper;
import de.x4technology.helper.reflect.ReflectionHelper;

/**
 * @author uwe
 */
final class JDOMJOXComponentFeeder implements JDOMComponentFeeder
{

    private static final String REF = "$ref:";

    private static final String ATTRIBUTE_CLASSNAME = "class";

    private static final String ATTRIBUTE_URI = "uri";

    private static final JDOMJOXComponentFeeder INSTANCE = new JDOMJOXComponentFeeder();

    public static final JDOMJOXComponentFeeder getInstance()
    {
        return JDOMJOXComponentFeeder.INSTANCE;
    }

    private JDOMJOXComponentFeeder()
    {
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.x4technology.core.configuration.bean.BeanFeeder#readBeans(java.util.Map,
     *      org.jdom.Element)
     */
    public void readBeans(final ComponentContainer m, final Element bean, boolean signed)
    {
        try
        {
            String classname = bean.getAttributeValue(JDOMJOXComponentFeeder.ATTRIBUTE_CLASSNAME);
            String uri = bean.getAttributeValue(JDOMJOXComponentFeeder.ATTRIBUTE_URI);

            String strippedClassName = stripClassName(classname);

            if (classname == null)
            {
                throw new RuntimeException("jox-type-bean needs class attribute");
            }

            Class c = Class.forName(classname);
            Object cb = null;
            if (ReflectionHelper.isSingleton(c))
            {
                cb = ReflectionHelper.getInstance(c);
            }
            else
            {
                cb = c.newInstance();
            }

            List childElements = bean.getContent();
            List injectionReferences = removeInjectionReferences(childElements);

            Format f = Format.getCompactFormat();
            f.setEncoding("UTF-8");
            f.setTextMode(TextMode.PRESERVE);
            String content = JDomHelper.renderDocument(childElements, f);
            StringBuffer sb = new StringBuffer(content.length() + strippedClassName.length() + 10);

            sb.append("<");
            sb.append(strippedClassName);
            sb.append(">");

            sb.append(content);

            sb.append("</");
            sb.append(strippedClassName);
            sb.append(">");

            String str = sb.toString();
            JOXBeanReader reader = new JOXBeanReader(new StringReader(str));
            reader.readObject(cb);

            if (uri == null)
            {
                m.put(cb);
            }
            else
            {
                m.put(uri, cb);
            }

            m.registerInjectionReferences(cb, injectionReferences);

            if (signed && (cb instanceof SignedComponent))
            {
                ((SignedComponent) cb).setSigned(true);
            }

        }
        catch (Throwable e)
        {
            if (e instanceof RuntimeException)
            {
                throw (RuntimeException) e;
            }
            if (e instanceof Error)
            {
                throw (Error) e;
            }
            throw new RuntimeException(ExceptionHelper.dump(e));
        }
    }

    private List removeInjectionReferences(final List content)
    {
        List l = new LinkedList();
        for (Iterator iter = content.iterator(); iter.hasNext();)
        {
            Object next = iter.next();
            if (next instanceof Element)
            {

                Element childElement = (Element) next;
                String text = childElement.getTextTrim();
                if ((text != null) && text.startsWith(JDOMJOXComponentFeeder.REF))
                {
                    l.add(new InjectionReference(childElement.getName(), text.substring(JDOMJOXComponentFeeder.REF
                            .length())));
                    iter.remove();
                }
            }
        }
        return l;
    }

    private String stripClassName(final String classname)
    {
        return classname.substring(classname.lastIndexOf(".") + 1);
    }

    private static transient de.x4technology.logging.LogFacility __log = null;

    private static de.x4technology.logging.LogFacility log()
    {
        if (__log == null)
        {
            __log = de.x4technology.logging.LogFactory.getFacility(JDOMJOXComponentFeeder.class);
        }
        return __log;
    }

}

package de.x4technology.registry;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.io.StringWriter;
import java.util.Iterator;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import de.x4technology.helper.conversion.TypeConversionException;
import de.x4technology.helper.conversion.TypeConversionHelper;
import de.x4technology.helper.lang.ExceptionHelper;
import de.x4technology.helper.lang.StringHelper;

/**
 * @author martin
 */
public class RegistryImpl implements Serializable, Registry
{
    private Document doc = new Document();

    private static final char KEY_SEPARATOR = '/';

    private static final String ELEMENT_ROOT = "registry";
    private static final String ELEMENT_KEY = "key";
    private static final String ELEMENT_VALUE = "value";
    private static final String ATTRIBUTE_NAME = "name";

    /**
     * 
     */
    public RegistryImpl()
    {
        doc.setRootElement(new Element(ELEMENT_ROOT));
    }

    /* (non-Javadoc)
     * @see de.x4technology.registry.Registry#put(java.lang.String, java.lang.String)
     */
    public void put(String name, String value)
    {
        if (name == null) throw new NullPointerException("name");
        if (value == null) throw new NullPointerException("value");

        name = adjustName(name);
        String keyname = StringHelper.beforeLastChar(name, KEY_SEPARATOR);
        String attributename = StringHelper.afterLastChar(name, KEY_SEPARATOR);

        if (name.indexOf(KEY_SEPARATOR) == -1)
        {
            keyname = "";
        }

        Element root = doc.getRootElement();
        Element parent = root;

        parent = createPath(keyname, parent);

        Element cur = null;
        List children = parent.getChildren(ELEMENT_VALUE);
        for (Iterator i2 = children.iterator(); i2.hasNext();)
        {
            Element e = (Element) i2.next();
            if (attributename.equals(e.getAttribute(ATTRIBUTE_NAME).getValue()))
            {
                cur = e;
                break;
            }
        }

        if (cur == null)
        {
            cur = new Element(ELEMENT_VALUE);
            cur.setAttribute(ATTRIBUTE_NAME, attributename);
            parent.addContent(cur);
        }
        cur.setText(value);

        store();
    }

    /**
     * @param keyname
     * @param parent
     * @return
     */
    private Element createPath(String keyname, Element parent)
    {
        if (keyname.length() > 0)
        {
            String[] keynames = keyname.split(String.valueOf(KEY_SEPARATOR));
            for (int i = 0; i < keynames.length; i++)
            {
                List children = parent.getChildren(ELEMENT_KEY);
                Element ch = null;
                for (Iterator i2 = children.iterator(); i2.hasNext();)
                {
                    Element e = (Element) i2.next();
                    if (keynames[i].equals(e.getAttribute(ATTRIBUTE_NAME).getValue()))
                    {
                        ch = e;
                        break;
                    }
                }
                if (ch == null)
                {
                    // create child
                    ch = new Element(ELEMENT_KEY);
                    ch.setName(ELEMENT_KEY);
                    ch.setAttribute(ATTRIBUTE_NAME, keynames[i]);
                    parent.addContent(ch);
                }
                parent = ch;
            }
        }
        return parent;
    }

    /**
     * Removes multiple KEY_SEPARATORs in name and trims leading and
     * trailing ones.
     *  
     * @param name
     * @return
     */
    private String adjustName(String name)
    {
        StringBuffer sb = new StringBuffer(name.length());

        boolean isPrevCharSeparator = true;
        for (int i = 0, j = name.length(); i < j; i++)
        {
            char curChar = name.charAt(i);
            if (curChar == KEY_SEPARATOR && isPrevCharSeparator)
            {
                continue;
            }

            isPrevCharSeparator = (curChar == KEY_SEPARATOR);
            sb.append(curChar);
        }

        // remove trailing KEY_SEPARATORs
        while (sb.charAt(sb.length() - 1) == KEY_SEPARATOR)
        {
            sb.deleteCharAt(sb.length() - 1);
        }

        return sb.toString();
    }

    /* (non-Javadoc)
     * @see de.x4technology.registry.Registry#put(java.lang.String, int)
     */
    public void put(String name, int value)
    {
        put(name, String.valueOf(value));
        store();
    }

    /* (non-Javadoc)
     * @see de.x4technology.registry.Registry#put(java.lang.String, double)
     */
    public void put(String name, double value)
    {
        put(name, String.valueOf(value));
        store();
    }

    /* (non-Javadoc)
     * @see de.x4technology.registry.Registry#put(java.lang.String, boolean)
     */
    public void put(String name, boolean value)
    {
        put(name, String.valueOf(value));
        store();
    }

    /* (non-Javadoc)
     * @see de.x4technology.registry.Registry#getString(java.lang.String)
     */
    public String getString(String name)
    {
        if (name == null) throw new NullPointerException("name");

        name = adjustName(name);
        String keyname = StringHelper.beforeLastChar(name, KEY_SEPARATOR);
        String attributename = StringHelper.afterLastChar(name, KEY_SEPARATOR);

        if (name.indexOf(KEY_SEPARATOR) == -1)
        {
            keyname = "";
        }

        Element root = doc.getRootElement();
        Element cur = root;
