			} else {
				log.debug("Creating new null activity");
				na = (NullActivityImpl) ((NullActivityFactoryImpl) naf)
						.createNullActivityNoTx();
			}
			
				public String[] getResourceAdaptorEntities(ResourceAdaptorEntityState state)
			throws NullPointerException, ManagementException {
		if (state == null)
			throw new NullPointerException("null entity state");

		Iterator resourceAdaptorEntityIterator = resourceAdaptorEntities
				.values().iterator();
		ArrayList resultEntityNamesArrayList = new ArrayList();

		while (resourceAdaptorEntityIterator.hasNext()) {
			ResourceAdaptorEntity resourceAdaptorEntity = (ResourceAdaptorEntity) resourceAdaptorEntityIterator
					.next();
			if (resourceAdaptorEntity.getState().equals(state))
				resultEntityNamesArrayList.add(resourceAdaptorEntity.getName());
		}

		String[] resultEntityNames = new String[resultEntityNamesArrayList
				.size()];
		resultEntityNames = (String[]) resultEntityNamesArrayList
				.toArray(resultEntityNames);

		return resultEntityNames;
	}

	/**
	 * @param svc
	 * @return
	 */
	public ServiceComponent getServiceComponent(ServiceID svc) {
		// Call this when you dont care about the service state ( this is just
		// an optimization to avoid creating a new tx.
		boolean b = SleeContainer.getTransactionManager().requireTransaction();
		try {
			return (ServiceComponent) this.getDeploymentCacheManager()
					.getServiceComponents().get(svc);
		} catch (SystemException ex) {
			throw new RuntimeException("Tx manager failed ", ex);
		} finally {
			try {
				if (b)
					getTransactionManager().commit();
			} catch (SystemException ex) {
				throw new RuntimeException("tx maanger failed ", ex);
			}
		}
	}

	/**
	 * @param serviceID
	 * @return
	 */
	public boolean checkServiceExists(ServiceID serviceID) {

		boolean b = SleeContainer.getTransactionManager().requireTransaction();
		try {
			return this.getDeploymentCacheManager().getServiceComponents()
					.containsKey(serviceID);
		} catch (SystemException ex) {
			throw new RuntimeException("Tx manager failed ", ex);
		} finally {
			try {
				if (b)
					getTransactionManager().commit();
			} catch (SystemException ex) {
				throw new RuntimeException("tx maanger failed ", ex);
			}
		}
	}

	public int getRmiRegistryPort() throws Exception {
		Integer port = (Integer) mbeanServer.getAttribute(new ObjectName(
				"slee:service=SleeTCKWrapper"), "RMIRegistryPort");
		return port.intValue();
	}

	/**
	 * @return
	 */
	public DeployableUnitDescriptor[] getDeployableUnitDescriptors()
			throws SystemException {
		if (logger.isDebugEnabled()) {
			logger.debug("getDeployableUnitDescriptors() ");
		}
		boolean b = SleeContainer.getTransactionManager().requireTransaction();

		try {
			Object[] descriptors = this.getDeploymentCacheManager()
					.getDeployableUnitIDtoDescriptorMap().values().toArray();

			DeployableUnitDescriptor[] retval = new DeployableUnitDescriptor[descriptors.length];
			for (int i = 0; i < descriptors.length; i++) {

				retval[i] = (DeployableUnitDescriptor) descriptors[i];
			}
			return retval;

		} finally {
			try {
				if (b)
					getTransactionManager().commit();

			} catch (SystemException ex) {
				throw new RuntimeException("tx maanger failed ", ex);
			}
			if (logger.isDebugEnabled()) {
				logger.debug("getDeployableUnitDescriptors() exit");
			}
		}

	}

	/**
	 * Return a list of component descriptors for the given list of component
	 * ids.
	 * 
	 * @param componentIds
	 * 
	 * @return an array of component descriptors.
	 * 
	 */
	public ComponentDescriptor[] getDescriptors(ComponentID[] componentIds) {

		boolean b = getTransactionManager().requireTransaction();
		try {
			ArrayList knownComps = new ArrayList();
			for (int i = 0; i < componentIds.length; i++) {
				if (isInstalled(componentIds[i])) {
					// may be too strict (spec says 'recognized', 14.7.8, p214)

					ComponentDescriptor descr = this
							.getComponentDescriptor(componentIds[i]);
					knownComps.add(descr);

				}
			}
			ComponentDescriptor[] components = new ComponentDescriptor[knownComps
					.size()];
			knownComps.toArray(components);
			return components;

	/**
	 * Return the deployable Unit id given the url string from where it was
	 * loaded.
	 * 
	 * @param deploymentUrl --
	 *            url from where the unit was loaded.
	 * @return the deployable unit id for the url.
	 */
	public DeployableUnitID getDeployableUnitIDFromUrl(String deploymentUrl)
			throws UnrecognizedDeployableUnitException {
		boolean b = getTransactionManager().requireTransaction();
		try {
			DeployableUnitID retval = (DeployableUnitID) this
					.getDeploymentCacheManager().getUrlToDeployableUnitIDMap()
					.get(deploymentUrl);
			if (retval == null)
				throw new UnrecognizedDeployableUnitException(
						"Unrecognized  deployable unit " + deploymentUrl);
			else
				return retval;
		} catch (SystemException ex) {
			throw new RuntimeException("Tx manager failed! ", ex);
		} finally {
			if (b)
				try {
					getTransactionManager().commit();
				} catch (Exception e) {
					logger
							.error(
									"Failed to complete tx for getDeployableUnitIDFromUrl()",
									e);
					throw new SLEEException(
							"Failed to complete tx for getDeployableUnitIDFromUrl()",
							e);
				}
		}
	}

	/**
	 * Return a set of services that match the given service state.
	 * 
	 * @param serviceState
	 * @return
	 */
	public ServiceID[] getServicesByState(ServiceState serviceState)
			throws Exception {
		// Service state is cached so we need to call this only in the context
		// of a tx.
		boolean b = getTransactionManager().requireTransaction();
		try {
			if (serviceState == ServiceState.ACTIVE) {
				// logger.info(">>>>>>>> fetching number of Active
				// services...:getDeploymentCacheManager()");
				DeploymentCacheManager dumgr = getDeploymentCacheManager();
				// logger.info(">>>>>>>> fetching number of Active
				// services...:getActiveServiceIDs()");
				Set activeServiceIds = dumgr.getActiveServiceIDs();
				// logger.info(">>>>>>>> fetching number of Active
				// services...:activeServiceIds.toArray(new ServiceID[0])");
				return (ServiceID[]) activeServiceIds.toArray(new ServiceID[0]);
			} else {
				Iterator it = this.getDeploymentCacheManager()
						.getServiceComponents().values().iterator();
				ArrayList retval = new ArrayList();
				while (it.hasNext()) {
					ServiceComponent svc = (ServiceComponent) it.next();
					Service service = getService(svc.getServiceID());
					if (service.getState().equals(serviceState)) {
						retval.add(svc.getServiceID());
					}
				}
				ServiceID[] ret = new ServiceID[retval.size()];
				retval.toArray(ret);
				return ret;

			}
		} finally {
			try {
				if (b)
					getTransactionManager().commit();
			} catch (Exception ex) {
				logger.error("Transaction manager failed commit", ex);
			}
		}

	}

	/**
	 * @param serviceID
	 */
	public synchronized void stopService(ServiceID serviceID)
			throws UnrecognizedServiceException, InvalidStateException {

		if (serviceID == null)
			throw new NullPointerException("null service ID");

		logger.debug("============Stopping service:" + serviceID);
		SleeTransactionManager transactionManager = SleeContainer
				.getTransactionManager();

		boolean rb = true;
		try {

			transactionManager.begin();

			if (this.getDeploymentCacheManager().getServiceComponents().get(
					serviceID) == null)
				throw new UnrecognizedServiceException("Service not found for "
						+ serviceID);

			// get the transactionally isolated copy of the service.

			ServiceComponent svc = this.getServiceComponent(serviceID);

			Service service = this.getService(serviceID);

			if (logger.isDebugEnabled())
				logger.debug("Service is " + service + " serviceState = "
						+ service.getState());
			if (service.getState().equals(ServiceState.STOPPING))
				throw new InvalidStateException("Service is STOPPING");

			if (service.getState().equals(ServiceState.INACTIVE)) {
				getDeploymentCacheManager().getActiveServiceIDs().remove(
						serviceID);
				throw new InvalidStateException("Service already deactivated");
			}

			// notifying the resource adaptor about service
			HashSet sbbIDs = svc.getSbbComponents();
			HashSet raEntities = new HashSet();
			Iterator i = sbbIDs.iterator();
			while (i.hasNext()) {
				SbbDescriptor sbbdesc = getSbbComponent((SbbID) i.next());
				if (sbbdesc != null) {
					String[] raLinks = sbbdesc.getResourceAdaptorEntityLinks();
					for (int c = 0; raLinks != null && c < raLinks.length; c++) {
						ResourceAdaptorEntity raEntity = getRAEntity(raLinks[c]);
						if (raEntity != null && !raEntities.contains(raEntity)) {
							raEntity.serviceDeactivated(serviceID.toString());
							raEntities.add(raEntity);
						}
					}
				}
			}

			service.deactivate();
			getDeploymentCacheManager().getActiveServiceIDs().remove(serviceID);
			rb = false;

		} catch (InvalidStateException ise) {
			logger.error(ise);
			throw ise;
		} catch (SystemException ex) {
			logger.error(ex);
			throw new RuntimeException("Tx manager failed! ", ex);
		} catch (Exception e) {
			logger.error(e);
			throw new SLEEException("Failed to stop service " + serviceID, e);
		} finally {
			try {
				if (rb)
					transactionManager.setRollbackOnly();
				transactionManager.commit();

			} catch (SystemException e2) {
				logger.error(e2);
			}
		}

		// The service is set to INACTIVE state after the activity end event
		// for the service activity has been processed ( See
		// EventRouterImpl.java )
		try {
			// Unlock the service for this comp.
			// Its just a local flag to signal that the component can
			// now be removed.
			getTransactionManager().begin();
			this.getServiceComponent(serviceID).unlock();
			getTransactionManager().commit();
			while (true) {
				logger.info("Waiting for Stop " + serviceID);
				try {
					Thread.sleep(1000);
				} catch (Exception ex) {
				}

				getTransactionManager().begin();
				Service svc = this.getService(serviceID);
				if (svc == null) {
					logger.info("Service has been removed!");
					break;
				}
				if (svc.getState().equals(ServiceState.INACTIVE)) {
					// LETS SCHEDULE REMOVAL
					new SleeContainerLingeringServiceSbbRemoverTask(
							sbbEntityRemoverTimer, svc,
							sevriceIdsToRemovalTasks);
					break;
				} else {
					logger.info("Service State is " + svc.getState());
					getTransactionManager().commit();
					continue;
				}
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {

			try {
				Service svc = this.getService(serviceID);

				logger.info("Successfully Stopped service " + serviceID
						+ " State = " + svc.getState());

				getTransactionManager().commit();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	public String getRAActivityContextInterfaceFactoryJNDIName(
			ResourceAdaptorTypeID resourceAdapterTypeId) {
		ResourceAdaptorActivityContextInterfaceFactory acif = (ResourceAdaptorActivityContextInterfaceFactory) this.activityContextInterfaceFactories
				.get(resourceAdapterTypeId);
		return acif.getJndiName();
	}

	public EventRouter getEventRouter() {
		return this.router;
	}

	/**
	 * Get a list of profiles known to me
	 * 
	 * @return A list of profiles that are registered with me.
	 */
	public ProfileSpecificationID[] getProfileSpecificationIDs() {
		boolean b = SleeContainer.getTransactionManager().requireTransaction();
		try {
			ProfileSpecificationIDImpl[] retval = new ProfileSpecificationIDImpl[this
					.getDeploymentCacheManager().getProfileComponents().size()];
			this.getDeploymentCacheManager().getProfileComponents().keySet()
					.toArray(retval);
			return retval;
		} catch (SystemException ex) {
			throw new RuntimeException("Tx manager failed ", ex);
		} finally {
			try {
				if (b)
					getTransactionManager().commit();
			} catch (SystemException ex) {
				throw new RuntimeException("tx maanger failed ", ex);
			}
		}
	}

	/**
	 * @return the usage parameter table / public HashMap
	 *         getUsageParameterTable() {
	 * 
	 * return this.usageParameters; } / /** return the null activity factory.
	 * 
	 * @return
	 */
	public NullActivityFactoryImpl getNullActivityFactory() {
		return this.nullActivityFactory;
	}

	/**
	 * get the null activity context interface factory.
	 * 
	 * @return the null activity context interface factory.
	 */
	public NullActivityContextInterfaceFactoryImpl getNullActivityContextInterfaceFactory() {
		return this.nullActivityContextInterfaceFactory;
	}

	/**
	 * Register standard SLEE contexts in JNDI
	 * 
	 * @throws Exception
	 */
	protected void initNamingContexts() throws Exception {
		// Initialize the SLEE name space

		/*
		 * The following code sets the global name for the Slee
		 */
		Context ctx = new InitialContext();
		ctx = Util.createSubcontext(ctx, JVM_ENV + CTX_SLEE);

		Util.createSubcontext(ctx, "resources");
		Util.createSubcontext(ctx, "container");
		Util.createSubcontext(ctx, "facilities");
		Util.createSubcontext(ctx, "sbbs");
		ctx = Util.createSubcontext(ctx, "nullactivity");
		Util.createSubcontext(ctx, "factory");
		Util.createSubcontext(ctx, "nullactivitycontextinterfacefactory");
	}

	/*
	 * Register property editors for the composite SLEE types so that the jboss
	 * jmx console can pass it as an argument.
	 */
	protected void registerPropertyEditors() {
		PropertyEditorManager.registerEditor(ComponentID.class,
				ComponentIDPropertyEditor.class);
		PropertyEditorManager.registerEditor(Level.class,
				LevelPropertyEditor.class);
		PropertyEditorManager.registerEditor(Properties.class,
				PropertiesPropertyEditor.class);
		PropertyEditorManager.registerEditor(ProfileSpecificationID.class,
				ProfileSpecificationIDPropertyEditor.class);
		PropertyEditorManager.registerEditor(ComponentID[].class,
				ComponentIDArrayPropertyEditor.class);
		PropertyEditorManager.registerEditor(SbbID[].class,
				ComponentIDArrayPropertyEditor.class);
		PropertyEditorManager.registerEditor(DeployableUnitID.class,
				DeployableUnitIDPropertyEditor.class);
		PropertyEditorManager.registerEditor(Object.class,
				ObjectPropertyEditor.class);
		PropertyEditorManager.registerEditor(ServiceID.class,
				ComponentIDPropertyEditor.class);
		PropertyEditorManager.registerEditor(Object.class,
				ServiceStatePropertyEditor.class);
		PropertyEditorManager.registerEditor(ResourceAdaptorID.class,
				ComponentIDPropertyEditor.class);
	}

	/**
	 * Get the current state of the Slee Container
	 * 
	 * @return SleeState
	 */
	public SleeState getSleeState() {
		return this.sleeState;
	}

	/**
	 * Set the current state of the Slee Container. CAUTION: Do not invoke this
	 * method directly! Use the SleeManagementMBean to change the Slee State
	 * 
	 * @param SleeState
	 */
	public SleeState setSleeState(SleeState newState) {
		return this.sleeState = newState;
	}

	/**
	 * Return the MBeanServer that the SLEEE is registers with in the current
	 * JVM
	 * 
	 */
	public MBeanServer getMBeanServer() {
		return mbeanServer;
	}

	public SbbEntityFactory getSbbEntityFactory() {

		return sbbEntityFactory;
	}

	public ServiceActivityContextInterfaceFactoryImpl getServiceActivityContextFactory() {
		return this.serviceActivityContextInterfaceFactory;
	}

	/**
	 * These are hacky -- will be removed after TCK
	 * 
	 * @return
	 */

	/**
	 * 
	 */
	public synchronized void removeEventType(EventTypeDescriptorImpl descriptor) {
		EventTypeIDImpl eventTypeID = (EventTypeIDImpl) descriptor.getID();
		ComponentKey ckey = eventTypeID.getComponentKey();
		logger.info("entry of removeEventType EventTypeDescriptorImpl");
		this.eventTypeIDToDescriptor.remove(eventTypeID);
		this.eventKeyToEventTypeIDMap.remove(ckey);
		this.eventTypeIDToEventKeyMap.remove(eventTypeID);
		this.eventTypeIDs.remove(new Integer(eventTypeID.getEventID()));

		logger.info("EVENT TYPE REMOVED: " + eventTypeID);
	}

	public HashMap getActivityContextInterfaceFactories() {
		return activityContextInterfaceFactories;
	}

	public void addActivityContextInterfaceFactory(ComponentID key,
			TCKActivityContextInterfaceFactoryImpl acif) {
		activityContextInterfaceFactories.put(key, acif);
	}

	public void createResourceAdaptorEntityLink(String link, String entityName)
			throws ManagementException {
		if (this.resourceAdaptorEntityLinks.containsKey(link))
			throw new ManagementException("Entity Link already exist!");
		this.resourceAdaptorEntityLinks.put(link, entityName);
	}

	public void removeResourceAdaptorEntityLink(String link)
			throws ManagementException {
		if (!this.resourceAdaptorEntityLinks.containsKey(link))
			throw new ManagementException("Entity Link not found!");
		this.resourceAdaptorEntityLinks.remove(link);
	}

	public Set listResourceAdaptorEntityLinks() {
		return this.resourceAdaptorEntityLinks.keySet();
	}

	public String[] getResourceAdaptorEntityLinks() throws ManagementException {
		Set entityLinksSet = resourceAdaptorEntityLinks.keySet();
		String[] entityLinksArray = new String[entityLinksSet.size()];
		entityLinksArray = (String[]) entityLinksSet.toArray(entityLinksArray);
		return entityLinksArray;
	}

	public String getResourceAdaptorEntityName(String linkName)
			throws NullPointerException, UnrecognizedLinkNameException {
		if (linkName == null)
			throw new NullPointerException("null link name");

		String entityName = (String) resourceAdaptorEntityLinks.get(linkName);
		if (entityName == null)
			throw new UnrecognizedLinkNameException("Entity link " + linkName
					+ " not found");

		return entityName;
	}

	public String[] getResourceAdaptorEntityNames(String[] linkNames)
			throws NullPointerException {
		if (linkNames == null)
			throw new NullPointerException("null link names");

		String[] resultEntityNames = new String[linkNames.length];
		for (int i = 0; i < linkNames.length; i++) {
			String entityName = (String) resourceAdaptorEntityLinks
					.get(linkNames[i]);
			resultEntityNames[i] = entityName;
		}

		return resultEntityNames;
	}

	public String[] getResourceAdaptorEntityNames() {
		String[] entityNames = new String[resourceAdaptorEntities.keySet()
				.size()];
		entityNames = (String[]) resourceAdaptorEntities.keySet().toArray(
				entityNames);
		return entityNames;
	}

	public String[] getResourceAdaptorEntityNames(
			ResourceAdaptorID resourceAdaptorID) throws NullPointerException,
			UnrecognizedResourceAdaptorException {
		if (resourceAdaptorID == null)
			throw new NullPointerException("null resource adaptor");

		InstalledResourceAdaptor installedRA = (InstalledResourceAdaptor) this.installedResourceAdaptors
				.get(resourceAdaptorID);
		if (installedRA == null)
			throw new UnrecognizedResourceAdaptorException("Resource adaptor "
					+ resourceAdaptorID.toString() + " not found");

		HashSet resourceAdaptorEntitiesSet = installedRA
				.getResourceAdaptorEntities();
		ResourceAdaptorEntity[] resourceAdaptorEntitiesArray = new ResourceAdaptorEntity[resourceAdaptorEntitiesSet
				.size()];
		resourceAdaptorEntitiesArray = (ResourceAdaptorEntity[]) resourceAdaptorEntitiesSet
				.toArray(resourceAdaptorEntitiesArray);

		String[] entityNames = new String[resourceAdaptorEntitiesArray.length];
		for (int i = 0; i < entityNames.length; i++) {
			entityNames[i] = resourceAdaptorEntitiesArray[i].getName();
		}
		return entityNames;
	}

	public String[] getResourceAdaptorEntityLinks(String entityName)
			throws NullPointerException,
			UnrecognizedResourceAdaptorEntityException, ManagementException {
		if (entityName == null)
			throw new NullPointerException("null entity name");

		if (!resourceAdaptorEntities.containsKey(entityName))
			throw new UnrecognizedResourceAdaptorEntityException("Entity "
					+ entityName + " not found");

		String[] entityLinksArray = getResourceAdaptorEntityLinks();
		ArrayList resultEntityLinksArrayList = new ArrayList();
		for (int i = 0; i < entityLinksArray.length; i++) {
			String entityLink = entityLinksArray[i];
			String entity = (String) resourceAdaptorEntityLinks.get(entityLink);
			if (entity.equals(entityName))
				resultEntityLinksArrayList.add(entityLink);
		}
		String[] resultEntityLinks = new String[resultEntityLinksArrayList
				.size()];
		resultEntityLinks = (String[]) resultEntityLinksArrayList
				.toArray(resultEntityLinks);
		return resultEntityLinks;
	}

	public ResourceAdaptorEntity getResourceAdaptorEntity(String entityName)
			throws NullPointerException,
			UnrecognizedResourceAdaptorEntityException {
		if (entityName == null)
			throw new NullPointerException("null entity name");

		ResourceAdaptorEntity entity = (ResourceAdaptorEntity) this.resourceAdaptorEntities
				.get(entityName);
		if (entity == null)
			throw new UnrecognizedResourceAdaptorEntityException("Entity "
					+ entityName + " not found");

		return entity;
	}

	/**
	 * @deprecated Use getResourceAdaptorEntity
	 */
	public ResourceAdaptorEntity getResourceAdaptorEnitity(String enitityName) {
		return (ResourceAdaptorEntity) this.resourceAdaptorEntities
				.get(enitityName);
	}

	public HashMap getResourceAdaptorEntities() {
		return resourceAdaptorEntities;
	}

	/**
			// fire an event on the slee endpoint using the right null activity
			NullActivityImpl na = null;
			if (activityHandle != null) {

				ActivityHandleImpl handle = (ActivityHandleImpl) activityHandle;
				ActivityContext ac = acf.getActivityContextById(handle
						.getKey());
				if (ac == null) {
					log.error("Invalid activity handle!");
					return;
				}
				na = (NullActivityImpl) ac.getActivity();

			} else {
				log.debug("Creating new null activity");
				na = (NullActivityImpl) ((NullActivityFactoryImpl) naf)
						.createNullActivityNoTx();
			}

			endpoint.enqueueEvent(eventType, event, na, address);
			log.debug("Queued event");
		} catch (Exception ex) {
			try {
		@param parent the parent element node containing the descendant.
     * @param tagName the name of the tag to retrieve elements for.
     * @return the descendant element noe.
     * @exception IllegalArgumentException if either of the supplied
     *        parameters is null, or <tt>tagName</tt> is zero-length..
     * @exception XMLException if zero or more than one descendant
     *        element with the given name is found.
     */
    public static Element getUniqueElement(Element parent, String tagName) throws IllegalArgumentException, XMLException {
        Iterator elements = getElementsByTagName(parent, tagName).iterator();
        if (elements.hasNext()) {
            Element element = (Element)elements.next();
            if (elements.hasNext()) {
                throw new XMLException("Only one \"" + tagName + "\" element expected");
            }
            return element;
        }
        else {
            throw new XMLException("One \"" + tagName + "\" (and only one) element expected");
        }
    }

    /**
     * Get an optional descendant element node from a given parent node.  The
     * descendant may occur at most one time.
     * @param parent the parent element containing the descendant.
     * @param tagName the name of the tag to retrieve elements for.
     * @return the descendant element, or <tt>null</tt> if no descendant
     *        was found.
     * @exception IllegalArgumentException if either of the supplied
     *        parameters is null, or <tt>tagName</tt> is zero-length..
     * @exception XMLException if more than one element was found.
     */
    public static Element getOptionalElement(Element parent, String tagName) throws IllegalArgumentException, XMLException {
        Iterator elements = getElementsByTagName(parent, tagName).iterator();
        if (elements.hasNext()) {
            Element element = (Element)elements.next();
            if (elements.hasNext()) {
                throw new XMLException("At most one \"" + tagName + "\" element expected");
            }
            return element;
        }
        else {
            return null;
        }
    }

    /**
     * Get the contents of an text element.  A text element contains a string of
     * text only, not further XML tags.
     * @param element the text element.
     * @return the text contents of the element as a string.  Whitespace from both
     *        ends of the string is trimmed.
     * @throws IllegalStateException if the element is null
     * @throws XMLException if the element is not a text node.
     */
    public static String getElementContent(Element element) throws IllegalArgumentException, XMLException {
        if (element == null) throw new IllegalArgumentException("Element is null");

        NodeList nodelist = element.getChildNodes();
        if (nodelist.getLength() == 0)
            return "";

        if ((nodelist.getLength() != 1) || (nodelist.item(0).getNodeType() != Node.TEXT_NODE))
            throw new XMLException("Not a text node: " + element);

        return nodelist.item(0).getNodeValue().trim();
    }

    /**
     * Get the contents of a text element that is a child of another node.
     *
     * @param parent the parent element of the text element
     * @param tagName the tag name of the text element
     * @return the text contents of the element as a string.  Whitespace from both
     *        ends of the string is trimmed.
     * @throws XMLException if the element is not found, or is not a text node
     */
    public static String getTextElement(Element parent, String name) throws XMLException {
	return getElementContent(getUniqueElement(parent, name));
    }

    public static String getOptionalTextElement(Element parent, String name) throws XMLException {
	Element e = getOptionalElement(parent, name);
	if (e == null) return null;
	return getElementContent(e);
    }

    /**
     * Create a new tag as a child of an existing element. Fill the tag with
     * the given text string.
     *
     * @param parent the parent element to create the tag as a child of
     * @param tagName the tag name of the child to create
     * @param text the text content to give the newly created tag     
     */
    public static void createTextElement(Element parent, String tagName, String text) {
	Document doc = parent.getOwnerDocument();
	Element newElement = doc.createElement(tagName);
	newElement.appendChild(doc.createTextNode(text));
	parent.appendChild(newElement);
    }

    
    /**
     * Merge two documents. Elements from the toMerge document are copied into the toModify
     * document. Elements with the special attribute 'id' are matched between documents based
     * on the value of the attribute (which is expected to be unique across all instances in
     * a document -- i.e. it is an XML ID attribute).
     *<p>
     * For example, if this is the toModify document:
     *<pre>
     * &lt;doc1&gt
     *   &lt;tag1&gt abc &lt;/tag1&gt
     *   &lt;tag2 id="123"&gt 
     *     &lt;tag3&gt; def &lt;/tag3&gt;
     *   &lt;/tag2&gt
     * &lt;/doc1&gt
     *</pre>
     * .. and this is the toMerge document:
     *<pre>
     * &lt;doc2&gt
     *   &lt;new-tag&gt ghi &lt;/new-tag&gt
     *   &lt;tag2 id="123"&gt
     *     &lt;new-tag-2&gt; jkl &lt;/new-tag-2&gt;
     *   &lt;/tag2&gt
     * &lt;/doc2&gt
     *</pre>
     *</pre>
     * .. then toModify will become:
     *<pre>
     * &lt;doc1&gt
     *   &lt;tag1&gt abc &lt;/tag1&gt
     *   &lt;tag2 id="123"&gt 
     *     &lt;tag3&gt; def &lt;/tag3&gt;
     *     &lt;new-tag-2&gt; jkl &lt;/new-tag-2&gt;
     *   &lt;/tag2&gt
     *   &lt;new-tag&gt ghi &lt;/new-tag&gt
     * &lt;/doc1&gt
     *</pre>
     *
     * @param toModify the document to merge data into
     * @param toMerge the document to merge data from
     * @param tagsToMerge a non-null array of tags where collisions should be merged
     * @throws XMLException if an ID was found in toMerge that could not be matched up with toModify
     */
    public static void mergeDocuments(Document toModify, Document toMerge, String[] tagsToMerge) throws XMLException {
	mergeTree(toModify.getDocumentElement(), toModify.getDocumentElement(), toMerge.getDocumentElement(), tagsToMerge);
    }

    /**
     * As {@link #mergeDocuments(Document,Document,String[])}, but no collisions are merged
     * @param toModify the document to merge data into
     * @param toMerge the document to merge data from
     */
    public static void mergeDocuments(Document toModify, Document toMerge) throws XMLException {
	mergeDocuments(toModify, toMerge, new String[0]);
    }

    private static Element findID(Node top, String id) {
	NodeList childList = top.getChildNodes();
	for (int i = 0; i < childList.getLength(); ++i) {
	    Node child = childList.item(i);
	    if (child.getNodeType() == Node.ELEMENT_NODE) {
		Element elem = (Element)child;
		Attr idAttr = elem.getAttributeNode("id");
		if (idAttr != null) {
		    if (idAttr.getValue().equals(id))
			return elem;
		    else
			continue;  // don't inspect past an existing ID attribute!
		}
	    }
	    
	    // Check subtree
	    Element found = findID(child, id);
	    if (found != null)
		return found;
	}

	return null;
    }

    // Merge children of 'source' to be children of 'dest'.
    // Also do ID merging.
    private static void mergeTree(Node top, Node dest, Node source, String[] tagsToMerge) throws XMLException {
	NodeList sourceList = source.getChildNodes();
	for (int i = 0; i < sourceList.getLength(); ++i) {
	    Node sourceChild = sourceList.item(i);
	    
	    if (sourceChild.getNodeType() == Node.ELEMENT_NODE) {
		Element elem = (Element)sourceChild;
		Attr idAttr = elem.getAttributeNode("id");
		if (idAttr != null) {
		    Element mergeDest = findID(top, idAttr.getValue());
		    if (mergeDest == null)
			throw new XMLException("Missing ID attribute: " + idAttr.getValue());
		    mergeTree(mergeDest, mergeDest, elem, tagsToMerge);
		    continue;
		}

                // Handle node collisions -- merge children.
                boolean found = false;
                NodeList destChildren = dest.getChildNodes();
                for (int j = 0; j < destChildren.getLength() && !found; ++j) {
                    Node destNode = destChildren.item(j);
                    if (destNode.getNodeType() == Node.ELEMENT_NODE && ((Element)destNode).getTagName().equals(elem.getTagName())) {
                        for (int k = 0; k < tagsToMerge.length && !found; ++k) {
                            if (elem.getTagName().equals(tagsToMerge[k])) {
                                // OK to merge, do it.
                                found = true;
                                mergeTree(top, destNode, sourceChild, tagsToMerge);
                            }
                        }
                    }
                }
                
                if (found)
                    continue;
            }

            switch (sourceChild.getNodeType()) {
            default:    
                // Don't copy other nodes (attributes, etc).
                // nb: attributes are actually copied automatically when we import their
                // owning element (see Document.importNode() javadoc)
                break;

            case Node.ELEMENT_NODE:
                {
                    // Import and recurse.
                    Node newNode = dest.getOwnerDocument().importNode(sourceChild, false);
                    dest.appendChild(newNode);	    
                    mergeTree(top, newNode, sourceChild, tagsToMerge);
                    break;
                }

            case Node.PROCESSING_INSTRUCTION_NODE:
            case Node.TEXT_NODE:
            case Node.CDATA_SECTION_NODE:
            case Node.COMMENT_NODE:
            case Node.ENTITY_REFERENCE_NODE:
                {
                    // Do a deep copy import as these nodes cannot contain Elements
                    Node newNode = dest.getOwnerDocument().importNode(sourceChild, true);
                    dest.appendChild(newNode);	    
                    break;
                }
            }
	}
    }    
}/*
* Created on Jul 19, 2004
*
* The Open SLEE Project
*
* The source code contained in this file is in in the public domain.          
* It can be used in any project, or product without prior permission, 	      
* license or royalty payments. There is no claim of correctness and
* NO WARRANTY OF ANY KIND provided with this code.
*/
package org.mobicents.slee.container;

import javax.slee.Address;
import org.mobicents.slee.container.management.*;
import org.mobicents.slee.resource.SleeActivityHandle;

import javax.slee.EventTypeID;

/**
 * 
 * Implements the InitialEventSelector interface
 * 
 * @author F.Moggia
 * 
 * 
 */
public class InitialEventSelectorImpl implements javax.slee.InitialEventSelector{
    private EventTypeID eventTypeID;
    private String eventName;
    private Object event;
    private Object activity;
    private Address address;
    private String customName;

    int[] select;
    private boolean isSelectMethod = false;
    private boolean isActivityContextSelected= false;
    private boolean isAddressProfileSelected= false;
    private boolean isAddressSelected= false;
    private boolean isEventSelected= false;
    private boolean isEventTypeSelected= false;
    
    
    private boolean isInitialEvent= false;
    
    
    private String selectMethodName;
    

    
    
    
    public InitialEventSelectorImpl(EventTypeID type, Object event, Object activity,  int[] select, String methodName, Address address) {
        eventTypeID = type;
        this.event = event;
        this.address = address;
        if ( activity instanceof SleeActivityHandle ) {
            SleeActivityHandle sah = (SleeActivityHandle) activity;
            this.activity = sah.getActivity();
        } else this.activity = activity;
        
        for(int i=0; i<select.length;i++){
            switch(select[i]){ 
            	case SbbEventEntry.ACTIVITY_CONTEXT_INITIAL_EVENT_SELECT: this.isActivityContextSelected = true;break;
            	case SbbEventEntry.ADDRESS_INITIAL_EVENT_SELECT:this.isAddressSelected=true;break;
            	case SbbEventEntry.ADDRESS_PROFILE_INITIAL_EVENT_SELECT:this.isAddressProfileSelected=true;break;
            	case SbbEventEntry.EVENT_INITIAL_EVENT_SELECT:this.isEventSelected=true;break;
            	case SbbEventEntry.EVENT_TYPE_INITIAL_EVENT_SELECT:this.isEventTypeSelected=true;break;
           
         
            
            }
        }
        
        if (methodName == null){
            isSelectMethod = false;
        } else {
            isSelectMethod = true;
            selectMethodName = methodName;
        }
        
        
    }
    
    
    public String toString() {
        return new StringBuffer()
        			.append("InitialEventSelector = { ")
        			.append("eventTypeID " + eventTypeID + "eventName " + eventName + " event " + event + " activity " + activity + " address " + address )
        			.append("\n activityContextSelected = "  + isActivityContextSelected)
        			.append("\n isAddressSelected " + this.isAddressSelected)
        			.append("\n isAddressProfileSelected " + this.isAddressProfileSelected)
        			.append("\n isEventSelected " + this.isEventSelected)
        			.append("\n customName " + this.customName)
        			.append("\n selectMethodName " + this.selectMethodName)
        			.append("\n }").toString();
    }
    
    /**
     * @return Returns the isActivityContextSelected.
     */
    public boolean isActivityContextSelected() {
        return this.isActivityContextSelected;
    }
    /**
     * @return Returns the isAddressProfileSelected.
     */
    public boolean isAddressProfileSelected() {
        return this.isAddressProfileSelected;
    }
    /**
     * @return Returns the isAddressSelected.
     */
    public boolean isAddressSelected() {
        return this.isAddressSelected;
    }
    /**
     * @return Returns the isEventTypeSelected.
     */
    public boolean isEventTypeSelected() {
        return this.isEventTypeSelected;
    }
    /**
     * @return Returns the eventType.
     */
    public EventTypeID getEventTypeID() {
        return eventTypeID;
    }
    /**
     * @param eventType The eventType to set.
     */
    public void setEventType(EventTypeID eventTypeID) {
        this.eventTypeID = eventTypeID;
    }
    /**
     * @return Returns the isEventSelected.
     */
    public boolean isEventSelected() {
        return this.isEventSelected;
    }
    /**
     * @param isEventSelected The isEventSelected to set.
     */
    
    /**
     * @param isAddressProfileSelected The isAddressProfileSelected to set.
     */
    public void setAddressProfileSelected(boolean isAddressProfileSelected) {
        this.isAddressProfileSelected = isAddressProfileSelected;
    }
    /**
     * @param isAddressSelected The isAddressSelected to set.
     */
    public void setAddressSelected(boolean isAddressSelected) {
        this.isAddressSelected = isAddressSelected;
    }
    /**
     * @param isEventTypeSelected The isEventTypeSelected to set.
     */
    public void setEventTypeSelected(boolean isEventTypeSelected) {
        this.isEventTypeSelected = isEventTypeSelected;
    }
    /**
     * @return Returns the isSelectMethod.
     */
    public boolean isSelectMethod() {
        return isSelectMethod;
    }
    /**
     * @param isSelectMethod The isSelectMethod to set.
     */
    public void setSelectMethod(boolean isSelectMethod) {
        this.isSelectMethod = isSelectMethod;
    }
    /**
     * @return Returns the selectMethodName.
     */
    public String getSelectMethodName() {
        return selectMethodName;
    }
    /**
     * @param selectMethodName The selectMethodName to set.
     */
    public void setSelectMethodName(String selectMethodName) {
        this.selectMethodName = selectMethodName;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#getEventName()
     */
    public String getEventName() {
        return eventName;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#getEvent()
     */
    public Object getEvent() {
        return event;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#getActivity()
     */
    public Object getActivity() {
        return activity;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#getAddress()
     */
    public Address getAddress() {
        
        return address;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#setAddress(javax.slee.Address)
     */
    public void setAddress(Address address) {
        
        this.address = address;
    }
    /* (non-Javadoc)
     * @see javax.slee.InitialEventSelector#getCustomName()
     */
    public String getCustomName() {
        
        return customName;
    }

    public void setCustomName(String customName) {
        this.customName = customName;
    }
    
    public void setActivityContextSelected(boolean isActivityContextSelected) {
        this.isActivityContextSelected = isActivityContextSelected;
    }
    
    public void setEventSelected(boolean isEventSelected) {
        this.isEventSelected = isEventSelected;
    }
    
    public boolean isInitialEvent() {
        return isInitialEvent;
    }
    
    public void setInitialEvent(boolean isInitialEvent) {
        this.isInitialEvent = isInitialEvent;
    }
}