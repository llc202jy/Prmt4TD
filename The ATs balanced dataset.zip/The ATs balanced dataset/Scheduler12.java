private Scheduler scheduler = new Scheduler();

private void CreateJob()
{
  DateTime startTime = ...;
  DateTime expirationTime = ...;
  
  //create job that executes every 1.5 seconds until it expires
  Job job = new Job("Job 1");
  job.Run.From(startTime).Every.Seconds(1.5).Until(expirationTime);

  //submit to scheduler
  scheduler.SubmitJob(job, OnJobExecution);
}


//the callback handler that is invoked every time the job is due
private void OnJobExecution(Job job)
{
  //process job
  ...

  //the job can be aborted directly via the callback method
  if (...)
  {
    job.Cancel();
  }
}
