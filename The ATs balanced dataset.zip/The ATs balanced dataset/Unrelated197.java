                    }
                }
                
                // If we failed to flush anything twice in a row break
                if (len <= 0)
                {
                    if (last_len <= 0) 
                        break Flushing;
                    break;
                }
                last_len = len;
                total+=len;
            }
            
            return total;
        }
        catch (IOException e)
        {
            Log.ignore(e);
            throw (e instanceof EofException) ? e:new EofException(e);
        }
    }

    /* ------------------------------------------------------------ */
    private void prepareBuffers()
    {
        // if we are not flushing an existing chunk
        if (!_bufferChunked)
        {
            // Refill buffer if possible
            if (_content != null && _content.length() > 0 && _buffer != null && _buffer.space() > 0)
            {
                int len = _buffer.put(_content);
                _content.skip(len);
                if (_content.length() == 0) 
                    _content = null;
            }

            // Chunk buffer if need be
            if (_contentLength == HttpTokens.CHUNKED_CONTENT)
            {
                int size = _buffer == null ? 0 : _buffer.length();
                if (size > 0)
                {
                    // Prepare a chunk!
                    _bufferChunked = true;

                    // Did we leave space at the start of the buffer.
                    if (_buffer.getIndex() == CHUNK_SPACE)
                    {
                        // Oh yes, goodie! let's use it then!
                        _buffer.poke(_buffer.getIndex() - 2, HttpTokens.CRLF, 0, 2);
                        _buffer.setGetIndex(_buffer.getIndex() - 2);
                        BufferUtil.prependHexInt(_buffer, size);

                        if (_needCRLF)
                        {
                            _buffer.poke(_buffer.getIndex() - 2, HttpTokens.CRLF, 0, 2);
                            _buffer.setGetIndex(_buffer.getIndex() - 2);
                            _needCRLF = false;
                        }
                    }
                    else
                    {
                        // No space so lets use the header buffer.
                        if (_needCRLF)
                        {
                            if (_header.length() > 0) throw new IllegalStateException("EOC");
                            _header.put(HttpTokens.CRLF);
                            _needCRLF = false;
                        }
                        BufferUtil.putHexInt(_header, size);
                        _header.put(HttpTokens.CRLF);
                    }

                    // Add end chunk trailer.
                    if (_buffer.space() >= 2)
                        _buffer.put(HttpTokens.CRLF);
                    else
                        _needCRLF = true;
                }

                // If we need EOC and everything written
                if (_needEOC && (_content == null || _content.length() == 0))
                {
                    if (_needCRLF)
                    {
                        if (_buffer == null && _header.space() >= 2)
                        {
                            _header.put(HttpTokens.CRLF);
                            _needCRLF = false;
                        }
                        else if (_buffer!=null && _buffer.space() >= 2)
                        {
                            _buffer.put(HttpTokens.CRLF);
                            _needCRLF = false;
                        }
                    }

                    if (!_needCRLF && _needEOC)
                    {
                        if (_buffer == null && _header.space() >= LAST_CHUNK.length)
                        {
                            _header.put(LAST_CHUNK);
                            _bufferChunked=true;
                            _needEOC = false;
                        }
                        else if (_buffer!=null && _buffer.space() >= LAST_CHUNK.length)
                        {
                            _buffer.put(LAST_CHUNK);
                            _bufferChunked=true;
                            _needEOC = false;
                        }
                    }
                }
            }
        }

        if (_content != null && _content.length() == 0) 
            _content = null;

    }


}
                                    keep_alive = true;
                                    if (_method==null) 
                                        _close = false;
                                }
                                break;
                            }
                            default:
                            {
                                if (connection==null)
                                    connection=new StringBuffer();
                                else
                                    connection.append(',');
                                connection.append(field.getValue());
                            }
                        }

                        // Do NOT add yet!
                        break;

                    case HttpHeaders.SERVER_ORDINAL:
                        if (getSendServerVersion()) 
                        {
                            has_server=true;
                            field.put(_header);
   public String getConnectionId() throws IOException
   {
      return connectionId;
   }

   protected HTTPConnection getHTTPConnection()
   {
      return connection;
   }




 public MBeanServerConnection getMBeanServerConnection(Subject delegate) throws IOException
   {
      if (!connected) throw new IOException("Connection has not been established");

      // TODO: here we hardcode the client invocation chain. Maybe worth remove this hardcoding ?
      ClientInvoker invoker = new ClientInvoker(connection, notificationHandler, delegate);
      MBeanServerConnection unmarshaller = ClientUnmarshaller.newInstance(invoker, defaultClassLoader);
      MBeanServerConnection catcher = ClientExceptionCatcher.newInstance(unmarshaller);
  public void connect(Map environment) throws IOException, SecurityException
   {
      synchronized (this)
      {
         if (connected) return;
         if (closed) throw new IOException("This RMIConnector has already been closed");

         // Spec says, about default ClassLoader, to look here:
         // 1. Environment at connect(); if null,
         // 2. Environment at creation; if null,
         // 3. Context classloader at connect().
         ClassLoader loader = findDefaultClassLoader(environment);
         if (loader != null)
            defaultClassLoader = loader;
         else if (defaultClassLoader == null)
            defaultClassLoader = Thread.currentThread().getContextClassLoader();

         Map env = environment == null ? new HashMap() : environment;

         String protocol = jmxServiceURL.getProtocol();
         ConnectionResolver resolver = ConnectionResolver.newConnectionResolver(protocol, env);
         if (resolver == null) throw new IOException("Unsupported protocol: " + protocol);
         if (rmiServer == null) rmiServer = (RMIServer)resolver.lookupClient(jmxServiceURL, env);
         rmiServer = (RMIServer)resolver.bindClient(rmiServer, env);

         Object credentials = env.get(CREDENTIALS);
         this.connection = rmiServer.newClient(credentials);

         connected = true;
         this.connectionId = connection.getConnectionId();