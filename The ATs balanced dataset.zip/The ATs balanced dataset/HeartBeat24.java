package org.apache.activemq.transport;

import java.io.IOException;
import java.net.URI;

import org.apache.activemq.Service;
import org.apache.activemq.wireformat.WireFormat;

/**
 * Represents the client side of a transport allowing messages to be sent
 * synchronously, asynchronously and consumed.
 * 
 * @version $Revision: 1.5 $
 */
public interface Transport extends Service {

    /**
     * A one way asynchronous send
     * 
     * @param command
     * @throws IOException
     */
    void oneway(Object command) throws IOException;

    /**
     * An asynchronous request response where the Receipt will be returned in
     * the future. If responseCallback is not null, then it will be called when
     * the response has been completed.
     * 
     * @param command
     * @param responseCallback TODO
     * @return the FutureResponse
     * @throws IOException
     */
    <T> FutureResponse<T> asyncRequest(Object command, ResponseCallback<T> responseCallback) throws IOException;

    /**
     * A synchronous request response
     * 
     * @param command
     * @return the response
     * @throws IOException
     */
    Object request(Object command) throws IOException;

    /**
     * A synchronous request response
     * 
     * @param command
     * @param timeout
     * @return the repsonse or null if timeout
     * @throws IOException
     */
    Object request(Object command, int timeout) throws IOException;

    // /**
    // * A one way asynchronous send
    // * @param command
    // * @throws IOException
    // */
    // void oneway(Command command) throws IOException;
    //
    // /**
    // * An asynchronous request response where the Receipt will be returned
    // * in the future. If responseCallback is not null, then it will be called
    // * when the response has been completed.
    // *
    // * @param command
    // * @param responseCallback TODO
    // * @return the FutureResponse
    // * @throws IOException
    // */
    // FutureResponse asyncRequest(Command command, ResponseCallback
    // responseCallback) throws IOException;
    //    
    // /**
    // * A synchronous request response
    // * @param command
    // * @return the response
    // * @throws IOException
    // */
    // Response request(Command command) throws IOException;
    //
    // /**
    // * A synchronous request response
    // * @param command
    // * @param timeout
    // * @return the repsonse or null if timeout
    // * @throws IOException
    // */
    // Response request(Command command, int timeout) throws IOException;

    /**
     * Returns the current transport listener
     * 
     * @return
     */
    TransportListener getTransportListener();

    /**
     * Registers an inbound command listener
     * 
     * @param commandListener
     */
    void setTransportListener(TransportListener commandListener);

    /**
     * @param target
     * @return the target
     */
    <T> T narrow(Class<T> target);

    /**
     * @return the remote address for this connection
     */
    String getRemoteAddress();

    /**
     * Indicates if the transport can handle faults
     * 
     * @return true if fault tolerant
     */
    boolean isFaultTolerant();
    
    /**
     * Indicates that the transport needs inactivity monitoring. This 
     * is true for transports like tcp that may not otherwise detect
     * a transport failure in a timely fashion. 
     * 
     * @return true if the transport requires inactivity monitoring.
     */
    boolean isUseInactivityMonitor();
    
    /**
     * @return true if the transport is disposed
     */
    boolean isDisposed();
    
    /**
     * @return true if the transport is connected
     */
    boolean isConnected();
    
    /**
     * @return The wireformat for the connection.
     */
    WireFormat getWireformat();
    
    /**
     * reconnect to another location
     * @param uri
     * @throws IOException on failure of if not supported
     */
    void reconnect(URI uri) throws IOException;

}