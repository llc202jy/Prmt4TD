public interface GradingManager
extends osid.OsidManager
{

    /**
    Create a new GradableObject which includes all the elements for grading something for a CourseSection.  The type of grade and other grade characteristics are also specified.
    @param displayName
    @param description
      CourseSectionId - CourseSections are defined in the CourseManagement OSID.
      ExternalReferenceId - the Unique Id of something to be graded such as an Assessment.
     GradeType
     ScoringDefinition
     GradeScale
    @return GradableObject
    @throws osid.grading.GradingException An exception with one of the following messages defined in osid.grading.GradingException:  {@link osid.shared.SharedException#OPERATION_FAILED OPERATION_FAILED}, {@link osid.shared.SharedException#PERMISSION_DENIED PERMISSION_DENIED}, {@link osid.shared.SharedException#CONFIGURATION_ERROR CONFIGURATION_ERROR}, {@link osid.shared.SharedException#UNIMPLEMENTED UNIMPLEMENTED}, {@link osid.shared.SharedException#NULL_ARGUMENT NULL_ARGUMENT}, {@link osid.shared.SharedException#UNKNOWN_TYPE UNKNOWN_TYPE}
    */
    GradableObject createGradableObject(String displayName
                                      , String description
                                      , osid.shared.Id courseSectionId
                                      , osid.shared.Id externalReferenceId
                                      , osid.shared.Type gradeType
                                      , osid.shared.Type scoringDefinition
                                      , osid.shared.Type gradeScale)
    throws osid.grading.GradingException;

    /**
    Delete a GradableObject.
     gradableObjectId
    @throws osid.grading.GradingException An exception with one of the following messages defined in osid.grading.GradingException:  {@link osid.shared.SharedException#OPERATION_FAILED OPERATION_FAILED}, {@link osid.shared.SharedException#PERMISSION_DENIED PERMISSION_DENIED}, {@link osid.shared.SharedException#CONFIGURATION_ERROR CONFIGURATION_ERROR}, {@link osid.shared.SharedException#UNIMPLEMENTED UNIMPLEMENTED}, {@link osid.shared.SharedException#NULL_ARGUMENT NULL_ARGUMENT}, {@link osid.shared.SharedException#UNKNOWN_ID UNKNOWN_ID}
    */
    void deleteGradableObject(osid.shared.Id assignmentId)
    throws osid.grading.GradingException;

    /**
    Get a GradableObject by Unique Id.
      gradableObjectId
    @return GradableObject
    @throws osid.grading.GradingException An exception with one of the following messages defined in osid.grading.GradingException:  {@link osid.shared.SharedException#OPERATION_FAILED OPERATION_FAILED}, {@link osid.shared.SharedException#PERMISSION_DENIED PERMISSION_DENIED}, {@link osid.shared.SharedException#CONFIGURATION_ERROR CONFIGURATION_ERROR}, {@link osid.shared.SharedException#UNIMPLEMENTED UNIMPLEMENTED}, {@link osid.shared.SharedException#NULL_ARGUMENT NULL_ARGUMENT}, {@link osid.shared.SharedException#UNKNOWN_ID UNKNOWN_ID}
    */
    GradableObject getGradableObject(osid.shared.Id gradableObjectId)
    throws osid.grading.GradingException;

    /**
    Get all the GradableObjects, optionally including only those for a specific CourseSection or External Reference to what is being graded.  If any parameter is null, what is returned is not filtered by that parameter.  Iterators return a group of items, one item at a time.  The Iterator's hasNext method returns <code>true</code> if there are additional objects available; <code>false</code> otherwise.  The Iterator's next method returns the next object.
      CourseSectionId - CourseSections are defined in the CourseManagement OSID.
      ExternalReferenceId - the Unique Id of something to be graded such as an Assessment.
    @return AssignmentIterator The order of the objects returned by the Iterator is not guaranteed.
    @throws osid.grading.GradingException An exception with one of the following messages defined in osid.grading.GradingException:  {@link osid.shared.SharedException#OPERATION_FAILED OPERATION_FAILED}, {@link osid.shared.SharedException#PERMISSION_DENIED PERMISSION_DENIED}, {@link osid.shared.SharedException#CONFIGURATION_ERROR CONFIGURATION_ERROR}, {@link osid.shared.SharedException#UNIMPLEMENTED UNIMPLEMENTED}, {@link osid.shared.SharedException#NULL_ARGUMENT NULL_ARGUMENT}, {@link osid.shared.SharedException#UNKNOWN_ID UNKNOWN_ID}
    */
    GradableObjectIterator getGradableObjects(osid.shared.Id courseSectionId
                                            , osid.shared.Id externalReferenceId)
    throws osid.grading.GradingException;

    /**
    Create a new GradeRecord for an Agent and with a Grade and GradeRecordType.   The GradeRecordType is they Type of GradeRecord not the Type of Grade contained in it.  GradeRecord Types might indicate a mid-term, partial, or final grade while GradeTypes might be letter, numeric, etc.  The Agent in this context is not the
     GradableObjectId - the Unique Id of the GradableObject created by the createGradableObject method.
     
     gradeValue
     gradeRecordType
    @return GradeRecord
    @throws osid.grading.GradingException An exception with one of the following messages defined in osid.grading.GradingException:  {@link osid.shared.SharedException#OPERATION_FAILED OPERATION_FAILED}, {@link osid.shared.SharedException#PERMISSION_DENIED PERMISSION_DENIED}, {@link osid.shared.SharedException#CONFIGURATION_ERROR CONFIGURATION_ERROR}, {@link osid.shared.SharedException#UNIMPLEMENTED UNIMPLEMENTED}, {@link osid.shared.SharedException#NULL_ARGUMENT NULL_ARGUMENT}, {@link osid.shared.SharedException#UNKNOWN_ID UNKNOWN_ID}, {@link osid.shared.SharedException#UNKNOWN_TYPE UNKNOWN_TYPE}
    */
    GradeRecord createGradeRecord(osid.shared.Id gradbaleObjectId
                                , osid.shared.Agent agent
                                , java.io.Serializable gradeValue
                                , osid.shared.Type gradeRecordType)
               , java.sql.Time param
               , java.util.Calendar cal)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setTimestamp(int parameterIndex
                    , java.sql.Timestamp param)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setTimestamp(int parameterIndex
                    , java.sql.Timestamp param
                    , java.util.Calendar cal)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setTransactionIsolation(int level)
    throws osid.dbc.DbcException;

    /**
