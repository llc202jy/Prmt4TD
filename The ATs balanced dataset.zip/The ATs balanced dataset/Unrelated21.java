ASM: a very small and fast Java bytecode manipulation framework
 
import java.util.List;
import java.util.Map;

import com.uwyn.rife.asm.Attribute;
import com.uwyn.rife.asm.ClassReader;
import com.uwyn.rife.asm.Label;
import com.uwyn.rife.asm.attrs.StackMapAttribute;
import com.uwyn.rife.asm.attrs.StackMapFrame;
import com.uwyn.rife.asm.attrs.StackMapType;

/**
 * An {@link ASMifiable} {@link StackMapAttribute} sub class.
 * 
 * @author Eugene Kuleshov
 */
public class ASMStackMapAttribute extends StackMapAttribute implements
        ASMifiable,
        Traceable
{
    /**
     * Length of the attribute used for comparison
     */
    private int len;

    public ASMStackMapAttribute() {
        super();
    }

    public ASMStackMapAttribute(List frames, int len) {
        super(frames);
        this.len = len;
    }

    protected Attribute read(
        ClassReader cr,
        int off,
        int len,
        char[] buf,
        int codeOff,
        Label[] labels)
    {
        StackMapAttribute attr = (StackMapAttribute) super.read(cr,
                off,
                len,
                buf,
                codeOff,
                labels);

        return new ASMStackMapAttribute(attr.getFrames(), len);
    }

    public void asmify(StringBuffer buf, String varName, Map labelNames) {
        List frames = getFrames();
        buf.append("{\n");
        buf.append("StackMapAttribute ").append(varName).append("Attr");
        buf.append(" = new StackMapAttribute();\n");
        if (frames.size() > 0) {
            for (int i = 0; i < frames.size(); i++) {
                asmify((StackMapFrame) frames.get(i), buf, varName + "frame"
                        + i, labelNames);
            }
        }
        buf.append(varName).append(".visitAttribute(").append(varName);
        buf.append("Attr);\n}\n");
    }

    void asmify(
        StackMapFrame f,
        StringBuffer buf,
        String varName,
        Map labelNames)
    {
        declareLabel(buf, labelNames, f.label);
        buf.append("{\n");

        buf.append("StackMapFrame ")
                .append(varName)
                .append(" = new StackMapFrame();\n");

        buf.append(varName)
                .append(".label = ")
                .append(labelNames.get(f.label))
                .append(";\n");

        asmifyTypeInfo(buf, varName, labelNames, f.locals, "locals");
        asmifyTypeInfo(buf, varName, labelNames, f.stack, "stack");

        buf.append("cvAttr.frames.add(").append(varName).append(");\n");
        buf.append("}\n");
    }

    void asmifyTypeInfo(
        StringBuffer buf,
        String varName,
        Map labelNames,
        List infos,
        String field)
    {
        if (infos.size() > 0) {
            buf.append("{\n");
            for (int i = 0; i < infos.size(); i++) {
                StackMapType typeInfo = (StackMapType) infos.get(i);
                String localName = varName + "Info" + i;
                int type = typeInfo.getType();
                buf.append("StackMapType ")
                        .append(localName)
                        .append(" = StackMapType.getTypeInfo( StackMapType.ITEM_")
                        .append(StackMapType.ITEM_NAMES[type])
                        .append(");\n");

                switch (type) {
                    case StackMapType.ITEM_Object: //
                        buf.append(localName)
                                .append(".setObject(\"")
                                .append(typeInfo.getObject())
                                .append("\");\n");
                        break;

                    case StackMapType.ITEM_Uninitialized: //
                        declareLabel(buf, labelNames, typeInfo.getLabel());
                        buf.append(localName)
                                .append(".setLabel(")
                                .append(labelNames.get(typeInfo.getLabel()))
                                .append(");\n");
                        break;
                }
                buf.append(varName)
                        .append(".")
                        .append(field)
                        .append(".add(")
                        .append(localName)
                        .append(");\n");
            }
            buf.append("}\n");
        }
    }

    static void declareLabel(StringBuffer buf, Map labelNames, Label l) {
        String name = (String) labelNames.get(l);
        if (name == null) {
            name = "l" + labelNames.size();
            labelNames.put(l, name);
            buf.append("Label ").append(name).append(" = new Label();\n");
        }
    }

    public void trace(StringBuffer buf, Map labelNames) {
        List frames = getFrames();
        buf.append("[\n");
        for (int i = 0; i < frames.size(); i++) {
            StackMapFrame f = (StackMapFrame) frames.get(i);

            buf.append("    Frame:");
            appendLabel(buf, labelNames, f.label);

            buf.append(" locals[");
            traceTypeInfo(buf, labelNames, f.locals);
            buf.append("]");
            buf.append(" stack[");
            traceTypeInfo(buf, labelNames, f.stack);
            buf.append("]\n");
        }
        buf.append("  ] length:").append(len).append("\n");
    }

    private void traceTypeInfo(StringBuffer buf, Map labelNames, List infos) {
        String sep = "";
        for (int i = 0; i < infos.size(); i++) {
            StackMapType t = (StackMapType) infos.get(i);

            buf.append(sep).append(StackMapType.ITEM_NAMES[t.getType()]);
            sep = ", ";
            if (t.getType() == StackMapType.ITEM_Object) {
                buf.append(":").append(t.getObject());
            }
            if (t.getType() == StackMapType.ITEM_Uninitialized) {
                buf.append(":");
                appendLabel(buf, labelNames, t.getLabel());
            }
        }
    }

    protected void appendLabel(StringBuffer buf, Map labelNames, Label l) {
        String name = (String) labelNames.get(l);
        if (name == null) {
            name = "L" + labelNames.size();
            labelNames.put(l, name);
        }
        buf.append(name);
    }

}/*
 * Copyright 2001-2007 Geert Bevin <gbevin[remove] at uwyn dot com>
 * Distributed under the terms of either:
 * - the common development and distribution license (CDDL), v1.0; or
 * - the GNU Lesser General Public License, v2.1 or later
 * $Id: AbstractContinuable.java 3714 2007-04-08 02:57:38Z gbevin $
 */
package com.uwyn.rife.continuations;

public abstract class AbstractContinuable implements Continuable
{
	public final void pause()
	{
	}
	
	public Object clone()
	throws CloneNotSupportedException
	{
		return super.clone();
	}
}or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.uwyn.rife.asm.util.attrs;

import java.util.List;
import java.util.Map;

import com.uwyn.rife.asm.Attribute;
import com.uwyn.rife.asm.ClassReader;
import com.uwyn.rife.asm.Label;
import com.uwyn.rife.asm.attrs.StackMapTableAttribute;
import com.uwyn.rife.asm.attrs.StackMapFrame;
import com.uwyn.rife.asm.attrs.StackMapType;

/**
 * An {@link ASMifiable} {@link StackMapTableAttribute} sub class.
 * 
 * @author Eugene Kuleshov
 */
public class ASMStackMapTableAttribute extends StackMapTableAttribute implements
        ASMifiable,
        Traceable
{
    /**
     * Length of the attribute used for comparison
     */
    private int len;

    public ASMStackMapTableAttribute() {
        super();
    }

    public ASMStackMapTableAttribute(List frames, int len) {
        super(frames);
        this.len = len;
    }

    protected Attribute read(
        ClassReader cr,
        int off,
        int len,
        char[] buf,
        int codeOff,
        Label[] labels)
    {
        StackMapTableAttribute attr = (StackMapTableAttribute) super.read(cr,
                off,
                len,
                buf,
                codeOff,
                labels);

        return new ASMStackMapTableAttribute(attr.getFrames(), len);
    }

    public void asmify(StringBuffer buf, String varName, Map labelNames) {
        List frames = getFrames();
        if (frames.size() == 0) {
            buf.append("List frames = Collections.EMPTY_LIST;\n");
        } else {
            buf.append("List frames = new ArrayList();\n");
            for (int i = 0; i < frames.size(); i++) {
                buf.append("{\n");
                StackMapFrame f = (StackMapFrame) frames.get(i);
                declareLabel(buf, labelNames, f.label);

                String frameVar = varName + "frame" + i;
                asmifyTypeInfo(buf, frameVar, labelNames, f.locals, "locals");
                asmifyTypeInfo(buf, frameVar, labelNames, f.stack, "stack");

                buf.append("StackMapFrame ")
                        .append(frameVar)
                        .append(" = new StackMapFrame(")
                        .append(labelNames.get(f.label))
                        .append(", locals, stack);\n");
                buf.append("frames.add(").append(frameVar).append(");\n");
                buf.append("}\n");
            }
        }
        buf.append("StackMapTableAttribute ").append(varName);
        buf.append(" = new StackMapTableAttribute(frames);\n");
    }

    void asmifyTypeInfo(
        StringBuffer buf,
        String varName,
        Map labelNames,
        List infos,
        String field)
    {
        if (infos.size() == 0) {
            buf.append("List ")
                    .append(field)
                    .append(" = Collections.EMPTY_LIST;\n");
        } else {
            buf.append("List ").append(field).append(" = new ArrayList();\n");
            buf.append("{\n");
            for (int i = 0; i < infos.size(); i++) {
                StackMapType typeInfo = (StackMapType) infos.get(i);
                String localName = varName + "Info" + i;
                int type = typeInfo.getType();
                buf.append("StackMapType ")
                        .append(localName)
                        .append(" = StackMapType.getTypeInfo( StackMapType.ITEM_")
                        .append(StackMapType.ITEM_NAMES[type])
                        .append(");\n");

                switch (type) {
                    case StackMapType.ITEM_Object: //
                        buf.append(localName)
                                .append(".setObject(\"")
                                .append(typeInfo.getObject())
                                .append("\");\n");
                        break;

                    case StackMapType.ITEM_Uninitialized: //
                        declareLabel(buf, labelNames, typeInfo.getLabel());
                        buf.append(localName)
                                .append(".setLabel(")
                                .append(labelNames.get(typeInfo.getLabel()))
                                .append(");\n");
                        break;
                }
                buf.append(field)
                        .append(".add(")
                        .append(localName)
                        .append(");\n");
            }
            buf.append("}\n");
        }
    }

    static void declareLabel(StringBuffer buf, Map labelNames, Label l) {
        String name = (String) labelNames.get(l);
        if (name == null) {
            name = "l" + labelNames.size();
            labelNames.put(l, name);
            buf.append("Label ").append(name).append(" = new Label();\n");
        }
    }

    public void trace(StringBuffer buf, Map labelNames) {
        List frames = getFrames();
        buf.append("[\n");
        for (int i = 0; i < frames.size(); i++) {
            StackMapFrame f = (StackMapFrame) frames.get(i);

            buf.append("    Frame:");
            appendLabel(buf, labelNames, f.label);

            buf.append(" locals[");
            traceTypeInfo(buf, labelNames, f.locals);
            buf.append("]");
            buf.append(" stack[");
            traceTypeInfo(buf, labelNames, f.stack);
            buf.append("]\n");
        }
        buf.append("  ] length:").append(len).append("\n");
    }

    private void traceTypeInfo(StringBuffer buf, Map labelNames, List infos) {
        String sep = "";
        for (int i = 0; i < infos.size(); i++) {
            StackMapType t = (StackMapType) infos.get(i);

            buf.append(sep).append(StackMapType.ITEM_NAMES[t.getType()]);
            sep = ", ";
            if (t.getType() == StackMapType.ITEM_Object) {
                buf.append(":").append(t.getObject());
            }
            if (t.getType() == StackMapType.ITEM_Uninitialized) {
                buf.append(":");
                appendLabel(buf, labelNames, t.getLabel());
            }
        }
    }

    protected void appendLabel(StringBuffer buf, Map labelNames, Label l) {
        String name = (String) labelNames.get(l);
        if (name == null) {
            name = "L" + labelNames.size();
            labelNames.put(l, name);
        }
        buf.append(name);
    }

}
/**
 * ASM: a very small and fast Java bytecode manipulation framework
 * Copyright (c) 2000-2005 INRIA, France Telecom
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.uwyn.rife.asm.util.attrs;

import java.util.Map;

/**
 * An attribute that can print the ASM code to create an equivalent attribute.
 * 
 * Implementation should print the ASM code that generates attribute data
 * structures for current attribute state.
 * 
 * @author Eugene Kuleshov
 */
public interface ASMifiable {

    /**
     * Prints the ASM code to create an attribute equal to this attribute.
     * 
     * @param buf A buffer used for printing Java code.
     * @param varName name of the variable in a printed code used to store
     *        attribute instance.
     * @param labelNames map of label instances to their names.
     */
    void asmify(StringBuffer buf, String varName, Map labelNames);
}
 *
 */
package com.uwyn.rife.asm.util.attrs;

import java.util.List;
import java.util.Map;

import com.uwyn.rife.asm.Attribute;
import com.uwyn.rife.asm.ClassReader;
import com.uwyn.rife.asm.Label;
import com.uwyn.rife.asm.attrs.StackMapTableAttribute;
import com.uwyn.rife.asm.attrs.StackMapFrame;
import com.uwyn.rife.asm.attrs.StackMapType;

/**
 * An {@link ASMifiable} {@link StackMapTableAttribute} sub class.
 * 
 * @author Eugene Kuleshov
 */
public class ASMStackMapTableAttribute extends StackMapTableAttribute implements
        ASMifiable,
        Traceable
{
    /**
     * Length of the attribute used for comparison
     */
    private int len;

    public ASMStackMapTableAttribute() {
        super();
    }

    public ASMStackMapTableAttribute(List frames, int len) {
        super(frames);
        this.len = len;
    }

    protected Attribute read(
        ClassReader cr,
        int off,
        int len,
        char[] buf,
        int codeOff,
        Label[] labels)
    {
        StackMapTableAttribute attr = (StackMapTableAttribute) super.read(cr,
                off,
                len,
                buf,
                codeOff,
                labels);

        return new ASMStackMapTableAttribute(attr.getFrames(), len);
    }

    public void asmify(StringBuffer buf, String varName, Map labelNames) {
        List frames = getFrames();
        if (frames.size() == 0) {
            buf.append("List frames = Collections.EMPTY_LIST;\n");
        } else {
            buf.append("List frames = new ArrayList();\n");
            for (int i = 0; i < frames.size(); i++) {
                buf.append("{\n");
                StackMapFrame f = (StackMapFrame) frames.get(i);
                declareLabel(buf, labelNames, f.label);

                String frameVar = varName + "frame" + i;
                asmifyTypeInfo(buf, frameVar, labelNames, f.locals, "locals");
                asmifyTypeInfo(buf, frameVar, labelNames, f.stack, "stack");

                buf.append("StackMapFrame ")
                        .append(frameVar)
                        .append(" = new StackMapFrame(")
                        .append(labelNames.get(f.label))
                        .append(", locals, stack);\n");
                buf.append("frames.add(").append(frameVar).append(");\n");
                buf.append("}\n");
            }
        }
        buf.append("StackMapTableAttribute ").append(varName);
        buf.append(" = new StackMapTableAttribute(frames);\n");
    }

    void asmifyTypeInfo(
        StringBuffer buf,
        String varName,
        Map labelNames,
        List infos,
        String field)
    {
        if (infos.size() == 0) {
            buf.append("List ")
                    .append(field)
                    .append(" = Collections.EMPTY_LIST;\n");
        } else {
            buf.append("List ").append(field).append(" = new ArrayList();\n");
            buf.append("{\n");
            for (int i = 0; i < infos.size(); i++) {
                StackMapType typeInfo = (StackMapType) infos.get(i);
                String localName = varName + "Info" + i;
                int type = typeInfo.getType();
                buf.append("StackMapType ")
                        .append(localName)
                        .append(" = StackMapType.getTypeInfo( StackMapType.ITEM_")
                        .append(StackMapType.ITEM_NAMES[type])
                        .append(");\n");

                switch (type) {
                    case StackMapType.ITEM_Object: //
                        buf.append(localName)
                                .append(".setObject(\"")
                                .append(typeInfo.getObject())
                                .append("\");\n");
                        break;

                    case StackMapType.ITEM_Uninitialized: //
                        declareLabel(buf, labelNames, typeInfo.getLabel());
                        buf.append(localName)
                                .append(".setLabel(")
                                .append(labelNames.get(typeInfo.getLabel()))
                                .append(");\n");
                        break;
                }
                buf.append(field)
                        .append(".add(")
                        .append(localName)
                        .append(");\n");
            }
            buf.append("}\n");
        }
    }

    static void declareLabel(StringBuffer buf, Map labelNames, Label l) {
        String name = (String) labelNames.get(l);
        if (name == null) {
            name = "l" + labelNames.size();
            labelNames.put(l, name);
            buf.append("Label ").append(name).append(" = new Label();\n");
        }
    }

    public void trace(StringBuffer buf, Map labelNames) {
        List frames = getFrames();
        buf.append("[\n");
        for (int i = 0; i < frames.size(); i++) {
            StackMapFrame f = (StackMapFrame) frames.get(i);

            buf.append("    Frame:");
            appendLabel(buf, labelNames, f.label);

            buf.append(" locals[");
            traceTypeInfo(buf, labelNames, f.locals);
            buf.append("]");
            buf.append(" stack[");
            traceTypeInfo(buf, labelNames, f.stack);
            buf.append("]\n");
        }
        buf.append("  ] length:").append(len).append("\n");
    }

    private void traceTypeInfo(StringBuffer buf, Map labelNames, List infos) {
        String sep = "";
        for (int i = 0; i < infos.size(); i++) {
            StackMapType t = (StackMapType) infos.get(i);

            buf.append(sep).append(StackMapType.ITEM_NAMES[t.getType()]);
            sep = ", ";
            if (t.getType() == StackMapType.ITEM_Object) {
                buf.append(":").append(t.getObject());
            }
            if (t.getType() == StackMapType.ITEM_Uninitialized) {
                buf.append(":");
                appendLabel(buf, labelNames, t.getLabel());
            }
        }
    }

    protected void appendLabel(StringBuffer buf, Map labelNames, Label l) {
        String name = (String) labelNames.get(l);
        if (name == null) {
            name = "L" + labelNames.size();
            labelNames.put(l, name);
        }
        buf.append(name);
    }

} ASM: a very small and fast Java bytecode manipulation framework
 * Copyright (c) 2000-2005 INRIA, France Telecom
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 */
package com.uwyn.rife.asm.util.attrs;

import java.util.Map;

/**
 * An attribute that can print eadable representation of the attribute.
 * 
 * Implementation should construct readable output from an attribute data
 * structures for current attribute state. Such representation could be used in
 * unit test assertions.
 * 
 * @author Eugene Kuleshov
 */
public interface Traceable {

    /**
     * Build a human readable representation of the attribute.
     * 
     * @param buf A buffer used for printing Java code.
     * @param labelNames map of label instances to their names.
     */
    void trace(StringBuffer buf, Map labelNames);
}
package com.uwyn.rife.continuations;

import com.uwyn.rife.continuations.instrument.ContinuableDetector;
import com.uwyn.rife.continuations.instrument.ContinuationsBytecodeTransformer;
import com.uwyn.rife.instrument.ClassBytesProvider;
import com.uwyn.rife.tools.ClassBytesLoader;

public class ClassLoaderTests extends ClassLoader implements ClassBytesProvider
{
	private ContinuationConfigInstrument	mConfig = new ContinuationConfigInstrumentTests();
	private ClassBytesLoader				mBytesLoader;
	private ContinuableDetector				mContinuableDetector;
	
    public ClassLoaderTests(ClassLoader parent)
	{
        super(parent);
		
		mBytesLoader = new ClassBytesLoader(getParent());
		mContinuableDetector = new ContinuableDetector(mConfig, this);
    }
	
	public byte[] getClassBytes(String className, boolean reloadAutomatically) throws ClassNotFoundException
	{
		return mBytesLoader.getClassBytes(className.replace('.', '/')+".class");
	}
	
    public Class loadClass(String name) throws ClassNotFoundException
	{
		if (findLoadedClass(name) == null)
		{
			byte[] bytes = getClassBytes(name, false);
			if (bytes == null)
			{
				return super.loadClass(name);
			}
			
			if (mContinuableDetector.detect(name.intern(), bytes, false))
			{
				byte[] resume_bytes = ContinuationsBytecodeTransformer.transformIntoResumableBytes(mConfig, bytes, name);
				
				if (resume_bytes != null)
				{
					bytes = resume_bytes;
				}
				
				return defineClass(name, bytes, 0, bytes.length);
			}
		}
		
        return super.loadClass(name);
    }
	
	public class ContinuationConfigInstrumentTests implements ContinuationConfigInstrument
	{
		public String getContinuableClassInternalName()
		{
			return "com/uwyn/rife/continuations/AbstractContinuable";
		}
		
		public String getContinuableInterfaceInternalName()
		{
			return "com/uwyn/rife/continuations/Continuable";
		}
		
		public String getContinuableClassOrInterfaceName()
		{
			return "com.uwyn.rife.continuations.AbstractContinuable";
		}
		
		public String getEntryMethod()
		{
			return "execute()V";
		}
	}
}

package com.uwyn.rife.continuations;

import com.uwyn.rife.continuations.instrument.ContinuableDetector;
import com.uwyn.rife.continuations.instrument.ContinuationsBytecodeTransformer;
import com.uwyn.rife.instrument.ClassBytesProvider;
import com.uwyn.rife.tools.ClassBytesLoader;

public class ClassLoaderTests extends ClassLoader implements ClassBytesProvider
{
	private ContinuationConfigInstrument	mConfig = new ContinuationConfigInstrumentTests();
	private ClassBytesLoader				mBytesLoader;
	private ContinuableDetector				mContinuableDetector;
	
    public ClassLoaderTests(ClassLoader parent)
	{
        super(parent);
		
		mBytesLoader = new ClassBytesLoader(getParent());
		mContinuableDetector = new ContinuableDetector(mConfig, this);
    }
	
	public byte[] getClassBytes(String className, boolean reloadAutomatically) throws ClassNotFoundException
	{
		return mBytesLoader.getClassBytes(className.replace('.', '/')+".class");
	}
	
    public Class loadClass(String name) throws ClassNotFoundException
	{
		if (findLoadedClass(name) == null)
		{
			byte[] bytes = getClassBytes(name, false);
			if (bytes == null)
			{
				return super.loadClass(name);
			}
			
			if (mContinuableDetector.detect(name.intern(), bytes, false))
			{
				byte[] resume_bytes = ContinuationsBytecodeTransformer.transformIntoResumableBytes(mConfig, bytes, name);
				
				if (resume_bytes != null)
				{
					bytes = resume_bytes;
				}
				
				return defineClass(name, bytes, 0, bytes.length);
			}
		}
		
        return super.loadClass(name);
    }
	
	public class ContinuationConfigInstrumentTests implements ContinuationConfigInstrument
	{
		public String getContinuableClassInternalName()
		{
			return "com/uwyn/rife/continuations/AbstractContinuable";
		}
		
		public String getContinuableInterfaceInternalName()
		{
			return "com/uwyn/rife/continuations/Continuable";
		}
		
		public String getContinuableClassOrInterfaceName()
		{
			return "com.uwyn.rife.continuations.AbstractContinuable";
		}
		
		public String getEntryMethod()
		{
			return "execute()V";
		}
	}
}

package com.uwyn.rife.database;

import com.uwyn.rife.database.queries.Query;
import com.uwyn.rife.tools.ExceptionUtils;
import java.sql.SQLException;
import java.util.logging.Logger;

/**
 * By extending this class it's possible to easily customize the behaviour of
 * some methods in the {@link DbQueryManager} class.
 * <p>You're able to perform custom logic with the resultset of a query by
 * overriding the {@link #concludeResults(DbResultSet) concludeResults} method
 * and returning an object.
 * <p>You're not supposed to close the resultset in this method.
 * 
 * @author Geert Bevin (gbevin[remove] at uwyn dot com)
 * @version $Revision: 3877 $
 * @see DbResultSet
 * @see DbQueryManager
 * @since 1.0
 */
public abstract class DbResultSetHandler implements Cloneable
{
	public DbStatement createStatement(DbConnection connection)
	{
		return connection.createStatement();
	}

	public DbPreparedStatement getPreparedStatement(Query query, DbConnection connection)
	{
		return connection.getPreparedStatement(query);
	}

	public Object concludeResults(DbResultSet resultset)
	throws SQLException
	{
		return null;
	}

	/**
	 * Simply clones the instance with the default clone method since this
	 * class contains no member variables.
	 * 
	 * @since 1.0
	 */
	public Object clone()
	{
		try
		{
			return super.clone();
		}
		catch (CloneNotSupportedException e)
		{
			// this should never happen
			Logger.getLogger("com.uwyn.rife.database").severe(ExceptionUtils.getExceptionStackTrace(e));
			return null;
		}
	}

 * This class parses an XML file to create a set of {@link Datasource}
 * objects.
 * <p>An example of the parsable datasource file:
 * <pre>&lt;datasources&gt;
 *  &lt;datasource name="postgres"&gt;
 *    &lt;driver&gt;org.postgresql.Driver&lt;/driver&gt;
 *    &lt;url&gt;jdbc:postgres://localhost/database&lt;/url&gt;
 *    &lt;user&gt;username&lt;/user&gt;
 *    &lt;password&gt;password&lt;/user&gt;
 *    &lt;poolsize&gt;5&lt;/poolsize&gt;
 *  &lt;/datasource&gt;
 *&lt;/datasources&gt;</pre>
 * <p>An explaination of terms:
 * <ul>
 * <li>datasource name: used to uniquely identify the datasource
 * <li>driver: the classname of the driver to use to connect
 * <li>url: the connection url used to connect
 * <li>user: the username needed for authentication
 * <li>password: the password needed for authentication
 * <li>poolsize: the number of connections to always keep connected
 * </ul>
 * Multiple datasource definitions are supported and can be used at anytime.
 *
 * @author JR Boyens (jboyens[remove] at uwyn dot com)
 * @author Geert Bevin (gbevin[remove] at uwyn dot com)
 * @version $Revision: 3884 $
 * @since 1.0
 */
public class Xml2Datasources extends Xml2Data
{
	private Datasource					mDatasource = null;
	private HashMap<String, Datasource>	mDatasources = null;
	private String						mNameAttribute = null;
	private StringBuilder				mCharacterData = null;

	/**
	 * Return the created datasources.
	 *
	 * @return the datasources created after parsing
	 * @since 1.0
	 */
	public HashMap<String, Datasource> getDatasources()
	{
		return mDatasources;
	}

	/**
	 * Clears the information in this datasource.
	 *
	 * @since 1.0
	 */
	protected void clear()
	{
		mDatasource = null;
		mDatasources = new HashMap<String, Datasource>();
		mNameAttribute = null;
		mCharacterData = null;
	}

	/**
	 * Called when the beginng of the document to be parsed is found
	 *
	 * @since 1.0
	 */
	public void startDocument()
	{
		clear();
	}

	/**
	 * Called when the start tag of an XML element is encountered
	 *
	 * @param namespaceURI the URI of the namespace of the start tag
	 * @param localName the local name of the starting element
	 * @param qName the qualified name of the starting element
	 * @param atts the attributes of the starting element
	 * @since 1.0
	 */
	public void startElement(String namespaceURI, String localName, String qName, Attributes atts)
	{
		if (qName.equals("datasource"))
		{
			mNameAttribute = atts.getValue("name");

			mDatasource = new Datasource();
		}
		else if (qName.equals("driver") ||
				 qName.equals("url") ||
				 qName.equals("user") ||
				 qName.equals("password") ||
				 qName.equals("poolsize") ||
				 qName.equals("jndi"))
		{
			mCharacterData = new StringBuilder();
		}
		else if (qName.equals("config"))
		{
			if (mCharacterData != null &&
				Config.hasRepInstance())
			{
				mCharacterData.append(Config.getRepInstance().getString(atts.getValue("param"), ""));
			}
		}
		else if (qName.equals("datasources"))
		{
			// do nothing
		}
		else
		{
			throw new XmlErrorException("Unsupport element name '"+qName+"'.");
		}
	}

	/**
	 * Called when the end tag of an XML element is encountered
	 *
	 * @param namespaceURI the URI of the namespace of the ending element
	 * @param localName the local name of the ending element
	 * @param qName the qualified name of the ending element
	 * @since 1.0
	 */
	public void endElement(String namespaceURI, String localName, String qName)
	{
		if (qName.equals("datasource"))
		{
			mDatasources.put(mNameAttribute, mDatasource);
		}
		else if (qName.equals("driver"))
		{
			mDatasource.setDriver(mCharacterData.toString());
		}
		else if (qName.equals("url"))
		{
			mDatasource.setUrl(mCharacterData.toString());
		}
		else if (qName.equals("user"))
		{
			mDatasource.setUser(mCharacterData.toString());
		}
		else if (qName.equals("password"))
		{
			mDatasource.setPassword(mCharacterData.toString());
		}
		else if (qName.equals("jndi"))
		{
			Context ctx;
			try
			{
				ctx = new InitialContext();

				Object ds = ctx.lookup(mCharacterData.toString());
				if (null == ds)
				{
					throw new XmlErrorException("The '"+mCharacterData.toString()+"' JNDI entry returned 'null'.");
				}
				if (!(ds instanceof DataSource))
				{
					throw new XmlErrorException("The '"+mCharacterData.toString()+"' JNDI entry isn't a DataSource.");
				}

				mDatasource.setDataSource((DataSource)ds);
			}
			catch (NamingException e)
			{
				throw new XmlErrorException("Unexpected error while looking up the '"+mCharacterData.toString()+"' JNDI entry.", e);
			}

		}
		else if (qName.equals("poolsize"))
		{
			try
			{
				mDatasource.setPoolsize(Integer.parseInt(mCharacterData.toString()));
			}
			catch (NumberFormatException e)
			{
				throw new XmlErrorException("The value of the poolsize isn't an integer.", e);
			}
		}
	}
