namespace CCNetConfig.Components.Wizards
{
    /// <summary>
    /// Provides an easy way to configure the auditing.
    /// </summary>
    public partial class SecurityXmlAuditingWizardPage : WizardPage
    {
        #region Constructors
        /// <summary>
        /// Initialises a new instance of a <see cref="SecurityAuditingWizardPage"/>.
        /// </summary>
        public SecurityXmlAuditingWizardPage()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Initialiases a new instance of a <see cref="SecurityAuditingWizardPage"/> and links it
        /// with the previous page.
        /// </summary>
        /// <param name="previousPage"></param>
        public SecurityXmlAuditingWizardPage(WizardPage previousPage)
            : base(previousPage)
        {
            InitializeComponent(); 
        }
        #endregion

        #region Private methods
        #region auditingAllowing_CheckedChanged()
        /// <summary>
        /// Sets the state of the rest of the settings.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void auditingAllowing_CheckedChanged(object sender, EventArgs e)
        {
            auditProperties.Enabled = auditingAllowing.Checked;
        }
        #endregion
        #endregion
    }
}

namespace CCNetConfig.UI.Wizards
{
    partial class XmlAuditingConfiguration
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.xmlSettings = new System.Windows.Forms.GroupBox();
            this.auditFailed = new System.Windows.Forms.CheckBox();
            this.auditSuccessful = new System.Windows.Forms.CheckBox();
            this.useXmlAuditing = new System.Windows.Forms.CheckBox();
            this.xmlSettings.SuspendLayout();
            this.SuspendLayout();
            // 
            // xmlSettings
            // 
            this.xmlSettings.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.xmlSettings.Controls.Add(this.auditFailed);
            this.xmlSettings.Controls.Add(this.auditSuccessful);
            this.xmlSettings.Enabled = false;
            this.xmlSettings.Location = new System.Drawing.Point(13, 13);
            this.xmlSettings.Name = "xmlSettings";
            this.xmlSettings.Size = new System.Drawing.Size(559, 300);
            this.xmlSettings.TabIndex = 0;
            this.xmlSettings.TabStop = false;
            // 
            // auditFailed
            // 
            this.auditFailed.AutoSize = true;
            this.auditFailed.Checked = true;
            this.auditFailed.CheckState = System.Windows.Forms.CheckState.Checked;
            this.auditFailed.Location = new System.Drawing.Point(14, 46);
            this.auditFailed.Name = "auditFailed";
            this.auditFailed.Size = new System.Drawing.Size(117, 17);
            this.auditFailed.TabIndex = 1;
            this.auditFailed.Text = "Audit Failed Events";
            this.auditFailed.UseVisualStyleBackColor = true;
            // 
            // auditSuccessful
            // 
            this.auditSuccessful.AutoSize = true;
            this.auditSuccessful.Location = new System.Drawing.Point(14, 23);
            this.auditSuccessful.Name = "auditSuccessful";
            this.auditSuccessful.Size = new System.Drawing.Size(141, 17);
            this.auditSuccessful.TabIndex = 0;
            this.auditSuccessful.Text = "Audit Successful Events";
            this.auditSuccessful.UseVisualStyleBackColor = true;
            // 
            // useXmlAuditing
            // 
            this.useXmlAuditing.AutoSize = true;
            this.useXmlAuditing.Location = new System.Drawing.Point(27, 13);
            this.useXmlAuditing.Name = "useXmlAuditing";
            this.useXmlAuditing.Size = new System.Drawing.Size(152, 17);
            this.useXmlAuditing.TabIndex = 1;
            this.useXmlAuditing.Text = "Use XML Auditing Logging";
            this.useXmlAuditing.UseVisualStyleBackColor = true;
            this.useXmlAuditing.CheckedChanged += new System.EventHandler(this.useXmlAuditing_CheckedChanged);
            // 
            // XmlAuditingConfiguration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.useXmlAuditing);
            this.Controls.Add(this.xmlSettings);
            this.Name = "XmlAuditingConfiguration";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.Size = new System.Drawing.Size(585, 326);
            this.xmlSettings.ResumeLayout(false);
            this.xmlSettings.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox xmlSettings;
        private System.Windows.Forms.CheckBox auditFailed;
        private System.Windows.Forms.CheckBox auditSuccessful;
        private System.Windows.Forms.CheckBox useXmlAuditing;
    }
}

namespace CCNetConfig.UI.Wizards
{
    /// <summary>
    /// Custom configuration settings for XML auditing.
    /// </summary>
    public partial class XmlAuditingConfiguration : UserControl
    {
        #region Constructors
        /// <summary>
        /// Initialise a new instance of <see cref="XmlAuditingConfiguration"/>.
        /// </summary>
        public XmlAuditingConfiguration()
        {
            InitializeComponent();
        }
        #endregion

        #region Public methods
        #region GenerateConfig()
        /// <summary>
        /// Generates the configuration.
        /// </summary>
        /// <returns>The new configuration.</returns>
        public virtual FileXmlLogger GenerateConfig()
        {
            FileXmlLogger logger = null;
            if (useXmlAuditing.Checked && (auditFailed.Checked || auditSuccessful.Checked))
            {
                logger = new FileXmlLogger
                {
                    LogFailureEvents = auditFailed.Checked,
                    LogSuccessfulEvents = auditSuccessful.Checked
                };
            }
            return logger;
        }
        #endregion

        #region GenerateDescription()
        /// <summary>
        /// Generates the configuration.
        /// </summary>
        /// <returns>The new configuration.</returns>
        public virtual string GenerateDescription()
        {
            var description = "No XML auditing";
            if (useXmlAuditing.Checked && (auditFailed.Checked || auditSuccessful.Checked))
            {
                if (auditFailed.Checked)
                {
                    if (auditSuccessful.Checked)
                    {
                        description = "XML logging for all events";
                    }
                    else
                    {
                        description = "XML logging for failed events only";
                    }
                }
                else
                {
                    description = "XML logging for successful events only";
                }
            }
            return description;
        }
        #endregion
        #endregion

        #region Private methods
        #region useXmlAuditing_CheckedChanged()
        /// <summary>
        /// Change the enabled status of the settings.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void useXmlAuditing_CheckedChanged(object sender, EventArgs e)
        {
            xmlSettings.Enabled = useXmlAuditing.Checked;
        }
        #endregion
        #endregion
    }
}

namespace CCNetConfig.Components.Wizards
{
    partial class SecurityXmlAuditingWizardPage
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.auditingAllowing = new System.Windows.Forms.CheckBox();
            this.auditProperties = new System.Windows.Forms.GroupBox();
            this.logLocationButton = new System.Windows.Forms.Button();
            this.logLocation = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.isDefaultReader = new System.Windows.Forms.CheckBox();
            this.canLogFailure = new System.Windows.Forms.CheckBox();
            this.canLogSuccess = new System.Windows.Forms.CheckBox();
            this.auditProperties.SuspendLayout();
            this.SuspendLayout();
            // 
            // auditingAllowing
            // 
            this.auditingAllowing.AutoSize = true;
            this.auditingAllowing.Checked = true;
            this.auditingAllowing.CheckState = System.Windows.Forms.CheckState.Checked;
            this.auditingAllowing.Location = new System.Drawing.Point(17, 75);
            this.auditingAllowing.Name = "auditingAllowing";
            this.auditingAllowing.Size = new System.Drawing.Size(178, 17);
            this.auditingAllowing.TabIndex = 0;
            this.auditingAllowing.Text = "Log Audit Events to an XML File";
            this.auditingAllowing.UseVisualStyleBackColor = true;
            this.auditingAllowing.CheckedChanged += new System.EventHandler(this.auditingAllowing_CheckedChanged);
            // 
            // auditProperties
            // 
            this.auditProperties.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.auditProperties.Controls.Add(this.logLocationButton);
            this.auditProperties.Controls.Add(this.logLocation);
            this.auditProperties.Controls.Add(this.label1);
            this.auditProperties.Controls.Add(this.isDefaultReader);
            this.auditProperties.Controls.Add(this.canLogFailure);
            this.auditProperties.Controls.Add(this.canLogSuccess);
            this.auditProperties.Location = new System.Drawing.Point(3, 75);
            this.auditProperties.Name = "auditProperties";
            this.auditProperties.Size = new System.Drawing.Size(519, 192);
            this.auditProperties.TabIndex = 1;
            this.auditProperties.TabStop = false;
            // 
            // logLocationButton
            // 
            this.logLocationButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.logLocationButton.Location = new System.Drawing.Point(488, 90);
            this.logLocationButton.Name = "logLocationButton";
            this.logLocationButton.Size = new System.Drawing.Size(25, 23);
            this.logLocationButton.TabIndex = 5;
            this.logLocationButton.Text = "...";
            this.logLocationButton.UseVisualStyleBackColor = true;
            // 
            // logLocation
            // 
            this.logLocation.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.logLocation.Location = new System.Drawing.Point(89, 92);
            this.logLocation.Name = "logLocation";
            this.logLocation.Size = new System.Drawing.Size(393, 20);
            this.logLocation.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Log Location:";
            // 
            // isDefaultReader
            // 
            this.isDefaultReader.AutoSize = true;
            this.isDefaultReader.Checked = true;
            this.isDefaultReader.CheckState = System.Windows.Forms.CheckState.Checked;
            this.isDefaultReader.Location = new System.Drawing.Point(14, 69);
            this.isDefaultReader.Name = "isDefaultReader";
            this.isDefaultReader.Size = new System.Drawing.Size(176, 17);
            this.isDefaultReader.TabIndex = 2;
            this.isDefaultReader.Text = "This is the Default Audit Reader";
            this.isDefaultReader.UseVisualStyleBackColor = true;
            // 
            // canLogFailure
            // 
            this.canLogFailure.AutoSize = true;
            this.canLogFailure.Checked = true;
            this.canLogFailure.CheckState = System.Windows.Forms.CheckState.Checked;
            this.canLogFailure.Location = new System.Drawing.Point(14, 46);
            this.canLogFailure.Name = "canLogFailure";
            this.canLogFailure.Size = new System.Drawing.Size(111, 17);
            this.canLogFailure.TabIndex = 1;
            this.canLogFailure.Text = "Log Failed Events";
            this.canLogFailure.UseVisualStyleBackColor = true;
            // 
            // canLogSuccess
            // 
            this.canLogSuccess.AutoSize = true;
            this.canLogSuccess.Checked = true;
            this.canLogSuccess.CheckState = System.Windows.Forms.CheckState.Checked;
            this.canLogSuccess.Location = new System.Drawing.Point(14, 23);
            this.canLogSuccess.Name = "canLogSuccess";
            this.canLogSuccess.Size = new System.Drawing.Size(135, 17);
            this.canLogSuccess.TabIndex = 0;
            this.canLogSuccess.Text = "Log Successful Events";
            this.canLogSuccess.UseVisualStyleBackColor = true;
            // 
            // SecurityXmlAuditingWizardPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.auditingAllowing);
            this.Controls.Add(this.auditProperties);
            this.HeaderText = "These settings allow you to configure using an XML file for auditing.";
            this.HeaderTitle = "XML File Auditing";
            this.HeaderTitleFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IsHeaderVisible = true;
            this.Name = "SecurityXmlAuditingWizardPage";
            this.Size = new System.Drawing.Size(525, 270);
            this.auditProperties.ResumeLayout(false);
            this.auditProperties.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox auditingAllowing;
        private System.Windows.Forms.GroupBox auditProperties;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox isDefaultReader;
        private System.Windows.Forms.CheckBox canLogFailure;
        private System.Windows.Forms.CheckBox canLogSuccess;
        private System.Windows.Forms.Button logLocationButton;
        private System.Windows.Forms.TextBox logLocation;
    }
}

        private void OnCheckChanged(object sender, EventArgs e)
        {
            if (securityModeNode.Checked)
            {
                modeDescription.Text = securityModeNode.Tag.ToString();
                ProgressWizardPage progressPage = new ProgressWizardPage(this);
                FinishedWizardPage finishPage = new FinishedWizardPage(progressPage);
            }
            if (securityModeInternal.Checked)
            {
                modeDescription.Text = securityModeInternal.Tag.ToString();
                SecurityDefaultsWizardPage defaultsPage = new SecurityDefaultsWizardPage(this);
                SecurityCacheWizardPage cachePage = new SecurityCacheWizardPage(defaultsPage);
                SecurityXmlAuditingWizardPage xmlAuditingPage = new SecurityXmlAuditingWizardPage(cachePage);
                ProgressWizardPage progressPage = new ProgressWizardPage(xmlAuditingPage);
                FinishedWizardPage finishPage = new FinishedWizardPage(progressPage);
            }
        }
        #endregion
        #endregion
    }
}
