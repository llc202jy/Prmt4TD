*
     * Idle (Main) loop of the node manager.
     * Monitor the node for fault detection and recovery and detect cluster
     * membership change or client request.
     * We give up if there is more than MAX_ERROR to recover a problem or
     * if the node cannot be running after a RUNTIME_TIMEOUT period of time.
     */
    private void idle() throws ManagedServiceException {

        Timeout timeout = new Timeout(RUNTIME_TIMEOUT);
        Timeout logTimeout = new Timeout(CMM.LOGGING_INTERVAL);
        int decay = 0;
        int nbErrors = 0;

        while (nbErrors < MAX_ERRORS && !stopRequested) {
            if (decay >= MONITOR_GRACE_PERIOD) {
                // we reach the end of the monitoring alert period.
                if (nbErrors != 0) {
                    logger.warning("ClusterMgmt - LEAVING ALERT PERIOD");
                }
                decay = 0;
                nbErrors = 0;
            }
            int delay = MONITOR_DELAY;
            try {
                if (monitor()) {
                    // the node needs attention -
                    // enter monitoring alert period.
                    delay = POLL_DELAY;
                } else {
                    decay++;
                    timeout.arm();
                }
            } catch (ManagedServiceException e) {
                if (nbErrors == 0) {
                    logger.warning("ClusterMgmt - ENTERING ALERT PERIOD");
                    timeout.arm();
                }
                delay = POLL_DELAY;
                nbErrors++;
            }

            /*
             * Publish the node mgr proxy and sleep for the requested delay.
             */
            try {
                publish();
                Thread.currentThread().sleep(delay);
            } catch (Exception e) {
                logger.severe("failed to publish proxy " + e.getMessage());
                nbErrors++;
            }

            /*
             * Detect failure (include our own latency thread issue) and
             * give up if the node has been unhealthy for too long.
             * FIXME - we should not care if we are in maintenance or not.
             * node restarting issue ?
             */
            if (!isInMaintenance && timeout.hasExpired()) {
                logger.warning("ClusterMgmt - FAILURE  DETECTED ??");
                try {
                    if (!monitor()) {
                        threadLatencyWarning();
                    } else {
                        break;
                    }
                } catch (ManagedServiceException e) {
                    break;
                }
                timeout.arm();
            }

            /*<
             * Flush the output of the processes -
             * if a process died, we will report the error
             * during the next round.
             */
            List jvms = config.getJVMs();
            for (int i = 0; i < jvms.size(); i++) {
                JVMProcess jvm = (JVMProcess) jvms.get(i);
                try {
                    jvm.flushOutput();
                } catch (Exception e) {
                    if (logger.isLoggable (Level.INFO)) {
                        logger.info("ClusterMgmt - process " + jvm + " died");
                        StackTraceElement[] lines = e.getStackTrace();
                        for (int j = 0; j < lines.length; j++) {
                            logger.info ("TRACE: " + lines[j]);
                        }
                    }
                }
            }

            /*
             * Log current state of the node.
             */
            if (logTimeout.hasExpired()) {
                StringBuffer msg = new StringBuffer ("ClusterMgmt - Quorum: [");
                msg.append (hasQuorum);
                msg.append ("] FailureTolerance: [");
                msg.append (failureTolerance);
                msg.append ("] ForceMaintenance: [");
                msg.append (forceMaintenance.booleanValue());
                msg.append ("] Mode: [");
                msg.append ((isInMaintenance ? "MAINTENANCE]" : "DATA]"));
                logger.info(msg.toString());
                logTimeout.arm();
            }
        }

        logger.info("ClusterMgmt - NodeMgr is exiting from idle loop");
        if (nbErrors >= MAX_ERRORS) {
            logger.severe("ClusterMgmt - **** NODE HAS TOO MANY FAILURES ****");
            ResourceBundle rs = BundleAccess.getInstance().getBundle();
            String str = rs.getString("err.cm.node_mgr.NodeMgr.toomanyfailures");
            logger.log(ExtLevel.EXT_SEVERE, str);
        }

        shutdown_sequence();
    }


    /**
     * Monitor the node/cell and update the state of the node accordingly.
     * Returns true if the node needs attention due to recoverable
     * error conditions. Generates a ManagedServiceException in case of
     * unexpected error.
     */
    synchronized private boolean monitor() throws ManagedServiceException {

        /*
         * Remember the current state, it's about to get updated
         */
        boolean wasMaster = isMaster;
        boolean hadQuorum = hasQuorum;
        boolean wasInMaintenance = isInMaintenance;
        boolean wasAcceptingRequests = isAcceptingRequests;


        /*
         * Check and update CMM view and update maintenanceTimeout if necessary
         */
        int aliveNodes = updateCMM();
        if (hasQuorum) {
            maintenanceTimeout.disable();
        } else {
            if (maintenanceTimeout.isDisabled()) {
                maintenanceTimeout.arm();                        
            }
        }

        /*
         * Check number of unrecovered disk failures
         */
        checkUnhealedFailures();

        /*
         * Do we need to start/stop master services on this node ?
         */
        if (wasMaster != isMaster) {
            ServiceMailbox[] svc = config.getServices();
            if (isMaster) {
                for (int i = 0; i < svc.length; i++) {
                    if (svc[i].isPartOf(ALL_MASTER_SERVICES)) {
                        /*
                         * a service can be part of multiple services groups
                         * (master and i/o) - only start the right ones.
                         */
                        if (!isInMaintenance || !svc[i].isPartOf(IO_SERVICES)) {
                            svc[i].setManaged(true);
                        }
                    }
                }
                logger.info("ClusterMgmt - *** STARTING MASTER SERVICES ***");
                startServices(ALL_MASTER_SERVICES);
            } else {
                logger.info("ClusterMgmt - *** STOPPING MASTER SERVICES ***");
                stopServices(ALL_MASTER_SERVICES, 1);
                for (int i = 0; i < svc.length; i++) {
                    if (svc[i].isPartOf(ALL_MASTER_SERVICES)) {
                        svc[i].setManaged(false);
                    }
                }
            }
        }


        /*
         * Do we need to enter/leave maintenance mode (stop/start data-path)?
         */
        if (!failureTolerance || forceMaintenance.booleanValue()) {
            isInMaintenance = true;
        } else if (!hasQuorum) {
            if (!maintenanceTimeout.hasExpired()) {
                if (!isInMaintenance) {
                    logger.info("ClusterMgmt - Lost quorum, wait for grace " +
                      " period before entering maintenance mode");
                }
            } else {
                isInMaintenance = true;
            }
        } else {
            isInMaintenance = false;
        }

        if (wasInMaintenance != isInMaintenance) {
            ServiceMailbox[] svc = config.getServices();
            if (isInMaintenance) {
                logger.info("ClusterMgmt - *** STOPPING DATA SERVICES ***");
                stopServices(IO_SERVICES, 1);
                for (int i = 0; i < svc.length; i++) {
                    if (svc[i].isPartOf(IO_SERVICES)) {
                        svc[i].setManaged(false);
                    }
                }
            } else {
                logger.info("ClusterMgmt - *** STARTING DATA SERVICES ***");
                for (int i = 0; i < svc.length; i++) {
                    if (svc[i].isPartOf(IO_SERVICES)) {
                        if (isMaster || !svc[i].masterOnly()) {
                            svc[i].setManaged(true);
                        }
                    }
                }
                startServices(IO_SERVICES);

                // This will make sure that the following code will
                // detect that we are accepting requests and if so
                // do something about it...
                wasAcceptingRequests = true;
            }
        }

        /*
         * Do we need to stop/start API services
         */
        if (!isInMaintenance) {
            isAcceptingRequests = ClusterPropertiesInterpreter.acceptRequests();
            if (wasAcceptingRequests != isAcceptingRequests) {
                ServiceMailbox[] svc = config.getServices();
                if (!isAcceptingRequests) {
                    logger.info("ClusterMgmt - *** STOPPING API ACCESS SERVICES ***");
                    stopServices(API_SERVICES, 1);
                    for (int i = 0; i < svc.length; i++) {
                        if (svc[i].isPartOf(API_SERVICES)) {
                            svc[i].setManaged(false);
                        }
                    }
                } else {
                    logger.info("ClusterMgmt - *** STARTING API ACCESS SERVICES ***");
                    for (int i = 0; i < svc.length; i++) {
                        if (svc[i].isPartOf(API_SERVICES)) {
                            if (isMaster || !svc[i].masterOnly()) {
                                svc[i].setManaged(true);
                            }
                        }
                    }
                    startServices(API_SERVICES);
                }
            }
        }

        /*
         * FIXME - this is not the right way to do it.
         * Use an nodeMgrRequest object to synchronize client request
         * with the node manager. A client posts a request and the node
         * manager does the actual action and notify the client upon
         * completion.
         */
        if (wasInMaintenance != isInMaintenance) {
            synchronized (forceMaintenance) {
                if (maintenanceThr != null) {
                    logger.info("ClusterMgmt - notify maintenance thread");
                    maintenanceNotified = true;
                    forceMaintenance.notify();
                }
            }
        }

        /*
         * Monitor and recover HC services.
         */
        ServiceMailbox[] svc = config.getServices();
        boolean failed = false;
        for (int i = 0; i < svc.length; i++) {
            try {
                if (svc[i].isManaged()) {
                    // FIXME - we should not have to use a restart flag -
                    // This is useless as it tries to cover a corner case
                    // that can happen anyway.
                    boolean restart = !stopRequested;
                    if (!svc[i].monitor(restart)) {
                        failed = true;
                        break;
                    }
                } else if (svc[i].isRunning()) {
                    logger.warning("ClusterMgmt - found service " +
                                   svc[i].getName() +
                                   " running - should be disabled"
                                   );
                    if (svc[i].isJVM()) {
                        JVMProcess jvm = config.getJVM(svc[i]);
                        if (jvm.safeToShutdown()) {
                            jvm.shutdown();
                        }
                    } else {                    
                        svc[i].stop();
                    }
                }
            } catch (Exception e) {
                logger.severe("ClusterMgmt - " + e.getMessage());
                if (svc[i].getLevel() == 0) {
                    logger.severe("ClusterMgmt - ESCALATION - EXITING");
                    shutdown_sequence();
                }
                JVMProcess jvm = config.getJVM(svc[i]);
                // FIXME - shutdown services that are still running.
                jvm.restart();
                startServices(ALL_SERVICES);
                throw new ManagedServiceException(e);
            }
        }

        /*
         * It is an error to have less than the required number of nodes.
         * In this case we want to wait here for a master or timeout and
         * trigger an exception.
         */
        if (!CMM.isSingleMode() && aliveNodes < MIN_NODES) {
            logger.severe("*** CLUSTER CONFIG and NODE ALONE ***");
            waitForMaster();
        }

        return failed;
    }


    /**
     * Update the node manager view of CMM and trigger the appropriate
     * actions according to the new state.
     * We lost quorum after a grace period to account for transient software 
     * failures; Node can leave/join CMM ring due to missed heartbeat, 
     * PLATFORM jvm can get killed and restarted.     
     * @return the number of active nodes.
     */
    synchronized private int updateCMM() throws ManagedServiceException {
        try {
            cmmNodes = CMM.getAPI().getNodes();
            if (CMM.getAPI().hasQuorum()) {
                hasQuorum = true;
            } else {
                hasQuorum = false;
            }
        } catch (CMMException e) {
            logger.log(Level.SEVERE,
                       "ClusterMgmt - ERROR lost connection with CMM", e
                       );
            throw new ManagedServiceException(e);
        }

        /*
         * Check if this node is elected/demoted master and
         * count the number of nodes alive in the ring.
         */
        isMaster = false;
        int aliveCount = 0;
        for (int i = 0; i < cmmNodes.length; i++) {
            if (cmmNodes[i].isAlive()) {
                aliveCount++;
            }
            if (cmmNodes[i].isMaster() &&
                localnode == cmmNodes[i].nodeId()) {
                isMaster = true;
            }
        }
        return aliveCount;
    }


    /**
     * check if Unhealed Failure Count is within our tolerance
     */
    private void checkUnhealedFailures() {

        ClusterProperties config = ClusterProperties.getInstance();

        // do not change the current value if
        // - config unavailable
        // - we have configured this check off (dev only!)
        // - we don't have the quorum
        if (config == null || !doFailureCheck || !hasQuorum) {
            return;
        }

        boolean oldFailureTolerance = failureTolerance;
        failureTolerance = !config.getPropertyAsBoolean
            (ConfigPropertyNames.PROP_DATA_LOSS);

        if (oldFailureTolerance != failureTolerance) {
            if (!failureTolerance) {
                logger.severe("failureTolerance above limit, too many "+
                              "unhealed disk failures, possible data loss!"
                              );
            } else {
                logger.info("failureTolerance now within limit - " +
                "no possible lost data");
            }
        }
    }

    /**
     * Wait for a master to show up.
     * A master needs to be elected within a limited period of time
     * otherwise this method triggers an error (java exception)
     */
    private void waitForMaster() throws ManagedServiceException {
        Timeout timeout = new Timeout(RUNTIME_TIMEOUT);
        while (true) {
            try {
                cmmNodes = CMM.getAPI().getNodes();
            } catch (CMMException e) {
                logger.log(Level.SEVERE,
                           "ClusterMgmt - ERROR lost connection with CMM",
                           e);
                throw new RuntimeException (e);
            }
            
            int aliveCount = 0;
            boolean hasMaster = false;
            for (int i = 0; i < cmmNodes.length; i++) {
                if (cmmNodes[i].isAlive()) {
                    aliveCount++;
                }
                if (cmmNodes[i].isMaster()) {
                    hasMaster = true;
                }
            }
            if (hasMaster && (CMM.isSingleMode() || aliveCount >= MIN_NODES)) {
                return;
            }

            logger.warning("ClusterMgmt - *** NO MASTER FOUND ***");
            if (timeout.hasExpired()) {
                throw new ManagedServiceException("- timeout escalation -");
            }
            try {
                Thread.currentThread().sleep(CMM.HEARTBEAT_TIMEOUT);
            } catch (InterruptedException ie) {
                throw new RuntimeException(ie);
            }
        }
    }


    private void threadLatencyWarning() {
        PlatformService.Proxy platform = PlatformService.Proxy.getProxy();
        if (platform == null) {
            logger.warning("ClusterMgmt - platform proxy not available");
            return;
        }
        SystemInfo sysinfo = platform.getSystemInfo();
        MemoryInfo meminfo = platform.getMemoryInfo();
        DecimalFormat formatter = new DecimalFormat("###.##");
        logger.warning("ClusterMgmt - High Thread Latency - Load average: " +
                       formatter.format(sysinfo.get1MinLoad()) + ", " +
                       formatter.format(sysinfo.get5MinLoad()) + ", " +
                       formatter.format(sysinfo.get15MinLoad()));
    }


    /**
     * Shutdown sequence: stop services, JVMs, services in this JVM
     */
    private void shutdown_sequence() {
        try {
            if (isMaster) {
                stopServices(MASTER_SERVICES, 1);
            }
            stopServices(ALL_SERVICES, 1);

            ResourceBundle rs = BundleAccess.getInstance().getBundle();
            String str = rs.getString("info.cm.services.shutdown");
            Object [] args = {new Integer (localnode)};
            logger.log(ExtLevel.EXT_INFO, MessageFormat.format(str, args));

        } catch (ManagedServiceException e) {
            logger.warning("ClusterMgmt - failed to stop services cleanly: " + e);
        }

        stopJVMs(); // other JVMs, not us

        cleanShutdownCompleted = true;
        synchronized(shutdownThr) {
            /*
             * A reboot / powerOff has been initiated, let the shutdown thread
             * powerOff/reboot the node, and simply return.
             */
            if (shutdownThr.isWaiting()) {
                shutdownThr.notify();
                logger.info("ClusterMgmt - ***** NODE SHUTDOWN COMPLETED " +
                            "SUCCESSFULLY ****");
                return;
            }
        }
        super.shutdown(); // stop level-zero services in our JVM
        logger.info("ClusterMgmt - ***** NODE SHUTDOWN COMPLETED SUCCESSFULLY ****");
        System.exit(1);
    }


    /**
     * Shutdown hook - reboot the system by default, or drop to the shell
     * if we are in debug mode or explicit stop was requested.
     *
     * The default behavior on NodeMgr's exit is to reboot the node to clear
     * potential bad state. It's not necessary to kill child JVMs in this case
     * because reboot will destroy them all.
     * If an external entity (like greenline) is programmed to restart NodeMgr,
     * it may try to do so in a race with reboot, but reboot will of course win.
     * Note: shutdown hooks are NOT guaranteed to execute if the JVM is
     * exiting on crash, so for full confidence we need an external reboot
     * mechanism to clear bad state.
     * In debug mode, NodeMgr will exit, the node will not reboot. This is
     * consistent with intentional shutdown of our process (greenline's
     * "svcadm disable" or user's "pkill java").
     * In case of crash, only NodeMgr may exit, but child JVMs will remain
     * running.
     * NodeMgr may be restarted by an external entity (greenline), and will
     * create new child JVMs.
     * For debug mode's sake, we may want to add code to kill child PIDs on
     * shutdown.
     *
     */
    private class Shutdown extends Thread {

        final int SHUTDOWN = 1;
        final int REBOOT   = 2;
        final int POWEROFF = 3;

        private int doAction;
        private boolean isWaiting;

        public Shutdown() {
            super();
            doAction = SHUTDOWN;
            isWaiting = false;
        }

        public void run() {
            switch (doAction) {

            case SHUTDOWN:
                if (stopRequested) {
                    logger.info(
                       "ClusterMgmt - EXPLICIT STOP REQUEST - WILL NOT REBOOT");
                    return;
                }
                System.exit(0);
                return;

            case REBOOT:
                logger.info("ClusterMgmt - **** NODE REBOOT REQUESTED ****");
                stopRequested = true;
                if (!waitForShutdownSequence()) {
                    logger.warning("ClusterMgmt - *** CLEAN SHUTDOWN TIMED OUT... ");
                }
                // The JVM exits at this point and let GL take any appropriate
                // action, such as rebooting the node.
                System.exit(0);
                return;

            case POWEROFF:
                logger.info("ClusterMgmt - **** NODE POWEROFF REQUESTED ****");
                stopRequested = true;
                if (!waitForShutdownSequence()) {
                    logger.warning("ClusterMgmt - *** CLEAN SHUTDOWN TIMED OUT... ");
                }
                _powerOff();
                return;

            default:
                logger.severe("ClusterMgmt - internal error");
                return;
            }
        }

        boolean isWaiting() {
            return isWaiting;
        }

        synchronized void shutdown() {
            doAction = SHUTDOWN;
            super.start();
        }

        synchronized void reboot() {
            doAction = REBOOT;
            super.start();
        }

        synchronized void powerOff() {
            doAction = POWEROFF;
            super.start();
        }

        private boolean waitForShutdownSequence() {
            synchronized(this) {
                try {
                    isWaiting = true;
                    wait(SHUTDOWN_TIMEOUT);
                } catch (InterruptedException ignore) {
                    logger.warning("ClusterMgmt - Shutdown thread has been " +
                                   "interrupted...");
                }
                isWaiting = false;
            }
            return cleanShutdownCompleted;
        }

        private void _reboot() {
            String str = BundleAccess.getInstance().getBundle().getString("info.cm.node.reboot");
            Object [] args = {new Integer (localnode)};
            logger.log(ExtLevel.EXT_INFO, MessageFormat.format(str, args));

            logger.info("\n\nClusterMgmt - *** NODE IS REBOOTING ***");

            try {
                Commands cmds = Commands.getCommands();
                Exec.exec(cmds.reboot() + "-n", logger);
            } catch (Exception e) {
                logger.severe("ClusterMgmt - ERROR failed to reboot node");
            }
        }

        private void _powerOff() {

            String str = BundleAccess.getInstance().getBundle().getString("info.cm.node.shutdown");
            Object [] args = {new Integer (localnode)};
            logger.log(ExtLevel.EXT_INFO, MessageFormat.format(str, args));

            logger.info ("\n\nClusterMgmt - *** NODE IS POWERING DOWN ***");
            //FIXME: Platform needs to be moved to runlevel 0 and
            //      this code changed to invoke Platform.powerOff()
            //      instead of relying on exec'ing shutdown
            try {
                Commands cmds = Commands.getCommands();
                Exec.exec(cmds.poweroff(), logger);
            } catch (Exception e) {
                logger.severe("ClusterMgmt - ERROR failed to reboot node");
            }
        }
    }


    /**
     * Main entry point of honeycomb
     */
    static public void main(String args[]) {

        if (ServiceManager.initNodeMgr() == false) {
            logger.severe("ClusterMgmt - ERROR failed to init contract template");
        }

        logger.info("***** HONEYCOMB IS STARTING UP *****");
        try {            
            /*
             * initialize and start CMM
             */
            String hostName = CMM.start();
            
            /*
             * setup node manager configuration tunables.
             */
            ClusterProperties properties = ClusterProperties.getInstance();
            
            doFailureCheck = properties.getPropertyAsBoolean
                (ConfigPropertyNames.PROP_CM_FAILURE_CHECK);
            
            if (!doFailureCheck) {
                failureTolerance = true;
                logger.info ("ClusterMgmt - unhealed disk failure "+
                             "checking disabled");
            } else {
                failureTolerance = !properties.getPropertyAsBoolean
                    (ConfigPropertyNames.PROP_DATA_LOSS);
                
                if (!failureTolerance) {
                    logger.warning ("ClusterMgmt - too many unhealed failures"+
                                    " starting checker + maintenance mode");
                }
            }
            
            /*
             * Iinitialize distributed IPC for this node.
             */
            localnode = CMM.nodeId();
            if (Mailbox.initIPC(localnode, 1) != 0) {
                throw new Error("Cannot initialize IPC for local node");
            }
            
            /*
             * parse the node configuration and build
             * the list of JVMs and services running on that node.
             */
            NodeConfig config = NodeConfig.getInstance();
            
            /*
             * fire up the node manager agent
             */
            ServiceMailbox nodemgr = config.getService(NodeMgr.class);
            if (nodemgr == null) {
                throw new Error("ClusterMgmt class is missing from config");
            }

            logger.info("ClusterMgmt - Starting NodeMgr Agent...");
            createAgent(hostName, NodeMgr.class, nodemgr.getTag());
            
            /*
             * be sure the node manager is running before
             * the main thread exits.
             */
            Timeout timeout = new Timeout(NODEMGR_STARTUP_TIMEOUT);
            nodemgr.setInitRqstReady();
            do {
                if (timeout.hasExpired()) {
                    logger.severe("ClusterMgmt - Cannot start node manager");
                    System.exit(1);
                }
                if (nodemgr.isReady()) {
                    timeout.arm();
                    nodemgr.rqstRunning();
                }
                try {
                    Thread.currentThread().sleep(POLL_DELAY);
                } catch (InterruptedException ie) {
                    throw new RuntimeException(ie);
                }
            } while (!nodemgr.isRunning());

        } catch (Exception e) {
            logger.log(Level.SEVERE,
                       "ClusterMgmt - ERROR failed to start node manager", e
                       );
            throw new Error(e);
        }
    }
}