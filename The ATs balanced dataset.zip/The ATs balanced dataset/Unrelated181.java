void waitForConnection()
	throws DatabaseException
	{void waitForConnection()
	throws DatabaseException
	{/**
	
 * @version $Revision: 3884 $
 * @see DbPreparedStatement
 * @see DbQueryManager
 * @since 1.0
 */
public abstract class DbPreparedStatementHandler<DataType> extends DbResultSetHandler
{
	protected DataType  mData = null;
	
	public DbPreparedStatementHandler()
	{
	}
	
	public DbPreparedStatementHandler(DataType data)
	{
		mData = data;
	}
	
	public DataType getData()
	{
		return mData;
	}
	
	public void setParameters(DbPreparedStatement statement)
	{
	}
	
	public int performUpdate(DbPreparedStatement statement)
	{
		setParameters(statement);
		return statement.executeUpdate();
	}
	
	public void performQuery(DbPreparedStatement statement)
	{
		setParameters(statement);
		statement.executeQuery();
	}
}ASM: a very small and fast Java bytecode manipulation framework
 * Copyright (c) 2000-2005 INRIA, France Telecom
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.uwyn.rife.asm.attrs;

import com.uwyn.rife.asm.Label;

/**
 * Verification type info used by {@link StackMapAttribute}.
 * 
 * @see <a href="http://www.jcp.org/en/jsr/detail?id=139">JSR 139 : Connected
 *      Limited Device Configuration 1.1</a>
 * 
 * @see "ClassFileFormat-Java6.fm Page 138 Friday, April 15, 2005 3:22 PM"
 * 
 * @author Eugene Kuleshov
 */ * @param localName the local name of the ending element
	 * @param qName the qualified name of the ending element
	 * @since 1.0
	 */
	public void endElement(String namespaceURI, String localName, String qName)
	{
		if (qName.equals("datasource"))
		{
			mDatasources.put(mNameAttribute, mDatasource);
		}
		else if (qName.equals("driver"))
		{
			mDatasource.setDriver(mCharacterData.toString());
		}
		else if (qName.equals("url"))
		{
			mDatasource.setUrl(mCharacterData.toString());
		}
		else if (qName.equals("user"))
		{
			mDatasource.setUser(mCharacterData.toString());
		}
		else if (qName.equals("password"))
		{
			mDatasource.setPassword(mCharacterData.toString());
		}
		else if (qName.equals("jndi"))
		{
			Context ctx;
			try
			{
				ctx = new InitialContext();

				Object ds = ctx.lookup(mCharacterData.toString());
				if (null == ds)
				{
					throw new XmlErrorException("The '"+mCharacterData.toString()+"' JNDI entry returned 'null'.");
				}
				if (!(ds instanceof DataSource))
				{
					throw new XmlErrorException("The '"+mCharacterData.toString()+"' JNDI entry isn't a DataSource.");
				}

				mDatasource.setDataSource((DataSource)ds);
			}
			catch (NamingException e)
			{
				throw new XmlErrorException("Unexpected error while looking up the '"+mCharacterData.toString()+"' JNDI entry.", e);
			}

		}
		else if (qName.equals("poolsize"))
		{
			try
			{
				mDatasource.setPoolsize(Integer.parseInt(mCharacterData.toString()));
			}
			catch (NumberFormatException e)
			{
				throw new XmlErrorException("The value of the poolsize isn't an integer.", e);
			}
		}
	}

	/**
	 * Called when text data is encountered, usually between tags.
	 *
	 * @param ch a character array of the encountered text content
	 * @param start the index in the array at which the content starts
	 * @param length the length of the data stored in the character array
	 * @since 1.0
	 */
	public void characters(char[] ch, int start, int length)
	{
		if (length > 0)
		{
			mCharacterData.append(String.copyValueOf(ch, start, length));
		}
	}
		if (mConnection.isClosed())
		{
			mConnection.handleException();
			throw new DatabaseException("The connection is not open.");
		}
		
		while (true)
		{
			if (!mConnection.isFree())
			{
				try
				{
					synchronized (mConnection)
					{
						mConnection.wait();
					}
				}
				catch (InterruptedException e)
				{
					throw new DatabaseException("Timeout while waiting for the connection to become available.");
				}
			}
			else
			{
				break;
			}
		}
	}

	/**
	 * Checks if there's a <code>ResultSet</code> object present.
	 *
	 * @return <code>true</code> if a <code>ResultSet</code> object is
	 * available; or
	 * <p><code>false</code> otherwise.
	 * @since 1.0
	 */
	boolean hasResultset()
	{
		return null != mResultSet;
	}

	/**
	 * Set the current <code>ResultSet</code> object and cleans up the
	 * previous <code>ResultSet</code> object automatically.
	 *
	 * @param resultSet the new current <code>ResultSet</code> object
	 * @exception DatabaseException if a database access error occurred.
	 * @since 1.0
	 */
	protected void setResultset(ResultSet resultSet)
	throws DatabaseException
	{
		if (null == resultSet)
		{
			mResultSet = null;
		}
		else
		{
			mResultSet = wrapWithDbResultSet(resultSet);
		}
	}

	private DbResultSet wrapWithDbResultSet(ResultSet resultSet) throws DatabaseException
	{
		Class resulset_class = null;
		try
		{
			if (JavaSpecificationUtils.isAtLeastJdk16())
			{
				resulset_class = Class.forName(DbResultSet.class.getName() + "40");
			}
			else
			{
				resulset_class = Class.forName(DbResultSet.class.getName() + "30");
			}
			
			Constructor constructor = resulset_class.getDeclaredConstructor(new Class[] {DbStatement.class, ResultSet.class});
			return (DbResultSet)constructor.newInstance(new Object[] {this, resultSet});
		}
		catch (Exception e)
		{
			handleException();
			throw new DatabaseException(e);
		}
	}

	/**
	 * Cleans up and closes the current <code>ResultSet</code> object.
	 *
	 * @exception DatabaseException if a database access error occurred.
	 * @since 1.0
	 */
	void cleanResultSet()
	throws DatabaseException
	{
		if (null != mResultSet)
		{
			try
			{
				mResultSet.close();
				mResultSet = null;
			}
			catch (SQLException e)
			{
				mResultSet = null;
				close();
				throw new DatabaseException(e);
			}
		}
	}

	/**
	 * Performs the cleanup logic in case an exeception is thrown during
	 * execution. The statement will be closed and if a transaction is active,
	 * it will be automatically rolled back.
	 *
	 * @exception DatabaseException when an error occurs during the cleanup of
	 * the connection, or when an error occurs during the roll-back.
	 */
	protected void handleException()
	throws DatabaseException
	{
		synchronized (this)
		{
			try
			{
				close();
			}
			catch (DatabaseException e)
			{
				// this is a defensive close, if it can't be closed again, it
				// probably already is
			}
			
			if (mConnection.isTransactionValidForThread())
			{
				mConnection.rollback();
			}
			else
			{
				synchronized (mConnection)
				{
					mConnection.notifyAll();
				}
			}
		}
	}

	/**
	 * Ensures that this <code>DbStatement</code> is correctly closed when
	 * it's garbage collected.
	 *
	 * @exception Throwable if an error occurred during the finalization
	 * @since 1.0
	 */
	protected void finalize()
	throws Throwable
	{
		close();
		super.finalize();
	}
	
	/**
	 * Simply clones the instance with the default clone method. This creates
	 * a shallow copy of all fields and the clone will in fact just be another
	 * reference to the same underlying data. The independence of each cloned
	 * instance is consciously not respected since they rely on resources that
	 * can't be cloned.
	 *
	 * @since 1.0
	 */
	public Object clone()
	{
		try
		{
			return super.clone();
		}
		catch (CloneNotSupportedException e)
		{
			// this should never happen
			Logger.getLogger("com.uwyn.rife.database").severe(ExceptionUtils.getExceptionStackTrace(e));
			return null;
		}
	}
}


public abstract class DbTransactionUser<ResultType, DataType> implements Cloneable
{
	protected DataType  mData = null;
	
	public DbTransactionUser()
	{
	}
	
	public DbTransactionUser(DataType data)
	{
		mData = data;
	}
	
	public DataType getData()
	{
		return mData;
	}
	
	/**
	 * Should be overridden if the transaction has to be executed in another
	 * isolation level.
	 * 
	 * @return <code>-1</code> when the active isolation level should be
	 * preserved; or
	 * <p>a level constant from {@link java.sql.Connection Connection} if the
	 * isolation needs to be changed.
	 * @since 1.0
	 */
	public int getTransactionIsolation()
	{
		return -1;
	}
	
	/**
	 * Should be used to roll back ongoing transactions, otherwise enclosing
	 * transaction users might not be interrupted and subsequent modification
	 * can still happen outside the transaction.
	 * 
	 * @exception RollbackException indicates that a rollback should happen
	 * and all further transaction logic interrupted.
	 * @since 1.0
	 */
	public void rollback()
	throws RollbackException
	{
		throw new RollbackException();
	}
	
	/**
	 * Calling this method makes it possible to throw a checked exception from
	 * within this class.
	 * <p>To catch it you should surround the {@link
	 * DbQueryManager#inTransaction(DbTransactionUser) inTransaction} with a
	 * <code>try-catch</code> block that catching
	 * <code>InnerClassException</code>. The original exception is then
	 * available through <code>getCause()</code> and can for example be
	 * rethrown.
	 * 
	 * @exception InnerClassException when a checked exception needs to be
	 * thrown from within this class and caught outside the caller.
	 * @since 1.0
	 */
	public void throwException(Exception exception)
	throws InnerClassException
	{
		throw new InnerClassException(exception);
	}
	
	/**
	 * Should be implemented by all extending classes.
	 * 
	 * @since 1.0
	 */
	public abstract ResultType useTransaction() throws InnerClassException;

	/**
	 * Simply clones the instance with the default clone method since this
	 * class contains no member variables.
	 * 
	 * @since 1.0
	 */
	public Object clone()
	{
		try
		{
			return super.clone();
		}
		catch (CloneNotSupportedException e)
		{
			// this should never happen
			Logger.getLogger("com.uwyn.rife.database").severe(ExceptionUtils.getExceptionStackTrace(e));
			return null;
		}
	}

public class DbBeanFetcher<BeanType> extends DbRowProcessor
{
	private Datasource							mDatasource = null;
	private Class<BeanType>						mBeanClass = null;
	private BeanType							mLastBeanInstance = null;
	private HashMap<String, PropertyDescriptor>	mBeanProperties = new HashMap<String, PropertyDescriptor>();
	private ArrayList<BeanType>					mCollectedInstances = null;

	/**
	 * Create a new DbBeanFetcher
	 *
	 * @param datasource the datasource to be used
	 * @param beanClass the type of bean that will be handled
	 * @exception BeanException thrown if there is an error getting
	 * information about the bean via the beanClass
	 * @since 1.0
	 */
	public DbBeanFetcher(Datasource datasource, Class<BeanType> beanClass)
	throws BeanException
	{
		this(datasource, beanClass, false);
	}
	/**
	 * Create a new DbBeanFetcher
	 *
	 * @param datasource the datasource to be used
	 * @param beanClass the type of bean that will be handled
	 * @param collectInstances <code>true</code> if the fetcher should
	 * collected the bean instances; <code>false</code> if otherwise
	 * @exception BeanException thrown if there is an error getting
	 * information about the bean via the beanClass
	 * @since 1.0
	 */
       
	public DbBeanFetcher(Datasource datasource, Class<BeanType> beanClass, boolean collectInstances)
	throws BeanException
	{
		if (null == datasource) throw new IllegalArgumentException("datasource can't be null.");
		if (null == beanClass)  throw new IllegalArgumentException("beanClass can't be null.");
		
		BeanInfo bean_info = null;

		mDatasource = datasource;
		mBeanClass = beanClass;
		try
		{
			bean_info = Introspector.getBeanInfo(beanClass);
		}
		catch (IntrospectionException e)
		{
			throw new BeanException("Couldn't introspect the bean with class '"+mBeanClass.getName()+"'.", beanClass, e);
		}
		PropertyDescriptor[] bean_properties = bean_info.getPropertyDescriptors();
		for (PropertyDescriptor bean_property : bean_properties)
		{
			mBeanProperties.put(bean_property.getName().toLowerCase(), bean_property);
		}
		
		if (collectInstances)
		{
			mCollectedInstances = new ArrayList<BeanType>();
		}

		assert mDatasource != null;
		assert mBeanClass != null;
		assert null == mLastBeanInstance;
		assert mBeanProperties != null;
	}
	
	/**
	 * Process a ResultSet row into a bean. Call this method on a {@link
	 * ResultSet} and the resulting bean will be stored and be accessible
	 * via {@link #getBeanInstance()}
	 *
	 * @param resultSet the {@link ResultSet} from which to process the
	 * row
	 * @exception SQLException thrown when there is a problem processing
	 * the row
	 * @return <code>true</code> if a bean instance was retrieved; or
	 * <p><code>false</code> if otherwise
	 */
	public boolean processRow(ResultSet resultSet)
	throws SQLException
	{
		if (null == resultSet)  throw new IllegalArgumentException("resultSet can't be null.");
		
		BeanType instance = null;
		try
		{
			instance = mBeanClass.newInstance();
		}
		catch (InstantiationException e)
		{
			SQLException e2 = new SQLException("Can't instantiate a bean with class '"+mBeanClass.getName()+"' : "+e.getMessage());
			e2.initCause(e);
			throw e2;
		}
		catch (IllegalAccessException e)
		{
			SQLException e2 = new SQLException("No permission to instantiate a bean with class '"+mBeanClass.getName()+"' : "+e.getMessage());
			e2.initCause(e);
			throw e2;
		}
		
		ResultSetMetaData	meta = resultSet.getMetaData();
		String				column_name = null;
		PropertyDescriptor	property = null;
		Method				write_method = null;
		int					column_type = Types.OTHER;
		Object				typed_object = null;

		for (int i = 1; i <= meta.getColumnCount(); i++)
		{
			column_name = meta.getColumnName(i).toLowerCase();
			if (mBeanProperties.containsKey(column_name))
			{
				property = mBeanProperties.get(column_name);

				write_method = property.getWriteMethod();
				if (write_method != null)
				{
					try
					{
						column_type = meta.getColumnType(i);
						try
						{
							typed_object = mDatasource.getSqlConversion().getTypedObject(resultSet, i, column_type, property.getPropertyType());
						}
						catch (DatabaseException e)
						{
							SQLException e2 = new SQLException("Data conversion error while obtaining the typed object.");
							e2.initCause(e);
							throw e2;
						}
						
						// the sql conversion couldn't create a typed value
						if (null == typed_object)
						{
							// check if the object returned by the resultset is of the same type hierarchy as the property type
							Object column_value = resultSet.getObject(i);
							if (column_value != null &&
								property.getPropertyType().isAssignableFrom(column_value.getClass()))
							{
								typed_object = column_value;
							}
							// otherwise try to call the property type's constructor with a string argument
							else
							{
								String column_stringvalue = resultSet.getString(i);
								if (column_stringvalue != null)
								{
									try
									{
										Constructor constructor = property.getPropertyType().getConstructor(new Class[] {String.class});
										if (constructor != null)
										{
											typed_object = constructor.newInstance((Object[])new String[] {column_stringvalue});
										}
									}
									catch (SecurityException e)
									{
										instance = null;
										SQLException e2 = new SQLException("No permission to obtain the String constructor of the property with name '"+property.getName()+"' and class '"+property.getPropertyType().getName()+"' of the bean with class '"+mBeanClass.getName()+"'.");
										e2.initCause(e);
										throw e2;
									}
									catch (NoSuchMethodException e)
									{
										instance = null;
										SQLException e2 = new SQLException("Couldn't find a String constructor for the property with name '"+property.getName()+"' and class '"+property.getPropertyType().getName()+"' of the bean with class '"+mBeanClass.getName()+"'.");
										e2.initCause(e);
										throw e2;
									}
									catch (InstantiationException e)
									{
										instance = null;
										SQLException e2 = new SQLException("Can't instantiate a new instance of the property with name '"+property.getName()+"' and class '"+property.getPropertyType().getName()+"' of the bean with class '"+mBeanClass.getName()+"'.");
										e2.initCause(e);
										throw e2;
									}
								}
							}
						}
						
						// if the typed object isn't null, set the value
						if (typed_object != null)
						{
							// stored the property type
							write_method.invoke(instance, new Object[] {typed_object});
						}
					}
					catch (IllegalAccessException e)
					{
						instance = null;
						SQLException e2 = new SQLException("No permission to invoke the '"+write_method.getName()+"' method on the bean with class '"+mBeanClass.getName()+"'.");
						e2.initCause(e);
						throw e2;
					}
					catch (IllegalArgumentException e)
					{
						instance = null;
						SQLException e2 = new SQLException("Invalid arguments while invoking the '"+write_method.getName()+"' method on the bean with class '"+mBeanClass.getName()+"'.");
						e2.initCause(e);
						throw e2;
					}
					catch (InvocationTargetException e)
					{
						instance = null;
						SQLException e2 = new SQLException("The '"+write_method.getName()+"' method of the bean with class '"+mBeanClass.getName()+"' has thrown an exception");
						e2.initCause(e);
						throw e2;
					}
					catch (SQLException e)
					{
						instance = null;
						SQLException e2 = new SQLException("SQLException while invoking the '"+write_method.getName()+"' method of the bean with class '"+mBeanClass.getName()+"'");
						e2.initCause(e);
						throw e2;
					}
				}
			}
		}

		assert instance != null;
		
		mLastBeanInstance = instance;
		
		if (mCollectedInstances != null)
		{
			mCollectedInstances.add(instance);
		}

		return gotBeanInstance(instance);

	}

	/**
	 * Hook method that can be overloaded to receive new bean instances as
	 * they are retrieved, without relying on the internal collection into
	 * a list.
	 *
	 * @param instance the received bean instance
	 * @return <code>true</code> if the bean fetcher should continue to
	 * retrieve the next bean; or
	 * <p><code>false</code> if the retrieval should stop after this bean
	 * @since 1.0
	 */
	public boolean gotBeanInstance(BeanType instance)
	{
		return true;
	}
	
	/**
	 * Get the last processed bean instance
	 *
	 * @return the last processed bean instance
	 * @since 1.0
	 */
	public BeanType getBeanInstance()
	{
		return mLastBeanInstance;
	}

	/**
	 * Get the collected bean instances
	 *
	 * @return the collected bean instances
	 * @since 1.0
	 */
	public List<BeanType> getCollectedInstances()
	{
		return mCollectedInstances;
	}
		if (mConnection.isClosed())
		{
			mConnection.handleException();
			throw new DatabaseException("The connection is not open.");
		}
		
		while (true)
		{
			if (!mConnection.isFree())
			{
				try
				{
					synchronized (mConnection)
					{
						mConnection.wait();
					}
				}
				catch (InterruptedException e)
				{
					throw new DatabaseException("Timeout while waiting for the connection to become available.");
				}
			}
			else
			{
				break;
			}
		}
	}

	/**
	 * Checks if there's a <code>ResultSet</code> object present.
	 *
	 * @return <code>true</code> if a <code>ResultSet</code> object is
	 * available; or
	 * <p><code>false</code> otherwise.
	 * @since 1.0
	 */
	boolean hasResultset()
	{
		return null != mResultSet;
	}

	/**
	 * Set the current <code>ResultSet</code> object and cleans up the
	 * previous <code>ResultSet</code> object automatically.
	 *
	 * @param resultSet the new current <code>ResultSet</code> object
	 * @exception DatabaseException if a database access error occurred.
	 * @since 1.0
	 */
	protected void setResultset(ResultSet resultSet)
	throws DatabaseException
	{
		if (null == resultSet)
		{
			mResultSet = null;
		}
		else
		{
			mResultSet = wrapWithDbResultSet(resultSet);
		}
	}

	private DbResultSet wrapWithDbResultSet(ResultSet resultSet) throws DatabaseException
	{
		Class resulset_class = null;
		try
		{
			if (JavaSpecificationUtils.isAtLeastJdk16())
			{
				resulset_class = Class.forName(DbResultSet.class.getName() + "40");
			}
			else
			{
				resulset_class = Class.forName(DbResultSet.class.getName() + "30");
			}
			
			Constructor constructor = resulset_class.getDeclaredConstructor(new Class[] {DbStatement.class, ResultSet.class});
			return (DbResultSet)constructor.newInstance(new Object[] {this, resultSet});
		}
		catch (Exception e)
		{
			handleException();
			throw new DatabaseException(e);
		}
	}

	/**
	 * Cleans up and closes the current <code>ResultSet</code> object.
	 *
	 * @exception DatabaseException if a database access error occurred.
	 * @since 1.0
	 */
	void cleanResultSet()
	throws DatabaseException
	{
		if (null != mResultSet)
		{
			try
			{
				mResultSet.close();
				mResultSet = null;
			}
			catch (SQLException e)
			{
				mResultSet = null;
				close();
				throw new DatabaseException(e);
			}
		}
	}

	/**
	 * Performs the cleanup logic in case an exeception is thrown during
	 * execution. The statement will be closed and if a transaction is active,
	 * it will be automatically rolled back.
	 *
	 * @exception DatabaseException when an error occurs during the cleanup of
	 * the connection, or when an error occurs during the roll-back.
	 */
	protected void handleException()
	throws DatabaseException
	{
		synchronized (this)
		{
			try
			{
				close();
			}
			catch (DatabaseException e)
			{
				// this is a defensive close, if it can't be closed again, it
				// probably already is
			}
			
			if (mConnection.isTransactionValidForThread())
			{
				mConnection.rollback();
			}
			else
			{
				synchronized (mConnection)
				{
					mConnection.notifyAll();
				}
			}
		}
	}

	/**
	 * Ensures that this <code>DbStatement</code> is correctly closed when
	 * it's garbage collected.
	 *
	 * @exception Throwable if an error occurred during the finalization
	 * @since 1.0
	 */
	protected void finalize()
	throws Throwable
	{
		close();
		super.finalize();
	}
	
	/**
	 * Simply clones the instance with the default clone method. This creates
	 * a shallow copy of all fields and the clone will in fact just be another
	 * reference to the same underlying data. The independence of each cloned
	 * instance is consciously not respected since they rely on resources that
	 * can't be cloned.
	 *
	 * @since 1.0
	 */
	public Object clone()
	{
		try
		{
			return super.clone();
		}
		catch (CloneNotSupportedException e)
		{
			// this should never happen
			Logger.getLogger("com.uwyn.rife.database").severe(ExceptionUtils.getExceptionStackTrace(e));
			return null;
		}
	}
}


public abstract class DbTransactionUser<ResultType, DataType> implements Cloneable
{
	protected DataType  mData = null;
	
	public DbTransactionUser()
	{
	}
	
	public DbTransactionUser(DataType data)
	{
		mData = data;
	}
	
	public DataType getData()
	{
		return mData;
	}
	
	/**
	 * Should be overridden if the transaction has to be executed in another
	 * isolation level.
	 * 
	 * @return <code>-1</code> when the active isolation level should be
	 * preserved; or
	 * <p>a level constant from {@link java.sql.Connection Connection} if the
	 * isolation needs to be changed.
	 * @since 1.0
	 */
	public int getTransactionIsolation()
	{
		return -1;
	}
	
	/**
	 * Should be used to roll back ongoing transactions, otherwise enclosing
	 * transaction users might not be interrupted and subsequent modification
	 * can still happen outside the transaction.
	 * 
	 * @exception RollbackException indicates that a rollback should happen
	 * and all further transaction logic interrupted.
	 * @since 1.0
	 */
	public void rollback()
	throws RollbackException
	{
		throw new RollbackException();
	}
	
	/**
	 * Calling this method makes it possible to throw a checked exception from
	 * within this class.
	 * <p>To catch it you should surround the {@link
	 * DbQueryManager#inTransaction(DbTransactionUser) inTransaction} with a
	 * <code>try-catch</code> block that catching
	 * <code>InnerClassException</code>. The original exception is then
	 * available through <code>getCause()</code> and can for example be
	 * rethrown.
	 * 
	 * @exception InnerClassException when a checked exception needs to be
	 * thrown from within this class and caught outside the caller.
	 * @since 1.0
	 */
	public void throwException(Exception exception)
	throws InnerClassException
	{
		throw new InnerClassException(exception);
	}
	
	/**
	 * Should be implemented by all extending classes.
	 * 
	 * @since 1.0
	 */
	public abstract ResultType useTransaction() throws InnerClassException;

	/**
	 * Simply clones the instance with the default clone method since this
	 * class contains no member variables.
	 * 
	 * @since 1.0
	 */
	public Object clone()
	{
		try
		{
			return super.clone();
		}
		catch (CloneNotSupportedException e)
		{
			// this should never happen
			Logger.getLogger("com.uwyn.rife.database").severe(ExceptionUtils.getExceptionStackTrace(e));
			return null;
		}
	}

public class DbBeanFetcher<BeanType> extends DbRowProcessor
{
	private Datasource							mDatasource = null;
	private Class<BeanType>						mBeanClass = null;
	private BeanType							mLastBeanInstance = null;
	private HashMap<String, PropertyDescriptor>	mBeanProperties = new HashMap<String, PropertyDescriptor>();
	private ArrayList<BeanType>					mCollectedInstances = null;

	/**
	 * Create a new DbBeanFetcher
	 *
	 * @param datasource the datasource to be used
	 * @param beanClass the type of bean that will be handled
	 * @exception BeanException thrown if there is an error getting
	 * information about the bean via the beanClass
	 * @since 1.0
	 */
	public DbBeanFetcher(Datasource datasource, Class<BeanType> beanClass)
	throws BeanException
	{
		this(datasource, beanClass, false);
	}
	/**
	 * Create a new DbBeanFetcher
	 *
	 * @param datasource the datasource to be used
	 * @param beanClass the type of bean that will be handled
	 * @param collectInstances <code>true</code> if the fetcher should
	 * collected the bean instances; <code>false</code> if otherwise
	 * @exception BeanException thrown if there is an error getting
	 * information about the bean via the beanClass
	 * @since 1.0
	 */
       
	public DbBeanFetcher(Datasource datasource, Class<BeanType> beanClass, boolean collectInstances)
	throws BeanException
	{
		if (null == datasource) throw new IllegalArgumentException("datasource can't be null.");
		if (null == beanClass)  throw new IllegalArgumentException("beanClass can't be null.");
		
		BeanInfo bean_info = null;

		mDatasource = datasource;
		mBeanClass = beanClass;
		try
		{
			bean_info = Introspector.getBeanInfo(beanClass);
		}
		catch (IntrospectionException e)
		{
			throw new BeanException("Couldn't introspect the bean with class '"+mBeanClass.getName()+"'.", beanClass, e);
		}
		PropertyDescriptor[] bean_properties = bean_info.getPropertyDescriptors();
		for (PropertyDescriptor bean_property : bean_properties)
		{
			mBeanProperties.put(bean_property.getName().toLowerCase(), bean_property);
		}
		
		if (collectInstances)
		{
			mCollectedInstances = new ArrayList<BeanType>();
		}

		assert mDatasource != null;
		assert mBeanClass != null;
		assert null == mLastBeanInstance;
		assert mBeanProperties != null;
	}
	
	/**
	 * Process a ResultSet row into a bean. Call this method on a {@link
	 * ResultSet} and the resulting bean will be stored and be accessible
	 * via {@link #getBeanInstance()}
	 *
	 * @param resultSet the {@link ResultSet} from which to process the
	 * row
	 * @exception SQLException thrown when there is a problem processing
	 * the row
	 * @return <code>true</code> if a bean instance was retrieved; or
	 * <p><code>false</code> if otherwise
	 */
	public boolean processRow(ResultSet resultSet)
	throws SQLException
	{
		if (null == resultSet)  throw new IllegalArgumentException("resultSet can't be null.");
		
		BeanType instance = null;
		try
		{
			instance = mBeanClass.newInstance();
		}
		catch (InstantiationException e)
		{
			SQLException e2 = new SQLException("Can't instantiate a bean with class '"+mBeanClass.getName()+"' : "+e.getMessage());
			e2.initCause(e);
			throw e2;
		}
		catch (IllegalAccessException e)
		{
			SQLException e2 = new SQLException("No permission to instantiate a bean with class '"+mBeanClass.getName()+"' : "+e.getMessage());
			e2.initCause(e);
			throw e2;
		}
		
		ResultSetMetaData	meta = resultSet.getMetaData();
		String				column_name = null;
		PropertyDescriptor	property = null;
		Method				write_method = null;
		int					column_type = Types.OTHER;
		Object				typed_object = null;

		for (int i = 1; i <= meta.getColumnCount(); i++)
		{
			column_name = meta.getColumnName(i).toLowerCase();
			if (mBeanProperties.containsKey(column_name))
			{
				property = mBeanProperties.get(column_name);

				write_method = property.getWriteMethod();
				if (write_method != null)
				{
					try
					{
						column_type = meta.getColumnType(i);
						try
						{
							typed_object = mDatasource.getSqlConversion().getTypedObject(resultSet, i, column_type, property.getPropertyType());
						}
						catch (DatabaseException e)
						{
							SQLException e2 = new SQLException("Data conversion error while obtaining the typed object.");
							e2.initCause(e);
							throw e2;
						}
						
						// the sql conversion couldn't create a typed value
						if (null == typed_object)
						{
							// check if the object returned by the resultset is of the same type hierarchy as the property type
							Object column_value = resultSet.getObject(i);
							if (column_value != null &&
								property.getPropertyType().isAssignableFrom(column_value.getClass()))
							{
								typed_object = column_value;
							}
							// otherwise try to call the property type's constructor with a string argument
							else
							{
								String column_stringvalue = resultSet.getString(i);
								if (column_stringvalue != null)
								{
									try
									{
										Constructor constructor = property.getPropertyType().getConstructor(new Class[] {String.class});
										if (constructor != null)
										{
											typed_object = constructor.newInstance((Object[])new String[] {column_stringvalue});
										}
									}
									catch (SecurityException e)
									{
										instance = null;
										SQLException e2 = new SQLException("No permission to obtain the String constructor of the property with name '"+property.getName()+"' and class '"+property.getPropertyType().getName()+"' of the bean with class '"+mBeanClass.getName()+"'.");
										e2.initCause(e);
										throw e2;
									}
									catch (NoSuchMethodException e)
									{
										instance = null;
										SQLException e2 = new SQLException("Couldn't find a String constructor for the property with name '"+property.getName()+"' and class '"+property.getPropertyType().getName()+"' of the bean with class '"+mBeanClass.getName()+"'.");
										e2.initCause(e);
										throw e2;
									}
									catch (InstantiationException e)
									{
										instance = null;
										SQLException e2 = new SQLException("Can't instantiate a new instance of the property with name '"+property.getName()+"' and class '"+property.getPropertyType().getName()+"' of the bean with class '"+mBeanClass.getName()+"'.");
										e2.initCause(e);
										throw e2;
									}
								}
							}
						}
						
						// if the typed object isn't null, set the value
						if (typed_object != null)
						{
							// stored the property type
							write_method.invoke(instance, new Object[] {typed_object});
						}
					}
					catch (IllegalAccessException e)
					{
						instance = null;
						SQLException e2 = new SQLException("No permission to invoke the '"+write_method.getName()+"' method on the bean with class '"+mBeanClass.getName()+"'.");
						e2.initCause(e);
						throw e2;
					}
					catch (IllegalArgumentException e)
					{
						instance = null;
						SQLException e2 = new SQLException("Invalid arguments while invoking the '"+write_method.getName()+"' method on the bean with class '"+mBeanClass.getName()+"'.");
						e2.initCause(e);
						throw e2;
					}
					catch (InvocationTargetException e)
					{
						instance = null;
						SQLException e2 = new SQLException("The '"+write_method.getName()+"' method of the bean with class '"+mBeanClass.getName()+"' has thrown an exception");
						e2.initCause(e);
						throw e2;
					}
					catch (SQLException e)
					{
						instance = null;
						SQLException e2 = new SQLException("SQLException while invoking the '"+write_method.getName()+"' method of the bean with class '"+mBeanClass.getName()+"'");
						e2.initCause(e);
						throw e2;
					}
				}
			}
		}

		assert instance != null;
		
		mLastBeanInstance = instance;
		
		if (mCollectedInstances != null)
		{
			mCollectedInstances.add(instance);
		}

		return gotBeanInstance(instance);

	}

	/**
	 * Hook method that can be overloaded to receive new bean instances as
	 * they are retrieved, without relying on the internal collection into
	 * a list.
	 *
	 * @param instance the received bean instance
	 * @return <code>true</code> if the bean fetcher should continue to
	 * retrieve the next bean; or
	 * <p><code>false</code> if the retrieval should stop after this bean
	 * @since 1.0
	 */
	public boolean gotBeanInstance(BeanType instance)
	{
		return true;
	}
	
	/**
	 * Get the last processed bean instance
	 *
	 * @return the last processed bean instance
	 * @since 1.0
	 */
	public BeanType getBeanInstance()
	{
		return mLastBeanInstance;
	}

	/**
	 * Get the collected bean instances
	 *
	 * @return the collected bean instances
	 * @since 1.0
	 */
	public List<BeanType> getCollectedInstances()
	{
		return mCollectedInstances;
	}