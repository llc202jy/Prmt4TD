     LoginContext lc;

    try {
       lc = new LoginContext("EntryName", mysubject, new MyCallbackHandler());
    } catch (LoginException e) {
       // If an exception is caused here, it's likely the ~/.java.login.config file is wrong
    }

Where MyCallbackHandler is the class you want the authentication module to ask for the username and password. Even if you want to use the ticket cache, you still need to supply this in case the cache is empty. The suggested code is as follows:

    class MyCallbackHandler implements CallbackHandler {
       public void handle(Callback[] callbacks)
          throws IOException, UnsupportedCallbackException {

          for (int i = 0; i < callbacks.length; i++) {
             if (callbacks[i] instanceof NameCallback) {
                NameCallback nc = (NameCallback)callbacks[i];
                nc.setName(username);
             } else if (callbacks[i] instanceof PasswordCallback) {
                PasswordCallback pc = (PasswordCallback)callbacks[i];
                pc.setPassword(password.toCharArray());
             } else throw new UnsupportedCallbackException
                (callbacks[i], "Unrecognised callback");
          }
       }
    }

username and password are Strings containing the username and password to authenticate with. You could have the callback handler as an inner class and then use global variables to pass the Strings, but a better way to do it would be to write a constructor that takes the two Strings and have them as properties of the MyCallbackHandler class.

Going back to the main code, the final step is to call the login() method of the Logincontext class (called lc in my code).

    try {
       lc.login();
    } catch (LoginException e) {
       // Bad username/password
    }

If no exception is thrown, the user is now authenticated and the Subject class you supplied earlier now holds a valid Kerberos ticket, which you can access if necessary with mysubject.getPrivateCredentials(). For added security, it is recommended that you have a simple for loop to overwrite the password String, so that it doesn't stay intact in memory for all to see. I've written all the other code for you, so I thought I might as well do this too.

    char passwordchars[] = password.toCharArray();
    for (int i