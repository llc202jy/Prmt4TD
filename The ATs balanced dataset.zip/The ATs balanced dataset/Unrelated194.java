/*
 * Copyright (C) The MX4J Contributors.
 * All rights reserved.
 *
 * This software is distributed under the terms of the MX4J License version 1.0.
 * See the terms of the MX4J License in the documentation provided with this software.
 */

package mx4j.server;

import javax.management.Attribute;
import javax.management.AttributeNotFoundException;
import javax.management.InvalidAttributeValueException;
import javax.management.MBeanException;
import javax.management.ReflectionException;

/**
 * Invokes methods on standard MBeans. <br />
 * Actually three implementations are available: two that uses reflection and one that generates on-the-fly a customized
 * MBeanInvoker per each MBean and that is implemented with direct calls via bytecode generation. <br />
 * The default is the direct call version, that uses the <a href="http://jakarta.apache.org/bcel">BCEL</a> to generate
 * the required bytecode on-the-fly. <br>
 * In the future may be the starting point for MBean interceptors.
 *
 * @version $Revision: 1.6 $
 */
public interface MBeanInvoker
{
   /**
    * Invokes the specified operation on the MBean instance
    */
   public Object invoke(MBeanMetaData metadata, String method, String[] signature, Object[] args) throws MBeanException, ReflectionException;

   /**
    * Returns the value of the specified attribute.
    */
   public Object getAttribute(MBeanMetaData metadata, String attribute) throws MBeanException, AttributeNotFoundException, ReflectionException;

   /**
    * Sets the value of the specified attribute.
    */
   public void setAttribute(MBeanMetaData metadata, Attribute attribute) throws MBeanException, AttributeNotFoundException, InvalidAttributeValueException, ReflectionException;
}
/*
 * Copyright (C) The MX4J Contributors.
 * All rights reserved.
 *
 * This software is distributed under the terms of the MX4J License version 1.0.
 * See the terms of the MX4J License in the documentation provided with this software.
 */

package mx4j.server;

import javax.management.loading.ClassLoaderRepository;

/**
 * Base class to extend to create custom ClassLoaderRepositories.
 * MX4J's MBeanServer can use a custom ClassLoaderRepository instead of the default one
 * by simply specifying a suitable system property, see {@link mx4j.MX4JSystemKeys}.
 * It must be a class, otherwise it opens up a security hole, as anyone can cast the MBeanServer's
 * ClassLoaderRepository down to this class and call addClassLoader or removeClassLoader
 * since, if this class is an interface, they must be public.
 *
 * @version $Revision: 1.4 $
 */
public abstract class ModifiableClassLoaderRepository implements ClassLoaderRepository
{
   /**
    * Adds, if does not already exist, the specified ClassLoader to this repository.
    *
    * @param cl The classloader to add
    * @see #removeClassLoader
    */
   protected abstract void addClassLoader(ClassLoader cl);

   /**
    * Removes, if exists, the specified ClassLoader from this repository.
    *
    * @param cl The classloader to remove
    * @see #addClassLoader
    */
   protected abstract void removeClassLoader(ClassLoader cl);
}
/*
 * Copyright (C) The MX4J Contributors.
 * All rights reserved.
 *
 * This software is distributed under the terms of the MX4J License version 1.0.
 * See the terms of the MX4J License in the documentation provided with this software.
 */

package mx4j.tools.remote.provider.local;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Map;

import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorProvider;
import javax.management.remote.JMXServiceURL;

import mx4j.tools.remote.local.LocalConnector;

/**
 * @version $Revision: 1.4 $
 */
public class ClientProvider implements JMXConnectorProvider
{
   public JMXConnector newJMXConnector(JMXServiceURL url, Map environment) throws IOException
   {
      String protocol = url.getProtocol();
      if (!"local".equals(protocol)) throw new MalformedURLException("Wrong protocol " + protocol + " for provider " + this);
      return new LocalConnector(url, environment);
   }
}
/*
 * Copyright (C) The MX4J Contributors.
 * All rights reserved.
 *
 * This software is distributed under the terms of the MX4J License version 1.0.
 * See the terms of the MX4J License in the documentation provided with this software.
 */

package mx4j.tools.remote.provider.local;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Map;

import javax.management.MBeanServer;
import javax.management.remote.JMXConnectorServer;
import javax.management.remote.JMXConnectorServerProvider;
import javax.management.remote.JMXServiceURL;

import mx4j.tools.remote.local.LocalConnectorServer;

/**
 * @version $Revision: 1.4 $
 */
public class ServerProvider implements JMXConnectorServerProvider
{
   public JMXConnectorServer newJMXConnectorServer(JMXServiceURL url, Map environment, MBeanServer server) throws IOException
   {
      String protocol = url.getProtocol();
      if (!"local".equals(protocol)) throw new MalformedURLException("Wrong protocol " + protocol + " for provider " + this);
      return new LocalConnectorServer(url, environment, server);
   }
}
/*
 * Copyright (C) The MX4J Contributors.
 * All rights reserved.
 *
 * This software is distributed under the terms of the MX4J License version 1.0.
 * See the terms of the MX4J License in the documentation provided with this software.
 */

package mx4j.tools.remote.provider.soap.ssl;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Map;

import javax.management.MBeanServer;
import javax.management.remote.JMXConnectorServer;
import javax.management.remote.JMXConnectorServerProvider;
import javax.management.remote.JMXServiceURL;

import mx4j.tools.remote.http.HTTPConnectorServer;

/**
 * @version $Revision: 1.2 $
 */
public class ServerProvider implements JMXConnectorServerProvider
{
   public JMXConnectorServer newJMXConnectorServer(JMXServiceURL url, Map environment, MBeanServer server) throws IOException
   {
      String protocol = url.getProtocol();
      if (!"soap+ssl".equals(protocol)) throw new MalformedURLException("Wrong protocol " + protocol + " for provider " + this);
      return new HTTPConnectorServer(url, environment, server);
   }
}
                        }
                        break;

                    default:
                        // write the field to the header buffer
                        field.put(_header);
                }
            }
        }

        // Calculate how to end _content and connection, _content length and transfer encoding
        // settings.
        // From RFC 2616 4.4:
        // 1. No body for 1xx, 204, 304 & HEAD response
        // 2. Force _content-length?
        // 3. If Transfer-Encoding!=identity && HTTP/1.1 && !HttpConnection==close then chunk
        // 4. Content-Length
        // 5. multipart/byteranges
        // 6. close
        switch ((int) _contentLength)
        {
            case HttpTokens.UNKNOWN_CONTENT:
                // It may be that we have no _content, or perhaps _content just has not been
                // written yet?
