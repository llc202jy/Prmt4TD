
   this.heartbeat = new RMIHeartBeat(connection, emitter, env);
         this.notificationHandler = new RMIRemoteNotificationClientHandler(connection, defaultClassLoader, emitter, heartbeat, env);

         this.heartbeat.start();
         this.notificationHandler.start();

 if (notificationHandler != null) notificationHandler.stop();
         if (heartbeat != null) heartbeat.stop();
         if (connection != null) connection.close();

   private transient String connectionId;
   private transient HeartBeat heartbeat;
   private transient RemoteNotificationClientHandler notificationHandler;


   protected void doConnect(Map environment) throws IOException, SecurityException
   {
      JMXServiceURL address = getAddress();
      String protocol = address.getProtocol();
      ConnectionResolver resolver = ConnectionResolver.newConnectionResolver(protocol, environment);
      if (resolver == null) throw new MalformedURLException("Unsupported protocol: " + protocol);

      HTTPConnection temp = (HTTPConnection)resolver.lookupClient(address, environment);
      connection = (HTTPConnection)resolver.bindClient(temp, environment);

      Object credentials = environment == null ? null : environment.get(CREDENTIALS);
      connectionId = connection.connect(credentials);

      this.heartbeat = createHeartBeat(connection, getConnectionNotificationEmitter(), environment);
      this.notificationHandler = createRemoteNotificationClientHandler(connection, getConnectionNotificationEmitter(), heartbeat, environment);

      this.heartbeat.start();
      this.notificationHandler.start();
   }

   protected HeartBeat createHeartBeat(HTTPConnection connection, ConnectionNotificationEmitter emitter, Map environment)
   {
      return new HTTPHeartBeat(connection, emitter, environment);
   }

   protected RemoteNotificationClientHandler createRemoteNotificationClientHandler(HTTPConnection connection, ConnectionNotificationEmitter emitter, HeartBeat heartbeat, Map environment)
   {
      return new HTTPRemoteNotificationClientHandler(connection, emitter, heartbeat, environment);
   }

   protected MBeanServerConnection doGetMBeanServerConnection(Subject delegate) throws IOException
   {
      return new HTTPConnectionMBeanServerConnection(getHTTPConnection(), delegate, getRemoteNotificationClientHandler());
   }

   protected void doClose() throws IOException
   {
      if (notificationHandler != null) notificationHandler.stop();
      if (heartbeat != null) heartbeat.stop();
      if (connection != null) connection.close();
   }

}
public abstract class AbstractHeartBeat implements HeartBeat, Runnable
{
   private final ConnectionNotificationEmitter emitter;
   private long pulsePeriod;
   private int maxRetries;
   private Thread thread;
   private volatile boolean stopped;

   /**
    * Creates a new HeartBeat.
    *
    * @param emitter     The NotificationEmitter that sends connection failures notifications.
    * @param environment The environment that may contain properties that specify heart beat's behavior
    * @see #sendConnectionNotificationFailed
    * @see MX4JRemoteConstants#CONNECTION_HEARTBEAT_PERIOD
    * @see MX4JRemoteConstants#CONNECTION_HEARTBEAT_RETRIES
    */
   protected AbstractHeartBeat(ConnectionNotificationEmitter emitter, Map environment)
   {
      this.emitter = emitter;
      if (environment != null)
      {
         try
         {
            pulsePeriod = ((Long)environment.get(MX4JRemoteConstants.CONNECTION_HEARTBEAT_PERIOD)).longValue();
         }
         catch (Exception ignored)
         {
         }
         try
         {
            maxRetries = ((Integer)environment.get(MX4JRemoteConstants.CONNECTION_HEARTBEAT_RETRIES)).intValue();
         }
         catch (Exception ignored)
         {
         }
      }
      if (pulsePeriod <= 0) pulsePeriod = 5000;
      if (maxRetries <= 0) maxRetries = 3;
   }

   public long getPulsePeriod()
   {
      return pulsePeriod;
   }

   public int getMaxRetries()
   {
      return maxRetries;
   }

   /**
    * Subclasses will implement this method using protocol specific connections.
    * Normally the method {@link javax.management.MBeanServerConnection#getDefaultDomain} is used
    * to "ping" the server side.
    */
   protected abstract void pulse() throws IOException;

   public void start() throws IOException
   {
      thread = new Thread(this, "Connection HeartBeat");
      thread.setDaemon(true);
      thread.start();
   }

   public void stop() throws IOException
   {
      if (stopped) return;
      stopped = true;
      thread.interrupt();
   }

   public void run()
   {
      try
      {
         int retries = 0;
         while (!stopped && !thread.isInterrupted())
         {
            try
            {
               Thread.sleep(pulsePeriod);

               try
               {
                  pulse();
                  retries = 0;
               }
               catch (IOException x)
               {
                  if (retries++ == maxRetries)
                  {
                     // The connection has died
                     sendConnectionNotificationFailed();
                     break;
                  }
               }
            }
            catch (InterruptedException x)
            {
               Thread.currentThread().interrupt();
            }
         }
      }
      finally
      {
         stopped = true;
      }
   }

   /**
    * Sends the connection failed notification using the emitter specified in
    * {@link #AbstractHeartBeat}
    */
   protected void sendConnectionNotificationFailed()
   {
      emitter.sendConnectionNotificationFailed();
   }
}


* MX4J's implementation uses this property to specify the period (in ms) of the heartbeat pulse for
    * {@link javax.management.remote.JMXConnector JMXConnectors} that use heartbeat to check if the
    * connection with {@link javax.management.remote.JMXConnectorServer JMXConnectorServers} is still alive.
    *
    * @see #CONNECTION_HEARTBEAT_RETRIES
    */
   public static final String CONNECTION_HEARTBEAT_PERIOD = "jmx.remote.x.connection.heartbeat.period";

   /**
    * MX4J's implementation uses this property to specify the number of retries of heartbeat pulses before
    * declaring the connection between a {@link javax.management.remote.JMXConnector JMXConnector} and a
    * {@link javax.management.remote.JMXConnectorServer JMXConnectorServer} failed, at which a
    * {@link javax.management.remote.JMXConnectionNotification notification failed} is emitted.
    *
    * @see #CONNECTION_HEARTBEAT_PERIOD
    */
   public static final String CONNECTION_HEARTBEAT_RETRIES = "jmx.remote.x.connection.heartbeat.retries";

   /**
    * MX4J's implementation uses this property to specify the maximum notification queue size
    * on client size. If set to 0, or not present, the queue will have no limit.
    * Specify this property when the server side is generating notifications at a fast rate,
    * but clients can process them only at a slower rate. In this case notifications will queue
    * up on client side, and if no limit is given to the queue, there is a potential risk of
    * an OutOfMemoryError.