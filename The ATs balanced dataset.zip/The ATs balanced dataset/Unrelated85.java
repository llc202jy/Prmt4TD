

    public boolean exportStatistic(String s, int i, int j, int k)
    {
        if(trace == 0)
            return false;
        else
            return t2pExportStatistic(trace, s, i, j, k);
    }

    public int getSRMatrixByte(int i, int j)
    {
        if(trace == 0)
            return -1;
        else
            return t2pGetSRMatrixByte(trace, i, j);
    }

    public int getScaleByteYCoord(int i)
    {
        if(trace == 0)
            return -1;
        else
            return t2pGetScaleByteYCoord(trace, i);
    }

    public int getScaleXCoord()
    {
        if(trace == 0)
            return -1;
        else
            return t2pGetScaleXCoord(trace);
    }

    public int getNumberOfMigrations(int i)
    {
        if(trace == 0)
            return -1;
        else
            return t2pGetNumberOfMigrations(trace, i);
    }

    public String getHostNameAfterMigration(int i, int j)
    {
        if(trace == 0)
            return null;
        else
            return t2pGetHostNameAfterMigration(trace, i, j);
    }

    public int getMigrationSec(int i, int j)
    {
        if(trace == 0)
            return -1;
        else
            return t2pGetMigrationSec(trace, i, j);
    }

    public int getMigrationUSec(int i, int j)
    {
        if(trace == 0)
            return -1;
        else
            return t2pGetMigrationUSec(trace, i, j);
    }

    public static final int SORTBYCOMMUNICATION = 1;
    public static final int SORTBYPROCNAME = 2;
    public static final int SORTBYHOSTNAME = 3;
    private URL url;
    private URLConnection istream;
    private int bytes_read;
    private int last_contentLenght;
    private int trace;
    private int sortby;
    private BufferedReader reader;
    public int getNumberOfProcesses()
    {
        if(trace == 0)
            return -1;
        else
            return t2pGetNumberOfProcesses(trace);
    }

    public String getProcessName(int i)
    {
        if(trace == 0)
            return null;
        else
            return t2pGetProcessName(trace, i);
    }

    public int getProcessYCoord(int i)
    {
        if(trace == 0)
            return -1;
        else
            return t2pGetProcessYCoord(trace, i);
    }

    public void hideProcess(int i)
    {
        if(trace == 0)
        {
            return;
        } else
        {
            t2pHideProcess(trace, i);
            System.out.println("hide" + i);
            return;
        }
    }

    public void showProcess(int i)
    {
        if(trace == 0)
        {
            return;
        } else
        {
            t2pShowProcess(trace, i);
            return;
        }
    }

    public boolean isProcessHidden(int i)
    {
        if(trace == 0)
            return false;
        else
            return t2pIsProcessHidden(trace, i);
    }            return;
        } else
        {
            sortby = i;
            t2pSort(trace, i);
            return;
        }
    }

    public void forgetEvents(int i, int j)
    {
        if(trace == 0)
        {
            return;
        } else
        {
            t2pForgetEvents(trace, i, j);
            return;
        }
    }

    public boolean collect()
    {
        return readLines() > 0;
    }
public synchronized void delete() {
    System.out.println("TF - TraceFile.delete() ~ START");
    if (this.tf.exists()) {
      this.tf.delete();
    }
    System.out.println("TF - TraceFile.delete() ~ END");
  }

  /**
   *
   * @return The absolute path of this trace file.
   */
  public String getAbsolutePath() {
    return this.tf.getAbsolutePath();
  }

  public int getLinesNumber() {
    BufferedReader in;
    int ln = -1;
    try {
      ln = 0;
      in = new BufferedReader(new FileReader(this.tf));
      while (in.readLine() != null) {
        ln++;
      }
              "TF - TraceFile.writeOutBuffer() ~ tf.createNewFile( "+this.tf.getAbsolutePath()+" ) FAILED");
          return;
        }
      }
//felirjuk az adatokat a listenernek      
      
      PrintWriter out = new PrintWriter(new FileOutputStream(this.tf, true));
      out.print(buffer.toString());
      out.close();
      this.buffer.delete(0, this.buffer.length());
      this.bufferCounter = 0;
    }
    catch (IOException ex) {
      System.out.println(
          "TF - TraceFile.writeOutBuffer( "+this.tf.getAbsolutePath()+" ) ~ FAILED, IOException: " +
          ex.getMessage());
      ex.printStackTrace();
      return;
    }
//    System.out.println("TF - TraceFile.writeOutBuffer() ~ END");
  }

  /**
   * Deletes file from the file system.
   */
  