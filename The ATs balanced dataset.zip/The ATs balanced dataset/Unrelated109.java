/**
	 * Returns the TagFTPrimaryTaggedComponent from the IOR (TaggedComponent). If any exception is
	 * throwed, returns <code>null</code>.
	 * 
	 * @param tc org.omg.IOP.TaggedComponent
	 * @return org.omg.CORBA.FT.TagFTPrimaryTaggedComponent
	 */
	protected static TagFTPrimaryTaggedComponent getPrimaryTC(TaggedComponent tc) {
		if (tc == null)
			return null;
		CDRInputStream in = new CDRInputStream(null, tc.component_data);
		try {
			in.setLittleEndian(in.read_boolean());

			return TagFTPrimaryTaggedComponentHelper.read(in);
		} catch (Exception ex) {
			return null;
		}
	}

	/**
	 * Returns the TagFTRecoveryRequestTaggedComponent from the IOR (TaggedComponent). If any
	 * exception is throwed, returns <code>null</code>.
	 * 
	 * @param tc org.omg.IOP.TaggedComponent
	 * @return org.omg.CORBA.FT.TagFTRecoveryRequestTaggedComponent
	 */
	protected static TagFTRecoveryRequestTaggedComponent getRecoveryTC(TaggedComponent tc) {
		if (tc == null)
			return null;
		CDRInputStream in = new CDRInputStream(null, tc.component_data);
		try {
			in.setLittleEndian(in.read_boolean());

			return TagFTRecoveryRequestTaggedComponentHelper.read(in);
		} catch (Exception ex) {
			return null;
		}
	}

	/**
	 * Find and return the first profile that has a TAG_PRIMARY. If there is no primary, then
	 * return <code>null</code>.
	 * 
	 * @return org.omg.IIOP.ProfileBody_1_1
	 */
	protected ProfileBody_1_1 getPrimaryProfile() {
		int k = getNumberOfObjects();
		ProfileBody_1_1 pb;
		for (int i = 0; i < k; i++) {
			pb = getProfileBodies()[i];
			TaggedComponent[] tc = pb.components;
			for (int j = 0; j < tc.length; j++)
				if (tc[j].tag == TAG_FT_PRIMARY.value)
					return pb;
		}
		// no primary profile was found!
		return null;
	}

	/**
	 * Checks for TAG_FT_GROUP presence. If there is no tag, then return <code>null</code>.
	 * 
	 * @return org.omg.CORBA.FT.TagFTGroupTaggedComponent
	 */
	protected TagFTGroupTaggedComponent getTagGroup() {
		if (!tag_group_parsed) {
			tag_group = getGroupTC(getTaggedComponent(TAG_FT_GROUP.value));
			tag_group_parsed = true;
		}

		return tag_group;
	}

	/**
	 * Checks for TAG_FT_PRIMARY presence. If there is no tag, then return <code>false</code>.
	 * 
	 * @return org.omg.CORBA.FT.TagFTPrimaryTaggedComponent
	 */
	protected TagFTPrimaryTaggedComponent getTagPrimary() {
		if (!tag_primary_parsed) {
			tag_primary = getPrimaryTC(getTaggedComponent(TAG_FT_PRIMARY.value));
			tag_primary_parsed = true;
		}

		return tag_primary;
	}

	/**
	 * Checks for TAG_FT_RECOVERY_REQUEST presence. If there is no tag, then return
	 * <code>false</code>.
	 * 
	 * @return org.omg.CORBA.FT.TagFTRecoveryRequestTaggedComponent
	 */
	protected TagFTRecoveryRequestTaggedComponent getTagRecovery() {
		if (!tag_recovery_parsed) {
			tag_recovery = getRecoveryTC(getTaggedComponent(TAG_FT_RECOVERY_REQUEST.value));
			tag_recovery_parsed = true;
		}

		return tag_recovery;
	}

	/**
	 * Create an IOR object from type_id & profile body.
	 * 
	 * @param type_id java.lang.String
	 * @param pb org.omg.IIOP.ProfileBody_1_1
	 * @param with_tags if true, includes all tags present in the original IOGR
	 * @return org.omg.IOP.IOR
	 */
	protected IOR makeIOR(String type_id, ProfileBody_1_1 pb, boolean with_tags) {
		boolean endianness = false;
		TaggedProfile[] tp;
		TaggedProfile mctp = null;
		if (with_tags && (taggedComponents != null)) {
			CDROutputStream cos_mc = new CDROutputStream();
			cos_mc.write_boolean(endianness);
			MultipleComponentProfileHelper.write(cos_mc, taggedComponents);
			mctp = new TaggedProfile(TAG_MULTIPLE_COMPONENTS.value, cos_mc.getBufferCopy());
		} else
			pb.components = new TaggedComponent[0];
		TaggedProfile pbtp = null;
		if (pb != null) {
			CDROutputStream cos = new CDROutputStream();
			cos.write_boolean(endianness);
			ProfileBody_1_1Helper.write(cos, pb);
			pbtp = new TaggedProfile(TAG_INTERNET_IOP.value, cos.getBufferCopy());
		}
		if ((pbtp != null) && (mctp != null)) {
			tp = new TaggedProfile[2];
			tp[0] = pbtp;
			tp[1] = mctp;
		} else if ((pbtp == null && mctp != null) || (pbtp != null && mctp == null)) {
			tp = new TaggedProfile[1];
			tp[0] = (pbtp == null) ? mctp : pbtp;
		} else
			tp = new TaggedProfile[0];

		return new IOR(type_id, tp);
	}

	/**
	 * Initializes the ParsedIOGR. Instantiate fields.
	 */
	private void initialize() {
	}


import edu.lcmi.grouppac.util.Debug;

/**
 * This class's purpose is to "initialize" the orb, creating and activating both client and server
 * IOGR support.
 * 
 * @version $Revision: 1.12 $
 * @author <a href="mailto:padilha@das.ufsc.br">Ricardo Sangoi Padilha</a>, <a
 *         href="http://www.das.ufsc.br/">UFSC, Florian?polis, SC, Brazil</a>
 * @author <a href="mailto:luciana@das.ufsc.br">Luciana Moreira S? de Souza</a>, <a
 *         href="http://www.das.ufsc.br/">UFSC, Florian?polis, SC, Brazil</a>
 */
public class GrouppacInterceptorsInitializer implements ORBInitializer {

	/**
	 * Default Constructor.
	 */
	public GrouppacInterceptorsInitializer() {
	}

	/**
	 * @see org.omg.PortableInterceptor.ORBInitializerOperations#post_init(ORBInitInfo)
	 */
	public void post_init(ORBInitInfo orbinitinfo) {
	}

	/**
	 * @see org.omg.PortableInterceptor.ORBInitializerOperations#pre_init(ORBInitInfo)
	 */
	public void pre_init(ORBInitInfo orbinitinfo) {
		ClientIOGRSupport cis = null;
		ServerIOGRSupport sis = null;
		//LoggingMessageClientInterceptor lmci = null;
		try {
			if (cis == null)
				cis = new ClientIOGRSupport();
			if (sis == null)
				sis = new ServerIOGRSupport();
			//if (lmci == null)
			//   lmci = new LoggingMessageClientInterceptor();
			//if (gi == null)
			//   gi = new LoggingGSeqInterceptor();
			//if (gmci == null)
			//   gmci = new GSeqMessagerClientInterceptor();
		} catch (Exception e) {
		}

		try {
			/*if(lmci != null) {
			   orbinitinfo.add_client_request_interceptor(lmci);
			   Debug.output(0, 
							"GrouppacInterceptorsInitializer: LoggingMessagerClientInterceptor adicionado.");
			   }
			   if(gmci != null) {
				   orbinitinfo.add_client_request_interceptor(gmci);
				   Debug.output(0, 
								"GrouppacInterceptorsInitializer: GSeqMessagerClientInterceptor adicionado.");
			   }*/
			orbinitinfo.add_client_request_interceptor(cis);
			orbinitinfo.add_server_request_interceptor(sis);
			edu.lcmi.grouppac.util.Debug.output(
				0,
				"GrouppacInterceptorsInitializer: Client/Server IOGR support interceptor is running.");
			/*if(gi != null) {
			   orbinitinfo.add_server_request_interceptor(gi);
			   Debug.output(0, 
							"GrouppacInterceptorsInitializer: LoggingGSeqInterceptor adicionado.");
			   }*/
		} catch (org.omg.PortableInterceptor.ORBInitInfoPackage.DuplicateName e) {
			Debug.output(
				0,
				"GrouppacInterceptorsInitializer: Ocorreu um erro durante o cadastramento dos interceptadores do Grouppac (Nome duplicado).");
		}
	}

	/**
	 * @see org.omg.CORBA.Object#_create_request(Context, String, NVList, NamedValue, ExceptionList, ContextList)
	 */
	public Request _create_request(
		Context ctx,
		String operation,
		NVList arg_list,
		NamedValue result,
		ExceptionList exclist,
		ContextList ctxlist) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_create_request(Context, String, NVList, NamedValue)
	 */
	public Request _create_request(Context ctx, String operation, NVList arg_list, NamedValue result) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_duplicate()
	 */
	public org.omg.CORBA.Object _duplicate() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_get_domain_managers()
	 */
	public DomainManager[] _get_domain_managers() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_get_interface_def()
	 */
	public org.omg.CORBA.Object _get_interface_def() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @deprecated deprecated by CORBA 2.3
	 */
	public InterfaceDef _get_interface() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_get_policy(int)
	 */
	public Policy _get_policy(int policy_type) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_hash(int)
	 */
	public int _hash(int maximum) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_is_a(String)
	 */
	public boolean _is_a(String repositoryIdentifier) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_is_equivalent(org.omg.CORBA.Object)
	 */
	public boolean _is_equivalent(org.omg.CORBA.Object other) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_non_existent()
	 */
	public boolean _non_existent() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_release()
	 */
	public void _release() {
	}

	/**
	 * @see org.omg.CORBA.Object#_request(String)
	 */
	public Request _request(String operation) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_set_policy_override(Policy[], SetOverrideType)
	 */
	public org.omg.CORBA.Object _set_policy_override(Policy[] policies, SetOverrideType set_add) {
		throw new NO_IMPLEMENT();
	}
}