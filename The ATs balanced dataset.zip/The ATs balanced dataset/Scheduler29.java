public class Process implements Comparable
{
	private int processID;
	private int arrivalTime;
	private int finishTime;
	private int originalCPUTime;
	private int totalCPUTime;
	private double printerProbability;
	private double diskProbability;
	private int avgPrintTime;
	private int printTimeLeft;
	private int avgDiskTime;
	private int diskTimeLeft;
	private int priority;
	private int totalWaitTime = 0;
	private int responseTime;
	private boolean respondedTo = false;

	/**
	 * New for Part 2 of HW
	 */
	private int total_Pages;
	private int free_Pages;
	private int used_Pages;
	private int allocated_Pages;
	private int second_Chance_Pointer;
	private LinkedList<TableKey> absent_Pages;
	private LinkedList<TableKey> resident_Pages;

	public Process(int processID, int arrivalTime, int totalCPUTime, double diskProbability,
			int avgDiskTime, double printerProbability, int avgPrintTime,
			int priority, int total_Pages)
	{
		this.processID = processID;
		this.arrivalTime = arrivalTime;
		this.totalCPUTime = totalCPUTime;
		this.originalCPUTime = totalCPUTime;
		this.diskProbability = diskProbability;
		this.avgDiskTime = avgDiskTime;
		this.printerProbability = printerProbability;
		this.avgPrintTime = avgPrintTime;
		this.priority = priority;
		this.total_Pages = total_Pages;
		free_Pages = (int) (total_Pages / 3);
		used_Pages = 0;
		allocated_Pages = free_Pages;
		second_Chance_Pointer = 0;
		absent_Pages = new LinkedList<TableKey>();
		resident_Pages = new LinkedList<TableKey>();

		for (int i = 0; i < total_Pages; i++)
		{
			TableKey key = new TableKey(this.processID, i);
			absent_Pages.add(key);
		}
	}

	public boolean isDiskRequest()
	{
		// calculate based on random numbers whether or not
		// this process is a disk request
		// returns true if
		double range = Math.random();
		if(range <= diskProbability)
		{
			calcDiskTime();
			return true;
		}
		else
			return false;
	}

	public boolean isPrinterRequest()
	{
		// calculate based on random numbers whether or not
		// this process is a printer request
		// returns true if
		double range = Math.random();
		if(range <= printerProbability)
		{
			calcPrintTime();
			return true;
		}
		else
			return false;
	}

	public void calcDiskTime()
	{
		// 2.0 * Math.random() is a value between 0 and 2 which is the between
		// twices the average and zero
		diskTimeLeft = 1 + (int) ((2.0 * Math.random()) * avgDiskTime);
		double diskTime = diskTimeLeft / 10.0;
		//System.out.println("Disk Time Left (msecs): " + diskTime);
		//System.out.println("Disk Time Left : " + diskTimeLeft);
	}

	public void calcPrintTime()
	{
		// 2.0 * Math.random() is a value between 0 and 2 which is the between
		// twices the average and zero
		printTimeLeft = 1 + (int) ((2.0 * Math.random()) * avgPrintTime);
		double printTime = printTimeLeft / 10.0;
		//System.out.println("Print Time Left (msecs): " + printTime);
		//System.out.println("Print Time Left: " + printTimeLeft);
	}

	public int getID()
	{
		return processID;
	}

	public int getPriority()
	{
		return priority;
	}

	public int getArrivalTime()
	{
		return arrivalTime;
	}

	public int getFinishTime()
	{
		return finishTime;
	}

	public int getTotalWaitTime()
	{
		return totalWaitTime;
	}

	public int getResponseTime()
	{
		return responseTime;
	}

	public void setResponseTime(int rt)
	{
		responseTime = rt;
	}

	public int getTotalPages()
	{
		return total_Pages;
	}

	public int getAllocatedPages()
	{
		return allocated_Pages;
	}

	public int getFreePages()
	{
		return free_Pages;
	}

	public void decFreePages()
	{
		free_Pages--;
	}

	public void waiting()
	{
		// each loop it is waiting, each process will be updated with this method?
		totalWaitTime++;
	}

	// This method is to adjust the wait time when a disk or print operation is done
	public void fixWaitTime()
	{
		totalWaitTime--;
	}

	public int compareTo(Object aProcess) // the obj will be a Process
	{
		Process tempProcess = (Process) aProcess;
		// what will be compared is the different priorities
		if(this.getPriority() < tempProcess.getPriority())
			return -1;
		else if(this.getPriority() > tempProcess.getPriority())
			return 1;
		else //default's aProcess.getPriority() == this.getPriority()
			return 0;
	}

	public int getPrintTimeLeft()
	{
		return printTimeLeft;
	}
	public int getDiskTimeLeft()
	{
		return diskTimeLeft;
	}

	public int getTotalCPUTime()
	{
		return totalCPUTime;
	}

	public int originalTotalCPUTime()
	{
		return originalCPUTime;
	}

	public String toString()
	{
		String result = "" +
		"Process ID: " + processID +
		"\nArrival Time: " + arrivalTime +
		"\nFinish Time: " + finishTime +
		"\nTotal CPU Time: " + totalCPUTime +
		"\nPrinter Probability: " + printerProbability +
		"\nDisk Probability: " + diskProbability +
		"\nAverage Print Time: " + avgPrintTime +
		"\nPrint Time Left: " + printTimeLeft +
		"\nAverage Disk Time: " + avgDiskTime +
		"\nDisk Time Left: " + diskTimeLeft +
		"\nPriority: " + priority +
		"\nTotal Wait Time: " + totalWaitTime +
		"\nResponse Time: " + responseTime +
		"\nResponded To: " + respondedTo +
		"\nTotal Pages: " + total_Pages + "\n\n\n";
		return result;
	}

	public void execute(int globalTime)
	{
		totalCPUTime--;
		if (!respondedTo)
		{
			respondedTo = true;
			responseTime = globalTime - arrivalTime;
		}
	}

	public boolean isCPUDone()
	{
		if (totalCPUTime == 0)
		{
			return true;
		}
		else return false;
	}

	public boolean isDiskDone()
	{
		if (diskTimeLeft == 0)
		{
			return true;
		}
		else return false;
	}

	public boolean isPrinterDone()
	{
		if (printTimeLeft == 0)
		{
			return true;
		}
		else return false;
	}

	public void decDiskTimeLeft()
	{
		diskTimeLeft--;
	}

	public void decPrintTimeLeft()
	{
		printTimeLeft--;
	}

	public int getHand()
	{
		return second_Chance_Pointer;
	}

	public void setHand(int hand)
	{
		second_Chance_Pointer = hand;
	}

	public void terminate(int globalTime)
	{
		finishTime = globalTime;
	}

	/**
	 * New functions for HW Part 2
	 */

	public LinkedList<TableKey> getAbsentPages()
	{
		return absent_Pages;
	}

	public LinkedList<TableKey> getResidentPages()
	{
		return resident_Pages;
	}
}