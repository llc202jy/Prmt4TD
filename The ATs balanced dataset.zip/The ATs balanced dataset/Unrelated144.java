package com.ibm.maf.rmi;

import com.ibm.awb.security.AccessController;
import com.ibm.maf.*;
import java.rmi.*;

public final class MAFAgentSystem_RMIClient extends MAFAgentSystem {

    private MAFAgentSystem_RMI _agent_system = null;
    private String             _address = null;

    static java.util.Hashtable to_maf = new java.util.Hashtable();

    static public MAFAgentSystem_RMI getMAFAgentSystem_RMI(String address) throws java.io.IOException {
	return to_rmi_agentsystem(MAFAgentSystem.getMAFAgentSystem(address));
    }

    MAFAgentSystem_RMIClient(MAFAgentSystem_RMI __rmi, String address) {
	_agent_system = __rmi;
	_address = address;
	if (_address != null) {
	    to_maf.put(__rmi, this);
	}
    }

    static MAFAgentSystem_RMI to_rmi_agentsystem(MAFAgentSystem __maf) {
	if (__maf instanceof MAFAgentSystem_RMIClient) {
	    return ((MAFAgentSystem_RMIClient)__maf)._agent_system;
	} else {
	    return MAFAgentSystem_RMIImpl.find_rmi_agentsystem(__maf);
	}
    }

    static synchronized MAFAgentSystem find_maf_agentsystem(MAFAgentSystem_RMI __rmi, String address) {
	if (__rmi == null) {
	    return null;
	}

	MAFAgentSystem maf = (MAFAgentSystem)to_maf.get(__rmi);

	if (maf == null) { // && address != null) {
	    maf = new MAFAgentSystem_RMIClient(__rmi, address);
	}
	return maf;
    }

    public String getAddress() {
	return _address;
    }

    public void setAddress(String name) {
	throw new NoSuchMethodError();
    }

    /* synchronized */
    private void rebind(RemoteException ex) throws RemoteException {
/*
	if (ex.detail instanceof java.io.IOException == false) {
	    ex.printStackTrace();
	    String msg = ex.detail.getMessage();
	    throw new RemoteException(msg,new MAFExtendedException(msg));
	}
*/
	MAFAgentSystem_RMI new_rmi = Handler.rebind(_agent_system);
	if (new_rmi != null) {
	    _agent_system = new_rmi;
	    to_maf.put(new_rmi, this);
	} else {
	    String msg = "ServerNotFound";
	    throw new RemoteException(msg,new MAFExtendedException(msg));
	}
    }

    public Name create_agent(Name agent_name,
			     AgentProfile agent_profile,
			     byte[] agent,
			     String place_name,
			     Object[] arguments,
			     ClassName[] class_names,
			     String code_base,
			     MAFAgentSystem class_provider) throws ClassUnknown, ArgumentInvalid, DeserializationFailed, MAFExtendedException /* RequestRefused */ {
	try {
	    AccessController.beginPrivileged();
	    MAFAgentSystem_RMI rmi_class_provider =
		    to_rmi_agentsystem(class_provider);

	    while(true) {
		try {
		    return _agent_system.create_agent(agent_name,
						      agent_profile,
						      agent,
						      place_name,
						      arguments,
						      class_names,
						      code_base,
						      rmi_class_provider);

		} catch (ConnectException ex) {
		    rebind(ex);
		} catch (UnmarshalException ex) {
		    rebind(ex);
		} catch (MarshalException ex) {
		    rebind(ex);
		}
	    }

	} catch (RemoteException ex) {
	    if (ex.detail instanceof ClassUnknown) {
		throw (ClassUnknown)ex.detail;
	    } else if (ex.detail instanceof ArgumentInvalid) {
		throw (ArgumentInvalid)ex.detail;
	    } else if (ex.detail instanceof DeserializationFailed) {
		throw (DeserializationFailed)ex.detail;
	    } else if (ex.detail instanceof MAFExtendedException) {
		throw (MAFExtendedException)ex.detail;
	    } else if (ex.detail instanceof RuntimeException) {
		throw (RuntimeException)ex.detail;
	    } else {
		ex.printStackTrace();
		throw new RuntimeException(ex.getMessage());
	    }

	} finally {
	    AccessController.endPrivileged();
	}
    }

    public byte[][] fetch_class(ClassName[] class_name_list,
				String code_base,
				AgentProfile agent_profile) throws ClassUnknown, MAFExtendedException /*, RequestRefused */ {
	try {
	    AccessController.beginPrivileged();

	    while(true) {
		try {
		    return _agent_system.fetch_class(class_name_list,
						     code_base,
						     agent_profile);
		} catch (ConnectException ex) {
		    rebind(ex);
		} catch (UnmarshalException ex) {
		    rebind(ex);
		} catch (MarshalException ex) {
		    rebind(ex);
		}
	    }

	} catch (RemoteException ex) {
	    if (ex.detail instanceof ClassUnknown) {
		throw (ClassUnknown)ex.detail;
	    } else if (ex.detail instanceof MAFExtendedException) {
		throw (MAFExtendedException)ex.detail;
	    } else if (ex.detail instanceof RuntimeException) {
		throw (RuntimeException)ex.detail;
	    } else {
		ex.printStackTrace();
		throw new RuntimeException(ex.getMessage());
	    }
	} finally {
	    AccessController.endPrivileged();
	}
    }

    public String find_nearby_agent_system_of_profile(AgentProfile profile) throws EntryNotFound {

	try {
	    AccessController.beginPrivileged();

	    while(true) {
		try {
		    return _agent_system.find_nearby_agent_system_of_profile(profile);
		} catch (ConnectException ex) {
		    rebind(ex);
		} catch (UnmarshalException ex) {
		    rebind(ex);
		} catch (MarshalException ex) {
		    rebind(ex);
		}
	    }

	} catch (RemoteException ex) {
	    if (ex.detail instanceof EntryNotFound) {
		throw (EntryNotFound)ex.detail;
	    } else if (ex.detail instanceof RuntimeException) {
		throw (RuntimeException)ex.detail;
	    } else {
		ex.printStackTrace();
		throw new RuntimeException(ex.getMessage());
	    }
	} finally {
	    AccessController.endPrivileged();
	}
    }

    public AgentStatus get_agent_status(Name agent_name) throws AgentNotFound {

	try {
	    AccessController.beginPrivileged();

	    while(true) {
		try {
		    return _agent_system.get_agent_status(agent_name);
		} catch (ConnectException ex) {
		    rebind(ex);
		} catch (UnmarshalException ex) {
		    rebind(ex);
		} catch (MarshalException ex) {
		    rebind(ex);
		}
	    }

	} catch (RemoteException ex) {
	    if (ex.detail instanceof AgentNotFound) {
		throw (AgentNotFound)ex.detail;
	    } else if (ex.detail instanceof RuntimeException) {
		throw (RuntimeException)ex.detail;
	    } else {
		ex.printStackTrace();
		throw new RuntimeException(ex.getMessage());
	    }
	} finally {
	    AccessController.endPrivileged();
	}
    }

    public AgentSystemInfo get_agent_system_info() {

	try {
	    AccessController.beginPrivileged();

	    while(true) {
		try {
		    return _agent_system.get_agent_system_info();
		} catch (ConnectException ex) {
		    rebind(ex);
		} catch (UnmarshalException ex) {
		    rebind(ex);
		} catch (MarshalException ex) {
		    rebind(ex);
		}
	    }

	} catch (RemoteException ex) {
	    if (ex.detail instanceof RuntimeException) {
		throw (RuntimeException)ex.detail;
	    } else {
		ex.printStackTrace();
		throw new RuntimeException(ex.getMessage());
	    }

	} finally {
	    AccessController.endPrivileged();
	}
    }

    public AuthInfo get_authinfo(Name agent_name) throws AgentNotFound {

	try {
	    AccessController.beginPrivileged();
	    while(true) {
		try {
		    return _agent_system.get_authinfo(agent_name);
		} catch (ConnectException ex) {
		    rebind(ex);
		} catch (UnmarshalException ex) {
		    rebind(ex);
		} catch (MarshalException ex) {
		    rebind(ex);
		}
	    }

	} catch (RemoteException ex) {
	    if (ex.detail instanceof AgentNotFound) {
		throw (AgentNotFound)ex.detail;
	    } else if (ex.detail instanceof RuntimeException) {
		throw (RuntimeException)ex.detail;
	    } else {
		ex.printStackTrace();
		throw new RuntimeException(ex.getMessage());
	    }

	} finally {
	    AccessController.endPrivileged();
	}
    }

    public MAFFinder get_MAFFinder() throws FinderNotFound {

	try {
	    AccessController.beginPrivileged();
	    while(true) {
		try {
		    return _agent_system.get_MAFFinder();
		} catch (ConnectException ex) {
		    rebind(ex);
		} catch (UnmarshalException ex) {
		    rebind(ex);
		} catch (MarshalException ex) {
		    rebind(ex);
		}
	    }

	} catch (RemoteException ex) {
	    if (ex.detail instanceof FinderNotFound) {
		throw (FinderNotFound)ex.detail;
	    } else if (ex.detail instanceof RuntimeException) {
		throw (RuntimeException)ex.detail;
	    } else {
		ex.printStackTrace();
		throw new RuntimeException(ex.getMessage());
	    }

	} finally {
	    AccessController.endPrivileged();
	}
    }

    public Name[] list_all_agents() {

	try {
	    AccessController.beginPrivileged();
	    while(true) {
		try {
		    return _agent_system.list_all_agents();
		} catch (ConnectException ex) {
		    rebind(ex);
		} catch (UnmarshalException ex) {
		    rebind(ex);
		} catch (MarshalException ex) {
		    rebind(ex);
		}
	    }

	} catch (RemoteException ex) {
	    if (ex.detail instanceof RuntimeException) {
		throw (RuntimeException)ex.detail;
	    } else {
		ex.printStackTrace();
		throw new RuntimeException(ex.getMessage());
	    }

	} finally {
	    AccessController.endPrivileged();
	}
    }

    public Name[] list_all_agents_of_authority(byte[] authority) {

	try {
	    AccessController.beginPrivileged();
	    while(true) {
		try {
		    return _agent_system.list_all_agents_of_authority(authority);
		} catch (ConnectException ex) {
		    rebind(ex);
		} catch (UnmarshalException ex) {
		    rebind(ex);
		} catch (MarshalException ex) {
		    rebind(ex);
		}
	    }

	} catch (RemoteException ex) {
	    if (ex.detail instanceof RuntimeException) {
		throw (RuntimeException)ex.detail;
	    } else {
		ex.printStackTrace();
		throw new RuntimeException(ex.getMessage());
	    }

	} finally {
	    AccessController.endPrivileged();
	}
    }

    public String[] list_all_places() {

	try {
	    AccessController.beginPrivileged();
	    while(true) {
		try {
		    return _agent_system.list_all_places();
		} catch (ConnectException ex) {
		    rebind(ex);
		} catch (UnmarshalException ex) {
		    rebind(ex);
		} catch (MarshalException ex) {
		    rebind(ex);
		}
	    }

	} catch (RemoteException ex) {
	    if (ex.detail instanceof RuntimeException) {
		throw (RuntimeException)ex.detail;
	    } else {
		ex.printStackTrace();
		throw new RuntimeException(ex.getMessage());
	    }

	} finally {
	    AccessController.endPrivileged();
	}
    }

    public void receive_agent(Name agent_name,
			      AgentProfile agent_profile,
			      byte[] agent,
			      String place_name,
			      ClassName[] class_names,
			      String code_base,
			      MAFAgentSystem class_sender) throws ClassUnknown, DeserializationFailed, MAFExtendedException /* RequestRefused */ {

	try {
	    AccessController.beginPrivileged();
	    MAFAgentSystem_RMI rmi_class_sender =
		    to_rmi_agentsystem(class_sender);

	    while(true) {
		try {
		    _agent_system.receive_agent(agent_name,
						agent_profile,
						agent,
						place_name,
						class_names,
						code_base,
						rmi_class_sender);
		    return;
		} catch (ConnectException ex) {
		    rebind(ex);
		} catch (UnmarshalException ex) {
		    rebind(ex);
		} catch (MarshalException ex) {
		    rebind(ex);
		}
	    }

	} catch (RemoteException ex) {
	    if (ex.detail instanceof ClassUnknown) {
		throw (ClassUnknown)ex.detail;
	    } else if (ex.detail instanceof DeserializationFailed) {
		throw (DeserializationFailed)ex.detail;
	    } else if (ex.detail instanceof MAFExtendedException) {
		throw (MAFExtendedException)ex.detail;
	    } else if (ex.detail instanceof RuntimeException) {
		throw (RuntimeException)ex.detail;
	    } else {
		ex.printStackTrace();
		throw new RuntimeException(ex.getMessage());
	    }
	} finally {
	    AccessController.endPrivileged();
	}
    }

    public void resume_agent(Name agent_name) throws AgentNotFound, ResumeFailed, AgentIsRunning {

	try {
	    AccessController.beginPrivileged();

	    while(true) {
		try {
		    _agent_system.resume_agent(agent_name);
		    return;
		} catch (ConnectException ex) {
		    rebind(ex);
		} catch (UnmarshalException ex) {
		    rebind(ex);
		} catch (MarshalException ex) {
		    rebind(ex);
		}
	    }

	} catch (RemoteException ex) {
	    if (ex.detail instanceof AgentNotFound) {
		throw (AgentNotFound)ex.detail;
	    } else if (ex.detail instanceof ResumeFailed) {
		throw (ResumeFailed)ex.detail;
	    } else if (ex.detail instanceof AgentIsRunning) {
		throw (AgentIsRunning)ex.detail;
	    } else if (ex.detail instanceof RuntimeException) {
		throw (RuntimeException)ex.detail;
	    } else {
		ex.printStackTrace();
		throw new RuntimeException(ex.getMessage());
	    }
	} finally {
	    AccessController.endPrivileged();
	}
    }

    public void suspend_agent(Name agent_name) throws AgentNotFound, SuspendFailed, AgentIsSuspended {
	try {
	    AccessController.beginPrivileged();
	    while(true) {
		try {
		    _agent_system.suspend_agent(agent_name);
		    return;
		} catch (ConnectException ex) {
		    rebind(ex);
		} catch (UnmarshalException ex) {
		    rebind(ex);
		} catch (MarshalException ex) {
		    rebind(ex);
		}
	    }

	} catch (RemoteException ex) {
	    if (ex.detail instanceof AgentNotFound) {
		throw (AgentNotFound)ex.detail;
	    } else if (ex.detail instanceof SuspendFailed) {
		throw (SuspendFailed)ex.detail;
	    } else if (ex.detail instanceof AgentIsSuspended) {
		throw (AgentIsSuspended)ex.detail;
	    } else if (ex.detail instanceof RuntimeException) {
		throw (RuntimeException)ex.detail;
	    } else {
		ex.printStackTrace();
		throw new RuntimeException(ex.getMessage());
	    }
	} finally {
	    AccessController.endPrivileged();
	}
    }

    public void terminate_agent(Name agent_name) throws AgentNotFound, TerminateFailed {
	try {
	    AccessController.beginPrivileged();
	    while(true) {
		try {
		    _agent_system.terminate_agent(agent_name);
		    return;
		} catch (ConnectException ex) {
		    rebind(ex);
		} catch (UnmarshalException ex) {
		    rebind(ex);
		} catch (MarshalException ex) {
		    rebind(ex);
		}
	    }

	} catch (RemoteException ex) {
	    if (ex.detail instanceof AgentNotFound) {
		throw (AgentNotFound)ex.detail;
	    } else if (ex.detail instanceof TerminateFailed) {
		throw (TerminateFailed)ex.detail;
	    } else if (ex.detail instanceof RuntimeException) {
		throw (RuntimeException)ex.detail;
	    } else {
		ex.printStackTrace();
		throw new RuntimeException(ex.getMessage());
	    }
	} finally {
	    AccessController.endPrivileged();
	}
    }

    public byte[] retract_agent(Name agent_name) throws AgentNotFound, MAFExtendedException {

	try {
	    AccessController.beginPrivileged();
	    while(true) {
		try {
		    return _agent_system.retract_agent(agent_name);
		} catch (ConnectException ex) {
		    rebind(ex);
		} catch (UnmarshalException ex) {
		    rebind(ex);
		} catch (MarshalException ex) {
		    rebind(ex);
		}
	    }

	} catch (RemoteException ex) {
	    if (ex.detail instanceof AgentNotFound) {
		throw (AgentNotFound)ex.detail;
	    } else if (ex.detail instanceof MAFExtendedException) {
		throw (MAFExtendedException)ex.detail;
	    } else if (ex.detail instanceof RuntimeException) {
		throw (RuntimeException)ex.detail;
	    } else {
		ex.printStackTrace();
		throw new RuntimeException(ex.getMessage());
	    }
	} finally {
	    AccessController.endPrivileged();
	}
    }

    public byte[] receive_message(Name agent_name, byte[] msg) throws AgentNotFound, NotHandled, MessageEx, MAFExtendedException {

	try {
	    AccessController.beginPrivileged();
	    while(true) {
		try {
		    return _agent_system.receive_message(agent_name, msg);
		} catch (ConnectException ex) {
		    rebind(ex);
		} catch (UnmarshalException ex) {
		    rebind(ex);
		} catch (MarshalException ex) {
		    rebind(ex);
		}
	    }

	} catch (RemoteException ex) {
	    if (ex.detail instanceof AgentNotFound) {
		throw (AgentNotFound)ex.detail;
	    } else if (ex.detail instanceof NotHandled) {
		throw (NotHandled)ex.detail;
	    } else if (ex.detail instanceof MessageEx) {
		throw (MessageEx)ex.detail;
	    } else if (ex.detail instanceof MAFExtendedException) {
		throw (MAFExtendedException)ex.detail;
	    } else if (ex.detail instanceof RuntimeException) {
		throw (RuntimeException)ex.detail;
	    } else {
		ex.printStackTrace();
		throw new RuntimeException(ex.getMessage());
	    }
	} finally {
	    AccessController.endPrivileged();
	}
    }

    public void receive_oneway_message(Name agent_name, byte[] msg) throws AgentNotFound, MAFExtendedException {
	try {
	    AccessController.beginPrivileged();
	    while(true) {
		try {
		    _agent_system.receive_oneway_message(agent_name, msg);
		    return;
		} catch (ConnectException ex) {
		    rebind(ex);
		} catch (UnmarshalException ex) {
		    rebind(ex);
		} catch (MarshalException ex) {
		    rebind(ex);
		}
	    }

	} catch (RemoteException ex) {
	    if (ex.detail instanceof AgentNotFound) {
		throw (AgentNotFound)ex.detail;
	    } else if (ex.detail instanceof MAFExtendedException) {
		throw (MAFExtendedException)ex.detail;
	    } else if (ex.detail instanceof RuntimeException) {
		throw (RuntimeException)ex.detail;
	    } else {
		ex.printStackTrace();
		throw new RuntimeException(ex.getMessage());
	    }
	} finally {
	    AccessController.endPrivileged();
	}
    }

    public long receive_future_message(Name agent_name, byte[] msg, MAFAgentSystem message_sender) throws AgentNotFound, MAFExtendedException {

	try {
	    AccessController.beginPrivileged();

	    MAFAgentSystem_RMI rmi_message_sender =
		    to_rmi_agentsystem(message_sender);

	    while(true) {
		try {
		    return _agent_system.receive_future_message(agent_name,
								msg,
								rmi_message_sender);

		} catch (ConnectException ex) {
		    rebind(ex);
		} catch (UnmarshalException ex) {
		    rebind(ex);
		} catch (MarshalException ex) {
		    rebind(ex);
		}
	    }

	} catch (RemoteException ex) {
	    if (ex.detail instanceof AgentNotFound) {
		throw (AgentNotFound)ex.detail;
	    } else if (ex.detail instanceof MAFExtendedException) {
		throw (MAFExtendedException)ex.detail;
	    } else if (ex.detail instanceof RuntimeException) {
		throw (RuntimeException)ex.detail;
	    } else {
		ex.printStackTrace();
		throw new RuntimeException(ex.getMessage());
	    }
	} finally {
	    AccessController.endPrivileged();
	}
    }

    public void receive_future_reply(long return_id, byte[] reply) throws EntryNotFound, MAFExtendedException {

	try {
	    AccessController.beginPrivileged();

	    while(true) {
		try {
		    _agent_system.receive_future_reply(return_id, reply);
		    return;
		} catch (ConnectException ex) {
		    rebind(ex);
		} catch (UnmarshalException ex) {
		    rebind(ex);
		} catch (MarshalException ex) {
		    rebind(ex);
		}
	    }

	} catch (RemoteException ex) {
	    if (ex.detail instanceof EntryNotFound) {
		throw (EntryNotFound)ex.detail;
	    } else if (ex.detail instanceof MAFExtendedException) {
		throw (MAFExtendedException)ex.detail;
	    } else if (ex.detail instanceof RuntimeException) {
		throw (RuntimeException)ex.detail;
	    } else {
		ex.printStackTrace();
		throw new RuntimeException(ex.getMessage());
	    }
	} finally {
	    AccessController.endPrivileged();
	}
    }
}

package com.ibm.maf.atp;

import com.ibm.maf.AgentSystemHandler;
import com.ibm.maf.MAFAgentSystem;
import com.ibm.maf.MAFExtendedException;
import com.ibm.maf.MAFFinder;
import com.ibm.maf.AgentSystemInfo;
import com.ibm.maf.FinderNotFound;

import com.ibm.aglet.Ticket;
import com.ibm.aglet.system.AgletRuntime;

import com.ibm.awb.misc.Resource;
import com.ibm.awb.misc.Opt;

//= import java.security.AccessController;
import com.ibm.awb.security.AccessController;

import java.net.URL;
import java.net.UnknownHostException;
import java.net.InetAddress;
import java.util.Hashtable;
import java.util.Enumeration;

public class Handler implements AgentSystemHandler {

    static final int DEFAULT_PORT = 4434;

    static boolean initialized = false;

    synchronized public void initMAFAgentSystem(MAFAgentSystem local) throws MAFExtendedException {
	try {
	    if (initialized) {
		return;
	    }
	    initialized = true;

	    /*
	     * initialize default resource
	     * default values installed within the code like here
	     * will never be maintained in the property file.
	     */
	    java.util.Properties sys_props = System.getProperties();
	    String s_port =
		sys_props.getProperty("maf.port",
				      String.valueOf(DEFAULT_PORT));
	    int port;
	    try {
		port = Integer.parseInt(s_port);
	    } catch (NumberFormatException ex) {
		port = DEFAULT_PORT;
		System.err.println("maf.port must be a number, use " + DEFAULT_PORT);
	    }
	    sys_props.put("maf.port", String.valueOf(port));
//	    Resource sys_res = Resource.getResourceFor("system");
//	    int port = sys_res.getInteger("maf.port", DEFAULT_PORT);

	    //res = Resource.getResourceFor("aglets");
	    //int default_port = res.getInteger("aglets.defaultport", DEFAULT_PORT);
	    //int port = res.getInteger("aglets.port", default_port);

	    Resource res = Resource.getResourceFor("atp");
	    res.setDefaultResource("atp.protocols", "atp");
	    res.setDefaultResource("atp.maxHandlerThread", "32");

	    /*
	     *
	     */
	    String hostname = getFullyQualifiedHostName();
	    local.setAddress("atp://" + hostname + ":" + port);

	    Resource system_res = Resource.getResourceFor("system");
	    /**
	     * Proxy settings
	     */
	    if (res.getBoolean("atp.useHttpProxy", false)) {
		system_res.setResource("http.proxyHost", 
				       res.getString("atp.http.proxyHost", ""));
		system_res.setResource("http.proxyPort",
				       res.getString("atp.http.proxyPort", ""));
		system_res.setResource("proxyHost", 
				       res.getString("atp.http.proxyHost", ""));
		system_res.setResource("proxyPort",
				       res.getString("atp.http.proxyPort", ""));
	    }
	    system_res.setResource("http.nonProxyHosts",
				   res.getString("atp.noProxy", ""));
	} catch (Exception ex) {
	    ex.printStackTrace();
	    throw new MAFExtendedException(ex.toString());
	}
    }

    public void startMAFAgentSystem(MAFAgentSystem local) throws MAFExtendedException {
	try {
	    Daemon daemon = new Daemon(local);
	    AgletRuntime runtime = AgletRuntime.getAgletRuntime();
	    if(runtime!=null) {
		daemon.setUser(runtime.getOwnerName(), runtime.getOwnerIdentity());
	    }
	    daemon.start();
	    Daemon.update();

	    // Register "local"(MAFAgentSystem) to MAFFinder server.
	    try {
		MAFFinder finder = local.get_MAFFinder();
		if (finder != null) {
		    try {
			AgentSystemInfo asi = local.get_agent_system_info();
			String addr = local.getAddress();
			finder.register_agent_system(asi.agent_system_name,
						     addr,
						     asi);
		    } catch (Exception ex) {
			ex.printStackTrace();
		    }
		}
	    } catch (FinderNotFound ex) {
	    }
	} catch (Exception ex ){
	    throw new MAFExtendedException(ex.toString());
	}
    }

    public MAFAgentSystem getMAFAgentSystem(Ticket ticket) throws UnknownHostException {
	MAFAgentSystem local = Daemon.getLocalAgentSystem(ticket);
	if (local != null) {
	    return local;
	}
	return new MAFAgentSystem_ATPClient(ticket);
    }

    public MAFAgentSystem getMAFAgentSystem(String address) throws UnknownHostException {

	int to   = -1;
	if (address.startsWith("//") == true) {
	    address = address.substring(2);
	    to = address.indexOf('/');

	} else if (address.startsWith("/")) {
	    address = address.substring(1);
	    to = address.indexOf('/');

	} else {
	    to = address.indexOf('/');

	}

	if (to>=0) {
	    address = address.substring(0,to);
	}

//	System.out.println("get..." + address);

	MAFAgentSystem local = Daemon.getLocalAgentSystem(address);

	if (local != null) {
	    return local;
	}

	return new MAFAgentSystem_ATPClient(address);
    }

//    static private int MAX_RETRY = 3;

    private static String getFullyQualifiedHostName() throws UnknownHostException {
	Resource res = Resource.getResourceFor("atp");

	if (res.getBoolean("atp.offline", false)) {
	    return "localhost";
	}

	final InetAddress host = InetAddress.getLocalHost();
	if(host==null) {
	    throw new UnknownHostException("Illegal local host.");
	}

	final String ipaddr = host.getHostAddress();
	if(ipaddr==null || ipaddr.equals("")) {
	    throw new UnknownHostException("IP address of local host does not exist.");
	}


	String hostname = null;
	if(res.getBoolean("atp.resolve", false)) {
	    final InetAddress canonhost = InetAddress.getByName(ipaddr);
	    if(canonhost!=null) {
		hostname = canonhost.getHostName();
	    } else {
		hostname = host.getHostName();
	    }
	    if(hostname==null || hostname.equals("")) {
		throw new UnknownHostException("No host name.");
	    }
	} else {
	    hostname = InetAddress.getLocalHost().getHostName();
	}

	String domain = res.getString("atp.domain");
	if (domain != null) {
	    if (hostname.indexOf('.')<0) {
		// you may not have any domain name
		hostname = hostname + "." + domain;
		InetAddress.getByName(hostname);
	    } else {
		System.out.println("You cannot set domain name");
	    }
	} else if (hostname.indexOf('.')<0) {
	    System.out.println("[Warning: The hostname seems not having domain name.");
	    System.out.println(" Please try -resolve option to resolve the fully qualified hostname");
            System.out.println(" or use -domain option to manually specify the domain name.]");
	}

	return hostname;
    }
}
private static ThreadGroup group = new ThreadGroup("ConnectionHandler");

    private static int BUFFSIZE = 2048;
    private static int number = 0;
    private static boolean authentication = false;
    private static int max_handlers = 32;
    private static int num_handlers = 0;
    private static int idle_handlers = 0;

    static {
	try {
	    _mdigest = MessageDigest.getInstance(MESSAGE_DIGEST_ALGORITHM);
	} catch (NoSuchAlgorithmException ex) {
	    ex.printStackTrace();
	}
	update();
    }

    static private void verboseOut(String msg) {
	Daemon.verboseOut(msg);
    }

    static boolean http_tunneling = false;
    static boolean http_messaging = false;

    static public void update() {
	Resource res = Resource.getResourceFor("atp");
	BUFFSIZE = res.getInteger("atp.buffersize", 2048);
	authentication = res.getBoolean("atp.authentication", false);
	http_tunneling = res.getBoolean("atp.http.tunneling", false);
	http_messaging = res.getBoolean("atp.http.messaging", false);
	max_handlers = res.getInteger("atp.maxHandlerThread", 32);
    }

    public ConnectionHandler(MAFAgentSystem maf, ServerSocket s) {
	super(group, "handler:" + (number++));
	_serversocket = s;
	_maf = maf;
	num_handlers ++;
	start();
    }

    synchronized public void run(){
	try {
	    while(true) {
		try {
		    idle_handlers ++;
		    try {
			AccessController.beginPrivileged();
			_connection = _serversocket.accept();
		    } finally {
			AccessController.endPrivileged();
		    }
		    idle_handlers --;
		    // synchronized (this.class) {
		    if (idle_handlers == 0 && num_handlers < max_handlers) {
			new ConnectionHandler(_maf, _serversocket);
		    }
		    // }
		    handle();
		    _connection = null;
		    headers.clear();
		} catch (Exception ex) {
		    ex.printStackTrace();
		}
	    }
	} finally {
	    num_handlers --;
	}
    }

    private java.util.Hashtable headers = new java.util.Hashtable();

    private void handle() throws IOException {
	AtpRequest request = null;
	AtpResponse response = null;
	InetAddress remoteHost = null;
	long time = System.currentTimeMillis();

	remoteHost = _connection.getInetAddress();

	verboseOut("[Connected from " + remoteHost + ']');

	InputStream in = new BufferedInputStream(_connection.getInputStream(),
						 BUFFSIZE);
	in.mark(128);
	DataInput di = new DataInputStream(in);
	String topLine = di.readLine();
	in.reset();
	if (topLine == null) {
	    try {
		_connection.close();
	    } catch (IOException exx) {
		System.err.println(exx.toString());
	    }
	    return;
	}
  request = new AtpRequestImpl(in);
	    response = new AtpResponseImpl(new BufferedOutputStream(_connection.getOutputStream(), BUFFSIZE));
	} else if (protocol.equalsIgnoreCase("HTTP")) {
	    verboseOut("[Accepting HTTP..]");

	    // Trim http headers
	    HttpFilter.readHttpHeaders(in, headers);

	    String r = (String)headers.get("method");
	    String type =(String) headers.get("content-type");

	    if ("GET".equalsIgnoreCase(r) && http_messaging ) {
		// may be HTTP browser...

		verboseOut("[Http/GET request received.]");

		request = new HttpCGIRequestImpl(in, headers);
		response = new HttpCGIResponseImpl(_connection.getOutputStream());

	    } else if ("POST".equalsIgnoreCase(r) &&
		       "application/x-atp".equalsIgnoreCase(type) &&
		       http_tunneling) {
		// http tunneling
		verboseOut("[Http/POST request received.]");

		request = new AtpRequestImpl(in);
		response = new AtpResponseImpl(new HttpResponseOutputStream(_connection.getOutputStream()));

	    } else if ("POST".equalsIgnoreCase(r) &&
		       "application/x-www-url-form".equalsIgnoreCase(type)) {

		verboseOut("[POST request received.]");
		sendHttpResponse();
		verboseOut("[Sending responser.]");

		return;

	    } else {
		throw new IOException("Unknown Content-Type:" + type);
	    }
	} else {
	    throw new IOException("unknown protocol " + protocol);
	}

	try {
	    request.parseHeaders();
	} catch (IOException ex) {
	    try {
		_connection.close();
	    } catch (IOException exx) {
		System.err.println(exx.toString());
	    }
	    Daemon.error(remoteHost,
			 System.currentTimeMillis(),
			 "",
			  ex.toString());
	    Daemon.access(remoteHost,
			  System.currentTimeMillis(),
			  request.getRequestLine(),
			  response.getStatusCode(),
			  String.valueOf('-'));
	    return;
	}

	try {
	    handleRequest(request, response);
//- 	    String agentSystem = request.getAgentSystem();
//- 	    AgentRequestHandler handler =
//- 		    _daemon.getRequestHandler(agentSystem);
//- 
//- 	    verboseOut("[Start handling : method = "+request.getMethod());
//- 
//- 	    if (handler != null) {
//- //		com.ibm.awb.misc.Debug.check();
//- 		handler.handleRequest(request, response);
//- 	    } else {
//- 		throw new ClassNotFoundException("[Agent System '" +
//- 						 agentSystem +
//- 						 "' not found]");
//- 	    }
	} catch (IOException ioe) {
	    if(Daemon.isVerbose()) {
		ioe.printStackTrace();
	    }
	    Daemon.error(remoteHost,
			  System.currentTimeMillis(),
			  "",
			  ioe.toString());
	    ioe.printStackTrace();
	    try {
		response.sendError(INTERNAL_ERROR);
	    } catch (IOException ex) {
		System.err.println(ex.toString());
	    }
//- 	} catch (ClassNotFoundException cnfe) {
//- 	    _daemon.error(remoteHost,
//- 			  System.currentTimeMillis(),
//- 			  "Error: SERVICE_UNAVAILABLE",
//- 			  cnfe.getMessage());
//- 	    cnfe.printStackTrace();
//- 	    try {
//- 		response.sendError(NOT_FOUND);
//- 	    } catch (Exception ex) {
//- 		ex.printStackTrace();
//- 	    }
	} finally {
//	    com.ibm.awb.misc.Debug.check();
	    try {
		_connection.close();
	    } catch(IOException e) {
		System.err.println(e.toString());
	    }

	    Daemon.access(remoteHost,
			  System.currentTimeMillis(),
			  request.getRequestLine(),
			  response.getStatusCode(),
			  String.valueOf('-'));
	}
    }

    /**
     * Handle ATP Requests
     */
    void handleRequest(AtpRequest request, AtpResponse response) throws IOException {
	switch( request.getMethod() ) {
	case DISPATCH:
	    handleDispatchRequest(request, response);
	    break;
	case RETRACT:
	    handleRetractRequest(request, response);
	    break;
	case FETCH:
	    handleFetchRequest(request, response);

	    break;
	case MESSAGE:
	    handleMessageRequest(request, response);
	    break;
	default:
	    response.sendError(BAD_REQUEST);
	    break;
	}
    }

    /**
     * Handles Dispatch Requests
     */
    protected void handleDispatchRequest(AtpRequest request, AtpResponse response) throws IOException {
	response.setContentType("application/x-aglets");
	boolean sent = false;
	try {

	    MAFAgentSystem class_sender =
		    MAFAgentSystem.getMAFAgentSystem(request.getSender());

	    DataInputStream in = new DataInputStream(request.getInputStream());
	    // CodeBase
	    String codebase = in.readUTF();
	    // ClassNames
	    int len = in.readInt();
	    ClassName class_names[] = new ClassName[len];
	    for(int i=0; i<len; i++) {
		String name = in.readUTF();
		byte desc[] = new byte[ in.readInt() ];
		in.readFully( desc, 0, desc.length );
		class_names[i] = new ClassName(name, desc);
	    }
	    // Agent
protected void handleRetractRequest(AtpRequest request, AtpResponse response) throws IOException {
	response.setContentType("application/x-aglets");
	boolean sent = false;
	try {
	    byte b[] = _maf.retract_agent(request.getAgentName());
	    OutputStream out = response.getOutputStream();
	    out.write(b);
//- 	    String idstr = request.getAgentId();
//- 	    int len = idstr.length();
//- 	    byte[] b = new byte[len/2];
//- 	    for(int i = 0, j=0; j<len; i++, j++) {
//- 		b[i] = (byte)(Character.digit(idstr.charAt(j++), 16) << 4);
//- 		b[i] += (byte)Character.digit(idstr.charAt(j), 16);
//- 	    }
//- 	    AgletID aid = new AgletID(b);
//- 
//- 
//- 
//- 	    // REMIND: This is supposed to be replaced with
//- 	    // other information. The remote URL is always null for the time
//- 	    // being
//- 	    URL remote = null;
//- 	    AgletContextImpl context = getAgletContext(request);
//- 	    if (context == null) {
//- 		response.sendError(NOT_FOUND);
//- 		return;
//- 	    }
//- 	    context.revertAglet(aid, remote, response.getOutputStream());
	    response.setStatusCode(OKAY);
	    response.sendResponse();
	    sent = true;
	} catch (SecurityException ex) {
	    response.sendError(FORBIDDEN);
	    sent = true;
//- 	} catch (DeserializationFailed ae) {
//- 	    response.sendError(NOT_FOUND);
	} catch (AgentNotFound ex) {
	    response.sendError(NOT_FOUND);
	    sent = true;

	} catch (MAFExtendedException ex) {
	    ex.printStackTrace();
	    response.sendError(INTERNAL_ERROR);
	    sent = true;
	} finally {
	    if (sent == false) {
		response.sendError(INTERNAL_ERROR);
	    }
	}
    }
	
    /**
     * Handles fetch requests.
     * @param request
     * @param response
     */
    protected void handleFetchRequest(AtpRequest request, AtpResponse response) throws IOException {
	byte[] bytecode = null;
	response.setContentType("application/x-aglets");
	boolean sent = false;
	try {
	    byte b[][] = _maf.fetch_class(null,
					  request.getFetchClassFile(),
					  request.getAgentProfile());

	    OutputStream out = response.getOutputStream();
	    verboseOut("fetch_class("+request.getFetchClassFile()+") : "+b[0].length+"bytes");
//	    if(Daemon.isVerbose()) {
//		dumpBytes(b[0]);
//	    }
	    out.write(b[0]);

	    response.setStatusCode(OKAY);
	    response.sendResponse();
	    sent = true;

	} catch (ClassUnknown ex) {

	    response.sendError(NOT_FOUND);
	    sent = true;

	} catch (MAFExtendedException ex) {
	    response.sendError(INTERNAL_ERROR);
	    sent = true;

	} finally {
	    if (sent == false) {
		response.sendError(NOT_FOUND);
	    }
	}
    }	
//- 	    String filename = request.getRequestURI().getFile();
//- 	    int index = filename.lastIndexOf('/');
//- 
//- 	    String dirname = filename.substring(0,index);
//- 
//- 	    filename = filename.substring(index+1,filename.length());
//- 
//- 	    if (AgletsSystem.getSecurityManager() != null) {
//- 		//
//- 		// REMIND: this part should be moved to SecurityManager
//- 		//
//- 		if (FileUtils.checkFile(dirname, agletsExportPath) == false) {
//- 		    throw new AgletsSecurityException("Illegal Fetch Request "
//- 						      + dirname + ' '
//- 						      + filename);
//- 		}
//- 	    }
//- 
//- 	    bytecode = getClassData(dirname,filename);
//- 
//- 	    response.setStatusCode(OKAY);
//- 
//- 	    OutputStream out = response.getOutputStream();
//- 	    out.write(bytecode);
//- 
//- 	    response.sendResponse();
//- 	} catch (SecurityException ce) {
//- 	    response.sendError(FORBIDDEN);
//- 	} catch (ClassNotFoundException ce) {
//- 	    response.sendError(NOT_FOUND);
//- 	} catch (IOException ie) {
//- 	    response.sendError(INTERNAL_ERROR);
//- 	}

    protected void handleMessageRequest(AtpRequest request, AtpResponse response) throws IOException {

	response.setContentType("application/x-aglets");
	boolean sent = false;

	Name name       = request.getAgentName();
	InputStream in  = request.getInputStream();
	byte type = (byte)in.read();

	int len = request.getContentLength();
	byte content[] = new byte[len -1];
	new DataInputStream(in).readFully(content);

	try {
	    switch(type) {
	    case SYNC:
		try {
		    byte ret[] = _maf.receive_message(name, content);
		    OutputStream out = response.getOutputStream();
		    out.write(HANDLED);
		    out.write(ret, 0, ret.length);
//		    DataOutput out = new DataOutputStream(...);
//		    out.writeByte(HANDLED);

		    response.setStatusCode(OKAY);
		    response.sendResponse();
		} catch (NotHandled ex) {
		    response.getOutputStream().write(NOT_HANDLED);
//		    DataOutput out = new DataOutputStream(
//		    out.writeByte(NOT_HANDLED);
		    response.setStatusCode(OKAY);
		    response.sendResponse();

		} catch (MessageEx ex) {
		    DataOutput out =
			    new DataOutputStream(response.getOutputStream());
		    out.writeByte(EXCEPTION);
		    ex.write(out);
		    response.setStatusCode(OKAY);
		    response.sendResponse();
		}
		break;
	    case FUTURE:
		String sender_address = request.getSender();
		MAFAgentSystem sender =
			MAFAgentSystem.getMAFAgentSystem(sender_address);
		long id = _maf.receive_future_message(name, content, sender);
		if (sender instanceof MAFAgentSystem_ATPClient) {
		    ((MAFAgentSystem_ATPClient)sender).registerFutureReply(this, id);
		}
		OutputStream out = response.getOutputStream();
		response.setStatusCode(OKAY);
		response.sendResponse();

		synchronized(this) {
		    while(future_reply == null) {
			try {
			    wait();
			} catch (InterruptedException ex) {
			}
		    }
		    out.write(future_reply);
		    out.flush();
		    out.close();
		    future_reply = null;
		}
//- 	try {
//- 	    DataOutput out = new DataOutputStream(response.getOutputStream());
//- 	    out.write(reply);
//- 	    response.setStatusCode(OKAY);
//- 	    response.sendResponse();
//- 	} catch (IOException ex) {
//- 	    throw new MAFExtendedException("UnexpectedException " +ex);
//- 	}
		break;
	    case ONEWAY:
		_maf.receive_oneway_message(name, content);
		response.getOutputStream();
		response.setStatusCode(OKAY);
		response.sendResponse();
		break;
	    }
	    sent = true;

	} catch (AgentNotFound ex) {
	    response.sendError(NOT_FOUND);
	    sent = true;

	} catch (ClassUnknown ex) {
	    response.sendError(NOT_FOUND);
	    sent = true;

	} catch (DeserializationFailed ex) {
	    response.sendError(NOT_FOUND);
	    sent = true;

	} catch (MAFExtendedException ex) {
	    response.sendError(INTERNAL_ERROR);
	    sent = true;

	} finally {
	    if (sent == false) {
		response.sendError(INTERNAL_ERROR);
	    }
	}
    }
//- 	    AgletID aid = null;
//- 	    if (obj instanceof AgletID) {
//- 		aid = (AgletID)obj;
//- 	    } else {
//- 		int len = ref.length();
//- 		byte[] b = new byte[len/2];
//- 		for(int i = 0, j=0; j<len; i++, j++) {
//- 		    b[i] = (byte)(Character.digit(ref.charAt(j++), 16) << 4);
//- 		    b[i] += (byte)Character.digit(ref.charAt(j), 16);
//- 		}
//- 		aid = new AgletID(b);
//- 	    }
//- 
//- //	    AgletID aid = new AgletID(b);
//- //	    String t =
//- 	    context.handleMessageRequest(aid,
//- 					 request.getAgentLanguage(),
//- 					 request.getInputStream(),
//- 					 response);
//- //	    response.setContentType(t);
//- //	    response.setStatusCode(OKAY);
//- //	    response.sendResponse();
//- 	} catch (InvalidAgletException ex) {
//- 	    response.sendError(NOT_FOUND);
//- 	} catch (Exception ex) {
//- 	    response.sendError(INTERNAL_ERROR);
//- 	}
//-     }
    byte future_reply[] = null;
    synchronized void sendFutureReply(byte b[]) {
	future_reply = b;
	notify();
    }

    /*
     *
     */
    private static final String CRLF       = "\r\n";
    private void sendHttpResponse() throws IOException {
	PrintStream p = new PrintStream(_connection.getOutputStream());
	// auto flush must be false.
	p.print("HTTP/1.0 200 OKAY" + CRLF);
	p.print("Content-type: text/html" + CRLF);

	String s = "<HTTP><HEAD> ATP DAEMON/0.1 </HEAD><BODY>" +
		   "<H1> IBM ATP DAEMON/0.1 </H1><BR>" +
		   "</BODY></HTTP>";
	p.print("Content-length: " + s.length() + CRLF + CRLF);
	p.println(s);
	_connection.getOutputStream().flush();
	_connection.close();
//	_connection.getOutputStream().close();
//	p.flush();
//	p.close();
    }

    static byte[] calculateMIC(SharedSecret secret, byte[] agent) {
	if (secret == null) {
	    // No shared secret
	    return null;
	}
	if (agent == null) {
	    // No aglet byte sequence
	    return null;
	}
	_mdigest.reset();
	_mdigest.update(agent);
	_mdigest.update(secret.secret());
	return _mdigest.digest();
    }
 private static boolean equalsSeq(byte[] seqa, byte[] seqb) {
	if (seqa == null && seqb == null) {
	    return true;
	}
	if (seqa == null || seqb == null || seqa.length != seqb.length) {
	    return false;
	}
	for(int i = 0; i < seqa.length; i++) {
	    if (seqa[i] != seqb[i]) {
		return false;
	    }
	}
	return true;
    }

    private static byte[] getMIC(AtpRequest request) {
	String micstr = request.getRequestParameter("mic");
	if (micstr == null) {
	    return null;
	}
	byte[] mic = null;
	try {
	    mic = Hexadecimal.parseSeq(micstr);
	} catch(NumberFormatException excpt) {
	    System.err.println("Illegal MIC in ATP request header : "+micstr);
	}
	return mic;
    }

    public String toString() {
	return super.toString() +
		", handling = " + (_connection != null);
    }

    private static void dumpBytes(byte[] bytes) {
	if(bytes!=null) {
	    for(int i=0; i<bytes.length; i++) {
		System.out.print(Hexadecimal.valueOf(bytes[i]));
		if(i%16==15) {
		    System.out.println();
		} else {
		    System.out.print(" ");
		}
	    }
	    if(bytes.length%16!=0) {
		System.out.println();
	    }
	}
    }
}
import com.ibm.aglet.*;
import com.ibm.aglet.event.*;

import java.net.URL;
import java.util.Hashtable;
import java.util.Enumeration;

/**
 * The HostCollector carries a list of aglet server names.
 * When it moves to another server, it adds current server address
 * to the list. If there is no HostList aglet is running, it creates
 * an instance of HostList on that server. If a HostList aglet is running,
 * it appends a list of server name to list in the HostList and
 * then get the list belongs to the HostList.
 * 
 * @version     1.00    $Date: 2002/03/16 00:42:03 $
 * @author      Yoshiaki Mima
 * @see examples.finder.HostList
 */

public class HostCollector extends Aglet implements MobilityListener {
	Hashtable hostList;

	public void appendList(Hashtable list) {
		for (Enumeration e = list.keys(); e.hasMoreElements(); ) {
			Object key = e.nextElement();

			if (hostList.get(key) == null) {
				System.out.println("new: " + key);
				hostList.put(key, "new");
			} else {
				System.out.println("key: " + key + " value: " 
								   + hostList.get(key));
			} 
		} 
	}
	public boolean handleMessage(Message msg) {
		if (msg.sameKind("dialog")) {
			try {
				System.out.println(hostList);
			} catch (Exception ex) {
				ex.printStackTrace();
			} 
			return true;
		} else if (msg.sameKind("shutdown")) {
			try {
				deactivate(0);
			} catch (Exception e) {}
			return true;
		} else {}
		return true;
	}
	public void onArrival(MobilityEvent event) {
		AgletProxy ap = (AgletProxy)getAgletContext().getProperty("hostlist");

		hostList.put(getAgletContext().getHostingURL().toString(), "running");

		try {
			if ((ap == null) ||!ap.isValid()) {
				ap = getAgletContext().createAglet(getCodeBase(), 
												   "examples.finder.HostList", 
												   hostList);
			} 

			ap.sendMessage(new Message("append", hostList));
			Hashtable list = 
				(Hashtable)ap.sendMessage(new Message("getlist"));

			if (list != null) {
				appendList(list);
			} 
		} catch (Exception e) {
			System.out.println(e);
		} 
	}
	public void onCreation(Object init) {
		hostList = new Hashtable();
		AgletProxy ap = (AgletProxy)getAgletContext().getProperty("hostlist");

		hostList.put(getAgletContext().getHostingURL().toString(), "running");

		try {
			if ((ap == null) ||!ap.isValid()) {
				ap = getAgletContext().createAglet(getCodeBase(), 
												   "examples.finder.HostList", 
												   hostList);
			} 
		} catch (Exception e) {
			System.out.println(e);
		} 

		addMobilityListener(this);
	}
	public void onDispatching(MobilityEvent event) {}
	public void onRetraction(MobilityEvent event) {}
	public void onReverting(MobilityEvent event) {}
}
