import Org.omg.CosConcurrencyControl.*;
import Org.omg.PortableServer.POA;
import Org.omg.CosTransactions.*;
import java.util.*;

class TransactionalLockSetImpl extends TransactionalLockSetPOA {
	private Hashtable locks = new Hashtable();
	private Vector queue = new Vector();
	private Vector related  = new Vector();
	private LockSetFactoryImpl factory;
	private boolean is_active = true;

	TransactionalLockSetImpl(LockSetFactoryImpl factory) {
		this.factory = factory;
	}

	public void change_mode(Coordinator current, lock_mode held_mode, lock_mode new_mode) throws LockNotHeld {
		synchronized (queue) {
			check_active();
			TransactionCoordinator tc = factory.get_transaction_coordinator(current);
			Request rqst = null;
			synchronized (tc) {
				check_status(tc);
				if (attempt_change(tc, new_mode, held_mode)) {
					return;
				}
				rqst = new Request();
				rqst.state = LockSetFactoryImpl.REQUEST;
				rqst.current = tc;
				rqst.to_do = Request.CHANGE;
				rqst.set_mode = new_mode;
				rqst.reset_mode = held_mode;
				queue.addElement(rqst);
				tc.get_lock_coordinator(this);
			}
			while (rqst.state == LockSetFactoryImpl.REQUEST) {
				try {
					queue.wait();
				} catch (Exception e) {
					e.printStackTrace(System.out);
					throw new Org.omg.CORBA.INTERNAL();
				}
			};
			switch (rqst.state) {
				case LockSetFactoryImpl.COMMIT :
				case LockSetFactoryImpl.NO_TRANS :
					throw new Org.omg.CORBA.INVALID_TRANSACTION();
				case LockSetFactoryImpl.ROLLBACK :
					throw new Org.omg.CORBA.TRANSACTION_ROLLEDBACK();
				case LockSetFactoryImpl.REJECT :
					throw new LockNotHeld();
			}
			if (attempt_lock_from_queue()) {
				queue.notifyAll();
			};
		}
	}

	//    public void destroy() throws LockExists {
	public void destroy() {
		synchronized (queue) {
			check_active();
			is_active = false;
			if (locks.size() > 0) {
				Enumeration enum = locks.elements();
				while (enum.hasMoreElements()) {
					TransactionLocks ls = (TransactionLocks) enum.nextElement();
					if (ls.any_locks()) {
						throw new RuntimeException("LockExists");
					}
				}
			}
			factory.remove_me(this);
		};
	}

	public LockCoordinator get_coordinator(Coordinator which) {
		TransactionCoordinator tc = factory.get_transaction_coordinator(which);
		return tc.get_lock_coordinator(this);
	}

	public void lock(Coordinator current, lock_mode mode) {
		synchronized (queue) {
			check_active();
			TransactionCoordinator tc = factory.get_transaction_coordinator(current);
			Request rqst = null;
			synchronized (tc) {
				check_status(tc);
				if (attempt_lock(tc, mode)) {
					return;
				}
				rqst = new Request();
				rqst.state = LockSetFactoryImpl.REQUEST;
				rqst.current = tc;
				rqst.to_do = Request.LOCK;
				rqst.set_mode = mode;
				rqst.reset_mode = null;
				queue.addElement(rqst);
				tc.set_lock_coordinator(this);
			}
			while (rqst.state == LockSetFactoryImpl.REQUEST) {
				try {
					queue.wait();
				} catch (Exception e) {
					e.printStackTrace(System.out);
					throw new Org.omg.CORBA.INTERNAL();
				}
			};
			switch (rqst.state) {
				case LockSetFactoryImpl.COMMIT :
				case LockSetFactoryImpl.NO_TRANS :
					throw new Org.omg.CORBA.INVALID_TRANSACTION();
				case LockSetFactoryImpl.ROLLBACK :
					throw new Org.omg.CORBA.TRANSACTION_ROLLEDBACK();
			}
		}
	}

	public void print() {
		Enumeration enum;
		System.out.println("\n=============================================================================");
		System.out.println(" LOCKS" + locks.size());
		System.out.println("-----------------------------------------------------------------------------");
		synchronized (queue) {
			enum = locks.elements();
			while (enum.hasMoreElements()) {
				TransactionLocks r = (TransactionLocks) enum.nextElement();
				System.out.println(r.toString());
			}
			System.out.println("\n-----------------------------------------------------------------------------");
			System.out.println(" QUEUE" + queue.size());
			System.out.println("-----------------------------------------------------------------------------");
			enum = queue.elements();
			while (enum.hasMoreElements()) {
				Request r = (Request) enum.nextElement();
				System.out.println(r.toString());
			}
		};
		System.out.println("=============================================================================\n");
	}

	public boolean try_lock(Coordinator current, lock_mode mode) {
		synchronized (queue) {
			check_active();
			TransactionCoordinator tc = factory.get_transaction_coordinator(current);
			synchronized (tc) {
				check_status(tc);
				return attempt_lock(tc, mode);
			}
		}
	}

	public void unlock(Coordinator current, lock_mode mode) throws LockNotHeld {
		synchronized (queue) {
			check_active();
			TransactionCoordinator tc = factory.get_transaction_coordinator(current);
			synchronized (tc) {
				check_status(tc);
				TransactionLocks current_locks = (TransactionLocks) locks.get(tc);
				if (current_locks == null) {
					throw new LockNotHeld();
				}
				current_locks.unlock(mode);
			}
			if (attempt_lock_from_queue()) {
				queue.notifyAll();
			};
		}
	}

	synchronized void add_related(TransactionalLockSet which) {
		related.addElement(which);
	}

	private synchronized boolean attempt_change(TransactionCoordinator tc, lock_mode set_mode, lock_mode reset_mode) throws LockNotHeld {
		TransactionLocks current_locks = (TransactionLocks) locks.get(tc);
		if (current_locks == null || !current_locks.is_held(reset_mode)) {
			throw new LockNotHeld();
		}
		if (attempt_lock(tc, set_mode)) {
			current_locks.unlock(reset_mode);
			return true;
		}
		return false;
	}

	synchronized boolean attempt_lock(TransactionCoordinator tc, lock_mode mode) {
		Enumeration enum = locks.elements();
		TransactionLocks current_transaction_locks = null;
		while (enum.hasMoreElements()) {
			TransactionLocks lock = (TransactionLocks) enum.nextElement();
			if (lock.current == tc) {
				current_transaction_locks = lock;
				continue;
			}
			if (!lock.no_conflict(mode)) {
				return false;
			}
		};
		if (current_transaction_locks == null) {
			current_transaction_locks = new TransactionLocks(tc);
			tc.get_lock_coordinator(this);
			locks.put(tc, current_transaction_locks);
		}
		current_transaction_locks.lock(mode);
		return true;
	}
