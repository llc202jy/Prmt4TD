public partial class admin_group_view : System.Web.UI.Page
{
    public static double id;
    String redirect_page = "home.aspx";
    SecurityModule security;
    LoginUserInfo userInfo;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["security"] == null)
        {
            Response.Redirect(Common.sLoginPage);
            return;
        }
         //CHECK FOR SECURITY
         userInfo = (LoginUserInfo)Session["security"];
         security = userInfo.getModuleSecurity("Group Management");
         if (security == null)
             Response.Redirect(redirect_page);
         else
         {
             if (security.getView() == 0)
                 Response.Redirect(redirect_page);
             if (security.getEdit() == 0)
                 btnEdit.Visible = false;
             if (security.getDelete() == 0)
                 Button1.Visible = false;
         }

        try
         {
             if (!Page.IsPostBack)
             {               
                 this.Master.setHeader("user");
                 this.Master.setHeaderText("Candidate Group View");
                 this.Master.setBreadcrumb("<img src='../images/white_arrow_2.jpg' width='10px' height='10px' />&nbsp;<a class='active_a' href='group_list.aspx'>Candidate Group</a>&nbsp;<img src='../images/white_arrow_2.jpg' width='10px' height='10px' />&nbsp;View Candidate Group");

                 if (Request.QueryString["Id"] == String.Empty || Request.QueryString["Id"] == null)
                     Response.Redirect("group_list.aspx");
                 else
                     id = Convert.ToDouble(Request.QueryString["Id"].ToString());
                 loadData();
                 //Insert into Audit Trail
                 //LoginUserInfo userInfo = (LoginUserInfo)Session["security"];
                 SqlDbClass.insertAudit("Group View", userInfo.getName(), userInfo.getLoginName(),
                     "View the details information of group:" + lblGroupname.Text);                
                
             }
         }
         catch (Exception ex)
         {

             //Insert into Audit Trail
             string msg = ex.Message.Replace("'", " ");
            // LoginUserInfo userInfo = (LoginUserInfo)Session["security"];
             SqlDbClass.insertAudit("Group View", userInfo.getName(), userInfo.getLoginName(),
                 "Error(" + msg + ") in viewing the details information of group:" + lblGroupname.Text);

             lblErrormsg.Text = "System cannot load the page successfully.";
             Common.MessageBox(lblErrormsg.Text, this);
         }
    }

    private void loadData()
    {
        String query = "SELECT group_name,group_desc from [Group] WHERE group_id=" + id +" AND deleted=0";
        DataSet ds = new DataSet();
        ds = SqlDbClass.ExecuteDataSet(query);
        lblGroupname.Text = ds.Tables[0].Rows[0]["group_name"].ToString();
        lblDescription.Text = ds.Tables[0].Rows[0]["group_desc"].ToString();
   }
    protected void btnEdit_Click(object sender, EventArgs e)
    {
        Response.Redirect("group_edit.aspx?Id=" + id);
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {

        try
        {
            string query;

            //check dependency
            query = "SELECT cg_cand_id FROM [CandidateGroup] WHERE cg_group_id =" + id ;
            if (SqlDbClass.recordExists(query))
            {
                lblErrormsg.Text = "This group has candidates. The group cannot be deleted.";
                Common.MessageBox(lblErrormsg.Text, this);
                return;
            }           

            query = "UPDATE [Group] SET deleted=1 WHERE group_id= " + id;
            SqlDbClass.ExecuteNonQuery(query);

            //Insert into Audit Trail 
            SqlDbClass.insertAudit("Delete Group", userInfo.getName(), userInfo.getLoginName(),
                "Delete Group:" + lblGroupname.Text);
  
            Response.Write("<script>window.location = 'group_list.aspx';</script>");
        }
        catch (Exception ex)
        {
            //Insert into Audit Trail 
            string msg = ex.Message.Replace("'", "\"");
            SqlDbClass.insertAudit("Delete Group", userInfo.getName(), userInfo.getLoginName(),
                "Error(" + msg + ") in deleting group:" + lblGroupname.Text);

            lblErrormsg.Text = "System cannot delete the data from the database.";
            Common.MessageBox(lblErrormsg.Text, this);
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("group_list.aspx");
    }
}