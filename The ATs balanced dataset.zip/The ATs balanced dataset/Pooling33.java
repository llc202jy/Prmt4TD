<ObjectPooling(MinPoolSize := 2, MaxPoolSize := 5, _
CreationTimeout := 20000)> _
Public Class TestObjectPooling 
Inherits ServicedComponent
      Public Sub Perform ()
            ' Method contents go here.
      End Sub 
      Public Overrides Sub Activate()
            ' Called when removed from the pool.
      End Sub 
      Public Overrides Sub Deactivate()
            ' Called before deactivating or placing back in pool.
      End Sub 
      Public Overrides Function CanBePooled() As Boolean
            ' Called after Deactivate. Indicate your vote here.
            Return True
      End Function 
End Class 
[C#]
[ObjectPooling(Enabled=true, MinPoolSize=2, MaxPoolSize=5, CreationTimeOut=20000)]
public class TestObjectPooling : ServicedComponent
{
      public void Perform ()
      {
         // Method contents go here.
      }
      public override void Activate()
      {
         // Called when removed from the pool.
      }
      public override void Deactivate()
      {
         // Called before deactivating or placing back in pool.
      }
      public override bool CanBePooled()
      {
         // Called after Deactivate. Indicate your vote here.
         return true;
      }