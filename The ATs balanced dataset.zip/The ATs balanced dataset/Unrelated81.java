package org.codehaus.classworlds.uberjar.boot;

/*
 $Id: InitialClassLoader.java,v 1.1 2003/09/23 18:11:30 jvanzyl Exp $

 Copyright 2002 (C) The Werken Company. All Rights Reserved.
 
 Redistribution and use of this software and associated documentation
 ("Software"), with or without modification, are permitted provided
 that the following conditions are met:

 1. Redistributions of source code must retain copyright
    statements and notices.  Redistributions must also contain a
    copy of this document.
 
 2. Redistributions in binary form must reproduce the
    above copyright notice, this list of conditions and the
    following disclaimer in the documentation and/or other
    materials provided with the distribution.
 
 3. The name "classworlds" must not be used to endorse or promote
    products derived from this Software without prior written
    permission of The Werken Company.  For written permission,
    please contact bob@werken.com.
 
 4. Products derived from this Software may not be called "classworlds"
    nor may "classworlds" appear in their names without prior written
    permission of The Werken Company. "classworlds" is a registered
    trademark of The Werken Company.
 
 5. Due credit should be given to The Werken Company.
    (http://classworlds.werken.com/).
 
 THIS SOFTWARE IS PROVIDED BY THE WERKEN COMPANY AND CONTRIBUTORS
 ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 THE WERKEN COMPANY OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 OF THE POSSIBILITY OF SUCH DAMAGE.
 
 */

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URL;
import java.security.SecureClassLoader;
import java.util.Map;
import java.util.HashMap;
import java.util.jar.JarInputStream;
import java.util.jar.JarEntry;

/** Initial bootstrapping <code>ClassLoader</code>.
 *
 *  @author <a href="mailto:jason@zenplex.com">Jason van Zyl</a>
 *  @author <a href="mailto:bob@eng.werken.com">bob mcwhirter</a>
 *
 *  @version $Id: InitialClassLoader.java,v 1.1 2003/09/23 18:11:30 jvanzyl Exp $
 */
public class InitialClassLoader
    extends SecureClassLoader
{
    // ----------------------------------------------------------------------
    //     Instance members
    // ----------------------------------------------------------------------

    /** Class index. */
    private Map index;

    /** Classworlds jar URL. */
    private URL classworldsJarUrl;

    // ----------------------------------------------------------------------
    //     Constructors
    // ----------------------------------------------------------------------

    /** Construct.
     *
     *  @throws Exception If an error occurs while attempting to perform
     *          bootstrap initialization.
     */
    public InitialClassLoader()
        throws Exception
    {
        this.index = new HashMap();

        ClassLoader cl = Thread.currentThread().getContextClassLoader();

        URL classUrl = getClass().getResource( "InitialClassLoader.class" );

        String urlText = classUrl.toExternalForm();

        int bangLoc = urlText.indexOf( "!" );

        System.setProperty( "classworlds.lib",
                            urlText.substring( 0,
                                               bangLoc ) + "!/WORLDS-INF/lib" );

        this.classworldsJarUrl = new URL( urlText.substring( 0,
                                                             bangLoc ) + "!/WORLDS-INF/classworlds.jar" );
    }

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

    /** @see ClassLoader
     */
    public synchronized Class findClass(String className)
        throws ClassNotFoundException
    {
        String classPath = className.replace( '.',
                                              '/' ) + ".class";

        if ( this.index.containsKey( classPath ) )
        {
            return (Class) this.index.get( classPath );
        }

        try
        {
            JarInputStream in = new JarInputStream( this.classworldsJarUrl.openStream() );
            
            try
            {
                JarEntry entry = null;
                
                while ((entry = in.getNextJarEntry()) != null)
                {
                    if ( entry.getName().equals( classPath ) )
                    {
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        
                        try
                        {
                            byte[] buffer = new byte[ 2048 ];
                            
                            int read = 0;
                            
                            while ( in.available() > 0 )
                            {
                                read = in.read( buffer,
                                                0,
                                                buffer.length );
                                
                                if ( read < 0 )
                                {
                                    break;
                                }
                                
                                out.write( buffer,
                                           0,
                                           read );
                            }
                            
                            buffer = out.toByteArray();
                            
                            Class cls = defineClass( className,
                                                     buffer,
                                                     0,
                                                     buffer.length );
                            
                            this.index.put( className,
                                            cls );
                            
                            return cls;
                        }
                        finally
                        {
                            out.close();
                        }
                    }
                }
            }
            finally
            {
                in.close();
            }
        }
		/* (non-Javadoc)
     * @see java.sql.PreparedStatement#setNull(int, int)
     */
    public void setNull(int parameterIndex, int sqlType) throws SQLException {
        if(realStatement[0]!=null){           
            realStatement[0].setNull(parameterIndex,sqlType);
        }  
        if(realStatement[1]!=null){           
            realStatement[1].setNull(parameterIndex,sqlType);
        }  

    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#setLong(int, long)
     */
    public void setLong(int parameterIndex, long x) throws SQLException {
        if(realStatement[0]!=null){           
            realStatement[0].setLong(parameterIndex,x);
        }  
        if(realStatement[1]!=null){           
            realStatement[1].setLong(parameterIndex,x);
        }  

    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#setShort(int, short)
     */
    public void setShort(int parameterIndex, short x) throws SQLException {
        if(realStatement[0]!=null){           
            realStatement[0].setShort(parameterIndex,x);
        }  
        if(realStatement[1]!=null){           
            realStatement[1].setShort(parameterIndex,x);
        }  

    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#setBoolean(int, boolean)
     */
    public void setBoolean(int parameterIndex, boolean x) throws SQLException {
        if(realStatement[0]!=null){           
            realStatement[0].setBoolean(parameterIndex,x);
        }  
        if(realStatement[1]!=null){           
            realStatement[1].setBoolean(parameterIndex,x);
        }  

    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#setBytes(int, byte[])
     */
    public void setBytes(int parameterIndex, byte[] x) throws SQLException {
        if(realStatement[0]!=null){           
            realStatement[0].setBytes(parameterIndex,x);
        }  
        if(realStatement[1]!=null){           
            realStatement[1].setBytes(parameterIndex,x);
        }  

    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#setAsciiStream(int, java.io.InputStream, int)
     */
    public void setAsciiStream(int parameterIndex, InputStream x, int length)
            throws SQLException {
        if(realStatement[0]!=null){           
            realStatement[0].setAsciiStream(parameterIndex,x,length);
        }  
        if(realStatement[1]!=null){           
            realStatement[1].setAsciiStream(parameterIndex,x,length);
        }  

    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#setBinaryStream(int, java.io.InputStream, int)
     */
    public void setBinaryStream(int parameterIndex, InputStream x, int length)
            throws SQLException {
        if(realStatement[0]!=null){           
            realStatement[0].setBinaryStream(parameterIndex,x,length);
        }  
        if(realStatement[1]!=null){           
            realStatement[1].setBinaryStream(parameterIndex,x,length);
        }  

    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#setUnicodeStream(int, java.io.InputStream, int)
     */
    public void setUnicodeStream(int parameterIndex, InputStream x, int length)
            throws SQLException {
        if(realStatement[0]!=null){           
            realStatement[0].setUnicodeStream(parameterIndex,x,length);
        }  
        if(realStatement[1]!=null){           
            realStatement[1].setUnicodeStream(parameterIndex,x,length);
        }  

    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#setCharacterStream(int, java.io.Reader, int)
     */
    public void setCharacterStream(int parameterIndex, Reader reader, int length)
            throws SQLException {
        if(realStatement[0]!=null){           
            realStatement[0].setCharacterStream(parameterIndex,reader,length);
        }  
        if(realStatement[1]!=null){           
            realStatement[1].setCharacterStream(parameterIndex,reader,length);
        }  

    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#setObject(int, java.lang.Object)
     */
    public void setObject(int parameterIndex, Object x) throws SQLException {
        if(realStatement[0]!=null){           
            realStatement[0].setObject(parameterIndex,x);
        }  
        if(realStatement[1]!=null){           
            realStatement[1].setObject(parameterIndex,x);
        } 

    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#setNull(int, int, java.lang.String)
     */
    public void setNull(int paramIndex, int sqlType, String typeName)
            throws SQLException {
        if(realStatement[0]!=null){           
            realStatement[0].setNull(paramIndex,sqlType,typeName);
        }  
        if(realStatement[1]!=null){           
            realStatement[1].setNull(paramIndex,sqlType,typeName);
        } 

    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#setString(int, java.lang.String)
     */
    public void setString(int parameterIndex, String x) throws SQLException {
        if(realStatement[0]!=null){           
            realStatement[0].setString(parameterIndex,x);
        }  
        if(realStatement[1]!=null){           
            realStatement[1].setString(parameterIndex,x);
        } 

    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#setBigDecimal(int, java.math.BigDecimal)
    
    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#setClob(int, java.sql.Clob)
     */
    if(realStatement[0]!=null){           
            realStatement[0].setTimestamp(parameterIndex,x);
        }  
        if(realStatement[1]!=null){           
            realStatement[1].setTimestamp(parameterIndex,x);
        }

    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#setDate(int, java.sql.Date, java.util.Calendar)
     */
    public void setDate(int parameterIndex, Date x, Calendar cal)
            throws SQLException {
        if(realStatement[0]!=null){           
            realStatement[0].setDate(parameterIndex,x, cal);
        }  
        if(realStatement[1]!=null){           
            realStatement[1].setDate(parameterIndex,x,cal);
        }

    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#setTime(int, java.sql.Time, java.util.Calendar)
     */
    public void setTime(int parameterIndex, Time x, Calendar cal)
            throws SQLException {
        if(realStatement[0]!=null){           
            realStatement[0].setTime(parameterIndex,x, cal);
        }  
        if(realStatement[1]!=null){           
            realStatement[1].setTime(parameterIndex,x,cal);
        }

    }

    /* (non-Javadoc)
     * @see java.sql.PreparedStatement#setTimestamp(int, java.sql.Timestamp, java.util.Calendar)
     */
    public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
            throws SQLException {
        if(realStatement[0]!=null){           
            realStatement[0].setTimestamp(parameterIndex,x, cal);
        }  
        if(realStatement[1]!=null){           
            realStatement[1].setTimestamp(parameterIndex,x,cal);
        }

    }

        catch (IOException e)
        {
            e.printStackTrace();
            throw new ClassNotFoundException( "io error reading stream for: " + className );
        }
        
        throw new ClassNotFoundException( className ); 
    }
}