package org.phramer.interfaceimpl.pooling;

import org.phramer.*;
import org.phramer.interfaceimpl.pooling.*;

public class NBestTranslationTask extends AbstractTranslationTask
{
	private int nbestListSize;
	private String[][] output;
	
	public NBestTranslationTask(String fSentence , boolean xml , boolean chunk , int nbestListSize, int outputDelta , String[][] output)
	{
		super(fSentence , xml , chunk , outputDelta);
		this.nbestListSize = nbestListSize;
		this.output = output;
	}
	public void execute(MachineTranslator resource) throws Exception
	{
		output[outputDelta] = resource.translateNBest(fSentence , xml , chunk , nbestListSize);
	}
	public boolean putInOutput()
	{
		return false;
	}
}
package org.phramer.interfaceimpl.pooling;
import info.olteanu.utils.workpool.impl.*;
import org.phramer.*;

public class MultiThreadingBlockMachineTranslation extends SplitBlockMachineTranslator
{
	public MultiThreadingBlockMachineTranslation(BlockMachineTranslator[] mts , int chunkSize)
	{
		super(new MultiThreadedWorkpoolImpl<BlockMachineTranslator>("BlockMachineTranslation 1", mts) , new MultiThreadedWorkpoolImpl<MachineTranslator>("BlockMachineTranslation 2", mts) , mts[0].getVersion(), chunkSize);
	}
	
}
package org.phramer.interfaceimpl.pooling;

import info.olteanu.utils.workpool.*;
import info.olteanu.utils.workpool.impl.*;
import info.olteanu.utils.workpool.service.*;
import java.io.*;
import org.phramer.*;
import org.phramer.interfaceimpl.pooling.*;
import java.util.*;

// code from MultiThreadedPhramerWrapper

public class WorkpoolMachineTranslator implements MachineTranslator, PooledService<MachineTranslator,AbstractTranslationTask,PhramerException>
{
	private final String version;
	private final Workpool<MachineTranslator> workpool;
	
	public WorkpoolMachineTranslator(Workpool<MachineTranslator> workpool , String version)
	{
		this.workpool = workpool;
		if (!workpool.isRunning())
			workpool.start();
		this.version = version;
	}
	
	public void enqueueTask(AbstractTranslationTask t)
	{
		workpool.add(t);
	}
	public void waitForCompletion() throws PhramerException
	{
		try
		{
			workpool.waitForCompletion();
		}
		catch (InterruptedException e)
		{
			throw new PhramerException(e);
		}
		assert workpool.getOutput(true).size() == 0;
	}
	
	public boolean allowConcurrency()
	{
		return true;
	}
	
	public String getVersion()
	{
		return version;
	}
	
	private static class TranslateMtTask extends Task<MachineTranslator>
	{
		private final String fSentence;
		private final int sentenceIdx;
		private final boolean xml;
		private final boolean chunk;
		private final Map<String,String[]> metaData;
		public String output;
		TranslateMtTask(String fSentence, int sentenceIdx, boolean xml, boolean chunk, Map<String,String[]> metaData)
		{
			this.fSentence = fSentence;
			this.sentenceIdx = sentenceIdx;
			this.xml = xml;
			this.chunk = chunk;
			this.metaData = metaData;
		}
		public void execute(MachineTranslator resource) throws Exception
		{
			output = resource.translate(fSentence, sentenceIdx, xml, chunk, metaData);
		}
		public boolean putInOutput()
		{
			return true;
		}
	}
	public String translate(String fSentence, int sentenceIdx, boolean xml, boolean chunk) throws PhramerException, IOException
	{
		return translate(fSentence, sentenceIdx, xml, chunk, null);
	}
	public String translate(String fSentence, int sentenceIdx, boolean xml, boolean chunk, Map<String,String[]> metaData) throws PhramerException, IOException
	{
		TranslateMtTask t = new TranslateMtTask(fSentence , sentenceIdx , xml , chunk, metaData);
		try
		{
			workpool.executeTask(t);
		}
		catch (InterruptedException e)
		{
			throw new PhramerException(e);
		}
		return t.output;
	}
	
	
	private static class TranslateNbestMtTask extends Task<MachineTranslator>
	{
		private final String fSentence;
		private final boolean xml;
		private final boolean chunk;
		private final int nbestListSize;
		private final Map<String,String[]> metaData;
		public String[] output;
		
		TranslateNbestMtTask(String fSentence, boolean xml, boolean chunk, Map<String,String[]> metaData, int nbestListSize)
		{
			this.fSentence = fSentence;
			this.xml = xml;
			this.chunk = chunk;
			this.nbestListSize = nbestListSize;
			this.metaData = metaData;
		}
		public void execute(MachineTranslator resource) throws Exception
		{
			output = resource.translateNBest(fSentence, xml, chunk , metaData, nbestListSize);
		}
		public boolean putInOutput()
		{
			return true;
		}
	}
	public String[] translateNBest(String fSentence, boolean xml, boolean chunk, int nbestListSize) throws PhramerException, IOException
	{
		return translateNBest(fSentence, xml, chunk, null, nbestListSize);
	}
	public String[] translateNBest(String fSentence, boolean xml, boolean chunk, Map<String,String[]> metaData, int nbestListSize) throws PhramerException, IOException
	{
		TranslateNbestMtTask t = new TranslateNbestMtTask(fSentence , xml , chunk , metaData, nbestListSize);
		try
		{
			workpool.executeTask(t);
		}
		catch (InterruptedException e)
		{
			throw new PhramerException(e);
		}
		return t.output;
	}
	
	