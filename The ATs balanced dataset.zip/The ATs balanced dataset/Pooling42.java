				final ThreadConstructor tcon){		
			return getWorkerPool(f, RuntimeExceptionReporter.instance(), tcon);
		}
	    /**
	     * creates NBWorkerPoolOwner.
	     * it's equivalent as calling <br><code>
	     * getWorkerPool(f, hdl, SimpleThreadConstructor.instance());
	     * <br></code>     
	     * @param f the WorkerPoolingFactory instance.
	     * @param hdl the handler of runtime exception
	     * @return a NBWorkerPoolOwner object.
	     * @see PoolFacade.NonBlocking#getWorkerPool(WorkerPoolingFactory, RuntimeExceptionHandler, ThreadConstructor)
	     */	
		public static NBWorkerPoolOwner getWorkerPool(final WorkerPoolingFactory f, 
				final RuntimeExceptionHandler hdl){	
			return getWorkerPool(f, hdl, SimpleThreadConstructor.instance());
		}
	    /**
	     * creates NBWorkerPoolOwner.
	     * It firstly constructs a WorkerEngineFactory instance using tcon,
	     * then creates a WorkerPooling object using f
	     * finally it calls <code>getWorkerPool(pooling, hdl);</code>      
	     * @param f the WorkerPoolingFactory instance.
	     * @param hdl the handler of runtime exception
	     * @param tcon the constructor of threads
	     * @return a NBWorkerPoolOwner object.
	     * @see PoolFacade.NonBlocking#getWorkerPool(WorkerPooling, RuntimeExceptionHandler)
	     */	
		public static NBWorkerPoolOwner getWorkerPool(final WorkerPoolingFactory f, 
				final RuntimeExceptionHandler hdl, final ThreadConstructor tcon){
			final WorkerPooling pooling = f.newWorkerPooling(SimpleWorkerEngineFactory.instance(tcon));
			return getWorkerPool(pooling, hdl);
		}
	    /**
	     */
		public static NBProcessorPoolOwner getProcessorPool(final WorkerPoolingFactory f){
			return getProcessorPool(f, RuntimeExceptionReporter.instance(), SimpleThreadConstructor.instance());
		}
	    /**
	     * creates NBProcessorPoolOwner.
	     * it's equivalent as calling <br><code>
	     * getProcessorPool(f, RuntimeExceptionReporter.instance(), tcon);
	     * <br></code>
	     * @param f the WorkerPoolingFactory instance.
	     * @param tcon the ThreadConstructor instance
	     * @return a NBProcessorPoolOwner object.
	     * @see PoolFacade.NonBlocking#getProcessorPool(WorkerPoolingFactory, RuntimeExceptionHandler, ThreadConstructor)
	     */
		public static NBProcessorPoolOwner getProcessorPool(final WorkerPoolingFactory f,
				final ThreadConstructor tcon){
			return getProcessorPool(f, RuntimeExceptionReporter.instance(), tcon);
		}
	    /**
	     * creates NBProcessorPoolOwner.
	     * it's equivalent as calling <br><code>
	     * getProcessorPool(f, hdl, SimpleThreadConstructor.instance());
	     * <br></code>
	     * @param f the WorkerPoolingFactory instance.
	     * @param hdl the handler of runtime exception
	     * @return a NBProcessorPoolOwner object.
	     * @see PoolFacade.NonBlocking#getProcessorPool(WorkerPoolingFactory, RuntimeExceptionHandler, ThreadConstructor)
	     */
		public static NBProcessorPoolOwner getProcessorPool(final WorkerPoolingFactory f,
				final RuntimeExceptionHandler hdl){
			return getProcessorPool(f, hdl, SimpleThreadConstructor.instance());
		}
	    /**
	     * creates NBProcessorPoolOwner.
	     * It firstly constructs a WorkerEngineFactory instance using tcon,
	     * then creates a WorkerPooling object using f
	     * finally it calls <code>getProcessorPool(pooling, hdl);</code>
	     * @param f the WorkerPoolingFactory instance.
	     * @param hdl the handler of runtime exception
	     * @param tcon the constructor of threads
	     * @return a NBProcessorPoolOwner object.
	     * @see PoolFacade.NonBlocking#getProcessorPool(WorkerPooling, RuntimeExceptionHandler)
	     */
		public static NBProcessorPoolOwner getProcessorPool(final WorkerPoolingFactory f,
				final RuntimeExceptionHandler hdl, final ThreadConstructor tcon){
			final WorkerPooling pooling = f.newWorkerPooling(SimpleWorkerEngineFactory.instance(tcon));
			return getProcessorPool(pooling, hdl);
		}
	    /**
	     * creates NBProcessorPoolOwner.
		 * @param pooling the WorkerPooling object.
	     * @param hdl the handler of runtime exception
	     * @return a NBProcessorPoolOwner object.
	     */
		public static NBProcessorPoolOwner getProcessorPool(final WorkerPooling pooling,
				final RuntimeExceptionHandler hdl){
			return WorkerPooling2NBProcessorPool.bridge(pooling, SimpleProcessorPooler.instance(hdl));
		}
   }
    public final void releaseWorker(WorkerEngine worker){
    	pooling.releaseWorker(worker);
    	synchronized(this){
    		notify();
    	}
    }
	public final void forgetWorker(WorkerEngine worker){
		pooling.forgetWorker(worker);
		synchronized(this){
			notify();
		}
	}
	
	public final void retain(final int count){
		pooling.retain(count);
	}
	public final void prepare(final int count){
		pooling.prepare(count);
	}
    private final WorkerPooling pooling;
    private SyncedWorkerPooling(WorkerPooling pooling){
    	this.pooling = pooling;
 