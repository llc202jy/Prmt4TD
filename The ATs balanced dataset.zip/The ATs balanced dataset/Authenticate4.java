 * PaperDog session bean
 * 
 * @author Daniel Mendler <dmendler@imedic.de>
 * @ejb:bean name="AuthService" jndi-name="ejb/PaperDog/AuthService"
 *           type="Stateful" cmp-version="2.x" view-type="remote"
 * @ejb.transaction type="NotSupported"
 * @jboss.container-configuration name="Standard Stateful SessionBean"
 * @ejb:interface generate="remote" extends="javax.ejb.EJBObject"
 * @ejb:home generate="remote" extends="javax.ejb.EJBHome"
 */
public class AuthServiceBean extends AbstractSessionBean {

    private static final long serialVersionUID = -8462533698030524815L;

    private static final Logger logger = Logger
            .getLogger(AuthServiceBean.class);

    private SessionCredential krbSession;

    /**
     * Create
     * 
     * @ejb:create-method view-type="both"
     */
    public void ejbCreate(BuildID build) throws CreateException {
        if (build == null)
            throw new IllegalArgumentException();

        if (!build.equals(BuildID.get()))
            throw new CreateException("Wrong build: server=" + BuildID.get()
                    + ", client=" + build);

        if (logger.isDebugEnabled())
            logger.debug("Creating...");
    }

    /**
     * Login
     * 
     * @ejb:interface-method view-type="remote"
     */
    public LoginResult login(String name, String password)
            throws AuthenticationException {
        if (logger.isDebugEnabled())
            logger.debug(name + " is logging in");

        return Service.getAuthentication().login(name, password);
    }

    /**
     * Write kerberos login token (not always supported by backend)
     * 
     * @ejb:interface-method view-type="remote"
     */
    public byte[] krbLoginToken(byte[] token) throws AuthenticationException {
        if (logger.isDebugEnabled())
            logger.debug("Logging in with Kerberos ticket");

        Authentication auth = Service.getAuthentication();
        if (!(auth instanceof AuthKrbExtension))
            throw new AuthenticationException(
                    "Kerberos authentication not supported by backend");

        AuthKrbExtension krbAuth = (AuthKrbExtension) auth;

        if (krbSession == null)
            krbSession = krbAuth.krbLoginInitiate();

        return krbAuth.krbLoginToken(krbSession, token);
    }

    /**
     * Login with Kerberos ticket (not always supported by backend)
     * 
     * This method has to be called multiple times while the result is null.
     * 
     * @ejb:interface-method view-type="remote"
     */
    public LoginResult krbLogin() throws AuthenticationException {
        if (logger.isDebugEnabled())
            logger.debug("Logging in with Kerberos ticket");

        Authentication auth = Service.getAuthentication();
        if (!(auth instanceof AuthKrbExtension))
            throw new AuthenticationException(
                    "Kerberos authentication not supported by backend");

        AuthKrbExtension krbAuth = (AuthKrbExtension) auth;
        if (krbSession == null)
            throw new AuthenticationException(
                    "krbLoginToken must be called before krbLogin");

        LoginResult result = krbAuth.krbLogin(krbSession);
        if (result != null)
            krbSession = null;
        return result;
    }

    /**
     * Confirm Login
     * 
     * @ejb:interface-method view-type="remote"
     */
    public Subject confirmLogin(SessionCredential session)
            throws AuthenticationException {
        if (logger.isDebugEnabled())
            logger.debug("Confirming login of " + session);

        return Service.getAuthentication().confirmLogin(session);
    }

    /**
     * Logout
     * 
     * @ejb:interface-method view-type="remote"
     */
    public void logout(SessionCredential session) {
        if (logger.isDebugEnabled())
            logger.debug("User is logging out");

        Service.getAuthentication().logout(session);
    }

    /**
     * Get user attribute
     * 
     * @ejb:interface-method view-type="remote"
     */
    public String getUserAttribute(String id, String key) {
        if (logger.isDebugEnabled())
            logger.debug("Getting attribute " + key + " by id " + id);
        return Service.getAuthentication().getUserAttribute(id, key);
    }

    /**
     * Update session timer (heart beat) Session can also be null. Thats usable
     * to ensure only that the bean is not destroyed.
     * 
     * @ejb:interface-method view-type="remote"
     */
    public void heartBeat(SessionCredential session) {
        if (logger.isDebugEnabled())
            logger.debug("Heart beat: " + session);
        if (session == null)
            return;
        Service.getAuthentication().heartBeat(session);
    }
}

/*******************************************************************************
 * File : $Source:
 * /cvsroot/paperdog/paperdog.server.ejb/src/de/imedic/paperdog/server/ejb/security/AuthServiceBean.java,v $
 * Date : $Date: 2006/12/13 21:40:12 $ Version: $Revision: 1.7 $ Author :
 * $Author: dmendler $
 * 
 * This file is part of the PaperDog-Project (www.paperdog.org)
 * 
 * Copyright (c) 2004, 2005 iMEDIC GmbH and others. All rights reserved. This
 * program and the accompanying materials are made available under the terms of
 * the LGPL which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/lgpl.html
 * 