namespace ObjectPool
{
      class ObjQueue
      {
           private static int maxSize = 2;
           private static readonly Queue objPool = new Queue(maxSize);
           public MyClass GetMyClass()
           {
              MyClass oMyClass;
              if (MyClass.Counter >= maxSize && objPool.Count>0)
                   oMyClass = RetrieveFromPool();
              else
                   oMyClass = GetNewMyClass();
                   return oMyClass;
           }
           private MyClass GetNewMyClass()
           {
               MyClass myObj = new MyClass();
               objPool.Enqueue(myObj);
               return myObj;
           }
           protected MyClass RetrieveFromPool()
           {
               MyClass myObj;
               if (objPool.Count>0)
               {
                   myObj = (MyClass)objPool.Dequeue();
                   MyClass.Counter--;
              }
              else
                   myObj = new MyClass();
                   return myObj;
          }
}
class MyClass
{
          public static int Counter = 0;
          public MyClass() { ++Counter; }
          private string _Firstname;
          public string Firstname
          {
               get { return _Firstname; }
               set { _Firstname = value; }
          }
}}
C#.Net - how to Implement an Object Pool in C#.NET - June 04, 2009 at 15:00 PM by Shuchi Gauri
Explain how to Implement an Object Pool in C#.NET.

Creating pool manager.

public sealed class MyPoolManager
{
       private Queue poolQ = new Queue();
       private Hashtable tblPool = new Hashtable();
       private static readonly object objLock = new object();
       private const int PoolSize = 10;
       private int count = 0;
       private static MyPoolManager poolManager = null;
       /// <summary>
       /// Private constructor to prevent instantiation
       /// </summary>
       private MyPoolManager()
       {
       }

    static MyPoolManager()
     {
          poolManager = new MyPoolManager();
     }

      public static MyPoolManager Instance
      {
           get
           {
                if (poolManager != null)
                {
                     return poolManager;
                }
                      return null;
            }
       }

      public void CreatePoolObjects(object obj)
      {
             object _obj = obj;
             count = 0;
             poolQ.Clear();
             tblPool.Clear();

             for (int objCounter = 0; objCounter < PoolSize; objCounter++)
             {
                  _obj = new object();

                  lock (objLock)
                  {
                        tblPool.Add(_obj.GetHashCode(), _obj);
                        poolQ.Enqueue(_obj);
                        count++;
                   }
              }
       }

       public bool AddObjectToPool(object obj)
       {
            if (count == PoolSize)
                 return false;

             lock (objLock)
             {
                   tblPool.Add(obj.GetHashCode(), obj);
                   poolQ.Enqueue(obj);
                   count++;
             }
                    return true;
         }

       public object ReleaseObjectFromPool()
       {
            if (count == 0)
                  return null;

             lock (objLock)
             {
                   tblPool.Remove(poolQ.Dequeue().GetHashCode());
                   count--;
                   if (poolQ.Count > 0)
                           return poolQ.Dequeue();
              }
                    return null;
         }

       public object ReleaseObjectFromPool(object obj)
       {
                if (count == 0)
                        return null;

                lock (objLock)
                {
                        tblPool.Remove(obj.GetHashCode());
                        count--;
                        PutInPoolAgain();
                        return obj;
               }
       }

       private void PutInPoolAgain()
       {
               if (poolQ.Count > 0)
                         poolQ.Clear();

               foreach (int key in tblPool.Keys)
               {
                      poolQ.Enqueue(tblPool[key]);
               }
       }

        public int CurrentObjectsInPool
        {
               get
               {
                    return count;
               }
         }

        public int MaxObjectsInPool
        {
                  get
                  {
                          return PoolSize;
                  }
         }
}

using MyPoolManager
object obj1 = new object();
object obj2 = new object();
MyPoolManager poolManager = MyPoolManager.Instance;
poolManager.AddObjectToPool(obj1);
poolManager.AddObjectToPool(obj2);
MessageBox.Show(poolManager.CurrentObjectsInPool.ToString());
poolManager.ReleaseObjectFromPool(obj1);
MessageBox.Show(poolManager.CurrentObjectsInPool.ToString());
object obj = null;
for(;;)
{
       obj = poolManager.ReleaseObjectFromPool();
       if(obj != null)
            MessageBox.Show(obj.GetHashCode().ToString());
       else
       {
            MessageBox.Show("No more objects in the pool");
            break;
       }
}