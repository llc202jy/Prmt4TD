
	public static Center mapCenterBOToCenter(CenterBO center) {
		Center newCenter = new Center();
		newCenter.setName(center.getDisplayName());
		newCenter.setOfficeId(center.getOffice().getOfficeId());
		newCenter.setLoanOfficerId(center.getPersonnel().getPersonnelId());
		MeetingBO meeting = center.getCustomerMeeting().getMeeting();
		if (meeting.isMonthly()) {
			newCenter.setMonthlyMeeting(
				MeetingMapper.mapMeetingBOToMonthlyMeeting(meeting));
		}
		else if (meeting.isWeekly()) {
			newCenter.setWeeklyMeeting(
				MeetingMapper.mapMeetingBOToWeeklyMeeting(meeting));
		}
		else {
			throw new RuntimeException(
					"Unhandled meeting type (not MONTHLY or WEEKLY)");
		}
		newCenter.setExternalId(center.getExternalId());
		newCenter.setMfiJoiningDate(mapDateToXMLGregorianCalendar(
			center.getMfiJoiningDate()));
		newCenter.setAddress(AddressMapper.mapMifosAddressToXMLAddress(
			center.getAddress()));

		// TODO: extract CustomField handling for reuse
		Set<CustomerCustomFieldEntity> fields = center.getCustomFields();
		List<CustomField> customFields = newCenter.getCustomField();
		for (CustomerCustomFieldEntity field : fields) {
			CustomField customField = new CustomField();
			customField.setFieldId(field.getFieldId());
			CustomFieldDefinitionEntity fieldDefinition = getCustomFieldDefinitionEntity(field.getFieldId());
			if (fieldDefinition.getFieldType().compareTo(CustomFieldType.ALPHA_NUMERIC.getValue()) == 0) {
				customField.setStringValue(field.getFieldValue());
			} else if (fieldDefinition.getFieldType().compareTo(CustomFieldType.NUMERIC.getValue()) == 0) {
				customField.setNumericValue(Integer.valueOf(field.getFieldValue()));
			} else if (fieldDefinition.getFieldType().compareTo(CustomFieldType.DATE.getValue()) == 0) {
				customField.setDateValue(mapStringToXMLGregorianCalendar(field.getFieldValue()));
			} else {
				throw new RuntimeException("Unhandled CustomFieldType");
			}			
			customFields.add(customField);
		}

		// TODO: extract Fee handling for reuse
		List<FeeAmount> feeAmounts = newCenter.getFeeAmount();
		Set<AccountFeesEntity> accountFees = 
			center.getCustomerAccount().getAccountFees();
		for (AccountFeesEntity feeEntity : accountFees) {
			FeeBO fee = feeEntity.getFees();
			Double amount = feeEntity.getFeeAmount();
			FeeAmount feeAmount = new FeeAmount();
			feeAmount.setAmount(BigDecimal.valueOf(amount));
			feeAmount.setFeeId(fee.getFeeId());
			feeAmounts.add(feeAmount);
		}

		// TODO: an order is imposed on output for testing purposes
		// so that the output order can be made to match the input
		// order.  There should be a better way to do this 
		sortFeeAmountsByFeeId(newCenter);
		sortCustomFieldsById(newCenter);
		
		return newCenter;
	}
	
	private static CustomFieldDefinitionEntity getCustomFieldDefinitionEntity(Short id) {
		Session session = HibernateUtil.getSessionTL();
		return (CustomFieldDefinitionEntity) session.get(CustomFieldDefinitionEntity.class, id);		
	}
	
	/* Sort the FeeAmount list by feeId to make sure we get the fees back
	 * in the same order they were created 
	 */
	private static void sortFeeAmountsByFeeId(Center center) {
		final class FeeAmountFeeIdComparator implements Comparator<FeeAmount> {
			public int compare(FeeAmount fee1, FeeAmount fee2) {
				return fee1.getFeeId() - fee2.getFeeId();
			}		
		}
		Collections.sort(center.getFeeAmount(), new FeeAmountFeeIdComparator());
	}

	/* Sort the CustomField list by fieldId to make sure we get them back
	 * in the same order they were created 
	 */
	private static void sortCustomFieldsById(Center center) {
		final class CustomFieldIdComparator implements Comparator<CustomField> {
			public int compare(CustomField field1, CustomField field2) {
				return field1.getFieldId() - field2.getFieldId();
			}		
		}
		Collections.sort(center.getCustomField(), new CustomFieldIdComparator());
	}
	
}
package org.mifos.migration.mapper;

import java.util.Date;

import org.mifos.application.meeting.business.MeetingBO;
import org.mifos.application.meeting.business.MeetingDetailsEntity;
import org.mifos.application.meeting.exceptions.MeetingException;
import org.mifos.application.meeting.util.helpers.MeetingType;
import org.mifos.application.meeting.util.helpers.RankType;
import org.mifos.application.meeting.util.helpers.WeekDay;
import org.mifos.migration.generated.MonthlyMeeting;
import org.mifos.migration.generated.WeekDayChoice;
import org.mifos.migration.generated.WeekDayOccurence;
import org.mifos.migration.generated.WeeklyMeeting;

public class MeetingMapper {

	public static WeekDay mapWeekDayChoiceToWeekDay(WeekDayChoice weekDayChoice) {
		return WeekDay.valueOf(weekDayChoice.toString());
	}
	
	public static WeekDayChoice mapWeekDayToWeekDayChoice(WeekDay weekDay) {
		return WeekDayChoice.valueOf(weekDay.toString());
	}
	
	public static RankType mapWeekDayOccurenceToRankType(WeekDayOccurence weekDayOccurence) {
		return RankType.valueOf(weekDayOccurence.toString());
	}
	
	public static WeekDayOccurence mapRankTypeToWeekDayOccurence(RankType rank) {
		return WeekDayOccurence.valueOf(rank.toString());
	}
	
	public static MeetingBO mapMonthlyMeetingToMeetingBO(MonthlyMeeting meeting) {
		short monthsBetweenMeetings = meeting.getMonthsBetweenMeetings();
		Date startDate = new Date();
		MeetingType meetingType = MeetingType.CUSTOMER_MEETING;
		String location = meeting.getLocation();
	
		MeetingBO newMeeting = null;
		
		try {
			if (meeting.getDayOfMonth() != null) {
				// monthly frequency is implicit in the constructor
				newMeeting = new MeetingBO(
						meeting.getDayOfMonth(),
						monthsBetweenMeetings,
						startDate,
						meetingType,
						location);					
			} else {
				// monthly frequency is implicit in the constructor
				newMeeting = new MeetingBO(
						mapWeekDayChoiceToWeekDay(meeting.getMeetingWeekDay()),
						mapWeekDayOccurenceToRankType(meeting.getMeetingWeekDayOccurence()),
						monthsBetweenMeetings,
						startDate,
						meetingType,
						location);					
			}
		} catch (MeetingException me) {
			throw new RuntimeException(me);
		}	
		
		return newMeeting;
	}

	public static MeetingBO mapWeeklyMeetingToMeetingBO(WeeklyMeeting meeting) {
		short weeksBetweenMeetings = meeting.getWeeksBetweenMeetings();
		Date startDate = new Date();
		MeetingType meetingType = MeetingType.CUSTOMER_MEETING;
		String location = meeting.getLocation();
	
		MeetingBO newMeeting = null;
		
		try {
			// weekly frequency is implicit in the constructor
			newMeeting = new MeetingBO(
					mapWeekDayChoiceToWeekDay(meeting.getMeetingWeekDay()),
					weeksBetweenMeetings,
					startDate,
					meetingType,
					location);					
		} catch (MeetingException me) {
			throw new RuntimeException(me);
		}	
		
		return newMeeting;
	}
	
	public static MonthlyMeeting mapMeetingBOToMonthlyMeeting(MeetingBO meeting) {
		if (!meeting.isMonthly()) {
			throw new IllegalArgumentException("Meeting required to be monthly but was not.");
		}
		if (meeting.getMeetingTypeEnum() != MeetingType.CUSTOMER_MEETING) {
			throw new IllegalArgumentException("Meeting required to be a CUSTOMER_MEETING but was not.");
		}
		short monthsBetweenMeetings = meeting.getMeetingDetails().getRecurAfter();
		// start date is ignored
		String location = meeting.getMeetingPlace();
	
		MonthlyMeeting newMeeting = new MonthlyMeeting();
		newMeeting.setLocation(location);
		newMeeting.setMonthsBetweenMeetings(monthsBetweenMeetings);
		
		MeetingDetailsEntity meetingDetails = meeting.getMeetingDetails();

		if (meetingDetails.isMonthlyOnDate()) {
			newMeeting.setDayOfMonth(meetingDetails.getDayNumber());
		} else {
			newMeeting.setMeetingWeekDay(MeetingMapper.mapWeekDayToWeekDayChoice(meetingDetails.getWeekDay()));
			newMeeting.setMeetingWeekDayOccurence(MeetingMapper.mapRankTypeToWeekDayOccurence(meetingDetails.getWeekRank()));
		}
		
		return newMeeting;
	}

	public static WeeklyMeeting mapMeetingBOToWeeklyMeeting(MeetingBO meeting) {
		if (!meeting.isWeekly()) {
			throw new IllegalArgumentException("Meeting required to be weekly but was not.");
		}
		if (meeting.getMeetingTypeEnum() != MeetingType.CUSTOMER_MEETING) {
			throw new IllegalArgumentException("Meeting required to be a CUSTOMER_MEETING but was not.");
		}
		short weeksBetweenMeetings = meeting.getMeetingDetails().getRecurAfter();
		// start date is ignored
		String location = meeting.getMeetingPlace();
	
		WeeklyMeeting newMeeting = new WeeklyMeeting();
		newMeeting.setLocation(location);
		newMeeting.setWeeksBetweenMeetings(weeksBetweenMeetings);
		
		newMeeting.setMeetingWeekDay(mapWeekDayToWeekDayChoice(meeting.getMeetingDetails().getWeekDay()));
				
		return newMeeting;
	}

}
public class ApplicationInitializer implements ServletContextListener {
	
	private static Throwable databaseVersionError;

	/**
	 * This is a simple initial use of Spring for resource bundle management
	 * and injection.  Ultimately an XMLWebApplicationContext initialized 
	 * via struts is probably the right thing to use.
	 * But this is just a first step to try introducting Spring with an
	 * initially low impact on other code and with the intent to iterate 
	 * and evolve the usage.  This usage will be refactored.
	 */
	private static ApplicationContext context = new ClassPathXmlApplicationContext(
			"org/mifos/config/applicationContext.xml");
	
	public void contextInitialized(ServletContextEvent ctx) {
		init();
	}
	
	public void init() {
		try{
			synchronized(ApplicationInitializer.class){
				initializeLogger();
				initializeHibernate();
				MifosLogManager.getLogger(LoggerConstants.FRAMEWORKLOGGER).info(
						"Logger has been initialised", false, null);
				try{
					syncDatabaseVersion();
				}catch(Throwable t){
					databaseVersionError = t;
					MifosLogManager.getLogger(LoggerConstants.FRAMEWORKLOGGER).fatal(
							"Failed to upgrade/downgrade database version", false, null, t);
				}
				if(databaseVersionError==null){
					initializeSecurity();
					configureAdminUser();
					FinancialInitializer.initialize();
					EntityMasterData.getInstance().init();
					initializeEntityMaster();
					(new MifosScheduler()).registerTasks();
					
					Configuration.getInstance();
					configureAuditLogValues();
					MifosConfiguration.getInstance().init();
				}
			}
		}catch(Exception e){
			throw new Error(e);
		}
	}
	
	public static void printDatabaseError(XmlBuilder xml) {
		synchronized(ApplicationInitializer.class){
	        if(databaseVersionError != null) {
	        	xml.startTag("p");
	        	xml.text("Here are details of what went wrong:");
	        	xml.endTag("p");

	        	xml.startTag("pre");
	        	StringWriter stackTrace = new StringWriter();
				databaseVersionError.printStackTrace(new PrintWriter(stackTrace));
				xml.text("\n" + stackTrace.toString());
	        	xml.endTag("pre");
			}
	        else {
	        	xml.startTag("p");
	        	xml.text("I don't have any further details, unfortunately.");
	        	xml.endTag("p");
	        }
	    }
	}
	
	public static void setDatabaseVersionError(Throwable error) {
		databaseVersionError = error;
	}
	
	/**
	 * Initializes Hibernate by making it read the hibernate.cfg file and also
	 * setting the same with hibernate session factory.
	 */
	public static void initializeHibernate()
			throws AppNotConfiguredException {
		try {
			String hibernatePropertiesPath = FilePaths.HIBERNATE_PROPERTIES;
			try {
				if (ResourceLoader
						.getURI(FilePaths.CONFIGURABLEMIFOSDBPROPERTIESFILE) != null)
					hibernatePropertiesPath = FilePaths.CONFIGURABLEMIFOSDBPROPERTIESFILE;
			} catch (URISyntaxException e) {
				throw new AppNotConfiguredException(e);
			}
			HibernateStartUp.initialize(hibernatePropertiesPath);
		} catch (HibernateStartUpException e) {
			throw new AppNotConfiguredException(e);
		}
	}

	/**
	 * Initializes the logger using loggerconfiguration.xml
	 * 
	 * @throws AppNotConfiguredException -
	 *             IF there is any exception while configuring the logger
	 */
	private void initializeLogger() throws AppNotConfiguredException {
		try {
			MifosLogManager.configure(FilePaths.LOGFILE);
		} catch (LoggerConfigurationException lce) {

			lce.printStackTrace();
			throw new AppNotConfiguredException(lce);
		}

	}

	/**
	 * This function initialize and bring up the authorization and
	 * authentication services
	 * 
	 * @throws AppNotConfiguredException -
	 *             IF there is any failures during init
	 */
	private void initializeSecurity() throws AppNotConfiguredException {
		try {

			AuthorizationManager.getInstance().init();

			HierarchyManager.getInstance().init();

		} catch (XMLReaderException e) {

			throw new AppNotConfiguredException(e);
		} catch (ApplicationException ae) {
			throw new AppNotConfiguredException(ae);
		} catch (SystemException se) {
			throw new AppNotConfiguredException(se);
		}

	}

	/**
	   This method sets the password for admin user. 

       This would expect that a row in
	   personnel table already exists where the user name is "mifos". Insertion
	   of that row is taken care by master data script.
	   
	   This is a temporary
	   method and would be altered when the set module is done.
	 */
	private void configureAdminUser() throws XMLReaderException,
			URISyntaxException, HibernateProcessException, SystemException {
		Session session = null;
		byte[] password = 
			EncryptionService.getInstance().createEncryptedPassword(
				"testmifos");
		try {
			session = HibernateUtil.openSession();
			Transaction trxn = session.beginTransaction();
			PersonRoles personRoles = (PersonRoles) session.createQuery(
					"from PersonRoles p where p.loginName ='mifos'")
					.uniqueResult();
			if (null != personRoles) {
				personRoles.setPassword(password);

				session.update(personRoles);
			}
			trxn.commit();
			MifosLogManager
					.getLogger(LoggerConstants.FRAMEWORKLOGGER)
					.debug(
							"password in personnel table for user name mifos has been updated ");
		} catch (HibernateException he) {
			MifosLogManager
					.getLogger(LoggerConstants.FRAMEWORKLOGGER)
					.error(
							"password in personnel table for user name mifos could not be updated  ",
							false, null, he);

		} finally {
			HibernateUtil.closeSession(session);
		}

	}
	
	private void initializeEntityMaster() throws HibernateProcessException {
		EntityMasterData.getInstance().init();
	}
	
	private void syncDatabaseVersion() throws SQLException, Exception {
		DatabaseVersionPersistence persistance = new DatabaseVersionPersistence();
		persistance.upgradeDatabase();
	}

	private void configureAuditLogValues() throws SystemException {
		AuditConfigurtion.init();
	}
	
	public void contextDestroyed(ServletContextEvent ctx) {
		
	}
	
	/**
	 * This method initializes Spring by loading this class.
	 */
	public static void initializeSpring() {
	}
}

package org.mifos.api;

    /**
     *  MifosServiceCallbackHandler Callback class 
     */

    public abstract class MifosServiceCallbackHandler{



	private Object clientData;


	/**
	* User can pass in any object that needs to be accessed once the NonBlocking 
	* Web service call is finished and appropreate method of this CallBack is called.
	* @param clientData Object mechanism by which the user can pass in user data
	* that will be avilable at the time this callback is called.
	*/
	public MifosServiceCallbackHandler(Object clientData){
		this.clientData = clientData;
	}


        
           /**
            * auto generated Axis2 call back method for findLoan method
            *
            */
           public void receiveResultfindLoan(
                    org.mifos.api.MifosServiceStub.FindLoanResponse param1) {
			        //Fill here with the code to handle the response
           }

          /**
           * auto generated Axis2 Error handler
           *
           */
            public void receiveErrorfindLoan(java.lang.Exception e) {
                //Fill here with the code to handle the exception
            }
                


    }
