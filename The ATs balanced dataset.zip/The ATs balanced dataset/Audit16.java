/*
             * Update the audit trail information.
             */

            data.setLong("ObjectVersionNum", data.getAsLong("ObjectVersionNum")+1);
            data.setDate("LastModifiedTime", new Date(System.currentTimeMillis()));
            data.setLong("LastModifiedBy", 0);

public void addAuditTrail(TableRow data, Connection conn) throws SQLException, TableRowException {
        Statement statement = null;
        ResultSet rs = null;
        
        try {
            statement = conn.createStatement();
            if (statement.executeUpdate(getCreateAuditTrailStatement(data)) < 1) {
                throw new TableRowException("Didn't create audit trail row for unknown reason.");
            }
        } finally {
            dbaccessComplete(conn, statement, rs);
        }
    }

    private String getCreateAuditTrailStatement(TableRow data) {
        StringBuffer buf = null;

        buf = new StringBuffer(1024);
        buf.append("INSERT INTO JOB__AUDIT_TRAIL (");
        buf.append("TABLE_NAME, USERNAME, CHANGE_TYPE, CHANGE_DATE, PRIMARY_KEY_VALUE)");
        buf.append(" VALUES (");
        buf.append("'" + data.getTableName() + "', ");
        if (data.getUsername() == null) {
            buf.append("'unknown', ");
        } else {
            buf.append("'" + data.getUsername() + "', ");
        }
        if (data.isNew()) {
            buf.append("'INSERT', ");
        } else if (data.isDirty()) {
            buf.append("'UPDATE', ");
        } else if (data.isRemoved()) {
            buf.append("'DELETE', ");
        } else {
            buf.append("'UNKNOWN', ");
        }
        buf.append(data.getSqlValue("LastModifiedTime") + ", ");
        buf.append("'" + data.getPrimaryKey() + "')");
        log.debug("AUDIT TRAIL: '" + buf.toString() + "'");
public Collection loadAuditTrailHistory(Oid oid, Connection conn) throws Exception {
        PreparedStatement statement = null;
        ResultSet rs = null;
        LinkedList list = null;

        list = new LinkedList();
        try {
            statement = conn.prepareStatement("SELECT USERNAME, CHANGE_TYPE, CHANGE_DATE FROM JOB__AUDIT_TRAIL WHERE TABLE_NAME=? AND PRIMARY_KEY_VALUE=? ORDER BY CHANGE_DATE");
            statement.setString(1, oid.getTableName());
            statement.setString(2, oid.getKey());
            rs = statement.executeQuery();
            while (rs.next()) {
                AuditTrailInfo info = null;

                info = new AuditTrailInfo();
 AuditTrailInfo() {
ublic class AuditTrailInfo implements Serializable

audit trail fields.
         */
        
        auditTrailFields.add(new MDMField("ObjectVersionNum", "long"));
        auditTrailFields.add(new MDMField("LastModifiedBy", "long"));
        auditTrailFields.add(new MDMField("LastModifiedTime", "date"));
    }

private LinkedList auditTrailFields = new LinkedList();

public Iterator getAuditTrailFields() {
        return auditTrailFields.iterator();

public void setHasAuditedClass(boolean value) {
        hasAuditedClass = value;
    }

    public boolean hasAuditedClass() {
        return hasAuditedClass;
    }
if (shell.audit()) {
                        dba.addAuditTrail(shell, getDataSource(jndiDataSource).getConnection());
if (shell.audit()) {
                        dba.addAuditTrail(shell, getDataSource(jndiDataSource).getConnection());
 public Collection loadAuditTrailHistory(BaseDBA dba, 
                                            String jndiDataSource,
                                            Oid oid) throws RemoteException {
        try {
            return dba.loadAuditTrailHistory(oid, getDataSource(jndiDataSource).getConnection())
  * Get the audit trail history for this <code>Persist</code> object.
     */
    public Collection getAuditTrailHistory() throws PersistException {
        if (!getDataShell().getData().audit()) {
            throw new PersistException("This persist type is not being audited.");
        }

        return pmanager.getAuditTrailHistory(getOid());
outputConstructorForFields(md.getAuditTrailFields(), pwriter, tm);
 public abstract void addAuditTrail(TableRow shell, Connection conn) 
private ServletReply getAuditTrailHistory(HttpServletRequest request, HttpServletResponse response) 
        throws Exception {
        ObjectInputStream ois = null;
        Collection result = null;
        ServletReply sr = null;
        Object [] args = null;

        try {
            ois = new ObjectInputStream(new BufferedInputStream(request.getInputStream()));
            args = (Object []) ois.readObject();
        } catch (Exception e) {
            sr = new ServletReply(EXCEPTION, new RemoteException("Error handling request", e));
            return sr;
        } finally {
            ois.close();
        }
        
        try {
            if (useEJB) {
                result = mdmSession.loadAuditTrailHistory((BaseDBA) args[0],
                                                          jndiDataSourceName,
                                                          (Oid) args[1]);
            } else {
                result = mdmSessionBean.loadAuditTrailHistory((BaseDBA) args[0],
                                                          jndiDataSourceName,
                                                          (Oid) args[1]);
            }

            sr = new ServletReply(SUCCESS, result);
        } catch (RemoteException e) {
            sr = new ServletReply(EXCEPTION, e);
        }

        return sr;
    }

    private ServletReply count(HttpServletRequest request, HttpServletResponse response) 
        throws Exception {
        ObjectInputStream ois = null;
        FindByArguments param = null;
        ServletReply sr = null;
        int result;
        Object [] args;

        try {
            ois = new ObjectInputStream(new BufferedInputStream(request.getInputStream()));
            args = (Object []) ois.readObject();
            param = (FindByArguments) args[1];
        } catch (Exception e) {
            sr = new ServletReply(EXCEPTION, new RemoteException("Error handling request", e));
            return sr;
        } finally {
            ois.close();
        }
        
        try {
            if (useEJB) {
                result = mdmSession.count((BaseDBA) args[0], jndiDataSourceName, param.getTableRow(), 
                                          param.getQuery());
            } else {
                result = mdmSessionBean.count((BaseDBA) args[0], jndiDataSourceName, param.getTableRow(),
                                              param.getQuery());
            }

            sr = new ServletReply(SUCCESS, new Integer(result));
        } catch (RemoteException e) {
            sr = new ServletReply(EXCEPTION, e);
        }

        return sr;
    }

    private ServletReply rawQuery(HttpServletRequest request, HttpServletResponse response) 
        throws Exception {
        ObjectInputStream ois = null;
        FindByArguments param = null;
        ServletReply sr = null;
        Collection rows = null;
        Object [] args;

        try {
            ois = new ObjectInputStream(new BufferedInputStream(request.getInputStream()));
            args = (Object []) ois.readObject();
        } catch (Exception e) {
            sr = new ServletReply(EXCEPTION, new RemoteException("Error handling request", e));
            return sr;
        } finally {
            ois.close();
        }
        
        try {
            if (useEJB) {
                rows = mdmSession.rawQuery((String) args[0], jndiDataSourceName);
            } else {
                rows = mdmSessionBean.rawQuery((String) args[0], jndiDataSourceName);
            }

            sr = new ServletReply(SUCCESS, rows);
        } catch (RemoteException e) {
            sr = new ServletReply(EXCEPTION, e);
        }

        return sr;
    }

    /**
     * Write the reply back to the client, throwing any exceptions 
     * that are thrown trying to do the write.
     */
    private void writeReply(HttpServletResponse response, ServletReply sr) throws IOException {
        ObjectOutputStream oos = null;

        /*
         * create ObjectOutputStream and write it to the OutputStream
         */

        response.setStatus(HttpServletResponse.SC_OK);

        oos = new ObjectOutputStream(new BufferedOutputStream(response.getOutputStream()));
        oos.writeObject(sr);
        oos.flush();
        oos.close();
    }

    private ServletReply callMethod(String methodName, HttpServletRequest request, 
                                    HttpServletResponse response) 
        throws Exception {
        ServletReply sr = null;

        if (methodName.equals(RAW_UPDATE)){
            sr = rawUpdate(request, response);
        } else if (methodName.equals(SAVE) ) {
            sr = save(request, response);
        } else if (methodName.equals(GET_KEYS) ) {
            sr =getKeys(request, response);
        } else if (methodName.equals(FIND_BY) ) {
            sr = findBy(request, response);
        } else if ( methodName.equals(LOAD)) {
            sr = load(request, response);
        } else if ( methodName.equals(COUNT)) {
            sr = count(request, response);
        } else if ( methodName.equals(GET_META_DATA)) {
            sr = getMetaData(request, response);
        } else if ( methodName.equals(GET_AUDIT_TRAIL_HISTORY)) {
            sr = getAuditTrailHistory(request, response);
        } else if ( methodName.equals(RAW_QUERY)) {
            sr = rawQuery(request, response);
        } else {
            throw new ServletException("Undefined Method: " + methodName);
        } // end of else
        return sr;
    }
private void outputAuditTrailStatements(MetaData md, PrintWriter pwriter) {
        TypeMapping tm = null;

        tm = md.getTypeMapping();
        pwriter.println("CREATE TABLE JOB__AUDIT_TRAIL (");
        pwriter.println("    TABLE_NAME " + tm.internalToDb("string") + ",");
        pwriter.println("    USERNAME " + tm.internalToDb("string") + ",");
        pwriter.println("    CHANGE_TYPE " + tm.internalToDb("string") + ",");
        pwriter.println("    CHANGE_DATE " + tm.internalToDb("date") + ",");
        pwriter.println("    PRIMARY_KEY_VALUE " + tm.internalToDb("string"));
        pwriter.println(");");
    }
 /*
         * Add the audit trail columns.
         */

        iter = md.getAuditTrailFields();
        while (iter.hasNext()) {
            MDMField f = null;

            f = (MDMField) iter.next();
            pwriter.println(",");
            pwriter.print("    " + getColumnName(f.getName()) + " " + 
                          tm.internalToDb(f.getType()));
        }

 private void outputAuditTrailStatements(MetaData md, PrintWriter pwriter) {
        TypeMapping tm = null;

        tm = md.getTypeMapping();
        pwriter.println("CREATE TABLE JOB__AUDIT_TRAIL (");
        pwriter.println("    TABLE_NAME " + tm.internalToDb("string") + ",");
        pwriter.println("    USERNAME " + tm.internalToDb("string") + ",");
        pwriter.println("    CHANGE_TYPE " + tm.internalToDb("string") + ",");
        pwriter.println("    CHANGE_DATE " + tm.internalToDb("date") + ",");
        pwriter.println("    PRIMARY_KEY_VALUE " + tm.internalToDb("string"));
        pwriter.println(");");
    }

 private void outputMethodsForAuditTrailFields(String pobjectName, String pobjectClassName,
                                                  MetaData md, PrintWriter pwriter) {
        Iterator iter = null;
        TypeMapping tm = null;
        
        tm = md.getTypeMapping();
        
        iter = md.getAuditTrailFields();
        while (iter.hasNext()) {
            MDMField f = null;
            String javaTypeName = null;

            f = (MDMField) iter.next();
            javaTypeName = tm.internalToJava(f.getType());
            pwriter.println();
            if (javaTypeName.equals("boolean")) {
                pwriter.println("    public " + javaTypeName + " is" + f.getName() + "() throws PersistException {");
                pwriter.println("        return ((" + pobjectClassName + ") this." + 
                                pobjectName + ").is" + f.getName() + "();");
            } else {
                pwriter.println("    public " + javaTypeName + " get" + 
                                f.getName() + "() throws PersistException {");
                pwriter.println("        return ((" + pobjectClassName + ") this." + 
                                pobjectName + ").get" + f.getName() + "();");
            }
            pwriter.println("    }");
        }
    }

 public Collection loadAuditTrailHistory(BaseDBA dba,
                                            String jndiDataSource,
                                            Oid oid) throws RemoteException;
}

 public Collection loadAuditTrailHistory(BaseDBA dba, Oid oid) 
        throws PersistException, RemoteException {
        URLConnection connection = null;
        ObjectOutputStream output = null;
        
        try {
            Object [] args = null;

            args = new Object[2];
            args[0] = dba;
            args[1] = oid;
            connection = getUrl(GET_AUDIT_TRAIL_HISTORY);
            connection.setUseCaches(false);
            connection.setDoInput(true);
            connection.setRequestProperty("Content-Type", "application/octet-stream");
            connection.setDoOutput(true);
            output = new ObjectOutputStream(connection.getOutputStream());
            output.writeObject(args);
            output.flush();
            output.close();
        } catch (Exception e) {
            throw new JobServletException("Error writing object: " + e);
        }

        return (Collection) getReply(connection);
    }
 private void outputMethodsForAuditTrailFields(MetaData md, PrintWriter pwriter) {
        Iterator iter = null;
        TypeMapping tm = null;
        
        tm = md.getTypeMapping();
        
        iter = md.getAuditTrailFields();
        while (iter.hasNext()) {
            MDMField f = null;
            String javaTypeName = null;

            f = (MDMField) iter.next();
            javaTypeName = tm.internalToJava(f.getType());
            pwriter.println();
            if (javaTypeName.equals("boolean")) {
                pwriter.println("    public " + javaTypeName + " is" + f.getName() + "() throws PersistException {");
                pwriter.println("        return getData().is" + f.getName() + "();");
            } else {
                pwriter.println("    public " + javaTypeName + " get" + f.getName() + "() throws PersistException {");
                pwriter.println("        return getData().get" + f.getName() + "();");
            }
            pwriter.println("    }");
        }
    }

 Collection getAuditTrailHistory(Oid oid) throws PersistException {
        try {
            Collection info = null;

            /*
             * Need to add the servlet for this, but am going
             * to do it later...
             */
            
            if (connectionMode == EJB) {
                info = mdmSession.loadAuditTrailHistory(getClassInfo().getDba(),
                                                        dataSourceJNDIName, oid);
                                                        
            } else if (connectionMode == LOCAL) {
                info = beanInstance.loadAuditTrailHistory(getClassInfo().getDba(),
                                                          dataSourceJNDIName, oid);
            } else {
                info = servletClient.loadAuditTrailHistory(getClassInfo().getDba(), oid);
            }
            return info;
        } catch (RemoteException e) { 
            e.printStackTrace();
            if (e.detail != null &&
                e.detail instanceof DataIntegrityException) {
                throw (DataIntegrityException) e.detail;
            } else {
                throw new PersistException("Can't load audit trail info.");
            }
        }
    }
