import org.sparrowcontainer.pooling.CommonPooling;

/**/** Created on 2004?~11??17??** TODO To change the template for this generated file go to* Window - Preferences - Java - Code Style - Code Templates*/package org.sparrowcontainer.jdbc;import java.io.InputStream;import org.apache.commons.digester.Digester;import org.sparrowcontainer.core.logging.Logger;/*** @author Leo** TODO To change the template for this generated type comment go to Window -* Preferences - Java - Code Style - Code Templates*/public class JdbcConfigurator implements ConnectionPoolConstant {public static void configConnectionPool(String fileSrc) {try {Logger.logDebug(JdbcConfigurator.class, "init connection pool");ClassLoader loader = ClassLoader.getSystemClassLoader();InputStream in = loader.getResourceAsStream(fileSrc);if (in == null) {return;}configConnectionPool(in);} catch (Exception e) {}}public static void configConnectionPool(InputStream in) {try {Digester digester = new Digester();digester.setValidating(false);digester.addObjectCreate(TAG_SPARROW_JDBC, ConnectionManager.class);digester.addObjectCreate(TAG_SPARROW_JDBC + "/"+ TAG_CONNECTION_POOL, ConnectionPool.class);digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + ATTR_NAME, "setPoolName", 0,new Class[] { java.lang.String.class });// digester.addCallParam(TAG_SPARROW_JDBC+"/"+TAG_CONNECTION_POOL,// 0, ATTR_NAME);// digester.addCallMethod(TAG_SPARROW_JDBC+"/"+TAG_CONNECTION_POOL,// "setPoolName", 1);digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + ATTR_TYPE, "setPoolType", 0,new Class[] { java.lang.String.class });// digester.addCallMethod(TAG_SPARROW_JDBC+"/"+TAG_CONNECTION_POOL,// "setPoolType", 1);// digester.addCallParam(TAG_SPARROW_JDBC+"/"+TAG_CONNECTION_POOL,// 0, ATTR_TYPE);digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + ATTR_AUTO_COMMIT, "setAutoCommit", 0,new Class[] { java.lang.String.class });// digester.addCallMethod(TAG_SPARROW_JDBC+"/"+TAG_CONNECTION_POOL,// "setAutoCommit", 1);// digester.addCallParam(TAG_SPARROW_JDBC+"/"+TAG_CONNECTION_POOL,// 0, ATTR_AUTO_COMMIT);digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + TAG_JDBC_DRIVER, "setJdbcDriver", 0,new Class[] { java.lang.String.class });digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + TAG_DB_URL, "setDbUrl", 0,new Class[] { java.lang.String.class });digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + TAG_DB_LOGIN, "setDBLogin", 0,new Class[] { java.lang.String.class });digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + TAG_DB_PWD, "setDBPwd", 0,new Class[] { java.lang.String.class });digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + TAG_MAX_SIZE, "setMaxSize", 0,new Class[] { java.lang.Integer.class });digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + TAG_MIN_SIZE, "setMinSize", 0,new Class[] { java.lang.Integer.class });digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + TAG_BLOCKING_WAITOUT, "setBlockingTimeout", 0,new Class[] { java.lang.Long.class });digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + TAG_TRANSACTION_ISOLATION, "setIsolationLevel", 0,new Class[] { java.lang.Integer.class });digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + TAG_CHECK_SQL, "setCheckSQL", 0,new Class[] { java.lang.String.class });digester.addSetNext(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL,"setDBConfig");digester.parse(in);ConnectionManager.initConnectionPool();} catch (Exception e) {e.printStackTrace();Logger.logError(JdbcConfigurator.class, e.getMessage());} finally {try {in.close();} catch (Exception e) {}}}}/** Created on 2004?~11??17??** TODO To change the template for this generated file go to* Window - Preferences - Java - Code Style - Code Templates*/package org.sparrowcontainer.jdbc;import java.io.InputStream;import org.apache.commons.digester.Digester;import org.sparrowcontainer.core.logging.Logger;/*** @author Leo** TODO To change the template for this generated type comment go to Window -* Preferences - Java - Code Style - Code Templates*/public class JdbcConfigurator implements ConnectionPoolConstant {public static void configConnectionPool(String fileSrc) {try {Logger.logDebug(JdbcConfigurator.class, "init connection pool");ClassLoader loader = ClassLoader.getSystemClassLoader();InputStream in = loader.getResourceAsStream(fileSrc);if (in == null) {return;}configConnectionPool(in);} catch (Exception e) {}}public static void configConnectionPool(InputStream in) {try {Digester digester = new Digester();digester.setValidating(false);digester.addObjectCreate(TAG_SPARROW_JDBC, ConnectionManager.class);digester.addObjectCreate(TAG_SPARROW_JDBC + "/"+ TAG_CONNECTION_POOL, ConnectionPool.class);digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + ATTR_NAME, "setPoolName", 0,new Class[] { java.lang.String.class });// digester.addCallParam(TAG_SPARROW_JDBC+"/"+TAG_CONNECTION_POOL,// 0, ATTR_NAME);// digester.addCallMethod(TAG_SPARROW_JDBC+"/"+TAG_CONNECTION_POOL,// "setPoolName", 1);digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + ATTR_TYPE, "setPoolType", 0,new Class[] { java.lang.String.class });// digester.addCallMethod(TAG_SPARROW_JDBC+"/"+TAG_CONNECTION_POOL,// "setPoolType", 1);// digester.addCallParam(TAG_SPARROW_JDBC+"/"+TAG_CONNECTION_POOL,// 0, ATTR_TYPE);digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + ATTR_AUTO_COMMIT, "setAutoCommit", 0,new Class[] { java.lang.String.class });// digester.addCallMethod(TAG_SPARROW_JDBC+"/"+TAG_CONNECTION_POOL,// "setAutoCommit", 1);// digester.addCallParam(TAG_SPARROW_JDBC+"/"+TAG_CONNECTION_POOL,// 0, ATTR_AUTO_COMMIT);digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + TAG_JDBC_DRIVER, "setJdbcDriver", 0,new Class[] { java.lang.String.class });digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + TAG_DB_URL, "setDbUrl", 0,new Class[] { java.lang.String.class });digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + TAG_DB_LOGIN, "setDBLogin", 0,new Class[] { java.lang.String.class });digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + TAG_DB_PWD, "setDBPwd", 0,new Class[] { java.lang.String.class });digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + TAG_MAX_SIZE, "setMaxSize", 0,new Class[] { java.lang.Integer.class });digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + TAG_MIN_SIZE, "setMinSize", 0,new Class[] { java.lang.Integer.class });digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + TAG_BLOCKING_WAITOUT, "setBlockingTimeout", 0,new Class[] { java.lang.Long.class });digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + TAG_TRANSACTION_ISOLATION, "setIsolationLevel", 0,new Class[] { java.lang.Integer.class });digester.addCallMethod(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL+ "/" + TAG_CHECK_SQL, "setCheckSQL", 0,new Class[] { java.lang.String.class });digester.addSetNext(TAG_SPARROW_JDBC + "/" + TAG_CONNECTION_POOL,"setDBConfig");digester.parse(in);ConnectionManager.initConnectionPool();} catch (Exception e) {e.printStackTrace();Logger.logError(JdbcConfigurator.class, e.getMessage());} finally {try {in.close();} catch (Exception e) {}}}}import org.sparrowcontainer.pooling.CommonPooling;

/**
 * To provide a simple Object Pooling Factory
 * 
 * @author <a href="mailto:leo@sparrowcontainer.org">Leo Chan </a>
 * @version $Revision: 0.1 Alpha $
 */
public class DefaultBeanFactoryBuilder {

    public static int DEFAULT_MAX_WORKER = 10;

    public static int DEFAULT_MIN_SIZE = 10;

    public static int DEFAULT_TIME_WAIT = 30000;

    public static void initThreadPool(Class bean) {
        initThreadPool(bean, DEFAULT_MAX_WORKER, DEFAULT_MIN_SIZE);
    }

	/**
	 * To init the Object Pooling you want with No arguement Consturctor
	 * @param bean the Object reference you want to be Pooled
     * @param maxSize the maximium number of Object to be pooled
     * @param minSize the minimium number of Object to be pooled	
	 */
    public static void initThreadPool(Class bean, int maxSize, int minSize) {
        initThreadPool(bean, maxSize, minSize, DEFAULT_TIME_WAIT);
    }
	
	/**
	 * To init the Object Pooling you want with No arguement Consturctor
	 * @param bean the Object reference you want to be Pooled
     * @param maxSize the maximium number of Object to be pooled
     * @param minSize the minimium number of Object to be pooled
	 * @param timewait the timewait to be blocked when the pool running out of Object
	 */
    public static void initThreadPool(Class bean, int maxSize, int minSize,
            long timewait) {
        if (BeanFactory.isFactoryBuilt(bean.getName())) {
            return;
        }

        DefaultBeanFactory factory = new DefaultBeanFactory();
        factory.setClassName(bean.getName());

        CommonPooling pooling = new CommonPooling(factory, maxSize,
                GenericKeyedObjectPool.WHEN_EXHAUSTED_BLOCK, timewait, minSize);

        BeanFactory.setFactory(bean.getName(), pooling);
        //Object obj=pooling.borrowObject();

    }
    
    /**
	 * To init the Object Pooling you want with No arguement Consturctor
	 * @param bean the Object reference you want to be Pooled
	 * @param suffix the suffix to identify the Pool if same Class need pool twise
     * @param maxSize the maximium number of Object to be pooled
     * @param minSize the minimium number of Object to be pooled
	 * @param timewait the timewait to be blocked when the pool running out of Object
	 */
    public static void initThreadPool(Class bean, String suffix, int maxSize, int minSize,
            long timewait) {
        if (BeanFactory.isFactoryBuilt(bean.getName())) {
            return;
        }

        DefaultBeanFactory factory = new DefaultBeanFactory();
        factory.setClassName(bean.getName());

        CommonPooling pooling = new CommonPooling(factory, maxSize,
                GenericKeyedObjectPool.WHEN_EXHAUSTED_BLOCK, timewait, minSize);

        BeanFactory.setFactory(bean.getName()+suffix, pooling);
        //Object obj=pooling.borrowObject();

    }
	
	/**
	 * To init the Object Pooling you want with No arguement Consturctor
	 * @param bean the Object reference you want to be Pooled
     * @param maxSize the maximium number of Object to be pooled
     * @param minSize the minimium number of Object to be pooled
	 * @param timewait the timewait to be blocked when the pool running out of Object
	 * @param factory the Factory that you customized
	 */
    public static void initThreadPool(Class bean, int maxSize, int minSize,
            long timewait, DefaultBeanFactory factory) {
        if (BeanFactory.isFactoryBuilt(bean.getName())) {
            return;
        }

        //DefaultPoolingFactory factory=new DefaultPoolingFactory();
        factory.setClassName(bean.getName());

        CommonPooling pooling = new CommonPooling(factory, maxSize,
                GenericKeyedObjectPool.WHEN_EXHAUSTED_BLOCK, timewait, minSize);

        BeanFactory.setFactory(bean.getName(), pooling);
        //Object obj=pooling.borrowObject();

    }
    
    /**
	 * To init the Object Pooling you want with No arguement Consturctor
	 * @param bean the Object reference you want to be Pooled
	 * @param suffix the suffix to identify the Pool if same Class need pool twise
     * @param maxSize the maximium number of Object to be pooled
     * @param minSize the minimium number of Object to be pooled
	 * @param timewait the timewait to be blocked when the pool running out of Object
	 * @param factory the Factory that you customized
	 */
    public static void initThreadPool(Class bean, String suffix, int maxSize, int minSize,
            long timewait, DefaultBeanFactory factory) {
        if (BeanFactory.isFactoryBuilt(bean.getName())) {
            return;
        }

        //DefaultPoolingFactory factory=new DefaultPoolingFactory();
        factory.setClassName(bean.getName());

        CommonPooling pooling = new CommonPooling(factory, maxSize,
                GenericKeyedObjectPool.WHEN_EXHAUSTED_BLOCK, timewait, minSize);

        BeanFactory.setFactory(bean.getName()+suffix, pooling);
        //Object obj=pooling.borrowObject();

    }

}       initThreadPool(bean, maxSize, minSize, DEFAULT_TIME_WAIT);
    }
	
	/**
	 * To init the Object Pooling you want with No arguement Consturctor
	 * @param bean the Object reference you want to be Pooled
     * @param maxSize the maximium number of Object to be pooled
     * @param minSize the minimium number of Object to be pooled
	 * @param timewait the timewait to be blocked when the pool running out of Object
	 */
    public static void initThreadPool(Class bean, int maxSize, int minSize,
            long timewait) {
        if (BeanFactory.isFactoryBuilt(bean.getName())) {
            return;
        }

        DefaultBeanFactory factory = new DefaultBeanFactory();
        factory.setClassName(bean.getName());

        CommonPooling pooling = new CommonPooling(factory, maxSize,
                GenericKeyedObjectPool.WHEN_EXHAUSTED_BLOCK, timewait, minSize);

        BeanFactory.setFactory(bean.getName(), pooling);
        //Object obj=pooling.borrowObject();

    }
    
    /**
	 * To init the Object Pooling you want with No arguement Consturctor
	 * @param bean the Object reference you want to be Pooled
	 * @param suffix the suffix to identify the Pool if same Class need pool twise
     * @param maxSize the maximium number of Object to be pooled
     * @param minSize the minimium number of Object to be pooled
	 * @param timewait the timewait to be blocked when the pool running out of Object
	 */
    public static void initThreadPool(Class bean, String suffix, int maxSize, int minSize,
            long timewait) {
        if (BeanFactory.isFactoryBuilt(bean.getName())) {
            return;
        }

        DefaultBeanFactory factory = new DefaultBeanFactory();
        factory.setClassName(bean.getName());

        CommonPooling pooling = new CommonPooling(factory, maxSize,
                GenericKeyedObjectPool.WHEN_EXHAUSTED_BLOCK, timewait, minSize);

        BeanFactory.setFactory(bean.getName()+suffix, pooling);
        //Object obj=pooling.borrowObject();

    }
	
	/**
	 * To init the Object Pooling you want with No arguement Consturctor
	 * @param bean the Object reference you want to be Pooled
     * @param maxSize the maximium number of Object to be pooled
     * @param minSize the minimium number of Object to be pooled
	 * @param timewait the timewait to be blocked when the pool running out of Object
	 * @param factory the Factory that you customized
	 */
    public static void initThreadPool(Class bean, int maxSize, int minSize,
            long timewait, DefaultBeanFactory factory) {
        if (BeanFactory.isFactoryBuilt(bean.getName())) {
            return;
        }

        //DefaultPoolingFactory factory=new DefaultPoolingFactory();
        factory.setClassName(bean.getName());

        CommonPooling pooling = new CommonPooling(factory, maxSize,
                GenericKeyedObjectPool.WHEN_EXHAUSTED_BLOCK, timewait, minSize);

        BeanFactory.setFactory(bean.getName(), pooling);
        //Object obj=pooling.borrowObject();

    }
    
    /**
	 * To init the Object Pooling you want with No arguement Consturctor
	 * @param bean the Object reference you want to be Pooled
	 * @param suffix the suffix to identify the Pool if same Class need pool twise
     * @param maxSize the maximium number of Object to be pooled
     * @param minSize the minimium number of Object to be pooled
	 * @param timewait the timewait to be blocked when the pool running out of Object
	 * @param factory the Factory that you customized
	 */
    public static void initThreadPool(Class bean, String suffix, int maxSize, int minSize,
            long timewait, DefaultBeanFactory factory) {
        if (BeanFactory.isFactoryBuilt(bean.getName())) {
            return;
        }

        //DefaultPoolingFactory factory=new DefaultPoolingFactory();
        factory.setClassName(bean.getName());

        CommonPooling pooling = new CommonPooling(factory, maxSize,
                GenericKeyedObjectPool.WHEN_EXHAUSTED_BLOCK, timewait, minSize);

        BeanFactory.setFactory(bean.getName()+suffix, pooling);
        //Object obj=pooling.borrowObject();

    }

}