@PublicAPI
final public class PNPConfig implements PAPropertiesLoaderSPI {

    /**
     * The TCP port to bind to
     *
     * PNP binds to a local TCP port to accept incoming connections. By default a free port is randomly chosen
     * (port 0). By setting this property, one can force the TCP port.
     */
    static final public PAPropertyInteger PA_PNP_PORT = new PAPropertyInteger("proactive.pnp.port", false, 0);

    /**
     * The default heartbeat period (in milliseconds)
     *
     * PNP offers an heartbeat mechanism to detect network failure. If set to 0 hearthbeats are disabled and
     * network failure will not be detected before the TCP timeout which can be quite long.
     *
     * Setting this value too low impacts the network performance. It is not recommended to use a value
     * lower than 500 milliseconds.
     *
     */
    static final public PAPropertyInteger PA_PNP_DEFAULT_HEARTBEAT = new PAPropertyInteger(
        "proactive.pnp.default_heartbeat", false, 9000);

    /**
     * Channel garbage collection timeout (in milliseconds)
     *
     * Idle channels are garbage collected after a given timeout. If a channel is unused since this value then
     * the channel will be garbage collected.
     */
    static final public PAPropertyInteger PA_PNP_IDLE_TIMEOUT = new PAPropertyInteger(
        "proactive.pnp.idle_timeout", false, 60 * 1000);

    private int port;
    private int idleTimeout;
    private int defaultHeartbeat;

    public PNPConfig() {
        this.port = 0;
        this.idleTimeout = 600 * 1000;
        this.defaultHeartbeat = 60 * 1000;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public void setIdleTimeout(int idleTimeout) {
        this.idleTimeout = idleTimeout;
    }

    public void setDefaultHeartbeat(int defaultHeartbeat) {
        this.defaultHeartbeat = defaultHeartbeat;
    }

    public int getPort() {
        return port;
    }

    public int getIdleTimeout() {
        return idleTimeout;
    }

    public int getDefaultHeartbeat() {
        return defaultHeartbeat;
    }

    public interface Loggers {
        static final public String PNP = org.objectweb.proactive.core.util.log.Loggers.CORE + ".pnp";
        static final public String PNP_HANDLER_SERVER = PNP + ".handler.server";
        static final public String PNP_HANDLER_CLIENT = PNP + ".handler.client";
        static final public String PNP_CODEC = PNP + ".codec";
    }
}PublicAPI
final public class PNPSslConfig implements PAPropertiesLoaderSPI {
    /**
     * The TCP port to bind to
     *
     * PNP binds to a local TCP port to accept incoming connections. By default a free port is randomly chosen
     * (port 0). By setting this property, one can force the TCP port.
     */
    static final public PAPropertyInteger PA_PNPSSL_PORT = new PAPropertyInteger("proactive.pnps.port",
        false, 0);

    /**
     * The default heartbeat period (in milliseconds)
     *
     * PNP offers an heartbeat mechanism to detect network failure. If set to 0 hearthbeats are disabled and
     * network failure will not be detected before the TCP timeout which can be quite long.
     *
     * Setting this value too low impacts the network performance. It is not recommended to use a value
     * lower than 500 milliseconds.
     *
     */
    static final public PAPropertyInteger PA_PNPSSL_DEFAULT_HEARTBEAT = new PAPropertyInteger(
        "proactive.pnps.default_heartbeat", false, 9000);

    /**
     * Channel garbage collection timeout (in milliseconds)
     *
     * Idle channels are garbage collected after a given timeout. If a channel is unused since this value then
     * the channel will be garbage collected.
     */
    static final public PAPropertyInteger PA_PNPSSL_IDLE_TIMEOUT = new PAPropertyInteger(
        "proactive.pnps.idle_timeout", false, 60 * 1000);

    /**
     * The keystore to be used.
     *
     * A keystore contains the private keys and the associated certificate to be used by the SSL layer.
     * The keystore must be in the PKCS12 format, and must contains at least one private keys. The keystore
     * and the keys must be protected by the password defined by {@link SslHelpers#DEFAULT_KS_PASSWD}.
     *
     * If the keystore is not defined then a certificate is generated at runtime.
     */
    static final public PAPropertyString PA_PNPSSL_KEYSTORE = new PAPropertyString("proactive.pnps.keystore",
        false);

    /**
     * Should PNP over SSL authenticate remote peers ?
     *
     * SSL can be used both for ciphering and authentication. By default PNP over SSL only ciphers communication
     * between remote runtimes. Anyone can connect to any runtime. By setting this property to true, authentication
     * is also performed. Remote runtimes must be able to offer a certificate which is on the local keystore defined
     * by {@link PNPSslConfig#PA_PNPSSL_KEYSTORE}
     */
    static final public PAPropertyBoolean PA_PNPSSL_AUTHENTICATE = new PAPropertyBoolean(
        "proactive.pnps.authenticate", false, false);

    public interface Loggers {
        static final public String PNPSSL = org.objectweb.proactive.core.util.log.Loggers.CORE + ".pnpssl";
        static final public String PNPSSL_HANDLER_SERVER = PNPSSL + ".handler.server";
        static final public String PNPSSL_HANDLER_CLIENT = PNPSSL + ".handler.client";
        static final public String PNPSSL_CODEC = PNPSSL + ".codec";
    }
}