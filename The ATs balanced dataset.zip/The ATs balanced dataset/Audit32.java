public class Audit {

    private Integer id;
    private String service;
    private String system;
    private Integer security;
    private Date createTimestamp;

    public Integer getSecurity() {
        return security;
    }

    public void setSecurity( Integer security ) {
        this.security = security;
    }

    public String getSystem() {
        return system;
    }

    public void setSystem( String system ) {
        this.system = system;
    }

    public Date getCreateTimestamp() {
        return createTimestamp;
    }

    public void setCreateTimestamp( Date createTimestamp ) {
        this.createTimestamp = createTimestamp;
    }

    public Integer getId() {
        return id;
    }

    public void setId( Integer id ) {
        this.id = id;
    }

    @Override
    public boolean equals( Object obj ) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Audit other = (Audit) obj;
        if (this.id != other.id && (this.id == null || !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + (this.id != null ? this.id.hashCode() : 0);
        return hash;
    }

    public String getService() {
        return service;
    }

    public void setService( String service ) {
        this.service = service;
    }

    @Override
    public String toString() {
        return "Audit Id: " + id;
    }


}