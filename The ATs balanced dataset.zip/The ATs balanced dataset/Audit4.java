setAuditTrailFormat (DatabaseInfo database, QueryFormat *format)
{
  if (databaseValid (database))
    {
      database->auditTrailFormat = format;
    }
}

getAuditTrailFormat (const DatabaseInfo database)
{
  if (databaseValid (database))
    {
      return database->auditTrailFormat;
    }
  else
    {
      return NULL;
    }
}

clearAuditTrailFormat (DatabaseInfo database)
{
  if (database->auditTrailFormat != NULL)
    {
      freeQueryFormatList (database->auditTrailFormat);
      database->auditTrailFormat = NULL;
    }
}


static char *newAuditTrailEntries = NULL;

static void
sendAuditMail (PR *pr, PR *oldPR, const char *editUserEmailAddr, 
	       const char *newAuditTrailEntries, ErrorDesc *err)
{
  FormatNamedParameter *parms = NULL;
  const DatabaseInfo database = pr->database;

  parms = allocateNamedParameter ("$EditUserEmailAddr", editUserEmailAddr,
				  parms);
  parms = allocateNamedParameter ("$NewAuditTrail", newAuditTrailEntries,
				  parms);

  if (strcmp (field_value (pr, RESPONSIBLE (database)),
	      field_value (oldPR, RESPONSIBLE (database))) != 0)
    {
      parms
	= allocateNamedParameter ("$OldResponsible",
				  field_value (oldPR, RESPONSIBLE (database)),
				  parms);
    }

  composeMailMessage (pr, oldPR, "audit-mail", parms, NULL, err);
  freeFormatParameterList (parms);
}

/* Add an entry to the AUDIT_TRAIL field. PARAMS are the format
   parameters used when composing the entry.  FMT is the format of the
   audit-trail entry to add.  */

static int
addAuditTrailEnt (PR *pr, QueryFormat *fmt, 
		  FormatNamedParameter *params, ErrorDesc *err)
{
  char *newAuditString = NULL;
  char *finalAuditString;
  const char *t;
  char *currDate = get_curr_date ();

  if (fmt == NULL)
    {
      fmt = getAuditTrailFormat (pr->database);
    }

  /* Format the new audit entry. */
  process_format (NULL, &newAuditString, pr, NULL, fmt, "\n", params);

  /* Squirrel it away, because we'll need to mail it later.  */
  append_string (&newAuditTrailEntries, newAuditString);

  /* Now append the formatted string to the audit-trail field.  */
  t = field_value (pr, AUDIT_TRAIL (pr->database));
  if (t == NULL)
    {
      t = "";
    }
  finalAuditString = xstrdup (t);
  append_string (&finalAuditString, newAuditString);
  set_field (pr, AUDIT_TRAIL (pr->database), finalAuditString, err);

  free (finalAuditString);
  free (newAuditString);


          if (field != InvalidFieldIndex && actionList->addAuditTrail)
	    {
	      addAuditTrailEnt (pr, actionList->auditTrailFormat, params, err);
	    }
	}
      actionList = actionList->next;
    }

  if (field != InvalidFieldIndex)
    {
      if (fieldDefForIndex (field)->datatype != MultiText)
	{
	  ChangeActions globalActions = globalChangeActions (pr->database);

	  while (globalActions != NULL)
	    {
	      if (globalActions->addAuditTrail)
		{
		  addAuditTrailEnt (pr, globalActions->auditTrailFormat,

 if (newAuditTrailEntries != NULL)
    {
      sendAuditMail (new_pr, pr, editUserEmailAddr, newAuditTrailEntries,
		     err);
      free (newAuditTrailEntries);
      newAuditTrailEntries = NULL;
    }
  res->addAuditTrail = 0;
  res->auditTrailFormat = NULL;

	      strncat (new_audit, copy_ptr, final1 - copy_ptr);
	      strcat  (new_audit, ">");

 char *new_audit;
  const char *copy_ptr;
  int  len, from_len, to_len, closed_date_set = 0, changed_separator;

  p = field_value (pr, AUDIT_TRAIL (pr->database));

  if (p == NULL || strlen (p) == 0) 
    {
      /* No Audit-Trail at all; initialize Closed-Date */
      set_field (pr, CLOSED_DATE (pr->database), "", err);
      return 1;
    }

  new_audit = xmalloc (strlen (p) * 2);
  new_audit[0] = '\0';
 strcat (new_audit, copy_ptr);
  set_field (pr, AUDIT_TRAIL (pr->database), new_audit, err);
  free (new_audit);

    set    Audit_text "Changed-When:\t[clock format [clock seconds]]\n"
    append Audit_text "Changed-By:\t$TkGnats(LogName) \"$TkGnats(FullName)\"
 foreach require {Audit Email Reason} {
                if {[check_audit_trail_opts $require $t]} {
proc get_audittrail_state {field} {
if {![info exists TkGnats(SERVER-REQUIRE_AUDIT_TRAIL_ENTRY)]} {
        set TkGnats(SERVER-REQUIRE_AUDIT_TRAIL_ENTRY)  "Responsible,State,Priority,Severity,Date-Required"
    }
    if {![info exists TkGnats(SERVER-REQUIRE_AUDIT_TRAIL_REASON)]} {
        set TkGnats(SERVER-REQUIRE_AUDIT_TRAIL_REASON) "Responsible,State,Priority,Severity,Date-Required"
    }
    if {![info exists TkGnats(SERVER-REQUIRE_AUDIT_TRAIL_EMAIL)]} {
        set TkGnats(SERVER-REQUIRE_AUDIT_TRAIL_EMAIL)  "Responsible,State,Priority,Severity,Date-Required"
foreach {var parm} {RequireAudit REQUIRE_AUDIT_TRAIL_ENTRY RequireReason REQUIRE_AUDIT_TRAIL_REASON RequireEmail REQ
proc check_audit_trail_opts
dputs "Reason audit trail for $requirement $field unknown, asking."
	return [get_audittrail_state $field]
