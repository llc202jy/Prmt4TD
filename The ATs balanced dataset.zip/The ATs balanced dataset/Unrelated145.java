package gnu.cajo.utils.extra;

import gnu.cajo.invoke.*;
import java.io.*;
package gnu.cajo.utils.extra;

import java.io.*;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
public class CryptObject extends gnu.cajo.utils.ZippedProxy {
   private final void writeObject(ObjectOutputStream out) throws IOException {
      try{
         Cipher cipher = Cipher.getInstance(CIPHER);
         cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(KEY, CIPHER));
         payload = cipher.doFinal(payload);
      } catch (Exception e){ throw new IOException(e.toString()); }
      out.defaultWriteObject();
   }
   private final void readObject(ObjectInputStream in)
      throws IOException, ClassNotFoundException {
      in.defaultReadObject();
      try{
         Cipher cipher = Cipher.getInstance(CIPHER);
         cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(KEY, CIPHER));
         payload = cipher.doFinal(payload);
      } catch (Exception e){ throw new IOException(e.toString()); }
   }
/*
 * Dynamic Server Item Functionality Redirector
 * Copyright (c) 2005 John Catherino
 * The cajo project: https://cajo.dev.java.net
 *
 
public final class DynamicObject implements Invoke {
   private transient Object object;
   /**
    * The constructor assigns the initial server object reference.
    * @param object The initial encapsulated server functionality to be
    * remoted through this object.
    */
   public DynamicObject(Object object) { this.object = object; }
   /**
    * This method simply redirects all invocations to the currently wrapped
    * object.
    * @param method The method name to be invoked on the wrapped object.
    * @param args The arguments to provide to the method for its invocation.
    * @return The resulting data, if any, from the invocation.
    * @throws NoSuchMethodException If no matching method can be found.
    * @throws Exception If the wrapped object rejected the invocation, for
    * application specific reasons.
    */package gnu.cajo.invoke;

import java.io.*;
import java.net.*;
import java.rmi.*;
import java.util.zip.*;
import java.rmi.server.*;
import java.rmi.registry.*;
import java.util.LinkedList;
import java.lang.reflect.Method;

/*
 * Generic Item Interface Exporter
 * Copyright (C) 1999 John Catherino
 * The cajo project: https://cajo.dev.java.net
 *
 * For issues or suggestions mailto:cajo@dev.java.net
 *
 * This file Remote.java is part of the cajo library.
 *
 * The cajo library is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public Licence as published
 * by the Free Software Foundation, at version 3 of the licence, or (at your
 * option) any later version.
 *
 * Th cajo library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public Licence for more details.
 *
 * You should have received a copy of the GNU Lesser General Public Licence
 * along with this library. If not, see http://www.gnu.org/licenses/lgpl.html
 */

/**
 * This class takes any object, and allows it to be called from
 * remote VMs. This class eliminates the need to maintain multiple
 * specialized stubs for multiple, application specific objects. It
 * effectively allows any object to be remoted, and makes all of
 * the object's public methods, including its static ones, remotely callable.
 * It also contains several very useful utility methods, to further support
 * the invoke package paradigm.<p> It can also be run as an application, to
 * load an object from a URL, and remote it within a JVM.
 *
 * @version 1.0, 01-Nov-99 Initial release
 * @author John Catherino
 */
public final class Remote extends UnicastRemoteObject implements RemoteInvoke {
   private static final class RSSF implements RMIServerSocketFactory {
      private int port;
      private String host;
      public ServerSocket createServerSocket(int port) throws IOException {
         ServerSocket ss = host == null ?
            RMISocketFactory.getDefaultSocketFactory().
               createServerSocket(this.port) :
            new ServerSocket(this.port, 50, InetAddress.getByName(host));
         if (host == null) host = ss.getInetAddress().getHostName();
         if (this.port == 0) {
            this.port = ss.getLocalPort();
            rcsf.port = this.port;
         } else if (rcsf.port == 0) rcsf.port = this.port;
         return ss;
      }

   public Object invoke(String method, Object args) throws Exception {
      return Remote.invoke(object, method, args);
   }
   /**
    * This method is used to dynamically redefine the functionality of
    * this wrapper at runtime. The remote client reference never changes,
    * but what the reference does, can be updated by the server repeatedly.
    * @param object The new encapsulated functionality to be provided to
    * the remote clients.
    */
   public void changeObject(Object object) { this.object = object; }
/**
 * This class is used to transfer an object between Virtual Machines as a
 * zipped marshalled object (zedmob). It will compress the object
 * automatically on serialisation, and decompress it automatically upon
 * deserialisation. This will incur a small runtime penalty, however, if
 * the object is large and highly compressable, or the data link is slow,
 * or the cost per byte to transmit data is high, this can become highly
 * advantageous.
 *
 * @version 1.0, 16-Mar-05 Initial release
 * @author John Catherino
 */
public final class Zedmobject implements Invoke {
   private static final long serialVersionUID = 0x369121518L;
   private byte payload[]; // compressed object transport buffer
   private void writeObject(ObjectOutputStream out) throws IOException {
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      Remote.zedmob(baos, object);
      payload = baos.toByteArray();
      out.defaultWriteObject();
   }
   private void readObject(ObjectInputStream in) throws IOException,
      ClassNotFoundException {
      in.defaultReadObject();
      ByteArrayInputStream bais = new ByteArrayInputStream(payload);
      object = Remote.zedmob(bais);
      payload = null;
   }
   /**
    * The wrapped object. Normally it would be accessed through the wrapper's
    * Invoke interface. However, direct access is provided for cases where
    * the wrapped object is purely data, for example a byte[]. It is declared
    * transient since it never travels over the network in its uncompressed
    * form.
    */
   public transient Object object;
   /**
    * The constructor simply assigns the reference to the member object
    * referece. The only restriction, quite naturally, is that the object
    * argument <i>must</i> be serialisable.
    * @param object The object to be de/compressed receipt/transmission.
    */
   public Zedmobject(Object object) { this.object = object; }
   /**
    * The invocation interface to the internal object. It is used to invoke
    * any of the object's public methods. It uses the Remote.invoke paradigm
    * internally, to make the presence of the zedmobject transparent.
    * @param method The name of the public method to invoke.
    * @param args The data, to be provided to the method as arguments, if any.
    * @throws Exception For any method-specific reasons.
    */
   public Object invoke(String method, Object args) throws Exception {
      return Remote.invoke(object, method, args);