		try {
			if (cis == null)
				cis = new ClientIOGRSupport();
			if (sis == null)
				sis = new ServerIOGRSupport();
			//if (lmci == null)
			//   lmci = new LoggingMessageClientInterceptor();
			//if (gi == null)
			//   gi = new LoggingGSeqInterceptor();
			//if (gmci == null)
			//   gmci = new GSeqMessagerClientInterceptor();
		} catch (Exception e) {
		}

		try {
			/*if(lmci != null) {
			   orbinitinfo.add_client_request_interceptor(lmci);
			   Debug.output(0, 
							"GrouppacInterceptorsInitializer: LoggingMessagerClientInterceptor adicionado.");
			   }
			   if(gmci != null) {
				   orbinitinfo.add_client_request_interceptor(gmci);
				   Debug.output(0, 
								"GrouppacInterceptorsInitializer: GSeqMessagerClientInterceptor adicionado.");
			   }*/
			orbinitinfo.add_client_request_interceptor(cis);
			orbinitinfo.add_server_request_interceptor(sis);
			edu.lcmi.grouppac.util.Debug.output(
				0,
				"GrouppacInterceptorsInitializer: Client/Server IOGR support interceptor is running.");
			/*if(gi != null) {
			   orbinitinfo.add_server_request_interceptor(gi);
			   Debug.output(0, 
							"GrouppacInterceptorsInitializer: LoggingGSeqInterceptor adicionado.");
			   }*/
		} catch (org.omg.PortableInterceptor.ORBInitInfoPackage.DuplicateName e) {
			Debug.output(
				0,
				"GrouppacInterceptorsInitializer: Ocorreu um erro durante o cadastramento dos interceptadores do Grouppac (Nome duplicado).");
		}
	}

	/**
	 * @see org.omg.CORBA.Object#_create_request(Context, String, NVList, NamedValue, ExceptionList, ContextList)
	 */
	public Request _create_request(
		Context ctx,
		String operation,
		NVList arg_list,
		NamedValue result,
		ExceptionList exclist,
		ContextList ctxlist) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_create_request(Context, String, NVList, NamedValue)
	 */
	public Request _create_request(Context ctx, String operation, NVList arg_list, NamedValue result) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_duplicate()
	 */
	public org.omg.CORBA.Object _duplicate() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_get_domain_managers()
	 */
	public DomainManager[] _get_domain_managers() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_get_interface_def()
	 */
	public org.omg.CORBA.Object _get_interface_def() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @deprecated deprecated by CORBA 2.3
	 */
	public InterfaceDef _get_interface() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_get_policy(int)
	 */
	public Policy _get_policy(int policy_type) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_hash(int)
	 */
	public int _hash(int maximum) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_is_a(String)
	 */
	public boolean _is_a(String repositoryIdentifier) {
		throw new NO_IMPLEMENT();
	}
import org.omg.CosNaming.BindingType;
import org.omg.CosNaming.NameComponent;

/**
 * Implementation of the "BindingIterator" interface. This is only a reformatted, cleaned version
 * of the original.
 * 
 * @version $Revision: 1.11 $
 * @author Gerald Brose
 * @author <a href="mailto:padilha@das.ufsc.br">Ricardo Sangoi Padilha</a>, <a
 *         href="http://www.das.ufsc.br/">UFSC, Florian?polis, SC, Brazil</a>
 */
public class BindingIteratorImpl extends BindingIteratorPOA {

	Binding[] bindings;
	int iterator_pos = 0;

	/**
	 * Creates a new BindingIteratorImpl object.
	 * 
	 * @param b
	 */
	public BindingIteratorImpl(Binding[] b) {
		bindings = b;
		if (b.length > 0)
			iterator_pos = 0;
	}

	/**
	 * @see org.omg.CosNaming.BindingIteratorOperations#destroy()
	 */
	public void destroy() {
		bindings = null;
		try {
			finalize();
		} catch (Throwable t) {
		}

	}

	/**
	 * @see org.omg.CosNaming.BindingIteratorOperations#next_n(int, BindingListHolder)
	 */
	public boolean next_n(int how_many, BindingListHolder bl) {
		int diff = bindings.length - iterator_pos;
		if (diff > 0) {
			Binding[] bndgs = null;
			if (how_many <= diff) {
				bndgs = new Binding[how_many];
				System.arraycopy(bindings, iterator_pos, bndgs, 0, how_many);
				iterator_pos += how_many;
			} else {
				bndgs = new Binding[diff];
				System.arraycopy(bindings, iterator_pos, bndgs, 0, diff);
				iterator_pos = bindings.length;
			}

			bl.value = bndgs;

			return true;
		} else {
			bl.value = new Binding[0];
			bl.value[0] = new Binding(new NameComponent[0], BindingType.nobject);

			return false;
		}
/*
 * GroupPac - Copyright (C) 2000-2002 LCMI
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
package edu.lcmi.grouppac;

import java.net.InetAddress;
import java.net.Socket;
import java.util.Map;

import org.omg.CORBA.BAD_PARAM;
import org.omg.CORBA.Context;
import org.omg.CORBA.ContextList;
import org.omg.CORBA.DomainManager;
import org.omg.CORBA.ExceptionList;
import org.omg.CORBA.InterfaceDef;
import org.omg.CORBA.MARSHAL;
import org.omg.CORBA.NO_IMPLEMENT;
import org.omg.CORBA.NVList;
import org.omg.CORBA.NamedValue;
import org.omg.CORBA.Policy;
import org.omg.CORBA.Request;
import org.omg.CORBA.SetOverrideType;
import org.omg.CORBA.FT.ACTIVE;
import org.omg.CORBA.FT.ACTIVE_WITH_VOTING;
import org.omg.CORBA.FT.FTGroupVersionServiceContext;
import org.omg.CORBA.FT.FTGroupVersionServiceContextHelper;
import org.omg.CORBA.FT.Property;
import org.omg.CORBA.FT.ReplicationManager;
import org.omg.CORBA.FT.ReplicationManagerHelper;
import org.omg.CORBA.FT.TagFTGroupTaggedComponent;
import org.omg.CORBA.FT.TagFTGroupTaggedComponentHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.InvalidName;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import org.omg.IOP.FT_GROUP_VERSION;
import org.omg.IOP.ServiceContext;
import org.omg.IOP.TAG_FT_GROUP;
import org.omg.IOP.TaggedComponent;
import org.omg.PortableInterceptor.ClientRequestInfo;
import org.omg.PortableInterceptor.ClientRequestInterceptor;
import org.omg.PortableInterceptor.ForwardRequest;

import org.jacorb.orb.CDROutputStream;

import edu.lcmi.grouppac.util.Debug;

/**
 * Provides IOGR support for clients. This interceptor tries each one of the profiles in the IOGR
 * before returning a definitive reference for the client.  Creation date: (01/04/00 13:10:28)
 * 
 * @version $Revision: 1.18 $
 * @author <a href="mailto:padilha@das.ufsc.br">Ricardo Sangoi Padilha</a>, <a
 *         href="http://www.das.ufsc.br/">UFSC, Florian?polis, SC, Brazil</a>
 */
public class ClientIOGRSupport implements ClientRequestInterceptor {
	private static final boolean endianness = false;
	private volatile boolean in_loop;

	/**
	 * Default Construtor.
	 */
	public ClientIOGRSupport() {
	}

	/**
	 * @see org.omg.CORBA.Object#_create_request(Context, String, NVList, NamedValue)
	 */
	public Request _create_request(Context ctx, String operation, NVList arg_list, NamedValue result) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_create_request(Context, String, NVList, NamedValue, ExceptionList, ContextList)
	 */
	public Request _create_request(
		Context ctx,
		String operation,
		NVList arg_list,
		NamedValue result,
		ExceptionList exc_list,
		ContextList ctx_list) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_duplicate()
	 */
	public org.omg.CORBA.Object _duplicate() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_get_domain_managers()
	 */
	public DomainManager[] _get_domain_managers() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @deprecated deprecated by CORBA 2.3
	 */
	public InterfaceDef _get_interface() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_get_interface_def()
	 */
	public org.omg.CORBA.Object _get_interface_def() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_get_policy(int)
	 */
	public Policy _get_policy(int policy_type) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_hash(int)
	 */
	public int _hash(int maximum) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_is_a(String)
	 */
	public boolean _is_a(String identifier) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_is_equivalent(Object)
	 */
	public boolean _is_equivalent(org.omg.CORBA.Object other_object) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_non_existent()
	 */
	public boolean _non_existent() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_release()
	 */
	public void _release() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_request(String)
	 */
	public Request _request(String operation) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_set_policy_override(Policy[], SetOverrideType)
	 */
	public org.omg.CORBA.Object _set_policy_override(Policy[] policies, SetOverrideType set_add) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.PortableInterceptor.InterceptorOperations#destroy()
	 */
	public void destroy() {
	}

	/**
	 * @see org.omg.PortableInterceptor.InterceptorOperations#name()
	 */
	public String name() {
		return "";
	}

	/**
	 * @see org.omg.PortableInterceptor.ClientRequestInterceptorOperations#receive_exception(ClientRequestInfo)
	 */
	public void receive_exception(ClientRequestInfo cri) throws ForwardRequest {
		/* if there is no NS, we can do nothing */
		if (Main.getNS(false) == null)
			return;
		org.omg.CORBA.Object target = cri.target();
		ParsedIOGR piogr = new ParsedIOGR(target);
		if (!piogr.isIOGR())
			return;
		try {
			String t_id = piogr.getTypeId();
			if (t_id.equals("IDL:omg.org/CORBA/FT/Voter:1.0")
				|| t_id.equals("IDL:omg.org/CORBA/FT/RingMember:1.0")
				|| t_id.equals("IDL:omg.org/CORBA/FT/LoggingRecovery:1.0"))
				return;
			String operation = cri.operation();
			
				return;
			String exception = cri.received_exception_id();
			if (exception.equals("IDL:omg.org/CORBA/COMM_FAILURE:1.0")
				|| exception.equals("IDL:omg.org/CORBA/TRANSIENT:1.0")
				|| exception.equals("IDL:omg.org/CORBA/NO_RESPONSE:1.0")
				|| exception.equals("IDL:omg.org/CORBA/OBJ_ADAPTER:1.0")
				|| exception.equals("IDL:omg.org/CORBA/OBJECT_NOT_EXIST:1.0")) {
				String name = ParsedIOGR.toName(t_id);
				org.omg.CORBA.Object new_ref = Main.getNS().resolve_str(name + ".service");
				ParsedIOGR new_iogr = new ParsedIOGR(new_ref);
				if (new_iogr.getNumberOfObjects() > 0) {
					/* forward only if it isn't an active group */
					if (!(isActiveReplicationStyle(new_ref)))
						throw new ForwardRequest(new_ref);
				}
			}
		} catch (BAD_PARAM e) {
		} catch (NotFound e) {
		} catch (CannotProceed e) {
		} catch (InvalidName e) {
		}

	}

	/**
	 * @see org.omg.PortableInterceptor.ClientRequestInterceptorOperations#receive_other(ClientRequestInfo)
	 */
	public void receive_other(ClientRequestInfo clientrequestinfo) throws ForwardRequest {
	}

	/**
	 * @see org.omg.PortableInterceptor.ClientRequestInterceptorOperations#receive_reply(ClientRequestInfo)
	 */
	public void receive_reply(ClientRequestInfo clientrequestinfo) {
	}

	/**
	 * @see org.omg.PortableInterceptor.ClientRequestInterceptorOperations#send_poll(ClientRequestInfo)
	 */
	public void send_poll(ClientRequestInfo clientrequestinfo) {
	}

	/**
	 * @see org.omg.PortableInterceptor.ClientRequestInterceptorOperations#send_request(ClientRequestInfo)
	 */
	public void send_request(ClientRequestInfo cri) throws ForwardRequest {
		org.omg.CORBA.Object target = cri.target();
		ParsedIOGR pior = new ParsedIOGR(target);
		if (pior.isIOGR()) {
			// add service context for group version
			FTGroupVersionServiceContext sc = new FTGroupVersionServiceContext(pior.getGroupRefVersion());
			ServiceContext group_sc = makeGroupVersionSC(sc);
			cri.add_request_service_context(group_sc, true);
			// check the number of objects
			int k = pior.getNumberOfObjects();
			if (k <= 1)
				return;
			for (int i = 0; i < k; i++) {
				org.omg.CORBA.Object o = pior.getObjectReference(i, false);
				Debug.assertCondition((!cri.operation().equals("_non_existent")), "Loop in Client IOGR support interceptor.");
				if (existsIP(o) && !o._non_existent()) {
					o = pior.getObjectReference(i, true);
					throw new ForwardRequest(o);
				}
			}
		}
	}

	/**
	 * @see Object#toString()
	 */
	public String toString() {
		throw new MARSHAL();
	}

	/**
	 * Create a TaggedComponent from the TagFTGroupTaggedComponent.
	 * 
	 * @param tag org.omg.CORBA.FT.TagFTGroupTaggedComponent
	 * @return org.omg.IOP.TaggedComponent
	 */
	protected static TaggedComponent makeGroupTC(TagFTGroupTaggedComponent tag) {
		CDROutputStream tgDataStream = new CDROutputStream();
		tgDataStream.write_boolean(endianness);
		TagFTGroupTaggedComponentHelper.write(tgDataStream, tag);

		return new TaggedComponent(TAG_FT_GROUP.value, tgDataStream.getBufferCopy());
	}

	/**
	 * Create a ServiceContext from the FTRecoveryRequestServiceContext.
	 * 
	 * @param sc org.omg.CORBA.FT.FTRecoveryRequestServiceContext
	 * @return org.omg.IOP.ServiceContext
	 */
	protected static ServiceContext makeGroupVersionSC(FTGroupVersionServiceContext sc) {
		CDROutputStream tgDataStream = new CDROutputStream();
		tgDataStream.write_boolean(endianness);
		FTGroupVersionServiceContextHelper.write(tgDataStream, sc);

		return new ServiceContext(FT_GROUP_VERSION.value, tgDataStream.getBufferCopy());
	}

	/**
	 * Checks with the RM if an Object is from a group with active replication
	 * 
	 * @param obj the CORBA object to be checked
	 * @return true if the object does belong to an active replication group
	 */
	protected boolean isActiveReplicationStyle(org.omg.CORBA.Object obj) {
		try {
			org.omg.CORBA.Object rm_ref = Main.getNS().resolve_str("ReplicationManager.service");
			ReplicationManager rm = ReplicationManagerHelper.narrow(rm_ref);
			Property[] props = rm.get_properties(obj);
			Map p = Main.toMap(props);
			int rs = Integer.parseInt((String) p.get(Main.RS));

			return (rs == ACTIVE.value || rs == ACTIVE_WITH_VOTING.value);
		} catch (Exception e) {
			Debug.output(2, e);

			return false;
		}
	}

	/**
	 * Tests RAW connections to the target. Only tries to open a socket. This method was created to
	 * facilitate the detection of faulty and removed members.
	 * 
	 * @param target org.omg.CORBA.Object
	 * @return boolean
	 */
	protected boolean existsIP(org.omg.CORBA.Object target) {
		ParsedIOGR pior = new ParsedIOGR(target);
		String address = pior.getAddress();
		String ip = address.substring(0, address.indexOf(":"));
		int port = Integer.parseInt(address.substring(address.indexOf(":") + 1));
		try {
			InetAddress host = InetAddress.getByName(ip);
			Socket s = new Socket(host, port);
			s.close();

			return true;
		} catch (Exception e) {
			Debug.output(3, e);

			return false;
		}
	}
}package net.xmlrouter.mod_pubsub.client;
}package net.xmlrouter.mod_pubsub.client;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/**
 * @author msg
 * Event router that uses mod-pubsub compliant server for network messaging.
 * The openConnection() method opens a persistent connection that can deliver messages to the client 
 */
public class EventServer {
	private static String ROUTES_STR = "/kn_routes/";
	String serverURI;
	String basePath;

	/**
	 * @param server URI of message server (ex. http://localhost/kn/)
	 */
	public EventServer(String uri) throws MalformedURLException {
		this.serverURI = uri;

		try {
			new URL(uri);
			basePath = "";
		} catch (Exception e) {
			throw new MalformedURLException(uri);
		}
	}

	public String getMessageId() {
		return Double.toString(Math.random()).substring(2, 10);
	}

	public String getRouteId(String topic, String msg_id) {
		return serverURI + topic + ROUTES_STR + msg_id;
	}
	public String getJournalId(String username)
	{
		return "/who/"+username+"/s/"+getMessageId()+"/kn_journal";
	}

	public String getTopicFromRoute(String route_id) {
		String retVal = "";

		int topicsIdx = route_id.indexOf(ROUTES_STR);
		if (route_id.startsWith(serverURI) && topicsIdx != -1) {

			retVal = route_id.substring(serverURI.length(), topicsIdx);
		}

		return retVal;
	}
	public String getIdFromRoute(String route_id) {
		String retVal = "";

		int topicsIdx = route_id.indexOf(ROUTES_STR);
		if (topicsIdx != -1) {

			retVal = route_id.substring(topicsIdx + ROUTES_STR.length());
		}

		return retVal;
	}
	
	private void consumeResponse(java.net.HttpURLConnection conn)
		throws IOException
	{
		byte buffer[] = new byte[1024];
		InputStream is = conn.getInputStream();
		while (is.read(buffer) > 0);
	}
	public String subscribe(String from, String to, Map options) {
		String route_id = null;
		String msg_id = getMessageId();

		// generate an id for the route we will create so we can delete it later
		route_id = getRouteId(from, msg_id);

		Map msg = new HashMap();
		java.net.HttpURLConnection conn;
		try {
			String uri;
			uri = serverURI + basePath;
			URL url = new URL(uri);

			// add some things
			msg.put("do_method", "route");
			msg.put("kn_from", from);
			msg.put("kn_to", to);
			//msg.put("kn_id",route_id);	// should we do this or not??
			//msg.put("do_max_age","3600");
			if (null != options) msg.putAll(options);

			// send message
			conn = HTTPUtil.Post(url, msg);

			// get response
			if (conn.getResponseCode() >= 200 && conn.getResponseCode() < 300) 
			{
			} 
			else 
			{
				System.err.println("subscribe() : ERROR : " + conn.getResponseMessage());
			}

			// consume response entity
			consumeResponse(conn);
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("subscribe() : ERROR : " + e.getMessage());
