public class SleeContainer implements ComponentContainer {

	public static boolean isSecurityEnabled = false;

	// For unit testing only -- to be removed later.
	private static final String JNDI_NAME = "container";

	public static final String JVM_ENV = "java:";

	/** standard ENC name in JNDI */
	public static final String COMP_ENV = "java:comp/env";

	/** the root context for SLEE */
	private static final String CTX_SLEE = "slee";

	/** The lifecycle state of the SLEE */
	private SleeState sleeState;

	// The usage parameter set
	// (Ivelin) obsolete, the usage params are now stored in sbbdescriptorimpl
	// Usage parameters - indexed by ServiceID/SbbID
	// These are now stored in the Service

	// private HashMap usageParameters;

	// the usage mbean -- one per usage parameter set.
	// Indexed using the same key as the usageParameters set.
	// private HashMap usageMBeans;

	// The key is the SbbID the value is the ObjectPooling
	private HashMap sbbPooling;

	private GenericObjectPool.Config poolConfig;

	// An interface for the resource adaptor to retrieve the event type id.
	private EventLookup eventLookup;

	private HashMap eventTypeIDToDescriptor;

	private HashMap eventKeyToEventTypeIDMap;

	// A vector containing all the event types that are known to the slee.
	private HashMap eventTypeIDs;

	private ActivityContextFactoryImpl activityContextFactory;

	// An abstraction used by resource adaptors to post events to the
	// slee event queue.
	private SleeInternalEndpoint sleeEndpoint;

	// the class that actually posts events to the SBBs.
	// This should be made into a facility and registered with jmx and jndi
	// so it can be independently controlled.
	private EventRouter router;

	private DeploymentManager deploymentManager;

	private ServiceActivityContextInterfaceFactoryImpl serviceActivityContextInterfaceFactory;

	private NullActivityContextInterfaceFactoryImpl nullActivityContextInterfaceFactory;

	private static TimerFacilityImpl timerFacility;

	private ProfileFacilityImpl profileFacility;

	// A set of event type ids mapped to event descriptors.

	private HashMap eventTypeIDToEventKeyMap;

	private final static Logger logger = Logger.getLogger(SleeContainer.class);

	private ActivityContextNamingFacilityImpl activityContextNamingFacility;

	private HARMIServerImpl rmiServer;

	private SbbEntityFactory sbbEntityFactory;

	/**
	 * Resource Container
	 */
	// maps Resource adaptor Type Ids to the installed ResourceAdaptorTypes
	private HashMap resourceAdaptorTypes;

	// maps ResourceAdaptorID to the installed ResourceAdaptor
	private HashMap installedResourceAdaptors;

	// maps a link to a resource adaptor entity name
	private HashMap resourceAdaptorEntityLinks;

	/*
	 * maps name to Resource Adaptor Entity This has to be persistent inside the
	 * slee. If the slee is shutdown and restarted the RaEntities are restored
	 * to their previous operational state
	 * 
	 */
	private HashMap resourceAdaptorEntities;

	private ResourceAdaptorContext bootstrapContext;

	// maps ResourceAdaptorTypeID to the proper ActivityContextInterfaceFactory
	private HashMap activityContextInterfaceFactories;

	private NullActivityFactoryImpl nullActivityFactory;

	private ProfileTableActivityContextInterfaceFactoryImpl profileTableActivityContextInterfaceFactory;

	private TransactionIDAccess transactionIDAccess;

	private MBeanServer mbeanServer;

	private ServiceManagementMBean serviceManagementMBean;

	// This timer runs task which allows graceful service deactivation
	// it allows sbbenitities to finish their processing before removing their
	// trees
	private Timer sbbEntityRemoverTimer = null;

	// Maps service id string to removal task if any - needed in
	// uninstallService
	// - since after that task shouldnt execute
	private Map sevriceIdsToRemovalTasks = new SyncMap(new HashMap(),
			new WriterPreferenceReadWriteLock()); // acess should be
													// sequential, but cant be
													// sure here

	private ClassLoader loader;

	{
		// establish the location of mobicents.sar
		initDeployPath();
	}

	/*
	 * private DeploymentCacheManager getDeploymentCacheManager() throws
	 * SystemException { DeploymentCacheManager cm = (DeploymentCacheManager)
	 * SleeContainer
	 * .getTransactionManager().getDeferredData("DeploymentCache"); if (cm ==
	 * null) { cm = new DeploymentCacheManager();
	 * SleeContainer.getTransactionManager().putDeferredData( "DeploymentCache",
	 * cm); cm.loadFromCache(); }
	 * 
	 * return cm; }
	 */
	private DeploymentCacheManager deploymentCacheManager;

	private static SleeContainer sleeContainer;

	private static SleeTransactionManager sleeTransactionManager;

	/**
	 * location of mobicents.sar
	 */
	private static String deployPath;

	/**
	 * Get deployment data set from cache
	 * 
	 */
	private DeploymentCacheManager getDeploymentCacheManager() {
		if (deploymentCacheManager == null) {
			deploymentCacheManager = new DeploymentCacheManager();
		}
		return deploymentCacheManager;
	}

	private static void initDeployPath() {
		java.net.URL url = SleeContainer.class.getResource("/");
		java.net.URI uri;
		try {
			uri = new java.net.URI(url.toExternalForm());
			File file = new File(uri);
			deployPath = file.getAbsolutePath();
		} catch (URISyntaxException e) {
			logger
					.error(
							"Failed to establish path to Mobicents root deployment directory (mobicents.sar)",
							e);
			deployPath = null;
		}
	}

	/**
	 * 
	 * @return the full file system path where mobicents.sar is located
	 */
	public static String getDeployPath() {
		return deployPath;
	}

	public DeploymentCacheManager getDeploymentManager() {
		return deploymentCacheManager;
	}

	public static TraceFacilityImpl getTraceFacility() throws NamingException {
		return (TraceFacilityImpl) lookupFacilityInJndi(TraceMBeanImpl.JNDI_NAME);
	}

	public static AlarmFacilityImpl getAlarmFacility() throws NamingException {
		return (AlarmFacilityImpl) lookupFacilityInJndi(AlarmMBeanImpl.JNDI_NAME);
	}

	public static ProfileTableActivityContextInterfaceFactoryImpl getProfileTableActivityContextInterfaceFactory()
			throws NamingException {
		return (ProfileTableActivityContextInterfaceFactoryImpl) SleeContainer
				.lookupFacilityInJndi(ProfileTableActivityContextInterfaceFactoryImpl.JNDI_NAME);
	}

	public ClassLoader getClassLoader() {
		return this.loader;
	}

	/**
	 * Get the service management MBean
	 * 
	 * @throws Exception
	 */
	public ServiceManagementMBean getServiceManagementMBean() {
		return this.serviceManagementMBean;
	}

	/**
	 * Initialization code.
	 * 
	 */
	public void init(SleeManagementMBean sleeManagementMBean) throws Exception {
		// loader = new URLClassLoader(new URL[0], Thread.currentThread()
		// .getContextClassLoader());
		logger.info("Initializing Slee");

		initNamingContexts();

		serviceManagementMBean = (ServiceManagementMBean) MBeanProxy.get(
				ServiceManagementMBean.class, sleeManagementMBean
						.getServiceManagementMBean(), mbeanServer);

		// Force class loading of ConcreteClassGeneratorUtils to initilize the
		// static pool
		ConcreteClassGeneratorUtils.class.getClass();

		DefaultSleeEntityResolver.init(this.getClass().getClassLoader());

		this.poolConfig = this.configurePooling();

		this.sbbPooling = new HashMap();
		this.sbbEntityFactory = new SbbEntityFactory(this);
		this.deploymentManager = new DeploymentManager();

		// this.usageParameters = new HashMap();
		this.eventTypeIDs = new HashMap();
		this.eventTypeIDToDescriptor = new HashMap();
		this.eventKeyToEventTypeIDMap = new HashMap();
		this.transactionIDAccess = new TransactionIDAccessImpl(
				(TransactionManagerImpl) SleeContainer.getTransactionManager());
		this.eventLookup = new EventLookup(this);

		this.eventTypeIDToEventKeyMap = new HashMap();

		this.deployStandardEvents();
		this.deployStandardProfileSpecs();
		this.activityContextFactory = new ActivityContextFactoryImpl(this);
		this.router = new EventRouterImpl(this);
		this.sleeEndpoint = new SleeInternalEndpointImpl(
				activityContextFactory, router, this);

		// Initialize the various facilities for the slee.

		this.activityContextNamingFacility = new ActivityContextNamingFacilityImpl();
		registerWithJndi("slee/facilities", "activitycontextnaming",
				activityContextNamingFacility);

		this.nullActivityContextInterfaceFactory = new NullActivityContextInterfaceFactoryImpl(
				this);
		registerWithJndi("slee/nullactivity",
				"nullactivitycontextinterfacefactory",
				nullActivityContextInterfaceFactory);

		this.nullActivityFactory = new NullActivityFactoryImpl(this);
		registerWithJndi("slee/nullactivity", "nullactivityfactory",
				nullActivityFactory);

		this.profileTableActivityContextInterfaceFactory = new ProfileTableActivityContextInterfaceFactoryImpl();
		registerWithJndi("slee/facilities",
				ProfileTableActivityContextInterfaceFactoryImpl.JNDI_NAME,
				profileTableActivityContextInterfaceFactory);

		SleeContainer.timerFacility = new TimerFacilityImpl(this);

		registerWithJndi("slee/facilities", TimerFacilityImpl.JNDI_NAME,
				SleeContainer.timerFacility);

		this.profileFacility = new ProfileFacilityImpl();

		registerWithJndi("slee/facilities", ProfileFacilityImpl.JNDI_NAME,
				profileFacility);

		// this.alarmFacility = (AlarmFacilityImpl)
		// lookupFacilityInJndi(AlarmMBeanImpl.JNDI_NAME);

		// This is not registered with jndi.
		this.serviceActivityContextInterfaceFactory = new ServiceActivityContextInterfaceFactoryImpl(
				this);

		registerWithJndi("slee/serviceactivity/",
				ServiceActivityContextInterfaceFactoryImpl.JNDI_NAME,
				serviceActivityContextInterfaceFactory);

		this.bootstrapContext = new ResourceAdaptorContext(this
				.getSleeEndpoint(), this.getEventLookupFacility());
		/*
		 * Resource Container initialization
		 */
		resourceAdaptorTypes = new HashMap();
		resourceAdaptorEntities = new HashMap();
		installedResourceAdaptors = new HashMap();
		this.resourceAdaptorEntityLinks = new HashMap();
		this.activityContextInterfaceFactories = new HashMap();

		registerWithJndi();

		startRMIServer(this.nullActivityFactory, this.sleeEndpoint,
				this.eventLookup);

		registerPropertyEditors();

		// Create timer
		sbbEntityRemoverTimer = new Timer();
	}

	private Config configurePooling() {
		GenericObjectPool.Config conf = new GenericObjectPool.Config();
		conf.maxActive = -1;
		conf.maxIdle = -1;
		conf.maxWait = -1;
		conf.minEvictableIdleTimeMillis = -1;
		conf.minIdle = 5;
		conf.numTestsPerEvictionRun = -1;
		conf.testOnBorrow = false;
		conf.testOnReturn = false;
		conf.testWhileIdle = false;
		conf.timeBetweenEvictionRunsMillis = -1;
		conf.whenExhaustedAction = GenericObjectPool.WHEN_EXHAUSTED_FAIL;

		return conf;
	}

	private void registerWithJndi() {
		registerWithJndi("slee", JNDI_NAME, this);
	}

	private void unregisterWithJndi() {
		unregisterWithJndi("slee/" + JNDI_NAME);
	}

	/**
	 * Return the SleeContainer instance registered in the JVM scope of JNDI
	 * 
	 */
	public static SleeContainer lookupFromJndi() {
		try {
			if (sleeContainer != null)
				return sleeContainer;
			else {
				sleeContainer = (SleeContainer) getFromJndi("slee/" + JNDI_NAME);
				return sleeContainer;
			}
		} catch (Exception ex) {
			logger.error("Unexpected error: Cannot retrieve SLEE Container!",
					ex);
			return null;
		}
	}

	/*
	 * Start the HA RMI Server, used by JCA resource adaptors to communicate
	 * with the SLEE
	 */
	private void startRMIServer(NullActivityFactory naf,
			SleeInternalEndpoint endpoint, EventLookup eventLookup) {
		try {
			logger.debug("Starting Slee Service RMI Server");

			InitialContext ctx = new InitialContext();

			// TODO This shouldn't be hardcoded - use a config. file to
			// configure the partition name, jndi name, port number and
			// inetaddress
			HAPartition myPartition = (HAPartition) ctx
					.lookup("/HAPartition/DefaultPartition");
			rmiServer = new HARMIServerImpl(myPartition, "RemoteSleeService",
					RemoteSleeService.class, new RemoteSleeServiceImpl(naf,
							endpoint, eventLookup, activityContextFactory));
			RemoteSleeService stub = (RemoteSleeService) rmiServer
					.createHAStub(new FirstAvailable());

			logger.debug("Created SleeService rmi stub");

			ctx.rebind("/SleeService", stub);

			logger.debug("Bound SleeService rmi stub in jndi");
		} catch (Exception e) {
			logger.error(
					"Failed to start HA RMI server for Remote slee service", e);
		}
	}

	private void stopRMIServer() {
		try {
			logger.debug("Stopping RMI Server for slee service");
			InitialContext ctx = new InitialContext();
			Util.unbind(ctx, "/SleeService");
			rmiServer.destroy();
		} catch (NamingException e) {
			logger.error(
					"Failed to stop HA RMI Server for remote slee service", e);
		}
	}

	/**
	 * Load up all the services from the deployment directory.
	 * 
	 * @throws Exception
	 */
	public void initializeServices() throws Exception {

		try {

			deploymentManager.deployAllUnitsAtLocation(getDeployPath()
					+ "/deploy", // get
					// deployable
					// units
					// here,
					getDeployPath(), // put classes from them here
					this); // and install them in this container

		} catch (Throwable ex) {
			ex.printStackTrace();
			throw new Exception(ex.getMessage());
		}
	}

	/**
	 * Start a service given its service ID.
	 * 
	 * @param serviceID
	 * @throws UnrecognizedServiceException
	 */

	public synchronized void startService(ServiceID serviceID)
			throws UnrecognizedServiceException, InvalidStateException {

		if (serviceID == null)
			throw new NullPointerException("null service id");

		SleeTransactionManager transactionManager = SleeContainer
				.getTransactionManager();
		boolean b = transactionManager.requireTransaction();
		boolean rb = true;
		try {

			Service service = this.getService(serviceID);

			if (service == null)
				throw new UnrecognizedServiceException("unrecognized service "
						+ serviceID);

			if (service.getState().equals(ServiceState.ACTIVE)) {
				// transactionManager.commit();
				// return;
				getDeploymentCacheManager().getActiveServiceIDs()
						.add(serviceID);

				throw new InvalidStateException("Service already active");
			}

			// notifying the resource adaptor about service
			ServiceComponent svcComponent = getServiceComponent(serviceID);
			HashSet sbbIDs = svcComponent.getSbbComponents();
			HashSet raEntities = new HashSet();
			Iterator i = sbbIDs.iterator();
			while (i.hasNext()) {
				SbbDescriptor sbbdesc = getSbbComponent((SbbID) i.next());
				if (sbbdesc != null) {
					String[] raLinks = sbbdesc.getResourceAdaptorEntityLinks();
					for (int c = 0; raLinks != null && c < raLinks.length; c++) {
						ResourceAdaptorEntity raEntity = getRAEntity(raLinks[c]);
						if (raEntity != null && !raEntities.contains(raEntity)) {
							raEntity.serviceActivated(serviceID.toString());
							raEntities.add(raEntity);
						}
					}
				}
			}

			// Already active just return.
			service.activate();
			getDeploymentCacheManager().getActiveServiceIDs().add(serviceID);
			if (logger.isInfoEnabled())
				logger.info("Service Activated. Service ID: " + serviceID);
			svcComponent.lock();
			rb = false;
		} catch (InvalidStateException ise) {
			throw ise;
		} catch (UnrecognizedServiceException use) {
			throw use;
		} catch (Exception ex) {
			throw new SLEEException("Failed starting service", ex);
		} finally {

			try {
				if (rb)
					transactionManager.setRollbackOnly();
				if (b)
					transactionManager.commit();

			} catch (Exception e) {
				logger.error("Failed: transaction commit", e);
			}
		}
	}

	/**
	 * Revive a dormant service and start it. This is called when starting the
	 * SLEE after stop.
	 * 
	 * @param serviceID --
	 *            service ID of the service to start
	 * @return
	 * @throws Exception
	 */
	public void reviveAndStartService(ServiceID serviceID) throws Exception {
		SleeTransactionManager txmgr = getTransactionManager();
		txmgr.begin();
		try {
			Service svc = this.getService(serviceID);
			ServiceActivityImpl svcActivity = svc.getServiceActivity();
			String acid = svcActivity.getActivityContextId();
			ActivityContext ac = getActivityContextFactory()
					.getActivityContextById(acid);
			ac.setState(ActivityContextState.ACTIVE);
			this.startService(serviceID);
		} catch (Exception ex) {
			txmgr.setRollbackOnly();
		} finally {
			try {
				txmgr.commit();
			} catch (SystemException ex) {
				throw new RuntimeException("txmgr failed", ex);
			}
		}
	}

	/**
	 * get a resource adaptor entity given its name. To retrieve an RA Entity
	 * from. A single resource adaptor type may have multiple resource adaptors
	 * associated with it. This conveniance method just returns the first one.
	 * 
	 * @param raTypeID --
	 *            Resource adaptor type id.
	 * 
	 */
	public ResourceAdaptorEntity getResourceAdaptorEntity(
			ResourceAdaptorTypeID raTypeID) throws Exception {
		ResourceAdaptorType raType = (ResourceAdaptorType) resourceAdaptorTypes
				.get(raTypeID);
		if (raType == null)
			throw new Exception("Ra Type not found! ");
		HashSet resourceAdaptors = raType.getResourceAdaptorIDs();
		if (resourceAdaptors == null || resourceAdaptors.isEmpty())
			throw new Exception(
					"Could not find a resource adaptor for this type: "
							+ raTypeID);
		ResourceAdaptorIDImpl raId = (ResourceAdaptorIDImpl) resourceAdaptors
				.iterator().next();
		InstalledResourceAdaptor installedRa = (InstalledResourceAdaptor) installedResourceAdaptors
				.get(raId);
		if (installedRa.getResourceAdaptorEntities().size() == 0)
			throw new Exception("cannot find RA Entity! ");
		return (ResourceAdaptorEntity) installedRa.getResourceAdaptorEntities()
				.iterator().next();
	}

	/**
	 * @return The installed resource adaptor matching the given component(RA)
	 *         ID. null if there is none.
	 * 
	 * @param raId --
	 *            Resource adaptor id.
	 * 
	 */
	public InstalledResourceAdaptor getInstalledResourceAdaptor(
			ResourceAdaptorID raId) throws Exception {
		InstalledResourceAdaptor installedRa = (InstalledResourceAdaptor) installedResourceAdaptors
				.get(raId);
		return installedRa;
	}

	/**
	 * Reverses the result of
	 * 
	 * @see #initializeTckResourceAdaptor()
	 * 
	 */
	public void closeTckResourceAdaptor() {
		unregisterWithJndi("slee/resources", "tckacif");

		try {
			deactivateResourceAdaptorEntity("tck");
			// FRANCESCO -- Why do you need a name for the entity and another
			// entity links?
			resourceAdaptorEntityLinks.remove("slee/resources/tck");
		} catch (Exception e) {
			logger.error("Error Closing RA", e);

		}
	}

	/**
	 * Activate a resource adaptor entity given its name.
	 * 
	 * @param name --
	 *            name of the RA entity
	 * @throws NullPointerException
	 * @throws UnrecognizedResourceAdaptorException
	 * @throws InvalidStateException
	 * @throws ResourceException
	 * @throws ManagementException
	 * 
	 * 
	 */
	public void activateResourceAdaptorEntity(String name)
			throws UnrecognizedResourceAdaptorEntityException,
			InvalidStateException, javax.slee.resource.ResourceException,
			ManagementException {
		if (this.resourceAdaptorEntities.get(name) == null) {
			throw new UnrecognizedResourceAdaptorEntityException(
					"Resource Adaptor Entity " + name + " not found.");
		}
		ResourceAdaptorEntity raEntity = (ResourceAdaptorEntity) this.resourceAdaptorEntities
				.get(name);
		raEntity.activate();
	}

	public void addResourceAdaptorType(ResourceAdaptorTypeID key,
			ResourceAdaptorType rat) {
		this.resourceAdaptorTypes.put(key, rat);
	}

	public HashMap getResourceAdaptorTypes() {
		return resourceAdaptorTypes;
	}

	/**
	 * 
	 * Cleanup in the reverse order of init()
	 * 
	 * @throws NamingException
	 * 
	 */
	public void close() throws NamingException {

		// Cleaning up the cache is not desired for failover scenarios.
		// Cache should be cleaned only when the last node in a SLEE cluster is
		// shutting down.
		// TODO: cleanSleeCache();

		unregisterWithJndi();

		Context ctx = new InitialContext();
		Util.unbind(ctx, JVM_ENV + CTX_SLEE);

		// closeSipResourceAdaptor();
		closeTckResourceAdaptor();

		stopRMIServer();

	}

	/**
	 * These are slee defined events. These are stored in the location
	 * slee-event-jar.xml Parse these and make them known to the slee.
	 * 
	 */
	private void deployStandardEvents() throws Exception {
		// TODO: modify to use new deployment mechanisms (have one or 2 DU for
		// the standard events)
		logger.info("Deploying standard events.");
		List stdEvents = EventTypeDeploymentDescriptorParser
				.parseStandardEvents(getDeployPath()
						+ "/xml/slee-event-jar.xml");
		Iterator it = stdEvents.iterator();
		while (it.hasNext()) {
			EventTypeDescriptorImpl etype = (EventTypeDescriptorImpl) it.next();
			this.installEventType(etype);
		}
		stdEvents = EventTypeDeploymentDescriptorParser
				.parseStandardEvents(getDeployPath() + "/xml/event-jar.xml");
		it = stdEvents.iterator();
		while (it.hasNext()) {
			EventTypeDescriptorImpl etype = (EventTypeDescriptorImpl) it.next();
			this.installEventType(etype);
		}

	}

	/**
	 * These are slee defined profiles. These are stored in the location
	 * slee-profile-spec-jar.xml Parse these and make them known to the slee.
	 * 
	 */
	private void deployStandardProfileSpecs() throws Exception {
		logger.info("Deploying standard profile specs.");
		List stdProfileSpecs = ProfileSpecificationDescriptorParser
				.parseStandardProfileSpecifications(getDeployPath()
						+ "/xml/slee-profile-spec-jar.xml");
		Iterator it = stdProfileSpecs.iterator();
		while (it.hasNext()) {
			ProfileSpecificationDescriptorImpl profileSpecification = (ProfileSpecificationDescriptorImpl) it
					.next();
			this.install(profileSpecification, null);
		}
	}

	private void installEventType(EventTypeDescriptorImpl descriptorImpl)
			throws AlreadyDeployedException {
		ComponentKey ckey = new ComponentKey(descriptorImpl.getName(),
				descriptorImpl.getVendor(), descriptorImpl.getVersion());

		if (this.eventKeyToEventTypeIDMap.get(ckey) == null) {
			EventTypeIDImpl eventTypeID = new EventTypeIDImpl(ckey);
			logger.info("Installing event Type:" + eventTypeID + " descriptor "
					+ descriptorImpl);
			this.eventTypeIDToDescriptor.put(eventTypeID, descriptorImpl);
			this.eventKeyToEventTypeIDMap.put(ckey, eventTypeID);
			this.eventTypeIDToEventKeyMap.put(eventTypeID, ckey);
			this.eventTypeIDs.put(new Integer(eventTypeID.getEventID()),
					eventTypeID);
			descriptorImpl.setID(eventTypeID);
			logger.info("Added Event " + ckey + "to the Container");
		} else {

			throw new AlreadyDeployedException("The event " + ckey
					+ " is already deployed");
		}

	}

	/**
	 * Remove all the deployed evnet type information related to the deployable
	 * unit id. Searches through the set of deployed event information and
	 * removes any event information associated with this deployableUnitID
	 * 
	 * @param deployableUnitID
	 */

	private synchronized void removeEventType(DeployableUnitID deployableUnitID) {
		Iterator it = eventTypeIDToDescriptor.keySet().iterator();

		logger.info("entry of removeEventType DeployableUnit");
		while (it.hasNext()) {
			EventTypeIDImpl eventTypeID = (EventTypeIDImpl) it.next();
			EventTypeDescriptorImpl desc = (EventTypeDescriptorImpl) eventTypeIDToDescriptor
					.get(eventTypeID);
			if (desc != null && desc.getDeployableUnit() != null
					&& desc.getDeployableUnit().equals(deployableUnitID)) {
				it.remove();
				ComponentKey ckey = (ComponentKey) this.eventTypeIDToEventKeyMap
						.get(eventTypeID);
				logger.info("EVENT TYPE REMOVED: " + eventTypeID);
				this.eventTypeIDToEventKeyMap.remove(eventTypeID);
				if (ckey != null)
					eventKeyToEventTypeIDMap.remove(ckey);
				this.eventTypeIDs.remove(new Integer(eventTypeID.getEventID()));

			}
		}
	}

	/**
	 * Unregister an internal slee component with jndi.
	 * 
	 */
	public static void unregisterWithJndi(String prefix, String name) {
		unregisterWithJndi(prefix + "/" + name);
	}

	/**
	 * Unregister an internal slee component with jndi.
	 * 
	 * @param Name -
	 *            the full path to the resource except the "java:" prefix.
	 */
	public static void unregisterWithJndi(String name) {
		Context ctx;
		String path = JVM_ENV + name;
		try {
			ctx = new InitialContext();
			Util.unbind(ctx, path);
		} catch (NamingException ex) {
			logger.warn("unregisterWithJndi failed for " + path);
		}
	}

	/**
	 * Register a internal slee component with jndi.
	 * 
	 */
	public static void registerWithJndi(String prefix, String name,
			Object object) {
		String fullName = JVM_ENV + prefix + "/" + name;
		try {
			Context ctx = new InitialContext();
			try {
				Util.createSubcontext(ctx, fullName);
			} catch (NamingException e) {
				logger.warn("Context, " + fullName + " might have been bound.");
				logger.warn(e);
			}
			ctx = (Context) ctx.lookup(JVM_ENV + prefix);
			// ctx.createSubcontext(name);
			// ctx = (Context) ctx.lookup(name);
			// Util.rebind(JVM_ENV + prefix + "/" + name, object);
			NonSerializableFactory.rebind(fullName, object);
			StringRefAddr addr = new StringRefAddr("nns", fullName);
			Reference ref = new Reference(object.getClass().getName(), addr,
					NonSerializableFactory.class.getName(), null);
			Util.rebind(ctx, name, ref);
			logger.debug("registered with jndi " + fullName);
		} catch (Exception ex) {
			logger.warn("registerWithJndi failed for " + fullName, ex);
		}
	}

	/**
	 * 
	 * Convenience method for registering SLEE facilities with JNDI
	 * 
	 * @param facilityName
	 * @param facility
	 */
	public static void registerFacilityWithJndi(String facilityName,
			Object facility) {
		registerWithJndi("slee/facilities", facilityName, facility);
	}

	/**
	 * 
	 * Convenience method for unregistering SLEE facilities with JNDI
	 * 
	 * @param facilityName
	 * @param facility
	 */
	public static void unregisterFacilityWithJndi(String facilityName) {
		unregisterWithJndi("slee/facilities", facilityName);
	}

	/**
	 * 
	 * Convenience method for unregistering SLEE facilities with JNDI
	 * 
	 * @param facilityName
	 * @param facility
	 * @throws NamingException
	 */
	private static Object lookupFacilityInJndi(String facilityName)
			throws NamingException {
		return getFromJndi("slee/facilities" + "/" + facilityName);
	}

	/**
	 * lookup a name reference from jndi.
	 * 
	 * @param resourceName --
	 *            name to lookup.
	 * @throws NamingException
	 */
	private static Object getFromJndi(String resourceName)
			throws NamingException {

		Context initialContext = new InitialContext();
		Context compEnv = (Context) initialContext.lookup(JVM_ENV);
		return compEnv.lookup(resourceName);

	}

	/**
	 * Add a service to the deployment table.<br>
	 * This method follows section 15.4.2.15 - page 302 of jslee1.1
	 * specification. In particular:
	 * <ul>
	 * <li>The event types specified are of interest to the service installed
	 * in the SLEE.
	 * <li>The SLEE will only provide the resource adaptor entity information
	 * about events that are specified by the resource adaptor type of the
	 * resource adaptor. For example, if a Foo resource adaptor type only
	 * references the Foo event, then the SLEE will only tell the resource
	 * adaptor implementing this resource adaptor type about Foo events.
	 * <li> If multiple SBB entities define different resource options in the
	 * deployment descriptor for the same event type, then the SLEE concatenates
	 * the resource options on that event type.
	 * </ul>
	 * <br>
	 * <b>Resource options passed are concatenated with "," sign, no white
	 * spaces are added. eventID and corresponding options are sorted in
	 * ascending order by eventID (integer).</b> <br>
	 * Examples parameters of passed to RA to serviceInstalled method:<br>
	 * <table border="1">
	 * <tr>
	 * <th>index</th>
	 * <th>eventID</th>
	 * <th>resource options</th>
	 * </tr>
	 * <tr>
	 * <td>0</td>
	 * <td>12</td>
	 * <td>null</td>
	 * </tr>
	 * <tr>
	 * <td>1</td>
	 * <td>24</td>
	 * <td>Block</td>
	 * </tr>
	 * <tr>
	 * <td>2</td>
	 * <td>53</td>
	 * <td>Pass,Ham,Cat</td>
	 * </tr>
	 * </table><br>
	 * <b>null</b> - this is java null value, not string - "null". It is the
	 * same as:<br>
	 * <i>String nully=null;<br>
	 * System.out.println(nully);</i>
	 * 
	 * @param serviceDescriptor --
	 *            the service descriptor to add.
	 * @throws Exception --
	 *             if there was a problem installing and starting the service.
	 */
	private void installService(ServiceDescriptorImpl serviceDescriptorImpl)
			throws Exception {

		ServiceComponent svc = new ServiceComponent(serviceDescriptorImpl);

		addService((ServiceID) serviceDescriptorImpl.getID(), svc);

		if (logger.isDebugEnabled()) {

			logger
					.debug("\n==================INSTALLING SERVICE=================\n"
							+ "ROOTSBB: "
							+ svc.getRootSbbComponent()
							+ "\n"
							+ "ROOTSBBID: "
							+ svc.getRootSbbComponent().getID()
							+ "\n"
							+ "SERVICEID: "
							+ svc.getServiceID()
							+ "\n"
							+ "=====================================================");
		}

		// SBBIDS FOR THIS SERVICE
		HashSet sbbIDs = svc.getSbbComponents();

		if (logger.isDebugEnabled()) {

			Iterator sbbIdsIterator = sbbIDs.iterator();
			StringBuffer sb = new StringBuffer(300);

			while (sbbIdsIterator.hasNext()) {
				SbbDescriptor sbbdesc = (SbbDescriptorImpl) getSbbComponent((SbbID) sbbIdsIterator
						.next());
				sb.append("NAME=" + sbbdesc.getName() + " COMPONENTID="
						+ sbbdesc.getID() + "\n");
			}
			logger
					.debug("\n==================SERVICE SBBS=======================\n"
							+ sb.toString()
							+ "\n"
							+ "=====================================================");
		}

		// CONTAINS MAPPING RAENTITY TO Events that are of interest of this
		// service, which are storeded in Set( of EventTypeIDs)
		HashMap raEntitiesToEventTypeIDsOfInterest = new HashMap(5);
		// CONTAINS MAPPING OF EVENTID TO resource options FOR THIS EVENT WHICH
		// ARE STORED IN String
		HashMap eventTypeIDsToResourceOptions = new HashMap(30);
		// MAPS RA ENTITY TO EVENTS IT CAN FIRE, EVENTS ARE STORED IN Set( of
		// EventTypeIDs)
		HashMap raEntitiesToEventsFired = new HashMap(5);

		Iterator sbbIdsIterator = sbbIDs.iterator();

		// WE HAVE TO ITERATE THROUGH ALL SBBS IN SERVICE AND BUILD DATA
		// STRUCTURES
		while (sbbIdsIterator.hasNext()) {

			SbbDescriptorImpl sbbdesc = (SbbDescriptorImpl) getSbbComponent((SbbID) sbbIdsIterator
					.next());
			if (sbbdesc == null)
				continue;

			// EventTypeID[] eventTypeIDs = sbbdesc.getEventTypes();

			// HashMap sbbResourceOptionsForEventsIfInterest=new HashMap(20);
			// maps EventTypeID to coresponding SbbEventEntry
			// IT CONTAINS MAPPING FOR ALL EVENTS THAT ARE OF INTEREST IF THIS
			// SBB
			HashMap eventTypeIdToEventEntriesMappings = sbbdesc
					.getEventTypesMappings();
			// SIMPLY SET OF EventTypeIDs that are of interest of this SBB
			Set sbbEventsOfInterest = eventTypeIdToEventEntriesMappings
					.keySet();
			// HashSet sbbRaEntities=new HashSet(20);
			// LINKS OF RAs FOR THIS SBB
			String[] raLinks = sbbdesc.getResourceAdaptorEntityLinks();

			if (raLinks == null || raLinks.length == 0) {
				logger.info("======= R ALINKS.length==0 ======");
				continue;
			}
			if (logger.isDebugEnabled()) {

				logger.debug("\n"
						+ "=============SBB==============================\n"
						+ "" + sbbdesc.getName() + ", " + sbbdesc.getVendor()
						+ ", " + sbbdesc.getVersion() + "\n"
						+ "==============================================");
				Iterator eventEntryItarator = eventTypeIdToEventEntriesMappings
						.values().iterator();

				StringBuffer sb = new StringBuffer(300);

				while (eventEntryItarator.hasNext()) {
					SbbEventEntry eventEntry = (SbbEventEntry) eventEntryItarator
							.next();
					sb.append("EVENT :" + eventEntry + "\n");
				}
				logger
						.debug("\n==================EVENTS OF SBB INTEREST=======================\n"
								+ sb.toString()
								+ "\n"
								+ "=================================================================");
				sb = new StringBuffer(300);
				for (int i = 0; i < raLinks.length; i++) {
					sb.append("RALINK : " + raLinks[i] + "\n");
				}
				logger
						.debug("\n================== RA LINKS FOR SBB ==================\n"
								+ ""
								+ sb
								+ "\n"
								+ "======================================================");

			}

			for (int i = 0; i < raLinks.length; i++) {
				// RAEntity FOR THIS LINK
				ResourceAdaptorEntity raEntity = getRAEntity(raLinks[i]);
				ResourceAdaptorType raType = raEntity
						.getInstalledResourceAdaptor().getRaType();

				// IF WE HAVE PROCESSED THIS RA FOR OTHER SBB IN THIS SERVICE WE
				// SHOULD HAVE A SET OF EventyTypeIDs of EVENTS
				// IT CAN FIRE, OTHERWISE WE HAVE TO CREATE IT.
				if (!raEntitiesToEventsFired.containsKey(raEntity)) {
					// SET OF EVENTS THAT THIS RA CAN FIRE
					HashSet setOfFiredEventIds = new HashSet();
					// ComponentKey
					// eventsK[]=raType.getRaTypeDescr().getEventTypeRefEntries();

					EventTypeID[] events = raType.getRaTypeDescr()
							.getEventTypes();
					if (events == null)
						continue; // IN ORDER TO PASS TCKS... TCK RA RETURNS
									// NULL...
					for (int j = 0; j < events.length; j++)
						setOfFiredEventIds.add(events[j]);
					// LETS STORE EventTypeIDs Set THAT ARE FIRED BY THIS RA
					raEntitiesToEventsFired.put(raEntity, setOfFiredEventIds);

					// LETS CREATE FOR THIS RA SET THAT WILL BE FILLED WITH
					// EVENTS THAT ARE OF INTEREST BY THIS SERVICE
					// AND STORE IT, IT WILL BE FILLED LATER
					raEntitiesToEventTypeIDsOfInterest.put(raEntity,
							new HashSet(20));
					// raEntitiesToEventTypeIDsOfInterest.put(raEntity,new
					// TreeSet());
				}

				// EVENTS THAT ARE FIRED BY THIS RA ENTITY AND ARE OF ITNEREST
				// OF THIS SERVICE
				// IT CONTAINS EventyTypeIDs
				Set eventsOfInterest = (Set) raEntitiesToEventTypeIDsOfInterest
						.get(raEntity);
				// SET OF EventTypeIDs FIRED BYT THIS RA ENTITY
				Set eventsFiredByRAEntity = (Set) raEntitiesToEventsFired
						.get(raEntity);
				Iterator eventsOfSbbinterest = sbbEventsOfInterest.iterator();

				// LETS FILL IN eventsOfInterest
				while (eventsOfSbbinterest.hasNext()) {
					// IT SHOUDL BE EventTypeID
					Object eventIdOfSbbItenrest = eventsOfSbbinterest.next();

					// IF THIS RA FIRES EVENT THAT IS OF ITNEREST OF SBB
					if (eventsFiredByRAEntity.contains(eventIdOfSbbItenrest)) {
						// TODO: - CAN WE REMOVE IT? IT SEEMS LIKE GOOD IDEA, IT
						// WILL REDUCE OVERHEAD OF PROCESSING
						// THOSE LOOPS FOR OTHER RAs
						// eventsOfSbbinterest.remove();
						eventsOfInterest.add(eventIdOfSbbItenrest);
						// GET RESOURCE OPTION?
						SbbEventEntry eventEntry = (SbbEventEntry) eventTypeIdToEventEntriesMappings
								.get(eventIdOfSbbItenrest);
						String resourceOption = eventEntry.getResourceOption();
						// STORE RESOURCE OPTION FOR THIS EventTypeID
						if (resourceOption != null)
							if (eventTypeIDsToResourceOptions
									.containsKey(eventIdOfSbbItenrest)) {
								String value = (String) eventTypeIDsToResourceOptions
										.remove(eventIdOfSbbItenrest);
								// WE DONT NEED MORE THAN ONE OPTION KIND HERE.
								if (value.indexOf(resourceOption) == -1) {
									value += "," + resourceOption;
									eventTypeIDsToResourceOptions.put(
											eventIdOfSbbItenrest, value);
								}
							} else {
								eventTypeIDsToResourceOptions.put(
										eventIdOfSbbItenrest, resourceOption);
							}
					}
				}

				if (logger.isDebugEnabled()) {

					StringBuffer sb = new StringBuffer(300);
					Iterator it = eventsOfInterest.iterator();
					while (it.hasNext()) {
						sb.append(it.next() + "\n");
					}
					logger
							.debug("\n=========================== EVENTIDS OF INTEREST FROM RA===========================\n"
									+ ""
									+ sb
									+ "\n"
									+ "=====================================================================================");
				}
			}

		}

		// NOW WE HAVE TO BUILD ARRAYS OF eventIDs and coresponding resource
		// options for each RA ENTITY

		Iterator raEntities = raEntitiesToEventTypeIDsOfInterest.keySet()
				.iterator();
		Iterator eventTypeIdIterator = null;
		String resourceOption = null;
		int eventID = -1;
		// IF WE HAVE SOME RAs, WE NEED TO LET THEM KNOW THAT SOMEONE IS GOING
		// TO BE INSTALLED
		// AND THAT HE IS INTERESTED IN SOME EVENTS WITH SOME ResoureOptions
		while (raEntities.hasNext()) {
			ResourceAdaptorEntity raEntity = (ResourceAdaptorEntity) raEntities
					.next();
			Set eventsOfServiceInterest = (Set) raEntitiesToEventTypeIDsOfInterest
					.get(raEntity);
			// eventIDs and resourceOptions ARE GOING TO BE PASSED AS ARGS TO RA
			// eventIDs[i]=int# , resourceOptions[i]=optionsFor-int#
			int[] eventIDs = new int[eventsOfServiceInterest.size()];
			String[] resourceOptions = new String[eventsOfServiceInterest
					.size()];

			eventsOfServiceInterest = new TreeSet(eventsOfServiceInterest);

			int i = 0;

			eventTypeIdIterator = eventsOfServiceInterest.iterator();

			while (eventTypeIdIterator.hasNext()) {
				EventTypeID ETID = (EventTypeID) eventTypeIdIterator.next();
				eventID = eventLookup.getEventID(getEventKey(ETID));
				resourceOption = (String) eventTypeIDsToResourceOptions
						.get(ETID);
				eventIDs[i] = eventID;
				resourceOptions[i++] = resourceOption;

			}

			if (logger.isDebugEnabled()) {

				StringBuffer sb = new StringBuffer(300);
				sb.append("INDEX[ eventID | resourceOptions ]\n");
				for (int k = 0; k < eventIDs.length; k++) {

					sb.append("#" + k + "[ " + eventIDs[k] + " | "
							+ resourceOptions[k] + " ]\n");
				}
				ResourceAdaptorTypeDescriptorImpl raDesc = raEntity
						.getInstalledResourceAdaptor().getRaType()
						.getRaTypeDescr();
				logger
						.debug("\n============= PASSING INSTALL SERVCICE ARGS TO RA =============\n"
								+ "| RA DESC: "
								+ raDesc.getName()
								+ ", "
								+ raDesc.getVendor()
								+ ", "
								+ raDesc.getVersion()
								+ "\n"
								+ "===============================================================\n"
								+ "| EVENTS : |\n"
								+ "============\n"
								+ ""
								+ sb
								+ "\n"
								+ "===============================================================");
			}

			raEntity.serviceInstalled(svc.getServiceID().toString(), eventIDs,
					resourceOptions);
			// ZERO VARS
			
			setupSbbEnvironment(sbbDescriptorImpl);

		} catch (Exception ex) {
			throw ex;
				}

			}
			if (logger.isDebugEnabled()) {
				logger.debug("removeReferredDU After Remove "
						+ this.getDeploymentCacheManager()
								.getComponentIDToDeployableUnitIDMap());
			}
		} catch (Exception ex) {
			throw new RuntimeException("tx manager failed ! ", ex);
		}
	}

	/**
	 * Return true if there are any components that hold references to the
	 * deployable unit
	 * 
	 * @param dudesc --
	 *            the deployable unit descriptor to check.
	 * @return true -- if there are referring components.
	 * @throws Exception --
	 *             if theres a problem with the cache.
	 */
	private boolean hasReferringDU(DeployableUnitDescriptorImpl dudesc)
	}
