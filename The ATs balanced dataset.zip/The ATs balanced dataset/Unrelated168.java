    if (db == null || o == null) {
      return;
    } else if (db.isPersistent(o) || m_Update) {
      log.debug(JwmaKernel.getReference().getLogMessage("jwma.plugin.castor.objupdate") + o.toString());
      if (o instanceof Associator) {
        cleanupAssociations(db, ((Associator) o).getRemovedAssociations());
      }
      db.update(o);
    } else {
      log.debug(JwmaKernel.getReference().getLogMessage("jwma.plugin.castor.objcreate") + o.toString());
      db.create(o);
    }
  }//storeObject


  private void cleanupAssociations(Database db, List l)
      throws PersistenceException {

    Object o = null;
    for (Iterator iter = l.iterator(); iter.hasNext();) {
      AssociatedAbstractIdentifiable assoc =
          (AssociatedAbstractIdentifiable) iter.next();
      //check if object has an association
      if (!assoc.isAssociated()) {
        log.debug(JwmaKernel.getReference().getLogMessage("jwma.plugin.castor.objremove") +
            assoc.getClass() +
            " " +
            assoc.toString());
        //needs to be loaded in this transaction :( hack but works
        try {
          o = db.load(assoc.getClass(), assoc.getUID());
        } catch (PersistenceException pex) {
          /*more hack, required to work*/
        }
        db.remove(o);
      }
    }
    //and definately, remove the references
    l.clear();
  }//cleanupAssociations

  public long jdoGetTimeStamp() {
    return m_Timestamp;
  }//jdoGetTimeStamp

  public void jdoSetTimeStamp(long timeStamp) {
    m_Timestamp = timeStamp;
  }//jdoSetTimeStamp

}//class JwmaPreferencesImpl
      persistPreferences(db);
    } finally {
      m_Update = false;
    }
  }//updateDatabase


  public void persistPreferences(Database db)
      throws PersistenceException {

    //1. store this
    storeObject(db, this);

    //3. iterate over identities, ensure order by indexing

    for (Iterator iter = m_MailIdentities.listIterator(); iter.hasNext();) {
      //Object next=iter.next();
      //((Indexable)next).setIndex(i);
      storeObject(db, iter.next());
    }
  }//persistPreferences


  private void storeObject(Database db, Object o)
      throws PersistenceException {
      prefs.setAutoEmpty(this.isAutoEmpty());
      prefs.setAutoMoveRead(this.isAutoMoveRead());
      prefs.setDisplayingInlined(this.isDisplayingInlined());

      //add up a default mail identity
      CastorMailIdentity mid = new CastorMailIdentity();
      //with some sense making values
      mid.setName("Default");
      prefs.addMailIdentity(mid);
      prefs.setDefaultMailIdentity(mid.getUID());
      return prefs;
    } catch (Exception ex) {
      return null;
    }
  }//getClone

  public List getRemovedAssociations() {
    return m_RemovedAssociations;
  }//getRemovedAssociations


  public void updatePreferences(Database db)
      throws PersistenceException {
    m_Update = true;
    try {
/* CVS ID: $Id: SendMessage.java,v 1.2 2003/03/22 12:07:13 gcsideal Exp $ */
import net.wastl.webmail.server.*;
import net.wastl.webmail.server.http.*;
import net.wastl.webmail.ui.html.*;
import net.wastl.webmail.ui.xml.*;

import net.wastl.webmail.misc.*;
import net.wastl.webmail.config.ConfigurationListener;
import net.wastl.webmail.exceptions.*;

import java.io.*;
import java.util.*;
import java.text.*;
import javax.mail.*;
import javax.mail.internet.*;


import javax.servlet.ServletException;

// Modified by exce, start
import org.bulbul.webmail.util.TranscodeUtil;
// Modified by exce, end

/*
 * SendMessage.java
 *
 * Created: Tue Sep  7 13:59:30 1999
 *
 * Copyright (C) 1999-2000 Sebastian Schaffert
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
/**
 * Send a message and show a result page.
 * 
 * provides: message send
 * requires: composer
 *
 * @author Sebastian Schaffert
 * @version
 */

public class SendMessage implements Plugin, URLHandler, ConfigurationListener {
    
    public static final String VERSION="1.8";
    public static final String URL="/send";
    
    Storage store;

    WebMailServer parent;

    Session mailsession;

    public SendMessage() {
	
    }

    public void register(WebMailServer parent) {
	parent.getURLHandler().registerHandler(URL,this);
	parent.getConfigScheme().configRegisterStringKey(this,"SMTP HOST","localhost","Host used to send messages via SMTP. Should be localhost or your SMTP smarthost");
	parent.getConfigScheme().configRegisterYesNoKey(this,"ADVERTISEMENT ATTACH", "Attach advertisement from ADVERTISEMENT SIGNATURE PATH to each outgoing message");
	parent.getConfigScheme().setDefaultValue("ADVERTISEMENT ATTACH","NO");
	parent.getConfigScheme().configRegisterStringKey(this,"ADVERTISEMENT SIGNATURE PATH","advertisement.sig","Path to advertisement to attach to all outgoing messages (either absolute or relative to data directory)");
	this.store=parent.getStorage();
	this.parent=parent;

	init();
    }

    protected void init() {
	Properties props=new Properties();
	props.put("mail.host",store.getConfig("SMTP HOST"));
	props.put("mail.smtp.host",store.getConfig("SMTP HOST"));
	mailsession=Session.getInstance(props,null);
    } 

    public String getName() {
	return "SendMessage";
    }

    public String getDescription() {
	return "This URL-Handler sends a submitted message.";
    }

    public String getVersion() {
	return VERSION;
    }

    public String getURL() {
	return URL;
    }
    
    public void notifyConfigurationChange(String key) {
	init();
    }

    public HTMLDocument handleURL(String suburl, HTTPSession sess1, HTTPRequestHeader head) throws WebMailException, ServletException {
	if(sess1 == null) {
	    throw new WebMailException("No session was given. If you feel this is incorrect, please contact your system administrator");
	}
	WebMailSession session=(WebMailSession)sess1;
	UserData user=session.getUser();
	HTMLDocument content;

	// Modified by exce, start
	Locale locale = user.getPreferredLocale();
	// Modified by exce, end
	
	/* Save message in case there is an error */
	session.storeMessage(head);

	if(head.isContentSet("SEND")) {
	    /* The form was submitted, now we will send it ... */
	    try {

		MimeMessage msg=new MimeMessage(mailsession);		

		Address from[]=new Address[1];
		try {
		    // Modified by exce, start
		    /**
		     * Why we need 
		     * org.bulbul.util.TranscodeUtil.transcodeThenEncodeByLocale()?
		     *
		     * Because we specify client browser's encoding to UTF-8, IE seems
		     * to send all data encoded in UTF-8. We have to transcode all byte
		     * sequences we received to UTF-8, and next we encode those strings
		     * using MimeUtility.encodeText() depending on user's locale. Since
		     * MimeUtility.encodeText() is used to convert the strings into its
		     * transmission format, finally we can use the strings in the
		     * outgoing e-mail which relies on receiver's email agent to decode
		     * the strings.
		     *
		     * As described in JavaMail document, MimeUtility.encodeText() conforms
		     * to RFC2047 and as a result, we'll get strings like "=?Big5?B......".
		     */
		    /**
		     * Since data in session.getUser() is read from file, the encoding
		     * should be default encoding.
		     */
		    // from[0]=new InternetAddress(MimeUtility.encodeText(session.getUser().getEmail()),
		    // 			MimeUtility.encodeText(session.getUser().getFullName()));
		    from[0]=
			new InternetAddress(
					    TranscodeUtil.transcodeThenEncodeByLocale(head.getContent("FROM"), null, locale),
					    TranscodeUtil.transcodeThenEncodeByLocale(session.getUser().getFullName(), null, locale)
					    );
		    // Modified by exce, end
		} catch(UnsupportedEncodingException e) {
		    store.log(Storage.LOG_WARN,
			      "Unsupported Encoding while trying to send message: "+e.getMessage());
		    from[0]=
			new InternetAddress(head.getContent("FROM"),
					    session.getUser().getFullName());
		}
		
		StringTokenizer t;
		try {
		    // Modified by exce, start
		    /**
		     * Since data in session.getUser() is read from file, the encoding
		     * should be default encoding.
		     */
		    // t=new StringTokenizer(MimeUtility.encodeText(head.getContent("TO")).trim(),",");
		    t = new StringTokenizer(TranscodeUtil.transcodeThenEncodeByLocale(head.getContent("TO"), null, locale).trim(), ",");
		    // Modified by exce, end
		} catch(UnsupportedEncodingException e) {
		    store.log(Storage.LOG_WARN,
			      "Unsupported Encoding while trying to send message: "+e.getMessage());
		    t=new StringTokenizer(head.getContent("TO").trim(),",;");
		}

		/* Check To: field, when empty, throw an exception */
		if(t.countTokens()<1) {
		    throw new MessagingException("The recipient field must not be empty!");
		}
		Address to[]=new Address[t.countTokens()];
		int i=0;
		while(t.hasMoreTokens()) {
		    to[i]=new InternetAddress(t.nextToken().trim());
		    i++;
		}
		
		try {
		    // Modified by exce, start
		    /**
		     * Since data in session.getUser() is read from file, the encoding
		     * should be default encoding.
		     */
		    // t=new StringTokenizer(MimeUtility.encodeText(head.getContent("CC")).trim(),",");
		    t = new StringTokenizer(TranscodeUtil.transcodeThenEncodeByLocale(head.getContent("CC"), null, locale).trim(), ",");
		    // Modified by exce, end
		} catch(UnsupportedEncodingException e) {
		    store.log(Storage.LOG_WARN,
			      "Unsupported Encoding while trying to send message: "+e.getMessage());
		    t=new StringTokenizer(head.getContent("CC").trim(),",;");
		}
		Address cc[]=new Address[t.countTokens()];
		i=0;
		while(t.hasMoreTokens()) {
		    cc[i]=new InternetAddress(t.nextToken().trim());
		    i++;
		}
		
		try {
		    // Modified by exce, start
		    /**
		     * Since data in session.getUser() is read from file, the encoding
		     * should be default encoding.
		     */
		    // t=new StringTokenizer(MimeUtility.encodeText(head.getContent("BCC")).trim(),",");
		    t = new StringTokenizer(TranscodeUtil.transcodeThenEncodeByLocale(head.getContent("BCC"), null, locale).trim(), ",");
		    // Modified by exce, end
		} catch(UnsupportedEncodingException e) {
		    store.log(Storage.LOG_WARN,
			      "Unsupported Encoding while trying to send message: "+e.getMessage());
		    t=new StringTokenizer(head.getContent("BCC").trim(),",;");
		}
		Address bcc[]=new Address[t.countTokens()];
		i=0;
		while(t.hasMoreTokens()) {
		    bcc[i]=new InternetAddress(t.nextToken().trim());
		    i++;
		}

		session.setSent(false);

		msg.addFrom(from);
		if(to.length > 0) {
		    msg.addRecipients(Message.RecipientType.TO,to);
		}
		if(cc.length > 0) {
		    msg.addRecipients(Message.RecipientType.CC,cc);
		}
		if(bcc.length > 0) {
		    msg.addRecipients(Message.RecipientType.BCC,bcc);
		}
		msg.addHeader("X-Mailer",WebMailServer.getVersion()+", "+getName()+" plugin v"+getVersion());

		String subject = null;

		if(!head.isContentSet("SUBJECT")) {
		    subject="no subject";
		} else {
		    try {
			// Modified by exce, start
			// subject=MimeUtility.encodeText(head.getContent("SUBJECT"));
			subject = TranscodeUtil.transcodeThenEncodeByLocale(head.getContent("SUBJECT"), "ISO8859_1", locale);
			// Modified by exce, end
		    } catch(UnsupportedEncodingException e) {
			store.log(Storage.LOG_WARN,"Unsupported Encoding while trying to send message: "+e.getMessage());
			subject=head.getContent("SUBJECT");
		    }	    
		}
				
		msg.addHeader("Subject",subject);

		if(head.isContentSet("REPLY-TO")) {
		    // Modified by exce, start
		    // msg.addHeader("Reply-To",head.getContent("REPLY-TO"));
		    msg.addHeader("Reply-To", TranscodeUtil.transcodeThenEncodeByLocale(head.getContent("REPLY-TO"), "ISO8859_1", locale));
		    // Modified by exce, end
		}

		msg.setSentDate(new Date(System.currentTimeMillis()));

		String contnt=head.getContent("BODY");

		//String charset=MimeUtility.mimeCharset(MimeUtility.getDefaultJavaCharset());
		String charset="utf-8";

		MimeMultipart cont=new MimeMultipart();
		MimeBodyPart txt=new MimeBodyPart();

		// Transcode to UTF-8
		contnt = new String(contnt.getBytes("ISO8859_1"), "UTF-8");
		// Encode text
		if (locale.getLanguage().equals("zh") && locale.getCountry().equals("TW")) {
		    txt.setText(contnt, "Big5");
		    txt.setHeader("Content-Type","text/plain; charset=\"Big5\"");
		    txt.setHeader("Content-Transfer-Encoding", "quoted-printable"); // JavaMail defaults to QP?
		} else {
		    txt.setText(contnt,"utf-8");
		    txt.setHeader("Content-Type","text/plain; charset=\"utf-8\"");
		    txt.setHeader("Content-Transfer-Encoding", "quoted-printable"); // JavaMail defaults to QP?
		}


		/* Add an advertisement if the administrator requested to do so */
		cont.addBodyPart(txt);
		if(store.getConfig("ADVERTISEMENT ATTACH").equals("YES")) {
		    MimeBodyPart adv=new MimeBodyPart();
		    String file="";
		    if(store.getConfig("ADVERTISEMENT SIGNATURE PATH").startsWith("/")) {
			file=store.getConfig("ADVERTISEMENT SIGNATURE PATH");
		    } else {
			file=parent.getProperty("webmail.data.path")+System.getProperty("file.separator")+
			    store.getConfig("ADVERTISEMENT SIGNATURE PATH");
		    }
		    String advcont="";
		    try {
			BufferedReader fin=new BufferedReader(new FileReader(file));
			String line=fin.readLine();
			while(line!= null && !line.equals("")) {
			    advcont+=line+"\n";
			    line=fin.readLine();
			}
			fin.close();
		    } catch(IOException ex) {}

		    /**
		     * Transcode to UTF-8; Since advcont comes from file, we transcode 
		     * it from default encoding.
		     */
		    // Encode text
		    if (locale.getLanguage().equals("zh") &&
			locale.getCountry().equals("TW")) {
			advcont = new String(advcont.getBytes(), "Big5");
			adv.setText(advcont,"Big5");
			adv.setHeader("Content-Type","text/plain; charset=\"Big5\"");
			adv.setHeader("Content-Transfer-Encoding", "quoted-printable"); 
		    } else {
			advcont = new String(advcont.getBytes(), "UTF-8");
		    	adv.setText(advcont,"utf-8");
		    	adv.setHeader("Content-Type","text/plain; charset=\"utf-8\"");
		    	adv.setHeader("Content-Transfer-Encoding", "quoted-printable"); 
		    }			

		    cont.addBodyPart(adv);
		}
