import jcifs.smb.NtlmPasswordAuthentication;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import ru.runa.af.Actor;
import ru.runa.af.ArgumentsCommons;
import ru.runa.af.AuthenticationException;
import ru.runa.af.authenticaion.KerberosLoginModuleResources;
import ru.runa.af.authenticaion.SubjectPrincipalsHelper;
import ru.runa.af.logic.AuthenticationLogic;
import ru.runa.af.service.AuthenticationService;

/**
 * Implements AuthenticationService as bean. Created on 20.07.2004
 * 
 * @ejb.bean name = "AuthenticationService" jndi-name = "af/AuthenticationService" local-jndi-name = "af/AuthenticationServiceLocal" transaction-type
 *           = "Container" type = "Stateless" view-type = "both"
 */
public class AuthenticationServiceBean extends ServiceBean implements AuthenticationService {
    private static final long serialVersionUID = -2701378434260245399L;
    private static final AuthenticationLogic authenticationLogic = new AuthenticationLogic();
    private static final Log log = LogFactory.getLog(AuthenticationServiceBean.class);

    /**
     * @ejb.interface-method view-type = "both"
     * @ejb.transaction type = "Required"
     */
    public Subject authenticate() throws AuthenticationException {
        log.debug("Authenticating (principal)");
        Subject subject = authenticationLogic.authenticate(context.getCallerPrincipal());
        log.debug("Authenticated (principal): " + SubjectPrincipalsHelper.getActor(subject));
        return subject;
    }

    /**
     * @ejb.interface-method view-type = "both"
     * @ejb.transaction type = "Required"
     */
    public Subject authenticate(NtlmPasswordAuthentication authentication) throws AuthenticationException {
        ArgumentsCommons.checkNotNull(authentication, "NtlmPasswordAuthentication");
        log.debug("Authenticating (ntlm)");
        Subject subject = authenticationLogic.authenticate(authentication);
        log.debug("Authenticated (ntlm): " + SubjectPrincipalsHelper.getActor(subject));
        return subject;
    }

    /**
     * @ejb.interface-method view-type = "both"
     * @ejb.transaction type = "Required"
     */
    public Subject authenticate(byte[] token) throws AuthenticationException {
        ArgumentsCommons.checkNotNull(token, "Kerberos authentication information");
        log.debug("Authenticating (kerberos)");
        Subject subject = authenticationLogic.authenticate(token, KerberosLoginModuleResources.rtnKerberosResources);
        log.debug("Authenticated (kerberos): " + SubjectPrincipalsHelper.getActor(subject));
        return subject;
    }

    /**
     * @ejb.interface-method view-type = "both"
     * @ejb.transaction type = "Required"
     */
    public Subject authenticate(String name, String password) throws AuthenticationException {
        ArgumentsCommons.checkNotEmpty(name, "User login");
        log.debug("Authenticating (login) " + name);
        Subject subject = authenticationLogic.authenticate(name, password);
        log.debug("Authenticated (login): " + name);
        return subject;
    }

    /**
     * @ejb.interface-method view-type = "both"
     * @ejb.transaction type = "Required"
     */
    public Actor getActor(Subject subject) throws AuthenticationException {
        ArgumentsCommons.checkNotNull(subject);
        return authenticationLogic.getActor(subject);
    }
}