import java.util.Properties;

import org.enhydra.shark.api.client.wfmc.wapi.WMFilter;
import org.enhydra.shark.api.client.wfmodel.WfProcessIterator;
import org.enhydra.shark.api.client.wfservice.SharkConnection;
import org.enhydra.shark.api.client.xpil.XPILHandler;
import org.enhydra.shark.api.common.ProcessFilterBuilder;
import org.enhydra.shark.api.common.SharkConstants;
import org.enhydra.shark.client.utilities.SharkInterfaceWrapper;
import org.enhydra.shark.utilities.MiscUtilities;
import org.enhydra.shark.webclient.spec.utils.ParamConsts;
import org.w3c.dom.Node;

import com.lutris.util.Config;

public class XMLProcessInstanceBuilder extends XMLBuilderImpl {

   public XMLProcessInstanceBuilder(String username,
                                    String selectedUser,
                                    Config config,
                                    String startElement,
                                    String sortCriterion,
                                    String sortAsc) {
      this.username = username;
      this.config = config;
      this.from_element = startElement;
      this.sortCriterion = sortCriterion;
      this.sortAsc = sortAsc;

      if (selectedUser!=null) {
         this.map.put("selected_user", selectedUser);
      }
   }

   protected Node fillXMLElements() throws Exception {
      SharkConnection sc = SharkInterfaceWrapper.getSharkConnection(username);

      int itemsPerPage = config.getInt("SharkWebClient."
                                       + ParamConsts.PROPERTY_PREFIX_PROCESSLIST
                                       + ".max.rows.per.page", 5);

      int startAt = Integer.parseInt(from_element != null ? from_element : "0");

      boolean myProcessesOnly = config.getBoolean("SharkWebClient."
                                                        + ParamConsts.PROPERTY_PREFIX_PROCESSLIST
                                                        + ".fill.xpil.onlymyprocesses",
                                                  true);

      String groups = config.getString("SharkWebClient."
                                       + ParamConsts.PROCLIST_WLH + ".groups", "none");
      String selectedUser = (String) this.map.get("selected_user");

      if (selectedUser==null) {
         selectedUser=username;
         map.put("selected_user",selectedUser);
      }
      if (selectedUser.equalsIgnoreCase("*")) {
         myProcessesOnly = false;
      } else {
         myProcessesOnly = true;
      }
      boolean isSuperUser = SharkUtils.canSwitchUsers(sc, groups, username);

      boolean openProcessesOnly = config.getBoolean("SharkWebClient."
                                                          + ParamConsts.PROPERTY_PREFIX_PROCESSLIST
                                                          + ".fill.xpil.onlyopenprocesses",
                                                    false);

      WfProcessIterator pit = sc.get_iterator_process();
      ProcessFilterBuilder fb = SharkInterfaceWrapper.getProcessFilterBuilder();
      WMFilter filter = fb.createEmptyFilter(sc.getSessionHandle());
      if (myProcessesOnly) {
         filter = fb.and(sc.getSessionHandle(),
                         filter,
                         fb.addRequesterUsernameEquals(sc.getSessionHandle(),
                                                       selectedUser));
      }
      if (openProcessesOnly) {
         filter = fb.and(sc.getSessionHandle(),
                         filter,
                         fb.addStateStartsWith(sc.getSessionHandle(),
                                               SharkConstants.STATEPREFIX_OPEN));
      }

      String exp = fb.toIteratorExpression(sc.getSessionHandle(), filter);
      pit.set_query_expression(exp);
      int hm = pit.how_many();
      if (startAt > hm) {
         startAt = (hm / itemsPerPage) * itemsPerPage;
         from_element = Integer.toString(startAt);
      } else if (startAt == hm && hm > 0) {
         startAt = startAt - itemsPerPage;
         from_element = Integer.toString(startAt);
      }
      from_element = Integer.toString(startAt);
      to_element = Integer.toString(startAt + itemsPerPage - 1);
      total_number = Integer.toString(hm);

      filter = fb.setLimit(sc.getSessionHandle(), filter, itemsPerPage);
      filter = fb.setStartPosition(sc.getSessionHandle(), filter, startAt);

      if (this.sortCriterion == null || this.sortCriterion.equals("")) { // search as
         // declared in
         // config file
         String orderByList = config.getString("SharkWebClient."
                                               + ParamConsts.PROPERTY_PREFIX_PROCESSLIST
                                               + ".fill.xpil.orderbylist", "");
         String[] obstrs = MiscUtilities.tokenize(orderByList, ";");
         if (obstrs.length > 0) {
            for (int i = 0; i < obstrs.length; i++) {
               String obs = obstrs[i];
               String[] sortinfo = MiscUtilities.tokenize(obs, ",");
               if (sortinfo != null && sortinfo.length == 2) {
                  String orderBy = sortinfo[0];
                  boolean asc = new Boolean(sortinfo[1]).booleanValue();
                  if (orderBy.equals("state")) {
                     fb.setOrderByState(sc.getSessionHandle(), filter, asc);
                  } else if (orderBy.equals("createdtime")) {
                     fb.setOrderByCreatedTime(sc.getSessionHandle(), filter, asc);
                  } else if (orderBy.equals("id")) {
                     fb.setOrderById(sc.getSessionHandle(), filter, asc);
                  } else if (orderBy.equals("priority")) {
                     fb.setOrderByPriority(sc.getSessionHandle(), filter, asc);
                  } else if (orderBy.equals("requester")) {
                     fb.setOrderByResourceRequesterId(sc.getSessionHandle(), filter, asc);
                  } else if (orderBy.equals("name")) {
                     fb.setOrderByName(sc.getSessionHandle(), filter, asc);
                  }
               }
            }
         }
      }
      // user has chosen search criterion
      // can search by state, createdTime, priority, requester, name
      else {
         if (this.sortCriterion.equalsIgnoreCase("state")) {
            fb.setOrderByState(sc.getSessionHandle(),
                               filter,
                               Boolean.valueOf(this.sortAsc).booleanValue());
         } else if (this.sortCriterion.equalsIgnoreCase("createdtime")) {
            fb.setOrderByCreatedTime(sc.getSessionHandle(),
                                     filter,
                                     Boolean.valueOf(this.sortAsc).booleanValue());
         } else if (this.sortCriterion.equalsIgnoreCase("priority")) {
            fb.setOrderByPriority(sc.getSessionHandle(),
                                  filter,
                                  Boolean.valueOf(this.sortAsc).booleanValue());
         } else if (this.sortCriterion.equalsIgnoreCase("requester")) {
            fb.setOrderByResourceRequesterId(sc.getSessionHandle(),
                                             filter,
                                             Boolean.valueOf(this.sortAsc).booleanValue());
         } else if (this.sortCriterion.equalsIgnoreCase("name")) {
            fb.setOrderByName(sc.getSessionHandle(),
                              filter,
                              Boolean.valueOf(this.sortAsc).booleanValue());
         } else if (this.sortCriterion.equalsIgnoreCase("id")) {
            fb.setOrderById(sc.getSessionHandle(), filter, Boolean.valueOf(this.sortAsc)
               .booleanValue());
         }
      }

      Properties props = new Properties();

      String prop = config.getString("SharkWebClient."
                                     + ParamConsts.PROPERTY_PREFIX_PROCESSLIST + "."
                                     + XPILHandler.FILL_PACKAGE_EXT_ATTRIBS, "false");
      props.setProperty(XPILHandler.FILL_PACKAGE_EXT_ATTRIBS, prop);
      prop = config.getString("SharkWebClient."
                              + ParamConsts.PROPERTY_PREFIX_PROCESSLIST + "."
                              + XPILHandler.FILL_PROCESS_FACTORY_EXT_ATTRIBS, "false");
      props.setProperty(XPILHandler.FILL_PROCESS_FACTORY_EXT_ATTRIBS, prop);
      prop = config.getString("SharkWebClient."
                              + ParamConsts.PROPERTY_PREFIX_PROCESSLIST + "."
                              + XPILHandler.FILL_PROCESS_EXT_ATTRIBS, "false");
      props.setProperty(XPILHandler.FILL_PROCESS_EXT_ATTRIBS, prop);
      prop = config.getString("SharkWebClient."
                              + ParamConsts.PROPERTY_PREFIX_PROCESSLIST + "."
                              + XPILHandler.FILL_ACTIVITY_EXT_ATTRIBS, "false");
      props.setProperty(XPILHandler.FILL_ACTIVITY_EXT_ATTRIBS, prop);
      config.getString("SharkWebClient."
                       + ParamConsts.PROPERTY_PREFIX_PROCESSLIST + "."
                       + XPILHandler.FILL_VARIABLE_EXT_ATTRIBS, "false");
      props.setProperty(XPILHandler.FILL_VARIABLE_EXT_ATTRIBS, prop);
      prop = config.getString("SharkWebClient."
                              + ParamConsts.PROPERTY_PREFIX_PROCESSLIST + "."
                              + XPILHandler.FILL_PROCESS_VARIABLES, "false");
      props.setProperty(XPILHandler.FILL_PROCESS_VARIABLES, prop);
      prop = config.getString("SharkWebClient."
                              + ParamConsts.PROPERTY_PREFIX_PROCESSLIST + "."
                              + XPILHandler.FILL_ALL_ACTIVITIES, "false");
      props.setProperty(XPILHandler.FILL_ALL_ACTIVITIES, prop);
      prop = config.getString("SharkWebClient."
                              + ParamConsts.PROPERTY_PREFIX_PROCESSLIST + "."
                              + XPILHandler.FILL_RUNNING_ACTIVITIES, "false");
      props.setProperty(XPILHandler.FILL_RUNNING_ACTIVITIES, prop);
      prop = config.getString("SharkWebClient."
                              + ParamConsts.PROPERTY_PREFIX_PROCESSLIST + "."
                              + XPILHandler.FILL_ACTIVITY_VARIABLES, "false");
      props.setProperty(XPILHandler.FILL_ACTIVITY_VARIABLES, prop);
      prop = config.getString("SharkWebClient."
                              + ParamConsts.PROPERTY_PREFIX_PROCESSLIST + "."
                              + XPILHandler.FILL_ACTIVITY_ASSIGNMENTS, "false");
      props.setProperty(XPILHandler.FILL_ACTIVITY_ASSIGNMENTS, prop);

      // prop = config.getString("SharkWebClient."
      // + ParamConsts.PROPERTY_PREFIX_PROCESSLIST + "."
      // + XPILHandler.FILL_USERS, "true");
      props.setProperty(XPILHandler.FILL_USERS, (new Boolean(isSuperUser)).toString());

      prop = config.getString("SharkWebClient."
                              + ParamConsts.PROPERTY_PREFIX_PROCESSLIST + "."
                              + XPILHandler.FILL_PROCESS_FACTORIES, "true");
      props.setProperty(XPILHandler.FILL_PROCESS_FACTORIES, prop);
      prop = config.getString("SharkWebClient."
                              + ParamConsts.PROPERTY_PREFIX_PROCESSLIST + "."
                              + XPILHandler.SHOW_LAST_FACTORY_VERSION_ONLY, "false");
      props.setProperty(XPILHandler.SHOW_LAST_FACTORY_VERSION_ONLY, prop);

      Node n = SharkInterfaceWrapper.getXPILHandler().getProcessInstanceList(sc.getSessionHandle(),
                                                                  selectedUser,
                                                                  filter,
                                                                  props);

      sc.disconnect();

      return n;
   }

}
import org.enhydra.shark.api.admin.RepositoryMgr;
import org.enhydra.shark.api.client.wfmc.wapi.WMFilter;
import org.enhydra.shark.api.client.wfservice.SharkConnection;
import org.enhydra.shark.api.client.wfservice.WMEntity;
import org.enhydra.shark.api.client.wfservice.WMEntityIterator;
import org.enhydra.shark.api.client.wfservice.XPDLBrowser;
import org.enhydra.shark.api.client.xpil.XPILHandler;
import org.enhydra.shark.client.utilities.SharkInterfaceWrapper;
import org.enhydra.shark.webclient.spec.utils.ParamConsts;
import org.enhydra.shark.xpil.XPILExtendedWorkflowFacilityInstanceDocument;
import org.enhydra.shark.xpil.XPILInstanceExtendedAttributeDocument.InstanceExtendedAttribute;
import org.enhydra.shark.xpil.XPILPackageInstancesDocument.PackageInstances;
import org.w3c.dom.Node;

import com.lutris.util.Config;

public class XMLPackageManagementInstanceBuilder extends XMLBuilderImpl {

   public XMLPackageManagementInstanceBuilder(String username,
                                              Config config,
                                              String startElement,
                                              String sortCriterion,
                                              String sortAsc) {
      this.username = username;
      this.config = config;
      this.from_element = startElement;
      this.sortCriterion = sortCriterion;
      this.sortAsc = sortAsc;

   }

   protected Node fillXMLElements() throws Exception {
      SharkConnection sc = SharkInterfaceWrapper.getSharkConnection(username);

      Map tempMap = new HashMap();

      tempMap.clear();

      RepositoryMgr rm = SharkUtils.getRepositoryManager();
      Map idMap = rm.getPackagePathToIdMapping();

      int itemsPerPage = config.getInt("SharkWebClient."
                                       + ParamConsts.PROPERTY_PREFIX_PACKAGELIST
                                       + ".max.rows.per.page", 5);

      int startAt = Integer.parseInt(from_element != null ? from_element : "0");

      XPDLBrowser ent = SharkInterfaceWrapper.getXPDLBrowser();
      WMEntityIterator ei = ent.listEntities(sc.getSessionHandle(), null, null, true);
      int hm = ei.getCount();
      ArrayList al = new ArrayList();
      al.clear();
      WMEntity[] oo = ei.getArray();
      for (int j = 0; j < hm; j++) {
         WMEntity entemp = oo[j];
         al.add(entemp.getPkgId());
      }

      if (startAt > hm) {
         startAt = (hm / itemsPerPage) * itemsPerPage;

         from_element = Integer.toString(startAt);

      } else if (startAt == hm && hm > 0) {
         startAt = startAt - itemsPerPage;
         from_element = Integer.toString(startAt);
      }

      from_element = Integer.toString(startAt);
      to_element = Integer.toString(startAt + itemsPerPage - 1);
      total_number = Integer.toString(hm);

      WMFilter filter = new WMFilter("Type", WMFilter.EQ, "Package");
      filter.setFilterType(XPDLBrowser.SIMPLE_TYPE_XPDL);

      if (sortCriterion.equalsIgnoreCase("id")) {
         filter.setOrderBy("Id," + this.sortAsc);
      } else if (sortCriterion.equalsIgnoreCase("name")) {
         filter.setOrderBy("Name," + this.sortAsc);
      } else if (sortCriterion.equalsIgnoreCase("version")) {
         filter.setOrderBy("PkgVer," + this.sortAsc);
      }
      filter.setStartPosition(startAt);
      filter.setLimit(itemsPerPage);

      Iterator itk = idMap.entrySet().iterator();
      while (itk.hasNext()) {
         Map.Entry me = (Map.Entry) itk.next();
         String path = (String) me.getKey();
         String pkgId = (String) me.getValue();
         if (!al.contains(pkgId)) {
            path=path.replace('\\', '/');
            tempMap.put(path, pkgId);
         }
      }

      InstanceExtendedAttribute[] iea = null;
      iea = new InstanceExtendedAttribute[tempMap.size()];

      Iterator itm = tempMap.keySet().iterator();
      int i = 0;
      while (itm.hasNext()) {
         InstanceExtendedAttribute ie = InstanceExtendedAttribute.Factory.newInstance();
         Object o = itm.next();
         ie.setName((String) o);
         iea[i] = ie;
         i++;
      }

      Properties props = new Properties();
      String prop = config.getString("SharkWebClient."
                                     + ParamConsts.PROPERTY_PREFIX_PACKAGELIST + "."
                                     + XPILHandler.FILL_PACKAGE_EXT_ATTRIBS, "false");
      props.setProperty(XPILHandler.FILL_PACKAGE_EXT_ATTRIBS, prop);
      Node n = SharkInterfaceWrapper.getXPILHandler().getPackageList(sc.getSessionHandle(),
                                                          filter,
                                                          props);
      sc.disconnect();
      XPILExtendedWorkflowFacilityInstanceDocument tws = XPILExtendedWorkflowFacilityInstanceDocument.Factory.parse(n);

      PackageInstances pis = tws.getExtendedWorkflowFacilityInstance()
         .getPackageInstancesArray(0);
      if (iea.length > 0) {
         pis.addNewInstanceExtendedAttributes().setInstanceExtendedAttributeArray(iea);
      }

      return tws.newDomNode();
   }

}
         } else if (name.equals(SharkConstants.PLUGIN_LOGGING_MANAGER)) {
            return getLoggingManager();
         } else if (name.equals(SharkConstants.PLUGIN_PARTICIPANT_MAPPING)) {
            AssignmentManager am = getAssignmentManager();
            if (am!=null) {
               plugIn=am.getParticipantMapPersistenceManager();
            }
         } else if (name.equals(SharkConstants.PLUGIN_REPOSITORY_PERSISTENCE_MANAGER)) {
            return getRepositoryPersistenceManager();
         } else if (name.equals(SharkConstants.PLUGIN_SCRIPTING_MANAGER)) {
            return getScriptingManager();
         } else if (name.equals(SharkConstants.PLUGIN_SECURITY_MANAGER)) {
            return getSecurityManager();
         } else if (name.equals(SharkConstants.PLUGIN_TOOLAGENT_MANAGER)) {
            return getToolAgentManager();
         } else if (name.equals(SharkConstants.PLUGIN_USER_GROUP)) {
            AssignmentManager am = getAssignmentManager();
            if (am!=null) {
               plugIn=am.getUserGroupManager();
            }
         } else {
            getCallbackUtilities().info(null, "There is no plug-in for name "+name);
         }

      }
      return plugIn;
   }

   // Initialization methods
   // ////////////////////////////////////////////////////////////////

   private static void configureFromJar() {
      String rootDirectoryPath = System.getProperty("user.dir");
      try {
         // URL u=Shark.class.getClassLoader().getResource("Shark.conf.forJar");
         // InputStream is=(InputStream)u.getContent();
         URL u = SharkEngineManager.class.getClassLoader()
            .getResource("Shark.conf.forJar");
         URLConnection urlConnection = u.openConnection();
         InputStream is = urlConnection.getInputStream();

         /* shark */getInstance().properties = new Properties();
         /* shark */getInstance().properties.load(is);
         /* shark */getInstance().properties.put(SharkConstants.ROOT_DIRECTORY_PATH_PROP,
                                                  rootDirectoryPath);
      } catch (Exception ex) {
         throw new RootError("Shark need to be configured properly - Can't read Shark's default configuration from JAR!!!",
                             ex);
      }
   }

   private static void adjustSharkProperties(Properties external) {
      Iterator it = external.entrySet().iterator();
      while (it.hasNext()) {
         Map.Entry me = (Map.Entry) it.next();
         String key = (String) me.getKey();
         String val = (String) me.getValue();
         /* shark */getInstance().properties.setProperty(key, val);
      }
   }

   private void init() {
      long tStart = System.currentTimeMillis();
      System.out.println("SharkEngineManager -> Shark engine is being initialized ...");

      // this is where the singlton class of SharkEngineManager is created
      SharkEngineManager.getInstance().init(properties);

      /* shark */getInstance().initCaches();
      /* shark */getInstance().reevaluateAssignments();

      /*
       * System.setProperty("user.dir",shark .getProperties()
       * .getProperty(SharkConstants.ROOT_DIRECTORY_PATH_PROP));
       */
      long tEnd = System.currentTimeMillis();
      System.out.println("Shark -> shark engine initialization is finished, it lasted "
                         + MiscUtilities.getTimeDiff(tStart, tEnd));
      System.out.println("Shark -> "
                         + properties.getProperty("enginename", "Shark")
                         + " ready and waiting ...");
   }

   // init caches
   private void initCaches() {
      String initPCS = properties.getProperty("Cache.InitProcessCacheString", "");
      String initRCS = properties.getProperty("Cache.InitResourceCacheString", "");
      try {
         if (!initPCS.trim().equals("")) {
            SharkEngineManager.getInstance().getCallbackUtilities().info(null,
                                                                         "Initializing Process cache using string "
                                                                               + initPCS);
            if (initPCS.trim().equalsIgnoreCase(initAllCachesString)) {
               List l = SharkEngineManager.getInstance()
                  .getInstancePersistenceManager()
                  .getAllProcesses(null);
               Iterator it = l.iterator();
               while (it.hasNext()) {
                  ProcessPersistenceObject po = (ProcessPersistenceObject) it.next();
                  // this creates and puts process into cache
                  SharkEngineManager.getInstance().getObjectFactory().createProcess(po);
               }
            } else {
               String[] procIds = MiscUtilities.tokenize(initPCS.trim(),
                                                         initCachesBoundary);
               if (procIds != null) {
                  for (int i = 0; i < procIds.length; i++) {
                     // this gets process from db and puts it into cache
                     Object proc = SharkUtilities.getProcess(null,
                                                             procIds[i],
                                                             SharkUtilities.READ_ONLY_MODE);
                     if (proc == null) {
                        SharkEngineManager.getInstance()
                           .getCallbackUtilities()
                           .info(null,
                                 "Process cache initialization - process with Id="
                                       + procIds[i] + " does not exist");
                     }
                  }
               }
            }
         }

         if (!initRCS.trim().equals("")) {
            SharkEngineManager.getInstance().getCallbackUtilities().info(null,
                                                                         "Initializing Resource cache using string "
                                                                               + initRCS);
            if (initRCS.equalsIgnoreCase(initAllCachesString)) {
               List l = SharkEngineManager.getInstance()
                  .getInstancePersistenceManager()
                  .getAllResources(null);
               Iterator it = l.iterator();
               while (it.hasNext()) {
                  // this creates and puts resources into cache
                  ResourcePersistenceObject po = (ResourcePersistenceObject) it.next();
                  SharkEngineManager.getInstance().getObjectFactory().createResource(po);
               }
            } else {
               String[] resIds = MiscUtilities.tokenize(initRCS.trim(),
                                                        initCachesBoundary);
               if (resIds != null) {
                  for (int i = 0; i < resIds.length; i++) {
                     // this gets resource from db and puts it into cache
                     Object res = SharkUtilities.getResource(null, resIds[i]);
                     if (res == null) {
                        SharkEngineManager.getInstance()
                           .getCallbackUtilities()
                           .info(null,
                                 "Resource cache initialization - resource with username="
                                       + resIds[i] + " does not exist");
                     }
                  }
               }
            }
         }
         SharkUtilities.restorePackages(null);
         // SharkUtilities.commitTransaction(t);
      } catch (Throwable e) {
         SharkEngineManager.getInstance()
            .getCallbackUtilities()
            .error(null, "Problem while initializing caches !!!");
         e.printStackTrace();
         // try {SharkUtilities.rollbackTransaction(t);} catch (Exception ex) {}
      }
   }

   // reevaluate assignments
   private void reevaluateAssignments() {
      boolean reeval = new Boolean(properties.getProperty("Assignments.InitialReevaluation",
                                                          "false")).booleanValue();
      if (!reeval)
         return;
      try {
         SharkUtilities.reevaluateAssignments(null);
      } catch (Throwable e) {
         SharkEngineManager.getInstance()
            .getCallbackUtilities()
            .error(null, "Problem while reevaluating assignments !!!");
      }
   }

}