package com.gargoylesoftware.base.resource;

import com.gargoylesoftware.base.util.DetailedIllegalArgumentException;
import java.util.LinkedList;
import java.util.List;

/**
 *  A resource factory that provides object pooling
 *
 * @version  $Revision: 1.6 $
 * @author <a href="mailto:mbowler@GargoyleSoftware.com">Mike Bowler</a>
 */
public class PooledResourceFactory extends ResourceFactory {

    private final ResourceFactory sourceFactory_;
    private int preferredCacheSize_;
    private List cache_ = new LinkedList();


    /**
     *  Create an instance
     *
     * @param  sourceFactory The factory that will be used to actually create
     *      and destroy the pooled resources
     */
    public PooledResourceFactory( final ResourceFactory sourceFactory ) {
        if( sourceFactory == null ) {
            throw new NullPointerException( "sourceFactory" );
        }
        sourceFactory_ = sourceFactory;
        setPreferredCacheSize( 4 );
    }


    /**
     *  Set the preferredCacheSize
     *
     * @param  size The new size. May not be negative
     */
    public void setPreferredCacheSize( final int size ) {
        if( size < 0 ) {
            throw new DetailedIllegalArgumentException( "size", new Integer(size), "May not be negative" );
        }
        preferredCacheSize_ = size;
    }


    /**
     *  Return the preferredCacheSize
     *
     * @return  The size
     */
    public int getPreferredCacheSize() {
        return preferredCacheSize_;
    }


    /**
     *  Reinitialize the resource to a known state. This is required for
     *  resource pooling as all resources being returned from a pool must have
     *  been initialized to a known state.
     *
     * @param  resource the resource to reinitialize
     * @return  true if the resource was successfully reinitialized
     */
    public synchronized boolean reinitializeResourceIfPossible( final ManagedResource resource ) {
        return sourceFactory_.reinitializeResourceIfPossible( resource );
    }



    /**
     *  Get a resource
     *
     * @param  resourceManager The manager that owns this factory
     * @return  A resource
     * @exception  Exception If an error occurs
     */
    protected synchronized ManagedResource getResourceImpl(
            final ResourceManager resourceManager )
        throws
            Exception {

        ManagedResource resource;

        synchronized( cache_ ) {
            if( cache_.isEmpty() == true ) {
                resource = sourceFactory_.getResource( resourceManager );
            }
            else {
                resource = (ManagedResource)cache_.get( 0 );
                cache_.remove( 0 );
            }
        }

        return resource;
    }


    /**
     *  Release a resource
     *
     * @param  resource The resource to release
     * @param  resourceManager The manager that owns this factory
     * @exception  Exception If an error occurs
     */
    protected synchronized void releaseResourceImpl(
            final ResourceManager resourceManager,
            final ManagedResource resource )
        throws
            Exception {

        synchronized( cache_ ) {
            if( cache_.size() < getPreferredCacheSize()
                     && sourceFactory_.reinitializeResourceIfPossible( resource ) == true ) {
                cache_.add( resource );
            }
            else {
                sourceFactory_.releaseResource( resourceManager, resource );
            }
        }
    }
}
