

extern void freeDatabaseInfo (DatabaseInfo database);

extern DatabaseInfo findOrLoadDatabase (const char *programName,
					const char *databaseName,
					ErrorDesc *err);
extern void clearDbList (void);

extern int databaseSpecIsNetConn (const char *dbName);
extern const char *databaseSpecServer (const char *dbName);
extern const char *databaseSpecPort (const char *dbName);


#endif

struct complex_field_index
{
  DatabaseInfo database;
  char *name;
  enum complex_field_index_datatype dtype;
  union field_list_u {
    Header_Name headerIndex;
    FieldIndex index;
    FieldType fieldType;
  } datum;
  char *admSubfield;
  int isReason;
  int isOldPr;
  int isRaw;
};

struct databaseFieldInfo
{
  FieldDef *fieldList;
  int fieldListSize;
  int lastFieldEnt;
  int *namePosition;
};

static void
insertNewFieldDef (DatabaseInfo database, FieldDef field)
{
  DatabaseFieldInfo *dinfoPtr = getDatabaseFieldInfoWrite (database);
  DatabaseFieldInfo dinfo = *dinfoPtr;

  field->database = database;
  if (dinfoPtr == NULL)
    {
      abort ();
    }
  if (dinfo == NULL)
    {
      dinfo = (*dinfoPtr = 
	       (DatabaseFieldInfo) 
	       xmalloc (sizeof (struct databaseFieldInfo)));
      dinfo->fieldList = (FieldDef *) xmalloc (sizeof (FieldDef) * 10);
      dinfo->namePosition = (int *) xmalloc (sizeof (int) * 10);
      dinfo->fieldListSize = 10;
      dinfo->lastFieldEnt = 0;
    }
  else if (dinfo->lastFieldEnt >= dinfo->fieldListSize)
    {
      dinfo->fieldListSize += 10;
      dinfo->fieldList = 
	(FieldDef *) xrealloc (dinfo->fieldList,
			       sizeof (FieldDef) * dinfo->fieldListSize);
      dinfo->namePosition =
	(int *) xrealloc (dinfo->namePosition,
			  sizeof (int) * dinfo->fieldListSize);
    }
  field->number = dinfo->lastFieldEnt;
  dinfo->fieldList[dinfo->lastFieldEnt] = field;

  {
    int x, y;

    for (x = 0; x < dinfo->lastFieldEnt; x++)
      {
	char *name = dinfo->fieldList[dinfo->namePosition[x]]->name;
	if (strcasecmp (name, field->name) > 0)
	  {
	    break;
	  }
      }
    for (y = dinfo->lastFieldEnt - 1; y >= x; y--)
      {
	dinfo->namePosition[y + 1] = dinfo->namePosition[y];
      }
    dinfo->namePosition[x] = dinfo->lastFieldEnt;
    dinfo->lastFieldEnt++;
  }
}
static ComplexFieldIndex
allocComplexFieldIndex (void)
{
  ComplexFieldIndex res;

  if (emptyEnt != NULL)
    {
      res = emptyEnt;
      emptyEnt = NULL;
    }
  else
    {
      res = (ComplexFieldIndex) xmalloc (sizeof (struct complex_field_index));
    }
  return res;
}


void
freeFieldList (FieldList list)
{
  FieldList n;
  while (list != NULL)
    {
      n = list->next;
      freeComplexFieldIndex (list->ent);
      free (list);
      list = n;
    }
}

void
freeFieldEdit (FieldEdit *edit)
{
  FieldEdit *n;
  while (edit != NULL)
    {
      n = edit->next;
      if (edit->fieldToEditName != NULL)
	{
	  free (edit->fieldToEditName);
	}
      if (edit->textFormat != NULL)
	{
	  free (edit->textFormat);
	}
      freeFieldList (edit->fieldsForFormat);
      free (edit);
      edit = n;
    }
}

void
clearFieldList (DatabaseInfo database)
{
  DatabaseFieldInfo *dinfoPtr = getDatabaseFieldInfoWrite (database);
  if (dinfoPtr != NULL && *dinfoPtr != NULL)
    {
      DatabaseFieldInfo dinfo = *dinfoPtr;
      int x;

      for (x = 0; x < dinfo->lastFieldEnt; x++)
	{
	  freeFieldDef (dinfo->fieldList[x]);
	}
      free (dinfo->fieldList);
      dinfo->fieldList = NULL;
      dinfo->fieldListSize = 0;
      dinfo->lastFieldEnt = 0;
      if (dinfo->namePosition != NULL)
	{
	  free (dinfo->namePosition);
	  dinfo->namePosition = NULL;
	}
      free (dinfo);
      *dinfoPtr = NULL;
    }
}


FieldDef
newFieldDef (DatabaseInfo database, char *name)
{
  if (find_field_index (database, name) == InvalidFieldIndex)
    {
      FieldDef res =  (FieldDef) xmalloc (sizeof (struct field_def));
      memset (res, 0, sizeof (struct field_def));
      res->name = name;
      insertNewFieldDef (database, res);
      return res;
    }
  else
    {
      return NULL;
    }
}
