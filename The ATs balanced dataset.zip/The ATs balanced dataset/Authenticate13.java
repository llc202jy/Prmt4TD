public AuthenticationStatus authenticate(int method, String mechanism, String security_name, //user name
	byte[] auth_data, //  passwd
	SecAttribute[] privileges, CredentialsHolder creds, OpaqueHolder continuation_data, OpaqueHolder auth_specific_data) {
		jacorb.util.Debug.output(3, "starting authentication");
		try {
			registerProvider();
			loginData.alias = security_name;
			if (auth_data == null) {
				loginData.password = null;
			} else {
				loginData.password = new String(auth_data);
			}

			//            LoginWindow lw = null; // for user login
			//              if (( loginData.keyStoreLocation == null ) ||
			//                  ( loginData.storePassphrase == null ) ||
			//                  ( loginData.alias == null ) ||
			//                  ( loginData.password == null ))
			//              {
			//                     lw = new LoginWindow(
			//                                        "Login",
			//                                        loginData,
			//                                        loginData.keyStoreLocation,
			//                                        loginData.storePassphrase,
			//                                        loginData.alias,
			//                                        loginData.password );
			//              }
			//              lw.finalize();


			try {
				if (loginData.keyStoreLocation == null) {
					System.out.print("Please enter key store file name: ");
					loginData.keyStoreLocation = (new BufferedReader(new InputStreamReader(System.in))).readLine();
				}
				if (loginData.storePassphrase == null) {
					System.out.print("Please enter store pass phrase: ");
					loginData.storePassphrase = (new BufferedReader(new InputStreamReader(System.in))).readLine();
				}
				if (loginData.alias == null) {
					System.out.print("Please enter alias  name: ");
					loginData.alias = (new BufferedReader(new InputStreamReader(System.in))).readLine();
				}
				if (loginData.password == null) {
					System.out.print("Please enter password: ");
					loginData.password = (new BufferedReader(new InputStreamReader(System.in))).readLine();
				}
			} catch (Exception e) {
			}
			if ((loginData.keyStoreLocation == null) || (loginData.storePassphrase == null) || (loginData.alias == null) || (loginData.password == null)) {
				return AuthenticationStatus.SecAuthFailure;
			}
			keyStore = KeyStoreUtil.getKeyStore(loginData.keyStoreLocation, loginData.storePassphrase.toCharArray());
			X509Certificate[] cert_chain = (X509Certificate[]) keyStore.getCertificateChain(loginData.alias);
			PrivateKey priv_key = (PrivateKey) keyStore.getKey(loginData.alias, loginData.password.toCharArray());
			KeyAndCert k_a_c = new KeyAndCert(priv_key, cert_chain);
			AttributeType type = new AttributeType(new ExtensibleFamily((short) 0, (short) 1), AccessId.value);


			//only considering AccessId attributes
			for (int i = 0; i < privileges.length; i++) {
				if (privileges[i].attribute_type.attribute_family.family_definer != 0 || privileges[i].attribute_type.attribute_family.family != 1 || privileges[i].attribute_type.attribute_type != AccessId.value) {
					throw new RuntimeException("Cannot handle security attribute.");
				}
				privileges[i] = attrib_mgr.createCertAttribute(k_a_c, type);
			}
			CredentialsImpl credsImpl = new CredentialsImpl(privileges, AuthenticationStatus.SecAuthSuccess, InvocationCredentialsType.SecOwnCredentials);
			credsImpl.accepting_options_supported(Environment.supportedBySSL());
			credsImpl.accepting_options_required(Environment.requiredBySSL());
			credsImpl.invocation_options_supported(Environment.supportedBySSL());
			credsImpl.invocation_options_required(Environment.requiredBySSL());
			creds.value = credsImpl;
			jacorb.util.Debug.output(3, "authentication succeeded");
			return AuthenticationStatus.SecAuthSuccess;
		} catch (Exception e) {
			jacorb.util.Debug.output(2, e);
			return Org.omg.Security.AuthenticationStatus.SecAuthFailure;
		}
	}
	public AuthenticationStatus authenticate(int method, String mechanism, String security_name, //user name
	byte[] auth_data, //  passwd
	SecAttribute[] privileges, CredentialsHolder creds, OpaqueHolder continuation_data, OpaqueHolder auth_specific_data) {
		jacorb.util.Debug.output(3, "starting authentication");
		try {
			registerProvider();
			loginData.alias = security_name;
			if (auth_data == null) {
				loginData.password = null;
			} else {
				loginData.password = new String(auth_data);
			}

			//            LoginWindow lw = null; // for user login
			//              if (( loginData.keyStoreLocation == null ) ||
			//                  ( loginData.storePassphrase == null ) ||
			//                  ( loginData.alias == null ) ||
			//                  ( loginData.password == null ))
			//              {
			//                     lw = new LoginWindow(
			//                                        "Login",
			//                                        loginData,
			//                                        loginData.keyStoreLocation,
			//                                        loginData.storePassphrase,
			//                                        loginData.alias,
			//                                        loginData.password );
			//              }
			//              lw.finalize();


			try {
				if (loginData.keyStoreLocation == null) {
					System.out.print("Please enter key store file name: ");
					loginData.keyStoreLocation = (new BufferedReader(new InputStreamReader(System.in))).readLine();
				}
				if (loginData.storePassphrase == null) {
					System.out.print("Please enter store pass phrase: ");
					loginData.storePassphrase = (new BufferedReader(new InputStreamReader(System.in))).readLine();
				}
				if (loginData.alias == null) {
					System.out.print("Please enter alias  name: ");
					loginData.alias = (new BufferedReader(new InputStreamReader(System.in))).readLine();
				}
				if (loginData.password == null) {
					System.out.print("Please enter password: ");
					loginData.password = (new BufferedReader(new InputStreamReader(System.in))).readLine();
				}
			} catch (Exception e) {
			}
			if ((loginData.keyStoreLocation == null) || (loginData.storePassphrase == null) || (loginData.alias == null) || (loginData.password == null)) {
				return AuthenticationStatus.SecAuthFailure;
			}
			keyStore = KeyStoreUtil.getKeyStore(loginData.keyStoreLocation, loginData.storePassphrase.toCharArray());
			X509Certificate[] cert_chain = (X509Certificate[]) keyStore.getCertificateChain(loginData.alias);
			PrivateKey priv_key = (PrivateKey) keyStore.getKey(loginData.alias, loginData.password.toCharArray());
			KeyAndCert k_a_c = new KeyAndCert(priv_key, cert_chain);
			AttributeType type = new AttributeType(new ExtensibleFamily((short) 0, (short) 1), AccessId.value);


			//only considering AccessId attributes
			for (int i = 0; i < privileges.length; i++) {
				if (privileges[i].attribute_type.attribute_family.family_definer != 0 || privileges[i].attribute_type.attribute_family.family != 1 || privileges[i].attribute_type.attribute_type != AccessId.value) {
					throw new RuntimeException("Cannot handle security attribute.");
				}
				privileges[i] = attrib_mgr.createCertAttribute(k_a_c, type);
			}
			CredentialsImpl credsImpl = new CredentialsImpl(privileges, AuthenticationStatus.SecAuthSuccess, InvocationCredentialsType.SecOwnCredentials);
			credsImpl.accepting_options_supported(Environment.supportedBySSL());
			credsImpl.accepting_options_required(Environment.requiredBySSL());
			credsImpl.invocation_options_supported(Environment.supportedBySSL());
			credsImpl.invocation_options_required(Environment.requiredBySSL());
			creds.value = credsImpl;
			jacorb.util.Debug.output(3, "authentication succeeded");
			return AuthenticationStatus.SecAuthSuccess;
		} catch (Exception e) {
			jacorb.util.Debug.output(2, e);
			return Org.omg.Security.AuthenticationStatus.SecAuthFailure;
		}
	}


