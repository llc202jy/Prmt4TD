package osid.dbc;

public interface ResultSetMetaData
extends java.io.Serializable
{
    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    int columnNoNulls = 0;
    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    int columnNullable = 1;
    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    int columnNullableUnknown = 2;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    int getColumnCount()
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    boolean isAutoIncrement(int column)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    boolean isCaseSensitive(int column)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    boolean isSearchable(int column)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    boolean isCurrency(int column)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    int isNullable(int column)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    boolean isSigned(int column)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    int getColumnDisplaySize(int column)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    String getColumnLabel(int column)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    String getColumnName(int column)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    String getSchemaName(int column)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    int getPrecision(int column)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    int getScale(int column)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    String getTableName(int column)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    String getCatalogName(int column)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    int getColumnType(int column)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    String getColumnTypeName(int column)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    boolean isReadOnly(int column)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    boolean isWritable(int column)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    boolean isDefinitelyWritable(int column)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    String getColumnClassName(int column)
    throws osid.dbc.DbcException;
// oki.SidLicense
    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setPassword(String password)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setQueryTimeout(int seconds)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setReadOnly(boolean value)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setRef(int parameterIndex
              , java.sql.Ref param)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setShort(int parameterIndex
                , short param)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setString(int parameterIndex
                 , String param)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setTime(int parameterIndex
               , java.sql.Time param)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setTime(int parameterIndex
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setType(int type)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setTypeMap(java.util.Map typeMap)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setUrl(String url)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setUsername(String name)
    throws osid.dbc.DbcException;
// oki.SidLicense
}
