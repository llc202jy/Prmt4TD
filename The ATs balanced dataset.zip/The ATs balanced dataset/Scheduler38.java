
public final class Timer implements java.io.Serializable {
   private final Scheduler sched;
   private final Integer handle;
   private boolean running;
   private ArrayList tasks;
   private final class TimedTask implements java.io.Serializable {
      private final Object task;
      private final long interval;
      private int count;
      private long time;
      private TimedTask(Object task, Long interval, Integer count) {
         this.task     = task;
         this.interval = interval.longValue();
         this.count    = count.intValue();
         this.time     = System.currentTimeMillis() + this.interval;
      }
      private void drop() {
         tasks.remove(tasks.indexOf((this)));
         if (tasks.isEmpty()) {
            tasks = null;
            if (running) {
               running = false;
               sched.stop(handle);
            }
         }
      }
   }
   /**
    * The constructor loads the timer into the Scheduler, but does not yet
    * start it running.  It will start itself automatically, when a task is
    * loaded, and will stop itself similarly, when it has no tasks to run.
    * @param sched The scheduler to use for execution.* This method loads a task for timed execution. If the timer object is not
    * currently running in its Scheduler, it will be started automatically.
    * Naturally, the task object must implement a public void slice() method.
    * &lt;i&gt;Note:&lt;/i&gt; the task will delay a full interval before its first
    * execution. If an ititial execution is required, it must be done manually.
    * @param task The operation to be timed, it can be local, remote, or even
    * a proxy, when enabled.
    * @param interval The time between execution, in milliseconds
    * @param count The number of times to run before removal, a count of zero
    * indicates to run indefinitely, or until removed
    */
   public synchronized void load(Object task, Long interval, Integer count) {
      if (tasks == null) tasks = new ArrayList();
      tasks.add(new TimedTask(task, interval, count));
      if (!running) {
         running = true;
         sched.wake(handle);
      }
   }
    public Timer(Scheduler sched) {
      this.sched = sched;
      handle = sched.load(this);
   }
   /**
    * This method loads a task for timed execution. If the timer object is not
    * currently running in its Scheduler, it will be started automatically.
    * Naturally, the task object must implement a public void slice() method.
    * &lt;i&gt;Note:&lt;/i&gt; the task will delay a full interval before its first
    * execution. If an ititial execution is required, it must be done manually.
    * @param task The operation to be timed, it can be local, remote, or even
    * a proxy, when enabled.
    * @param interval The time between execution, in milliseconds
    * @param count The number of times to run before removal, a count of zero
    * indicates to run indefinitely, or until removed
    */ The timer task implementation itself, invoked by the scheduler.  This
    * method will scan the scheduled tasks for timeout, indicating readiness
    * for execution.  Additionally it will decrement the task's count, when
    * applicable, and remove the task when the count reaches zero.  When the
    * task list becomes empty, it will suspend itself as a scheduled task,
    * until a new task is loaded. If several tasks are eligible for execution
    * in any given slice, only one eligible task will be run, to improve
    * scheduler responsiveness. If the execution of the task slice results in
    * an exception, the task will be automatically dropped from the queue.
    */
   public void slice() {
      TimedTask tt = null;
      synchronized(this) {
         long time = System.currentTimeMillis();
         for (int i = 0; i &lt; tasks.size(); i++) {
            TimedTask task = (TimedTask)tasks.get(i);
            if (time &gt;= task.time) {
               if (task.count != 0 &amp;&amp; --task.count == 0) task.drop();
               else task.time += task.interval;
               tt = task;
               break;
            }
         }
      }
      if (tt != null) try { Remote.invoke(tt.task, &quot;slice&quot;, null); }
      catch(Exception x)  { synchronized(this) { tt.drop(); } }
   }
}
public final class Scheduler implements Serializable {
   private static final String
      INDEX_INVALID = "task table index invalid";
   private transient Thread thread;
   private int syncFlags, soonFlags, wakeFlags;
   private Object list[] = new Object[32];
   private void readObject(ObjectInputStream in)
      throws IOException, ClassNotFoundException {
      in.defaultReadObject();
      setEnabled(true);
   }
   private final Runnable kernel = new Runnable() {
      public void run() {
         try {
            int next = 0;
            while (!thread.isInterrupted()) {
               int slot = 0;
               synchronized(Scheduler.this) {
                  if (syncFlags != 0) {
                     int mask = 1;
                     while((syncFlags & mask) == 0) {
                        slot++;
                        mask <<= 1;
                     }
                     syncFlags ^= mask;
                  } else if (soonFlags != 0) {
                     int mask = 1;
                     while((soonFlags & mask) == 0) {
                        slot++;
                        mask <<= 1;
                     }
                     soonFlags ^= mask;
                  } else if (wakeFlags != 0) {
                     for (int i = 0; i < 32; i++) {
                        if (++next == 32) next = 0;
                        if ((1 << next & wakeFlags) != 0) {
                           slot = next;
                           break;
                        }
                     }
                  } else {
                     Scheduler.this.wait();
                     continue;
                  }
               }
               try { Remote.invoke(list[slot], "slice", null); }
               catch(Exception x) { drop(slot); }
           }
         } catch(InterruptedException x) {}
      }
   };
   /**
    * Nothing is performed in the constructor, since no tasks can be
    * scheduled for execution until they have been loaded.
    */
   public Scheduler() {}
   /**
    * This method will start, or suspend, the scheduler.  The scheduler will
    * be started automatically when the first task is flagged for execution.
    * The method is idempotent; therefore enabling an already enabled
    * scheduler will cause no effect, just as disabling a currently disabled
    * scheduler.
    * @param enabled The flag to indicate if this is a startup, or suspend
    * operation.
    * @return true if successfully started or stopped, false if not for
    * logical reasons, i.e. already stopped/started, no tasks running.
    */
   public synchronized boolean setEnabled(boolean enabled) {
      if (enabled) {
         if (syncFlags != 0 | soonFlags != 0 | wakeFlags != 0) {
            if (thread == null) {
               thread = new Thread(kernel);
               thread.start();
               return true;
            } else notify();
         }
      } else {
         if (thread != null) {
            thread.interrupt();
            thread = null;
            return true;
         }
      }
      return false;
   }