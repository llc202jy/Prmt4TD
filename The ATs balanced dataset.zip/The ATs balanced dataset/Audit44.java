package com.oncecorp.visa3d.bridge.auditing;

import com.oncecorp.visa3d.bridge.beans.AuditingListenerBean;
import com.oncecorp.visa3d.bridge.beans.AuditingServiceBean;
import com.oncecorp.visa3d.bridge.beans.BeansHelper;
import com.oncecorp.visa3d.bridge.beans.MerchantInfoBean;
import com.oncecorp.visa3d.bridge.configure.ConfigurationManager;
import com.oncecorp.visa3d.bridge.monitoring.AuditingMBean;
import com.oncecorp.visa3d.bridge.listening.ListeningManager;
import com.oncecorp.visa3d.bridge.listening.ListeningUtils;
import com.oncecorp.visa3d.bridge.logging.DataBridgeLoger;
import org.apache.log4j.Logger;

/**
 * <p>Title: ONCE MPI Data Bridge</p>
 * <p>Description: This is the MBean class for updating the auditing config.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Once Corporation</p>
 * @author yge@oncecorp.com
 * @version 1.0
 */

public class Auditing implements AuditingMBean {

  private static final Logger  log4j = DataBridgeLoger.getLogger(Auditing.class);

  /**
   * The default constructor.
   */
  public Auditing() {
  }

  /**
   * This method returns the auditing server xml string.
   * @return The auditing server xml string.
   */
  public String obtainAuditingServerXml() {
    return AuditingManager.getInstance().getBean().toXml();
  }
  /**
   * This method sets the auditing server xml string.
   * @param xml The auditing server xml string.
   */
  public void putAuditingServerXml(String xml) {
    AuditingServiceBean updateBean = BeansHelper.auditingServiceFromXml(null, xml);
    if ( updateBean != null && AuditingManager.getInstance().update(updateBean) ) {
      ListeningManager.getInstance().resetAuditingListeners( updateBean.getListeners() );
      if ( ConfigurationManager.getInstance().isAutoSave() ) {
        ConfigurationManager.getInstance().save();
      }
    }
  }

  /**
   * This method add new auditing logger object to the auditing service.
   * @param xml The xml string that contains the new logger data.
   */
  public void addAuditingLogger(String xml) {
    AuditingListenerBean bean = BeansHelper.auditingListenerFromXml(null, xml);
    if ( bean != null ) {
      log4j.debug("bean != null");
      addAuditingLogger(bean);
    }
    else {
      log4j.debug("bean == null");
    }
  }

  void addAuditingLogger(AuditingListenerBean bean) {
    if ( AuditingManager.getInstance().addAuditingLogger(bean) ) {
      log4j.debug("logger added -- " + bean.getId());
      /**
       * The following Added by Gang Wu:
       * bean is the AuditingListenerBean
       * It should be called after Auditing manager add
       */
      ListeningManager.getInstance().addAuditingListener( bean );
      /**
       * Add finish
       */
      if ( ConfigurationManager.getInstance().isAutoSave() ) {
        ConfigurationManager.getInstance().save();
      }
    }
  }

  /**
   * This method removes a auditing logger from the auditing server.
   * @param loggerId The logger id.
   */
  public void removeAuditingLogger(String loggerId) {
    if ( AuditingManager.getInstance().containsLogger(loggerId) ) {
      log4j.debug("logger removed -- " + loggerId);
      /**
       * The following Added by Gang Wu:
       * bean is the AuditingListenerBean
       * It should be called before Auditing manager remove
       */
      ListeningManager.getInstance().unregisterListener(
              ListeningUtils.AUDITING_LISTENER, loggerId );
      /**
       * Add finish
       */
      // This method was called by ListeningManager.unregisterListener().
      //AuditingManager.getInstance().removeAuditingLogger(loggerId);

      if ( ConfigurationManager.getInstance().isAutoSave() ) {
        ConfigurationManager.getInstance().save();
      }
    }
  }

  /**
   * This method updates the existed logger.
   * @param xml The xml that contains the logger data.
   */
  public void updateAuditingLogger(String xml) {
    AuditingListenerBean bean = BeansHelper.auditingListenerFromXml(null, xml);
    if ( bean != null ) {
      log4j.debug("bean != null");
      updateAuditingLogger(bean);
    }
    else {
      log4j.debug("bean == null");
    }
  }

  void updateAuditingLogger(AuditingListenerBean bean) {
    if ( !AuditingManager.getInstance().containsLogger(bean.getId()) ) {
      log4j.error("The auditing logger does not exsit.");
      return;
    }
    log4j.debug("do update logger -- " + bean.getId());
    if ( AuditingManager.getInstance().updateAuditingLogger(bean) ) {
      log4j.debug("logger updated -- " + bean.getId());
      /**
       * The following Added by Gang Wu:
       * bean is the AuditingListenerBean
       * It should be called after Auditing manager update
       */
      ListeningManager.getInstance().updateAuditingListener(bean);
      /**
       * Add finish
       */
      if ( ConfigurationManager.getInstance().isAutoSave() ) {
        ConfigurationManager.getInstance().save();
      }
    }
  }

  /**
   * This method returns the particluar logger's mail subject text.
   * @param loggerId The logger id.
   * @return The subject text.
   */
  public String obtainSubjectText(String loggerId) {
    return AuditingManager.getInstance().getLogger(loggerId).getSubject();
  }
  /**
   * This method sets the the particular logger's subject text.
   * @param loggerId The logger id.
   * @param text The subject text.
   */
  public void putSubjectText(String loggerId, String text) {
    AuditingLogger logger = AuditingManager.getInstance().getLogger(loggerId);
    if ( logger != null && !logger.getSubject().equals(text) ) {
      AuditingManager.getInstance().getLogger(loggerId).setSubject(text);
      logger.saveMailTemplate();
    }
  }

  /**
   * This method returns the particular logger's mail body template text.
   * @param loggerId The logger id.
   * @return The body template text.
   */
  public String obtainBodyTemplateText(String loggerId) {
    return AuditingManager.getInstance().getLogger(loggerId).getBody();
  }

  /**
   * This method sets the particular logger's mail body template text.
   * @param loggerId loggerId The logger id.
   * @param text The body template text.
   */
  public void putBodyTemplateText(String loggerId, String text) {
    AuditingLogger logger = AuditingManager.getInstance().getLogger(loggerId);
    if ( logger != null && !logger.getBody().equals(text) ) {
      AuditingManager.getInstance().getLogger(loggerId).setBody(text);
      logger.saveMailTemplate();
    }
  }

  /**
   * This method returns the current record number of the particular logger and
   * particular message type (table).
   * @param merchantId The merchant id.
   * @return The current record number in the database table.
   */
  public int obtainCurrentNumber(String merchantId) {
    //MerchantInfoBean bean = AuditingManager.getInstance().getMerchantInfoBean(merchantId)
    //AuditingLogger logger = AuditingManager.getInstance().getLogger(loggerId);
    //if ( logger == null ) {
    //  return -1;
    //}
    //return logger.getCurrentRecordNumber(AuditingUtils.getMessageTypeIndex(messageType));
    return AuditingManager.getInstance().getCurrentRecordNumber(
      AuditingManager.getInstance().getMerchantInfoBean(merchantId)  );
  }

  /**
   * This method sets the SMTP name.
   * @param smtpName Tne SMTP name.
   */
  public void putMailInet(String smtpName) {
    String oldValue = AuditingManager.getInstance().getBean().getMailInet();
    if ( !oldValue.equals(smtpName) && smtpName != null ) {
      AuditingManager.getInstance().getBean().setMailInet(smtpName);
      if ( ConfigurationManager.getInstance().isAutoSave() ) {
        ConfigurationManager.getInstance().save();
      }
    }
  }

  /**
   * This method sets the the performance counter sampling time.
   * @param samplingTime The sampling time.
   */
  public void putSamplingTime(int samplingTime) {
    long oldValue = AuditingManager.getInstance().getBean().getSamplingTime();
    if ( oldValue != samplingTime && samplingTime > 0 ) {
      AuditingManager.getInstance().getBean().setSamplingTime(samplingTime);
      if ( ConfigurationManager.getInstance().isAutoSave() ) {
        ConfigurationManager.getInstance().save();
      }
    }
  }

  /**
   * This method starts the particular auditing logger.
   * @param loggerId The logger id.
   * @param reason - stop reason
   */
  public void start(String loggerId, String reason) {

      /**
      * The following Added by Gang Wu:
      * bean is the AuditingListenerBean
      * It should be called before Auditing manager remove
      */
      ListeningManager.getInstance().startListener(
               ListeningUtils.AUDITING_LISTENER, loggerId, reason);
     /**
      * Add finish
      */
  }

  /**
   * This method stops the particular auditing logger.
   * @param loggerId The logger id.
   * @param reason - stop reason
   */
  public void stop(String loggerId, String reason) {
     /**
      * The following Added by Gang Wu:
      * bean is the AuditingListenerBean
      * It should be called before Auditing manager remove
      */
      ListeningManager.getInstance().stopListener(
              ListeningUtils.AUDITING_LISTENER, loggerId, reason);
     /**
      * Add finish
      */
  }

  /**
   * This method returns the auditing status.
   * @return The auditing status string.
   */
  public String obtainStatus(String loggerId) {
    return ListeningManager.getInstance().getListenerStatus(
			ListeningUtils.AUDITING_LISTENER, loggerId);
  }

  /**
   * This method reset the current number of the auditing logger database table.
   * @param loggerId The auditing status string.
   */
  public void initCurrentNumber(String jndi, String schema) {
	  /**
	   *[Gang Wu's Note: June 19, 2003] This method useless
	   */
    //AuditingManager.getInstance().initCurrentNumber(jndi, schema);
  }

  /**
   * This method remove data source from the application server.
   * (This method is used for doing test and debug.)
   * @param jndi The jndi name.
   */
  public void removeDataSource(String jndi) {
    AuditingManager.getInstance().removeDataSource(jndi);
  }

  /**
   * Obtain the start stop reason
   * @param loggerId - the the loger handler id
   */
  public String obtainStartStopReason( String loggerId )
  {
	  return ListeningManager.getInstance().getStartStopReason(
			  ListeningUtils.AUDITING_LISTENER, loggerId );
  }

  /**
   * Obtain the start stop time
   * @param loggerId - the the loger handler id
   */
  public long obtainStartStopTime(  String loggerId )
  {
	  return ListeningManager.getInstance().getStartStopTime(
			  ListeningUtils.AUDITING_LISTENER, loggerId );
  }


}
package com.oncecorp.visa3d.bridge.configure;

import org.w3c.dom.Document;
import org.apache.log4j.Logger;

import com.oncecorp.visa3d.bridge.auditing.AuditingManager;
import com.oncecorp.visa3d.bridge.beans.AuditingServiceBean;
import com.oncecorp.visa3d.bridge.listening.ListeningManager;
import com.oncecorp.visa3d.bridge.logging.DataBridgeLoger;
import com.oncecorp.visa3d.bridge.beans.DataBridgeBean;


/**
 * <p>Title: Auditing Config </p>
 * <p>Description: Implement Configurable interface, configure the auditing service</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: ONCE Corporation</p>
 * @author Gang Wu ( gwu@oncecorp.com)
 * @version 1.0
 */

public class AuditingConfig implements Configurable
{

    private static Logger m_logger = DataBridgeLoger.getLogger(
            AuditingConfig.class.getName() );

    /**
     * Default Constructor
     */
    public AuditingConfig()
    {
    }

    /**
     * Configure Interface
     * @param root - the new databridge bean
     */
    public void config( DataBridgeBean root )
    {
        m_logger.debug("Enter config");
        AuditingServiceBean bean = root.getAuditingService();
        //AuditingServiceBean oldBean = AuditingManager.getInstance().getBean();
        AuditingManager.getInstance().setBean(bean);
        ListeningManager.getInstance().resetAuditingListeners( bean.getListeners() );
        //ListeningManager.getInstance().resetAuditingListeners(
        //  AuditingManager.getInstance().getBean().getListeners()
        //);
        m_logger.debug("Exit config");
    }

}
package com.oncecorp.visa3d.bridge.listening;

import java.util.Collections;
import java.util.Map;
import java.util.ArrayList;
import java.util.Iterator;

import javax.jms.Message;
import javax.jms.TextMessage;

import org.w3c.dom.Document;
import org.apache.log4j.Logger;
import com.oncecorp.visa3d.bridge.logging.DataBridgeLoger;
import com.oncecorp.visa3d.bridge.beans.AuditingListenerBean;
import com.oncecorp.visa3d.bridge.auditing.AuditingManager;
import com.oncecorp.visa3d.bridge.utility.Utils;

/**
 * <p>Title: AuditingMessageReceiver </p>
 * <p>Description: Inherit from ListeningThread and call auditing handler</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: ONCE Corporation</p>
 * @author Gang Wu ( gwu@oncecorp.com )
 * @version 1.0
 */

public class AuditingMessageReceiver extends ListeningThread
{

    private static Logger m_logger = DataBridgeLoger.getLogger(
            AuditingMessageReceiver.class.getName() );

    private AuditingListenerBean m_bean = null;

    /**
     * Constructor with the channel identify
     * @param channel - channel identify
     */
    public AuditingMessageReceiver( AuditingListenerBean bean )
    {
        m_logger.debug("Enter Constructor AuditingMessageReceiver");

        if ( bean == null )
        {
            m_logger.error("Empty AuditingListenerBean" );
            setStatus( Utils.LISTENING_EXCEPTION );
            return;
        }

        m_bean = bean;
        super.init( ListeningUtils.AUDITING_LISTENER, bean.getId(), bean.getStatus() );

        setMerchantIDs( bean.getMerchantIds() );
        setMessagesMap( bean.getMessages() );

        m_plugin = (MPIMessageListener)AuditingManager.getInstance().getLogger( m_bean.getId() );
        if ( m_plugin == null )
        {
            m_logger.error("Can't find auditing logger [" + m_bean.getId() + "]" );
            setStatus( Utils.LISTENING_EXCEPTION );
        }
        else
            m_logger.debug("get logger [" + m_bean.getId() + "] from AuditingManager" );

        m_logger.debug("Exit Constructor AuditingMessageReceiver");

    }

    /**
     * Check and decide whether the bean is any different with the old one and if
     * it is different, do the reset action.
     * @param bean - auditing listener bean contains new configuration data.
     */
    public void reset( AuditingListenerBean bean )
    {
        m_logger.debug("Enter reset of AuditingMessageReceiver.");
        boolean notChangeFilter = ListeningUtils.merchantListEqual(
                bean.getMerchantIds(), m_merchantIDs ) &&
             ListeningUtils.messageMapEqual( bean.getMessages(),
                m_messages, false );

        String status = m_bean.getStatus();

        m_logger.debug("Stop auditing listener first.");
        super.stop();

        if ( !notChangeFilter )
        {
            setMerchantIDs( bean.getMerchantIds() );
            super.changeFilter();
        }

        setMessagesMap( bean.getMessages() );
        m_bean = bean;
        setStatus( status );
        m_plugin = (MPIMessageListener)AuditingManager.getInstance().getLogger( m_bean.getId() );

        if ( !ListeningUtils.isStopAction( status ) )
            super.start();

        m_logger.debug("Exit reset of AuditingMessageReceiver.");
    }

    /**
     *
     * @param status - Auditing message bean status
     */
    protected void setAuditingListenerBeanStatus( String status )
    {
        m_bean.setStatus( status );
    }
}
package com.oncecorp.visa3d.bridge.auditing;

import com.oncecorp.visa3d.bridge.utility.DataBridgeRuntimeException;
/**
 * Title:        ONCE MPI Data Bridge
 * Description:  This exception class handle all exception occurs in the
 * auditing service.  It can ecapsulate the other exception which originally
 * happen.
 * Copyright:    Copyright (c) 2002
 * Company:      Once Corporation
 * @author yge@oncecorp.com
 * @version 1.0
 */

public class AuditingException extends DataBridgeRuntimeException {

  /**
   * The default constructor.
   */
  public AuditingException() {
  }

  /**
   * The constructor of the class.
   * @param s The detail message.
   */
  public AuditingException(String s) {
    super(s);
  }

  /**
   * The constructor of the class.
   * @param throwable The encapsulated throwable.
   */
  public AuditingException(Throwable throwable) {
    super(throwable);
  }

  /**
   * The constructor of the class.
   * @param s The detail message.
   * @param throwable The encapsulated throwable.
   */
  public AuditingException(String s, Throwable throwable) {
    super(s, throwable);
  }
}
package com.oncecorp.visa3d.bridge.monitoring;

/**
 * <p>Title: ONCE MPI Data Bridge</p>
 * <p>Description: This is the MBean interface for dynamically configuring the
 * auditing service.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Once Corporation</p>
 * @author yge@oncecorp.com
 * @version 1.0
 */

public interface AuditingMBean {

  /**
   * This method returns the auditing server xml string.
   * @return The auditing server xml string.
   */
  public String obtainAuditingServerXml();
  /**
   * This method sets the auditing server xml string.
   * @param xml The auditing server xml string.
   */
  public void putAuditingServerXml(String xml);

  /**
   * This method add new auditing logger object to the auditing service.
   * @param xml The xml string that contains the new logger data.
   */
  public void addAuditingLogger(String xml);
  /**
   * This method removes a auditing logger from the auditing server.
   * @param loggerId The logger id.
   */
  public void removeAuditingLogger(String loggerId);

  /**
   * This method updates the existed logger.
   * @param xml The xml that contains the logger data.
   */
  public void updateAuditingLogger(String xml);

  /**
   * This method returns the particluar logger's mail subject text.
   * @param loggerId The logger id.
   * @return The subject text.
   */
  public String obtainSubjectText(String loggerId);
  /**
   * This method sets the the particular logger's subject text.
   * @param loggerId The logger id.
   * @param text The subject text.
   */
  public void putSubjectText(String loggerId, String text);

  /**
   * This method returns the particular logger's mail body template text.
   * @param loggerId The logger id.
   * @return The body template text.
   */
  public String obtainBodyTemplateText(String loggerId);
  /**
   * This method sets the particular logger's mail body template text.
   * @param loggerId loggerId The logger id.
   * @param text The body template text.
   */
  public void putBodyTemplateText(String loggerId, String text);

  /**
   * This method returns the current record number of the particular logger and
   * particular message type (table).
   * @param loggerId The logger id.
   * @return The current record number in the database table.
   */
  public int obtainCurrentNumber(String merchantId);

  /**
   * This method sets the SMTP name.
   * @param smtpName Tne SMTP name.
   */
  public void putMailInet(String smtpName);

  /**
   * This method sets the the performance counter sampling time.
   * @param samplingTime The sampling time.
   */
  public void putSamplingTime(int samplingTime);

  /**
   * This method starts the particular auditing logger.
   * @param loggerId The logger id.
   * @param reason - stop reason
   */
  public void start(String loggerId, String reason);

  /**
   * This method stops the particular auditing logger.
   * @param loggerId The logger id.
   * @param reason - stop reason
   */
  public void stop(String loggerId, String reason);

  /**
   * This method returns the auditing status string.
   * @return The auditing status string.
   */
  public String obtainStatus(String loggerId);

  /**
   * This method reset the current number of the auditing logger database table.
   * @param loggerId The auditing status string.
   */
  public void initCurrentNumber(String jndi, String schema);

  /**
   * This method remove data source from the application server.
   * (This method is used for doing test and debug.)
   * @param jndi The jndi name.
   */
  public void removeDataSource(String jndi);

  /**
   * Obtain the start stop reason
   * @param loggerId - the loger handler id
   */
  public String obtainStartStopReason(  String loggerId );

  /**
   * Obtain the start stop time
   * @param loggerId - the the loger handler id
   */
  public long obtainStartStopTime( String loggerId );

}
import com.oncecorp.visa3d.bridge.beans.PluginChannelBean;
import com.oncecorp.visa3d.bridge.beans.PluginListenerBean;
import com.oncecorp.visa3d.bridge.beans.PluginServiceBean;
import com.oncecorp.visa3d.bridge.beans.AuditingListenerBean;
import com.oncecorp.visa3d.bridge.logging.DataBridgeLoger;
import com.oncecorp.visa3d.bridge.beans.BeansHelper;
import com.oncecorp.visa3d.bridge.auditing.AuditingManager;
import com.oncecorp.visa3d.bridge.utility.Utils;

public class ListeningManager
{
    private static Map m_listeners = Collections.synchronizedMap( new TreeMap() );
    private final static ListeningManager m_instance = new ListeningManager();
    private PluginServiceBean m_pluginServiceBean = null;

    private static Logger m_logger = DataBridgeLoger.getLogger(
            ListeningManager.class.getName() );


    /**
     * Default constructor
     */
    private ListeningManager()
    {
    }

    /**
     * Get the only Listening Manager instance
     * @return - Listening Manager instance
     */
    public static ListeningManager getInstance()
    {
        return m_instance;
    }

    /**
     * This is a generice function to handle listening service related actions
     * @param props - the action related properties
     * @return - successfully action or not
     */
    public boolean doAction(Properties props)
    {

        String action = ListeningUtils.getAction( props );
        String listener = ListeningUtils.getListener(props);
        String channel = ListeningUtils.getChannel(props);
		String reason = ListeningUtils.getReason(props);

        m_logger.debug( "action=[" + action + "] listener=[" + listener + "]");

        if ( action == null || listener == null )
            return false;

        if ( ListeningUtils.isStopAction(action) )
            return stopListener( listener, channel, reason );
        else if ( ListeningUtils.isStartAction(action) )
            return startListener( listener, channel, reason );
        else if ( ListeningUtils.isRegisterAction(action) )
        {
            String xml = ListeningUtils.getConfigXml( props );
            return registerListener( listener, channel, xml );
        }
        else if ( ListeningUtils.isUnregisterAction(action) )
            return unregisterListener( listener, channel );

        return false;
    }

	/**
	 * Start a listener channel
	 * @param listener - the plugin listener
	 * @param channel - the channel under the given listener
	 * @return - successfully action or not
	 */
	public boolean startListener(String listener, String channel )
	{
		return this.startListener( listener, channel, "" );
	}

	/**
	 * Retrive a listener channel's start/stop reason
	 * @param listener - the plugin listener
	 * @param channel - the channel under the given listener
	 * @return - start/stop reason
	 */
	public String getStartStopReason( String listener, String channel )
	{
		if ( listener != null )
		{
			Map items = (Map) m_listeners.get( listener );
			if ( items != null && items.size() > 0 )
			{
				if ( channel != null )
				{
					ListeningThread lthread = (ListeningThread) items.get(channel);
					if ( lthread != null )
					{
						return lthread.getStartStopReason();
					}
				}
			}
		}
		return "";
	}

	/**
	 * Retrive a listener channel's start/stop time
	 * @param listener - the plugin listener
	 * @param channel - the channel under the given listener
	 * @return - start/stop time
	 */
	public long getStartStopTime( String listener, String channel )
	{
		if ( listener != null )
		{
			Map items = (Map) m_listeners.get( listener );
			if ( items != null && items.size() > 0 )
			{
				if ( channel != null )
				{
					ListeningThread lthread = (ListeningThread) items.get(channel);
					if ( lthread != null )
					{
						return lthread.getStartStopTime();
					}
				}
			}
		}
		return 0;
	}

    /**
     * Start a listener channel
     * @param listener - the plugin listener
     * @param channel - the channel under the given listener
	 * @param reason - start reason
     * @return - successfully action or not
     */
    public boolean startListener(String listener, String channel, String reason)
    {
        if ( listener != null )
        {
            Map items = (Map) m_listeners.get( listener );
            if ( items != null && items.size() > 0 )
            {
                if ( channel != null )
                {
                    m_logger.debug("channel [" + channel + "] is defined" );
                    ListeningThread lthread = (ListeningThread) items.get(channel);
                    if ( lthread != null )
                    {
                        lthread.start( reason );
                        if ( ListeningUtils.isAuditingListener( listener ) )
                        {
                            AuditingMessageReceiver amr = (AuditingMessageReceiver) lthread;
                            amr.setAuditingListenerBeanStatus( Utils.LISTENTING_START );
                        }
                        else
                        {
                            PluginMessageReceiver pmr = (PluginMessageReceiver) lthread;
                            pmr.setPluginChannelBeanStatus( Utils.LISTENTING_START );
                        }
                        return true;
                    }
                }
                else {
                    m_logger.debug("start all channels of listener [" + listener  );
                    for (Iterator lt = items.values().iterator(); lt.hasNext(); )
                    {
                        ListeningThread lthread = (ListeningThread) lt.next();
                        if ( lthread != null )
                        {
                            lthread.start( reason );
                            if ( ListeningUtils.isAuditingListener( listener ) )
                            {
                                AuditingMessageReceiver amr = (AuditingMessageReceiver) lthread;
                                amr.setAuditingListenerBeanStatus( Utils.LISTENTING_START );
                            }
                            else
                            {
                                PluginMessageReceiver pmr = (PluginMessageReceiver) lthread;
                                pmr.setPluginChannelBeanStatus( Utils.LISTENTING_START );
                            }
                        }
                    }
                    return true;
                }
            }
        }

        return false;
    }

	/**
	 * Stop a listener channel
	 * @param listener - the plugin listener
	 * @param channel - the channel under the given listener
	 * @return - successfully action or not
	 */
	public boolean stopListener(String listener, String channel)
	{
		return this.startListener( listener, channel, "" );
	}

    /**
     * Stop a listener channel
     * @param listener - the plugin listener
     * @param channel - the channel under the given listener
	 * @param reason - stop reason
     * @return - successfully action or not
     */
    public boolean stopListener(String listener, String channel, String reason )
    {
        if ( listener != null )
        {
            Map items = (Map) m_listeners.get( listener );
            if ( items != null && items.size() > 0 )
            {
                if ( channel != null )
                {
                    m_logger.debug("channel [" + channel + "] is defined" );
                    ListeningThread lthread = (ListeningThread) items.get(channel);
                    if ( lthread != null )
                    {
                        lthread.stop( reason );
                        if ( ListeningUtils.isAuditingListener( listener ) )
                        {
                            AuditingMessageReceiver amr = (AuditingMessageReceiver) lthread;
                            amr.setAuditingListenerBeanStatus( Utils.LISTENING_STOP );
                        }
                        else
                        {
                            PluginMessageReceiver pmr = (PluginMessageReceiver) lthread;
                            pmr.setPluginChannelBeanStatus( Utils.LISTENING_STOP );
                        }
                        return true;
                    }
                }
                else {
                    m_logger.debug("stop all channels of listener [" + listener  );
                    for (Iterator lt = items.values().iterator(); lt.hasNext(); )
                    {
                        ListeningThread lthread = (ListeningThread) lt.next();
                        if ( lthread != null )
                        {
                            lthread.stop( reason );
                            if ( ListeningUtils.isAuditingListener( listener ) )
                            {
                                AuditingMessageReceiver amr = (AuditingMessageReceiver) lthread;
                                amr.setAuditingListenerBeanStatus( Utils.LISTENING_STOP );
                            }
                            else
                            {
                                PluginMessageReceiver pmr = (PluginMessageReceiver) lthread;
                                pmr.setPluginChannelBeanStatus( Utils.LISTENING_STOP );
                            }
                        }
                    }
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Register a listener channel or plug in
     * @param listener - the plugin listener
     * @param channel - the channel under the given listener
     * @param xml - the plugin related properties which is defined in a XML string
     * @return - successfully action or not
     */
    public boolean registerListener(String listener, String channel, String xml)
    {
        if ( listener != null )
        {
            if ( m_listeners.containsKey( listener ) && channel == null )
            {
                m_logger.debug("In [registerPlugin] listener [" + listener + "] is already exists.");
                return false;
            }
            else if ( channel != null )
            {
                Map items = (Map) m_listeners.get( listener );
                if ( items == null )
                {
                    items = Collections.synchronizedMap( new TreeMap() );
                    m_listeners.put( listener, items);
                }
                if ( items.containsKey( channel ) )
                {
                    m_logger.debug("In [registerPlugin] listener [" + listener
                                       + "] channel [" + channel + "] is already exists.");
                    return false;
                }

                if ( !ListeningUtils.isAuditingListener( listener ) )
                {
                    m_logger.debug("Begin register plugin listener ["
                                   + listener + "] channel=[" +  channel + "]" );

                    PluginChannelBean pcb = BeansHelper.pluginChannelFromXml( null, xml );
                    if ( pcb != null )
                    {
                        PluginListenerBean plb = m_pluginServiceBean.getPluginListener( listener );
                        plb.addChannel( pcb );
                        PluginMessageReceiver pmr = new PluginMessageReceiver( pcb, plb );

                        this.registerListener( pmr );

                        m_logger.debug("register successfully.");
                    }
                    else
                    {
                        m_logger.warn("Empy channel from configuration data.");
                    }

                    return true;
                } else
                {
                    m_logger.debug("Begin register auditing listener ["
                                   + listener + "] channel=[" +  channel + "]" );

                    AuditingListenerBean alb = BeansHelper.auditingListenerFromXml( null, xml);
                    if ( alb != null )
                    {
                        AuditingManager.getInstance().addAuditingLogger(alb);
                        AuditingMessageReceiver pmr = new AuditingMessageReceiver( alb );
                        this.registerListener( pmr );
                        m_logger.debug("register successfully.");
                    }
                    else
                    {
                        m_logger.warn("Empy auditing listener from configuration data.");
                    }

                    m_logger.debug("End register auditing listener ["
                                   + listener + "] channel=[" +  channel + "]" );
                    return true;
                }
            }
            else
            {
                m_logger.debug("Begin register listener ["
                               + listener + "] " );
                Map items = Collections.synchronizedMap( new TreeMap() );
                m_listeners.put( listener, items);

                if ( !ListeningUtils.isAuditingListener( listener ) )
                {
                    PluginListenerBean plb = BeansHelper.pluginListenerFromXml( null, xml );
                    if ( plb != null )
                    {
                        registerPlugin( plb );
                        m_logger.debug("register plugin listener successfully.");
                    }
                    else
                    {
                        m_logger.warn("Empy plugin listener from configuration data.");
                    }
                    m_logger.debug("End register listener ["
                                   + listener + "] " );
                    return true;
                }
                else
                {
                    m_logger.debug("Auditing listener always exist, can't register." );
                    return false;
                }
            }
        }

        return false;
    }

    /**
     * Register a plugin listener from plugin listener bean.
     * @param plb = Plugin listener bean which contains all listener data
     */
    public void registerPlugin( PluginListenerBean plb )
    {
        m_pluginServiceBean.AddPlugin( plb );

        PluginChannelBean pcb;
        PluginMessageReceiver pmr;

        Map channels = plb.getChannels();

        for ( Iterator lt = channels.values().iterator(); lt.hasNext(); )
        {
            pcb = (PluginChannelBean) lt.next();
            pmr = new PluginMessageReceiver( pcb, plb );
            registerListener( pmr );
        }
    }

    /**
     * Register a plugin instance
     * @param pmr - the plugin instance
     */
    public void registerListener( ListeningThread pmr )
    {
        m_logger.debug("Begin register/start listener thread. " );
        if ( pmr != null )
        {
            String listener = pmr.getListenerName();
            Map items = (Map) m_listeners.get( listener );
            if ( items == null )
            {
                items = Collections.synchronizedMap( new TreeMap() );
                m_listeners.put( listener, items);
            }
            String cid = pmr.getChannelName();
            if ( cid == null || items.containsKey( cid ) )
            {
                m_logger.debug("In [registerPlugin] listener [" + listener
                                   + "] channel [ " + cid
                                   + "] is already exists.");
                return;
            }

            items.put( cid, pmr );
            pmr.register();
        }
        m_logger.debug("End register/start listener thread. " );
    }

    /**
     * Unregister a listener channel or plugin
     * @param listener - the plugin listener
     * @param channel - the channel under the given listener
     * @return - successfully action or not
     */
    public boolean unregisterListener(String listener, String channel)
    {
        boolean flag = false;

        m_logger.debug("Begin unregister/stop listener thread [" + listener + "] [" + channel + "]" );
        if (  listener != null )
        {
            Map items = (Map) m_listeners.get( listener );
            if ( items != null && items.size() > 0 )
            {
                m_logger.debug(" Listener found with item's size " + items.size() );

                if ( channel != null )
                {
                    if ( !ListeningUtils.isAuditingListener( listener ) )
                    {
                        PluginListenerBean bean = m_pluginServiceBean.getPluginListener( listener );
                        bean.removeChannel( channel );
                    }
                    else
                    {
                        AuditingManager.getInstance().removeAuditingLogger( channel );
                    }

                    ListeningThread lthread = (ListeningThread) items.get(channel);
                    if ( lthread != null )
                    {
                        lthread.unregister();
                        items.remove( channel );
                        if ( items.size() == 0 )
                        {
                            m_listeners.remove( listener );
                            flag = true;
                        }
                    }
                }
                else {
                    for (Iterator lt = items.values().iterator(); lt.hasNext(); )
                    {
                        ListeningThread lthread = (ListeningThread) lt.next();
                        if ( lthread != null )
                            lthread.unregister();
                    }

                    if ( !ListeningUtils.isAuditingListener( listener ) )
                    {
                        m_listeners.remove( listener );
                        m_pluginServiceBean.removePlugin( listener );
                    }
                    flag = true;
                }
            }
        }
        m_logger.debug("End register/start listener thread. " );
        return flag;
    }

    /**
     * Get the a channel's start/stop status
     * @param listenr - the plugin listener
     * @param channel - the channel under the given listener
     * @return - the defined plugins status: start/stop
     */
    public String getListenerStatus( String listener, String channel )
    {
        m_logger.debug("Begin get Status of listener thread. " );
        if (  listener != null )
        {
            Map items = (Map) m_listeners.get( listener );
            if ( items != null && items.size() > 0 )
            {
                if ( channel != null )
                {
                    ListeningThread lthread = (ListeningThread) items.get(channel);
                    if ( lthread != null )
                    {
                        String rstr = lthread.getStatus();
                        m_logger.debug("End get Status of listener thread with status=[ "
                                      + rstr + "]" );
                        return rstr;
                    }
                }
            }
        }
        m_logger.debug("End get Status of listener thread with not found. " );

        return null;
    }

    /**
     * Start listening service which means all suspend channels are resumed
     */
    public void startService()
    {
        String listener;
        Map items;
        ListeningThread lthread;

        for ( Iterator lt = m_listeners.keySet().iterator(); lt.hasNext(); )
        {
            listener = (String)lt.next();

            items = (Map) m_listeners.get( listener );
            if ( items != null && items.size() > 0 )
            {
                for (Iterator slt = items.values().iterator(); slt.hasNext(); )
                {
                    lthread = (ListeningThread) slt.next();
                    if ( lthread != null )
                        lthread.start();
                }
            }
        }
    }

    /**
     * Stop listening service which means all channels are suspended
     */
    public void stopService()
    {
        String listener;
        Map items;
        ListeningThread lthread;

        for ( Iterator lt = m_listeners.keySet().iterator(); lt.hasNext(); )
        {
            listener = (String)lt.next();

            items = (Map) m_listeners.get( listener );
            if ( items != null && items.size() > 0 )
            {
                for (Iterator slt = items.values().iterator(); slt.hasNext(); )
                {
                    lthread = (ListeningThread) slt.next();
                    if ( lthread != null )
                        lthread.stop();
                }
            }
        }
    }

    /**
     * Remove plugins that not include in the new list
     * @param plugins - new plugin list
     */
    public void removePlugins( ArrayList plugins )
    {
        String listener;
        Map items;
        ListeningThread lthread;
        ArrayList al = new ArrayList();
        for ( Iterator lt = m_listeners.keySet().iterator(); lt.hasNext(); )
        {
            listener = (String)lt.next();

            if ( !ListeningUtils.isAuditingListener( listener ) && !plugins.contains(listener) )
            {
                al.add(listener);
                items = (Map) m_listeners.get( listener );
                if ( items != null && items.size() > 0 )
                {
                    for (Iterator slt = items.values().iterator(); slt.hasNext(); )
                    {
                        lthread = (ListeningThread) slt.next();
                        if ( lthread != null )
                            lthread.unregister();
                    }
                }
            }
        }

        for (Iterator lt = al.iterator(); lt.hasNext(); )
            m_listeners.remove( lt.next() );
    }

    /**
     * Remove channels that not included in the new channel list
     * @param listener - the listener which channels to be handled
     * @param newChannels - new channel list
     * @return - successfully action or not
     */
    public boolean removeChannels( String listener, ArrayList newChannels )
    {
        String key;
        ListeningThread lthread;
        ArrayList al = new ArrayList();
        Map channels = (Map) m_listeners.get( listener );

        boolean flag = false;

        for ( Iterator lt = channels.keySet().iterator(); lt.hasNext(); )
        {
            key = (String)lt.next();

            if ( !newChannels.contains(key) )
            {
                al.add(  key  );
            }
        }

        for (Iterator lt = al.iterator(); lt.hasNext(); )
        {
            key = (String)lt.next();

            lthread = (ListeningThread) channels.get( key );
            lthread.unregister();
            channels.remove( key );
            if ( channels.size() == 0 )
                m_listeners.remove( listener );
            flag = true;
        }

        return flag;
    }

    /**
     * The plugin channel's attributes are modified
     * @param pmr - the plugin message receiver
     * @param prb - the new plugin channel bean
     * @param plb - the new plugin listener bean
     * @return - successfully action or not
     */
    private boolean resetPluginChannel( PluginMessageReceiver pmr,
                                    PluginChannelBean prb, PluginListenerBean plb )
    {
        return pmr.reset( prb, plb );
    }

    /**
     * Reset attributies of plugin listener
     * @param key - listener identify
     * @param bean - plugin Listener bean
     * @return - successfully action or not
     */
    private boolean resetPluginListener( String key, PluginListenerBean bean )
    {
        Map oldChannels = (Map) m_listeners.get( key );
        ArrayList rchannels = new ArrayList();
        String ckey;
        Map channels = bean.getChannels();
        PluginChannelBean pcb;
        PluginMessageReceiver pmr;

        m_logger.debug("Enter resetPluginListener");
        boolean flag = false;

        for ( Iterator slt = channels.keySet().iterator(); slt.hasNext(); )
        {
            ckey = (String) slt.next();
            pcb = (PluginChannelBean) channels.get( ckey );
            rchannels.add( ckey );
            if ( oldChannels != null && oldChannels.containsKey( ckey ) )
            {
                pmr = (PluginMessageReceiver) oldChannels.get( ckey );
                if ( resetPluginChannel( pmr, pcb, bean ) )
                    flag = true;

                m_logger.debug("reset PluginChannel [" + ckey + "]" );
            }
            else
            {
                pmr = new PluginMessageReceiver( pcb, bean );
                registerListener( pmr );
                flag = true;
            }
        }

        if ( removeChannels( key, rchannels ) )
            flag = true;

        m_logger.debug("Exit resetPluginListener");
        return flag;

    }

    /**
     * Reset all plugin listeners which is usually called when configuration are changed
     * @param bean - plugin service bean
     */
    public void resetPluginService( PluginServiceBean bean )
    {
        ArrayList rplugins = new ArrayList();
        m_pluginServiceBean = bean;

        Map listeners = bean.getPlugins();
        String key, ckey;
        PluginListenerBean plb;
        PluginChannelBean pcb;
        PluginMessageReceiver pmr;
        Map channels, oldChannels;

        m_logger.debug("Enter resetPluginService");

        for ( Iterator lt = listeners.keySet().iterator(); lt.hasNext(); )
        {
            key = (String) lt.next();
            rplugins.add( key );
            plb = (PluginListenerBean) listeners.get( key );

            channels = plb.getChannels();

            if ( m_listeners.containsKey( key ) )
            {
                resetPluginListener(key, plb);
                m_logger.debug("reset plugin [" + key + "]");
            }
            else
            {
                for ( Iterator slt = channels.keySet().iterator(); slt.hasNext(); )
                {
                    ckey = (String) slt.next();
                    pcb = (PluginChannelBean) channels.get( ckey );
                    pmr = new PluginMessageReceiver( pcb, plb );
                    registerListener( pmr );
                }

            }

        }

        removePlugins( rplugins );

        m_logger.debug("Exit resetPluginService");
    }

    /**
     * Handle auditing listener attributes modifications
     * @param amr - auditing listener receiver
     * @param alb - auditing listener bean
     */
    private void resetAuditingChannel( AuditingMessageReceiver amr,
                                      AuditingListenerBean alb )
    {
        amr.reset( alb );
    }

    /**
     * Reset all auditing listeners which is usually called when reload configuration
     * @param listeners - the new listeners list
     */
    public void resetAuditingListeners( Map listeners )
    {
        m_logger.debug("Enter resetAuditingListeners");
        String key;
        Map items = (Map)m_listeners.get( ListeningUtils.AUDITING_LISTENER );
        if ( items == null )
        {
            items = Collections.synchronizedMap( new TreeMap() );
            m_listeners.put( ListeningUtils.AUDITING_LISTENER , items);
        }

        ArrayList al = new ArrayList();
        AuditingMessageReceiver amr;
        AuditingListenerBean alb;

        for ( Iterator lt = listeners.keySet().iterator(); lt.hasNext(); )
        {
            key = (String) lt.next();
            al.add( key );
            alb = (AuditingListenerBean) listeners.get( key );
            if ( items.containsKey( key ) )
            {
                amr = (AuditingMessageReceiver) items.get( key );
                resetAuditingChannel(amr, alb);
                m_logger.debug("reset auditing logger [" + key + "]" );
            }
            else
            {
                amr = new AuditingMessageReceiver( alb );
                registerListener( amr );
            }
        }

        removeChannels( ListeningUtils.AUDITING_LISTENER, al );

        m_logger.debug("Exit resetAuditingListeners");

    }

    /**
     *
     * @return - the registered plugin service bean
     */
    public PluginServiceBean getPluginService()
    {
        return m_pluginServiceBean;
    }


    /**
     * Notify all registered timer service listener
     */
    public void notifyTimerService()
    {
        Object obj;
        TimerServiceListener listener;
        ListeningThread lthread;
        String lstr, cstr;
        Map items;

        if ( m_listeners == null || m_listeners.size() < 1 )
            return;

        m_logger.debug("Enter notifyTimerService.");
        for ( Iterator lt = m_listeners.keySet().iterator(); lt.hasNext(); )
        {
            lstr = (String)lt.next();
            items = (Map)m_listeners.get( lstr );
            if ( items == null )
                continue;

            for ( Iterator slt = items.keySet().iterator(); slt.hasNext(); )
            {
                cstr = (String) slt.next();
                lthread = (ListeningThread) items.get( cstr );
                obj = lthread.m_plugin;
                if ( obj instanceof TimerServiceListener )
                {
                    listener = (TimerServiceListener) obj;
                    listener.timerNotify();
                    m_logger.debug("Notify: [" + lstr + "] [" + cstr + "]" );
                }
            }
        }
        m_logger.debug("Exit notifyTimerService.");
    }

    /**
     * The new listener is defined in the XML string
     * @param xml - XML definition for the listener
     * @return - successfully action or not
     */
    public boolean updatePluginListener( String xml )
    {
        m_logger.debug("Enter updatePluginListener.");
        PluginListenerBean bean = BeansHelper.pluginListenerFromXml( null, xml );
        if ( bean != null )
        {
            String listener = bean.getId();
            if ( !m_listeners.containsKey( listener ) )
            {
                m_logger.debug("PluginListener [" + listener + "] not found, can't update it.");
                return false;
            }

            boolean flag = resetPluginListener( listener, bean );

            m_logger.debug("Exit updatePluginListener with flag=[" + flag + "]");

            return flag;
        }
        else
        {
            m_logger.warn("Can't get plugin listener from configuration data.");
            return false;
        }

    }

    /**
     * The new channel is defined in the XML string
     * @param listener - plug in listener identify
     * @param xml - XML definition for the channel
     * @return - successfully action or not
     */
    public boolean updatePluginChannel( String listener, String xml )
    {
        m_logger.debug("Enter updatePluginChannel.");
        if ( !m_listeners.containsKey( listener ) )
        {
            m_logger.debug("PluginListener [" + listener + "] not found, can't update it's channel.");
            return false;
        }

        PluginChannelBean bean = BeansHelper.pluginChannelFromXml( null, xml );
        if ( bean != null )
        {

            Map lmap = (Map)m_listeners.get( listener );
            PluginMessageReceiver pmr = (PluginMessageReceiver) lmap.get( bean.getId() );

            if ( pmr == null )
            {
                m_logger.debug("PluginChannel [" +  bean.getId() + "] not found, can't update it.");
                return false;
            }

            PluginListenerBean parent = (PluginListenerBean)
                                        m_pluginServiceBean.getPlugins().get( listener );

            return resetPluginChannel( pmr, bean, parent );
        }
        else
        {
            m_logger.warn("Can't set up plugin channel from configuration data.");
            return false;
        }
    }

    /**
     * Update exist auditing listener which properties from the new listener bean
     * @param bean - new listener bean
     */
    public void updateAuditingListener( AuditingListenerBean bean )
    {
        m_logger.debug("Enter updateAuditingListener.");
        if ( !m_listeners.containsKey( ListeningUtils.AUDITING_LISTENER ) )
        {
            m_logger.debug("AuditingListener  not registered yet, can't update it's channel.");
            return;
        }

        Map lmap = (Map)m_listeners.get( ListeningUtils.AUDITING_LISTENER );
        AuditingMessageReceiver amr = (AuditingMessageReceiver) lmap.get( bean.getId() );

        if ( amr == null )
        {
            m_logger.debug("Auditing logger [" +  bean.getId() + "] not found, can't update it.");
            return;
        }

        resetAuditingChannel( amr, bean );

    }

    /**
     * Add a new auditing listener configured from auditing listener bean
     * @param bean - new auditing listener bean
     */
    public void addAuditingListener( AuditingListenerBean bean )
    {
        AuditingMessageReceiver amr = new AuditingMessageReceiver( bean );
        registerListener( amr );
    }
}
package com.oncecorp.visa3d.bridge.beans;

import java.io.Serializable;

import com.oncecorp.visa3d.bridge.utility.ConfigureConstants;

/**
 * <p>Title: DataBridgeBean</p>
 * <p>Description: Hold the Data Bridge related configuration data </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: ONCE Corporation </p>
 * @author Gang Wu ( gwu@oncecorp.com )
 * @version 1.0
 */


public class DataBridgeBean implements Serializable, ConfigureConstants
{

    private boolean autoSave = true;

    /**
     * This for internal use only.
     */
    private boolean attributeSet = true;

    private ListeningServiceBean listeningService = null;
    private AuditingServiceBean  auditingService = null;
    private MonitoringServiceBean monitoringService = null;
    private PluginServiceBean     pluginService = null;

    /**
     * Default constructor
     */
    public DataBridgeBean()
    {
    }

    /**
     * Get auto save flag
     * @return
     */
    public boolean isAutoSave()
    {
        return autoSave;
    }

    /**
     * Set auto save value
     * @param flag - auto save flag
     */
    public void setAutoSave( boolean flag )
    {
        autoSave = flag;
    }

    /**
     * Configure from XML string
     * @param xml - Configuration XML string
     */
    public void fromXml( String xml )
    {
        BeansHelper.databridgeFromXml( this, xml );
    }

    /**
     * Generate XML string
     * @return - XML definition
     */
    public String toXml()
    {
        String sauto = "false";
        if ( autoSave )
            sauto = "true";

        StringBuffer sb = new StringBuffer();
        sb.append("<?xml version=\"1.0\" encoding=\"ISO-8859-1\" standalone=\"no\"?>\r\n");
        sb.append("<!DOCTYPE " + DATA_BRIDGE_TAG +" >\r\n");
        sb.append("<" + DATA_BRIDGE_TAG +" xmlns:mpidb='http://www.oncecorp.com/ONCEmpi/databridge-configuration' "
                  + "autoSave=\"" + sauto + "\">\r\n");

        if ( listeningService != null )
        {
            sb.append( listeningService.toXml() );
        }
        else
        {
            sb.append( "<" + LISTENING_SERVICE_TAG + " />\r\n\r\n");
        }

        if ( auditingService != null )
        {
            sb.append( auditingService.toXml() );
        }
        else
        {
            sb.append( "<" + AUDITING_SERVICE_TAG + " />\r\n\r\n");
        }

        if ( monitoringService != null )
        {
            sb.append( monitoringService.toXml() );
        }
        else
        {
            sb.append( "<" + MONITORING_SERVICE_TAG + " />\r\n\r\n");
        }

        if ( pluginService != null )
        {
            sb.append( pluginService.toXml() );
        }
        else
        {
            sb.append( "<" + PLUGIN_SERVICE_TAG + " />\r\n\r\n");
        }

        sb.append("</" + DATA_BRIDGE_TAG + ">\r\n");

        return sb.toString();
    }

    /**
    *
    * @return the ListeningServiceBean value of listeningService.
    */
    public ListeningServiceBean getListeningService(){
        return listeningService;
    }

    /**
    *
    * @param aListeningService - the new value for listeningService
    */
    public void setListeningService(ListeningServiceBean aListeningService){
        listeningService = aListeningService;
    }


    /**
    *
    * @return the AuditingServiceBean value of auditingService.
    */
    public AuditingServiceBean getAuditingService(){
        return auditingService;
    }

    /**
    *
    * @param aAuditingService - the new value for auditingService
    */
    public void setAuditingService(AuditingServiceBean aAuditingService){
        auditingService = aAuditingService;
    }


    /**
    *
    * @return the MonitoringServiceBean value of monitoringService.
    */
    public MonitoringServiceBean getMonitoringService(){
        return monitoringService;
    }

    /**
    *
    * @param aMonitoringService - the new value for monitoringService
    */
    public void setMonitoringService(MonitoringServiceBean aMonitoringService){
        monitoringService = aMonitoringService;
    }


    /**
    *
    * @return the PluginServiceBean value of pluginService.
    */
    public PluginServiceBean getPluginService(){
        return pluginService;
    }

    /**
    *
    * @param aPluginService - the new value for pluginService
    */
    public void setPluginService(PluginServiceBean aPluginService){
        pluginService = aPluginService;
    }

    /**
    *
    * @return true if attributeSet is set to true.
    */
    public boolean isAttributeSet(){
        return attributeSet;
    }

    /**
    *
    * @param aAttributeSet - the new value for attributeSet
    */
    public void setAttributeSet(boolean aAttributeSet){
        attributeSet = aAttributeSet;
    }


}
package  com.oncecorp.visa3d.bridge.auditing;

import  com.oncecorp.visa3d.bridge.beans.AuditingListenerBean;
import  com.oncecorp.visa3d.bridge.beans.AuditingServiceBean;
import  com.oncecorp.visa3d.bridge.beans.MerchantInfoBean;
import  com.oncecorp.visa3d.bridge.beans.BeansHelper;
import  com.oncecorp.visa3d.bridge.monitoring.AuditingPerformanceMBean;

import  java.util.Iterator;
import  java.util.List;
import  java.util.Map;
import  java.util.TreeMap;
import  java.util.TreeSet;


/**
 * <p>Title: ONCE MPI Data Bridge</p>
 * <p>Description: This is the MBean class that is used for populating the
 * statistics counter result.  The counter flush can also through this MBean
 * class.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Once Corporation</p>
 * @author yge@oncecorp.com
 * @author Gang Wu ( gwu@oncecorp.com )
 * @version 1.0
 */
public class AuditingPerformance
        implements AuditingPerformanceMBean, PropertiesConstants {

    /**
     * The default constructor.
     */
    public AuditingPerformance () {
    }

    /**
     * This method returns the message type counting results map.
     * @return The message type counting results map.
     */
    public Map obtainMessageTypeCountMap () {
        Map map = new TreeMap();
        List msgTypes = AuditingUtils.getMessageMappingList();

        if ( msgTypes == null )
            return  map;
        String key, type, version;
        for ( Iterator lt = msgTypes.iterator(); lt.hasNext(); )
        {
            key = (String) lt.next();
            type = BeansHelper.extractTypeFromKey(key);
            version = BeansHelper.extractVersionFromKey(key);
            map.put(key,
                    AuditingManager.getInstance().getCountingValue(ALL,
                        type, version ) );
        }
        return  map;
    }

    /**
     * This method returns the message status counting results map.
     * @return The message status counting results map.
     */
    public Map obtainMessageStatusCountMap () {
        //System.out.println("It's status");
        Map map = new TreeMap();
        for (int i = 0; i < STATUS_CATEGORY_ID_LIST.length; i++) {
            map.put(STATUS_CATEGORY_ID_LIST[i],
                    AuditingManager.getInstance().getCountingValue(
                    STATUS + "." + STATUS_CATEGORY_ID_LIST[i].getStatus(),
                    STATUS_CATEGORY_ID_LIST[i].getMsgType(), ""));
        }
        return  map;
    }

    /**
     * This method returns the given merchant counting results map.
     * @return The merchant counting results map.
     */
    public Map obtainMerchantCountMap () {
        Map map = new TreeMap();

        StatisticsHolder main =
                AuditingManager.getInstance().getMainStatisticsHolder();
        MerchantStatisticsHolder msh = (MerchantStatisticsHolder)
                main.getSubCounter( MERCHANT );
        Map counters = msh.getCounters();

        String key;
        String[] list = merchantIdList();
        if ( list != null && list.length > 0 )
        {
            for ( int i = 0; i < list.length; i++ )
            {
                key = list[i];
                if ( !counters.containsKey( key ) )
                    map.put( key, AuditingUtils.getProtocolCounter() );
            }
        }

        MerchantCounter mc;
        for ( Iterator lt = counters.keySet().iterator(); lt.hasNext(); )
        {
            key = (String)lt.next();
            mc = (MerchantCounter)counters.get( key );
            map.put( key, mc.getCountingValue( key, "", "" ) );
        }
        return  map;
    }

    /**
     * This method return the peak number of the message processed per second
     * @return The peak number.
     */
    public float obtainPeakTPS () {
        return  AuditingManager.getInstance().getPerformanceCounter().getPeakTPS();
    }

    /**
     * This method returns the average number of the message processed per second
     * @return The average number.
     */
    public float obtainAverageTPS () {
        return  AuditingManager.getInstance().getPerformanceCounter().getAverageTPS();
    }

    /**
     * This method set all counter indicators to "zero".
     */
    public void flush () {
        AuditingManager.getInstance().flushCounters();
    }

    /**
     * This method returns the current supporting merchant id list array.
     * @return The current supporting merchant id list array.
     */
    public String[] merchantIdList () {
        MerchantInfo merchantInfoMBean = new MerchantInfo();
        List infoBeanList = merchantInfoMBean.query(null);
        if (infoBeanList == null || infoBeanList.isEmpty()) {
            return  new String[0];
        }
        String[] result = new String[infoBeanList.size()];
        for (int i = 0; i < infoBeanList.size(); i++) {
            MerchantInfoBean bean = (MerchantInfoBean)infoBeanList.get(i);
            result[i] = bean.getId();
        }
        return  result;
    }

    /**
     * This mehtod returns the Data Bridge start time.
     * @return The Data Bridge start time.
     */
    public long obtainStartTime () {
        return  AuditingManager.getInstance().getStartTime();
    }

    /**
     * This method returns the performance counter sampling time.
     * @return The sampling time.
     */
    public int obtainSamplingTime () {
        return  AuditingManager.getInstance().getPerformanceCounter().getSamplingTime();
    }

    /**
     * This method sets the performance counter sampling time.
     * @param samplingTime The sampling time.
     */
    public void putSamplingTime (int samplingTime) {
        AuditingManager.getInstance().getPerformanceCounter().setSamplingTime(samplingTime);
    }

    /**
     * This method retrns the total message number from the last flush.
     * @return The total message number.
     */
    public int obtainTotalMessageNumber () {
        return  AuditingManager.getInstance().getPerformanceCounter().getTotalMessageNumber();
    }

    /**
     * This method return the last flush time.
     * @return The last flush time.
     */
    public long obtainLastFlushTime () {
        return  AuditingManager.getInstance().getPerformanceCounter().getLastFlushTime();
    }

    /**
     * This method returns the peak time.
     * @return The peak time.
     */
    public long obtainPeakTime () {
        return  AuditingManager.getInstance().getPerformanceCounter().getPeakTime();
    }

    /**
     * This method returns the total count number at the last flush.
     * @return The total count number at the last flush.
     */
    public int totalMessageNumberAtLastFlush () {
        return  AuditingManager.getInstance().getPerformanceCounter().getTotalMessageNumberAtLastFlush();
    }
}

