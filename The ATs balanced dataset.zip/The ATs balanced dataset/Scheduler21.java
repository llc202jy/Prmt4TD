public abstract class GenericActivator extends Activator
{     
    protected GenScheduler myScheduler;
    
    public  PRNGInterface randomSource;
    
    public int priority=0; //lesser priority nb is, higher execution priority is

    public GenericActivator(String community, String group, String role,int activatorPriority)
    {
	super(community, group, role);
	priority = activatorPriority;
    }
/** lesser priority nb is, higher execution priority is*/    
public void setPriority(int activatorPriority)
{
	priority = activatorPriority;
}	
    
/**
 * do what has to be done in the activator and returns the next event for this activator
 * @return a simEvent that represents the next action of this activator {@link SimEvent}
 * @param GVT: the current GVT
 */
abstract public SimEvent execute(double GVT);

public void setRandomSource(PRNGInterface source)
{
	randomSource = source;
}


} * The SchedulingMessage class: interactions with the Scheudler
 *
 *  @author Fabien MICHEL
 *  @version 2.1 10/04/2005
 */

public class SchedulingMessage extends madkit.kernel.Message {
    final public static int ADD_EVENT=1;
    final public static int PAUSE_REQ=2;
    final public static int RUN_REQ=3;
    final public static int STOP_REQ=4;
    final public static int STEP_REQ=5;

    final public static int ACK=6;
    
    private Object content;
    private int requestType;
    
    public SchedulingMessage(int theRequest, Object content) {
        requestType=theRequest;
        this.content = content;
    }
    
    public SchedulingMessage(int theRequest) {
        this(theRequest,null);
    }
    
    public Object getContent() {
        return content;
    }

    public int getRequestType() {
        return requestType;
    }
}