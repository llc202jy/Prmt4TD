int GetInitialPing(int a_readDescriptor, char **a_pongFifoName)
{
 
  char *pongFifoName;
  int result;
  int data = 0;
  fd_set readSet;
  int done = 0;

#ifdef DEBUG
   fprintf(stderr, "GetIntialPing\n");
#endif

  FD_ZERO(&readSet);
  FD_SET(a_readDescriptor, &readSet);

  while (!done)
  { 
     /* wait until there is something to read (i.e. ping)
      this can block indefinitely when NULL */
     /* TODO: remove blocking call */
     result = select(a_readDescriptor+1, &readSet,
                     NULL, NULL, NULL);
     if (result >= 0)
     {
        data = ReadInitialPing(a_readDescriptor, &pongFifoName);
#ifdef DEBUG
        fprintf(stderr, "Initial Ping contained: '%s'\n", pongFifoName);
#endif
        *a_pongFifoName = pongFifoName;
        done = 1;
     }
  }
 
  return data;
}
/**
 * Creates the thread that handles acknowledgement of incoming
 * pings.
 * Opens the fifo for read/write.
 *
 * @return The thread identifier, or zero on error.
 */
pthread_t StartPingThread(SInternalRegistrationInfo *ap_regInfo,
                          int a_data)
{
   static SThreadData threadData;
   int writeFd;
   pthread_t thread;
   pthread_attr_t threadAttributes;

   if (NULL == ap_regInfo)
   {
 
/*
      ErrorHandler::LogMessage(LOG_ERR, "Internal registration info to thread is invalid.\n");
*/
      return 0;
   }

#ifdef DEBUG
   fprintf(stderr, "StartPingThread\n");
#endif
 
#ifdef DEBUG
   fprintf(stderr, "writeName = '%s'\n", 
           ap_regInfo->writeFifoName);
#endif
 
   writeFd = open(ap_regInfo->writeFifoName, O_WRONLY);
   if (writeFd > 0 )
   {
#ifdef DEBUG
   fprintf(stderr, "write fd = '%d'\n", writeFd);
   fprintf(stderr, "read fd = '%d'\n", ap_regInfo->readDescriptor);
#endif
      ap_regInfo->writeDescriptor = writeFd;
     
      threadData.writeDescriptor = writeFd;
      threadData.readDescriptor  = ap_regInfo->readDescriptor;
      strncpy(threadData.readFifoName, ap_regInfo->readFifoName, STRING_LENGTH);
      threadData.pingData = a_data;
      threadData.timeout = ap_regInfo->regInfo.frequency;

      /* create the thread as joinable since the app should not exit unless
         the thread has properly unregisterd with the monitor */
      pthread_attr_init(&threadAttributes);
      pthread_attr_setdetachstate(&threadAttributes, PTHREAD_CREATE_JOINABLE); 
      pthread_create(&thread, 
                     &threadAttributes, 
                     HandlePings, 
                     (void*) &threadData);

      ap_regInfo->threadId = thread;

      return thread;
   }
 
   return 0;
}
/**
 * Entry point of thread which handles incoming pings.
 * If the thread receives data that is zero, then it
 * assumes this is intentional and the result of an
 * unregistration request.  It will terminate the thread.
 *
 *
 * @param a_args  The file descriptor of the fifo
 * @todo Determine appropriate loop -- currently is infinite
 * @todo Determine use of pid field in ping data
 * @todo Determine course of action if failure reading ping
 *
 */
void * HandlePings(void *a_args)
{
 
  int readDescriptor;
  int writeDescriptor;
  fd_set readSet;
  int result;
  int pid;
  int data;
  SThreadData  *descriptors;
  struct timeval timeout;
  int microseconds;

#ifdef DEBUG
  fprintf(stderr, "HandlePings\n");
#endif
 
  pid = getpid();
#ifdef DEBUG
  fprintf(stderr, "pid of thread = '%d'\n", pid);
#endif
  descriptors = (SThreadData*) a_args;
 
  readDescriptor = (int ) descriptors->readDescriptor;
  writeDescriptor  = (int ) descriptors->writeDescriptor;
  data = (int) descriptors->pingData;

  /* rather than block indefinitely on the incoming ping fifo, 
     set the timeout to be twice the frequency, then yield and 
     try again. */
  microseconds = (int) descriptors->timeout * 2;

#ifdef DEBUG
  fprintf(stderr, "read descriptor = '%d'\n", readDescriptor);
  fprintf(stderr, "write descriptor = '%d'\n", writeDescriptor);
#endif

  data = doSendPong(writeDescriptor, data, pid);
 
  /* begin loop */
  do
  {
     /* do this inside the loop because the sets
      are modified by the select call */
     FD_ZERO(&readSet);
     FD_SET(readDescriptor, &readSet);
 
     /* wait until there is something to read (i.e. ping)
        this can block indefinitely when NULL */

     timeout.tv_sec = 0;
     timeout.tv_usec = microseconds; 
     
     result = select(readDescriptor+1, &readSet, NULL, NULL, NULL);

     if (result > 0)
     {
        data = doReadPing(readDescriptor);
        if (0 == data)
        {
#ifdef DEBUG
           printf("Received 0 in ping -- terminating thread\n");
#endif
           /* if 0 is sent, then terminate this thread */
           pthread_exit(NULL);
        }
        else if (data < 0)
        {
#ifdef DEBUG
           printf("There was an error reading the ping\n");
           printf("TODO: determine action to take in this case\n");
#endif
        }

        doSendPong(writeDescriptor, data, pid);
     }
     sched_yield();
  } while (1);
 
}

/**
 * This function is to be called by the user code to send a 
 * pong to the heartbeat monitor.  
 * 
 * @param ap_regInfo This is the library specific information
 *                   needed to send the correct ping.
 *
 * @return zero on success, non-zero on failure 
 */
int SendPong(void *ap_regInfo)
{
   int result;
   SInternalRegistrationInfo *p_regInfo;

   if (NULL == ap_regInfo )
   {
      errno = EINVAL;
      return EINVAL;    
   }
     
   p_regInfo = static_cast<SInternalRegistrationInfo *>(ap_regInfo);   
 
   /* if we already replied, don't resend */ 
   if (p_regInfo->lastData < 0)
   {
      errno = EINPROGRESS;
      return EINPROGRESS;
   } 
  
   result = doSendPong(p_regInfo->writeDescriptor,
                       p_regInfo->lastData,
                       p_regInfo->regInfo.pid);

   if (result != 0)
   {
      errno = EPIPE;
      return EPIPE;
   } 

   /* indicate that we replied to the ping */
   p_regInfo->lastData = -1;

   errno = 0;
   return 0;
 
}

/**
 * Sends a reply to the monitor based on the
 * data received in the last ping.
 *
 * @param a_fifoDescriptor The file descriptor of the fifo to write to
 * @param a_data The ping specific data to send
 * @param a_pid The pid of this application
 *
 * @return zero on success;  non-zero on failure
 */
int doSendPong(int a_fifoDescriptor, int a_data, int a_pid)
{
 
   /* the structure containing the ping information */
   SPingData ping;
   ssize_t bytes;

#ifdef DEBUG
   fprintf(stderr, "doSendPong ('%d')\n", a_data);
#endif

   /* Fill ping information structure with a unique
      value for this ping. */
   ping.pingData = a_data;
   ping.destinationPid = a_pid ;
 
   /* write ping info to the fifo */
   bytes =  write(a_fifoDescriptor, &ping, sizeof(ping));
   if (bytes != sizeof(ping))
   {
#ifdef DEBUG
      fprintf(stderr, "Error writing ping info to fifo\n");
      fprintf(stderr, "Fix here for handling this error\n");
#endif
      return 1;
   }
   return 0;
}

/**
 * This function is used by the client when threads are
 * *not* being used.  The ping data is stored in the 
 * registration info structure passed and is used
 * in the next call to SendPong.
 *
 *@param ap_regInfo  This is the structure containing the
 *                   library specific data
 *@param a_timeout  The amount of time to wait for a ping 
 *                  before returning.
 *
 *@return zero on success, non-zero on failure.
 */
int ReadPing(void **ap_regInfo, struct timeval a_timeout)
{
   int data;
   int result;
   SInternalRegistrationInfo *p_regInfo;
   fd_set readSet;

   if (NULL == *ap_regInfo )
   {
      return -EINVAL;    
   }
     
   p_regInfo = static_cast<SInternalRegistrationInfo *>(*ap_regInfo);   

   FD_ZERO(&readSet);
   FD_SET(p_regInfo->readDescriptor, &readSet);
 
   /* wait until there is something to read (i.e. ping)
      this can block indefinitely when NULL */

   if (a_timeout.tv_sec == 0 &&
       a_timeout.tv_usec == 0)
   {
      result = select(p_regInfo->readDescriptor+1, 
                   &readSet, NULL, NULL, NULL);
   }
   else
   { 
      result = select(p_regInfo->readDescriptor+1, 
                   &readSet, NULL, NULL, &a_timeout);
   }
 
   if (result <=  0)
   {
      return -ETIMEDOUT; 
   }

   data = doReadPing(p_regInfo->readDescriptor);
   if (data <0)
   {
      return -EMSGSIZE;
   } 
   else
   {
      p_regInfo->lastData = data;
   }

   return 0;
} 
 

/**
 *  Reads the ping data from the fifo.
 *
 * @param a_fifoDescriptor The file descriptor of the fifo to read from
 * @return On success, the ping specific data which is non-negative; negative on failure
 */
int doReadPing(int a_fifoDescriptor)
{
   /* the structure containing the pong information */
   SPingData ping;
   ssize_t bytes;

#ifdef DEBUG
   fprintf(stderr, "doReadPing\n");
#endif
 
   /* data should be ready to be read */
   bytes = read(a_fifoDescriptor,&ping, sizeof(ping));
   if (bytes == sizeof(ping))
   {
      return ping.pingData;
   }
#ifdef DEBUG
   fprintf(stderr, " not enough data in fifo\n");
#endif
   return -1;
}

/**
 *  Reads the initial ping data from the fifo.
 *
 * @param a_fifoDescriptor The file descriptor of the fifo to read from
 * @param a_pongFifoName a pointer to a string that will be filled with the fifo name sent from the monitor.
 * @return The ping specific data which is non-zero on success; zero on failure
 */
int ReadInitialPing(int a_fifoDescriptor, char ** a_pongFifoName)
{
   /* the structure containing the pong information */
   SInitialPingData ping;
   ssize_t bytes;

#ifdef DEBUG
   fprintf(stderr, "ReadInitialPing\n");
#endif
 
   /* data should be ready to be read */
   bytes = read(a_fifoDescriptor,&ping, sizeof(ping));
   if (bytes == sizeof(ping))
   {
      *a_pongFifoName = strdup(ping.fifoName);
      return ping.pingData;
   }
#ifdef DEBUG
   fprintf(stderr, " not enough data in fifo\n");
#endif
   return 0;
}

/**
 * Initializes the message queue and also creates
 * a unique filename for the fifo and opens it.
 * If either the message queue initialization fails
 * or the pipe creation fails, then this function
 * will return the error and registration will not
 * work.
 * 
 * It should be noted that this function sets the
 * signal handler for SIGPIPE to SIG_IGN so that these
 * signals are ignored.  It is possible that when an 
 * application unregisters, that the heartbeat monitor
 * will send it a ping at the same time (or thereabouts).
 * In this case the application should continue to respond
 * to the monitor's pings until it receives confirmation 
 * that it can discontinue.  The timing of waiting for
 * a confirmation ping and responding to pending pings
 * may cause the application to write a pong after the
 * heartbeat monitor has closed the communication channel.
 * Thus, a broken pipe signal will be sent to the client
 * application -- however, in this case it is of no 
 * concern.
 *
 * @param ap_clientInfo The structure which is filled with
 *           information to be used during registration.
 *
 * @param ap_regInfo The registration information is returned
 *           here.  The client does not have to free this as
 *           long as shutdown is called. This is cast to
 *           a SInternalRegistrationInfo structure and the readFifoName, 
 *           readDescriptor and messageQueueId are filled.
 *
 * @returns zero on success or negative on failure. Also
 *          fills in the read descriptor, messageQueue
 *          identifier and readFifoName of the structure provided.
 *
 * 
 */
int Initialize(SClientRegistrationInfo *ap_clientInfo, void **ap_regInfo)
{
#ifdef DEBUG
   printf("In library function: Initialize\n");
   fflush(NULL);
#endif

   SInternalRegistrationInfo *p_regInfo = NULL; 

   *ap_regInfo = NULL;

   if (!ap_clientInfo)
   {
      return -1; 
   }

   p_regInfo = (SInternalRegistrationInfo*) malloc(sizeof(SInternalRegistrationInfo));
   if (!p_regInfo)
   {
      *ap_regInfo = NULL;
      return -2;
   }

   /* get the message queue id for the "name" 1234, which was
      created by the server. 
      TODO:  fix the name*/
   key_t key = 1234;
   int msgflg = (S_IWUSR | S_IWGRP | S_IWOTH);
   int msqid;

   /* Ignore broken pipe signal */
   signal(SIGPIPE, SIG_IGN);

   /* Attempt to create the communication fifo on which
      to receive pings */
#ifdef DEBUG
   printf("About to call CreateFifo\n");
#endif
   
   p_regInfo->readDescriptor = CreateFifo(p_regInfo->readFifoName);

   if (0 == p_regInfo->readDescriptor)
   { 
      free(p_regInfo);
      p_regInfo = NULL;
      return -1;
   }
 
#ifdef DEBUG
   fprintf(stderr, "Initializing message queue...\n");
#endif
 
   if ((msqid = msgget(key, msgflg)) < 0 )
   {
#ifdef DEBUG
      fprintf(stderr, "error initializing message queue (%d) \n", errno);
      perror("msgget");
#endif
      free(p_regInfo);
      p_regInfo = NULL;
      return -2;
   }

#ifdef DEBUG
   fprintf(stderr, "successful\n");
#endif

   p_regInfo->messageQueueId = msqid;

   *ap_regInfo = (void *)p_regInfo;

   return 0; 
}

/**
 * Creates the fifo for reading pings.  
 *
 * @param a_readfifoName The return location for the read fifo name
 *
 * @returns file descriptor of the fifo, on success; negative value on 
 *          failure.
 */
int CreateFifo(char a_readFifoName[STRING_LENGTH])
{
   int  readDescriptor;
   char *temp;
 
   /* Create fifo for reading pings   */
#ifdef DEBUG
   fprintf(stderr, "Creating fifo for reading pings\n");
#endif
 
   sprintf(a_readFifoName, "/tmp/%d_pings_XXXXXX", getpid());
   temp = mktemp((char*) a_readFifoName);
   strncpy(a_readFifoName, temp, STRING_LENGTH);
   if (!temp)
   {
#ifdef DEBUG
      perror("mktemp");
#endif
      a_readFifoName = NULL;
      return -1;
   }
#ifdef DEBUG
   fprintf(stderr, "readName = (%s)\n", a_readFifoName);
#endif
 
   if (a_readFifoName && 0 == mkfifo(a_readFifoName, 0x1FF))
   {
      readDescriptor = open(a_readFifoName, O_RDWR);
      if (readDescriptor <= 0)
      {
#ifdef DEBUG
         fprintf(stderr, "Could not open fifo for reading\n");
         perror("open");
#endif
         a_readFifoName = NULL;
         return -2;
      }
   }
   else
   {
#ifdef DEBUG
      fprintf(stderr, "Could not create unique fifo\n");
#endif
      return -3;
   }

   return readDescriptor;
}

/**
 * The message queue identifier created from initialization
 * is passed to this function, along with the application's
 * registration information.  This is then packaged and 
 * placed on the message queue for the Application Heartbeat
 * Monitor to retrieve and process.
 *
 * @param a_regInfo Contains the information needed for registration. Return values are also placed here for use during unregistration.
 *
 * a_messageQueueId The identifier of the message queue
 *        obtained from initialization.
 * a_pid The process identifier of the application being
 *        monitored
 * a_frequency The frequency in milliseconds between
 *        each ping.
 * a_recoveryScript The full path to the recovery script
 * a_readFifoName The name of the fifo on which to accept
 *        pings.  This is obtained from the initialization function.
 * a_readDescriptor The descriptor associated with the read
          fifo.  This is obtained from the initialization function.
 * a_useThreads a boolean value that indicates if this app should use
 *           threads to communicate.
 * @returns non-zero on failure, zero on success
 */
int RegisterApplication(SClientRegistrationInfo *ap_clientInfo,
                        void **ap_regInfo, int a_useThreads)
{
   SRegistrationInfo          registration;
   size_t                     messageLength;
   char                      *p_pongFifoName;
   int                        data;
   SInternalRegistrationInfo *p_regInfo;

   if (NULL == *ap_regInfo || NULL == ap_clientInfo)
   {
      return 4;    
   }
   
   p_regInfo = static_cast<SInternalRegistrationInfo *>(*ap_regInfo);   

   if (ap_clientInfo->path == NULL)
   {
      return 1;
   }

   if (p_regInfo->writeFifoName == NULL)
   {
      return 2;
   }
   
   /* Fill in registration information /////////////// */
 
   registration.type = REGISTRATION_INFO;
   registration.pid = (int) ap_clientInfo->pid;
   registration.frequency = (int) ap_clientInfo->frequency;

   strncpy(registration.path, 
           ap_clientInfo->path, 
           STRING_LENGTH);

   /* the server will WRITE to this pipe and the client will
      READ from it */
   strncpy(registration.fifo,  
           p_regInfo->readFifoName, 
           STRING_LENGTH);

   strncpy(registration.appName, 
           ap_clientInfo->appName,  
           STRING_LENGTH);

   /* readFifoName, readDescriptor, messageQueueId 
      already filled from initialize function. 
      Still need writeDescriptor (obtained after 
      getting initial ping), and thread_id */

   /* //////////////////////////////////////////////////// 
    This is the length of the message minus the long integer for
    the type. The message is supposed to be of the form of
    struct msgbuf which takes a long and a char array.
    */
   messageLength = REGISTRATION_INFO_SIZE; 
 
 
#ifdef DEBUG
   fprintf(stderr,"Send registration message to queue\n");
#endif
   /* send the message */
   if (msgsnd(p_regInfo->messageQueueId, &registration, 
              messageLength, IPC_NOWAIT) < 0)
   {
#ifdef DEBUG
      fprintf(stderr, "Error sending message\n");
#endif
      return 3;
   }
 
   /* Wait for the initial ping so the pong fifo can be opened */
   data = GetInitialPing(p_regInfo->readDescriptor, &p_pongFifoName);

   if (data <= 0)
   {
      return 4;
   } 

   strncpy(p_regInfo->writeFifoName, 
           p_pongFifoName, STRING_LENGTH);

   /* copy the client registration info (pid, appname, etc.) to
      the internal registration info structure */
   p_regInfo->regInfo = *ap_clientInfo;
   p_regInfo->lastData = data;

   if (a_useThreads)
   {
      /* Create thread that handles pings  */
      StartPingThread(p_regInfo, data);
   }
   else 
   {
      /* open the writeFifo and send initial ping */
      p_regInfo->writeDescriptor = open(p_regInfo->writeFifoName, O_WRONLY);
      if (p_regInfo->writeDescriptor < 0 )
      {
         return errno; 
      }

      /* on success, the application must now send a pong */
   }
   return 0;
}

/**
 * This function unregisters an application by sending an
 * unregistration pong to the message queue.  It is possible that
 * the pong will coincide with another pong from the thread,
 * however, it will be queued for the App heartbeat monitor
 * to retrieve.  The monitor will send a confirmation ping
 * to the thread which will signal it to end.
 *
 * @param a_writeDescriptor The descriptor for writing pongs to. 
 * @param a_pid The pid of the application unregistering
 * @param a_readFifoName[STRING_LENGTH] The name of the read
 *              fifo that was passed during registration
 * @return zero on success; non-zero on failure
 *
 */
const int UnregisterApplication(void **ap_regInfo)
{
   SInternalRegistrationInfo *p_regInfo;

#ifdef DEBUG
   printf("UnregisterApplication (library)\n");
#endif
   
   if (!*ap_regInfo)
   {
/*
      ErrorHandler::LogMessage(LOG_ERR, "Unable to unregister due to invalid registration info.\n");
*/
      return 1;
   } 
   
   p_regInfo  = static_cast<SInternalRegistrationInfo *>(*ap_regInfo);

   /* Send an unregistration ping to the monitor, then
    this app will get a confirmation ping and terminate
    the thread  */
   if (0 != doSendPong(p_regInfo->writeDescriptor, 0, p_regInfo->regInfo.pid))
   {
      /* there was an error unregistering */
      /* perhaps the AHM is down (??) */
      return 2;
   }

