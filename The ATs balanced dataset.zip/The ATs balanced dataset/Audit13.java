public class OAFormAuditing extends OAFormEditDomain {
    
    public static String HISTORY_FORM = "/common/history_form";    
    
    public OAFormAuditing() {
        setFormView(HISTORY_FORM);
    }

    protected void getModel(Map model, HttpServletRequest request, Object command) throws Exception {
        super.getModel(model, request, command);
        
        List history = AuditUtil.getAuditing((Auditable)command);
        model.put("_commandHistory", history);
    }
    
    public String getTitle(HttpServletRequest request, Object command) {
        return GetText.get("History") + " - " + super.getTitle(request, command);
    }    
}

public class AuditUtil {
    
    public static List getAuditing(Auditable auditable) {
        ValueListInfo info = new ValueListInfo();        
        info.addSortColumn(OABeanUtil.TIMESTAMP_FIELD, ColumnSort.DESC);   
        info.addSortColumn(OABeanUtil.VERSION_FIELD, ColumnSort.DESC); 
        info.addFilterNamedParam("who.class", Op.EQUALS, OAClassUtil.getPersistentClassName(auditable));
        return OADomainUtil.getReferencesTo(AuditAction.class, "who.id", (Identifiable)auditable, info);
    }
    
    public static List getLineItemAuditing(Auditable auditable, AuditableLine line, ValueListInfo info) {
        
        Class auditableLineClass = line.getAuditLogClass();        
        
        if (info == null)
        	info = new ValueListInfo();        
        info.addSortColumn(OABeanUtil.ID_FIELD, ColumnSort.ASC);
        info.addFilterNamedParam("sourceLineId", Op.EQUALS, ((BaseObject)line).getId().toString());
        info.addFilterNamedParam("parent.clazz", Op.EQUALS, auditable.getAuditLogClass().getName());
        return OADomainUtil.getAll(auditableLineClass, info);
    }      
    
    /**
     * Delete all the auditing for a given auditable object
     */
    public static void deleteAuditing(Auditable auditable) {
    	Iterator i = getAuditing(auditable).iterator();
        while (i.hasNext())
            OADomainUtil.remove(i.next());
    }
    
    /**
     * Delete all the auditing for a given auditable object, except for the first and last auditing entries
     */    
    public static void deleteIntermediateAuditing(Auditable auditable) {
    	throw new IllegalArgumentException("deleteIntermediateAuditing is untested");
    	
    	/*List vl = getAuditing(auditable);
    	for (int i=1;i<vl.size()-1;i++)
    		OADomainUtil.remove(vl.get(0));*/
    }    
    
    // -------------------------------------------        
    
    public static void handleAdd(Auditable auditable) {
        checkTypeAndExists(auditable, false);          

        AuditAddAction addAction = new AuditAddAction();
        addAction.setWho((BaseObjectConcrete)auditable);
        addAction.setUser(Auth.getCurrentUserName());
        
        // make a copy of the target object to save in the audit log
        addAction.setWhat((BaseObject)newAuditLogObject(auditable, addAction));

        OADomainUtil.add(addAction);  
    }
    
    public static void handlePrint(Auditable auditable) {
       checkTypeAndExists(auditable, true);          

       AuditPrintAction printAction = new AuditPrintAction((BaseObjectConcrete)auditable, 
                                                                    null, Auth.getCurrentUserName());        
       OADomainUtil.add(printAction);       
    }
    
    public static void handleUpdate(Auditable auditable) {
        checkTypeAndExists(auditable, true);        
        
        AuditUpdateAction updateAction = new AuditUpdateAction();
        updateAction.setWho((BaseObjectConcrete)auditable);
        updateAction.setUser(Auth.getCurrentUserName());
                
        // create an audit log object (copy of target object)
        updateAction.setWhat((BaseObject)newAuditLogObject(auditable, updateAction));

        OADomainUtil.add(updateAction);         
    }
    
    public static void handleDelete(Auditable auditable) {
        checkTypeAndExists(auditable, true);
        
        deleteAuditing(auditable);        
    }
    
    // -------------------------------------------    
    
    private static void checkTypeAndExists(Auditable auditable, boolean requireSaved) {
        // must be BaseObjectConcrete (as well as Auditable)
        if (!(auditable instanceof BaseObjectConcrete))
            throw new IllegalArgumentException("AuditUtil action : Object (" + auditable +") must be BaseObjectConcrete");
        
        if (requireSaved) {
            // version must not be null (ie. it's already saved)
            if (OABeanUtil.getVersion(auditable) == null)
                throw new IllegalArgumentException("AuditUtil.handleUpdate : Object (" + auditable +") does not have a version, it is a new instance.");            
        }
        
        if (!requireSaved) {
            // version must be zeri (ie. it's just been saved)
            if (OABeanUtil.getVersion(auditable).intValue() != 0)
                throw new IllegalArgumentException("AuditUtil.handleAdd : Object (" + auditable +") has a version > 0, it is not a new instance.");
        }
    }
    
    // -------------------------------------------    
    
/*    private static AuditAction getLastAudit(Auditable auditable) {
        // get the last audit log entry for auditable where there is a valid what
        // some audit entries, like print, do not store a what, so we want to skip those when searching
        ValueListInfo info = new ValueListInfo();
        info.addFilter("what","is not","null");
        info.addSortColumn(OABeanUtil.TIMESTAMP_FIELD, ColumnSort.DESC);
        info.setLimit(1);        
        
        ValueList all = OADomainUtil.getAll(AuditAction.class, info);

        if (all.size() ==0) 
            throw new IllegalArgumentException("No valid last audit entry found for (" + auditable + ")");
            
        return (AuditAction)all.next();
    }*/
    
    private static AuditLog newAuditLogObject(Auditable auditable, AuditAction action) {
        AuditLog auditLog = (AuditLog)BeanUtils.instantiateClass(auditable.getAuditLogClass());
        
        String ignoreProperties[] = {OABeanUtil.ID_FIELD, OABeanUtil.VERSION_FIELD, OABeanUtil.CLASS_FIELD};
        auditLog.setAction(action);
        auditLog.copyFrom(auditable, action);
        return auditLog;  
    }    
}

public class AuditPostAdvisor extends CommonAdvisor {
	
	public boolean supports(Object target) {
		return (target instanceof Auditable);
	}	
    
    public void add(Object target, BaseServiceManager manager) {
        // it is imperative that the session is flushed before auditing is added because it
        // requires up-to-date information
        // this definitely comes with a performance penalty
        manager.flush();                  
        AuditUtil.handleAdd((Auditable)target);
    }
    
    public void update(Object target, BaseServiceManager manager) {
        // it is imperative that the session is flushed before auditing is added because it
        // requires up-to-date information  
        // this definitely comes with a performance penalty                 
        manager.flush();
        AuditUtil.handleUpdate((Auditable)target);
    }    
    
    public void print(Object target, BaseServiceManager manager) {
        AuditUtil.handlePrint((Auditable)target);          
    }     
    
    public void remove(Object target, BaseServiceManager manager) {
        AuditUtil.handleDelete((Auditable)target);          
    }     
}

	protected void postRemove(Object obj) {
        PurchaseOrder po = (PurchaseOrder)obj;        
        POPlanning planning = po.getPlanning();
        // remove the planning auditing
        AuditUtil.deleteAuditing((Auditable)planning);
        
        super.postRemove(obj);
	}

