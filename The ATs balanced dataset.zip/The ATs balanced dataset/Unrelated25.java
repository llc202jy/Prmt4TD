package amalgam.server;

import java.sql.*;
import java.util.Enumeration;
import amalgam.util.LoggingProxy;
import amalgam.interfaces.ClientServerCommunication;
import amalgam.util.*;

public class ServerDataManager implements ClientServerCommunication{
  private Connection conn;
  private ConnectionManager conMan;
  protected LoggingProxy logProxy;
  public void setConnectionManager(ConnectionManager _cm) throws Exception{
    conMan = _cm;
    conn = conMan.getConnection();
    resetDataBase();
  }

  private void validateConnection() throws Exception{
    conn = conMan.getConnection();
  }

  private void resetDataBase(){
    PreparedStatement cleanClients = null;
    PreparedStatement cleanClienModules = null;
    PreparedStatement cleanArgs = null;
    try {
      logProxy.log("Cleaning database client and clientmodules tables");
      validateConnection();
      cleanClients = conn.prepareStatement("delete"
                +" from"
                +" clients");

      cleanClienModules = conn.prepareStatement("delete"
                +" from"
                +" clientmodules");
      cleanArgs = conn.prepareStatement("delete"
                +" from"
                +" arguements");
      cleanClients.executeUpdate();
      cleanClienModules.executeUpdate();
      cleanArgs.executeUpdate();

    } catch (Exception ex) {
      logProxy.log(ex);
    } finally {
      try {cleanClients.close();} catch (Exception ex) {}
      try {cleanClienModules.close();} catch (Exception ex) {}
      try {cleanArgs.close();} catch (Exception ex) {}
    }
  }

  public void deleteClient(String clientName, int threadID){
    PreparedStatement select = null;
    PreparedStatement remove = null;
    PreparedStatement removeMods = null;
    PreparedStatement removeArgs = null;
    ResultSet rset = null;
    try {
      validateConnection();

      select = conn.prepareStatement("select"
                +" clientid"
                +" from"
                +" clients"
                +" where"
                +" clientname = ?"
                +" and threadid = ?");
      select.setString(1,clientName);
      select.setInt(2,threadID);
      rset = select.executeQuery();
      if(rset.next()){
            insertMod.setInt(5, mod.getModuleType());
            insertMod.setString(6, mod.getClassName());
            insertMod.executeUpdate();
            //------------- LOAD ANY ARGUEMENTS -------------//
            if (mod.size() > 0) {
              selectModID.setInt(1, clientid);
              selectModID.setString(2, mod.getModName());
              rset = selectModID.executeQuery();
              if (rset.next()) {
                modid = rset.getInt("moduleid");
                for (int loc = 0; loc < mod.size(); loc++) {
                  insertArg.setInt(1, clientid);
                  insertArg.setInt(2, modid);
                  insertArg.setString(3, mod.getArgName(loc));
                  insertArg.executeUpdate();
                } //end for
              } //end rset.next
            } //end mod-size > 0
            result = ACK;
          }//end while
