public final class AuditTrail
{
    // static private Logger _log = Logger.getLogger( AuditTrail.class );

    ConfigurationManager _confManager;
    
    SimpleAnalyzer _analyzer;

    public AuditTrail( ConfigurationManager confManager )
    {
        _confManager = confManager;
        _analyzer = new SimpleAnalyzer();
    }

    public boolean isActionActive( String realmId, AuditTrailConfActionType type )
    {
        // Beware. This class is a singleton.

        if ( _confManager.isAuditTrailActive( realmId, type ) )
            return true;
        return false;
    }

    public void recordAction( AuditTrailConfActionType type, String userid,
            UUID uuid, int version, Worker worker, Archive archive )
            throws SQLException, IOException
    {
        // Beware. This class is a singleton.

        GregorianCalendar gc = new GregorianCalendar();
        gc.setTimeInMillis( System.currentTimeMillis() );
        
        final String uuids = uuid.toString();
        
        StringBuilder strBuild = new StringBuilder( uuids );
        strBuild.append( '|' );
        strBuild.append( gc.getTime() );
        strBuild.append( '|' );
        strBuild.append( gc.getTimeInMillis() );
        strBuild.append( '|' );
        strBuild.append( version );
        strBuild.append( '|' );
        strBuild.append( userid );
        strBuild.append( '|' );
        strBuild.append( archive.getRealmId() );
        strBuild.append( '|' );
        strBuild.append( archive.getId() );
        strBuild.append( '|' );
        strBuild.append( type.toString() );
        strBuild.append( '\n' );

        worker.lockIndex( archive );

        try
        {
            AuditTrailFile atf = archive.getAuditTrailFile( gc );
            
            long pos = atf.getOutputStream().getChannel().position();
            atf.getOutputStream().write( strBuild.toString().getBytes() );
            
            Document doc = new Document();
            
            doc.add( new Field( "uuid", uuids,
                    Field.Store.NO, Field.Index.UN_TOKENIZED ) );
            doc.add( new Field( "file", atf.getFileName(),
                    Field.Store.YES, Field.Index.NO ) );
            doc.add( new Field( "pos", Long.toString( pos ),
                    Field.Store.YES, Field.Index.NO ) );
            
            IndexWriter writer = new IndexWriter( atf.getIndexDir(), _analyzer, false );
            writer.addDocument(  doc );  
            writer.close();
            // FIXME audit trail index optimization
        }

        finally
        {
            worker.unlockIndex();
        }

    }

    /**
     * Close audit trails handlles
     * 
     */
    public void shutdown()
    {
    }

    /*
     * public void importAction( UUID uuid, AuditTrailExp audExp, Worker worker,
     * Archive archive ) throws SQLException { // Beware. This class is a
     * singleton.
     * 
     * AuditTrailEntity audEnt = new AuditTrailEntity(); audEnt.setAction(
     * audExp.getAction() ); audEnt.setUuidObj( uuid ); audEnt.setVersion(
     * audExp.getVersion() ); audEnt.setActor( audExp.getActor() );
     * audEnt.setActionDate( audExp.getActionDate() );
     * archive.getRdbms().insertAuditTrail( worker.getConnection(), archive,
     * worker, audEnt );
     *  }
     */

}