package net.sourceforge.concurrentQuery.test.domain;
package net.sourceforge.concurrentQuery.test.domain;

import net.sourceforge.concurrentQuery.domain.ResolvableFromConcurrentQuery;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;

public class CityList implements ResolvableFromConcurrentQuery {

    private HashSet<Integer> idSet;

    public CityList() {

    }

    public boolean processResultSet(ResultSet rs) throws SQLException {
        idSet = new HashSet<Integer>();

        if (rs != null) {
            while (rs.next()) {
                idSet.add(rs.getInt("id"));
            }
        }

        return true;

    }

    public int size() {
        return idSet.size();
    }

}package net.sourceforge.concurrentQuery.domain;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface ResolvableFromConcurrentQuery {
    boolean processResultSet(ResultSet rs) throws SQLException;
}ublic void run() {
	        Statement statement = null;
	        try {
	            statement = connection.createStatement();
	           if (statement.execute(query)) {
	               resultSet = statement.getResultSet();
	               connection.close();
	           }
	        } catch (SQLException e) {
	            sqlException = e;
	        }ublic SQLException getSQLException() {
			return sqlException;
		}
		
		public ResultSet getResultSet() {
			return resultSet;
		}
		
		public boolean isAlive() {
			return !future.isDone();
		}
		
			
		}
		public SQLException getSQLException() {
			return sqlException;
		}
		public ResultSet getResultSet() {
			return resultSet;
		}
package net.sourceforge.concurrentQuery.query;

import net.sourceforge.concurrentQuery.domain.ResolvableFromConcurrentQuery;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

public abstract class ConcurrentQuery implements ConcurrentQueryInterface {

    private static Logger logger = Logger.getLogger(ConcurrentQuery.class);
    private String jdbcURL = null;
    private int maxConcurrentQueries = 3;
    private ConcurrentHashMap<ResolvableFromConcurrentQuery, String> queuedQueries;
    private ConcurrentHashMap<QueryRunnerInterface, QueryRunnerWorkUnit> activeQueryRunners;

    protected ConcurrentQuery() {}
    
    public ConcurrentQuery(int maxConcurrent, String jdbcURL, String jdbcUser, String jdbcPasswd) throws SQLException {

        if (maxConcurrent > 0) {
            maxConcurrentQueries = maxConcurrent;
        }

        this.jdbcURL = jdbcURL;
        DriverManager.getConnection(jdbcURL, jdbcUser, jdbcPasswd).close();

        queuedQueries = new ConcurrentHashMap<ResolvableFromConcurrentQuery, String>();
        activeQueryRunners = new ConcurrentHashMap<QueryRunnerInterface, QueryRunnerWorkUnit>();
    }

    public void addQueryToQueue(String query, ResolvableFromConcurrentQuery resolvableDomainObject) {
    		getQueuedQueries().put(resolvableDomainObject, query);
    }

    public int getMaxConcurrentQueries() {
        return maxConcurrentQueries;
    }

    public String getJDBCURL() {
        return jdbcURL;
    }

    public ConcurrentHashMap<ResolvableFromConcurrentQuery, String> getQueuedQueries() {
        return queuedQueries;

import net.sourceforge.concurrentQuery.domain.ResolvableFromConcurrentQuery;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;

public class CityList implements ResolvableFromConcurrentQuery {

    private HashSet<Integer> idSet;

    public CityList() {

    }

    public boolean processResultSet(ResultSet rs) throws SQLException {
        idSet = new HashSet<Integer>();

        if (rs != null) {
            while (rs.next()) {
                idSet.add(rs.getInt("id"));
            }
        }

        return true;

    }

    public int size() {
        return idSet.size();
    }

}package net.sourceforge.concurrentQuery.domain;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface ResolvableFromConcurrentQuery {
    boolean processResultSet(ResultSet rs) throws SQLException;
}ublic void run() {
	        Statement statement = null;
	        try {
	            statement = connection.createStatement();
	           if (statement.execute(query)) {
	               resultSet = statement.getResultSet();
	               connection.close();
	           }
	        } catch (SQLException e) {
	            sqlException = e;
	        }ublic SQLException getSQLException() {
			return sqlException;
		}
		
		public ResultSet getResultSet() {
			return resultSet;
		}
		
		public boolean isAlive() {
			return !future.isDone();
		}
		
			
		}
		public SQLException getSQLException() {
			return sqlException;
		}
		public ResultSet getResultSet() {
			return resultSet;
		}
