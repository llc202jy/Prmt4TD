	_cli_client_delete_callback = v;
    }

    //
    // Debug-related methods
    //
    
    /**
     * Test if trace log is enabled.
     * 
     * This method is used to test whether to output trace log debug messges.
     * 
     * @return true if trace log is enabled, otherwise false.
     */
    bool	is_log_trace() const { return (_is_log_trace); }
    
    /**
     * Enable/disable trace log.
     * 
     * This method is used to enable/disable trace log debug messages output.
     * 
     * @param is_enabled if true, trace log is enabled, otherwise is disabled.
     */
    void	set_log_trace(bool is_enabled) { _is_log_trace = is_enabled; }
    
private:
    friend class CliClient;
    
    //
    // Internal CLI commands
    //
    int		add_internal_cli_commands(string& error_msg);
    int		cli_show_log(const string& server_name,
			     const string& cli_term_name,
			     uint32_t cli_session_id,
			     const vector<string>& command_global_name,
			     const vector<string>& argv);
    int		cli_show_log_user(const string& server_name,
				  const string& cli_term_name,
				  uint32_t cli_session_id,
				  const vector<string>& command_global_name,
				  const vector<string>& argv);
    int		cli_set_log_output_cli(const string& server_name,
				       const string& cli_term_name,
				       uint32_t cli_session_id,
				       const vector<string>& command_global_name,
				       const vector<string>& argv);
    int		cli_set_log_output_file(const string& server_name,
					const string& cli_term_name,
					uint32_t cli_session_id,
					const vector<string>& command_global_name,
					const vector<string>& argv);
    int		cli_set_log_output_remove_cli(const string& server_name,
					      const string& cli_term_name,
					      uint32_t cli_session_id,
					      const vector<string>& command_global_name,
					      const vector<string>& argv);
    int		cli_set_log_output_remove_file(const string& server_name,
					       const string& cli_term_name,
					       uint32_t cli_session_id,
					       const vector<string>& command_global_name,
					       const vector<string>& argv);
    
    int send_process_command(const string& server_name,
			     const string& cli_term_name,
			     const uint32_t cli_session_id,
			     const vector<string>& command_global_name,
			     const vector<string>& argv);
    
    XorpFd	sock_serv_open();
    int		sock_serv_close();
    CliClient	*add_connection(XorpFd input_fd, XorpFd output_fd,
				bool is_network,
				const string& startup_cli_prompt,
				string& error_msg);
    int		delete_connection(CliClient *cli_client, string& error_msg);
    void	accept_connection(XorpFd fd, IoEventType type);
    
    bool	is_allow_cli_access(const IPvX& ipvx) const;
    
    XorpFd		_cli_socket;	// The CLI listening socket
    unsigned short	_cli_port;	// The CLI port (network-order) to
					//   listen on for new connections.
    list<CliClient *>	_client_list;	// The list with the CLI clients
    uint32_t		_next_session_id; // Used to assign unique session IDs.
    string		_startup_cli_prompt; // The CLI prompt on startup
    
    CliCommand		_cli_command_root; // The root of the CLI commands
    
    SenderProcessCallback _send_process_command_callback;
    
    // The callback pethod that is invoked whenever a CliClient is deleted
    CliClientDeleteCallback _cli_client_delete_callback;
    
    list<IPvXNet>	_enable_cli_access_subnet_list;
    list<IPvXNet>	_disable_cli_access_subnet_list;

    //
    // Debug and test-related state
    //
