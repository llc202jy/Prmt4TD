 PROJECT:         ReactOS Kernel
 * LICENSE:         GPL - See

typedef struct _D3DHAL_DP2SETRENDERTARGET {
  DWORD hRenderTarget;
  DWORD hZBuffer;
} D3DHAL_DP2SETRENDERTARGET,*LPD3DHAL_DP2SETRENDERTARGET;

typedef struct _D3DHAL_DP2CLEAR {
  DWORD		dwFlags;
  DWORD		dwFillColor;
  D3DVALUE	dvFillDepth;
  DWORD		dwFillStencil;
  RECT		Rects[1];
} D3DHAL_DP2CLEAR,*LPD3DHAL_DP2CLEAR;

typedef struct _D3DHAL_DP2SETTEXLOD {
  DWORD dwDDSurface;
  DWORD dwLOD;
} D3DHAL_DP2SETTEXLOD,*LPD3DHAL_DP2SETTEXLOD;

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* _D3DHAL_H_ *#define SERIAL_ERROR_BREAK                0x00000001
#define SERIAL_ERROR_FRAMING              0x00000002
#define SERIAL_ERROR_OVERRUN              0x00000004
#define SERIAL_ERROR_QUEUEOVERRUN         0x00000008
#define SERIAL_ERROR_PARITY               0x00000010

#define SERIAL_SP_UNSPECIFIED             0x00000000
#define SERIAL_SP_RS232                   0x00000001
#define SERIAL_SP_PARALLEL                0x00000002
#define SERIAL_SP_RS422                   0x00000003
#define SERIAL_SP_RS423                   0x00000004
#define SERIAL_SP_RS449                   0x00000005
#define SERIAL_SP_MODEM                   0X00000006
#define SERIAL_SP_FAX                     0x00000021
#define SERIAL_SP_SCANNER                 0x00000022
#define SERIAL_SP_BRIDGE                  0x00000100
#define SERIAL_SP_LAT                     0x00000101
#define SERIAL_SP_TELNET                  0x00000102
#define SERIAL_SP_X25                     0x00000103
#define SERIAL_SP_SERIALCOMM              0x00000001

#define SERIAL_TX_WAITING_FOR_CTS         0x00000001
#define SERIAL_TX_WAITING_FOR_DSR         0x00000002
#define SERIAL_TX_WAITING_FOR_DCD         0x00000004
#define SERIAL_TX_WAITING_FOR_XON         0x00000008
#define SERIAL_TX_WAITING_XOFF_SENT       0x00000010
#define SERIAL_TX_WAITING_ON_BREAK        0x00000020
#define SERIAL_RX_WAITING_FOR_DSR         0x00000040

#define SERIAL_DTR_STATE                  0x00000001
#define SERIAL_RTS_STATE                  0x00000002
#define SERIAL_CTS_STATE                  0x00000010
#define SERIAL_DSR_STATE                  0x00000020
#define SERIAL_RI_STATE                   0x00000040
#define SERIAL_DCD_STATE                  0x00000080

typedef struct _SERIALCONFIG {
  ULONG  Size;
  USHORT  Version;
  ULONG  SubType;
  ULONG  ProvOffset;
  ULONG  ProviderSize;
  WCHAR  ProviderData[1];
} SERIALCONFIG,*PSERIALCONFIG;

#ifdef __cplusplus
}
#endif

#endif /* __NTDDSER_H */
 COPYING in the top level directory
 * FILE:            ntoskrnl/include/hal.h
 * PURPOSE:         Internal header for the I/O HAL Functions (Fstub)
 * PROGRAMMERS:     Alex Ionescu (alex.ionescu@reactos.org)
 */
#ifndef _HAL_
#define _HAL_
/*
 * PROJECT:   registry manipulation library
 * LICENSE:   GPL - See COPYING in the top level directory
 * COPYRIGHT: Copyright 2005 Filip Navara <navaraf@reactos.org>
 *            Copyright 2001 - 2005 Eric Kohl
 */
*
 * PROJECT:   registry manipulation library
 * LICENSE:   GPL - See COPYING in the top level directory
 * COPYRIGHT: Copyright 2005 Filip Navara <navaraf@reactos.org>
 *            Copyright 2001 - 2005 Eric Kohl
 */

#ifndef CMLIB_HIVEDATA_H
#define CMLIB_HIVEDATA_H

#define HV_BLOCK_SIZE                  4096
#define HV_LOG_HEADER_SIZE             FIELD_OFFSET(HBASE_BLOCK, Reserved2)
#define HV_SIGNATURE                   0x66676572
#define HV_BIN_SIGNATURE               0x6e696268

#define HV_MAJOR_VER                   1
#define HV_MINOR_VER                   3
#define HV_FORMAT_MEMORY               1

#define HV_TYPE_PRIMARY                0
#define HV_TYPE_ALTERNATE              1
#define HV_TYPE_LOG                    2
#define HV_TYPE_EXTERNAL               3
#define HV_TYPE_MAX                    4

/**
 * @name HCELL_INDEX
 *
 * A handle to cell index. The highest bit specifies the cell storage and
 * the other bits specify index into the hive file. The value HCELL_NULL
 * (-1) is reserved for marking invalid cells.
 */
typedef ULONG HCELL_INDEX, *PHCELL_INDEX;

#define HCELL_NULL                     ((HCELL_INDEX)-1)
#define HCELL_TYPE_MASK                0x80000000
#define HCELL_BLOCK_MASK               0x7ffff000
#define HCELL_OFFSET_MASK              0x00000fff
#define HCELL_TYPE_SHIFT               31
#define HCELL_BLOCK_SHIFT              12
#define HCELL_OFFSET_SHIFT             0

#define HvGetCellType(Cell)             \
    ((ULONG)((Cell & HCELL_TYPE_MASK) >> HCELL_TYPE_SHIFT))

#include <pshpack1.h>

/**
 * @name HBASE_BLOCK
 *
 * On-disk header for registry hive file.
 */

typedef struct _HBASE_BLOCK
{
   /* Hive identifier "regf" (0x66676572) */
   ULONG Signature;

   /* Update counter */
   ULONG Sequence1;

   /* Update counter */
   ULONG Sequence2;
   
   /* When this hive file was last modified */
   LARGE_INTEGER TimeStamp;

   /* Registry format major version (1) */
   ULONG Major;

   /* Registry format minor version (3)
      Version 3 added fast indexes, version 5 has large value optimizations */
   ULONG Minor;

   /* Registry file type (0 - Primary, 1 - Log) */
   ULONG Type;

   /* Registry format (1 is the only defined value so far) */
   ULONG Format;

   /* Offset into file from the byte after the end of the base block.
      If the hive is volatile, this is the actual pointer to the CM_KEY_NODE */
   HCELL_INDEX RootCell;

   /* Size of each hive block ? */
   ULONG Length;

   /* (1?) */
   ULONG Cluster;

   /* Name of hive file */
   CHAR FileName[64];

   ULONG Reserved1[99];

   /* Checksum of first 0x200 bytes */
   ULONG Checksum;

   ULONG Reserved2[0x37E];
   ULONG BootType;
   ULONG BootRecover;
} HBASE_BLOCK, *PHBASE_BLOCK;

typedef struct _HBIN
{
   /* Bin identifier "hbin" (0x6E696268) */
   ULONG Signature;

   /* Block offset of this bin */
   HCELL_INDEX FileOffset;

   /* Size in bytes, multiple of the block size (4KB) */
   ULONG Size;

   ULONG Reserved1[2];

   /* When this bin was last modified */
   LARGE_INTEGER TimeStamp;

   /* ? (In-memory only) */
   ULONG MemAlloc;
} HBIN, *PHBIN;

typedef struct _HCELL
{
   /* <0 if used, >0 if free */
   LONG Size;
} HCELL, *PHCELL;

#include <poppack.h>

#define IsFreeCell(Cell)(Cell->Size >= 0)
#define IsUsedCell(Cell)(Cell->Size < 0)

typedef enum _HV_STORAGE_TYPE
{
   HvStable = 0,
   HvVolatile,
   HvMaxStorageType
} HV_STORAGE_TYPE;

#endif /* CMLIB_HIVEDATA_H */
#ifndef CMLIB_H
#define CMLIB_H

#ifdef CMLIB_HOST
#include <typedefs_host.h>
#include <stdio.h>
#include <string.h>
#include <ntstatus.h>
#endif

#ifndef _TYPEDEFS_HOST_H
 #include <ntddk.h>
#else
 #define REG_OPTION_VOLATILE 1
 #define OBJ_CASE_INSENSITIVE 0x00000040L
 #define USHORT_MAX USHRT_MAX

VOID NTAPI
KeQuerySystemTime(
    OUT PLARGE_INTEGER CurrentTime);

VOID NTAPI
RtlInitializeBitMap(
    IN PRTL_BITMAP BitMapHeader,
    IN PULONG BitMapBuffer,
    IN ULONG SizeOfBitMap);

ULONG NTAPI
RtlFindSetBits(
    IN PRTL_BITMAP BitMapHeader,
    IN ULONG NumberToFind,
    IN ULONG HintIndex);

VOID NTAPI
RtlSetBits(
    IN PRTL_BITMAP BitMapHeader,
    IN ULONG StartingIndex,
    IN ULONG NumberToSet);

VOID NTAPI
RtlClearAllBits(
    IN PRTL_BITMAP BitMapHeader);

#define RtlCheckBit(BMH,BP) (((((PLONG)(BMH)->Buffer)[(BP) / 32]) >> ((BP) % 32)) & 0x1)

#endif

#include <wchar.h>
#include "hivedata.h"
#include "cmdata.h"

#ifndef ROUND_UP
#define ROUND_UP(a,b)        ((((a)+(b)-1)/(b))*(b))
#define ROUND_DOWN(a,b)      (((a)/(b))*(b))
#endif

#define CMAPI NTAPI

struct _HHIVE;

typedef PVOID (CMAPI *PGET_CELL_ROUTINE)(
   struct _HHIVE *Hive,
   HCELL_INDEX Cell);

typedef VOID (CMAPI *PRELEASE_CELL_ROUTINE)(
   struct _HHIVE *Hive,
   HCELL_INDEX Cell);

typedef PVOID (CMAPI *PALLOCATE_ROUTINE)(
   SIZE_T Size,
   BOOLEAN Paged);

typedef VOID (CMAPI *PFREE_ROUTINE)(
   PVOID Ptr);

typedef BOOLEAN (CMAPI *PFILE_READ_ROUTINE)(
   struct _HHIVE *RegistryHive,
   ULONG FileType,
   ULONGLONG FileOffset,
   PVOID Buffer,
   SIZE_T BufferLength);

typedef BOOLEAN (CMAPI *PFILE_WRITE_ROUTINE)(
   struct _HHIVE *RegistryHive,
   ULONG FileType,
   ULONGLONG FileOffset,
   PVOID Buffer,
   SIZE_T BufferLength);

typedef BOOLEAN (CMAPI *PFILE_SET_SIZE_ROUTINE)(
   struct _HHIVE *RegistryHive,
   ULONG FileType,
   ULONGLONG FileSize);

typedef BOOLEAN (CMAPI *PFILE_FLUSH_ROUTINE)(
   struct _HHIVE *RegistryHive,
   ULONG FileType);

typedef struct _HMAP_ENTRY
{
    ULONG_PTR Bin;
    ULONG_PTR Block;
    struct _CM_VIEW_OF_FILE *CmHive;
    ULONG MemAlloc;
} HMAP_ENTRY, *PHMAP_ENTRY;

typedef struct _HMAP_TABLE
{
    HMAP_ENTRY Table[512];
} HMAP_TABLE, *PHMAP_TABLE;

typedef struct _HMAP_DIRECTORY
{
    PHMAP_TABLE Directory[2048];
} HMAP_DIRECTORY, *PHMAP_DIRECTORY;

typedef struct _DUAL
{
    ULONG Length;
    PHMAP_DIRECTORY Map;
    PHMAP_ENTRY BlockList; // PHMAP_TABLE SmallDir;
    ULONG Guard;
    HCELL_INDEX FreeDisplay[24]; //FREE_DISPLAY FreeDisplay[24];
    ULONG FreeSummary;
    LIST_ENTRY FreeBins;
} DUAL, *PDUAL;

typedef struct _HHIVE
{
    ULONG Signature;
    PGET_CELL_ROUTINE GetCellRoutine;
    PRELEASE_CELL_ROUTINE ReleaseCellRoutine;
    PALLOCATE_ROUTINE Allocate;
    PFREE_ROUTINE Free;
    PFILE_READ_ROUTINE FileRead;
    PFILE_WRITE_ROUTINE FileWrite;
    PFILE_SET_SIZE_ROUTINE FileSetSize;
    PFILE_FLUSH_ROUTINE FileFlush;
    PHBASE_BLOCK HiveHeader;
    RTL_BITMAP DirtyVector;
    ULONG DirtyCount;
    ULONG DirtyAlloc;
    ULONG BaseBlockAlloc;
    ULONG Cluster;
    BOOLEAN Flat;
    BOOLEAN ReadOnly;
    BOOLEAN Log;
    BOOLEAN DirtyFlag;
    ULONG HvBinHeadersUse;
    ULONG HvFreeCellsUse;
    ULONG HvUsedcellsUse;
    ULONG CmUsedCellsUse;
    ULONG HiveFlags;
    ULONG LogSize;
    ULONG RefreshCount;
    ULONG StorageTypeCount;
    ULONG Version;
    DUAL Storage[HvMaxStorageType];
} HHIVE, *PHHIVE;

#ifndef _CM_
typedef struct _EREGISTRY_HIVE
{
  HHIVE Hive;
  LIST_ENTRY  HiveList;
  UNICODE_STRING  HiveFileName;
  UNICODE_STRING  LogFileName;
  PCM_KEY_SECURITY  RootSecurityCell;
  ULONG  Flags;
  HANDLE  HiveHandle;
  HANDLE  LogHandle;
} EREGISTRY_HIVE, *PEREGISTRY_HIVE;
#endif

/*
 * Public functions.
 */

#define HV_OPERATION_CREATE_HIVE    0
#define HV_OPERATION_MEMORY         1
#define HV_OPERATION_MEMORY_INPLACE 3

NTSTATUS CMAPI
HvInitialize(
   PHHIVE RegistryHive,
   ULONG Operation,
   ULONG HiveType,
   ULONG HiveFlags,
   ULONG_PTR HiveData OPTIONAL,
   ULONG Cluster OPTIONAL,
   PALLOCATE_ROUTINE Allocate,
   PFREE_ROUTINE Free,
   PFILE_READ_ROUTINE FileRead,
   PFILE_WRITE_ROUTINE FileWrite,
   PFILE_SET_SIZE_ROUTINE FileSetSize,
   PFILE_FLUSH_ROUTINE FileFlush,
   IN PUNICODE_STRING FileName);

VOID CMAPI 
HvFree(
   PHHIVE RegistryHive);

PVOID CMAPI
HvGetCell(
   PHHIVE RegistryHive,
   HCELL_INDEX CellOffset);

#define HvReleaseCell(h, c)     \
    if (h->ReleaseCellRoutine) h->ReleaseCellRoutine(h, c)

LONG CMAPI
HvGetCellSize(
   PHHIVE RegistryHive,
   PVOID Cell);

HCELL_INDEX CMAPI
HvAllocateCell(
   PHHIVE RegistryHive,
   SIZE_T Size,
   HV_STORAGE_TYPE Storage);

BOOLEAN CMAPI
HvIsCellAllocated(
    IN PHHIVE RegistryHive,
    IN HCELL_INDEX CellIndex
);

HCELL_INDEX CMAPI
HvReallocateCell(
   PHHIVE RegistryHive,
   HCELL_INDEX CellOffset,
   ULONG Size);

VOID CMAPI
HvFreeCell(
   PHHIVE RegistryHive,
   HCELL_INDEX CellOffset);

VOID CMAPI
HvMarkCellDirty(
   PHHIVE RegistryHive,
   HCELL_INDEX CellOffset);

BOOLEAN CMAPI
HvIsCellDirty(
    IN PHHIVE Hive,
    IN HCELL_INDEX Cell
);

BOOLEAN CMAPI
HvSyncHive(
   PHHIVE RegistryHive);

BOOLEAN CMAPI
HvWriteHive(
   PHHIVE RegistryHive);

BOOLEAN CMAPI
CmCreateRootNode(
   PHHIVE Hive,
   PCWSTR Name);

VOID CMAPI
CmPrepareHive(
   PHHIVE RegistryHive);

/*
 * Private functions.
 */

PHBIN CMAPI
HvpAddBin(
   PHHIVE RegistryHive,
   ULONG Size,
   HV_STORAGE_TYPE Storage);

NTSTATUS CMAPI
HvpCreateHiveFreeCellList(
   PHHIVE Hive);

ULONG CMAPI
HvpHiveHeaderChecksum(
   PHBASE_BLOCK HiveHeader);/*
 * COPYRIGHT:        See COPYING in the top level directory
 * PROJECT:          ReactOS kernel
 * FILE:             hal/hal.c
 * PURPOSE:          Hardware Abstraction Layer DLL
 * PROGRAMMER:       Casper S. Hornstrup (chorns@users.sourceforge.net)
 * REVISION HISTORY:
 *    01-08-2001 CSH Created
 */

/* INCLUDES ******************************************************************/

#include <ntddk.h>
#include <ntdddisk.h>
#include <arc/arc.h>
#include <intrin.h>
#include <ndk/halfuncs.h>
#include <ndk/iofuncs.h>
#include <ndk/kdfuncs.h>

#define NDEBUG
#include <debug.h>

#undef ExAcquireFastMutex
#undef ExReleaseFastMutex
#undef ExTryToAcquireFastMutex

/* DATA **********************************************************************/

ULONG _KdComPortInUse = 0;

/* FUNCTIONS *****************************************************************/

NTSTATUS
NTAPI
DriverEntry(
  PDRIVER_OBJECT DriverObject,
  PUNICODE_STRING RegistryPath)
{
  UNIMPLEMENTED;

  return STATUS_SUCCESS;
}

/*
* @unimplemented
*/
VOID
NTAPI
HalStopProfileInterrupt(IN KPROFILE_SOURCE ProfileSource)
{
    KEBUGCHECK(0);
    return;
}

/*
* @unimplemented
*/
VOID
NTAPI
HalStartProfileInterrupt(IN KPROFILE_SOURCE ProfileSource)
{
    KEBUGCHECK(0);
    return;
}

/*
* @unimplemented
*/
ULONG_PTR
NTAPI
HalSetProfileInterval(IN ULONG_PTR Interval)
{
    KEBUGCHECK(0);
    return Interval;
}

VOID
FASTCALL
ExAcquireFastMutex(
  PFAST_MUTEX FastMutex)
{
  UNIMPLEMENTED;
}


VOID
FASTCALL
ExReleaseFastMutex(
  PFAST_MUTEX FastMutex)
{
  UNIMPLEMENTED;
}


BOOLEAN FASTCALL
ExTryToAcquireFastMutex(
  PFAST_MUTEX FastMutex)
{
  UNIMPLEMENTED;

  return TRUE;
}


VOID
NTAPI
HalAcquireDisplayOwnership(
  PHAL_RESET_DISPLAY_PARAMETERS ResetDisplayParameters)
{
  UNIMPLEMENTED;
}


NTSTATUS
NTAPI
HalAdjustResourceList(
  PCM_RESOURCE_LIST Resources)
{
  UNIMPLEMENTED;

  return STATUS_SUCCESS;
}


BOOLEAN
NTAPI
HalAllProcessorsStarted(VOID)
{
  UNIMPLEMENTED;

  return TRUE;
}


NTSTATUS
NTAPI
HalAllocateAdapterChannel(
  PADAPTER_OBJECT AdapterObject,
  PWAIT_CONTEXT_BLOCK WaitContextBlock,
  ULONG NumberOfMapRegisters,
  PDRIVER_CONTROL ExecutionRoutine)
{
  UNIMPLEMENTED;

  return STATUS_SUCCESS;
}


PVOID
NTAPI
HalAllocateCommonBuffer(
  PADAPTER_OBJECT AdapterObject,
  ULONG Length,
  PPHYSICAL_ADDRESS LogicalAddress,
  BOOLEAN CacheEnabled)
{
  UNIMPLEMENTED;

  return NULL;
}


PVOID
NTAPI
HalAllocateCrashDumpRegisters(
  PADAPTER_OBJECT AdapterObject,
  PULONG NumberOfMapRegisters)
{
  UNIMPLEMENTED;
  return NULL;
}


NTSTATUS
NTAPI
HalAssignSlotResources(
  PUNICODE_STRING RegistryPath,
  PUNICODE_STRING DriverClassName,
  PDRIVER_OBJECT DriverObject,
  PDEVICE_OBJECT DeviceObject,
  INTERFACE_TYPE BusType,
  ULONG BusNumber,
  ULONG SlotNumber,
  PCM_RESOURCE_LIST *AllocatedResources)
{
  UNIMPLEMENTED;

  return TRUE;
}


BOOLEAN 
NTAPI 
HalBeginSystemInterrupt (KIRQL Irql,
			 ULONG Vector,
			 PKIRQL OldIrql)
{
  UNIMPLEMENTED;

  return TRUE;
}


VOID
NTAPI
HalCalibratePerformanceCounter(
  volatile LONG *Count,
  ULONGLONG NewCount)
{
  UNIMPLEMENTED;
}


BOOLEAN
NTAPI
HalDisableSystemInterrupt(
  ULONG Vector,
  KIRQL Irql)
{
  UNIMPLEMENTED;

  return TRUE;
}


VOID
NTAPI
HalDisplayString(
  PCH String)
{
  UNIMPLEMENTED;
}


BOOLEAN
NTAPI
HalEnableSystemInterrupt(
  ULONG Vector,
  KIRQL Irql,
  KINTERRUPT_MODE InterruptMode)
{
  UNIMPLEMENTED;

  return TRUE;
}


VOID
NTAPI
HalEndSystemInterrupt(
  KIRQL Irql,
  ULONG Unknown2)
{
  UNIMPLEMENTED;
}


BOOLEAN
NTAPI
HalFlushCommonBuffer(
  ULONG Unknown1,
  ULONG Unknown2,
  ULONG Unknown3,
  ULONG Unknown4,
  ULONG Unknown5)
{
  UNIMPLEMENTED;

   return TRUE;
}


VOID
NTAPI
HalFreeCommonBuffer(
  PADAPTER_OBJECT AdapterObject,
  ULONG Length,
  PHYSICAL_ADDRESS LogicalAddress,
  PVOID VirtualAddress,
  BOOLEAN CacheEnabled)
{
  UNIMPLEMENTED;
}


PADAPTER_OBJECT
NTAPI
HalGetAdapter(
  PDEVICE_DESCRIPTION DeviceDescription,
  PULONG NumberOfMapRegisters)
{
  UNIMPLEMENTED;

  return (PADAPTER_OBJECT)NULL;
}


ULONG
NTAPI
HalGetBusData(
  BUS_DATA_TYPE BusDataType,
  ULONG BusNumber,
  ULONG SlotNumber,
  PVOID Buffer,
  ULONG Length)
{
  UNIMPLEMENTED;

  return 0;
}


ULONG
NTAPI
HalGetBusDataByOffset(
  BUS_DATA_TYPE BusDataType,
  ULONG BusNumber,
  ULONG SlotNumber,
  PVOID Buffer,
  ULONG Offset,
  ULONG Length)
{
  UNIMPLEMENTED;

  return 0;
}


ARC_STATUS
NTAPI
HalGetEnvironmentVariable(
  PCH Name,
  USHORT ValueLength,
  PCH Value)
{
  UNIMPLEMENTED;

  return ENOENT;
}


ULONG
NTAPI
HalGetInterruptVector(
  INTERFACE_TYPE InterfaceType,
  ULONG BusNumber,
  ULONG BusInterruptLevel,
  ULONG BusInterruptVector,
  PKIRQL Irql,
  PKAFFINITY Affinity)
{
  UNIMPLEMENTED;

  return 0;
}


VOID
NTAPI
HalHandleNMI(
  PVOID NmiData)
{
  UNIMPLEMENTED;
}


BOOLEAN
NTAPI
HalInitSystem(
  ULONG BootPhase,
  PLOADER_PARAMETER_BLOCK LoaderBlock)
{
  UNIMPLEMENTED;

  return TRUE;
}


VOID
NTAPI
HalInitializeProcessor(ULONG ProcessorNumber,
                       PLOADER_PARAMETER_BLOCK LoaderBlock)
{
  UNIMPLEMENTED;
}


BOOLEAN
NTAPI
HalMakeBeep(
  ULONG Frequency)
{
  UNIMPLEMENTED;

  return TRUE;
}


VOID
NTAPI
HalProcessorIdle(VOID)
{
  UNIMPLEMENTED;
}


BOOLEAN
NTAPI
HalQueryDisplayOwnership(VOID)
{
  UNIMPLEMENTED;

  return FALSE;
}


VOID
NTAPI
HalQueryDisplayParameters(
  OUT PULONG DispSizeX,
  OUT PULONG DispSizeY,
  OUT PULONG CursorPosX,
  OUT PULONG CursorPosY)
{
  UNIMPLEMENTED;
}


BOOLEAN
NTAPI
HalQueryRealTimeClock(
  PTIME_FIELDS Time)
{
  UNIMPLEMENTED;
  return FALSE;
}


ULONG
NTAPI
HalReadDmaCounter(
  PADAPTER_OBJECT AdapterObject)
{
  UNIMPLEMENTED;
  
  return 0;
}


VOID
NTAPI
HalReleaseDisplayOwnership(VOID)
{
  UNIMPLEMENTED;
}

VOID
NTAPI
HalReportResourceUsage(VOID)
{
  UNIMPLEMENTED;
}


VOID
NTAPI
HalRequestIpi(
  ULONG Unknown)
{
  UNIMPLEMENTED;
}


VOID
FASTCALL
HalRequestSoftwareInterrupt(
  KIRQL Request)
{
  UNIMPLEMENTED;
}

VOID FASTCALL
HalClearSoftwareInterrupt(
  IN KIRQL Request)
{
  UNIMPLEMENTED;
}


VOID
NTAPI
HalReturnToFirmware(
  FIRMWARE_REENTRY Action)
{
  UNIMPLEMENTED;
}


ULONG
NTAPI
HalSetBusData(
  BUS_DATA_TYPE BusDataType,
  ULONG BusNumber,
  ULONG SlotNumber,
  PVOID Buffer,
  ULONG Length)
{
  UNIMPLEMENTED;

  return 0;
}


ULONG
NTAPI
HalSetBusDataByOffset(
  BUS_DATA_TYPE BusDataType,
  ULONG BusNumber,
  ULONG SlotNumber,
  PVOID Buffer,
  ULONG Offset,
  ULONG Length)
{
  UNIMPLEMENTED;

  return 0;
}


VOID
NTAPI
HalSetDisplayParameters(
  ULONG CursorPosX,
  ULONG CursorPosY)
{
  UNIMPLEMENTED;
}


ARC_STATUS
NTAPI
HalSetEnvironmentVariable(
  PCH Name,
  PCH Value)
{
  UNIMPLEMENTED;

  return ESUCCESS;
}


BOOLEAN
NTAPI
HalSetRealTimeClock(
  PTIME_FIELDS Time)
{
  UNIMPLEMENTED;

  return TRUE;
}


ULONG
NTAPI
HalSetTimeIncrement(
  ULONG Increment)
{
  UNIMPLEMENTED;

  return Increment;
}


BOOLEAN
NTAPI
HalStartNextProcessor(IN PLOADER_PARAMETER_BLOCK LoaderBlock,
                      IN PKPROCESSOR_STATE ProcessorState)
{
  UNIMPLEMENTED;

  return TRUE;
}


ULONG
FASTCALL
HalSystemVectorDispatchEntry(
  ULONG Unknown1,
  ULONG Unknown2,
  ULONG Unknown3)
{
  UNIMPLEMENTED;

  return 0;
}


BOOLEAN
NTAPI
HalTranslateBusAddress(
  INTERFACE_TYPE InterfaceType,
  ULONG BusNumber,
  PHYSICAL_ADDRESS BusAddress,
  PULONG AddressSpace,
  PPHYSICAL_ADDRESS TranslatedAddress)
{
  UNIMPLEMENTED;

  return TRUE;
}


VOID
NTAPI
HalpAssignDriveLetters(IN struct _LOADER_PARAMETER_BLOCK *LoaderBlock,
                       IN PSTRING NtDeviceName,
                       OUT PUCHAR NtSystemPath,
                       OUT PSTRING NtSystemPathString)
{
    /* Call the kernel */
    IoAssignDriveLetters(LoaderBlock,
                                NtDeviceName,
                                NtSystemPath,
                                NtSystemPathString);
}

NTSTATUS
NTAPI
HalpReadPartitionTable(IN PDEVICE_OBJECT DeviceObject,
                       IN ULONG SectorSize,
                       IN BOOLEAN ReturnRecognizedPartitions,
                       IN OUT PDRIVE_LAYOUT_INFORMATION *PartitionBuffer)
{
    /* Call the kernel */
    return IoReadPartitionTable(DeviceObject,
                                SectorSize,
                                ReturnRecognizedPartitions,
                                PartitionBuffer);
}

NTSTATUS
NTAPI
HalpWritePartitionTable(IN PDEVICE_OBJECT DeviceObject,
                        IN ULONG SectorSize,
                        IN ULONG SectorsPerTrack,
                        IN ULONG NumberOfHeads,
                        IN PDRIVE_LAYOUT_INFORMATION PartitionBuffer)
{
    /* Call the kernel */
    return IoWritePartitionTable(DeviceObject,
                                 SectorSize,
                                 SectorsPerTrack,
                                 NumberOfHeads,
                                 PartitionBuffer);
}

NTSTATUS
NTAPI
HalpSetPartitionInformation(IN PDEVICE_OBJECT DeviceObject,
                            IN ULONG SectorSize,
                            IN ULONG PartitionNumber,
                            IN ULONG PartitionType)
{
    /* Call the kernel */
    return IoSetPartitionInformation(DeviceObject,
                                     SectorSize,
                                     PartitionNumber,
                                     PartitionType);
}


BOOLEAN
NTAPI
IoFlushAdapterBuffers(
  PADAPTER_OBJECT AdapterObject,
  PMDL Mdl,
  PVOID MapRegisterBase,
  PVOID CurrentVa,
  ULONG Length,
  BOOLEAN WriteToDevice)
{
  UNIMPLEMENTED;

  return TRUE;
}


VOID
NTAPI
IoFreeAdapterChannel(
  PADAPTER_OBJECT AdapterObject)
{
  UNIMPLEMENTED;
}


VOID
NTAPI
IoFreeMapRegisters(
  PADAPTER_OBJECT AdapterObject,
  PVOID MapRegisterBase,
  ULONG NumberOfMapRegisters)
{
  UNIMPLEMENTED;
}


PHYSICAL_ADDRESS
NTAPI
IoMapTransfer(
  PADAPTER_OBJECT AdapterObject,
  PMDL Mdl,
  PVOID MapRegisterBase,
  PVOID CurrentVa,
  PULONG Length,
  BOOLEAN WriteToDevice)
{
  PHYSICAL_ADDRESS Address;

  UNIMPLEMENTED;

  Address.QuadPart = 0;

  return Address;
}


#undef KeAcquireSpinLock
VOID
NTAPI
KeAcquireSpinLock(
  PKSPIN_LOCK SpinLock,
  PKIRQL OldIrql)
{
  UNIMPLEMENTED;
}


KIRQL
FASTCALL
KeAcquireSpinLockRaiseToSynch(
  PKSPIN_LOCK SpinLock)
{
  UNIMPLEMENTED;

  return 0;
}


VOID
FASTCALL
KeAcquireInStackQueuedSpinLock(
    IN PKSPIN_LOCK SpinLock,
    IN PKLOCK_QUEUE_HANDLE LockHandle
    )
{
  UNIMPLEMENTED;
}

VOID
FASTCALL
KeAcquireInStackQueuedSpinLockRaiseToSynch(
    IN PKSPIN_LOCK SpinLock,
    IN PKLOCK_QUEUE_HANDLE LockHandle
    )
{
   UNIMPLEMENTED;
}

VOID
FASTCALL
KeReleaseInStackQueuedSpinLock(
    IN PKLOCK_QUEUE_HANDLE LockHandle
    )
{
  UNIMPLEMENTED;
}

VOID
NTAPI
KeFlushWriteBuffer(VOID)
{
  UNIMPLEMENTED;
}

#undef KeGetCurrentIrql
KIRQL
NTAPI
KeGetCurrentIrql(VOID)
{
  UNIMPLEMENTED;

  return (KIRQL)0;
}

#undef KeLowerIrql
VOID
NTAPI
KeLowerIrql(
  KIRQL NewIrql)
{
  UNIMPLEMENTED;
}


LARGE_INTEGER
NTAPI
KeQueryPerformanceCounter(
  PLARGE_INTEGER PerformanceFreq)
{
  LARGE_INTEGER Value;

  UNIMPLEMENTED;

  Value.QuadPart = 0;

  return Value;
}

#undef KeRaiseIrql
VOID
NTAPI
KeRaiseIrql(
  KIRQL NewIrql,
  PKIRQL OldIrql)
{
  UNIMPLEMENTED;
}


KIRQL
NTAPI
KeRaiseIrqlToDpcLevel(VOID)
{
  UNIMPLEMENTED;

  return (KIRQL)0;
}


KIRQL
NTAPI
KeRaiseIrqlToSynchLevel(VOID)
{
  UNIMPLEMENTED;

  return (KIRQL)0;
}

#undef KeReleaseSpinLock
VOID
NTAPI
KeReleaseSpinLock(
  PKSPIN_LOCK SpinLock,
  KIRQL NewIrql)
{
  UNIMPLEMENTED;
}


VOID
NTAPI
KeStallExecutionProcessor(
  ULONG Microseconds)
{
  UNIMPLEMENTED;
}


LOGICAL
FASTCALL
KeTryToAcquireQueuedSpinLock(
  KSPIN_LOCK_QUEUE_NUMBER LockNumber,
  PKIRQL OldIrql)
{
  UNIMPLEMENTED;

  return FALSE;
}


BOOLEAN
FASTCALL
KeTryToAcquireQueuedSpinLockRaiseToSynch(
  KSPIN_LOCK_QUEUE_NUMBER LockNumber,
  PKIRQL OldIrql)
{
  UNIMPLEMENTED;

  return FALSE;
}


KIRQL
FASTCALL
KfAcquireSpinLock(
  PKSPIN_LOCK SpinLock)
{
  UNIMPLEMENTED;

  return (KIRQL)0;
}


VOID
FASTCALL
KfLowerIrql(
  KIRQL NewIrql)
{
  UNIMPLEMENTED;
}


KIRQL
FASTCALL
KfRaiseIrql(
  KIRQL NewIrql)
{
  UNIMPLEMENTED;

  return (KIRQL)0;
}


VOID
FASTCALL
KfReleaseSpinLock(
  PKSPIN_LOCK SpinLock,
  KIRQL NewIrql)
{
  UNIMPLEMENTED;
}


VOID
NTAPI
READ_PORT_BUFFER_UCHAR(
  PUCHAR Port,
  PUCHAR Buffer,
  ULONG Count)
{
  UNIMPLEMENTED;
}


VOID
NTAPI
READ_PORT_BUFFER_ULONG(
  PULONG Port,
  PULONG Buffer,
  ULONG Count)
{
  UNIMPLEMENTED;
}


VOID
NTAPI
READ_PORT_BUFFER_USHORT(
  PUSHORT Port,
  PUSHORT Buffer,
  ULONG Count)
{
  UNIMPLEMENTED;
}


UCHAR
NTAPI
READ_PORT_UCHAR(
  PUCHAR Port)
{
  UNIMPLEMENTED;

  return 0;
}


ULONG
NTAPI
READ_PORT_ULONG(
  PULONG Port)
{
  UNIMPLEMENTED;

  return 0;
}


USHORT
NTAPI
READ_PORT_USHORT(
  PUSHORT Port)
{
  UNIMPLEMENTED;

  return 0;
}


VOID
NTAPI
WRITE_PORT_BUFFER_UCHAR(
  PUCHAR Port,
  PUCHAR Buffer,
  ULONG Count)
{
  UNIMPLEMENTED;
}


VOID
NTAPI
WRITE_PORT_BUFFER_USHORT(
  PUSHORT Port,
  PUSHORT Buffer,
  ULONG Count)
{
  UNIMPLEMENTED;
}


VOID
NTAPI
WRITE_PORT_BUFFER_ULONG(
  PULONG Port,
  PULONG Buffer,
  ULONG Count)
{
  UNIMPLEMENTED;
}


VOID
NTAPI
WRITE_PORT_UCHAR(
  PUCHAR Port,
  UCHAR Value)
{
  UNIMPLEMENTED;
}

VOID
NTAPI
WRITE_PORT_ULONG(
  PULONG Port,
  ULONG Value)
{
  UNIMPLEMENTED;
}

VOID
NTAPI
WRITE_PORT_USHORT(
  PUSHORT Port,
  USHORT Value)
{
  UNIMPLEMENTED;
}

KIRQL
FASTCALL
KeAcquireQueuedSpinLock(IN PKLOCK_QUEUE_HANDLE LockHandle)
{
  UNIMPLEMENTED;
  return (KIRQL)0;
}

KIRQL
FASTCALL
KeAcquireQueuedSpinLockRaiseToSynch(IN PKLOCK_QUEUE_HANDLE LockHandle)
{
    UNIMPLEMENTED;
    return (KIRQL)0;
}

VOID
FASTCALL
KeReleaseQueuedSpinLock(IN PKLOCK_QUEUE_HANDLE LockHandle,
                        IN KIRQL OldIrql)
{
  UNIMPLEMENTED;
}

/* EOF */
<module name="hal" type="kernelmodedll">
	<importlibrary basename="hal" definition="hal.def" />
	<include base="ntoskrnl">include</include>
	<library>ntoskrnl</library>
	<define name="_NTHAL_" />
	<define name="__USE_W32API" />
    <linkerflag>-enable-stdcall-fixup</linkerflag>
	<file>hal.c</file>
	<file>hal.rc</file>
</module>

<if property="ARCH" value="i386">
	<module ifnot="${MP}" name="halupalias" type="alias" installbase="system32" installname="hal.dll" aliasof="halup">
	</module>

	<module if="${MP}" name="halmpalias" type="alias" installbase="system32" installname="hal.dll" aliasof="halmp">
	</module>
</if>
<if property="ARCH" value="powerpc">
	<module name="halupalias" type="alias" installbase="system32" installname="hal.dll" aliasof="halppc_up"/>
</if>

//
// Various offsets in the boot record
//
#define PARTITION_TABLE_OFFSET                      (0x1BE / 2)
#define BOOT_SIGNATURE_OFFSET                       ((0x200 / 2) - 1)
#define BOOT_RECORD_RESERVED                        0x1BC
#define BOOT_RECORD_SIGNATURE                       0xAA55
#define NUM_PARTITION_TABLE_ENTRIES                 4

//
// Helper Macros
//
#define GET_STARTING_SECTOR(p)                      \
    ((ULONG)(p->StartingSectorLsb0) +               \
     (ULONG)(p->StartingSectorLsb1 << 8 ) +         \
     (ULONG)(p->StartingSectorMsb0 << 16) +         \
     (ULONG)(p->StartingSectorMsb1 << 24))

#define GET_ENDING_S_OF_CHS(p)                      \
    ((UCHAR)(p->EndingCylinderLsb & 0x3F))

#define GET_PARTITION_LENGTH(p)                     \
    ((ULONG)(p->PartitionLengthLsb0) +              \
     (ULONG)(p->PartitionLengthLsb1 << 8) +         \
     (ULONG)(p->PartitionLengthMsb0 << 16) +        \
     (ULONG)(p->PartitionLengthMsb1 << 24))

//
// Structure describing a partition
//
typedef struct _PARTITION_DESCRIPTOR
{
    UCHAR ActiveFlag;
    UCHAR StartingTrack;
    UCHAR StartingCylinderLsb;
    UCHAR StartingCylinderMsb;
    UCHAR PartitionType;
    UCHAR EndingTrack;
    UCHAR EndingCylinderLsb;
    UCHAR EndingCylinderMsb;
    UCHAR StartingSectorLsb0;
    UCHAR StartingSectorLsb1;
    UCHAR StartingSectorMsb0;
    UCHAR StartingSectorMsb1;
    UCHAR PartitionLengthLsb0;
    UCHAR PartitionLengthLsb1;
    UCHAR PartitionLengthMsb0;
    UCHAR PartitionLengthMsb1;
} PARTITION_DESCRIPTOR, *PPARTITION_DESCRIPTOR;

//
// Structure describing a boot sector
//
typedef struct _BOOT_SECTOR_INFO
{
    UCHAR JumpByte[1];
    UCHAR Ignore1[2];
    UCHAR OemData[8];
    UCHAR BytesPerSector[2];
    UCHAR Ignore2[6];
    UCHAR NumberOfSectors[2];
    UCHAR MediaByte[1];
    UCHAR Ignore3[2];
    UCHAR SectorsPerTrack[2];
    UCHAR NumberOfHeads[2];
} BOOT_SECTOR_INFO, *PBOOT_SECTOR_INFO;

//
// Partition Table and Disk Layout
//
typedef struct _PARTITION_TABLE
{
    PARTITION_INFORMATION PartitionEntry[4];
} PARTITION_TABLE, *PPARTITION_TABLE;

typedef struct _DISK_LAYOUT
{
    ULONG TableCount;
    ULONG Signature;
    PARTITION_TABLE PartitionTable[1];
} DISK_LAYOUT, *PDISK_LAYOUT;

//
// Partition Table Entry
//
typedef struct _PTE
{
    UCHAR ActiveFlag;
    UCHAR StartingTrack;
    USHORT StartingCylinder;
    UCHAR PartitionType;
    UCHAR EndingTrack;
    USHORT EndingCylinder;
    ULONG StartingSector;
    ULONG PartitionLength;
} PTE, *PPTE;

#endif