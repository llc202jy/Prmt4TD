					{		//DEUBG
						System.out.println("BuddyList.parseBuddyList(): parsing done");
					}
					
					//we're done
					return;	
				}	
				
			}
			
			
			eventType = xpp.next();
			Thread.yield();
				
		} while (eventType != XmlPullParser.END_DOCUMENT);
		
		
		{		//DEUBG
			System.out.println("BuddyList.parseBuddyList(): parsing done");
			
		}
	}
	
	
	
	/*
	
		updateBuddyPresence
		
		called only by Presence.parsePresence	
		
		@uname - uesrname of the buddy to be updated
		@st - status of the buddy to be updated
		@stmsg - status message
	*/
	
	public static void updateBuddyPresence(String uname,String st,String stmsg,String time) throws Exception
	{
		if (instance == null)
			throw new Exception("BuddyList.updateBuddyPresence(): instance not created yet!");	
		
		if (uname == null)
			throw new Exception("BuddyList.updateBuddyPresence(): passed username is null!");
				
		String lw = uname.toLowerCase();
		
		//check to see if the username exists within the hashmap
		if (instance.buddies.containsKey(lw) == false)
		{
			//throw new Exception("BuddyList.updateBuddyPresence(): passed username " + uname + " does not exist in hashmap!");
			System.out.println("BuddyList.updateBuddyPresence(): passed username " + uname + " does not exist in hashmap!");
			return;
		}
		
		Buddy buddy = (Buddy) instance.buddies.get(lw);
		
		if (buddy == null)
			throw new Exception("BuddyList.updateBuddyPresence(): returned buddy is null!");
			
		System.out.println(uname + "'s presence is updated to: " + st + ":" + stmsg);
		
		//see what changed
		int status = buddy.getPresence().getStatus();
		int st1 = Presence.convertStatus(st);
		
		if ((status == Presence.OFFLINE || status == Presence.INVISIBLE) && (st1 == Presence.ONLINE || st1 == Presence.AWAY))
		{
			//update all the groups
			Object[] buddyGroups = buddy.getGroups().toArray();
			
			for (Object o : buddyGroups)
			{
				Group group = (Group)instance.groups.get((String)o);
				
				if (group == null)
					continue;
					
				group.buddySignedOn();
				
			}	
		}
		else if ((status == Presence.ONLINE || status == Presence.AWAY) && (st1 == Presence.OFFLINE || st1 == Presence.INVISIBLE))
		{
				//update all the groups
			Object[] buddyGroups = buddy.getGroups().toArray();
			
			for (Object o : buddyGroups)
			{
				Group group = (Group)instance.groups.get((String)o);
				
				if (group == null)
					continue;
					