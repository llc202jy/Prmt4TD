Usage
Dim instance As SchedulerCounters

Syntax
C#
C++
VB

[ClassInterfaceAttribute(ClassInterfaceType.None)] 
[ComVisibleAttribute(true)] 
[GuidAttribute("256241B2-42E8-41fc-AEFB-365CAC3EF7A8")] 
public class SchedulerCounters : ISchedulerCounters

J#

/** @attribute ClassInterfaceAttribute(ClassInterfaceType.None) */ 
/** @attribute ComVisibleAttribute(true) */ 
/** @attribute GuidAttribute("256241B2-42E8-41fc-AEFB-365CAC3EF7A8") */ 
public class SchedulerCounters implements ISchedulerCounters

JScript

ClassInterfaceAttribute(ClassInterfaceType.None) 
ComVisibleAttribute(true) 
GuidAttribute("256241B2-42E8-41fc-AEFB-365CAC3EF7A8") 
public class SchedulerCounters implements ISchedulerCounterClass	Description
AggregateColumn	Defines the property and the type of aggregation to perform on that property.
AllocationProperties	Used to track resource allocations for a task.
AzureDeploymentPropertyIds	 
ErrorCode	Defines the possible HPC-defined error codes that HPC can set.
ExpandedPriority	Provides methods and fields for working with the expanded scale of job priority values introduced in Windows HPC Server 2008 R2.
FilterProperty	Defines a filter to use for filtering lists of jobs, tasks, or nodes.
JobHistoryPropertyIds	Defines the job history properties that you can retrieve when calling the IScheduler.OpenJobHistoryEnumerator method.
JobOrderBy	Used to specify the preference that you want the scheduler to use when it decides on which nodes to run your job. For example, schedule the job on nodes with the most amount of memory and the least number of cores.
JobOrderByList	Contains a list of JobOrderBy objects.
JobPropertyIds	Defines the identifiers that uniquely identify the properties of a job.
JobTemplatePropertyIds	Defines the identifiers that uniquely identify the properties of a job template.
NodeGroup	Defines a node group.
NodeHistoryPropertyIds	Defines the node history properties that you can retrieve when calling the IScheduler.OpenNodeHistoryEnumerator method.
NodePropertyIds	Defines the identifiers that uniquely identify the properties of a node.
PendingReason	Defines the possible reasons why the job or task has yet to start.
PoolPropertyIds	Defines the identifiers that uniquely identify the properties of a pool.
PropertyId	Defines a property.
PropertyRow	Defines the properties that are in a row of a rowset.
PropertyRowEnumerator	Supports a simple iteration over a collection of the properties in a row of a rowset.
PropertyRowSet	Defines a rowset object that you can use to retrieve the properties of one or more objects in the rowset.
ResourcePropertyIds	Defines the identifiers that uniquely identify the properties of a schedulable resource.
SchedulerException	Defines an exception raised by the scheduler.
SortProperty	Defines a property on which the lists of jobs, tasks, or nodes are sorted.
StandardServiceAsClientIdentityProviders	Defines the methods that provide the identity of calling client.
StoreProperty	Defines a store property.
StorePropertyIds	Defines the identifiers that uniquely identify the each property in the store.
TaskGroupPropertyIds	Defines the identifiers that uniquely identify the properties of a task group.
TaskId	Contains the identifiers that uniquely identify the task.
TaskPropertyIds	Defines identifiers that uniquely identify the properties of a task.

Class	Description
Public class	Alarm	A notification for which a custom sound can be specified.
Public class	PeriodicTask	Represents a scheduled task that runs regularly for a small amount of time.
Public class	Reminder	A notification that can pass contextual information to the parent application.
Public class	ResourceIntensiveTask	Represents a scheduled task that runs occasionally and is allowed to use substantial device resources.
Public class	ScheduledAction	The base class for all scheduled actions.
Public class	ScheduledActionService	Enables the management of scheduled actions.
Public class	ScheduledNotification	Represents a notification that is launched once or in a recurring pattern according to a time-based schedule.
Public class	ScheduledTask	Represents a task that will be run periodically or when the phone is in a state that supports resource-intensive processing.
Public class	ScheduledTaskAgent	Override this class to implement a Scheduled Task, also referred to as a background agent. This class contains one method, OnInvoke, which is called whenever the Scheduled Task is executed. For more information, see Background agents for Windows Phone.
Public class	SchedulerServiceException	Represents the exception that is thrown when the ScheduledActionService has an internal error.

[HostProtectionAttribute(SecurityAction.LinkDemand, Synchronization = true, 
	ExternalThreading = true)]
[PermissionSetAttribute(SecurityAction.InheritanceDemand, Unrestricted = true)]
public abstract class TaskScheduler

Name	Description
Public methodSupported by Portable Class LibrarySupported in .NET for Windows Store apps	Equals(Object)	Determines whether the specified object is equal to the current object. (Inherited from Object.)
Protected methodSupported by Portable Class Library	Finalize	Allows an object to try to free resources and perform other cleanup operations before it is reclaimed by garbage collection. (Inherited from Object.)

In .NET Framework Client Profile, this member is overridden by Finalize().

In Portable Class Library, this member is overridden by Finalize().
Public methodStatic memberSupported by Portable Class LibrarySupported in .NET for Windows Store apps	FromCurrentSynchronizationContext	Creates a TaskScheduler associated with the current System.Threading.SynchronizationContext.
Public methodSupported by Portable Class LibrarySupported in .NET for Windows Store apps	GetHashCode	Serves as a hash function for a particular type. (Inherited from Object.)
Protected methodSupported by Portable Class LibrarySupported in .NET for Windows Store apps	GetScheduledTasks	For debugger support only, generates an enumerable of Task instances currently queued to the scheduler waiting to be executed.
Public methodSupported by Portable Class LibrarySupported in .NET for Windows Store apps	GetType	Gets the Type of the current instance. (Inherited from Object.)
Protected methodSupported by Portable Class LibrarySupported in .NET for Windows Store apps	MemberwiseClone	Creates a shallow copy of the current Object. (Inherited from Object.)
Protected methodSupported by Portable Class LibrarySupported in .NET for Windows Store apps	QueueTask	Queues a Task to the scheduler.
Public methodSupported by Portable Class LibrarySupported in .NET for Windows Store apps	ToString	Returns a string that represents the current object. (Inherited from Object.)
Protected methodSupported by Portable Class LibrarySupported in .NET for Windows Store apps	TryDequeue	Attempts to dequeue a Task that was previously queued to this scheduler.
Protected methodSupported by Portable Class LibrarySupported in .NET for Windows Store apps	TryExecuteTask	Attempts to execute the provided Task on this scheduler.
Protected methodSupported by Portable Class LibrarySupported in .NET for Windows Store apps	TryExecuteTaskInline	Determines whether the provided Task can be executed synchronously in this call, and if it can, executes it.
