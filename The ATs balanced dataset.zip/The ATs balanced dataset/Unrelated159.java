You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA
 */
package com.lucene.index;

import java.io.IOException;
import java.io.File;
import java.io.PrintStream;
import java.util.Vector;

import com.lucene.store.Directory;
import com.lucene.store.RAMDirectory;
import com.lucene.store.FSDirectory;
import com.lucene.store.InputStream;
import com.lucene.store.OutputStream;
import com.lucene.document.Document;
import com.lucene.analysis.Analyzer;

/**
  An IndexWriter creates and maintains an index.

  The third argument to the <a href="#IndexWriter"><b>constructor</b></a>
  determines whether a new index is created, or whether an existing index is
  opened for the addition of new documents.

  In either case, documents are added with the <a
  href="#addDocument"><b>addDocument</b></a> method.  When finished adding
  documents, <a href="#close"><b>close</b></a> should be called.

  If an index will not have more documents added for a while and optimal search
  performance is desired, then the <a href="#optimize"><b>optimize</b></a>
  method should be called before the index is closed.
  */

public final class IndexWriter {
  private Directory directory;			  // where this index resides
  private Analyzer analyzer;			  // how to analyze text

  private SegmentInfos segmentInfos = new SegmentInfos(); // the segments
  private final Directory ramDirectory = new RAMDirectory(); // for temp segs

  /** Constructs an IndexWriter for the index in <code>path</code>.  Text will
    be analyzed with <code>a</code>.  If <code>create</code> is true, then a
    new, empty index will be created in <code>d</code>, replacing the index
    already there, if any. */
  public IndexWriter(String path, Analyzer a, boolean create)
       throws IOException {
    this(FSDirectory.getDirectory(path, create), a, create);
  }

  /** Constructs an IndexWriter for the index in <code>path</code>.  Text will
    be analyzed with <code>a</code>.  If <code>create</code> is true, then a
    new, empty index will be created in <code>d</code>, replacing the index
    already there, if any. */
  public IndexWriter(File path, Analyzer a, boolean create)
       throws IOException {
    this(FSDirectory.getDirectory(path, create), a, create);
  }

  /** Constructs an IndexWriter for the index in <code>d</code>.  Text will be
    analyzed with <code>a</code>.  If <code>create</code> is true, then a new,
    empty index will be created in <code>d</code>, replacing the index already
    there, if any. */
  public IndexWriter(Directory d, Analyzer a, boolean create)
       throws IOException {
    directory = d;
    analyzer = a;

    synchronized (directory) {
      if (create)
	segmentInfos.write(directory);
      else
	segmentInfos.read(directory);
    }
  }

  /** Flushes all changes to an index, closes all associated files, and closes
    the directory that the index is stored in. */
  public final synchronized void close() throws IOException {
    flushRamSegments();
    ramDirectory.close();
    directory.close();
  }

  /** Returns the number of documents currently in this index. */
  public final synchronized int docCount() {
    int count = 0;
    for (int i = 0; i < segmentInfos.size(); i++) {
      SegmentInfo si = segmentInfos.info(i);
      count += si.docCount;
    }
    return count;
  }

  /** The maximum number of terms that will be indexed for a single field in a
    document.  This limits the amount of memory required for indexing, so that
    collections with very large files will not crash the indexing process by
    running out of memory.

    <p>By default, no more than 10,000 terms will be indexed for a field. */
  public int maxFieldLength = 10000;

  /** Adds a document to this index.*/
  public final void addDocument(Document doc) throws IOException {
    DocumentWriter dw =
      new DocumentWriter(ramDirectory, analyzer, maxFieldLength);
    String segmentName = newSegmentName();
    dw.addDocument(segmentName, doc);
    synchronized (this) {
      segmentInfos.addElement(new SegmentInfo(segmentName, 1, ramDirectory));
      maybeMergeSegments();
    }
  }

  private final synchronized String newSegmentName() {
    return "_" + Integer.toString(segmentInfos.counter++, Character.MAX_RADIX);
  }

  /** Determines how often segment indexes are merged by addDocument().  With
   * smaller values, less RAM is used while indexing, and searches on
   * unoptimized indexes are faster, but indexing speed is slower.  With larger
   * values more RAM is used while indexing and searches on unoptimized indexes
   * are slower, but indexing is faster.  Thus larger values (> 10) are best
   * for batched index creation, and smaller values (< 10) for indexes that are
   * interactively maintained.
   *
   * <p>This must never be less than 2.  The default value is 10.*/
  public int mergeFactor = 10;

  /** Determines the largest number of documents ever merged by addDocument().
   * Small values (e.g., less than 10,000) are best for interactive indexing,
   * as this limits the length of pauses while indexing to a few seconds.
   * Larger values are best for batched indexing and speedier searches.
   *
   * <p>The default value is {@link Integer#MAX_VALUE}. */
  public int maxMergeDocs = Integer.MAX_VALUE;

  /** If non-null, information about merges will be printed to this. */
  public PrintStream infoStream = null;

  /** Merges all segments together into a single segment, optimizing an index
      for search. */
  public final synchronized void optimize() throws IOException {
    flushRamSegments();
    while (segmentInfos.size() > 1 ||
	   (segmentInfos.size() == 1 &&
	    SegmentReader.hasDeletions(segmentInfos.info(0)))){
      int minSegment = segmentInfos.size() - mergeFactor;
      mergeSegments(minSegment < 0 ? 0 : minSegment);
    }
  }

  /** Merges all segments from an array of indexes into this index.
   *
   * <p>This may be used to parallelize batch indexing.  A large document
   * collection can be broken into sub-collections.  Each sub-collection can be
   * indexed in parallel, on a different thread, process or machine.  The
   * complete index can then be created by merging sub-collection indexes
   * with this method.
   *
   * <p>After this completes, the index is optimized. */
  public final synchronized void addIndexes(Directory[] dirs)
      throws IOException {
    optimize();					  // start with zero or 1 seg
    int minSegment = segmentInfos.size();
    int segmentsAddedSinceMerge = 0;
    for (int i = 0; i < dirs.length; i++) {
      SegmentInfos sis = new SegmentInfos();	  // read infos from dir
      sis.read(dirs[i]);
      for (int j = 0; j < sis.size(); j++) {
	segmentInfos.addElement(sis.info(j));	  // add each info

	// merge whenever mergeFactor segments have been added
	if (++segmentsAddedSinceMerge == mergeFactor) {
	  mergeSegments(minSegment++, false);
	  segmentsAddedSinceMerge = 0;
	}
      }
    }
    optimize();					  // final cleanup
  }

  /** Merges all RAM-resident segments. */
  private final void flushRamSegments() throws IOException {
    int minSegment = segmentInfos.size()-1;
    int docCount = 0;
    while (minSegment >= 0 &&
	   (segmentInfos.info(minSegment)).dir == ramDirectory) {
      docCount += segmentInfos.info(minSegment).docCount;
      minSegment--;
    }
    if (minSegment < 0 ||			  // add one FS segment?
	(docCount + segmentInfos.info(minSegment).docCount) > mergeFactor ||
	!(segmentInfos.info(segmentInfos.size()-1).dir == ramDirectory))
      minSegment++;
    if (minSegment >= segmentInfos.size())
      return;					  // none to merge
    mergeSegments(minSegment);
  }

  /** Incremental segment merger.  */
  private final void maybeMergeSegments() throws IOException {
    long targetMergeDocs = mergeFactor;
    while (targetMergeDocs <= maxMergeDocs) {
      // find segments smaller than current target size
      int minSegment = segmentInfos.size();
      int mergeDocs = 0;
      while (--minSegment >= 0) {
	SegmentInfo si = segmentInfos.info(minSegment);
	if (si.docCount >= targetMergeDocs)
	  break;
	mergeDocs += si.docCount;
      }

      if (mergeDocs >= targetMergeDocs)		  // found a merge to do
	mergeSegments(minSegment+1);
      else
	break;
      
      targetMergeDocs *= mergeFactor;		  // increase target size
    }
  }

  /** Pops segments off of segmentInfos stack down to minSegment, merges them,
    and pushes the merged index onto the top of the segmentInfos stack. */
  private final void mergeSegments(int minSegment) throws IOException {
    mergeSegments(minSegment, true);
  }

  /** Pops segments off of segmentInfos stack down to minSegment, merges them,
    and pushes the merged index onto the top of the segmentInfos stack. */
  private final void mergeSegments(int minSegment, boolean delete)
      throws IOException {
    String mergedName = newSegmentName();
    int mergedDocCount = 0;
    if (infoStream != null) infoStream.print("merging segments");
    SegmentMerger merger = new SegmentMerger(directory, mergedName);
    Vector segmentsToDelete = new Vector();
    for (int i = minSegment; i < segmentInfos.size(); i++) {
      SegmentInfo si = segmentInfos.info(i);
      if (infoStream != null)
	infoStream.print(" " + si.name + " (" + si.docCount + " docs)");
      SegmentReader reader = new SegmentReader(si);
      merger.add(reader);
      if (delete)
	segmentsToDelete.addElement(reader);	  // queue for deletion
      mergedDocCount += si.docCount;
    }
    if (infoStream != null) {
      infoStream.println();
      infoStream.println(" into "+mergedName+" ("+mergedDocCount+" docs)");
    }
    merger.merge();

    segmentInfos.setSize(minSegment);		  // pop old infos & add new
    segmentInfos.addElement(new SegmentInfo(mergedName, mergedDocCount,
					    directory));
    
    synchronized (directory) {
      segmentInfos.write(directory);		  // commit before deleting
      deleteSegments(segmentsToDelete);		  // delete now-unused segments
    }
  }

  /* Some operating systems (e.g. Windows) don't permit a file to be deleted
     while it is opened for read (e.g. by another process or thread).  So we
     assume that when a delete fails it is because the file is open in another
     process, and queue the file for subsequent deletion. */

  private final void deleteSegments(Vector segments) throws IOException {
    Vector deletable = new Vector();

    deleteFiles(readDeleteableFiles(), deletable); // try to delete deleteable
    
    for (int i = 0; i < segments.size(); i++) {
      SegmentReader reader = (SegmentReader)segments.elementAt(i);
      if (reader.directory == this.directory)
	deleteFiles(reader.files(), deletable);	  // try to delete our files
      else
	deleteFiles(reader.files(), reader.directory); // delete, eg, RAM files
    }

    writeDeleteableFiles(deletable);		  // note files we can't delete
  }

  private final void deleteFiles(Vector files, Directory directory)
       throws IOException {
    for (int i = 0; i < files.size(); i++)
      directory.deleteFile((String)files.elementAt(i));
  }

  private final void deleteFiles(Vector files, Vector deletable)
       throws IOException {
    for (int i = 0; i < files.size(); i++) {
      String file = (String)files.elementAt(i);
      try {
	directory.deleteFile(file);		  // try to delete each file
      } catch (IOException e) {			  // if delete fails
	if (directory.fileExists(file)) {
	  if (infoStream != null)
	    infoStream.println(e.getMessage() + "; Will re-try later.");
	  deletable.addElement(file);		  // add to deletable
	}
      }
    }
  }

  private final Vector readDeleteableFiles() throws IOException {
    Vector result = new Vector();
    if (!directory.fileExists("deletable"))
      return result;

    InputStream input = directory.openFile("deletable");
    try {
      for (int i = input.readInt(); i > 0; i--)	  // read file names
	result.addElement(input.readString());
    } finally {
      input.close();
    }
    return result;
  }

  private final void writeDeleteableFiles(Vector files) throws IOException {
    OutputStream output = directory.createFile("deleteable.new");
    try {
      output.writeInt(files.size());
      for (int i = 0; i < files.size(); i++)
	output.writeString((String)files.elementAt(i));
    } finally {
      output.close();
    }/**
	 * Convenience method. Return the address String for a reference. Format: "x.x.x.x:pppp"
	 * Creation date: (16/05/01 13:21:14)
	 * 
	 * @param str
	 * @return String
	 */
	public static String getAddress(String str) {
		return new ParsedIOGR(checkIORString(str)).getAddress();
	}

	/**
	 * Convenience method. Return the address String for a reference. Format: "x.x.x.x:pppp"
	 * Creation date: (16/05/01 13:21:14)
	 * 
	 * @param ior
	 * @return String
	 */
	public static String getAddress(IOR ior) {
		return new ParsedIOGR(ior).getAddress();
	}

	/**
	 * Checks if two CORBA Object are equivalent. This means that they must have the same domain_id
	 * and same group_id.
	 * 
	 * @param o1 org.omg.CORBA.Object
	 * @param o2 org.omg.CORBA.Object
	 * @return boolean
	 */
	public static boolean isEquivalent(org.omg.CORBA.Object o1, org.omg.CORBA.Object o2) {
		if ((o1 == null) || (o2 == null))
			return false;
		ParsedIOGR i1 = new ParsedIOGR(o1);
		ParsedIOGR i2 = new ParsedIOGR(o2);

		return i1.equals(i2);
	}

	/**
	 * Checks if two CORBA Object are equivalent. This means that they must have the same domain_id
	 * and same group_id.
	 * 
	 * @param o1 Object
	 * @param o2 Object
	 * @return boolean
	 */
	public static boolean isEquivalent(Object o1, Object o2) {
		try {
			return isEquivalent((org.omg.CORBA.Object) o1, (org.omg.CORBA.Object) o2);
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Returns the location of the IOR inside a NameComponent array.
	 * 
	 * @param ior
	 * @return NameComponent[]
	 */
	public static NameComponent[] getObjectLocation(String ior) {
		NameComponent[] nc = { new NameComponent(getAddress(ior), Main.OBJECT_LOCATION)};
		return nc;
	}

	/**
	 * Returns the location of the Object inside a NameComponent array.
	 * 
	 * @param obj
	 * @return NameComponent[]
	 */
	public static NameComponent[] getObjectLocation(org.omg.CORBA.Object obj) {
		NameComponent[] nc = { new NameComponent(getAddress(obj), Main.OBJECT_LOCATION)};
		return nc;
	}

	/**
	 * Converts an IOR string representation back to an IOR.
	 * 
	 * @param ior_str
	 * @return org.omg.IOP.IOR
	 */
	public static IOR toIOR(String ior_str) {
		return new ParsedIOGR(ior_str).getIOR();
	}

	/**
	 * Converts an Object to an IOR.
	 * 
	 * @param obj
	 * @return org.omg.IOP.IOR
	 */
	public static IOR toIOR(org.omg.CORBA.Object obj) {
		return new ParsedIOGR(obj).getIOR();
	}

	/**
	 * Trims a type_id to get the default Name Service name.
	 * 
	 * @param type_id
	 * @return String
	 */
	public static String toName(String type_id) {
		if (type_id == null)
			return null;
		int init = type_id.lastIndexOf("/");
		if (init == -1)
			init = type_id.indexOf(":");
		return type_id.substring(init + 1, type_id.lastIndexOf(":"));
	}

	/**
	 * Converts an IOR to an Object reference.
	 * 
	 * @param ior org.omg.IOP.IOR
	 * @return org.omg.CORBA.Object
	 */
	public static org.omg.CORBA.Object toObject(IOR ior) {
		if (ior == null)
			return null;
		return Main.getORB().string_to_object(toString(ior));
	}

	/**
	 * Converts IOR in a string representation.
	 * 
	 * @param ior
	 * @return String
	 */
	public static String toString(IOR ior) {
		return new ParsedIOGR(ior).getIORString();
	}

	/**
	 * Converts an Object in a string representation.
	 * 
	 * @param obj
	 * @return String
	 */
	public static String toString(org.omg.CORBA.Object obj) {
		return checkIORString(Main.getORB().object_to_string(obj));
	}

	/**
	 * Fix for different representation of a org.omg.CORBA.Object.
	 * 
	 * @param original the original string representation
	 * @return String a string that starts with 'IOR:'
	 */
	public static String checkIORString(String original) {
		if (original.indexOf("IOR:") > 0) {
			return original.substring(original.indexOf("IOR:"));
		} else {
			return original;
		}
	}

	/**
	 * Return this IOGR's FTDomainId. Return <code>null</code> if it's not an IOGR.
	 * 
	 * @return String
	 */
	public String getFTDomainId() {
		if (getTagGroup() != null)
			return getTagGroup().ft_domain_id;
		else
			return null;
	}

	/**
	 * Returns the version of this IOGR. Return zero (0) if it's not an IOGR.
	 * 
	 * @return int
	 */
	public int getGroupRefVersion() {
		if (getTagGroup() != null)
			return getTagGroup().object_group_ref_version;
		else
			return 0;
	}

	/**
	 * Return the TAG_FT_GROUP presence.
	 * 
	 * @return boolean
	 */
	public boolean isIOGR() {
		return (getTagGroup() != null);
	}

	/**
	 * Verifies that this IOGR is newer than another one.  Creation date: (19-01-2001 16:27)
	 * 
	 * @param piogr edu.lcmi.grouppac.ParsedIOGR
	 * @return boolean
	 * @throws IllegalArgumentException
	 */
	public boolean isNewer(ParsedIOGR piogr) {
		if (!this.equals(piogr))
			throw new IllegalArgumentException("The ParsedIOGR's are not equivalent.");

		return (this.getGroupRefVersion() > piogr.getGroupRefVersion());
	}

	/**
	 * Return an iterator that will navigate through the replicas references contained in this IOGR.
	 * @return Iterator backed by this IOGR
	 */
	public Iterator iterator() {
		return new IOGRIterator();
	}

	/**
	 * Returns the number of objects (profiles) in the IOGR. If none, return zero.
	 * 
	 * @return int
	 */
	public int getNumberOfObjects() {
		if (getProfileBodies() != null)
			return getProfileBodies().length;
		else
			return 0;
	}

	/**
	 * Returns this IOGR's ObjectGroupId. Return zero (0) if it's not an IOGR.
	 * 
	 * @return new_id long
	 */
	public long getObjectGroupId() {
		if (getTagGroup() != null)
			return getTagGroup().object_group_id;
		else
			return 0;
	}

	/**
	 * Create a full-featured IOR from one profile of the original IOGR, with or without the FT
	 * tags.
	 * 
	 * @param index
	 * @param with_tags
	 * @return org.omg.CORBA.Object
	 */
	public org.omg.CORBA.Object getObjectReference(int index, boolean with_tags) {
		IOR ior = makeIOR(getTypeId(), getProfileBodies()[index], with_tags);

		return toObject(ior);
	}

	/**
	 * Create a full-featured IOR from one profile of the original IOGR.
	 * 
	 * @param index
	 * @return org.omg.CORBA.Object
	 */
	public org.omg.CORBA.Object getObjectReference(int index) {
		IOR ior = makeIOR(getTypeId(), getProfileBodies()[index], true);

		return toObject(ior);
	}

	/**
	 * Create a full-featured IOR from one profile of the original IOGR, searching for the profile
	 * that has the required location. If none match the location, return <code>null</code>.
	 * 
	 * @param location
	 * @return org.omg.CORBA.Object
	 */
	public org.omg.CORBA.Object getObjectReference(String location) {
		int k = getNumberOfObjects();
		ProfileBody_1_1 pb;
		String address;
		int port;
		for (int i = 0; i < k; i++) {
			pb = getProfileBodies()[i];
			port = pb.port + ((pb.port < 0) ? 0x10000 : 0);
			address = pb.host + ":" + port;
			if (address.equals(location))
				return getObjectReference(i);
		}

		return null;
	}

	/**
	 * Verifies that this IOGR is older than another one.  Creation date: (19-01-2001 16:27)
	 * 
	 * @param piogr edu.lcmi.grouppac.ParsedIOGR
	 * @return boolean
	 * @throws IllegalArgumentException
	 */
	public boolean isOlder(ParsedIOGR piogr) {
		if (!this.equals(piogr))
			throw new IllegalArgumentException("The ParsedIOGR's are not equivalent.");

		return (this.getGroupRefVersion() < piogr.getGroupRefVersion());
	}

	/**
	 * Return an CORBA Object reference for the primary of this IOGR. Return <code>null</code> if
	 * none of the profiles have the TAG_FT_PRIMARY in it's components.
	 * 
	 * @return org.omg.CORBA.Object
	 */
	public org.omg.CORBA.Object getPrimaryReference() {
		ProfileBody_1_1 primary_profile = getPrimaryProfile();
		if (primary_profile == null)
			return null;
		else
			return toObject(makeIOR(getTypeId(), primary_profile, true));
	}

	/**
	 * Return the TAG_FT_RECOVERY_REQUEST presence.
	 * 
	 * @return boolean
	 */
	public boolean isRecovery() {
		return (getTagRecovery() != null);
	}

	/**
	 * Returns the TaggedComponent in this IOGR correspoding to the id. Return <code>null</code> if
	 * there is no TaggedComponent of the required id.
	 * 
	 * @param id the TaggedComponent id
	 * @return TaggedComponent
	 */
	public TaggedComponent getTaggedComponent(int id) {
		if (taggedComponents == null)
			return null;
		for (int i = 0; i < taggedComponents.length; i++) {
			if (taggedComponents[i].tag == id)
				return taggedComponents[i];
		}

		return null;
	}

	/**
	 * This method does the IOR decoding. First, we grab the type_id. Then, retrieve the profile
	 * bodies. Finally, search for TAGS.
	 * 
	 * @param ior
	 */
	public void decode(IOR ior) {
		super.decode(ior);
	}

	/**
	 * Compares two ParsedIOGRs. This is done according to the specification: If their domain_id
	 * and group_id matches, they're equal.
	 * 
	 * @see Object#equals(Object)
	 */
	public boolean equals(Object obj) {
		if (!(obj instanceof ParsedIOGR))
			return false;
		ParsedIOGR piogr = (ParsedIOGR) obj;
		if (this.isIOGR() && piogr.isIOGR())
			return ((this.getFTDomainId().equals(piogr.getFTDomainId())) && (this.getObjectGroupId() == piogr.getObjectGroupId()));
		else
			return super.equals(obj);
	}

	/**
	 * Return the TAG_FT_PRIMARY presence.
	 * 
	 * @return boolean
	 */
	public boolean hasPrimary() {
		return (getPrimaryProfile() != null);
	}

	/**
	 * Returns the TagFTGroupTaggedComponent from the IOR (TaggedComponent). If any exception is
	 * throwed, returns <code>null</code>.
	 * 
	 * @param tc org.omg.IOP.TaggedComponent
	 * @return org.omg.CORBA.FT.TagFTGroupTaggedComponent
	 */
	protected static TagFTGroupTaggedComponent getGroupTC(TaggedComponent tc) {
		if (tc == null)
			return null;
		CDRInputStream in = new CDRInputStream(null, tc.component_data);
		try {
			in.setLittleEndian(in.read_boolean());

			return TagFTGroupTaggedComponentHelper.read(in);
		} catch (Exception ex) {
			return null;
		}
	}

	/**
	 * Returns the TagFTPrimaryTaggedComponent from the IOR (TaggedComponent). If any exception is
	 * throwed, returns <code>null</code>.
	 * 
	 * @param tc org.omg.IOP.TaggedComponent
	 * @return org.omg.CORBA.FT.TagFTPrimaryTaggedComponent
	 */
	protected static TagFTPrimaryTaggedComponent getPrimaryTC(TaggedComponent tc) {
		if (tc == null)
			return null;
		CDRInputStream in = new CDRInputStream(null, tc.component_data);
		try {
			in.setLittleEndian(in.read_boolean());

			return TagFTPrimaryTaggedComponentHelper.read(in);
		} catch (Exception ex) {
			return null;
		}
	}

	/**
	 * Returns the TagFTRecoveryRequestTaggedComponent from the IOR (TaggedComponent). If any
	 * exception is throwed, returns <code>null</code>.
	 * 
	 * @param tc org.omg.IOP.TaggedComponent
	 * @return org.omg.CORBA.FT.TagFTRecoveryRequestTaggedComponent
	 */
	protected static TagFTRecoveryRequestTaggedComponent getRecoveryTC(TaggedComponent tc) {
		if (tc == null)
			return null;
		CDRInputStream in = new CDRInputStream(null, tc.component_data);
		try {
			in.setLittleEndian(in.read_boolean());

			return TagFTRecoveryRequestTaggedComponentHelper.read(in);
		} catch (Exception ex) {
			return null;
		}
	}

	/**
	 * Find and return the first profile that has a TAG_PRIMARY. If there is no primary, then
	 * return <code>null</code>.
	 * 
	 * @return org.omg.IIOP.ProfileBody_1_1
	 */
	protected ProfileBody_1_1 getPrimaryProfile() {
		int k = getNumberOfObjects();
		ProfileBody_1_1 pb;
		for (int i = 0; i < k; i++) {
			pb = getProfileBodies()[i];
			TaggedComponent[] tc = pb.components;
			for (int j = 0; j < tc.length; j++)
				if (tc[j].tag == TAG_FT_PRIMARY.value)
					return pb;
		}
		// no primary profile was found!
		return null;
	}

	/**
	 * Checks for TAG_FT_GROUP presence. If there is no tag, then return <code>null</code>.
	 * 
	 * @return org.omg.CORBA.FT.TagFTGroupTaggedComponent
	 */
	protected TagFTGroupTaggedComponent getTagGroup() {
		if (!tag_group_parsed) {
			tag_group = getGroupTC(getTaggedComponent(TAG_FT_GROUP.value));
			tag_group_parsed = true;
		}

		return tag_group;
	}

	/**
	 * Checks for TAG_FT_PRIMARY presence. If there is no tag, then return <code>false</code>.
	 * 
	 * @return org.omg.CORBA.FT.TagFTPrimaryTaggedComponent
	 */
	protected TagFTPrimaryTaggedComponent getTagPrimary() {
		if (!tag_primary_parsed) {
			tag_primary = getPrimaryTC(getTaggedComponent(TAG_FT_PRIMARY.value));
			tag_primary_parsed = true;
		}

		return tag_primary;
	}

	/**
	 * Checks for TAG_FT_RECOVERY_REQUEST presence. If there is no tag, then return
	 * <code>false</code>.
	 * 
	 * @return org.omg.CORBA.FT.TagFTRecoveryRequestTaggedComponent
	 */
	protected TagFTRecoveryRequestTaggedComponent getTagRecovery() {
		if (!tag_recovery_parsed) {
			tag_recovery = getRecoveryTC(getTaggedComponent(TAG_FT_RECOVERY_REQUEST.value));
			tag_recovery_parsed = true;
		}

		return tag_recovery;
	}

	/**
	 * Create an IOR object from type_id & profile body.
	 * 
	 * @param type_id java.lang.String
	 * @param pb org.omg.IIOP.ProfileBody_1_1
	 * @param with_tags if true, includes all tags present in the original IOGR
	 * @return org.omg.IOP.IOR
	 */
	protected IOR makeIOR(String type_id, ProfileBody_1_1 pb, boolean with_tags) {
		boolean endianness = false;
		TaggedProfile[] tp;
		TaggedProfile mctp = null;
		if (with_tags && (taggedComponents != null)) {
			CDROutputStream cos_mc = new CDROutputStream();
			cos_mc.write_boolean(endianness);
			MultipleComponentProfileHelper.write(cos_mc, taggedComponents);
			mctp = new TaggedProfile(TAG_MULTIPLE_COMPONENTS.value, cos_mc.getBufferCopy());
		} else
			pb.components = new TaggedComponent[0];
		TaggedProfile pbtp = null;
		if (pb != null) {
			CDROutputStream cos = new CDROutputStream();
			cos.write_boolean(endianness);
			ProfileBody_1_1Helper.write(cos, pb);
			pbtp = new TaggedProfile(TAG_INTERNET_IOP.value, cos.getBufferCopy());
		}
		if ((pbtp != null) && (mctp != null)) {
			tp = new TaggedProfile[2];
			tp[0] = pbtp;
			tp[1] = mctp;
		} else if ((pbtp == null && mctp != null) || (pbtp != null && mctp == null)) {
			tp = new TaggedProfile[1];
			tp[0] = (pbtp == null) ? mctp : pbtp;
		} else
			tp = new TaggedProfile[0];

		return new IOR(type_id, tp);
	}

	/**
	 * Initializes the ParsedIOGR. Instantiate fields.
	 */
	private void initialize() {
	}


    directory.renameFile("deleteable.new", "deletable");
  }
}
