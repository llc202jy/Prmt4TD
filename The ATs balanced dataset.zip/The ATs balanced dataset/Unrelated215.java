/**
	 * Convenient method to get profileRequest type attribute value
	 *
	 * @param doc The message document
	 * @param xpath The XPath to retrieve element value or nodelist
	 * @return The CardRange[] object
	 */
	private Object getCrValue(Document doc, String xpath) throws Exception {
		//Cr type: need return an array of type CardRange
		NodeList nl = XMLUtil.getNodeListByXPath(doc, xpath);

		if (nl.getLength() == 0)
			return null;

		//Prepare container
		CardRange[] crs = new CardRange[nl.getLength()];
		logger.debug("    Number of Card Ranges: " + crs.length);

		for (int i = 0; i < crs.length; i++) {
			Element crElement = (Element) nl.item(i);
			CardRange cr = new CardRange();

			String begin = XMLUtil.getValueByXPath(crElement, "begin/text()");
			String end = XMLUtil.getValueByXPath(crElement, "end/text()");
			String action = XMLUtil.getValueByXPath(crElement, "action/text()");

			// Validate the size of the begin card number provided
			if ((begin == null) || (begin.length() > 19) || (begin.length() < 13)) {
				logger.error("CR.begin is invalid. Value: " + begin);
				throw new MessagingException(
					"UNKNOWN",
					ErrorCodes.ERROR_CODE_5,
					ErrorCodes.ERROR_MESSAGE_5,
					"CR.begin",
					"Invalid number size.",
					"Invalid number size.");
			}

			// Validate the size of the end card number provided
			if ((end == null) || (end.length() > 19) || (end.length() < 13)) {
				logger.error("CR.begin is invalid. Value: " + end);
				throw new MessagingException(
					"UNKNOWN",
					ErrorCodes.ERROR_CODE_5,
					ErrorCodes.ERROR_MESSAGE_5,
					"CR.end",
					"Invalid number size.",
					"Invalid number size.");
			}

			// Validate to ensure the begin and end card number are of the same length
			if (begin.length() != end.length()) {
				logger.error("Card range not of same size. Begin size: " + begin.length() + " End size: " + end.length());
				throw new MessagingException(
					"UNKNOWN",
					ErrorCodes.ERROR_CODE_5,
					ErrorCodes.ERROR_MESSAGE_5,
					"CR.begin, CR.end",
					"Begin card not same length as End card",
					"Begin card not same length as End card.");
			}

			// Validate the action associate with the card range provided
			if ((action == null) || !(action.equalsIgnoreCase("A") || action.equalsIgnoreCase("D"))) {
				logger.error("CR.action is invalid. Value: " + action);
				throw new MessagingException(
					"UNKNOWN",
					ErrorCodes.ERROR_CODE_5,
					ErrorCodes.ERROR_MESSAGE_5,
					"CR.action",
					"Invalid action.",
					"Invalid action.");
			}

			try {
				cr.setBegin(Long.valueOf(begin));
			}
			catch (NumberFormatException nfe) {
				logger.error("CR.begin is invalid. Value: " + begin);
				throw new MessagingException(
					"UNKNOWN",
					ErrorCodes.ERROR_CODE_5,
					ErrorCodes.ERROR_MESSAGE_5,
					"CR.begin",
					"Invalid number format.",
					"Invalid number format.");
			}

			try {
				cr.setEnd(Long.valueOf(end));
			}
			catch (NumberFormatException nfe) {
				logger.error("CR.end is invalid. Value: " + end);
				throw new MessagingException(
					"UNKNOWN",
					ErrorCodes.ERROR_CODE_5,
					ErrorCodes.ERROR_MESSAGE_5,
					"CR.end",
					"Invalid number format.",
					"Invalid number format.");

			}

			cr.setAction(action);

			logger.debug(
				"      CR "
					+ i
					+ ":\n"
					+ "        begin: "
					+ begin
					+ "\n"
					+ "        end: "
					+ end
					+ "\n"
					+ "        action: "
					+ action);

			crs[i] = cr;
		}

		return crs;
	}

	/**
	 * check undefined elements in received messages. It checks if there is any
	 * undefined element under Message element.
	 *
	 * In turn, it checks elements under CRRes, VERes, PARes and Error elements.
	 *
	 * @param e The Message element
	 */
//	private void checkUndefinedElements(Element e) throws MessagingException {
//		try {
//			logger.debug("Checking undefined elements under Message element...");
//			Element element = XUtil.getFirstChildElement(e);
//			if (element == null) {
//				logger.error("Element missing under Message element.");
//				return;
//			}
//
//			String nodeName = element.getTagName();
//
//			if (!MSG_ELEMENTS.contains(nodeName)) {
//				logger.error("Undefined element found under Message element: " + nodeName);
//				throw new MessagingException(
//					"UNKNOWN",
//					ErrorCodes.ERROR_CODE_2,
//					ErrorCodes.ERROR_MESSAGE_2,
//					nodeName,
//					"Undefined element check failed.",
//					"Undefined element found under Message element: " + nodeName);
//			}
//
//			logger.debug("No undefined elements found under Message element.");
//
//			if ((nodeName.equals("CRRes"))
//				|| (nodeName.equals("VERes"))
//				|| (nodeName.equals("PARes"))
//				|| (nodeName.equals("Error"))) {
//				Vector validElements = (Vector) MSG_MAPPING.get(nodeName);
//				Node node = XUtil.getFirstChildElement(element);
//
//				while (node != null) {
//					if (validElements.contains(node.getNodeName()))
//						node = XUtil.getNextSiblingElement(node);
//					else {
//						logger.error(
//							"Undefined element found under " + nodeName + " element: " + node.getNodeName());
//						throw new MessagingException(
//							"UNKNOWN",
//							ErrorCodes.ERROR_CODE_2,
//							ErrorCodes.ERROR_MESSAGE_2,
//							nodeName,
//							"Undefined element check failed.",
//							"Undefined element found under " + nodeName + " element: " + node.getNodeName());
//					}
//				}
//
//				logger.debug("No undefined elements found under " + nodeName + " element.");
//			}
//		}
//		catch (Exception exc) {
//			logger.error("Exception caught during Undefined elements checking.", exc);
//			throw new MessagingException(exc);
//		}
//	}

	private Class getJavatypeClass(String javatype) throws Exception {
		try {
			//Filter array
			int inx = javatype.indexOf("[]");

			if (inx > 0) {
				//Array class
				String arraytype = javatype.substring(0, inx);
				Object result = Array.newInstance(Class.forName(arraytype), 0);
				return result.getClass();
			}
			else {
				//Not array class
				return Class.forName(javatype);
			}
		}
		catch (Exception e) {
			logger.error("Failed to get javatype class: " + javatype, e);
			throw new NullPointerException("Failed to get javatype class: " + javatype);
		}
	}

	private Element findDefinedMessageElement(String id, Element msg) throws Exception {
		//Get Message element's first child
		Element e = XUtil.getFirstChildElement(msg);

		if (e == null) {
			logger.error("The first element under Message is not defined message element.");
			throw new MessagingException(
				id,
				ErrorCodes.ERROR_CODE_3,
				ErrorCodes.ERROR_MESSAGE_3,
				"Message element",
				"Message element missign.",
				"Message element missing.");

		}

		//check element name
		String tagName = e.getTagName();
		if (MSG_ELEMENTS.contains(tagName)) {
			return e;
		}
		else {
			logger.error("The first element under Message is not defined message element.");
			throw new MessagingException(
				id,
				ErrorCodes.ERROR_CODE_2,
				ErrorCodes.ERROR_MESSAGE_2,
				tagName,
				"No defined message element found.",
				"No defined message element found.");
		}
	}
}

/**
	 * Convenient method to get extension type attribute value
	 *
	 * @param doc The message document
	 * @param xpath The XPath to retrieve element value or nodelist
	 * @return The Extension[] object.
	 */
	private Object getExtensionValue(Document doc, String xpath) throws Exception {
		//Extension type: need return an array of type Extension
		NodeList nl = XMLUtil.getNodeListByXPath(doc, xpath);

		if (nl.getLength() == 0)
			return null;

		//Prepare container
		Extension[] value = new Extension[nl.getLength()];
		logger.debug("    Extension no.: " + value.length);

		//Get all the values
		for (int i = 0; i < value.length; i++) {
			//Get extension element
			Element extElement = (Element) nl.item(i);

			//Prepare Extension object
			Extension ext = new Extension();

			//id attribute missing
			if (extElement.getAttributeNode(THREED_MSG_ID) == null) {
				logger.error("Extension missing id attribute.");
				throw new MessagingException(
					"UNKNOWN",
					ErrorCodes.ERROR_CODE_3,
					ErrorCodes.ERROR_MESSAGE_3,
					"Extension.id",
					"Extension missing id attribute.",
					"Extension missing id attribute.");
			}
            // Set the extension ID
			ext.setExtID(extElement.getAttribute(THREED_MSG_ID));

			// critical attribute missing
			if (extElement.getAttributeNode(EXTENSION_CRITICAL) == null) {
                // Correction for BugID:648
                // From page 88 of VISA spec: a missing critical attribute is equivalent to
                // false critical extension. However a critical extension with no value should
				// no be OK
                ext.setCritical("false");
			}
            else {
                // Critical attribute is specified so we use that value
                ext.setCritical(extElement.getAttribute(EXTENSION_CRITICAL));
            }
			// Set attribute values
			ext.setExtValue(XMLUtil.getValueByXPath(extElement, "text()"));

			// Set extension object in container
			value[i] = ext;
		}

		//return result
		return value;
	}

	/**
	 * Convenient method to get attr type attribute value
	 *
	 * @param doc The message document
	 * @param xpath The XPath to retrieve element value or nodelist
	 * @return The attribute value.
	 */
	private Object getAttrValue(Document doc, String xpath) throws Exception {
		//attrValue type: Get value
		Node node = XMLUtil.getFirstNodeByXPath(doc, xpath);

		if (node == null)
			return null;
		else
			return node.getNodeValue();
	}

	/**
	 * Convenient method to get profileRequest type attribute value
	 *
	 * @param doc The message document
	 * @param xpath The XPath to retrieve element value or nodelist
	 * @return The ProfileRequestScope[] object
	 */
	private Object getProfileRequestValue(Document doc, String xpath) throws Exception {
		//Profile request type: need return an array of type ProfileRequestScope
		NodeList nl = XMLUtil.getNodeListByXPath(doc, xpath);

		if (nl.getLength() == 0)
			return null;

		//Prepare container
		ProfileRequestScope[] value = new ProfileRequestScope[nl.getLength()];
		logger.debug("    Profile request scope no.: " + value.length);

		//Get all the values
		for (int i = 0; i < value.length; i++) {
			//Get profileRequestScope element
			Element scopeElement = (Element) nl.item(i);

			//Prepare ProfileRequestScope object
			ProfileRequestScope prs = new ProfileRequestScope();

			//Set attribute values
			prs.setScopeid(scopeElement.getAttribute(PROFILE_SCOPE_ID));

			//Get all profileRequestItem elements
			NodeList itemElements = XMLUtil.getNodeListByXPath(scopeElement, PROFILE_REQUEST_ITEM);

			//Prepare container
			String[] items = new String[itemElements.getLength()];
			logger.debug("      Scope[" + i + "] ID: " + prs.getScopeid() + " Item no.: " + items.length);

			//Set all profileRequestItem value
			for (int j = 0; j < items.length; j++) {
				//Get individual profileRequestItem element
				Element itemElement = (Element) itemElements.item(j);

				//Get id attribute value
				items[j] = itemElement.getAttribute(PROFILE_UID);
			}

			//Set item values to profileRequestScope
			prs.setRequestItem(items);

			//Set profileRequestScope object in container
			value[i] = prs;
		}

		//return result
		return value;
	}

	/**
	 * Convenient method to get signature type attribute value
	 *
	 * @param doc The message document
	 * @param xpath The XPath to retrieve element value or nodelist
	 * @return The Signature element.
	 */
	private Object getSignatureValue(Document doc, String xpath) throws Exception {
		//Get signature parent element
		Element parent = (Element) XMLUtil.getFirstNodeByXPath(doc, xpath);

		//Get signature element
		NodeList nl = parent.getElementsByTagName(SIGNATURE_TAG_NAME);
		if (nl.getLength() == 0)
			return null;

		Element signature = (Element) nl.item(0);

		//Create wrap document
		Document doc2 = XMLUtil.createDocument();

		//Import signature to wrap document
		doc2.appendChild(doc2.importNode(signature, true));

		//return String who represents this document
		return XMLUtil.toXmlString(doc2);
	}

	
package com.oncecorp.visa3d.mpi.messaging;

import com.oncecorp.visa3d.mpi.configuration.Config;
import com.oncecorp.visa3d.mpi.configuration.ConfigurationException;
import com.oncecorp.visa3d.mpi.configuration.MPIConfigDefinition;
import com.oncecorp.visa3d.mpi.controller.AuthenticatorSession;
import com.oncecorp.visa3d.mpi.domain.payment.CRReqMessage;
import com.oncecorp.visa3d.mpi.domain.payment.CRResMessage;
import com.oncecorp.visa3d.mpi.domain.payment.PAResMessage;
import com.oncecorp.visa3d.mpi.domain.payment.VEResMessage;
import com.oncecorp.visa3d.mpi.domain.profile.IPResMessage;
import com.oncecorp.visa3d.mpi.intf.payment.PaymentAuthResMessage;
import com.oncecorp.visa3d.mpi.intf.payment.PaymentVerifResMessage;
import com.oncecorp.visa3d.mpi.intf.profile.ProfileAuthResMessage;
import com.oncecorp.visa3d.mpi.intf.profile.ProfileVerifResMessage;
import com.oncecorp.visa3d.mpi.logging.MPILogger;
import com.oncecorp.visa3d.mpi.messaging.meta.MessageUID;
import com.oncecorp.visa3d.mpi.monitoring.PerformanceMonitorMBean;
import com.oncecorp.visa3d.mpi.utility.Utils;

import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;

/**
 * Class description
 *
 * @author azhang
 * @author Gang Wu ( gwu@oncecorp.com )
 * @version 1.0 3-Dec-02
 */
public class PerformanceMonitor implements PerformanceMonitorMBean {

	/**
	 * Martin's Note - Jan 24 - 2003 @ 16:52
	 * Removing profile message that are not needed for the MPI now
	 */

	/*
		private final String[][] STATUS_CATEGORY =
			new String[][] { { "Authenticated", "PaymentAuthRes" }, {
				"Authenticated", "ProfileAuthRes" }, {
				"Authenticated", "PARes" }, {
				"Authenticated", "IPRes" }, {
				"Not Authenticated", "PaymentAuthRes" }, {
				"Not Authenticated", "ProfileAuthRes" }, {
				"Not Authenticated", "PARes" }, {
				"Not Authenticated", "IPRes" }, {
				"Enrolled", "VERes" }, {
				"Enrolled", "PaymentVerifRes" }, {
				"Enrolled", "ProfileVerifRes" }, {
				"Not Enrolled", "PaymentVerifRes" }, {
				"Not Enrolled", "ProfileVerifRes" }, {
				"Not Enrolled", "VERes" }, {
				"Unknown", "PaymentVerifRes" }, {
				"Unknown", "PaymentAuthRes" }, {
				"Unknown", "ProfileVerifRes" }, {
				"Unknown", "ProfileAuthRes" }, {
				"Unknown", "VERes" }, {
				"Unknown", "IPRes" }, {
				"Unknown", "PARes" }
		};
	*/

	private final String[][] STATUS_CATEGORY =
		new String[][] { { "Authenticated", "PaymentAuthRes" }, {
			"Authenticated", "PARes" }, {
			"Not Authenticated", "PaymentAuthRes" }, {
			"Not Authenticated", "PARes" }, {
			"Enrolled", "VERes" }, {
			"Enrolled", "PaymentVerifRes" }, {
			"Not Enrolled", "PaymentVerifRes" }, {
			"Not Enrolled", "VERes" }, {
			"Unknown", "PaymentVerifRes" }, {
			"Unknown", "PaymentAuthRes" }, {
			"Unknown", "VERes" }, {
			"Unknown", "PARes" }
	};

	private final String AUTHENTICATED = "Authenticated";
	private final String NOT_AUTHENTICATED = "Not Authenticated";
	private final String ENROLLED = "Enrolled";
	private final String NOT_ENROLLED = "Not Enrolled";
	private final String UNKNOWN = "Unknown";

	/**
	 * Local logger
	 */
	protected static Logger logger =
		MPILogger.getLogger(PerformanceMonitor.class.getName());

	/**
	 * Synchronized token
	 */
	protected static byte[] token = new byte[] { 0 };

	/**
	 * singleton instance
	 */
	private static PerformanceMonitor performanceMonitor;

	/**
	 * TreeMap contains MessageUID/Individual message counter
	 */
	private static Map msgTypeCounters;

	/**
	 * TreeMap contains StatusCategoryID/counter
	 */
	private  static Map msgStatusCounters;

	/**
	 * TreeMap contains MerchantID/counter
	 */
	private static Map msgMerchantIDCounters;

	/**
	 * Total processed message counter
	 */
	private static long totalCounter;

	/**
	 * Peak TPS(Transaction per second)
	 */
	private static float peakTPS;

	/**
	 * Average TPS
	 */
	private static float averageTPS;

	/**
	 * Sampling time (in secs)
	 */
	private static long samplingTime;

	/**
	 * Counting startup time
	 */
	private static long statupTime;

	/**
	 * Peak time
	 */
	private static long peakTime;

	/**
	 * Last flush time
	 */
	private static long lastFlushTime;

	/**
	 * Last flush counter
	 */
	private static long lastFlushCounter;

	// zero counter backup
	private static Map zeroTypeCounter;
	private static Map zeroStatusCounter;
	private static Map zeroMerchantCounter;

	/**
	 * Constructor
	 */
	public PerformanceMonitor() {
		if (performanceMonitor == null) {

			performanceMonitor = this;

			// Get all message definition to retrieve message UIDs
			HashMap meta =
				(HashMap) (new MessagingConfigAccessor()).getConfigData();

			// Initialize counters per message type
			msgTypeCounters = Collections.synchronizedMap( new TreeMap() );
            zeroTypeCounter = Collections.synchronizedMap(new TreeMap() );
			Iterator iterator = meta.keySet().iterator();
			int i = 0;
            String key;
			while (iterator.hasNext()) {
				MessageUID uid = (MessageUID) iterator.next();
				logger.debug("Meta UID: " + uid.toString());

				/*
				 * [Alan's Note - Jan 24, 2003]
				 * We are not counting CR messages, so don't include
				 * them in the mapping
				 */
				if (!uid.getName().equals(CRReqMessage.MSG_TYPE)
					&& !uid.getName().equals(CRResMessage.MSG_TYPE)) {
					// Create counter for this UID
                    key = Utils.getMessageMappingKey(
                            uid.getName(), uid.getVersion() );
					msgTypeCounters.put(key,  getZeroProtocolCounter() );
                    zeroTypeCounter.put(key,  getZeroProtocolCounter() );
				}
			}


			// Initialize counters per status
			msgStatusCounters = Collections.synchronizedMap( new TreeMap() );
            zeroStatusCounter = Collections.synchronizedMap( new TreeMap() );
			for (int k = 0; k < STATUS_CATEGORY.length; k++) {
                key = Utils.getMessageMappingKey(
                        STATUS_CATEGORY[k][0],
						STATUS_CATEGORY[k][1]);

				msgStatusCounters.put( key, getZeroProtocolCounter());
                zeroStatusCounter.put( key, getZeroProtocolCounter());
			}


			// Initialize counters per merchant ID
			msgMerchantIDCounters = Collections.synchronizedMap( new TreeMap() );
            zeroMerchantCounter = Collections.synchronizedMap( new TreeMap() );
			Iterator merchantList = null;
			try {
				merchantList =
					((Map) Config
						.getConfigReference()
						.getMerchantConfigData())
						.keySet()
						.iterator();
			} catch (ConfigurationException e) {
				logger.error(
					"Failed to retrieve merchant list from config.",
					e);
			}
			String temp = null;
			while (merchantList.hasNext()) {
				temp = (String) merchantList.next();
				msgMerchantIDCounters.put(temp, getZeroProtocolCounter());
                zeroMerchantCounter.put(temp, getZeroProtocolCounter());
			}

			//Set startup, lastFlush time and peakTime
			long current = Calendar.getInstance().getTime().getTime();
			setStatupTime(current);
			setLastFlushTime(current);
			setPeakTime(current);

			// Get sampling time
			String time = null;
			try {
				time =
					(String) Config.getConfigReference().getConfigData(
						MPIConfigDefinition.PERFOMANCE_MONITOR_SAMPLING_TIME);

				setSamplingTime(Long.parseLong(time));
			} catch (ConfigurationException e) {
				logger.error(
					"Failed to retrieve sampling time from config.",
					e);
			} catch (NumberFormatException nfe) {
				logger.error("Failed to convert sampling time: " + time, nfe);
			}

			logger.debug(
				"PerformanceMonitor status: "
					+ "Total count: "
					+ getTotalCounter()
					+ ", Startup time: "
					+ getStatupTime());
		}

	}

	public synchronized static PerformanceMonitor getInstance() {
		if (performanceMonitor == null) {
			performanceMonitor = new PerformanceMonitor();
			logger.info("Performance Monitor init finished.");
		}

		return performanceMonitor;
	}

	/**
	 * Count message.
	 * Following counters will be increased:
	 * <ul>
	 * <li>counter per message type</li>
	 * <li>counter per status</li>
	 * <li>counter per merchantID</li>
	 * <li>overall total counter</li>
	 * </ul>
	 *
	 * Following performance statistic index will be calculated:
	 * <ul>
	 * <li>average TPS</li>
	 * <li>peak TPS</li>
	 * </ul>
	 *
	 * @param msg The message to be counted
	 * @param merID The merchantID
	 */
	public void count(Message msg, String merID) {
		synchronized (token) {
			Map counter = null;

			// Increase counter per message type first
			// Create UID
            String key = Utils.getMessageMappingKey( msg.getType(), msg.getVersion() );
            String protocol = "" + Utils.toProtocolByte(
                    AuthenticatorSession.instance().getProtocol() );

			// Get counter by UID
			counter = (Map) getMsgTypeCounters().get(key);

            increaseMapItemValue( counter, protocol );
            increaseMapItemValue( counter, ""+Utils.ALL_SUPPORT );

			logger.debug("Counter per type increased: " + key );

			// Increase counter per status
			// Categorize message
			StatusCategoryID scid = categorize(msg);
			if (scid != null) {
                key = Utils.getMessageMappingKey( scid.getStatus(),
                        scid.getMsgType() );
				counter = (Map) getMsgStatusCounters().get(key);
                increaseMapItemValue( counter, protocol );
                increaseMapItemValue( counter, ""+Utils.ALL_SUPPORT );
				logger.debug(
					"Counter per status increased: " + scid.toString());
			} else {
				logger.debug("Message is not belong to status category.");
			}

			// Increase counter per merchantID
			// Check counter existence
			if (getMsgMerchantIDCounters().get(merID) == null) {
				// Counter not exist, create one for this merchant ID
				msgMerchantIDCounters.put(merID, getZeroProtocolCounter());
				zeroMerchantCounter.put(merID, getZeroProtocolCounter());
				logger.debug("New counter created for merchant: " + merID);
			}
			// Counter exist, increase counter
			counter = (Map) getMsgMerchantIDCounters().get(merID);
            increaseMapItemValue( counter, protocol );
            increaseMapItemValue( counter, ""+Utils.ALL_SUPPORT );
			logger.debug("Counter increaed for merchant: " + merID);

			// Increase total counter
			setTotalCounter(getTotalCounter() + 1);
			logger.debug("New total count: " + getTotalCounter());

			long current = Calendar.getInstance().getTime().getTime();

			// Recalculate average TPS
			long period = (current - getLastFlushTime()) / 1000;
			logger.debug("Average period: " + period);
			if (period != 0) {
				setAverageTPS((float) getTotalCounter() / period);
				logger.debug("New average TPS: " + getAverageTPS());
			}

			// Flush peak TPS if necessary
			period = (current - getPeakTime()) / 1000;
			logger.debug("Peak period: " + period);
			if (period >= getSamplingTime()) {
				float newPeakTPS = (float) getTotalCounter() / period;

				if (newPeakTPS > getPeakTPS()) {
					setPeakTPS(newPeakTPS);
					logger.debug("New peak TPS:" + getPeakTPS());
				}

				//setLastFlushCounter(getTotalCounter());
				setPeakTime(current);
			}
		}
	}

	/**
	 * Analyze message to sort out status category
	 * @param msg The message
	 * @return The StatusCategory. Return Null if the message is not belong to any category
	 */
	private StatusCategoryID categorize(Message msg) {
		String status = null;
		if (msg instanceof PaymentAuthResMessage) {
			status = ((PaymentAuthResMessage) msg).getStatus();
			if (status.equalsIgnoreCase("Y") || status.equalsIgnoreCase("A")) {
				return new StatusCategoryID(AUTHENTICATED, msg.getType());
			} else {
				if (status.equalsIgnoreCase("N")) {
					return new StatusCategoryID(
						NOT_AUTHENTICATED,
						msg.getType());
				} else {
					if (status.equalsIgnoreCase("U")) {
						return new StatusCategoryID(UNKNOWN, msg.getType());
					} else {
						return null;
					}
				}
			}
		} else {
			if (msg instanceof PaymentVerifResMessage) {
				status = ((PaymentVerifResMessage) msg).getEnrolled();
				if (status.equalsIgnoreCase("Y")) {
					return new StatusCategoryID(ENROLLED, msg.getType());
				} else {
					if (status.equalsIgnoreCase("N")) {
						return new StatusCategoryID(
							NOT_ENROLLED,
							msg.getType());
					} else {
						if (status.equalsIgnoreCase("U")) {
							return new StatusCategoryID(UNKNOWN, msg.getType());
						} else {
							return null;
						}
					}
				}
			} else {
				if (msg instanceof PAResMessage) {
					status = ((PAResMessage) msg).getTxStatus();
					if (status.equalsIgnoreCase("Y")
						|| status.equalsIgnoreCase("A")) {
						return new StatusCategoryID(
							AUTHENTICATED,
							msg.getType());
					} else {
						if (status.equalsIgnoreCase("N")) {
							return new StatusCategoryID(
								NOT_AUTHENTICATED,
								msg.getType());
						} else {
							if (status.equalsIgnoreCase("U")) {
								return new StatusCategoryID(
									UNKNOWN,
									msg.getType());
							} else {
								return null;
							}
						}
					}
				} else {
					if (msg instanceof VEResMessage) {
						status = ((VEResMessage) msg).getEnrolled();
						if (status.equalsIgnoreCase("Y")) {
							return new StatusCategoryID(
								ENROLLED,
								msg.getType());
						} else {
							if (status.equalsIgnoreCase("N")) {
								return new StatusCategoryID(
									NOT_ENROLLED,
									msg.getType());
							} else {
								if (status.equalsIgnoreCase("U")) {
									return new StatusCategoryID(
										UNKNOWN,
										msg.getType());
								} else {
									return null;
								}
							}
						}
					} else {
						if (msg instanceof ProfileAuthResMessage) {
							status = ((ProfileAuthResMessage) msg).getStatus();
							if (status.equalsIgnoreCase("Y")) {
								return new StatusCategoryID(
									AUTHENTICATED,
									msg.getType());
							} else {
								if (status.equalsIgnoreCase("N")) {
									return new StatusCategoryID(
										NOT_AUTHENTICATED,
										msg.getType());
								} else {
									if (status.equalsIgnoreCase("U")) {
										return new StatusCategoryID(
											UNKNOWN,
											msg.getType());
									} else {
										return null;
									}
								}
							}
						} else {
							if (msg instanceof ProfileVerifResMessage) {
								status =
									((ProfileVerifResMessage) msg)
										.getEnrolled();
								if (status.equalsIgnoreCase("Y")) {
									return new StatusCategoryID(
										ENROLLED,
										msg.getType());
								} else {
									if (status.equalsIgnoreCase("N")) {
										return new StatusCategoryID(
											NOT_ENROLLED,
											msg.getType());
									} else {
										if (status.equalsIgnoreCase("U")) {
											return new StatusCategoryID(
												UNKNOWN,
												msg.getType());
										} else {
											return null;
										}
									}
								}
							} else {
								if (msg instanceof IPResMessage) {
									status = ((IPResMessage) msg).getTxStatus();
									if (status.equalsIgnoreCase("Y")) {
										return new StatusCategoryID(
											AUTHENTICATED,
											msg.getType());
									} else {
										if (status.equalsIgnoreCase("N")) {
											return new StatusCategoryID(
												NOT_AUTHENTICATED,
												msg.getType());
										} else {
											if (status.equalsIgnoreCase("U")) {
												return new StatusCategoryID(
													UNKNOWN,
													msg.getType());
											} else {
												return null;
											}
										}
									}
								} else {
									return null;
								}
							}
						}
					}
				}
			}
		}

	}

    /**
     * Returns statistic result per message type
     * @return The vector contains MsgTypeStatisticResult objects
     */
    public Map optMsgTypeStatistic() {
        return PerformanceMonitor.getMsgTypeCounters();
    }

    /**
     * Returns statistic result per status
     * @return The map contains MsgStatusStatisticResult objects
     */
    public Map optMsgStatusStatistic() {
        return PerformanceMonitor.getMsgStatusCounters();
    }

    /**
     * Returns statistic result per merchantID
     * @return The map contains MsgMerchantIDStatisticResult objects
     */
    public Map optMsgMerchantIDStatistic() {
        return PerformanceMonitor.getMsgMerchantIDCounters();
    }

	/**
	 * Flush total counter
	 */
	public void optFlush() {
		synchronized (token) {
			setLastFlushCounter(getTotalCounter());
			setTotalCounter(0);
			setPeakTPS(0);
			setAverageTPS(0);
			setPeakTime(Calendar.getInstance().getTime().getTime());
			setLastFlushTime(Calendar.getInstance().getTime().getTime());

			/*
			 * [Alan's Note - Jan 24, 2003]
			 * Flush statistic counters as well.
			 */
			setMsgTypeCounters( initZeroCounter(zeroTypeCounter) );
			setMsgStatusCounters( initZeroCounter(zeroStatusCounter) );
			setMsgMerchantIDCounters( initZeroCounter(zeroMerchantCounter) );
		}
	}

    /**
     * Make zero counter
     * @param map
     * @return
     */
    public static Map initZeroCounter( Map map )
    {
        Map newmap = Collections.synchronizedMap( new TreeMap() );

        for ( Iterator lt = map.keySet().iterator(); lt.hasNext(); )
        {
            newmap.put( lt.next(), getZeroProtocolCounter() );
        }

        return newmap;
    }

	/**
	 * Returns the averageTPS.
	 * @return long
	 */
	public float getAverageTPS() {
		return averageTPS;
	}

	/**
	 * Returns the counters.
	 * @return TreeMap
	 */
	public static Map getMsgTypeCounters() {
		return PerformanceMonitor.msgTypeCounters;
	}

	/**
	 * Returns the peakTPS.
	 * @return long
	 */
	public float getPeakTPS() {
		return peakTPS;
	}

	/**
	 * Returns the samplingTime.
	 * @return long
	 */
	public long getSamplingTime() {
		return samplingTime;
	}

	/**
	 * Returns the totalCounter.
	 * @return long
	 */
	public long getTotalCounter() {
		return totalCounter;
	}

	/**
	 * Sets the averageTPS.
	 * @param averageTPS The averageTPS to set
	 */
	public static void setAverageTPS(float averageTPS) {
		PerformanceMonitor.averageTPS = averageTPS;
	}

	/**
	 * Sets the counters.
	 * @param counters The counters to set
	 */
	public static void setMsgTypeCounters( Map counters ) {
		PerformanceMonitor.msgTypeCounters = counters;
	}

	/**
	 * Sets the peakTPS.
	 * @param peakTPS The peakTPS to set
	 */
	public static void setPeakTPS(float peakTPS) {
		PerformanceMonitor.peakTPS = peakTPS;
	}

	/**
	 * Sets the samplingTime.
	 * @param samplingTime The samplingTime to set
	 */
	public void setSamplingTime(long samplingTime) {
		PerformanceMonitor.samplingTime = samplingTime;
	}

	/**
	 * Sets the totalCounter.
	 * @param totalCounter The totalCounter to set
	 */
	public static void setTotalCounter(long totalCounter) {
		PerformanceMonitor.totalCounter = totalCounter;
	}

	/**
	 * Returns the lastFlushTime.
	 * @return long
	 */
	public long getPeakTime() {
		return peakTime;
	}

	/**
	 * Returns the statupTime.
	 * @return long
	 */
	public long getStatupTime() {
		return statupTime;
	}

	/**
	 * Sets the lastFlushTime.
	 * @param lastFlushTime The lastFlushTime to set
	 */
	public static void setPeakTime(long lastFlushTime) {
		PerformanceMonitor.peakTime = lastFlushTime;
	}

	/**
	 * Sets the statupTime.
	 * @param statupTime The statupTime to set
	 */
	public static void setStatupTime(long statupTime) {
		PerformanceMonitor.statupTime = statupTime;
	}

	/**
	 * Returns the lastFlushCounter.
	 * @return long
	 */
	public long getLastFlushCounter() {
		return lastFlushCounter;
	}

	/**
	 * Sets the lastFlushCounter.
	 * @param lastFlushCounter The lastFlushCounter to set
	 */
	public static void setLastFlushCounter(long lastFlushCounter) {
		PerformanceMonitor.lastFlushCounter = lastFlushCounter;
	}

	/**
	 * Returns the msgStatusCounters.
	 * @return TreeMap
	 */
	public static Map getMsgStatusCounters() {
		return PerformanceMonitor.msgStatusCounters;
	}

	/**
	 * Returns the msgMerchantIDCounters.
	 * @return TreeMap
	 */
	public static Map getMsgMerchantIDCounters() {
		return PerformanceMonitor.msgMerchantIDCounters;
	}

	/**
	 * Returns the lastFlushTime.
	 * @return long
	 */
	public long getLastFlushTime() {
		return lastFlushTime;
	}

	/**
	 * Sets the lastFlushTime.
	 * @param lastFlushTime The lastFlushTime to set
	 */
	public static void setLastFlushTime(long lastFlushTime) {
		PerformanceMonitor.lastFlushTime = lastFlushTime;
	}

	/**
	 * Sets the msgStatusCounters.
	 * @param msgStatusCounters The msgStatusCounters to set
	 */
	public static void setMsgStatusCounters(  Map msgStatusCounters ) {
		PerformanceMonitor.msgStatusCounters = msgStatusCounters;
	}

	/**
	 * Sets the msgMerchantIDCounters.
	 * @param msgMerchantIDCounters The msgMerchantIDCounters to set
	 */
	public static void setMsgMerchantIDCounters( Map msgMerchantIDCounters ) {
		PerformanceMonitor.msgMerchantIDCounters = msgMerchantIDCounters;
	}

    /**
     * Increase the mapping item integer value
     */
    public static void increaseMapItemValue( Map props, String key )
    {
        if ( props == null || key == null )
            return;

        Long value = (Long)props.get( key );
        if ( value != null )
            props.put( key, new Long( value.longValue() + 1 ) );
    }

    /**
     *
     * @return - counters mapping divided by protocol
     */
    public static Map getZeroProtocolCounter()
    {
        Map counters = Collections.synchronizedMap( new TreeMap() );

        counters.put( ""+ Utils.VISA_SUPPORT, new Long(0) );
        counters.put( ""+ Utils.MASTER_SUPPORT, new Long(0) );
        counters.put( ""+ Utils.ALL_SUPPORT, new Long(0) );

        return counters;
    }}

package com.oncecorp.visa3d.mpi.messaging;

import com.oncecorp.visa3d.mpi.configuration.ConfigAccessor;
import com.oncecorp.visa3d.mpi.logging.MPILogger;
import com.oncecorp.visa3d.mpi.messaging.meta.BindingMetaInfo;
import com.oncecorp.visa3d.mpi.messaging.meta.MessageMetaInfo;
import com.oncecorp.visa3d.mpi.messaging.meta.MessageUID;
import com.oncecorp.visa3d.mpi.utility.XMLUtil;

import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 * Description: This class implements ConfigAccessor interface to actually
 * load/update Messaging Mapping data from/to file/CMP for caller's
 * request
 *
 * @version 0.1 July 20, 2002
 * @author	Jun Shi
 */

public class MessagingConfigAccessor implements ConfigAccessor {

	// init a flag
	private static boolean initialized = false;

	// init mapping repository
	private static HashMap allConfigData;

	// local Log4J logger
	private static Logger logger = MPILogger.getLogger(MessagingConfigAccessor.class.getName());

	/** ConvertionBindings Definition */
	private static final String MESSAGE_DEFINITION_FILE	= "MessageDefinition.xml";

	// Element: Binding
	private final static String MESSAGE_TYPE_XMLATTR 	= "type";
	private final static String MESSAGE_VERSION_XMLATTR = "version";

	private final static String ENTRY_PATH 		= "path";
	private final static String ENTRY_ATTRIBUTE = "attribute";
	private final static String ENTRY_TYPE		= "type";
	private final static String ENTRY_JAVATYPE	= "javatype";

	private final static String MESSAGE_DEFINITION_XMLPATH 	= "/messageDefinition/message";
	private final static String MESSAGE_BINDING_XMLPATH 	= "./bindings/entry";
	private final static String MESSAGE_TRANSFORMER_XMLPATH = "./transformers/transform";
	private final static String MESSAGE_EXTENSION_XMLPATH 	= "./extensions/extension";

	/**
	 * [MessagingConfigAccessor] implements two public methods in [ConfigAccessor]
	 * interface, i.e. [.getConfigData] and [.setConfigData]. Current version,
	 * [MessagingConfigAccessor.getConfigData] loads data from [MessageDefinition.xml]
	 * and stores both "MessageMapping" and "ProcessorMapping"  etc. information in
	 * "allConfigData:HashMap" and returns as Serializable.
	 *
	 * @param none
	 * @return Serializable (allConfigData)
	 */
	public Serializable getConfigData() {
		/** loading once */
		if (! initialized) {
			logger.debug("First Time initial starting ...");
			return initialize();
		}
		else {
			logger.debug("Initial already done before, Just Return allConfigData...");
			return allConfigData;
		}
	}

	private HashMap initialize() throws FactoryConfigurationError {
		// init mapping repository
		allConfigData = new HashMap();

		// loading the message definition file
		// The class loading mechanisn in Weblogic and in Tomcat is different
		// so we have to try two strategies to load that configuration file
		InputStream is = Thread.currentThread().getContextClassLoader()
				 .getResourceAsStream(MESSAGE_DEFINITION_FILE);

		// Try with the second strategy
		if (is == null) {
			is = this.getClass().getResourceAsStream(MESSAGE_DEFINITION_FILE);
		}

		// Still not working then we need to exit from here....
		if (is == null) {
			logger.debug("Unable to find " + MESSAGE_DEFINITION_FILE);
			throw new RuntimeException("Unable to read the message definition file as a resource");
		}
		else {
			logger.debug("[MessageDefinition.xml] is loaded properly");
		}

		/** create DOM object for [MessageDefinition.xml] */
		Element root = null;
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(is);

			// do logging
			logger.debug("Building DOM of [MessageDefinition.xml] completed!!");

			// get root element
			root = doc.getDocumentElement();
		}
		catch (Exception e) {
			logger.error("[.getConfigData] loading [MessageDefinition.xml] failed!!", e);
			e.printStackTrace();
		}

		/** loading Message Mapping */
		NodeList msgDef = XMLUtil.getNodeListByXPath(root, MESSAGE_DEFINITION_XMLPATH);
		if ((msgDef == null) || (msgDef.getLength() == 0)) {
			logger.debug("NO Message Mapping Information Found!!!");
		}

		// Load message definition
		Element currentMsgDef;
		for (int i = 0; i < msgDef.getLength(); i++) {
			MessageMetaInfo metaInfo = new MessageMetaInfo();
			currentMsgDef = (Element) msgDef.item(i);

			// Retrieve message definition items
			String name = currentMsgDef.getAttribute("name");
			String version = currentMsgDef.getAttribute("version");
			String impl = currentMsgDef.getAttribute("impl");
			String processor = currentMsgDef.getAttribute("processor");
			String protocol = currentMsgDef.getAttribute("protocol");
			metaInfo.setName(name);
			metaInfo.setSupportedVersion(parseSupportedVersion(version));
			metaInfo.setImpl(impl);
			metaInfo.setProcessor(processor);
			metaInfo.setProtocol(protocol);

			// Load transformer definition
			loadTransformerDefinition(currentMsgDef, metaInfo);

			// Load binding definition
			loadBindingDefinition(currentMsgDef, metaInfo);

			// Load extension definitions
			loadExtensionDefinition(currentMsgDef, metaInfo);

			// Now we stored a metainfo object per message name/version
			String msgName = metaInfo.getName();
			ArrayList versions = metaInfo.getSupportedVersion();
			for (int j = 0; j < versions.size(); j++) {
				String msgVersion = (String) versions.get(j);

				allConfigData.put(new MessageUID(msgName, msgVersion), metaInfo);
			}
		}

	   // set flag
       initialized = true;

       //do logging
       logger.debug("Messaging Definition loading finished");

	   // return to caller
	   return allConfigData;
	}

	/**
	 * Parse version string and extract all supported versions.
	 * @param version		All supported versions separated by commas
	 * @return ArrayList	Each item is the version number
	 */
	private ArrayList parseSupportedVersion(String version) {
		StringTokenizer tokenizer = new StringTokenizer(version, ", ");
		ArrayList versions = new ArrayList();

		// Extract all version numbers separated by ';'
		while (tokenizer.hasMoreTokens()) {
			String token = tokenizer.nextToken();
			if (token != null) {
				versions.add(token);
			}
		}
		logger.debug("Version supported information:" + versions.toString());
		return versions;
	}

	private void loadExtensionDefinition(Element root, MessageMetaInfo metaInfo) {
	}

	private void loadBindingDefinition(Element supportElement, MessageMetaInfo metaInfo) {
		NodeList nl;
		Element current;
		BindingMetaInfo bInfo = null;

		/** loading ConvertionBindings Mappings */
		nl = XMLUtil.getNodeListByXPath(supportElement, MESSAGE_BINDING_XMLPATH);

		if ((nl == null) || (nl.getLength() == 0)) {
			logger.debug("NO binding information Found!!!");
		}

		try {
			bInfo = this.getDomToMessageMapping(nl);
		}
		catch (Exception e) {
			e.printStackTrace();
			logger.debug("loading ConvertionBindings Mapping Info Exception !!");
		}
		metaInfo.setBindings(bInfo);
	}

	private void loadTransformerDefinition(Element messageElement, MessageMetaInfo metaInfo) {
		NodeList nl;
		Element current;
		HashMap transformers = new HashMap();

		// Loading Transformer Mapping info
		nl = XMLUtil.getNodeListByXPath(messageElement, MESSAGE_TRANSFORMER_XMLPATH);
		if ((nl == null) || (nl.getLength() == 0)) {
			logger.debug("NO Transformer Mapping Information Found!!!");
		}

		for (int i = 0; i < nl.getLength(); i++) {
			current = (Element) nl.item(i);

			String toMessage = current.getAttribute("to");
			String toVersion = current.getAttribute("version");
			String impl = current.getAttribute("impl");

			// Create messageUID and use it as key to insert proper
			// transformer implementation
			MessageUID uid = new MessageUID(toMessage, toVersion);
			transformers.put(uid, impl);
		}
		// Update meta info with new transformer structure
		metaInfo.setTransformers(transformers);
	}

	// Actual loading ConvertionBindings method */
	private BindingMetaInfo getDomToMessageMapping(NodeList nl) throws Exception {
		//Instantial mapping HashMap
		HashMap domToMessageMapping = new HashMap();
		int nbEntry = nl.getLength();

		//Prepare convertion binding
		BindingMetaInfo bInfo = new BindingMetaInfo();
		String[] paths = new String[nbEntry];
		String[] attributes = new String[nbEntry];
		String[] types = new String[nbEntry];
		String[] javatypes = new String[nbEntry];

		//Get bindings
		for (int i = 0; i < nl.getLength(); i++) {
			//Get individual binding
			Element entry = (Element) nl.item(i);

			//Get attribute: path
			paths[i] = entry.getAttribute(ENTRY_PATH);

			//Get attribute: attribute
			attributes[i] = entry.getAttribute(ENTRY_ATTRIBUTE);

			//Get attribute: type
			types[i] = entry.getAttribute(ENTRY_TYPE);

			//Get attribute: javatype
			javatypes[i] = entry.getAttribute(ENTRY_JAVATYPE);
		}

		//Set up BindingMetaInfo
		bInfo.setPaths(paths);
		bInfo.setAttributes(attributes);
		bInfo.setTypes(types);
		bInfo.setJavatypes(javatypes);

		return bInfo;
	}

	// To be implemented
	public boolean setConfigData(Serializable data) {
		logger.debug("[MessagingConfigAccessor.setConfigData] called");
		boolean isSuccess = true;
		return isSuccess;
	}


	/**
	 * Retrieve all messageMetaInfo defined for a specific protocol. In order to retrieve all messages defined
	 * use "ALL" as the parameter value.
	 *
	 * @param aProtocol	Protocol can be either "3DSecure", "MPI_Interface" or "ALL"
	 * @return Collection
	 */
	public Vector getAllMessageInfo(String aProtocol) throws MessagingException {
		// Check for null protocol which is invalid
		if (aProtocol == null) {
			throw new MessagingException("Null parameter supplied for getAllMessageInfo()");
		}

		Vector resultingSet = new Vector();
		Iterator it = ((HashMap) getConfigData()).keySet().iterator();
		while (it.hasNext()) {
			MessageUID uid = (MessageUID) it.next();
			MessageMetaInfo info = (MessageMetaInfo) allConfigData.get(uid);
			if (aProtocol.equalsIgnoreCase(MessageMetaInfo.MESSAGE_PROTOCOL_ALL) ||
				info.getProtocol().equalsIgnoreCase(aProtocol)) {
				resultingSet.add(uid);
			}
		}
		return resultingSet;
	}
}

package com.oncecorp.visa3d.mpi.messaging;

import com.oncecorp.visa3d.mpi.domain.payment.CRReqMessage;
import com.oncecorp.visa3d.mpi.domain.payment.ErrorCodes;
import com.oncecorp.visa3d.mpi.logging.MPILogger;
import com.oncecorp.visa3d.mpi.messaging.meta.ExtensionMetaInfo;
import com.oncecorp.visa3d.mpi.messaging.meta.MessageMetaInfo;
import com.oncecorp.visa3d.mpi.messaging.meta.MessageUID;
import com.oncecorp.visa3d.mpi.utility.XMLUtil;

import java.io.Serializable;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Mapping Class of MPI message Extension element   
 *   
 * @version $Revision: 26 $
 * @author	Jun Shi
 * @author 	Alan Zhang
 */
public class Extension implements Serializable {
	/**
	 * Extension message structure
	 */
	private String extID;
	private String critical;
	private String extValue;
	private Serializable extData;

	/**
	 * Validation error messages
	 */
	private static final String CRITICAL_ERRMSG = "Size is zero(0), or value not equal to 'true' or 'false'";
	private static final String CRITICAL_ERRMSG_LONG = "Invalid field. [Extension.critical] - " + CRITICAL_ERRMSG;;

	/**
	 * Local Log4J logger
	 */
	private transient Logger logger =
		MPILogger.getLogger(CRReqMessage.class.getName());

	public Extension() {
		super();
	}

	/**
	 * Convenient method to create corresponding DOM element of
	 * Extension
	 */
	public Element toXML() throws Exception {
		//Create empty document
		Document doc = XMLUtil.createDocument();

		//Prepare extension element
		Element extensionElement = doc.createElement("Extension");

		//Set attribute value
		extensionElement.setAttribute("id", getExtID());
		extensionElement.setAttribute("critical", getCritical());

		//Set element value
		extensionElement.appendChild(doc.createTextNode(getExtValue()));
		
		//return result
		return extensionElement;
	}
	
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("<Extension id=\"");
		sb.append(XMLUtil.filterSpecialChars(getExtID()));
		sb.append("\" critical=\"");
		sb.append(XMLUtil.filterSpecialChars(getCritical()));
		sb.append("\">");
		sb.append(XMLUtil.filterSpecialChars(getExtValue()));
		sb.append("</Extension>");
		
		return sb.toString();
	}

	/**
	 * Gets the extID
	 * @return Returns a String
	 */
	public String getExtID() {
		return extID;
	}
	/**
	 * Sets the extID
	 * @param extID The extID to set
	 */
	public void setExtID(String extID) throws MessagingException {
		// Validate proper extension id specification
		MessageValidator.validateField("UNKNOWN", extID, "[Extension.id]", 1, -1, true);
		this.extID = extID;
	}

	/**
	 * Gets the critical
	 * @return Returns a String
	 */
	public String getCritical() {
		return critical;
	}
	/**
	 * Sets the critical
	 * @param critical The critical to set
	 */
	public void setCritical(String critical) throws MessagingException {
		//Validate proper specification for critical attribute
		MessageValidator.validateField("UNKNOWN", critical, "[Extension.critical]", 4, 5, true);
		if ((! critical.equalsIgnoreCase("true")) &&
			(! critical.equalsIgnoreCase("false"))) {
				this.logger.error(CRITICAL_ERRMSG_LONG);
				throw new MessagingException(
					"UNKNOWN",
					ErrorCodes.ERROR_CODE_5,
					ErrorCodes.ERROR_MESSAGE_5,
					"[Extension.critical]",
					CRITICAL_ERRMSG,
					CRITICAL_ERRMSG_LONG + "Value: {" + critical + "}");
		}
		
		this.critical = critical;
	}

	/** 
	 * Indicate id extension is critical or not
	 * @return	true=Extension is critical, false=Extension is NOT critical
	 */
	public boolean isCritical() {
		return (getCritical().equalsIgnoreCase("true"));
	}
	
	/**
	 * Gets the extValue
	 * @return Returns a String
	 */
	public String getExtValue() {
		return extValue;
	}
	/**
	 * Sets the extValue
	 * @param extValue The extValue to set
	 */
	public void setExtValue(String extValue) {
		this.extValue = extValue;
	}

	public boolean validate() throws MessagingException {
		logger.debug("Validating current CRReq message...");

		//Check all the mandatory field existence
		MessageValidator.validateField("UNKNOWN", getExtID(), 			"[Extension.extID]", 		1, -1, true);
		MessageValidator.validateField("UNKNOWN", getCritical(), 		"[Extension.critical]", 	1, -1, true);
		
		return true;
	}
	
	
	/**
	 * Check the support of the extension for this particulay message. Support
	 * information is retrieved from the MessageDefinition information file
	 * @param aMsgType		Type of the message
	 * @param aMsgVersion	Version of the message
	 * @param extension		The extension needed to be tested for support
	 * @return boolean		True = Extension supported, False = Extension not supported.
	 */
	public static boolean isSupported(String aMsgType, String aMsgVersion, Extension extension) {
		// Fetch proper meta-information about extension definition for this message
		boolean supported = false;
		MessageUID uid = new MessageUID(aMsgType, aMsgVersion);

		// Retrieve extension metainfo and check for support
		ExtensionMetaInfo meta = MessageMetaInfo.getExtensionInfo(uid);
		if (meta != null) {
			supported = meta.isSupported(extension.getExtID(), extension.getExtValue());
		}			
		
		// If critical and not supported by us then this is NOT supported.
		// Everything else is OK
		if (extension.isCritical()) {
			if (supported) {
				return true;		
			}
			else {
				return false;
			}
		}
		else {
			// Since it is not critical, then it is supported by default
			return true;
		}
	}
}

package com.oncecorp.visa3d.mpi.messaging;

import java.util.Vector;

import org.apache.log4j.Logger;

import com.oncecorp.visa3d.mpi.configuration.ConfigAccessorGenerator;
import com.oncecorp.visa3d.mpi.configuration.ConfigAccessorType;
import com.oncecorp.visa3d.mpi.domain.payment.ErrorMessage;
import com.oncecorp.visa3d.mpi.domain.payment.ErrorCodes;
import com.oncecorp.visa3d.mpi.logging.MPILogger;
import com.oncecorp.visa3d.mpi.messaging.meta.MessageMetaInfo;
import com.oncecorp.visa3d.mpi.messaging.meta.MessageUID;

/**
 * Description: This class is used for generating a specific Message in
 * terms of type, version
 *  
 * @version 0.1 Aug 03, 2002
 * @author	Jun Shi
 */

public class MessageGenerator {

	// Local Log4J logger
	private static Logger logger =
		MPILogger.getLogger(MessageGenerator.class.getName());

	private static String overridenVersion = null;
	private static Vector visa3DSecureMessageUIDs;

	static {
		MessagingConfigAccessor accessor =
			(MessagingConfigAccessor) ConfigAccessorGenerator.getAccessor(
				ConfigAccessorType.ACCESSOR_TYPE_MESSAGING);
		try {
			visa3DSecureMessageUIDs =
				accessor.getAllMessageInfo(
					MessageMetaInfo.MESSAGE_PROTOCOL_3DSECURE);
		} catch (MessagingException e) {
			logger.error(
				"Failed to load 3DSecure messaging UIDs in MessageGenerator.",
				e);
		}
	}

	/** MessageGenerator Constructor */
	private MessageGenerator() {
	}

	/** 
	 * static method - create (type, version) return a specific Message
	 * according to submitted type and version.
	 * 
	 * @param type    - String
	 * @param version - String
	 * @return Message
	 */
	public static Message create(String type, String version)
		throws MessagingException {
		Message msg = null;
		String msgImpl = null;
		try {
            MessageUID uid = new MessageUID(type, version);
            if (!MessageMetaInfo.isVersionSupported(uid)) {
                 throw new MessagingException(
                     "unknown",
                     ErrorCodes.ERROR_CODE_5,
                     ErrorCodes.ERROR_MESSAGE_5,
                     "version",
                     "Version: " + version + " is not supported by this software release.",
                     "[MessageType:"
                         + type
                         + "] Version: "
                         + version
                         + " is not supported by this software release.)");
             }

            // Get implementation for that UID
 			msgImpl = MessageMetaInfo.getImpl(uid);
			if (msgImpl == null) {
				logger.error("Message Impl Not Found!!");
				throw new MessagingException("Message Impl Not Found!!");
			}

			// instantiate msgImpl class
			msg = (Message) Class.forName(msgImpl).newInstance();

			// By default the message is initialized to the latest version of the protocol it
			// is supporting. If it is supporting more than one version, we ensure than the 
			// requested version is set in this message instance....
			if (visa3DSecureMessageUIDs
				.contains(new MessageUID(msg.getType(), msg.getVersion()))) {
				if (getOverridenVersion() != null) {
					msg.setVersion(getOverridenVersion());
				} else {
					msg.setVersion(version);
				}
			} else {
				msg.setVersion(version);
			}

			// do logging
			logger.debug("create [" + msg.getClass() + "] completed !!");
		} catch (ClassCastException e1) {
			// Wrong type stored in the mapping file
			logger.fatal(
				"Wrong type stored in the mapping file. Unable to load message definition");
			throw new MessagingException("Wrong type stored in the mapping file. Unable to load message definition");
		} catch (Exception e) {
			logger.error(
				"Fatal Error: Message Impl Not Found or cannot instantiate",
				e);
			throw new MessagingException(
				"MessageGenerator:"
					+ " Message Impl Not Found or Cannot Instantiate");
		}

		// return created empty msg to caller
		return msg;
	}

	public static void checkVersionSupport(Message msg) {
		try {
			if ((msg != null) && (msg instanceof ErrorMessage)) {
				if (((ErrorMessage) msg).getErrorCode().equals("6")) {
					setOverridenVersion(((ErrorMessage) msg).getErrorDetail());
					logger.info(
						"Current support version is forced to: "
							+ getOverridenVersion());
				}
			}
		} catch (Exception e) {
			logger.debug("Error in checking Version Support.", e);
		}
	}

	/**
	 * Returns the currentVersion.
	 * @return String
	 */
	public static String getOverridenVersion() {
		return overridenVersion;
	}

	/**
	 * Sets the currentVersion.
	 * @param currentVersion The currentVersion to set
	 */
	public static void setOverridenVersion(String currentVersion) {
		MessageGenerator.overridenVersion = currentVersion;
	}

}

package com.oncecorp.visa3d.mpi.messaging;

import com.oncecorp.visa3d.mpi.domain.payment.ErrorCodes;
import com.oncecorp.visa3d.mpi.logging.MPILogger;

import org.apache.log4j.Logger;

/**
 * This class provides a generic message validator that allows both
 * field validation and constraint validation.
 * In it's first release, this class is pretty straighforward but should
 * be extended to include regular expression validation and more expressive
 * constraint validation procedure.
 * 
 * Note: I was tired of Copy&Pasting the same validation code all over the place...
 * 		 Centralization is better....
 * 
 * @author Martin Dufort (mdufort@oncecorp.com)
 * 
 */
public class MessageValidator {

	private static final String EMPTY_ERROR_MESSAGE =
		"The content of this field should be specified.";
	private static final String SIZE1_ERROR_MESSAGE = "Field size must be ";
	private static final String DIGIT_ERROR_MESSAGE =
		"Field value should be digits. But: ";

	/**
	 * Local Log4J logger
	 */
	private static Logger logger =
		MPILogger.getLogger(MessageValidator.class.getName());

	/**
	 * This method performs field validation by ensuring that the supplied
	 * field value is within the length range and it is specified.
	 * @param msgID		Message ID to use for exception creation.
	 * @param value		Value of field to validate
	 * @param fieldName	Name of field being validated
	 * @param minSize	Minimum length size for the field (-1 = no minimum)
	 * @param maxSize	Maximum length size for the field (-1 = no maximum)
	 * @param needed	Field is optional or mandatory
	 */
	static public void validateField(
		String msgID,
		Object value,
		String fieldName,
		int minSize,
		int maxSize,
		boolean needed)
		throws MessagingException {

		// Check for needed field which could be missing
		if ((needed) && (value == null)) {
			generateMissingElementError(msgID, fieldName, value);
		}

		// Check according to object type
		if (value instanceof String) {
			String strValue = (String) value;

			// If the field is mandatory, or if the field is not mandatory but has 
			// a value.
			if ((needed)
				|| (!needed)
				&& ((strValue != null) && (strValue.length() > 0))) {
				// No check for length
				if ((minSize == -1) && (maxSize == -1))
					return;

				// Just check the max length size
				if (minSize == -1) {
					if (strValue.length() > maxSize) {
						generateSizeError(
							msgID,
							fieldName,
							strValue,
							minSize,
							maxSize);
					}
				} else if (maxSize == -1) {
					if (strValue.length() < minSize) {
						generateSizeError(
							msgID,
							fieldName,
							strValue,
							minSize,
							maxSize);
					}
				} else {
					if ((strValue.length() > maxSize)
						|| (strValue.length() < minSize)) {
						generateSizeError(
							msgID,
							fieldName,
							strValue,
							minSize,
							maxSize);
					}
				}
			}
		}
	}

	private static void generateMissingElementError(
		String msgId,
		String fieldName,
		Object value)
		throws MessagingException {
		String emptyMessageLong =
			"Field is missing " + fieldName + ". - " + EMPTY_ERROR_MESSAGE;

		logger.debug(emptyMessageLong);
		throw new MessagingException(
			msgId,
			ErrorCodes.ERROR_CODE_3,
			ErrorCodes.ERROR_MESSAGE_3,
			fieldName,
			EMPTY_ERROR_MESSAGE,
			emptyMessageLong);
	}

	private static void generateSizeError(
		String msgId,
		String fieldName,
		Object value,
		int minSize,
		int maxSize)
		throws MessagingException {

		String errMessage = null;
		if (minSize == -1) {
			errMessage = SIZE1_ERROR_MESSAGE + "<= " + maxSize;
		} else if (maxSize == -1) {
			errMessage = SIZE1_ERROR_MESSAGE + ">= " + minSize;
		} else {
			errMessage =
				SIZE1_ERROR_MESSAGE + ">= " + minSize + " and <= " + maxSize;
		}

		String errMessageLong =
			"Invalid field: " + fieldName + " - " + errMessage;

		// Throw proper exception
		throw new MessagingException(
			msgId,
			ErrorCodes.ERROR_CODE_5,
			ErrorCodes.ERROR_MESSAGE_5,
			fieldName,
			errMessage,
			errMessageLong + " Value: {" + value + "}");
	}

	/**
	 * This method performs field validation by ensuring that the supplied
	 * field value is within the length range and it is specified and all in digits.
	 * @param msgID		Message ID to use for exception creation.
	 * @param value		Value of field to validate
	 * @param fieldName	Name of field being validated
	 * @param minSize	Minimum length size for the field (-1 = no minimum)
	 * @param maxSize	Maximum length size for the field (-1 = no maximum)
	 * @param needed	Field is optional or mandatory
	 */
	public static void validateDigitField(
		String msgID,
		Object value,
		String fieldName,
		int minSize,
		int maxSize,
		boolean needed)
		throws MessagingException {
		//Validate field length first
		validateField(msgID, value, fieldName, minSize, maxSize, needed);

		//Validate digits
		if ((needed) || (value != null)) {
			
			try {
				Long.parseLong((String) value);
			} catch (NumberFormatException nfe) {
					logger.debug(DIGIT_ERROR_MESSAGE + value);
					throw new MessagingException(
						msgID,
						ErrorCodes.ERROR_CODE_5,
						ErrorCodes.ERROR_MESSAGE_5,
						fieldName,
						DIGIT_ERROR_MESSAGE,
						DIGIT_ERROR_MESSAGE + value);
			}
		}
	}

	public static boolean isValidMerchantID(String id) {
		boolean valid = false;
		int hyphenIndex = id.indexOf("-");
		if (hyphenIndex < 0) {
			// no hyphen found
			if (id.length() <= 15)
				valid = true;
		} else {
			// hyphen found
			String firstPart = null;
			String secondPart = null;
			while (hyphenIndex >= 0) {
				firstPart = id.substring(0, hyphenIndex);
				if (hyphenIndex != (id.length() - 1)) {
					secondPart = id.substring(hyphenIndex + 1);
				} else {
					secondPart = "";
				}

				if ((firstPart.length() <= 15) && (secondPart.length() <= 8))
					valid = true;

				if (hyphenIndex != (id.length() - 1))
					hyphenIndex = id.indexOf("-", hyphenIndex + 1);
				else
					hyphenIndex = -1;
			}
		}

		return valid;
	}

	static public void validateConstraint() throws MessagingException {
	}
}

package com.oncecorp.visa3d.mpi.messaging;

import com.oncecorp.visa3d.mpi.controller.AuthenticatorSession;
import com.oncecorp.visa3d.mpi.domain.payment.CRReqMessage;
import com.oncecorp.visa3d.mpi.domain.payment.CRResMessage;
import com.oncecorp.visa3d.mpi.domain.payment.ErrorCodes;
import com.oncecorp.visa3d.mpi.logging.MPILogger;
import com.oncecorp.visa3d.mpi.messaging.meta.MessageMetaInfo;
import com.oncecorp.visa3d.mpi.messaging.meta.MessageUID;
import com.oncecorp.visa3d.mpi.publishing.PublishException;
import com.oncecorp.visa3d.mpi.publishing.PublishingManager;

import org.apache.log4j.Logger;

/**
 * MessageEngine is a key member of Messaging Component.
 * As a fa?ade object, it receive the generic message from other MPI
 * component and return a processed message back.
 * 
 * There is 1 public methods can be used by other MPI component:
 * 
 * - public static Message process (Message msg)
 * 
 * On the other hand, MessageEngine is responsible for catching all messaging
 * component exceptions during processing and return an MPIErrorMessage
 * returning to caller (e.g. Authenticator)    
 * 
 * @version $Revision: 36 $
 * @author Jun Shi
 * @author Martin Dufort (mdufort@oncecorp.com)
 */

public class MessageEngine {

	// define internal messaging exception code
	public static final String MESSAGING_EXCEPTION_CODE = "888";
	public static final String UNEXPECTED_EXCEPTION_CODE = "889";

	/**
	 * Generic error message for MPIError message
	 */
	public static final String GENERIC_ERROR_MESSAGE =
		"Unexpected error occurred in Messaging Component.";

	// Local Log4J logger
	private static Logger logger =
		MPILogger.getLogger(MessageEngine.class.getName());

	/** 
	 * Loading all messaging mapping info from MessagingConfigAccessor
	 * and assign to each individual repository defined above
	 */
	private MessageEngine() {
	}

	/**
	 * Process a specific message accoding to it's functional behavior. The process message
	 * takes a message object and applies functional behavior to it be located it's corresponding
	 * processor and invoking it appropriately.
	 * @param msg - Message 
	 * @return msg - Message (processed finalMsg) 
	 */
	public static Message process(Message msg) throws MessagingException {
		MessageProcessor processor = null;

		// Check if message is valid. If not then a MessagingException will be thrown.
		if (msg.validate()) {
			logger.debug("Message is valid: " + msg.getClass().getName());
		}

		// get desired processor object referrence
		MessageUID uid = new MessageUID(msg.getType(), msg.getVersion());

		// instantiate a specific processor class
		processor = (MessageProcessor) MessageMetaInfo.getProcessor(uid);

		// processing this message 
		Message newMsg = processor.process(msg);

		if (!(msg instanceof CRReqMessage) && !(msg instanceof CRResMessage)) {
			// count & publish this message
			PerformanceMonitor.getInstance().count(msg, AuthenticatorSession.instance().getMerchantID());
			
			try {
				PublishingManager.getInstance().publish(msg);
			} catch (PublishException e) {
				logger.error("Current transaction abandoned as publishing error occurred.", e);
				throw new MessagingException(
					msg.getId(),
					ErrorCodes.ERROR_CODE_99,
					ErrorCodes.ERROR_MESSAGE_99,
					"JMS Publishing",
					"Current transaction abandoned as publishing error occurred.",
					"Current transaction abandoned as publishing error occurred.");
			}
		}

		// keep processing
		if (processor instanceof ComplexMessageProcessor) {
			// This guy is a complex processor so we must do additional processing
			ComplexMessageProcessor cProcessor =
				(ComplexMessageProcessor) processor;
			newMsg = cProcessor.processComplex(newMsg);
		}

		// do logging
		logger.debug("process(" + msg.getClass().getName() + ") completed !!");

		// return to caller
		return newMsg;
	}
}

