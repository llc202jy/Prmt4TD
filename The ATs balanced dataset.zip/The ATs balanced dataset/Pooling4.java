     * <b>FIXME</b>:  Aren't there constants defined for
     * these levels in log4j?  Use those instead
     * of strings.
     *
     * @param level One of {debug, error, fatal, info, warn}
     * @param text String to be logged.
     */
    public void log(String level, String text) {
        if ((level == null) ||
            (text == null)) {
            log.warn("log message incomplete");
            return;
        }
        if (level.equals("debug"))
            log.debug(text);
        else if (level.equals("error"))
            log.error(text);
        else if (level.equals("fatal"))
            log.fatal(text);
        else if (level.equals("info"))
            log.info(text);
        else if (level.equals("warn"))
            log.warn(text);
    }

    
    /** Get the value of a configuration property
     *
     * @param property the property name to look up
     * @return the property value
     */
    public String getPropertyValue(String property) {
        
        return props.getString(property);
        
    } // getPropertyValue()


    /** Get the base url of the installed application
     *
     * @return The base url.
     */
    public String getURLBase() {
        return urlBase;
    }
    
    /** Set the base url of the installed application
     *
     * @param urlBase The user-visible base url
     */
    public void setURLBase( String urlBase ) {
        this.urlBase = urlBase;
    }


    /** Get the webapp path of the installed application    
     *
     * @return The webapp path sans leading and trailing slashes
     */
    public String getWebappPath() {
        return webappPath;
    }
    
    /** Set the webapp path of the installed application (which
     * might be different from the ContextPath if mapped differently)
     *
     * @param webappPath The user-visible webapp-path
     */
    public void setWebappPath( String webappPath ) {
        this.webappPath = webappPath;
    }

    /** Convenience function for constructing a full context URL
     *
     * @return The full absolute path of the application
     */
    public String getURLPath() {
        return getURLBase() + "/" + getWebappPath();
    }
        
    
    /** Get the short name of the database engine.
     *
     * @return The short name of the database engine.
     * @see #setDBEngine
     */
    public String getDBEngine() {
        return dbengine;
    }
    
    /** Specifies the name of the database type, currently
     * one of "mysql", "pgsql".
     *
     * @param dbengine One of "mysql", "pgsql".
     */
    public void setDBEngine(String dbe) {
        if ((dbe != null) &&
            (!dbe.equals(""))) {
            dbengine = dbe;
        }
        if (dbengine.equals("mysql"))
            sqlFactory = new MySQLFactory();
        else if (dbengine.equals("pgsql"))
            sqlFactory = new PostgreSQLFactory();
        log.debug("new " + getDBEngine() + " factory created.");
    }

    /** Get the jdbc/poolman url for the db used.
     *
     * @return The JDBC URL.
     */
    public String getJdbcURL() {
        return jdbcURL;
    }

    /** Set the jdbc/poolman url for the db used.
     *
     * @param url The JDBC URL.
     */
    public void setJdbcURL(String url) {
        if (url == null) {
            log.warn("url is null");
            return;
        }
        if (url.equals("")) {
            log.warn("url is blank");
            return;
        }
        jdbcURL = url;
    }

    /** 
     * Initialize the jdbc connection pool.
     *
     * @param props The jake.properties configuration bundle
     */
    private static void initializeConnectionPool(ResourceBundle props) {

        GenericObjectPool connectionPool = new GenericObjectPool(null);        

        ConnectionFactory connectionFactory = new DriverManagerConnectionFactory(
            props.getString("jdbc.url"), 
            props.getString("jdbc.username"),
            props.getString("jdbc.password"));

        try {
            
            // load the jdbc driver for mysql
            Class.forName(props.getString("jdbc.driver.class")).newInstance();

            PoolableConnectionFactory poolableConnectionFactory = 
                new PoolableConnectionFactory(connectionFactory,
                    connectionPool,
                    null,
                    null,
                    false,
                    true);
                    
            log.debug("maxActive: " + connectionPool.getMaxActive());
            log.debug("maxIdle: " + connectionPool.getMaxIdle());
            log.debug("maxWait: " + connectionPool.getMaxWait());
            
        } catch (Exception e) {
            
            log.warn(e);
            
        }

        PoolingDriver driver = new PoolingDriver();

        driver.registerPool("jakepool", connectionPool);

    } // initializeConnectionPool()


    /** 
     * Get a sql Connection from the pool.
     *
     * @return A valid Connection, or null.
     */
    public Connection getConnection() {

        Connection con = null;

        try {

            con = DriverManager.getConnection("jdbc:apache:commons:dbcp:jakepool");

        } catch (SQLException sqle) {
            
            log.warn(sqle);

        }

        return con;

    }


    /**
     * Return a connection to the pool
     * 
     * @param the open connection to close
     */
    public void closeConnection(Connection con) {
        
        try {
            con.close();
        } catch (SQLException sqle) {
            log.warn(sqle);
        }
        
    } // closeConnection()


    /** Allow direct access to the sqlFactory.
     *
     * @return the current sqlFactory
     */
    public SQLFactory getSQLFactory() { return sqlFactory; }


    /** Constructs a jake Search object from an incoming query
     * as represented by an openurl or a bibtex article entry.  See 
     * <a href="http://www.sfxit.com/openurl/openurl.html">the 
     * openurl standard</a> for more info.  Assume we should use
     * the cached results by default.
     *
     * @param q a single query reflecting search terms.
     * @return A jake Search object.
     * @see Query
     */
    public Search doSearch(Query q) {

        return doSearch(q, Search.USE_CACHE);

    }
    
    /** Constructs a jake Search object from an incoming query
     * as represented by an openurl or a bibtex article entry.  See 
     * <a href="http://www.sfxit.com/openurl/openurl.html">the 
     * openurl standard</a> for more info.
     *
     * @param q a single query reflecting search terms.
     * @param useCache whether to bypass the cached result
     * @return A jake Search object.
     * @see Query
     */
    public Search doSearch(Query q, boolean useCache) {
        if (q == null) {
            log.debug("query is null");
            return null;
        }
        
        if (sqlFactory == null) {
            log.warn("sqlFactory is null");
            return null;
        }
        
        Request req = new Request(q);

        if (req == null) {
            log.debug("request is null");
            return null;
        }
        
        Search s = new Search(req);

        try {

            Connection con = getConnection();

            if (con == null) {
                log.warn("connection is null");
                return null;
            }
            
            if (useCache) {
                
                log.debug("useCache should be true");
                s.execute(sqlFactory, con);
            
            } else {
            
                log.debug("useCache should be false");
                s.execute(sqlFactory, con, Search.IGNORE_CACHE);
            
            }

            con.close();

        } catch (SQLException sqle) {
            log.warn(sqle);
            return null;
        }
        return s;
    }
    
    
    
    /**
     * Return a current transformer, setting "webapp-path" and "url-base"
     * as default parameters
     * 
     * @param type the transformer type {'search','queue'}
     * @return the appropriate transformer
     */
    public Transformer getTransformer(String type) {

        TransformerFactory tFactory = TransformerFactory.newInstance();

        Transformer t;
        
        try {

            if ("search".equals(type)) {
             
                t = tFactory.newTransformer(
                    new StreamSource(props.getString("searchXslBase")));
            
            } else if ("queue".equals(type)) {
                
                t = tFactory.newTransformer(
                    new StreamSource(props.getString("queueXslBase")));
                    
            } else {

                log.warn("unknown type: " + type);
                return null;
        
            }

            t.setParameter("url-base", getURLBase());
            t.setParameter("webapp-path",  getWebappPath());
    
            return t;
        
        } catch (Exception e) {
            
            log.warn(e);
            return null;
        
        }

    } // getSearchTransformer()
 
    
}