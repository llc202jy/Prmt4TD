package org.openware.job.gui;

import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.Action;
import javax.swing.UIManager;
import javax.swing.JTabbedPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.ImageIcon;
import javax.swing.JToolBar;
import javax.swing.AbstractAction;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.Dimension;
import java.awt.Color;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

/**
 * An <code>ApplicationContainer</code> provides a framework for deploying one or 
 * more applications.  The container is a <code>JTabbedPane</code> and each 
 * application a tab in the pane.
 */
public class ApplicationContainer extends JFrame implements ChangeListener
{
    private HashMap applications = new HashMap();
    private LinkedList applicationList = new LinkedList();
    private JTabbedPane tabbedPane = null;
    private JMenuBar defaultMenuBar = null;
    private JToolBar defaultToolBar = null;
    private Action exitAction = null;
    private boolean exitFromShutdown = false;
    private JToolBar currentToolBar = null;
    private JPanel currentStatusBar = null;

    private ApplicationContainer() {
        JMenu fileMenu = null;
        JMenuItem fileExit = null;

        initializeActions();
        defaultMenuBar = new JMenuBar();
        fileMenu = new JMenu("File");
        fileMenu.setMnemonic(KeyEvent.VK_F);
        defaultMenuBar.add(fileMenu);

        fileExit = new JMenuItem(exitAction);
        fileExit.setIcon(null);
        fileExit.setMnemonic(KeyEvent.VK_X);
        fileMenu.add(fileExit);

        defaultToolBar = new JToolBar();

        setNativeLookAndFeel();
        tabbedPane = new JTabbedPane();
        tabbedPane.addChangeListener(this);
        setJMenuBar(defaultMenuBar);
        getContentPane().setLayout(new BorderLayout());
        currentToolBar = defaultToolBar;
        getContentPane().add(defaultToolBar, BorderLayout.NORTH);
        getContentPane().add(tabbedPane, BorderLayout.CENTER);
        currentStatusBar = new JPanel();
        getContentPane().add(currentStatusBar, BorderLayout.SOUTH);

        pack();

        //width,height
        setSize(800, 600);

        //Center window on screen
        Dimension dim = getToolkit().getScreenSize();
        this.setLocation(dim.width/2 - this.getWidth()/2, dim.height/2 - this.getHeight()/2);
    }

    public void exit() {
        exitFromShutdown = false;
        exitAction.actionPerformed(null);
    }

    private void exitFromShutdown() {
        exitFromShutdown = true;
        exitAction.actionPerformed(null);
    }

    private void initializeActions() {
        exitAction = new AbstractAction("Exit") {
                public void actionPerformed (ActionEvent event) {
                    try {
                        Iterator iter = null;

                        iter = applicationList.iterator();
                        while (iter.hasNext()) {
                            IApplication app = null;

                            app = (IApplication) iter.next();
                            System.out.println("Shutting down " + app.getName());
                            app.shutdown();
                        }
                        applicationList.clear();
                        applications.clear();
                        if (!exitFromShutdown) {
                            System.out.println("Exiting");
                            System.exit(0);
                        }
                    } catch (Exception ignored) {
                    }
                }
            };
    }

    void addApplication(IApplication app) {
        applications.put(app.getName(), app);
        applicationList.add(app);
        tabbedPane.add(app.getName(), app.getMainPanel());
        if (applicationList.size() == 1) {
            tabbedPane.setSelectedIndex(0);
        }
    }

    public Action getExitAction() {
        return exitAction;
    }

    private int getApplicationIndex(IApplication app) {
        int index = 0;
        boolean found = false;
        Iterator iter = null;

        iter = applicationList.iterator();
        while (iter.hasNext() && !found) {
            IApplication curapp = null;

            curapp = (IApplication) iter.next();
            if (curapp.getName().equals(app.getName())) {
                found = true;
            } else {
                index++;
            }
        }
        
        if (!found) {
            index = -1;
        }
        
        return index;
    }

    /**
     * Set the icon for the tab of the given application.
     */
    public void setTabIcon(IApplication app, ImageIcon icon) {
    }


    /**
     * Set the background color for the tab of the given application.
     */
    public void setTabBackground(IApplication app, Color color) {
        int index = 0;

        index = getApplicationIndex(app);
        if (index >= 0 &&
            index != tabbedPane.getSelectedIndex()) {
            tabbedPane.setBackgroundAt(index, color);
        }
    }

    /**
     * Detects when the user tabs between 2 different applications and 
     * takes appropriate actions, which include switching the toolbar
     * and menubar.
     */
    public void stateChanged(ChangeEvent e) {
        IApplication app = null;

        int index = 0;
        JToolBar toolBar = null;
        JPanel statusBar = null;

        index = tabbedPane.getSelectedIndex();
        tabbedPane.setBackgroundAt(index, null);

        app = (IApplication) applicationList.get(index);
        if (app.getMenuBar() != null) {
            setJMenuBar(app.getMenuBar());
        } else {
            setJMenuBar(defaultMenuBar);
        }

        statusBar = app.getStatusBarPanel();
        getContentPane().remove(currentStatusBar);
        if (statusBar == null) {
            statusBar = new JPanel();
        }
        currentStatusBar = statusBar;
        getContentPane().add(statusBar, BorderLayout.SOUTH);
        statusBar.repaint();

        toolBar = app.getToolBar();
        getContentPane().remove(currentToolBar);
        if (toolBar == null) {
            toolBar = defaultToolBar;
        }
        currentToolBar = toolBar;
        getContentPane().add(toolBar, BorderLayout.NORTH);
    }

    public static void setNativeLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch(Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void setJavaLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch(Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public static void setMotifLookAndFeel() {
        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
        } catch(Exception ex) {
            ex.printStackTrace();
        }
    }

    private static void usage() {
        System.err.println("usage:  ApplicationContainer --props propfile");
        System.exit(1);
    }

    public static void main(String [] args) throws Exception {
        ApplicationContainer container = null;
        boolean error = false;
        Properties props = null;
        String appName = null;
        int appIndex = 0;
        String title = null;

        if (args.length == 2) {
            if (args[0].equals("--props")) {
                
                props = new Properties();
                props.load(new FileInputStream(args[1]));
            } else {
                usage();
            }
        } else if (args.length > 0) {
            usage();
        } else {
            props = System.getProperties();
        }
        container = new ApplicationContainer();

        title = props.getProperty("mainTitle", "Application");
        container.setTitle(title);
        appName = props.getProperty("applicationName." + appIndex);
        while (appName != null) {
            int argIndex = 0;
            String className = null;
            IApplication app = null;
            ArrayList appArgs = null;
            String arg = null;
            
            className = props.getProperty(appName + ".classname");
            if (className == null) {
                System.err.println(appName + ".classname property not found");
                error = true;
            }
            
            argIndex = 0;
            appArgs = new ArrayList();
            arg = props.getProperty(appName + ".arg." + argIndex);
            while (arg != null) {
                appArgs.add(arg);
                argIndex++;
                arg = props.getProperty(appName + ".arg." + argIndex);
            }
            
            try {
                String [] argsArr = null;
                
                System.out.println("appArgs = " + appArgs);
                argsArr = new String[appArgs.size()];
                argsArr = (String []) appArgs.toArray(argsArr);
                app = (IApplication) Class.forName(className).newInstance();
                app.init(container, argsArr);
            } catch (ClassNotFoundException e) {
                System.err.println(className + " not found in classpath.");
                error = true;
            } catch (ClassCastException e) {
                System.err.println(className + " must be of type IApplication.");
                error = true;
            } catch (IllegalAccessException e) {
                System.err.println(className + " constuctor not accessible.");
                error = true;
            } catch (InstantiationException e) {
                System.err.println(className + " cannot instantiate application.");
                    error = true;
            } catch (ExceptionInInitializerError e) {
                System.err.println(className + " cannot instantiate application.");
                e.getCause().printStackTrace();
                error = true;
            }
            
            container.addApplication(app);
            appIndex++;
            appName = props.getProperty("applicationName." + appIndex);
        }

        container.setVisible(true);
        container.stateChanged(null);
        if (error) {
            System.err.println("Errors found, exiting.");
            System.exit(1);
        }
        
        Runtime.getRuntime().addShutdownHook(new ShutdownThread(container));
    }

    public static class ShutdownThread extends Thread {
        ApplicationContainer container = null;

        public ShutdownThread(ApplicationContainer container) {
            super("Shutdown Thread");
            this.container = container;
        }

        public void run() {
            try {
                if ( container != null ) {
                    container.exitFromShutdown();
                }
            } catch (Exception ignored) {
            }
        }
    }

}
package org.openware.job.gui;

import org.openware.job.data.Persist;
import org.openware.job.data.View;
import org.openware.job.data.PersistComparator;
import org.openware.job.data.PersistException;

import java.util.Collections;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Iterator;
import java.util.HashMap;

public class PersistCollectionTable
{
    private Collection persists = null;
    private LinkedList columnLabels = new LinkedList();
    private LinkedList columnNames = new LinkedList();
    private boolean iteratorStale = true;
    private LinkedList rows = null;
    private String indexColumn = null;
    private HashMap indexedRows = new HashMap();
    private String [] indexedValues = null;

    public PersistCollectionTable() {
        persists = new LinkedList();
        indexedValues = new String[persists.size()];
    }

    public PersistCollectionTable(Collection persists) {
        this.persists = persists;
        indexedValues = new String[persists.size()];
    }

    public synchronized void setPersists(Collection persists) {
        this.persists = persists;
        indexedValues = new String[persists.size()];
        iteratorStale = true;
    }

    /**
     * Set the name of the column that is used for indexing the row.  This
     * is needed so that the highlighted rows will remain highlighted after
     * table is sorted.
     */
    public void setIndexColumn(String indexColumn) {
        this.indexColumn = indexColumn;
    }

    public synchronized void addColumnLabel(String colLabel) {
        iteratorStale = true;
        columnLabels.add(colLabel);
    }

    public synchronized int getNumRows() {
        return persists.size();
    }

    public synchronized int getNumCols() {
        return columnNames.size();
    }

    public String getIndexedValueForRow(int row) {
        return indexedValues[row];
    }

    public int getRowForIndexedValue(String value) {
        Integer row = null;
        int retrow = -1;

        row = (Integer) indexedRows.get(value);
        if (row != null) {
            retrow = row.intValue();
        }

        return retrow;
    }

    public synchronized void addColumnHeader(String colname, String colLabel) {
        iteratorStale = true;
        columnNames.add(colname);
        columnLabels.add(colLabel);
    }

    public synchronized void addColumnName(String colname) {
        iteratorStale = true;
        columnNames.add(colname);
    }

    public synchronized void sort(int colnum, boolean ignoreCase, boolean ascending) {
        String colname = null;

        iteratorStale = true;
        colname = (String) columnNames.get(colnum);
        Collections.sort((List) persists, 
                         new PersistComparator(colname, ignoreCase, ascending));
    }

    /**
     * Get an <code>LinkedList</code> of rows for the table.  Each
     * row can, in turn, provide a <code>LinkedList</code> of columns 
     * making up the row.
     */
    public synchronized LinkedList getRows() throws PersistException {
        int rownum = 0;

        if (rows == null || iteratorStale) {        
            Iterator iter = null;
            
            rows = new LinkedList();
            
            iter = persists.iterator();
            while (iter.hasNext()) {
                LinkedList cols = null;
                Iterator colnames = null;
                Object obj = null;

                cols = new LinkedList();
                rows.add(cols);
                obj = iter.next();
                try {
                    Persist persist = null;

                    persist = (Persist) obj;
                    if (indexColumn != null) {
                        String value = null;

                        value = persist.getAsString(indexColumn);
                        indexedValues[rownum] = value;
                        indexedRows.put(value, new Integer(rownum));
                    }

                    colnames = columnNames.iterator();
                    while (colnames.hasNext()) {
                        String colname = null;
                        
                        colname = (String) colnames.next();
                        cols.add(persist.getAsString(colname));
                    }
                } catch (ClassCastException e) {
                    View view = null;

                    view = (View) obj;
                    colnames = columnNames.iterator();
                    if (indexColumn != null) {
                        String value = null;

                        value = view.getAsString(indexColumn);
                        indexedValues[rownum] = value;
                        indexedRows.put(value, new Integer(rownum));
                    }
                    while (colnames.hasNext()) {
                        String colname = null;
                        
                        colname = (String) colnames.next();
                        cols.add(view.getAsString(colname));
                    }
                }
                rownum++;
            }
            
            iteratorStale = false;
        }

        return rows;
    }

    public LinkedList getColumnLabels() {
        return columnLabels;
    }
}
