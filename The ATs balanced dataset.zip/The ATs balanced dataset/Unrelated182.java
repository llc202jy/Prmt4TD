   static final List valid_activity_states(String currentState) {
      return (List) validActivityStates.get(currentState);
   }

   static List valid_activity_states_to_get_in(String state) {
      List valid_states = new ArrayList();

      for (int i = 0; i < SharkConstants.possibleActivityStates.size(); i++) {
         List temp = valid_activity_states((String) SharkConstants.possibleActivityStates.get(i));
         if (temp.contains(state))
            valid_states.add(SharkConstants.possibleActivityStates.get(i));
      }

      return valid_states;
   }

   private static Map validProcessStates = new HashMap();
   static {
      List vsList = new ArrayList();
      validProcessStates.put(SharkConstants.STATE_CLOSED_ABORTED, vsList);
      validProcessStates.put(SharkConstants.STATE_CLOSED_COMPLETED, vsList);
      validProcessStates.put(SharkConstants.STATE_CLOSED_TERMINATED, vsList);

      vsList = new ArrayList(SharkConstants.possibleProcessStates);
      vsList.remove(SharkConstants.STATE_OPEN_RUNNING);
      vsList.remove(SharkConstants.STATE_OPEN_NOT_RUNNING_NOT_STARTED);
      validProcessStates.put(SharkConstants.STATE_OPEN_RUNNING, vsList);

      vsList = new ArrayList(SharkConstants.possibleProcessStates);
      vsList.remove(SharkConstants.STATE_OPEN_NOT_RUNNING_NOT_STARTED);
      vsList.remove(SharkConstants.STATE_OPEN_NOT_RUNNING_SUSPENDED);
      vsList.remove(SharkConstants.STATE_CLOSED_COMPLETED);
      validProcessStates.put(SharkConstants.STATE_OPEN_NOT_RUNNING_NOT_STARTED, vsList);

      vsList = new ArrayList(SharkConstants.possibleProcessStates);
      vsList.remove(SharkConstants.STATE_OPEN_NOT_RUNNING_SUSPENDED);
      vsList.remove(SharkConstants.STATE_OPEN_NOT_RUNNING_NOT_STARTED);
      vsList.remove(SharkConstants.STATE_CLOSED_COMPLETED);
      validProcessStates.put(SharkConstants.STATE_OPEN_NOT_RUNNING_SUSPENDED, vsList);
   }

   static final List valid_process_states(String currentState) {
      return (List) validProcessStates.get(currentState);
   }

   static List valid_process_states_to_get_in(String state) {
      List valid_states = new ArrayList();

      for (int i = 0; i < SharkConstants.possibleProcessStates.size(); i++) {
         List temp = valid_process_states((String) SharkConstants.possibleProcessStates.get(i));
         if (temp.contains(state))
            valid_states.add(SharkConstants.possibleProcessStates.get(i));
      }

      return valid_states;
   }

   // counts connections to engine
   private static int nextConnectionKey = 1;

   static synchronized String getNextConnectionKey() {
      String ck = Integer.toString(nextConnectionKey);
      nextConnectionKey++;
      return ck;
   }

   // a cache of loaded objects
   private static Map loggedUsers = new TreeMap();

   private static int currentUsrId=0;

   private static Map currentPkgVersions = new HashMap();

   static String connect(String userId, boolean storingConnectionInfo) {
      if (storingConnectionInfo) {
         String connectionKey = null;
         synchronized (loggedUsers) {
            while (true) {
               connectionKey = Integer.toHexString(new Random().nextInt(Integer.MAX_VALUE));
               if (!loggedUsers.containsKey(connectionKey)) {
                  loggedUsers.put(connectionKey, userId);
                  return connectionKey;
               }
            }
         }
      } 
      return Integer.toHexString(++currentUsrId);
   }

   static boolean checkSession(WMSessionHandle shandle) {
      return true;
   }

   static boolean disconnect(String connectionKey, boolean storingConnectionInfo) {
      if (storingConnectionInfo) {
         synchronized (loggedUsers) {
            return null != loggedUsers.remove(connectionKey);
         }
      }
      return true;
   }

   static Map getLoggedUsers() throws Exception {
      return Collections.unmodifiableMap(loggedUsers);
   }

   static List createProcessMgrsProcessWrappers(WMSessionHandle shandle, String mgrName)
      throws Exception {

      List l = SharkEngineManager.getInstance()
         .getInstancePersistenceManager()
         .getAllProcessesForMgr(shandle, mgrName);
      List ret = new ArrayList();
      for (int i = 0; i < l.size(); i++) {
         ProcessPersistenceObject po = (ProcessPersistenceObject) l.get(i);
         ret.add(SharkEngineManager.getInstance()
            .getObjectFactory()
            .createProcessWrapper(shandle, mgrName, po.getId()));
      }

      return ret;
   }

   static List createActivityPerformerWrapper(WMSessionHandle shandle,
                                              String procId,
                                              String actId) throws Exception {
      WfActivityInternal act = SharkUtilities.getActivity(shandle,
                                                          procId,
                                                          actId,
                                                          SharkUtilities.READ_ONLY_MODE);
      String performerId = act.getPerformerId(shandle);
      List ret = new ArrayList();
      if (performerId != null) {
         // TODO: process manager information is not valid
         ret.add(SharkEngineManager.getInstance()
            .getObjectFactory()
            .createProcessWrapper(shandle, null, performerId));
      }

      return ret;
   }

   static List createResourceRequesterPerformersWrapper(WMSessionHandle shandle,
                                                        String username) throws Exception {

      PersistentManagerInterface ipi = SharkEngineManager.getInstance()
         .getInstancePersistenceManager();
      List l = ipi.getResourceRequestersProcessIds(shandle, username);
      List ret = new ArrayList();
      for (int i = 0; i < l.size(); i++) {
         String pId = (String) l.get(i);
         ProcessPersistenceObject po = ipi.restoreProcess(shandle, pId);
         // TODO: decide if we have to check here about external
         // requesters
         // (or maybe already in instance persistence layer). This is
         // all due
         // to a change of persisting external requesters
         ret.add(SharkEngineManager.getInstance()
            .getObjectFactory()
            .createProcessWrapper(shandle, po.getProcessMgrName(), po.getId()));
      }
      return ret;
   }

   static List createProcessActivityWrappers(WMSessionHandle shandle, String procId)
      throws Exception {

      WfProcessInternal proc = SharkUtilities.getProcess(shandle,
                                                         procId,
                                                         SharkUtilities.READ_ONLY_MODE);
      List l = proc.getAllActivities(shandle);
      List ret = new ArrayList();
      for (int i = 0; i < l.size(); i++) {
         WfActivityInternal act = (WfActivityInternal) l.get(i);
         ret.add(SharkEngineManager.getInstance()
            .getObjectFactory()
            .createActivityWrapper(shandle,
                                   proc.manager_name(shandle),
                                   procId,
                                   act.key(shandle)));
      }
      // System.err.println("AllProcesses for mgr
      // "+mgr.getProcessDefinitionId()+" are "+ret);
      return ret;
   }

   static List createAssignmentWrappers(WMSessionHandle shandle,
                                        String procId,
                                        String actId) throws Exception {

      List objs = SharkEngineManager.getInstance()
         .getInstancePersistenceManager()
         .getAllValidAssignmentsForActivity(shandle, procId, actId);

      List pobjs = new ArrayList();
      for (Iterator i = objs.iterator(); i.hasNext();) {
         AssignmentPersistenceObject po = (AssignmentPersistenceObject) i.next();
         pobjs.add(SharkEngineManager.getInstance()
            .getObjectFactory()
            .createAssignmentWrapper(shandle,
                                     po.getProcessMgrName(),
                                     procId,
                                     actId,
                                     po.getResourceUsername()));
      }
      return pobjs;
   }

   static List createAssignmentWrappers(WMSessionHandle shandle, String username)
      throws Exception {

      List objs = SharkUtilities.getResource(shandle, username).getAssignments(shandle);
      List pobjs = new ArrayList();
      for (Iterator i = objs.iterator(); i.hasNext();) {
         WfAssignmentInternal ass = (WfAssignmentInternal) i.next();
         pobjs.add(SharkEngineManager.getInstance()
            .getObjectFactory()
            .createAssignmentWrapper(shandle,
                                     ass.managerName(shandle),
                                     ass.processId(shandle),
                                     ass.activityId(shandle),
                                     username));
      }
      return pobjs;
   }

   static List createAllResourceWrappers(WMSessionHandle shandle) throws Exception {
      List resources = new ArrayList();
      List l = SharkEngineManager.getInstance()
         .getInstancePersistenceManager()
         .getAllResources(shandle);
      for (int i = 0; i < l.size(); i++) {
         ResourcePersistenceObject po = (ResourcePersistenceObject) l.get(i);
         resources.add(SharkEngineManager.getInstance()
            .getObjectFactory()
            .createResourceWrapper(shandle, po.getUsername()));
      }
      return resources;
   }

   static List createProcessHistoryEvents(WMSessionHandle shandle, String procId)
      throws Exception {
      List history = new ArrayList();

      EventAuditManagerInterface eam = SharkEngineManager.getInstance()
         .getDefaultEventAuditManager();

      if (null == eam)
         return history;

      List l = eam.restoreProcessHistory(shandle, procId);
      for (int i = 0; i < l.size(); i++) {
         EventAuditPersistenceInterface audit = (EventAuditPersistenceInterface) l.get(i);
         if (audit instanceof CreateProcessEventAuditPersistenceObject) {
            history.add(SharkEngineManager.getInstance()
               .getObjectFactory()
               .createCreateProcessEventAuditWrapper(shandle,
                                                     (CreateProcessEventAuditPersistenceObject) audit));
         } else if (audit instanceof DataEventAuditPersistenceObject) {
            history.add(SharkEngineManager.getInstance()
               .getObjectFactory()
               .createDataEventAuditWrapper(shandle,
                                            (DataEventAuditPersistenceObject) audit));
         } else if (audit instanceof StateEventAuditPersistenceObject) {
            history.add(SharkEngineManager.getInstance()
               .getObjectFactory()
               .createStateEventAuditWrapper(shandle,
                                             (StateEventAuditPersistenceObject) audit));
         }
      }
      return history;
   }

   static List createActivityHistoryEvents(WMSessionHandle shandle,
                                           String procId,
                                           String actId) throws Exception {
      List history = new ArrayList();

      EventAuditManagerInterface eam = SharkEngineManager.getInstance()
         .getDefaultEventAuditManager();
      if (null == eam)
         return history;
      List l = eam.restoreActivityHistory(shandle, procId, actId);
      for (int i = 0; i < l.size(); i++) {
         EventAuditPersistenceInterface audit = (EventAuditPersistenceInterface) l.get(i);
         if (audit instanceof AssignmentEventAuditPersistenceObject) {
            history.add(SharkEngineManager.getInstance()
               .getObjectFactory()
               .createAssignmentEventAuditWrapper(shandle,
                                                  (AssignmentEventAuditPersistenceObject) audit));
         } else if (audit instanceof DataEventAuditPersistenceObject) {
            history.add(SharkEngineManager.getInstance()
               .getObjectFactory()
               .createDataEventAuditWrapper(shandle,
                                            (DataEventAuditPersistenceObject) audit));
         } else if (audit instanceof StateEventAuditPersistenceObject) {
            history.add(SharkEngineManager.getInstance()
               .getObjectFactory()
               .createStateEventAuditWrapper(shandle,
                                             (StateEventAuditPersistenceObject) audit));
         }
      }

      return history;
   }

   static void reevaluateAssignments(WMSessionHandle shandle) throws Exception {
      List l = SharkEngineManager.getInstance()
         .getInstancePersistenceManager()
         .getAllRunningProcesses(shandle);
      for (int i = 0; i < l.size(); i++) {
         ProcessPersistenceObject po = (ProcessPersistenceObject) l.get(i);
         if (po.getState().startsWith(SharkConstants.STATEPREFIX_OPEN)) {
            WfProcessInternal proc = SharkUtilities.getProcess(shandle,
                                                               po.getId(),
                                                               SharkUtilities.WRITE_MODE);
            List acts = proc.getActiveActivities(shandle);
            Iterator itActs = acts.iterator();
            while (itActs.hasNext()) {
               WfActivityInternal aint = (WfActivityInternal) itActs.next();
               aint.reevaluateAssignments(shandle);
            }
         }
      }
   }

   static TxSynchronization getTxSynchronization() throws Exception {
      TxSynchronizationFactory xasf = SharkEngineManager.getInstance()
         .getTxSynchronizationFactory();
      return (null != xasf) ? xasf.createTxSynchronization() : null;
   }

   static void addResourceToCache(WMSessionHandle shandle, WfResourceInternal r)
      throws Exception {
      SharkUtilities.getTxSynchronization().addToTransaction(r.resource_key(shandle), r);
      CacheMgr cm = SharkEngineManager.getInstance().getCacheManager();
      if (null != cm)
         try {
            cm.getResourceCache().add(r.resource_key(shandle), r);
         } catch (Exception e) {
         }
   }

   static void removeResourceFromCache(WMSessionHandle shandle, WfResourceInternal r)
      throws Exception {
      // ((SharkInternalTransaction)t).removeResource(r.resource_key(t));
      CacheMgr cm = SharkEngineManager.getInstance().getCacheManager();
      if (null != cm)
         cm.getResourceCache().remove(r.resource_key(shandle));
   }

   static WfResourceInternal getResourceFromCache(String username) throws Exception {
      TxSynchronization sr = SharkUtilities.getTxSynchronization();
      WfResourceInternal res = sr.getResource(username);
      if (res == null) {
         CacheMgr cm = SharkEngineManager.getInstance().getCacheManager();
         if (null != cm) {
            try {
               res = cm.getResourceCache().get(username);
               if (res != null) {
                  sr.addToTransaction(username, res);
               }
            } catch (Exception ex) {
            }
         }
      }

      return res;
   }

   static WfResourceInternal getResource(WMSessionHandle shandle, String username)
      throws Exception {
      SharkEngineManager em = SharkEngineManager.getInstance();
      ObjectFactory objectFactory = em.getObjectFactory();

      WfResourceInternal res = SharkUtilities.getResourceFromCache(username);
      if (res == null) {
         PersistentManagerInterface pmi = em.getInstancePersistenceManager();
         ResourcePersistenceObject po = pmi.restoreResource(shandle, username);
         if (po != null) {
            res = objectFactory.createResource(po);
            SharkUtilities.addResourceToCache(shandle, res);
         }
      }

      return res;
   }

   static void addProcessToCache(WMSessionHandle shandle, WfProcessInternal p, int mode)
      throws Exception {
      TxSynchronization sr = SharkUtilities.getTxSynchronization();
      sr.addToTransaction(p.key(shandle), p);
      if (mode == SharkUtilities.WRITE_MODE) {
         sr.markNotReadOnly(p.key(shandle));
      } else {
         CacheMgr cm = SharkEngineManager.getInstance().getCacheManager();
         if (null != cm) {
            try {
               cm.getProcessCache().add(p.key(shandle), p);
            } catch (Exception e) {
            }
         }
      }
   }

   static void removeProcessFromCache(WMSessionHandle shandle, WfProcessInternal p)
      throws Exception {
      CacheMgr cm = SharkEngineManager.getInstance().getCacheManager();

      if (null != cm)
         cm.getProcessCache().remove(p.key(shandle));
   }

   private static WfProcessInternal getProcessFromCache(WMSessionHandle shandle,
                                                        String procId,
                                                        int mode) throws Exception {
      TxSynchronization sr = SharkUtilities.getTxSynchronization();
      WfProcessInternal proc = sr.getProcess(procId);

      if (proc == null) {
         CacheMgr cm = SharkEngineManager.getInstance().getCacheManager();
         if (null != cm) {
            try {
               proc = cm.getProcessCache().get(procId);
               if (proc != null) {
                  sr.addToTransaction(proc.key(shandle), proc);
               }
            } catch (Exception ex) {
            }
         }
      }

      if (proc != null && mode == SharkUtilities.WRITE_MODE && proc.isReadOnly()) {
         sr.markNotReadOnly(procId);
         proc = sr.getProcess(procId);
      }

      return proc;
   }

   static WfProcessInternal getProcess(WMSessionHandle shandle, String procId, int mode)
      throws Exception {
      ObjectFactory objectFactory = SharkEngineManager.getInstance().getObjectFactory();

      WfProcessInternal proc = SharkUtilities.getProcessFromCache(shandle, procId, mode);

      if (proc == null) {
         PersistentManagerInterface pmi = SharkEngineManager.getInstance()
            .getInstancePersistenceManager();
         ProcessPersistenceObject po = pmi.restoreProcess(shandle, procId);
         if (po != null) {
            proc = objectFactory.createProcess(po);
            if (mode == SharkUtilities.WRITE_MODE) {
               proc.setReadOnly(false);
            }
            SharkUtilities.addProcessToCache(shandle, proc, mode);
         }
      }

      return proc;
   }

   static WfProcessInternal getProcess(WMSessionHandle shandle,
                                       ProcessPersistenceObject po,
                                       int mode) throws Exception {
      ObjectFactory objectFactory = SharkEngineManager.getInstance().getObjectFactory();

      WfProcessInternal proc = SharkUtilities.getProcessFromCache(shandle,
                                                                  po.getId(),
                                                                  mode);
      if (proc == null) {
         proc = objectFactory.createProcess(po);
         if (mode == SharkUtilities.WRITE_MODE) {
            proc.setReadOnly(false);
         }
         SharkUtilities.addProcessToCache(shandle, proc, mode);
      }

      return proc;
   }

   static WfProcessMgrInternal getProcessMgr(WMSessionHandle shandle, String name)
      throws Exception {

      WfProcessMgrInternal mgr = null;

      PersistentManagerInterface pmi = SharkEngineManager.getInstance()
         .getInstancePersistenceManager();

      ProcessMgrPersistenceObject po = pmi.restoreProcessMgr(shandle, name);
      if (po != null) {
         mgr = SharkEngineManager.getInstance().getObjectFactory().createProcessMgr(po);
      }
      return mgr;
   }

   static WfActivityInternal getActivity(WMSessionHandle shandle,
                                         String procId,
                                         String actId,
                                         int mode) throws Exception {

      // System.out.println("PID="+procId+",aid="+actId);
      WfProcessInternal proc = getProcess(shandle, procId, mode);
      WfActivityInternal act = proc.getActivity(shandle, actId);

      return act;
   }

   static WfAssignmentInternal getAssignment(WMSessionHandle shandle,
                                             String procId,
                                             String actId,
                                             String username) throws Exception {

      WfResourceInternal res = getResource(shandle, username);
      WfAssignmentInternal ass = res.getAssignment(shandle, procId, actId);

      return ass;
   }

   static WfAssignment getAssignmentWrapper(WMSessionHandle shandle,
                                            String procId,
                                            String assId) throws Exception {
      String[] tokens = MiscUtilities.tokenize(assId, "#");
      String actId = tokens[0];
      String uname = tokens[1];
      WfResourceInternal res = getResource(shandle, uname);
      WfAssignmentInternal ass = null;

      if (res != null) {
         ass = res.getAssignment(shandle, procId, actId);
      }

      if (ass != null) {
         return SharkEngineManager.getInstance()
            .getObjectFactory()
            .createAssignmentWrapper(shandle,
                                     ass.managerName(shandle),
                                     procId,
                                     actId,
                                     uname);
      }

      return null;
   }
 boolean throwException = false;
      XMLElement choosen = ((DataType) dfOrFp.get("DataType")).getDataTypes()
         .getChoosen();

      if (choosen instanceof BasicType) {
         if (cls == Long.class) {
            if (val instanceof Integer) {
               val = new Long(((Integer) val).intValue());
            } else if (val instanceof Short) {
               val = new Long(((Short) val).shortValue());
            } else {
               throwException = true;
            }
         } else if (cls == Double.class) {
            if (val instanceof Integer) {
               val = new Double(((Integer) val).intValue());
            } else if (val instanceof Short) {
               val = new Double(((Short) val).shortValue());
            } else if (val instanceof Long) {
               val = new Double(((Long) val).longValue());
            } else if (val instanceof Float) {
               val = new Double(((Float) val).floatValue());
            } else {
               throwException = true;
            }
         } else if (cls == java.util.Date.class) {
            if (val instanceof java.sql.Date) {
               val = new java.util.Date(((java.sql.Date) val).getTime());
            } else if (val instanceof java.sql.Timestamp) {
               val = new java.util.Date(((java.sql.Timestamp) val).getTime());
            } else if (val instanceof Calendar) {
               val = new java.util.Date(((Calendar) val).getTime().getTime());
            } else {
               throwException = true;
            }
         } else if (cls == String.class) {
            if (!(val instanceof String)) {
               throwException = true;
            }
         } else if (cls == Boolean.class) {
            if (!(val instanceof Boolean)) {
               throwException = true;
            }
         }
      } else if (choosen instanceof SchemaType) {
         if (!Node.class.isAssignableFrom(val.getClass())) {
            throwException = true;
         }
      } else {
         if (oldVal != null || !cls.isInstance(val)) {
            throwException = true;
         }
      }

      if (throwException) {
         throw new Exception("Invalid data type for variable "
                             + dfOrFp.getId() + ", required type=" + cls.getName()
                             + ", provided type=" + val.getClass() + ", oldval=" + oldVal
                             + ", value=" + val);
      }

      return val;
   }

