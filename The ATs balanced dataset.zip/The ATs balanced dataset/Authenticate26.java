import java.io.*;
import java.util.*;
import wolf.security.*;
import wolf.net.http.*;

/**
AuthentificationManager reads the files containing the protected resources
and associates bindings between URI and *.auth files.
*/
public class AuthentificationManager extends Object implements Configurable{
	protected SecurityManager SM;
	protected WolfServer WS;
        protected Hashtable AuthEntries,AuthMapFile,AuthMapDir;
        protected String AuthFileName;
	protected ConfigManager configuration;
        
        public AuthentificationManager(WolfServer WS){
		this(WS,null);
		this.SM=new SecurityManager(WS,true);
	}
	public AuthentificationManager(WolfServer WS,SecurityManager SM){
		this.WS=WS;
		this.SM=SM==null?(this.SM=new SecurityManager(WS,true)):SM;
		configuration=WolfServer.getConfiguration();
		configuration.add(this);
                readProtectedResources();
	}
/**
Parses the "protected" file. Associates bindings between URIs and *.auth files.
*/
	protected synchronized void readProtectedResources(){
		AuthFileName=configuration.getConfigDir()+File.separator+"protected";
                File AuthFile=new File(AuthFileName);
                BufferedReader BR=null;
                String Now,Resource,AuthForResource;
                AuthentificationEntry TmpAuth;
                AuthEntries=new Hashtable();
                AuthMapFile=new Hashtable();
                AuthMapDir=new Hashtable();
                int Index;
                try{
                    BR=new BufferedReader(new FileReader(AuthFile));
                }catch (FileNotFoundException e){
                    writeLog("AuthFile "+AuthFileName+" not found.");
                    System.exit(1);
                }
                try{
                    while (BR.ready()){
                        Now=BR.readLine().trim();
                        if (Now.startsWith("#")) continue;
                        if (Now.equals("")) continue;
                        Index=Now.indexOf(":");
                        if (Index==-1){
                            writeLog("Invalid AuthEntry:"+Now+".");
			    continue;
                        }
                        Resource=Now.substring(0,Index);
                        AuthForResource=Now.substring(Index+1);
                        TmpAuth=new AuthentificationEntry("config"+File.separator+AuthForResource);
			System.out.println("Read: config"+File.separator+AuthForResource);
                        if (Resource.endsWith("/*")){
				String what=Resource.substring(0,Resource.lastIndexOf("/"));
				System.err.println("Resource:"+what);
                            	AuthMapDir.put(Resource.substring(0,Resource.lastIndexOf("/")),TmpAuth);
                        }else{
                            	AuthMapFile.put(Resource,TmpAuth);
				System.err.println(Resource);
                        }
                    }
                }catch (IOException e){
                    writeLog("Error reading AuthFile "+AuthFileName+".");
                }
                            
        }
/**
Returns the name of the Realm the specified Request belongs to, null if the
Request is not known to the AuthentificationManager.
*/
	public String authRequired(String Request){
		System.err.println("Wants:"+Request);
		if (Request==null) return null;
		if (Request.equals("")) return null;
		if (AuthMapFile.containsKey(Request)){
			AuthentificationEntry TmpAuth=(AuthentificationEntry)
				AuthMapFile.get(Request);
				if (TmpAuth==null) System.err.println("Auth==null!1");
			return TmpAuth.getRealm();
		}
		int index=Request.lastIndexOf("/");
		if (index==-1) return null;
		String what=Request.substring(0,index);
		System.err.println("Wants:"+what);
		if (AuthMapDir.containsKey(Request.substring(0,index))){
			AuthentificationEntry TmpAuth=(AuthentificationEntry)
				AuthMapDir.get(Request.substring(0,index));
				if (TmpAuth==null) System.err.println("Auth==null!2");
			return TmpAuth.getRealm();
		}
		return null;
	}                    
/**
Checks wether the credentials in HTTPHeader allow the user access to the URI.
*/
	public boolean authCorrect(String Request,HTTPHeader Header){
//first check if the Request is meaningfull
		if (Request==null || Header==null) return false;
		if (Request.equals("")) return false;
		AuthentificationEntry TmpAuth=null;
//now get the AuthentificationEntry for our Request
		if (AuthMapFile.containsKey(Request)){
			TmpAuth=(AuthentificationEntry)AuthMapFile.get(Request);
		}else{
			int Index=Request.lastIndexOf("/");
			if (Index==-1) return false;
			String RequestDir=Request.substring(0,Index);
			if (AuthMapDir.containsKey(RequestDir)){
				TmpAuth=(AuthentificationEntry)AuthMapDir.get(RequestDir);
			}
		}
/*
TmpAuth shouldnt be null, as ResourceManager (who calls this procedure) first
checks authRequired().
*/
		if (TmpAuth==null) return false;
//ok got AuthEntry...
		String AuthData[],User,Password,Groups[];
		AuthData=Header.getAuthData();
		if (AuthData==null) return false;
		User=AuthData[0];Password=AuthData[1];
// First check if the username and password are sufficient
		if (TmpAuth.isUserValid(User)){
			if (SM.isAllowed(User,Password,null)) return true;
		}
// Else check if a user belongs to a group and knows the correct group-password
		Groups=TmpAuth.getGroups();
		if (SM.isAllowed("#",Password,Groups)) return true;
		return false;
	}
/**
Returns "AuthentificationManager".
*/
	public String toString(){
		return "AuthentificationManager";
	}
/**
Write to the log file.
*/
	protected void writeLog(String Msg){
		WS.writeLog(this,Msg);
	}
/**
Required by Interface Configurable. Parses the "protected" file if appropriate.
*/
	public void configurationChange(int code){
		if (code==ConfigManager.protectedResourcesChanged){
			WS.writeLog(this,"Loading protected resources.");
			readProtectedResources();
		}
	}
			
}
