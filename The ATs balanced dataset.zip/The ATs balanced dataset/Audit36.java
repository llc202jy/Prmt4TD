*  org.biomage.AuditAndSecurity
 *  
 */
package org.biomage.AuditAndSecurity;

/**
 *  Import list for Audit
 *  
 */
import java.io.IOException;
import java.io.Serializable;
import java.io.Writer;
import java.util.Date;
import java.util.HashMap;

import org.biomage.Common.Describable;
import org.biomage.Interface.HasPerformer;
import org.xml.sax.Attributes;

/**
 *  Tracks information on the contact that creates or modifies an object.
 *  
 */
public
class Audit
    extends Describable
    implements Serializable,
        HasPerformer
{
    /**
     *  The date of a change.
     *  
     */
    private Date date;

    /**
     *  Inner class for the enumeration values that the attribute action 
     *  can assume.
     *  
     */
    public
    class
    Action
    implements Serializable
    {
        int value = -1;
        String name = null;
        private HashMap nameToValue = new HashMap(2);

        private HashMap valueToName = new HashMap(2);

        final public int creation = 0;
        final public int modification = 1;

        Action(){
            nameToValue.put("creation",new Integer(0));
            valueToName.put(new Integer(0),"creation");
            nameToValue.put("modification",new Integer(1));
            valueToName.put(new Integer(1),"modification");
        }

        public String[] getNames() {
                java.util.ArrayList names = new java.util.ArrayList();
                names.addAll(nameToValue.keySet());
                java.util.Collections.sort(names);
                return (String[]) names.toArray(new String[0]);
        }
        private void setValue(int newValue) {
                if (value != newValue) {
                    value = newValue;
                    setAttributeModified(!isLoading());
                }
        }
        public int setValueByName(String newName) {
                name = newName;
                setValue(((Integer)nameToValue.get(newName)).intValue());
                return value;
        }
        public int getValueByName(String name) {
                return ((Integer)nameToValue.get(name)).intValue();
        }
        public String setNameByValue(int newValue) {
                setValue(newValue);
                name = ((String)valueToName.get(new Integer(newValue)));
                return name;
        }
        public String getNameByValue(int val) {
                return ((String)valueToName.get(new Integer(val)));
        }
        public int getValue() {
                return value;
        }
        public String getName() {
                return name;
        }
        public String toString() {
                return getNameByValue(getValue());
        }
    }

    /**
     *  Indicates whether an action is a creation or a modification.
     *  
     */
     Action action = new Action();

    /**
     *  The contact for creating or changing the instance referred to by 
     *  the Audit.
     *  
     */
    private Contact performer;


    /**
     *  Default constructor.
     *  
     */
    public
    Audit()
    {
        super();
    }

    /**
     *  Attribute constructor.
     *  
     *  Looks up the attributes in the parameter and casts them from strings 
     *  appropriately
     *  @param atts: the attribute list.
     *  
     */
    // TO_BE_DONE Work in progress (attribute constructor).
    public
    Audit(Attributes atts)
    {
        super(atts);

        {
            int nIndex = atts.getIndex("", "date");
            if (nIndex != -1 && null != atts.getValue(nIndex) && 0 < ((String) atts.getValue(nIndex)).length())
            {
                try {
                    date = (new java.text.SimpleDateFormat("yyyy-MM-dd")).parse(atts.getValue(nIndex));
                } catch (java.text.ParseException e) {
                    e.printStackTrace();
                }
            }
        }

        {
            int nIndex = atts.getIndex("", "action");
            if (nIndex != -1 && null != atts.getValue(nIndex) && 0 < ((String) atts.getValue(nIndex)).length())
            {
                action.setValueByName(atts.getValue(nIndex));
            }
        }

    }

    /**
     *  writeMAGEML
     *  
     *  This method is responsible for assembling the attribute and 
     *  association data into XML. It creates the object tag and then calls 
     *  the writeAttributes and writeAssociation methods.
     *  
     *  
     */
    public
    void
    writeMAGEML(Writer out)
    throws IOException
    {
        if (!emptyMAGEobject()) {
            out.write("<!-- ");
            out.write("inDatabase=" + inDatabase() + ", dbId=" + getDbId() + ", uniqueId=" + getUniqueId() + ", ");
            out.write("modified=" + isModified() + ", attributeModified=" + isAttributeModified());
            out.write(" -->\n");
            out.write("<Audit");
            writeAttributes(out);
            out.write(">\n");
            writeAssociations(out);
            out.write("</Audit>\n");
        }
    }

    public
    boolean
    emptyMAGEobject()
    {
        return this.getPropertySets().size() == 1 && 
            this.getFromPropertySets(0).getName().equals("Placeholder");
    }

    /**
     *  writeAttributes
     *  
     *  This method is responsible for assembling the attribute data into 
     *  XML. It calls the super method to write out all attributes of this 
     *  class and it's ancestors.
     *  
     *  
     */
    public
    void
    writeAttributes(Writer out)
    throws IOException
    {
        super.writeAttributes(out);
        if ( getDate() != null ) {
            out.write(" date=\"" + getDate() + "\"");
        }
        if ( getAction() != null ) {
            out.write(" action=\"" + getAction() + "\"");
        }
    }

    /**
     *  writeAssociations
     *  
     *  This method is responsible for assembling the association data 
     *  into XML. It calls the super method to write out all associations of 
     *  this class's ancestors.
     *  
     *  
     */
    public
    void
    writeAssociations(Writer out)
    throws IOException
    {
        super.writeAssociations(out);
        if ( getPerformer() != null ){
            out.write("<Performer_assnref>\n");
            out.write("<" + getPerformer().getModelClassName() +
                "_ref identifier=\"" + getPerformer().getIdentifier() + "\"/>\n ");
            out.write("</Performer_assnref>\n");
        }
    }

    /**
     *  Set method for date
     *  
     *  @param value to set
     *  
     *  
     */
    public
    void
    setDate(
        Date date
    )
    {
        ensureLoaded();
        if (handleSetAttribute(this.date, date)) {
            this.date = date;
        }
    }

    /**
     *  Get method for date
     *  
     *  @return value of the attribute
     *  
     *  
     */
    public
    Date
    getDate()
    {
        ensureLoaded();
        return date;
    }

    /**
     *  Set method for action
     *  
     *  @param value to set
     *  
     *  
     */
    public
    void
    setAction(
        Action action
    )
    {
        ensureLoaded();
        if (handleSetAttribute(this.action, action)) {
            this.action = action;
        }
    }

    /**
     *  Get method for action
     *  
     *  @return value of the attribute
     *  
     *  
     */
    public
    Action
    getAction()
    {
        ensureLoaded();
        return action;
    }

/**
* For Action set the Name of the Enumeration type by passing a value (int)
* @param int value The value to be mapped to the name */
    public
    String
    setNameByValueAction (int val)
    {
    return getAction().setNameByValue(val);
    }
/**
* For Action set the Value of the Enumeration type by passing a Name to it.
* @param String name The name to be mapped to a value */
    public
    int
    setValueByNameAction (String name)
    {
    return getAction().setValueByName(name);
    }
/**
* For Action get the Name of the Enumeration type by passing a Value to it.
* @param int val The value for which the Mapped String will be returned. */
    public
    String
    getNameByValueAction (int val)
    {
     return getAction().getNameByValue(val);
    }
/**
* For Action get the Value of the Enumeration type by passing a Name to it.
* @param String name The name to be mapped to a value. */
    public
    int    
getValueByNameAction (String name)
    {
     return getAction().getValueByName(name);
    }
/**
* Return the current name of the Enumeration type of Action.
*/    public
    String
    getNameAction()
    {
     return getAction().getName();
    }
/**
* Return the currrent value of the Enumeration type of Action.
*/    public
    int
    getValueAction()
    {
     return getAction().getValue();
    }
    public
    static String
    getStaticModelClassName() {
        return "Audit";
    }

    public
    String
    getModelClassName() {
        return getStaticModelClassName();
    }

    /**
     *  Set method for performer
     *  
     *  @param value to set
     *  
     *  
     */
    public
    void
    setPerformer(
        Contact performer
    )
    {
        ensureLoaded();
        if (handleSetMAGEObjectContainer(this.performer, performer)) {
            this.performer = performer;
        }
    }

    /**
     *  Get method for performer
     *  
     *  @return value of the attribute
     *  
     *  
     */
    public
    Contact
    getPerformer()
    {
        ensureLoaded();
        return this.performer;
    }


    protected void cloneAttributes(org.biomage.Common.MAGEObjectContainer clone) {
        super.cloneAttributes(clone);
        Audit cloneAudit = (Audit) clone;
        if (date != null) {
            cloneAudit.date = date;
        }
        if (action != null) {
            cloneAudit.action = action;
        }
    }

    protected void cloneAssociations(org.biomage.Common.MAGEObjectContainer clone, org.biomage.Common.MAGECloneManager mageCloneManager) {
        super.cloneAssociations(clone, mageCloneManager);
        Audit cloneAudit = (Audit) clone;
        if (performer != null) {
            cloneAudit.performer = (Contact) performer.cloneMAGE(cloneAudit, mageCloneManager);
        }
    }

    protected org.biomage.Common.MAGEObjectContainer createCloneInstance() {
        return new Audit();
    }

    protected void addModifiedChildren(org.biomage.Common.Modifications modifications) {
        super.addModifiedChildren(modifications);
        if (performer != null) {
            performer.addModifications(modifications);
        }
    }

    protected void addDeleteableChildren(java.util.Set deleteableObjects) {
        super.addDeleteableChildren(deleteableObjects);
        if (performer != null) {
            performer.addDeleteableObjects(deleteableObjects);
        }
    }
}package org.biomage.AuditAndSecurity;

/**
 *  Import list for Security
 *  
 */
import java.io.IOException;
import java.io.Serializable;
import java.io.Writer;

import org.biomage.Common.Identifiable;
import org.biomage.Interface.HasOwner;
import org.biomage.Interface.HasSecurityGroups;
import org.xml.sax.Attributes;

/**
 *  Permission information for an object as to ownership, write and read 
 *  permissions.
 *  
 */
public
class Security
    extends Identifiable
    implements Serializable,
        HasSecurityGroups,
        HasOwner
{
    /**
     *  The owner of the security rights.
     *  
     */
    protected Owner_list owner;

    /**
     *  Specifies which security groups have permission to view the 
     *  associated object.
     *  
     */
    protected SecurityGroups_list securityGroups;

    /**
     *  Default constructor.
     *  
     */
    public
    Security()
    {
        super();
    }

    /**
     *  Attribute constructor.
     *  
     *  Looks up the attributes in the parameter and casts them from strings 
     *  appropriately
     *  @param atts: the attribute list.
     *  
     */
    // TO_BE_DONE Work in progress (attribute constructor).
    public
    Security(Attributes atts)
    {
        super(atts);

    }

    /**
     *  writeMAGEML
     *  
     *  This method is responsible for assembling the attribute and 
     *  association data into XML. It creates the object tag and then calls 
     *  the writeAttributes and writeAssociation methods.
     *  
     *  
     */
    public
    void
    writeMAGEML(Writer out)
    throws IOException
    {
        if (!emptyMAGEobject()) {
            out.write("<!-- ");
            out.write("inDatabase=" + inDatabase() + ", dbId=" + getDbId() + ", uniqueId=" + getUniqueId() + ", ");
            out.write("modified=" + isModified() + ", attributeModified=" + isAttributeModified());
            out.write(" -->\n");
            out.write("<Security");
            writeAttributes(out);
            out.write(">\n");
            writeAssociations(out);
            out.write("</Security>\n");
        }
    }

    public
    boolean
    emptyMAGEobject()
    {
        return this.getPropertySets().size() == 1 && 
            this.getFromPropertySets(0).getName().equals("Placeholder");
    }

    /**
     *  writeAttributes
     *  
     *  This method is responsible for assembling the attribute data into 
     *  XML. It calls the super method to write out all attributes of this 
     *  class and it's ancestors.
     *  
     *  
     */
    public
    void
    writeAttributes(Writer out)
    throws IOException
    {
        super.writeAttributes(out);
    }

    /**
     *  writeAssociations
     *  
     *  This method is responsible for assembling the association data 
     *  into XML. It calls the super method to write out all associations of 
     *  this class's ancestors.
     *  
     *  
     */
    public
    void
    writeAssociations(Writer out)
    throws IOException
    {
        super.writeAssociations(out);
        if ( getOwner().size() > 0 ){
            out.write("<!-- ");
            out.write("listModified=" + owner.isListModified());
            out.write(" -->\n");
            out.write("<Owner_assnreflist>\n");
            for ( int i = 0; i < getOwner().size(); i++) {
                String modelClassName = ((Contact) getOwner().get(i)).getModelClassName();
                out.write("<" + modelClassName +
                "_ref identifier=\"" + ((Contact) getOwner().get(i)).getIdentifier() + "\"/>\n");
            }
            out.write("</Owner_assnreflist>\n");
        }
        if ( getSecurityGroups().size() > 0 ){
            out.write("<!-- ");
            out.write("listModified=" + securityGroups.isListModified());
            out.write(" -->\n");
            out.write("<SecurityGroups_assnreflist>\n");
            for ( int i = 0; i < getSecurityGroups().size(); i++) {
                String modelClassName = ((SecurityGroup) getSecurityGroups().get(i)).getModelClassName();
                out.write("<" + modelClassName +
                "_ref identifier=\"" + ((SecurityGroup) getSecurityGroups().get(i)).getIdentifier() + "\"/>\n");
            }
            out.write("</SecurityGroups_assnreflist>\n");
        }
    }

    public
    static String
    getStaticModelClassName() {
        return "Security";
    }

    public
    String
    getModelClassName() {
        return getStaticModelClassName();
    }

    /**
     *  Set method for owner
     *  
     *  @param value to set
     *  
     *  
     */
    public
    void
    setOwner(
        Owner_list owner
    )
    {
        ensureLoaded();
        if (handleSetMAGEObjectContainer(this.owner, owner)) {
            this.owner = owner;
        }
    }

    /**
     *  Get method for owner
     *  
     *  @return value of the attribute
     *  
     *  
     */
    public
    Owner_list
    getOwner()
    {
        ensureLoaded();
        if (this.owner == null) {
            this.owner = new Owner_list(this);
        }
        return this.owner;
    }

    /**
     *  Method to add Contact to Owner_list
     *  
     */
    public
    void
    addToOwner(
        Contact contact
    )
    {
        this.getOwner().add(contact);
    }

    /**
     *  Method to add Contact at position to Owner_list
     *  
     */
    public
    void
    addToOwner(
        int position,
        Contact contact
    )
    {
        this.getOwner().add(position, contact);
    }

    /**
     *  Method to get Contact from Owner_list
     *  
     */
    public
    Contact
    getFromOwner(
        int position
    )
    {
        return (Contact) this.getOwner().get(position);
    }

    /**
     *  Method to remove by position from Owner_list
     *  
     */
    public
    void
    removeElementAtFromOwner(
        int position
    )
    {
        this.getOwner().remove(position);
    }

    /**
     *  Method to remove first Contact from Owner_list
     *  
     */
    public
    void
    removeFromOwner(
        Contact contact
    )
    {
        this.getOwner().remove(contact);
    }

    /**
     *  Set method for securityGroups
     *  
     *  @param value to set
     *  
     *  
     */
    public
    void
    setSecurityGroups(
        SecurityGroups_list securityGroups
    )
    {
        ensureLoaded();
        if (handleSetMAGEObjectContainer(this.securityGroups, securityGroups)) {
            this.securityGroups = securityGroups;
        }
    }

    /**
     *  Get method for securityGroups
     *  
     *  @return value of the attribute
     *  
     *  
     */
    public
    SecurityGroups_list
    getSecurityGroups()
    {
        ensureLoaded();
        if (this.securityGroups == null) {
            this.securityGroups = new SecurityGroups_list(this);
        }
        return this.securityGroups;
    }

    /**
     *  Method to add SecurityGroup to SecurityGroups_list
     *  
     */
    public
    void
    addToSecurityGroups(
        SecurityGroup securityGroup
    )
    {
        this.getSecurityGroups().add(securityGroup);
    }

    /**
     *  Method to add SecurityGroup at position to SecurityGroups_list
     *  
     */
    public
    void
    addToSecurityGroups(
        int position,
        SecurityGroup securityGroup
    )
    {
        this.getSecurityGroups().add(position, securityGroup);
    }

    /**
     *  Method to get SecurityGroup from SecurityGroups_list
     *  
     */
    public
    SecurityGroup
    getFromSecurityGroups(
        int position
    )
    {
        return (SecurityGroup) this.getSecurityGroups().get(position);
    }

    /**
     *  Method to remove by position from SecurityGroups_list
     *  
     */
    public
    void
    removeElementAtFromSecurityGroups(
        int position
    )
    {
        this.getSecurityGroups().remove(position);
    }

    /**
     *  Method to remove first SecurityGroup from SecurityGroups_list
     *  
     */
    public
    void
    removeFromSecurityGroups(
        SecurityGroup securityGroup
    )
    {
        this.getSecurityGroups().remove(securityGroup);
    }


    protected void cloneAssociations(org.biomage.Common.MAGEObjectContainer clone, org.biomage.Common.MAGECloneManager mageCloneManager) {
        super.cloneAssociations(clone, mageCloneManager);
        Security cloneSecurity = (Security) clone;
        if (owner != null) {
            cloneSecurity.owner = (Owner_list) owner.cloneMAGE(cloneSecurity, mageCloneManager);
        }
        if (securityGroups != null) {
            cloneSecurity.securityGroups = (SecurityGroups_list) securityGroups.cloneMAGE(cloneSecurity, mageCloneManager);
        }
    }

    protected org.biomage.Common.MAGEObjectContainer createCloneInstance() {
        return new Security();
    }

    protected void addModifiedChildren(org.biomage.Common.Modifications modifications) {
        super.addModifiedChildren(modifications);
        if (owner != null) {
            owner.addModifications(modifications);
        }
        if (securityGroups != null) {
            securityGroups.addModifications(modifications);
        }
    }

    protected void addDeleteableChildren(java.util.Set deleteableObjects) {
        super.addDeleteableChildren(deleteableObjects);
        if (owner != null) {
            owner.addDeleteableObjects(deleteableObjects);
        }
        if (securityGroups != null) {
            securityGroups.addDeleteableObjects(deleteableObjects);
        }
    }
}