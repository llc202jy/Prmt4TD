package com.oncecorp.visa3d.bridge.beans;

import java.io.Serializable;
import java.util.Properties;

/**
 * <p>Title: ONCE MPI Data Bridge</p>
 * <p>Description: This bean class contains the merchant info data.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Once Corporation</p>
 * @author yge@oncecorp.com
 * @version 1.0
 */

public class MerchantInfoBean implements Serializable {

  public static final String  ID                 = "id";
  public static final String  NAME               = "name";
  public static final String  DATA_SOURCE_JNDI   = "dataSourceJndi";
  public static final String  JDBC_DRIVER_NAME   = "jdbcDriverName";
  public static final String  DATABASE_URL       = "databaseUrl";
  public static final String  DATABASE_USER_NAME = "databaseUserName";
  public static final String  DATABASE_PASSWORD  = "databasePassword";
  public static final String  SCHEMA_NAME        = "schemaName";
  public static final String  MERCHANT_PASSWORD  = "merchantPassword";
  public static final String  MERCHANT_URL       = "merchantUrl";
  public static final String  COUNTRY_CODE       = "countryCode";
  public static final String  PURCHASE_CURRENCY  = "purchaseCurrency";
  public static final String  ACQ_BIN            = "acqBIN";
  public static final String  PROTOCOL_SUPPORT   = "protocolSupport";
  public static final String  LICENSING_KEY      = "licensingKey";
  public static final String  KEY_EXPIRY_DATE    = "keyExpiryDate";

  private String id;
  private String name;
  private String dataSourceJndi;
  private String jdbcDriverName;
  private String databaseUrl;
  private String databaseUserName;
  private String databasePassword;
  private String schemaName;
  private String merchantPassword;
  private String merchantUrl;
  private String countryCode;
  private String purchaseCurrency;
  private String acqBin;
  private byte protocolSupport = 1;
  private String licensingKey;
  private long keyExpiryDate;

  /**
   * The default constructor.
   */
  public MerchantInfoBean() {
  }

  public String getId() {
    return this.id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDataSourceJndi() {
    return this.dataSourceJndi;
  }

  public void setDataSourceJndi(String dataSourceJndi) {
    this.dataSourceJndi = dataSourceJndi;
  }

  public String getJdbcDriverName() {
    return jdbcDriverName;
  }

  public void setJdbcDriverName(String jdbcDriverName) {
    this.jdbcDriverName = jdbcDriverName;
  }

  public String getDatabaseUrl() {
    return this.databaseUrl;
  }

  public void setDatabaseUrl(String databaseUrl) {
    this.databaseUrl = databaseUrl;
  }

  public String getDatabaseUserName() {
    return this.databaseUserName;
  }

  public void setDatabaseUserName(String databaseUserName) {
    this.databaseUserName = databaseUserName;
  }

  public String getDatabasePassword() {
    return this.databasePassword;
  }

  public void setDatabasePassword(String databasePassword) {
    this.databasePassword = databasePassword;
  }

  public String getMerchantPassword() {
    return this.merchantPassword;
  }

  public String getSchemaName() {
    return schemaName == null ? "" : schemaName;
  }

  public void setSchemaName(String schemaName) {
    this.schemaName = schemaName;
  }

  public void setMerchantPassword(String merchantPassword) {
    this.merchantPassword = merchantPassword;
  }

  public String getMerchantUrl() {
    return this.merchantUrl;
  }

  public void setMerchantUrl(String merchantUrl) {
    this.merchantUrl = merchantUrl;
  }

  public String getCountryCode() {
    return this.countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  public String getPurchaseCurrency() {
    return this.purchaseCurrency;
  }

  public void setPurchaseCurrency(String purchaseCurrency) {
    this.purchaseCurrency = purchaseCurrency;
  }

  public void fromProperties(Properties prop)
  {
    if ( prop == null )
	{
      return;
    }
    id = prop.getProperty(ID);
    name = prop.getProperty(NAME);
    dataSourceJndi = prop.getProperty(DATA_SOURCE_JNDI);
    jdbcDriverName = prop.getProperty(JDBC_DRIVER_NAME);
    databaseUrl = prop.getProperty(DATABASE_URL);
    databaseUserName = prop.getProperty(DATABASE_USER_NAME);
    databasePassword = prop.getProperty(DATABASE_PASSWORD);
    schemaName = prop.getProperty(SCHEMA_NAME);
    merchantPassword = prop.getProperty(MERCHANT_PASSWORD);
    merchantUrl = prop.getProperty(MERCHANT_URL);
    countryCode = prop.getProperty(COUNTRY_CODE);
    purchaseCurrency = prop.getProperty(PURCHASE_CURRENCY);
    acqBin = prop.getProperty(ACQ_BIN);
	String str = prop.getProperty(PROTOCOL_SUPPORT);
	byte pvalue = 0;
	if ( str != null )
	{
		try {
			pvalue = Byte.parseByte( str );
		} catch ( Exception e )
		{
			pvalue = 0;
		}
	}
    protocolSupport = pvalue;
	licensingKey = prop.getProperty( LICENSING_KEY );

	long kvalue = 0;
	str = prop.getProperty( KEY_EXPIRY_DATE );
	if ( str != null )
	{
		try {
			kvalue = Long.parseLong(  str );
		} catch ( Exception e )
		{
			kvalue = 0;
		}
	}
	keyExpiryDate = kvalue;
  }

  public Properties toProperties() {
    Properties prop = new Properties();
    if ( id != null ) {
      prop.setProperty(ID, id);
    }
    if ( name != null ) {
      prop.setProperty(NAME, name);
    }
    if ( dataSourceJndi != null ) {
      prop.setProperty(DATA_SOURCE_JNDI, dataSourceJndi);
    }
    if ( jdbcDriverName != null ) {
      prop.setProperty(JDBC_DRIVER_NAME, jdbcDriverName);
    }
    if ( databaseUrl != null ) {
      prop.setProperty(DATABASE_URL, databaseUrl);
    }
    if ( databaseUserName != null ) {
      prop.setProperty(DATABASE_USER_NAME, databaseUserName);
    }
    if ( databasePassword != null ) {
      prop.setProperty(DATABASE_PASSWORD, databasePassword);
    }
    if ( schemaName != null ) {
      prop.setProperty(SCHEMA_NAME, schemaName);
    }
    if ( merchantPassword != null ) {
      prop.setProperty(MERCHANT_PASSWORD, merchantPassword);
    }
    if ( merchantUrl != null ) {
      prop.setProperty(MERCHANT_URL, merchantUrl);
    }
    if ( countryCode != null ) {
      prop.setProperty(COUNTRY_CODE, countryCode);
    }
    if ( purchaseCurrency != null ) {
      prop.setProperty(PURCHASE_CURRENCY, purchaseCurrency);
    }
    if ( acqBin != null ) {
      prop.setProperty(ACQ_BIN, acqBin);
    }
    prop.setProperty( PROTOCOL_SUPPORT, ""+protocolSupport );
	if ( licensingKey != null ) {
	  prop.setProperty(LICENSING_KEY, licensingKey);
	}
    prop.setProperty(KEY_EXPIRY_DATE, ""+keyExpiryDate);
    return prop;
  }

  /**
   * Returns the acqBin.
   * @return String
   */
  public String getAcqBin() {
	return acqBin;
  }

  /**
   * Sets the acqBin.
   * @param acqBin The acqBin to set
   */
  public void setAcqBin(String acqBin) {
	this.acqBin = acqBin;
  }

  /**
  *
  * @return the byte value of protocolSupport.
  */
  public byte getProtocolSupport(){
      return protocolSupport;
  }

  /**
  *
  * @param aProtocolSupport - the new value for protocolSupport
  */
  public void setProtocolSupport(byte aProtocolSupport){
      protocolSupport = aProtocolSupport;
  }


	/**
	*
	* @return the String value of licensingKey.
	*/
	public String getLicensingKey(){
		return licensingKey;
	}

	/**
	*
	* @param aLicensingKey - the new value for licensingKey
	*/
	public void setLicensingKey(String aLicensingKey){
		licensingKey = aLicensingKey;
	}


	/**
	*
	* @return the long value of keyExpiryDate.
	*/
	public long getKeyExpiryDate(){
		return keyExpiryDate;
	}

	/**
	*
	* @param aKeyExpiryDate - the new value for keyExpiryDate
	*/
	public void setKeyExpiryDate(long aKeyExpiryDate){
		keyExpiryDate = aKeyExpiryDate;
	}


}

package com.oncecorp.visa3d.bridge.beans;

import java.io.Serializable;

import com.oncecorp.visa3d.bridge.utility.ConfigureConstants;

/**
 * <p>Title: DataBridgeBean</p>
 * <p>Description: Hold the Data Bridge related configuration data </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: ONCE Corporation </p>
 * @author Gang Wu ( gwu@oncecorp.com )
 * @version 1.0
 */


public class DataBridgeBean implements Serializable, ConfigureConstants
{

    private boolean autoSave = true;

    /**
     * This for internal use only.
     */
    private boolean attributeSet = true;

    private ListeningServiceBean listeningService = null;
    private AuditingServiceBean  auditingService = null;
    private MonitoringServiceBean monitoringService = null;
    private PluginServiceBean     pluginService = null;

    /**
     * Default constructor
     */
    public DataBridgeBean()
    {
    }

    /**
     * Get auto save flag
     * @return
     */
    public boolean isAutoSave()
    {
        return autoSave;
    }

    /**
     * Set auto save value
     * @param flag - auto save flag
     */
    public void setAutoSave( boolean flag )
    {
        autoSave = flag;
    }

    /**
     * Configure from XML string
     * @param xml - Configuration XML string
     */
    public void fromXml( String xml )
    {
        BeansHelper.databridgeFromXml( this, xml );
    }

    /**
     * Generate XML string
     * @return - XML definition
     */
    public String toXml()
    {
        String sauto = "false";
        if ( autoSave )
            sauto = "true";

        StringBuffer sb = new StringBuffer();
        sb.append("<?xml version=\"1.0\" encoding=\"ISO-8859-1\" standalone=\"no\"?>\r\n");
        sb.append("<!DOCTYPE " + DATA_BRIDGE_TAG +" >\r\n");
        sb.append("<" + DATA_BRIDGE_TAG +" xmlns:mpidb='http://www.oncecorp.com/ONCEmpi/databridge-configuration' "
                  + "autoSave=\"" + sauto + "\">\r\n");

        if ( listeningService != null )
        {
            sb.append( listeningService.toXml() );
        }
        else
        {
            sb.append( "<" + LISTENING_SERVICE_TAG + " />\r\n\r\n");
        }

        if ( auditingService != null )
        {
            sb.append( auditingService.toXml() );
        }
        else
        {
            sb.append( "<" + AUDITING_SERVICE_TAG + " />\r\n\r\n");
        }

        if ( monitoringService != null )
        {
            sb.append( monitoringService.toXml() );
        }
        else
        {
            sb.append( "<" + MONITORING_SERVICE_TAG + " />\r\n\r\n");
        }

        if ( pluginService != null )
        {
            sb.append( pluginService.toXml() );
        }
        else
        {
            sb.append( "<" + PLUGIN_SERVICE_TAG + " />\r\n\r\n");
        }

        sb.append("</" + DATA_BRIDGE_TAG + ">\r\n");

        return sb.toString();
    }

    /**
    *
    * @return the ListeningServiceBean value of listeningService.
    */
    public ListeningServiceBean getListeningService(){
        return listeningService;
    }

    /**
    *
    * @param aListeningService - the new value for listeningService
    */
    public void setListeningService(ListeningServiceBean aListeningService){
        listeningService = aListeningService;
    }


    /**
    *
    * @return the AuditingServiceBean value of auditingService.
    */
    public AuditingServiceBean getAuditingService(){
        return auditingService;
    }

    /**
    *
    * @param aAuditingService - the new value for auditingService
    */
    public void setAuditingService(AuditingServiceBean aAuditingService){
        auditingService = aAuditingService;
    }


    /**
    *
    * @return the MonitoringServiceBean value of monitoringService.
    */
    public MonitoringServiceBean getMonitoringService(){
        return monitoringService;
    }

    /**
    *
    * @param aMonitoringService - the new value for monitoringService
    */
    public void setMonitoringService(MonitoringServiceBean aMonitoringService){
        monitoringService = aMonitoringService;
    }


    /**
    *
    * @return the PluginServiceBean value of pluginService.
    */
    public PluginServiceBean getPluginService(){
        return pluginService;
    }

    /**
    *
    * @param aPluginService - the new value for pluginService
    */
    public void setPluginService(PluginServiceBean aPluginService){
        pluginService = aPluginService;
    }

    /**
    *
    * @return true if attributeSet is set to true.
    */
    public boolean isAttributeSet(){
        return attributeSet;
    }

    /**
    *
    * @param aAttributeSet - the new value for attributeSet
    */
    public void setAttributeSet(boolean aAttributeSet){
        attributeSet = aAttributeSet;
    }


}

package com.oncecorp.visa3d.bridge.listening;

import java.io.File;
import java.util.List;
import java.util.Collections;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.Enumeration;
import java.util.StringTokenizer;
import java.text.MessageFormat;
import java.text.ParsePosition;
import java.text.Format;
import java.text.SimpleDateFormat;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import org.apache.log4j.Logger;
import com.oncecorp.visa3d.bridge.logging.DataBridgeLoger;
import com.oncecorp.visa3d.bridge.beans.MessageFieldBean;
import com.oncecorp.visa3d.bridge.utility.XMLUtils;
import com.oncecorp.visa3d.bridge.security.TripleDESEncrypter;
import com.oncecorp.visa3d.bridge.beans.MessageDefinitionBean;
import com.oncecorp.visa3d.bridge.beans.FieldDefinitionBean;
import com.oncecorp.visa3d.bridge.beans.MessageMappingBean;
import com.oncecorp.visa3d.bridge.beans.BeansHelper;
import com.oncecorp.visa3d.bridge.configure.FileHandler;

/**
 * <p>Title: MessageFieldsFilter</p>
 * <p>Description: Provide fields related filter functionalities to a given
 * XML message document</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: ONCE Corporation</p>
 * @author Gang Wu ( gwu@oncecorp.com )
 * @version 1.0
 */


public class MessageFieldsFilter
{

    private static Logger m_logger = DataBridgeLoger.getLogger(
            MessageFieldsFilter.class.getName() );

    private static String DEFINITION_FILE_NAME = "mpi-messages.xml";
    private static MessageMappingBean m_messages = null;

    private static SimpleDateFormat m_sdf = new SimpleDateFormat("yyyyMMdd hh:mm:ss");

    private static Map m_parsedMasks = Collections.synchronizedMap( new HashMap() );

    /**
     * Default constructor
     */
    public MessageFieldsFilter()
    {

    }

    /**
     * Initialize message path table and mandatory message fields table
     */
    public static void initMessageTable( String filePath )
    {
        try {
            m_logger.debug("Load from property file");
            String fname;
            if ( filePath != null )
                fname = filePath + File.separator + DEFINITION_FILE_NAME;
            else
                fname = DEFINITION_FILE_NAME;
            Document doc = new FileHandler().load( fname );
            MessageMappingBean bean = BeansHelper.messageMappingFromXml( null, doc );
            if ( bean != null )
                m_messages = bean;
            else
                m_logger.warn("Can't extract message definition.");

            m_logger.debug("Finish loading from property file");
        } catch ( Exception e )
        {
            m_logger.warn("Loading property file exception", e);
        }

    }

    /**
     * Extract not defined fields from the message document
     * @param type - message type
     * @param version - message version
     * @param items - message field items
     * @param doc - message document
     */
    public static void extractFields( String type, String version, List items, Document doc )
    {
       if ( doc == null || m_messages == null )
       {
           m_logger.warn("Not message document get or no message mapping definition");
           return;
       }
       m_logger.debug("Enter extractFields.");

       if ( items != null && items.size() > 0 )
       {
           MessageDefinitionBean mdb = m_messages.getMessageDefinition( type, version );
           if ( mdb == null )
           {
               m_logger.debug("No definition for the given message type ["
                              + type + "], version [" + version + "]" );
               return;
           }

           String snode = mdb.getXpath();
           if ( snode == null || snode.trim().equals("") )
           {
               m_logger.warn("Message type [" + type  + "], version [" + version + "] not define messages path ");
               return;
           }

           Element root = XMLUtils.findXPathElement(
                   doc.getDocumentElement(), snode );
           if ( root == null )
           {
               m_logger.warn("Message type [" + type + "][" + snode + "] element not found in the message document");
               return;
           }

           List mlist = mdb.getMandatoryList();
           ArrayList nlist;
           if ( mlist == null || mlist.size() < 1 )
           {
               m_logger.debug("Not mandatory field define for Message type ["
                              + type  + "], version [" + version + "]");
               nlist = new ArrayList();
           }
           else
               nlist = new ArrayList( mlist );

           MessageFieldBean bean;
           for ( Iterator lt = items.iterator(); lt.hasNext(); )
           {
               bean = (MessageFieldBean) lt.next();
               nlist.add( bean.getName() );
           }
           checkNode( "", root, nlist );
       }

       m_logger.debug("Exit extractFields.");
    }

    /**
     * Check the given root's child whether is the ancestor of the given items or
     * is the given items itself
     * @param sroot - root element's xpath from the message type
     * @param root - checked element parent
     * @param items - item list
     */
    private static void checkNode( String sroot, Element root, List items )
    {
        NodeList nlist = root.getChildNodes();
        Node node;
        Element element;
        ArrayList dlist = new ArrayList();
        String snode, spath;
        boolean flag;

        for ( int i = 0; i < nlist.getLength(); i++ )
        {
            node = nlist.item(i);
            if ( node instanceof Element )
            {
                element = (Element) node;
                spath = sroot + "/" + element.getNodeName();
                flag = false;
                for ( Iterator lt = items.iterator(); !flag && lt.hasNext(); )
                {
                    snode = (String)lt.next();
                    if ( snode.charAt(0) != '/' )
                        snode = '/' + snode ;
                    if ( snode.startsWith( spath ) )
                        flag = true;
                }
                if ( !flag )
                    dlist.add( node );
                else
                    checkNode( spath, element, items );
            }
        }

        for ( Iterator lt = dlist.iterator(); lt.hasNext(); )
        {
            node = (Node) lt.next();
            root.removeChild( node );
        }
    }

    /**
     * Encrypt message fileds defined by configuration data
     * @param type - message type
     * @param version - message version
     * @param items - message field items
     * @param doc - XML document
     */
    public static void encryptFields( String type, String version, List items, Document doc )
    {
        if ( doc == null || m_messages == null )
        {
            m_logger.warn("Not message document get or no message mapping definition");
            return ;
        }

        m_logger.debug("Enter encryptFields.");

        if ( items != null && items.size() > 0 )
        {
            MessageDefinitionBean mdb = m_messages.getMessageDefinition( type, version );
            String snode = "";
            if ( mdb == null )
            {
                m_logger.debug("No definition for the given message type ["
                               + type + "], version [" + version + "]" );
            }
            else
                snode = mdb.getXpath();
            if ( snode == null || snode.trim().equals("") )
            {
                m_logger.warn("Message type [" + type + "] not defined in messages path table");
                return ;
            }

            Element root = XMLUtils.findXPathElement(
                    doc.getDocumentElement(), snode );
            if ( root == null )
            {
                m_logger.warn("Message type [" + type + "][" + snode + "] element not found in the message document");
                return ;
            }

            MessageFieldBean bean;
            String value, nvalue;
            String [] eresult;
            Element node;
            String name;
            for ( Iterator lt = items.iterator(); lt.hasNext(); )
            {
                bean = (MessageFieldBean) lt.next();
                if ( bean.isEncryption()
                     && ( bean.getFormat() == null
                     || bean.getFormat().equals("")) )
                {
                    m_logger.debug("Encrypt the field:" +  bean.getName() );
                    name = bean.getName();
                    node = XMLUtils.findXPathElement( root, name );
                    if ( node != null )
                    {
                        value = XMLUtils.getText( node );
                        try {
                            eresult = TripleDESEncrypter.getInstance().encrypt( value );
                            nvalue = eresult[0]
                                   +  TripleDESEncrypter.CIPHER_TEXT_IV_DELIMITER
                                   + eresult[1];
                            XMLUtils.setNodeText( node, nvalue );
                        } catch ( Exception e )
                        {
                            m_logger.warn("Encryption field [" + name + "] failed",
                                    e);
                        }
                    }
                }
            }
        }

        m_logger.debug("Exit encryptFields.");

        return ;
    }

    /**
     * Mask message fileds defined by configuration data.
     * This support the following rules:
     * <ul>
     * <li> Standard Java message format which is enclosed by { and };
     * <li> Mask format, which can be in the format X{1}#{3}XXX where # means
     * original letter, {3} means occurence number. {0} means any, it only can occurence once
     * in the format. If {0} occure before #, which means count from end, otherwise from front.
     * </ul>
     * @param type - message type
     * @param version - message version
     * @param items - message field items
     * @param doc - XML document
     */
    public static void maskFields( String type, String version, List items, Document doc )
    {
        if ( doc == null || m_messages == null )
        {
            m_logger.warn("Not message document get or no message mapping definition");
            return ;
        }
        m_logger.debug("Enter maskFields.");

        if ( items != null  && items.size() > 0 )
        {
            MessageDefinitionBean mdb = m_messages.getMessageDefinition( type, version );
            String snode = "";
            if ( mdb == null )
            {
                m_logger.debug("No definition for the given message type ["
                               + type + "], version [" + version + "]" );
            }
            else
                snode = mdb.getXpath();
            if ( snode == null || snode.trim().equals("") )
            {
                m_logger.warn("Message type [" + type + "] not defined in messages path table");
                return ;
            }

            Element root = XMLUtils.findXPathElement(
                    doc.getDocumentElement(), snode );
            if ( root == null )
            {
                m_logger.warn("Message type [" + type + "][" + snode + "] element not found in the message document");
                return ;
            }

            MessageFieldBean bean;
            String value, nvalue, fmt, name;
            Element node;
            for ( Iterator lt = items.iterator(); lt.hasNext(); )
            {
                bean = (MessageFieldBean) lt.next();
                fmt = bean.getFormat();
                if ( fmt != null && !fmt.trim().equals("") )
                {
                    m_logger.debug("do formatting:" +  bean.getName());
                    name = bean.getName();
                    node = XMLUtils.findXPathElement( root, name );
                    if ( node == null )
                        continue;

                    value = XMLUtils.getText( node );
                    nvalue = value;
                    fmt = fmt.trim();

                    MaskToken pmask = (MaskToken) m_parsedMasks.get( fmt );
                    if ( pmask == null && ( fmt.startsWith("{") && fmt.endsWith("}") ) )
                    {
                        pmask = parseMessageFormat( fmt );
                        if ( pmask != null )
                            m_parsedMasks.put( fmt, pmask );
                    }

                    MessageFormat mf = null;

                    if ( pmask != null && !pmask.isMaskFlag() )
                        mf = pmask.getJavaMessageFormat();

                    if ( mf != null )
                    {
                        try {
                            Object objs[] = new Object[1];
                            objs[0] = value;
                            switch ( pmask.getMessageObjectType() )
                            {
                                case MaskToken.NUMBER_FMT:
                                    objs[0] = new Double( value );
                                    break;
                                case MaskToken.DATE_FMT:
                                    objs[0] = m_sdf.parse( value );
                                    break;
                            }
                            nvalue = mf.format(  objs );
                        } catch ( Exception e )
                        {
                            e.printStackTrace();
                            m_logger.error("Format error with " + fmt, e);
                        }
                    }
                    else
                    {
                        if ( pmask == null )
                        {
                            pmask = parseMaskFormat( fmt );
                            m_parsedMasks.put( fmt , pmask );
                        }
                        StringBuffer sb = pmask.getParsedArray();
                        int wildPlace = pmask.getWildCharPlace();

                        char lastcc = 0;
                        char cc;
                        char nstr[] = new char[ value.length() ];

                        if ( wildPlace != -1 )
                        {
                            cc = sb.charAt( wildPlace );
                            m_logger.debug("wildchar is " + cc + " place=" +  wildPlace );
                            for ( int i = 0; i < value.length(); i++ )
                                nstr[i] = cc;

                            for ( int i = 0; i < wildPlace && i < value.length(); i++ )
                            {
                                lastcc = sb.charAt( i );
                                if ( lastcc != '#' )
                                    cc = lastcc;
                                else
                                    cc = value.charAt(i);
                                nstr[i] = cc;
                            }

                            for ( int i = sb.length() - 1, k = value.length() - 1;
                                  k > wildPlace && i > wildPlace; i--, k-- )
                            {
                                lastcc = sb.charAt( i );
                                if ( lastcc != '#' )
                                    cc = lastcc;
                                else
                                    cc = value.charAt(k);
                                nstr[k] = cc;
                            }
                        }
                        else
                        {
                            for ( int i = 0; i < value.length(); i++ )
                            {
                                if ( sb.length() <= i )
                                    cc = value.charAt(i);
                                else
                                {
                                    lastcc = sb.charAt( i );
                                    if ( lastcc != '#' )
                                        cc = lastcc;
                                    else
                                        cc = value.charAt(i);
                                }
                                nstr[i] = cc;
                            }
                        }

                        nvalue = new String( nstr );
                    }

                    m_logger.debug("field value from [" +  value + "]  to [" + nvalue + "]" );
                    XMLUtils.setNodeText( node, nvalue );
                }
            }
        }

        m_logger.debug("Exit maskFields.");

        return ;
    }

    /**
     * Encrypt must encrypt fields such as PAN which is not encrypted or masked before
     * by custom defined fields'methods.
     * @param items - fields that have been defined
     * @param doc - XML document
     * @param type - message type
     * @param version - message version
     */
    public static void doMustEncrypt( List items, Document doc,
                                      String type, String version )
    {
        m_logger.debug( "Enter doMustEncrypt.");

        if ( doc == null || m_messages == null )
        {
            m_logger.warn("Not message document get or no message mapping definition");
            return ;
        }

        MessageDefinitionBean mdb = m_messages.getMessageDefinition( type, version );
        String snode = "";
        if ( mdb == null )
        {
            m_logger.debug("No definition for the given message type ["
                           + type + "], version [" + version + "]" );
            return;
        }
        else
            snode = mdb.getXpath();
        if ( snode == null || snode.trim().equals("") )
        {
            m_logger.warn("Message type [" + type + "] not defined in messages path table");
            return ;
        }

        Element root = XMLUtils.findXPathElement(
                doc.getDocumentElement(), snode );

        if ( root == null )
        {
            m_logger.warn("Message type [" + type + "][" + snode + "] element not found in the message document");
            return ;
        }

        List mlist = mdb.getMustEncryptionList();
        if ( mlist == null )
        {
            m_logger.debug("No must encryption fields defined for the given message type ["
                           + type + "], version [" + version + "]" );
            return ;
        }

        String path, value,  nvalue;
        String[] eresult;
        Element node;

        MessageFieldBean bean;
        ArrayList fields = new ArrayList();
        if ( items != null )
        {
            for ( Iterator lt = items.iterator(); lt.hasNext(); )
            {
                bean = (MessageFieldBean) lt.next();
                if ( ( bean.getFormat() != null && !bean.getFormat().trim().equals("") )
                    || bean.isEncryption() )
                    fields.add( bean.getName() );
            }
        }

        for ( Iterator lt = mlist.iterator(); lt.hasNext(); )
        {
            path = (String) lt.next();
            if ( !fields.contains( path ) )
            {
                m_logger.debug("Do must encrypt:" +  path );
                node = XMLUtils.findXPathElement( doc.getDocumentElement(), path );
                if ( node != null )
                {
                    value = XMLUtils.getText( node );

                    try {
                        eresult = TripleDESEncrypter.getInstance().encrypt( value );
                        nvalue = eresult[0]
                               + TripleDESEncrypter.CIPHER_TEXT_IV_DELIMITER
                               + eresult[1];
                        XMLUtils.setNodeText( node, nvalue );
                    } catch ( Exception e )
                    {
                        m_logger.warn("Encryption field [" + path + "] failed",
                                e);
                    }
                }

            }
        }
        m_logger.debug( "Exit doMustEncrypt.");
    }


    /**
     * Parse message field format and construct Java message format instance
     * @param fmt - message field format definition
     * @return - parsed mask token
     */
    public static MaskToken parseMessageFormat( String fmt )
    {

        try {
           fmt = fmt.substring( 1, fmt.length() - 1);
           int sb = fmt.indexOf(",");
           String javaFmt;
           int type = MaskToken.STRING_FMT;
           if ( sb != -1 )
           {
               String ftype = fmt.substring(0, sb );
               String lstr = fmt.substring( sb + 1);
               if ( ftype.trim().equalsIgnoreCase("number") )
               {
                   javaFmt = "{0,number," + lstr + "}";
                   type = MaskToken.NUMBER_FMT;
               }
               else if ( ftype.trim().equalsIgnoreCase("date") )
               {
                   SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd hh:mm:ss");
                   javaFmt = "{0,date," + lstr  + "}";
                   type = MaskToken.DATE_FMT;
               }
               else
               {
                   javaFmt = lstr ;
               }
           }
           else
           {
               javaFmt = fmt ;
           }
           return new MaskToken( new MessageFormat( javaFmt ), type );
       } catch ( Exception e )
       {
           e.printStackTrace();
           m_logger.error("Format error with " + fmt, e);
       }

       return null;
   }

   /**
    * Parse message field format and construct mask string array
    * @param fmt - message field format definition
    * @return - parsed mask token
    */
   public static MaskToken parseMaskFormat( String fmt )
   {
       StringBuffer sb = new StringBuffer();
       char lastcc = 0;
       char cc;
       int ce;
       int num = 1;
       String snum;
       int wildPlace = -1;

       for ( int i = 0; i < fmt.length() ; i++ )
       {
           cc = fmt.charAt( i );
           if ( cc != '{' )
           {
               sb.append( cc );
               lastcc = cc;
           }
           else
           {
               ce = fmt.indexOf( '}', i );
               if ( ce != -1 )
               {
                   try {
                       snum = fmt.substring( i + 1, ce );
                       num = Integer.valueOf( snum ).intValue();
                       } catch ( Exception e )
                       {
                           m_logger.warn( "Invalid format [" + fmt + "]", e );
                           num = 1;
                       }
                       if ( num == 0 && wildPlace == -1 )
                       {
                           if ( i > 0 )
                               wildPlace = sb.length() - 1;
                           else
                               wildPlace = 0;
                       }
                       else
                       {
                           if ( num == 0 )
                           {
                               m_logger.warn("More than one {0} is defined in the format ["
                                       + fmt + "]" );
                               num = 1;
                           }
                           for ( int j = 1; j < num; j++ )
                               sb.append( lastcc );
                       }
                       i = ce;
               }
               else
               {
                   sb.append( cc );
                   lastcc = cc;
               }
           }
       }

       m_logger.debug("field mask string is [" + sb.toString() + "].");
       return new MaskToken( sb, wildPlace );

   }

    /**
     *
     * @return - message mapping bean
     */
    public static MessageMappingBean getMessageMappingBean()
    {
        return m_messages;
    }

    /**
     * Get the message type root element in the message XML DOM tree
     * @param doc - XML dom document
     * @param type - message type
     * @param version - message version
     * @return - root element
     */
    public static Element getMessageTypeRoot( Document doc,
            String type, String version )
    {

        if ( doc == null || m_messages == null )
        {
            m_logger.warn("Not message document get or no message mapping definition");
            return null;
        }

        MessageDefinitionBean mdb = m_messages.getMessageDefinition( type, version );
        String snode = "";
        if ( mdb == null )
        {
            m_logger.debug("No definition for the given message type ["
                           + type + "], version [" + version + "]" );
            return null;
        }
        else
            snode = mdb.getXpath();
        if ( snode == null || snode.trim().equals("") )
        {
            m_logger.warn("Message type [" + type + "] not defined in messages path table");
            return null;
        }

        Element root = XMLUtils.findXPathElement(
                doc.getDocumentElement(), snode );
        if ( root == null )
            m_logger.warn("Message type [" + type + "][" + snode + "] element not found in the message document");

        return root;
    }
}

package com.oncecorp.visa3d.bridge.listening;

import java.util.Iterator;
import java.util.Map;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import javax.jms.Message;

import org.apache.log4j.Logger;
import com.oncecorp.visa3d.bridge.logging.DataBridgeLoger;
import com.oncecorp.visa3d.bridge.beans.ListeningMessageBean;
import com.oncecorp.visa3d.bridge.beans.MessageFieldBean;
import com.oncecorp.visa3d.bridge.beans.MessageMappingBean;

/**
 * <p>Title: ListeningUtils</p>
 * <p>Description: Helper class for Listening Service </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: ONCE Corporation</p>
 * @author Gang Wu ( gwu@oncecorp.com )
 * @version 1.0
 */

public class ListeningUtils
{
    public final static String AUDITING_LISTENER  =  "AuditingListener";
    public final static String PLUGIN_LISTENER    =  "PluginListener";
    public final static String LISTENER    =  "Listener";
    public final static String CHANNEL    =  "Channel";
    public final static String ACTION          = "action";
    public final static String START            = "start";
    public final static String STOP            = "stop";
	public final static String REASON            = "reason";
    public final static String EXCEPTION         = "exception";
    public final static String PLUGIN_CLASS_NOT_INIT         = "pluginClassCannotInstanitiated";
    public final static String INITIALIZE_ERROR         = "initializeError";
    public final static String REGISTER            = "register";
    public final static String UNREGISTER            = "unregister";
    public final static String PLUG_NAME            = "pluginName";
    public final static String CLASS_NAME            = "className";
    public final static String CONFIG_XML            = "configXml";
    public final static String JMS_MERCHANT_PROPERTY = "MerchantID";
    public final static String JMS_MESSAGE_TYPE      = "MessageType";
    public final static String JMS_MESSAGE_VERSION   = "MessageVersion";
    public final static String JMS_MESSAGE_PROTOCOL   = "Protocol";
    public final static String JMS_MESSAGE_TIMESTAMP   = "MessageTimestamp";
    public final static String JMS_ENCRYPTION_MODE   = "EncryptionMode";
    public final static String JMS_ENCRYPTION_IV   = "EncryptionIV";

    private static Logger m_logger = DataBridgeLoger.getLogger(
            ListeningUtils.class.getName() );

    /**
     * Default constructor
     */
    public ListeningUtils()
    {
    }

    /**
     * Extract action string from property list
     * @param props - property list
     * @return - the action string
     */
    public static String getAction( Properties props )
    {
        if ( props != null && props.containsKey(ACTION) )
            return props.getProperty(ACTION);
        return null;
    }

    /**
     * Extract listener name from property list
     * @param props - property list
     * @return - the listener name
     */
    public static String getListener( Properties props )
    {
        if ( props != null && props.containsKey(LISTENER) )
            return props.getProperty(LISTENER);
        return null;
    }

	/**
	 * Extract reason from property list
	 * @param props - property list
	 * @return - the start/stop reason
	 */
	public static String getReason( Properties props )
	{
		if ( props != null && props.containsKey(REASON) )
			return props.getProperty(REASON);
		return "";
	}

    /**
     * Extrace channel name from property list
     * @param props - propery list
     * @return - the channel name
     */
    public static String getChannel( Properties props )
    {
        if ( props != null && props.containsKey(CHANNEL) )
            return props.getProperty(CHANNEL);
        return null;
    }

    /**
     * Extract xml configue string from property list
     * @param props - property list
     * @return - xml configue string
     */
    public static String getConfigXml( Properties props )
    {
        if ( props != null && props.containsKey(CONFIG_XML) )
            return props.getProperty(CONFIG_XML);
        return null;
    }

    /**
     * Extract listener class name from property list
     * @param props - property list
     * @return - listener class name
     */
    public static String getPluginClass( Properties props )
    {
        if ( props != null && props.containsKey(CLASS_NAME) )
            return props.getProperty(CLASS_NAME);
        return null;
    }

    /**
     * Is given action string a stop action?
     * @param action - an action string
     * @return - true or false
     */
    public static boolean isStopAction( String action )
    {
        if ( action != null && action.trim().equalsIgnoreCase(STOP) )
            return true;
        else
            return false;
    }

    /**
     * Is given action string a start action?
     * @param action - an action string
     * @return - true or false
     */
    public static boolean isStartAction( String action )
    {
        if ( action != null && action.trim().equalsIgnoreCase(START) )
            return true;
        else
            return false;
    }

    /**
     * Is given action string a register action?
     * @param action - an action string
     * @return - true or false
     */
    public static boolean isRegisterAction( String action )
    {
        if ( action != null && action.trim().equalsIgnoreCase(REGISTER) )
            return true;
        else
            return false;
    }

    /**
     * The given action should stop the listening thread
     * @param action - an action string
     * @return - true or false
     */
    public static boolean shouldStop( String action )
    {
        if ( action != null &&
          ( action.trim().equalsIgnoreCase( STOP )
          || action.trim().equalsIgnoreCase( UNREGISTER ) ) )
            return true;
        else
            return false;


    }

    /**
     * Is given action string a unregister action?
     * @param action - an action string
     * @return - true or false
     */
    public static boolean isUnregisterAction( String action )
    {
        if ( action != null && action.trim().equalsIgnoreCase(UNREGISTER) )
            return true;
        else
            return false;
    }

    /**
     * Is given listener name a auditing listener?
     * @param listener - a listener name
     * @return - true or false
     */
    public static boolean isAuditingListener( String listener )
    {
        if ( listener != null )
            return listener.equals( AUDITING_LISTENER );

        return false;
    }

    /**
     * Get published JMS related head properties
     * @param message - JMS message
     * @return - all published JMS related head properties
     */
    public static Properties getMessageProperties( Message message )
    {
        Properties props = new Properties();

        try {
            String str = message.getStringProperty( JMS_MERCHANT_PROPERTY );
            if ( str != null )
                props.put( JMS_MERCHANT_PROPERTY, str );
        } catch ( Exception e )
        {
            m_logger.error("Get JMS_MERCHANT_PROPERTY", e);
        }

        try {
            String str = message.getStringProperty( JMS_MESSAGE_TYPE );
            if ( str != null )
                props.put( JMS_MESSAGE_TYPE, str );
        } catch ( Exception e )
        {
            m_logger.error("Get JMS_MESSAGE_TYPE", e);
        }

        try {
            String str = message.getStringProperty( JMS_MESSAGE_VERSION );
            if ( str != null )
                props.put( JMS_MESSAGE_VERSION, str );
        } catch ( Exception e )
        {
            m_logger.error("Get JMS_MESSAGE_VERSION", e);
        }

        try {
            String str = message.getStringProperty( JMS_MESSAGE_PROTOCOL );
            if ( str != null )
                props.put( JMS_MESSAGE_PROTOCOL, str );
        } catch ( Exception e )
        {
            m_logger.error("Get JMS_MESSAGE_PROTOCOL", e);
        }

        try {
            props.put( JMS_MESSAGE_TIMESTAMP, ""+message.getJMSTimestamp() );
        } catch ( Exception e )
        {
            m_logger.error("Get JMS_MESSAGE_TIMESTAMP", e);
        }

        return props;
    }

    /**
     * Iterate through two merchant lists and check whether they are equal
     * @param l1 - first merchant list
     * @param l2 - second merchant list
     * @return - equal or not
     */
    public static boolean merchantListEqual( List l1, List l2 )
    {
        if ( l1 == null && l2 == null )
            return true;
        else if ( l1 == null && l2 != null )
            return false;
        else if ( l1 != null && l2 == null )
            return false;
        else if ( l1.size() != l2.size() )
            return false;

        for ( Iterator lt1 = l1.iterator(); lt1.hasNext(); )
        {
            if ( !l2.contains( lt1.next() ) )
                return false;
        }

        return true;
    }


    /**
     * Iterate through two fields lists and check whether they are equal
     * @param l1 - first field list
     * @param l2 - second field list
     * @return - equal or not
     */
    public static boolean fieldsListEqual( List l1, List l2 )
    {
        MessageFieldBean mfb1, mfb2;

        if ( l1 == null && l2 == null )
            return true;
        else if ( l1 == null && l2 != null )
            return false;
        else if ( l1 != null && l2 == null )
            return false;
        else if ( l1.size() != l2.size() )
            return false;

        String name, format;
        boolean eflag, efound;

        for ( Iterator lt1 = l1.iterator(); lt1.hasNext(); )
        {
            mfb1 = (MessageFieldBean) lt1.next();
            name = mfb1.getName();
            format = mfb1.getFormat();
            eflag = mfb1.isEncryption();

            efound = false;
            for ( Iterator lt2 = l2.iterator(); lt2.hasNext(); )
            {
                mfb2 = (MessageFieldBean) lt2.next();

                if ( !stringEqual( name, mfb2.getName() ) )
                    continue;
                if ( !stringEqual( format, mfb2.getFormat() ) )
                    continue;
                if ( !booleanEqual( eflag, mfb2.isEncryption() ) )
                    continue;

                efound = true;
                break;
            }

            if ( !efound )
                return false;
        }

        return true;
    }

    /**
     * Iterate through two message maps and check whether they are equal
     * @param m1 - first message map
     * @param m2 - second message map
     * @param cflag - whether check fields list
     * @return - equal or not
     */
    public static boolean messageMapEqual( Map m1, Map m2, boolean cflag )
    {

        if ( m1 == null && m2 == null )
            return true;
        else if ( m1 == null && m2 != null )
            return false;
        else if ( m1 != null && m2 == null )
            return false;
        else if ( m1.size() != m2.size() )
            return false;

        String key;
        ListeningMessageBean lmb1, lmb2;

        for ( Iterator lt = m1.keySet().iterator(); lt.hasNext(); )
        {
            key = (String)lt.next();
            if ( !m2.containsKey(key) )
                return false;
            if ( cflag )
            {
                lmb1 = (ListeningMessageBean)m1.get(key);
                lmb2 = (ListeningMessageBean)m2.get(key);
                if ( !fieldsListEqual( lmb1.getFields(), lmb2.getFields() ) )
                    return false;
            }
        }

        return true;
    }

    /**
     * Check two string object equal or not, which could be null
     * @param s1 - first string
     * @param s2 - second string
     * @return - equal or not
     */
    public static boolean stringEqual( String s1, String s2 )
    {
        if ( s1 == null && s2 == null )
            return true;
        else if ( s1 == null && s2 != null )
            return false;
        else if ( s1 != null && s2 == null )
            return false;
        else
            return s1.equals(s2);
    }

    /**
     * Check two boolean variable equal or not
     * @param b1 - first boolean variable
     * @param b2 - second boolean variable
     * @return - equal or not
     */
    public static boolean booleanEqual( boolean b1, boolean b2 )
    {
        if ( ( b1 && b2 ) || ( !b1 && !b2 ) )
            return true;
        else
            return false;
    }

    /**
     * Generate the version list that defined under the same message type
     * @param msgs - message map
     * @param type - message type
     * @return - version list
     */
    public static ArrayList getMessageVersionList( Map msgs, String type )
    {
        ArrayList al = new ArrayList();
        ListeningMessageBean lmb;
        String version;
        for ( Iterator lt = msgs.values().iterator(); lt.hasNext(); )
        {
            lmb = (ListeningMessageBean) lt.next();
            if ( type.equals( lmb.getType() ) )
            {
                version = lmb.getVersion();
                if ( !al.contains( version ) )
                    al.add( version );
            }
        }

        return al;
    }

    /**
     * Create filter properties that used by Plugins, it include a merchant id list
     * and a message map which the key is the message type and value is a version list
     * that defined under that type
     * @param msgs - message map
     * @param mids - merchant ids
     * @return - filter properties structure
     */
    public static Properties createFilterProperties( Map msgs, List mids )
    {
        Properties props = new Properties();
        props.put( JMS_MERCHANT_PROPERTY, mids );
        HashMap map = new HashMap();
        String key;

        for ( Iterator lt = msgs.keySet().iterator(); lt.hasNext(); )
        {
            key = (String) lt.next();
            map.put( key, getMessageVersionList(msgs, key) );
        }

        props.put( JMS_MESSAGE_TYPE, map );

        return props;
    }

    /**
     * Check wheather the given message mapping contain all defined messages, so
     * we can use this check to tune up the JMS selector string.
     * @param msgs - a given messages mapping
     * @return - contain all defined messages or not
     */
    public static boolean containAllMessages( Map msgs )
    {
        MessageMappingBean mmb = MessageFieldsFilter.getMessageMappingBean();

        if ( mmb == null )
            return true;

        Map definedMsgs = mmb.getMessages();

        if ( msgs == null )
            return true;
        else if ( msgs.size() < definedMsgs.size() )
            return false;

        Object key;

        for ( Iterator lt = definedMsgs.keySet().iterator(); lt.hasNext(); )
        {
            key = lt.next();
            if ( !msgs.containsKey( key ) )
                return false;
        }

        m_logger.debug("contain all messages is true.");
        return true;
    }

}

package com.oncecorp.visa3d.bridge.listening;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import org.apache.log4j.Logger;
import com.oncecorp.visa3d.bridge.logging.DataBridgeLoger;

import com.oncecorp.visa3d.bridge.beans.BeansHelper;
import com.oncecorp.visa3d.bridge.beans.MessageFieldBean;
import com.oncecorp.visa3d.bridge.beans.MessageDefinitionBean;
import com.oncecorp.visa3d.bridge.utility.XMLUtils;
import com.oncecorp.visa3d.bridge.security.ShaMessageDigest;

/**
 * <p>Title: MessageColumnDataExtract</p>
 * <p>Description: Extract message data needed by auditing from the original messages </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: ONCE Corporation</p>
 * @author Gang Wu ( gwu@oncecorp.com )
 * @version 1.0
 */

public class MessageColumnDataExtract
{
    public final static String MESSAGE_ID =          "message_id";
    public final static String MESSAGE_STATUS =      "message_status";
    public final static String CARD_NUMBER =         "card_number";
    public final static String CARD_NUMBER_FLAG =    "card_number_flag";
    public final static String TRANSACTION_ID =      "transaction_id";

    public final static String ALL_MESSAGE   =       "ALL";

    private static Hashtable m_message_status = new Hashtable();
    private static Hashtable m_card_number = new Hashtable();
    private static Hashtable m_transaction_id = new Hashtable();

    private static Hashtable m_allColumnDefinitions = new Hashtable();

    static {

        m_message_status.put(
                BeansHelper.getMessageMappingKey("PARes", "1.0.1" ), "TX/status");
        m_message_status.put(
                BeansHelper.getMessageMappingKey("PARes", "1.0.2" ), "TX/status");
        m_message_status.put(
                BeansHelper.getMessageMappingKey("PaymentAuthRes", "1.0" ), "status");
        m_message_status.put(
                BeansHelper.getMessageMappingKey("PaymentAuthRes", "1.1" ), "status");
        m_message_status.put(
                BeansHelper.getMessageMappingKey("VERes", "1.0.1" ), "CH/enrolled");
        m_message_status.put(
                BeansHelper.getMessageMappingKey("VERes", "1.0.2" ), "CH/enrolled");
        m_message_status.put(
                BeansHelper.getMessageMappingKey("PaymentVerifRes", "1.0" ), "enrolled");
        m_allColumnDefinitions.put( MESSAGE_STATUS, m_message_status );

        /**
         * Card number should handle different
         */
        m_card_number.put(
                BeansHelper.getMessageMappingKey("VEReq", "1.0.1" ), "pan");
        m_card_number.put(
                BeansHelper.getMessageMappingKey("VEReq", "1.0.2" ), "pan");
        m_card_number.put(
                BeansHelper.getMessageMappingKey("PARes", "1.0.1" ), "pan");
        m_card_number.put(
                BeansHelper.getMessageMappingKey("PARes", "1.0.2" ), "pan");
        m_card_number.put(
                BeansHelper.getMessageMappingKey("PaymentVerifReq", "1.0" ), "pan");
        m_card_number.put(
                BeansHelper.getMessageMappingKey("PaymentVerifReq", "1.1" ), "pan");
        m_allColumnDefinitions.put( CARD_NUMBER, m_card_number );


        m_transaction_id.put(
                BeansHelper.getMessageMappingKey("PaymentVerifReq", "1.1" ), "transactionID");
        m_transaction_id.put(
                BeansHelper.getMessageMappingKey("PaymentAuthRes", "1.0" ), "transactionID");
        m_transaction_id.put(
                BeansHelper.getMessageMappingKey("PaymentAuthRes", "1.1" ), "transactionID");
        m_allColumnDefinitions.put( TRANSACTION_ID, m_transaction_id );
    }

    private static Logger m_logger = DataBridgeLoger.getLogger(
            MessageColumnDataExtract.class.getName() );

    /**
     * Default constructor
     */
    public MessageColumnDataExtract()
    {
    }

    /**
     * Get given column's XPath for the given message type and version
     * @param tbl - the column XPath defintion table
     * @param type - message type
     * @param version - message version
     * @return - the XPath of a given column field under the given type and version
     */
    public static String getColumnDefinitionXpath( Hashtable tbl,
            String type, String version )
    {
        if ( tbl.containsKey( ALL_MESSAGE ) )
            return (String) tbl.get( ALL_MESSAGE );
        else
            return (String) tbl.get(
                    BeansHelper.getMessageMappingKey( type, version) );
    }

    /**
     * Extract the message column needed data before fields operation
     * @param tbl - the properties tbale contain the setting value
     * @param type - message type
     * @param version - message version
     * @param doc - message document
     */
    public static void getMessageColumnData( Properties tbl, String type,
            String version, Document doc )
    {
       m_logger.debug("Enter getMessageColumnData for ["
                      + type + "] [" + version + "]" );
       boolean idFlag = false;
       NodeList nodes = doc.getElementsByTagName("Message");
       if ( nodes != null && nodes.getLength() > 0 ) {
           Element message = (Element)nodes.item(0);
           tbl.put( MESSAGE_ID, message.getAttribute("id") );
           idFlag = true;
       }

       Element root = MessageFieldsFilter.getMessageTypeRoot( doc, type, version );

        if ( root != null )
        {
            if ( !idFlag )
                tbl.put( MESSAGE_ID, root.getAttribute("id") );

            String name = "";
            String key;
            Hashtable dtbl;
            boolean flag;
            for ( Iterator lt = m_allColumnDefinitions.keySet().iterator();
                  lt.hasNext(); )
            {
                key = (String) lt.next();
                dtbl = (Hashtable) m_allColumnDefinitions.get( key );
                name = getColumnDefinitionXpath( dtbl, type, version );
                flag = false;
                if ( name != null )
                {
                    Element node = XMLUtils.findXPathElement( root, name );
                    if ( node != null )
                    {
                        tbl.put( key,  XMLUtils.getText( node ) );
                        flag = true;
                    }
                }

                if ( !flag )
                    tbl.put( key, "" );
            }
        }

        m_logger.debug("Leave getMessageColumnData for ["
                       + type + "] [" + version + "]" );
    }

    /**
     * Set up card number and its flag from the message document
     * @param tbl - the properties table to set attribute
     * @param type - message type
     * @param version - message version
     * @param doc - message body document after message fields operation
     * @param fields - message fields definition list
     */
    public static void checkCardNumberField( Properties tbl, String type, String version,
            Document doc, List fields )
    {

        m_logger.debug("Enter checkCardNumberField for ["
                       + type + "] [" + version + "]" );

        String card_number = tbl.getProperty( CARD_NUMBER );

        /**
         * Set default value
         */
        tbl.put( CARD_NUMBER, "" );
        tbl.put( CARD_NUMBER_FLAG, ""+BeansHelper.NONE_FLAG );

        Element root = MessageFieldsFilter.getMessageTypeRoot( doc, type, version );

        if ( root != null )
        {
            String name = getColumnDefinitionXpath( m_card_number, type, version );
            String cardValue = null;

            if ( name != null )
            {
                Element node = XMLUtils.findXPathElement( root, name );
                if ( node != null )
                {
                    cardValue = XMLUtils.getText( node ) ;
                }
            }

            if ( cardValue != null )
            {

                MessageFieldBean mfb;
                MessageDefinitionBean mdb = MessageFieldsFilter
                        .getMessageMappingBean()
                        .getMessageDefinition( type, version );
                List mlist = mdb.getMandatoryList();
                boolean isEncrypted = false;

                if ( mlist.contains( name ) )
                {
                    tbl.put( CARD_NUMBER_FLAG, ""+BeansHelper.ENCRYPTION_FLAG );
                    isEncrypted = true;
                }
                else
                    tbl.put( CARD_NUMBER_FLAG, ""+BeansHelper.PLAIN_FLAG );
                if ( fields != null )
                {
                    boolean foundFlag = false;

                    for ( Iterator lt = fields.iterator(); !foundFlag && lt.hasNext() ; )
                    {
                        mfb = (MessageFieldBean) lt.next();
                        if ( mfb.getName().trim().equalsIgnoreCase( name.trim() ) )
                        {
                           if ( mfb.getFormat() != null &&
                                      !mfb.getFormat().trim().equals("") )
                           {
                                tbl.put( CARD_NUMBER_FLAG, ""+BeansHelper.MASK_FLAG );
                                isEncrypted = false;
                           }
                            else if ( mfb.isEncryption() )
                            {
                                tbl.put( CARD_NUMBER_FLAG, ""+BeansHelper.ENCRYPTION_FLAG);
                                isEncrypted = true;
                            }

                            foundFlag = true;
                        }
                    }
                }

                if ( !isEncrypted )
                    tbl.put( CARD_NUMBER, cardValue );
                else
                {
                    try {
                        tbl.put( CARD_NUMBER, ShaMessageDigest.digestString( card_number ) );
                    } catch ( Exception e )
                    {
                        m_logger.debug("Error during message digest.", e);
                        tbl.put( CARD_NUMBER, "" );
                    }
                }
            }

            m_logger.debug("Leave checkCardNumberField for ["
                          + type + "] [" + version + "]" );
       }
    }

}

package com.oncecorp.visa3d.bridge.listening;

import org.apache.log4j.Logger;
import com.oncecorp.visa3d.bridge.logging.DataBridgeLoger;

import java.util.Timer;
import java.util.TimerTask;

/**
 * <p>Title: TimerService </p>
 * <p>Description: Provide time service to all timer listener, which is mainly
 * used to notify the plugin listener to sweep out the unfinished waiting transaction.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: ONCE Corporation</p>
 * @author Gang Wu ( gwu@oncecorp.com )
 * @version 1.0
 */

public class TimerService
{
    private long interval = 3 * 60;
    private boolean running = false;
    private Timer   m_timer = null;

    private static Logger m_logger = DataBridgeLoger.getLogger(
            TimerService.class.getName() );

    private static TimerService m_instance = new TimerService();

    /**
     * Default constructor
     */
    private TimerService()
    {
        super();
    }

    /**
     * The Singleton pattern calling method to get the service instance
     * @return - timer service instance
     */
    public static TimerService getInstance()
    {
        return m_instance;
    }

    /**
    *
    * @return - the long value of interval in minute.
    */
    synchronized public long getInterval(){
        return interval;
    }

    /**
    *
    * @param aInterval - the new value for interval in minute
    */
    synchronized public void setInterval(long aInterval){
        interval = aInterval ;
        if ( m_timer != null )
        {
            stopService();
            startService();
        }
    }


    /**
    *
    * @return - running status.
    */
    public boolean isRunning(){
        return running;
    }

    /**
     * Start the timer service
     */
    public void startService()
    {
        m_logger.debug("Enter start timer service.");
        if ( !isRunning() )
        {
            try {
                m_timer = new Timer( true );

                m_timer.scheduleAtFixedRate( new PluginTimerTask(),
                        getInterval()  * 60 * 1000,
                        getInterval()  * 60 * 1000);
            } catch ( Exception e )
            {
                m_logger.warn("Exception when reschedule the timer.", e);
            }
            running = true;
        }

        m_logger.debug("Exit start timer service.");

    }

    /**
     * Stop the timer service
     */
    public void stopService()
    {
        m_logger.debug("Enter stop timer service.");
        if ( isRunning() )
        {
            m_timer.cancel();
            m_timer = null;
            running = false;
        }

        m_logger.debug("Exit stop timer service.");


    }

    /**
     *
     * <p>Title: PluginTimerTask</p>
     * <p>Description: Inner class implement Timer Task</p>
     * <p>Copyright: Copyright (c) ONCE Corporation 2002</p>
     * <p>Company: ONCE Corporation</p>
     * @author Gang Wu ( gwu@oncecorp.com )
     * @version 1.0
     */
    static class PluginTimerTask extends TimerTask
    {
        /**
         * Default constructor
         */
        public PluginTimerTask()
        {
            super();
        }

