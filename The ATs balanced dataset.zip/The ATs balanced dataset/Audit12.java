import java.rmi.*;

import com.adventnet.security.audit.*;

import com.adventnet.nms.security.audit.*;

public class CustomAuditAPIImpl extends NmsAuditAPI

{

   public CustomAuditAPIImpl() throws RemoteException

   {

        super();

    }

    public void audit(String userName, Properties auditProp) throws RemoteException, AuditException

    {

        //user code begin//

        //user code end//

        super.audit(userName, auditProp);

    }

}AuditAPI authAudit = (AuditAPI) NmsUtil.getAPI("NmsAuditAPI");

Properties p = new Properties();

p.setProperty("operation", "<Operation Name>");

p.setProperty("category", "<Category>");

p.setProperty("auditedObj", "<Audited Object>");

p.setProperty("CUSTOM_PROPERTY", "<VALUE OF CUSTOM_PROPERTY>");

authAudit.audit("<User Name>", p);
  void 	audit(java.lang.String userName, java.util.Properties auditProp)
          Method used to do audit when a user performs certain operations.
 void 	clearAudit(java.lang.String userName, java.util.Properties auditProp)
          Method used to clear the previous audit trials.
 int 	getAuditLevel()
          Method to get the audit level.
 java.util.Vector 	getAuditTrails(java.lang.String user, java.util.Properties auditProp)
          Method used to get all the audit trials logged before, based on the given parameters of audit.
 void 	init(java.lang.Object obj)
          Method that performs initialization, if required.
 void 	setAuditLevel(int level)
          Method to set the audit level.