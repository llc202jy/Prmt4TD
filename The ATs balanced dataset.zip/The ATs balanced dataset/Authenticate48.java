 * Describes the kerberos authentication properties stored within the <kerberos> block of the current configuration.
 * 
 * @author dward
 */
public class KerberosConfigElement extends ConfigElementAdapter
{
    private static final long serialVersionUID = 4178518406841891833L;

    /** The password. */
    private String password;

    /** The realm. */
    private String realm;

    /** The Service Principal Name to use on the endpoint. This must be like: HTTP/host.name@REALM */
    private String endpointSPN;

    /** JAAS login configuration entry name. */
    private String loginEntryName;

    /**
     * Constructs a new Kerberos Config Element.
     */
    public KerberosConfigElement()
    {
        super("kerberos");
    }

    /*
     * (non-Javadoc)
     * @see
     * org.springframework.extensions.surf.config.element.ConfigElementAdapter#combine(org.springframework.extensions
     * .surf.config.ConfigElement)
     */
    public ConfigElement combine(ConfigElement element)
    {
        KerberosConfigElement configElement = (KerberosConfigElement) element;

        // new combined element
        KerberosConfigElement combinedElement = new KerberosConfigElement();

        combinedElement.password = configElement.password == null ? this.password : configElement.password;
        combinedElement.realm = configElement.realm == null ? this.realm : configElement.realm;
        combinedElement.endpointSPN = configElement.endpointSPN == null ? this.endpointSPN : configElement.endpointSPN;
        combinedElement.loginEntryName = configElement.loginEntryName == null ? this.loginEntryName
                : configElement.loginEntryName;

        // return the combined element
        return combinedElement;
    }

    /**
     * Gets the password.
     * 
     * @return the password
     */
    public String getPassword()
    {
        return password;
    }

    /**
     * Gets the realm.
     * 
     * @return the realm
     */
    public String getRealm()
    {
        return realm;
    }

    /**
     * Gets the Service Principal Name to use on the endpoint. This must be like: HTTP/host.name@REALM.
     * 
     * @return the endpoint SPN
     */
    public String getEndpointSPN()
    {
        return endpointSPN;
    }

    /**
     * Gets the JAAS login configuration entry name.
     * 
     * @return the login entry name
     */
    public String getLoginEntryName()
    {
        return loginEntryName == null ? "ShareHTTP" : loginEntryName;
    }

    /**
     * Constructs a new instance from an XML Element.
     * 
     * @param elem
     *            the XML element
     * @return the Kerberos configuration element
     */
    protected static KerberosConfigElement newInstance(Element elem)
    {
        KerberosConfigElement configElement = new KerberosConfigElement();

        String password = elem.elementTextTrim("password");
        if (password != null && password.length() > 0)
        {
            configElement.password = password;
        }

        String realm = elem.elementTextTrim("realm");
        if (realm != null && realm.length() > 0)
        {
            configElement.realm = realm;
        }

        String endpointSPN = elem.elementTextTrim("endpoint-spn");
        if (endpointSPN != null && endpointSPN.length() > 0)
        {
            configElement.endpointSPN = endpointSPN;
        }

        String loginEntryName = elem.elementTextTrim("config-entry");
        if (loginEntryName != null && loginEntryName.length() > 0)
        {
            configElement.loginEntryName = loginEntryName;
        }

        return configElement;
    }
}