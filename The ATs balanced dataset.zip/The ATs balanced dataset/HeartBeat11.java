/**
 * An object implementing this interface provides methods to detect failed active objects
 * by sending heartbeat messages. An internal thread can be started so as to periodically
 * test a set of active objects.
 * This server is an RMI object.
 * @author The ProActive Team
 * @since ProActive 2.2
 */
public interface FaultDetector extends Remote {

    /**
     * This value is return by an alive and reachable active object that receive a
     * heartbeat message.
     */
    public static final Integer OK = new Integer(0);

    /**
     * This value is return by a dead but reachable active object that receive a
     * heartbeat message.
     */
    public static final Integer IS_DEAD = new Integer(1);

    /**
     * The fault detector test the reachability of the active object body by sending
     * a heartbeat message to body.
     * @param body the tested active object
     * @return true if body is unreachable, false otherwise
     * @throws RemoteException
     */
    public boolean isUnreachable(UniversalBody body) throws RemoteException;

    /**
     * Start the tread that periodically test the reachability of objects that are registred in
     * the location server ls. If a failure is detected, the recovery process must be noticed.

     * @throws RemoteException
     */
    public void startFailureDetector() throws RemoteException;

    /**
     * Temporarily suspend the failure detector thread.
     * @throws RemoteException
     */
    public void suspendFailureDetector() throws RemoteException;

    /**
     * Stop the the failure detector thread.
     * @throws RemoteException
     */
    public void stopFailureDetector() throws RemoteException;

    /**
     * Force a failure detection even if the failure detector thread is waiting.
     * @throws RemoteException
     */
    public void forceDetection() throws RemoteException;

    /**
     * Reinit the state of the fault detector
     */
    public void initialize() throws RemoteException;
}
/**
 * An implementation of the FaultDetector
 * @author The ProActive Team
 */
public class FaultDetectorImpl implements FaultDetector {
    //logger
    protected static Logger logger = ProActiveLogger.getLogger(Loggers.FAULT_TOLERANCE);

    // global server
    private FTServer server;

    // detection thread
    private FaultDetectorThread fdt;

    // static heartbeat message
    private static final Heartbeat hbe = new Heartbeat();

    // detection period
    private long faultDetectionPeriod;

    /**
     *
     */
    public FaultDetectorImpl(FTServer server, long faultDetectPeriod) {
        this.faultDetectionPeriod = faultDetectPeriod;
        this.server = server;
        this.fdt = new FaultDetectorThread();
    }

    /**
     * @see org.objectweb.proactive.core.body.ft.servers.faultdetection.FaultDetector#isUnreachable(org.objectweb.proactive.core.body.UniversalBody)
     */
    public boolean isUnreachable(UniversalBody body) throws RemoteException {
        Object res = null;
        try {
            res = body.receiveFTMessage(FaultDetectorImpl.hbe);
        } catch (Exception e) {
            // object is unreachable
            return true;
        }
        if (res.equals(FaultDetector.OK)) {
            // object is OK
            return false;
        } else {
            // object is dead
            return true;
        }
    }

    /**
     * @see org.objectweb.proactive.core.body.ft.servers.faultdetection.FaultDetector#startFailureDetector()
     */
    public void startFailureDetector() throws RemoteException {
        this.fdt.start();
    }

    /**
     * @see org.objectweb.proactive.core.body.ft.servers.faultdetection.FaultDetector#suspendFailureDetector()
     */
    public void suspendFailureDetector() throws RemoteException {
        throw new NotImplementedException();
    }

    /**
     * @see org.objectweb.proactive.core.body.ft.servers.faultdetection.FaultDetector#stopFailureDetector()
     */
    public void stopFailureDetector() throws RemoteException {
        throw new NotImplementedException();
    }

    /**
     * @see org.objectweb.proactive.core.body.ft.servers.faultdetection.FaultDetector#forceDetection()
     */
    public void forceDetection() throws RemoteException {
        this.fdt.wakeUp();
    }

    /*
     * Thread for fault detection. One unique thread scans all active objects
     * @author The ProActive Team
     */
    private class FaultDetectorThread extends Thread {
        private boolean kill;
        private boolean wakeUpCalled;

        public FaultDetectorThread() {
            this.kill = false;
            this.wakeUpCalled = false;
            this.setName("FaultDetectorThread");
        }

        public synchronized void wakeUp() {
            notifyAll();
            this.wakeUpCalled = true;
        }

        public synchronized void killMe() {
            this.kill = true;
            notifyAll();
        }

        public synchronized void pause() {
            try {
                this.wakeUpCalled = false;
                this.wait(FaultDetectorImpl.this.faultDetectionPeriod);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            while (true) {
                try {
                    if (kill) {
                        break;
                    }

                    //synchronized (FaultDetectorImpl.this.server){
                    List<UniversalBody> al = FaultDetectorImpl.this.server.getAllLocations();
                    Iterator<UniversalBody> it = al.iterator();
                    logger.info("[FAULT DETECTOR] Scanning " + al.size() + " objects ...");
                    while (it.hasNext()) {
                        if (kill) {
                            break;
                        }
                        if (wakeUpCalled) {
                            // a detection is forced, restart...
                            it = al.iterator();
                            this.wakeUpCalled = false;
                        }
                        UniversalBody current = (it.next());
                        if (FaultDetectorImpl.this.server.isUnreachable(current)) {
                            FaultDetectorImpl.this.server.failureDetected(current.getID());
                            // other failures may be detected by the recoveryProcess
                            break;
                        }
                    }
                    logger.info("[FAULT DETECTOR] End scanning.");
                    if (kill) {
                        break;
                    }
                    this.pause();
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @see org.objectweb.proactive.core.body.ft.servers.faultdetection.FaultDetector#initialize()
     */
    public void initialize() throws RemoteException {
        this.fdt.killMe();
        this.fdt = new FaultDetectorThread();
    }
}