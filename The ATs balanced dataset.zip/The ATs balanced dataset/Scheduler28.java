namespace SocializeIt.Web.Controllers
{
	public class MaintainerController : Controller
	{
		IPrincipalFactory principalFactory;
		IScheduler scheduler;

		public MaintainerController(IPrincipalFactory principalFactory, IScheduler scheduler)
		{
			this.principalFactory = principalFactory;
			this.scheduler = scheduler;
		}

		public void Cron()
		{
			Thread.CurrentPrincipal = principalFactory.CreateImporterPrincipal();
			Thread.CurrentThread.Priority = ThreadPriority.Lowest;

			Response.ContentType = "text/plain";
			Response.Buffer = false;
			Response.BufferOutput = false;
			scheduler.Execute(Response.Output);
			HttpContext.Response.End();
		}
	}
}