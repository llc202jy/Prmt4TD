public class HeartbeatSender implements Runnable
{
	HeartbeatServerReader hsr;
	private boolean abort = false;
	TheraThread thread;
/**
 * HeartbeatSender constructor comment.
 */
public HeartbeatSender(HeartbeatServerReader hsr)
{
	this.hsr = hsr;
}
/**
 * Insert the method's description here.
 */
public void launch()
{
	int id = Verify.generateID();
	String name = hsr.getServer().getName() + " HB sender " + id;
	thread = new TheraThread(this, name, hsr.getContext());
	thread.start();
}
/**
 * run method comment.
 */
public void run() {
	int interval = hsr.hbServer.getIntervalms();
	int failures = hsr.hbServer.getFailures();
	while (!abort) {
		try {
			Thread.sleep(interval);
		}
		catch (InterruptedException ie) {
			return;
		}
		hsr.failure();
		if (hsr.getFailedCount() > failures) {
			((External) hsr.hbServer).log(
				"log.tcp.heartbeat",
				"Heartbeat failures exceeded limit.");
			return;
		}
		sendHeartbeat();
		((External) hsr.hbServer).log("log.tcp.heartbeat", "HB sent.");
	}
}
/**
 * Insert the method's description here.
 */
protected void sendHeartbeat()
{
	hsr.send(new StreamMessage("", StreamMessage.CMD_HB));
}
/**
 * Insert the method's description here.
 */
public void stop()
{
	abort = true;
	thread.interrupt();
	try
	{
		thread.join();
	} catch (InterruptedException ie)
	{
	}
}
}

 */
public abstract class HeartbeatServerReader extends MultiServerReader
{
	HeartbeatServer hbServer;
	private int failures;
	private HeartbeatSender sender;
/**
 * HeartbeatServerReader constructor comment.
 * @param server thera.framework.Server
 */
public HeartbeatServerReader(Server server, HeartbeatServer hbServer)
{
	super(server);
	this.hbServer = hbServer;
	sender = null;
}
/**
 * Insert the method's description here.
 */
public void failure()
{
	failures++;
}
/**
 * Insert the method's description here.
 * @return int
 */

 @author: Ivo Maixner
 */
public class HeartbeatServiceTimer extends Timer
{
	HeartbeatService svc;
	int retryDelay;
/**
 * HeartbeatSender constructor comment.
 */
public HeartbeatServiceTimer(HeartbeatService svc)
{
	this.svc = svc;
}
/**
 * expired method comment.
 */
protected void expired()
{
	svc.log("log.tcp.heartbeat", "Heartbeat timeout expired.");
	svc.setError();
	try
	{
		Thread.sleep(retryDelay);
	} catch (InterruptedException ie)
	{
	}
}
/**
 * run method comment.
 */
public void run()
{
	int timeout = svc.getTimeout();
	retryDelay = svc.getRetryDelay();
	try
	{
		Thread.sleep(timeout);
	} catch (InterruptedException ie)
	{
		return;
	}
	expired();
}
}

public int getFailedCount()
{
	return failures;
}
/**
 * Insert the method's description here.
 * @return java.lang.String
 */
public StreamMessage receive()
{
	failures = 0;
	StreamMessage msg;
	startSender();
	while (true)
	{
		msg = super.receive();
		if (null == msg || msg.CMD_MSG == msg.command)
		{
			sender.stop();
			return msg;
		}
		if (msg.CMD_HB != msg.command)
			throw new TheraRuntimeException("Command not supported: " + msg.command, this);
		failures = 0;
	}
}
/**
 * Insert the method's description here.
 */
public void startSender()
{
	sender = new HeartbeatSender(this);
	sender.launch();
}
}
\protected StreamMessage handleMessage(StreamMessage msg)
{
	msg.verifyCommand();
	switch (msg.command)
	{
		case StreamMessage.CMD_HB :
			replyHeartbeat();
			return null;
		case StreamMessage.CMD_MSG :
			return msg;
		default :
			throw new TheraRuntimeException("Command not supported: " + msg.command, this);
	}
}
/**
 * receive method comment.
 */
public Object receive()
{
	while (true)
	{
		Object obj = receiveOnTime();
		if (null == obj)
				continue;
		if (obj instanceof StreamMessage)
		{
			StreamMessage msg = handleMessage((StreamMessage) obj);
			if (null != msg)
				return msg;
		} else
			throw new TheraRuntimeException("Received unsupported: " + obj.getClass(), this);
	}
}
 */
protected synchronized Object receiveOnTime()
{
	Object obj = null;
	startTimer();
	try
	{
		obj = super.receive();
	} catch (ServiceNotAccessibleException snae)
	{
		timer.join();
	} finally
	{
		timer.stop();
	}
	return obj;
}
/**
 * Insert the method's description here.
 */
protected void replyHeartbeat()
{
 	log("log.tcp.heartbeat", "Replying HB.");
	MessageOutputStream mos = new MessageOutputStream(getOS());
	try
	{
		mos.write(new StreamMessage("", StreamMessage.CMD_HB));
	} catch (IOException ioe)
	{
		setError();
	}
}
/*