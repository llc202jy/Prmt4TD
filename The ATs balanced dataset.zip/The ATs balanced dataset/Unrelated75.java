
	public static void setRelationshipId(Object mainObj, Object dependentObj) throws Exception{
		String sqlName = getSQLName(mainObj.getClass());
		for(Field field : dependentObj.getClass().getDeclaredFields()){
			if(field.getAnnotation(RelationshipKey.class) != null && ((RelationshipKey)field.getAnnotation(RelationshipKey.class)).value().equals(sqlName)){
				String methodName = NameUtils.propertyToSetter(field.getName());
				LoopMethod:
					for(Method method : dependentObj.getClass().getMethods())
						if(method.getName().equals(methodName)){
							method.invoke(dependentObj,AnnotationReader.getId(mainObj));
							break LoopMethod;
						}
			}
		}	
	}

	public static String getIdProperty(Class beanClass) {
		// Enchendo lista com todos os campos e m?todos
		List<Field> fields = new ArrayList<Field>();
		List<Method> methods = new ArrayList<Method>();
		Class currentClass = beanClass;
		while (currentClass != Object.class) {
			Collections.addAll(fields, currentClass.getDeclaredFields());
			Collections.addAll(methods, currentClass.getDeclaredMethods());
			currentClass = currentClass.getSuperclass();
		}
		// Procurando por fields com annotations
		for (Field field : fields) {
			for (Annotation annotation : field.getDeclaredAnnotations()) {
				if (annotation.annotationType().getSimpleName().equals("Id")) {
					return field.getName();
				}
			}
		}
	
		// Procurando m?todos get e set com annotations
		for (Method method : methods) {
			if (method.getName().startsWith("get")
					|| method.getName().startsWith("set")) {
				for (Annotation annotation : method.getDeclaredAnnotations()) {
					if (annotation.annotationType().getSimpleName().equals("Id")) {
						return NameUtils.acessorToProperty(method.getName());
					}
				}
			}
		}package org.esfinge.session;

import java.rmi.RemoteException;
import java.util.List;

import javax.ejb.EJBException;
import javax.ejb.SessionContext;

import org.esfinge.business.factory.BusinessFactory;
import org.esfinge.business.interf.CRUDService;
import org.esfinge.domain.DomainObject;
import org.esfinge.exception.ApplicationException;



/**
 * <!-- begin-xdoclet-definition --> 
 * @ejb.bean name="CRUD"	
 *           description="Um servi?o geral para cadastros"
 *           display-name="CRUD"
 *           jndi-name="CRUD"
 *           type="Stateless" 
 *           transaction-type="Container"
 * 
 * <!-- end-xdoclet-definition -->
 */ 

public class CRUDBean implements javax.ejb.SessionBean {

	private CRUDService crudBusiness; 
	private SessionContext context;
	
	public void setSessionContext(SessionContext context) throws EJBException, RemoteException {
		this.context = context;		
	}

	/** 
	 * <!-- begin-xdoclet-definition --> 
	 * @ejb.create-method view-type="remote"
	 * <!-- end-xdoclet-definition --> 
	 */ 
	public void ejbCreate() {
		try {
			Class.forName("org.esfinge.init.SystemInit");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		crudBusiness = BusinessFactory.getFactory().getCRUDService();
	}

	  /** 
	   * <!-- begin-xdoclet-definition --> 
	   * @ejb.interface-method view-type="remote"
	   * @ejb.transaction type = "Required"
	   * <!-- end-xdoclet-definition --> 
	   */
	  public Object getObjById(Object obj) throws ApplicationException{
		  try {
			return crudBusiness.getObjById(obj);
		} catch (ApplicationException e) {
			if(e.isRollbackTransaction())
				context.setRollbackOnly();
			throw e;
		} 
	  }
		
		/** 
		 * <!-- begin-xdoclet-definition --> 
		 * @ejb.interface-method view-type="remote"
		 * @ejb.transaction type = "Required"
		 * <!-- end-xdoclet-definition --> 
		 */
		public Object getCompleteObjById(Object obj) throws ApplicationException{
			try {
				return crudBusiness.getCompleteObjById(obj);
			} catch (ApplicationException e) {
				if(e.isRollbackTransaction())
					context.setRollbackOnly();
				throw e;
			} 
		}
		
		/** 
		 * <!-- begin-xdoclet-definition --> 
		 * @throws ApplicationException 
		 * @ejb.interface-method view-type="remote"
		 * @ejb.transaction type = "Required"
		 * <!-- end-xdoclet-definition --> 
		 */
		public Object insert(Object obj) throws ApplicationException {
			try {
				return crudBusiness.insert(obj);
			} catch (ApplicationException e) {
				if(e.isRollbackTransaction())
					context.setRollbackOnly();
				throw e;
			}
		}
		
		/** 
		 * <!-- begin-xdoclet-definition --> 
		 * @ejb.interface-method view-type="remote"
		 * @ejb.transaction type = "Required"
		 * <!-- end-xdoclet-definition --> 
		 */
		public void update(Object obj) throws ApplicationException {
			try {
				crudBusiness.update(obj);
			} catch (ApplicationException e) {
				if(e.isRollbackTransaction())
					context.setRollbackOnly();
				throw e;
			}
		}
		
		/** 
		 * <!-- begin-xdoclet-definition --> 
		 * @ejb.interface-method view-type="remote"
		 * @ejb.transaction type = "Required"
		 * <!-- end-xdoclet-definition --> 
		 */
		public void delete(Object obj) throws ApplicationException{
			try {
				crudBusiness.delete(obj);
			} catch (ApplicationException e) {
				if(e.isRollbackTransaction())
					context.setRollbackOnly();
				throw e;
			}
		}
		
		/** 
		 * <!-- begin-xdoclet-definition --> 
		 * @ejb.interface-method view-type="remote"
		 * @ejb.transaction type = "Required"
		 * <!-- end-xdoclet-definition --> 
		 */
		public List getList(Object obj) throws ApplicationException{
			try {
				return crudBusiness.getList(obj);
			} catch (ApplicationException e) {
				if(e.isRollbackTransaction())
					context.setRollbackOnly();
				throw e;
			} 
		}
		
		/** 
		 * <!-- begin-xdoclet-definition --> 
		 * @ejb.interface-method view-type="remote"
		 * @ejb.transaction type = "Required"
		 * <!-- end-xdoclet-definition --> 
		 */
		