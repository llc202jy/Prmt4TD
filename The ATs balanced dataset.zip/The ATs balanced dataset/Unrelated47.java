package amalgam.server;

import java.sql.*;
import java.util.Enumeration;
import amalgam.util.LoggingProxy;
import amalgam.interfaces.ClientServerCommunication;
import amalgam.util.*;

public class ServerDataManager implements ClientServerCommunication{
  private Connection conn;
  private ConnectionManager conMan;
  protected LoggingProxy logProxy;
  public void setConnectionManager(ConnectionManager _cm) throws Exception{
    conMan = _cm;
    conn = conMan.getConnection();
    resetDataBase();
  }

  private void validateConnection() throws Exception{
    conn = conMan.getConnection();
  }

  private void resetDataBase(){
    PreparedStatement cleanClients = null;
    PreparedStatement cleanClienModules = null;
    PreparedStatement cleanArgs = null;
    try {
      logProxy.log("Cleaning database client and clientmodules tables");
      validateConnection();
      cleanClients = conn.prepareStatement("delete"
                +" from"
                +" clients");

      cleanClienModules = conn.prepareStatement("delete"
                +" from"
                +" clientmodules");
      cleanArgs = conn.prepareStatement("delete"
                +" from"
                +" arguements");
      cleanClients.executeUpdate();
      cleanClienModules.executeUpdate();
      cleanArgs.executeUpdate();

    } catch (Exception ex) {
      logProxy.log(ex);
    } finally {
      try {cleanClients.close();} catch (Exception ex) {}
      try {cleanClienModules.close();} catch (Exception ex) {}
      try {cleanArgs.close();} catch (Exception ex) {}
    }
  }

  public void deleteClient(String clientName, int threadID){
    PreparedStatement select = null;
    PreparedStatement remove = null;
    PreparedStatement removeMods = null;
    PreparedStatement removeArgs = null;
    ResultSet rset = null;
    try {
      validateConnection();

      select = conn.prepareStatement("select"
                +" clientid"
                +" from"
                +" clients"
                +" where"
                +" clientname = ?"
                +" and threadid = ?");
      select.setString(1,clientName);
      select.setInt(2,threadID);
      rset = select.executeQuery();
      if(rset.next()){
        remove = conn.prepareStatement("delete"
               +" from"
               +" clients"
               +" where threadid = ?");

        removeMods = conn.prepareStatement("delete"
               +" from"
               +" clientmodules"
               +" where threadid = ?");
        removeArgs = conn.prepareStatement("delete"
               +" from"
               +" arguements"
               +" where threadid = ?");
       remove.setInt(1,threadID);
       removeMods.setInt(1,threadID);
       removeArgs.setInt(1,threadID);

       remove.executeUpdate();
       removeMods.executeUpdate();
       removeArgs.executeUpdate();
      }

    } catch (Exception ex) {
      logProxy.log(ex);
    } finally {
      try {select.close();} catch (Exception ex) {}
      try {remove.close();} catch (Exception ex) {}
      try {removeMods.close();} catch (Exception ex) {}
      try {removeArgs.close();} catch (Exception ex) {}
      try {rset.close();} catch (Exception ex) {}
    }
  }


  public int createNewClient(int threadID, String clientName, String clientIP, Enumeration modlist) throws Exception{
      validateConnection();
      PreparedStatement exist = null;
      PreparedStatement insert = null;
      PreparedStatement getClientID = null;
      PreparedStatement insertMod = null;
      PreparedStatement selectModID = null;
      PreparedStatement insertArg = null;
      ResultSet rset = null;
      int result = NACK;
      try {
        validateConnection();
        exist = conn.prepareStatement("select"
                +" clientname"
                +" from"
                +" clients"
                +" where"
                +" clientname = ?");
        insert = conn.prepareStatement("insert"
