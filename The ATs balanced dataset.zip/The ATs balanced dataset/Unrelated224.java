#include <config.h>
#include "Files.hh"

using std::list ;

namespace certi {
namespace rtia {

// ----------------------------------------------------------------------------
//! Returns logical time from first message in TSO list.
void
Queues::nextTsoDate(bool &found, FederationTime &time)
{
    NetworkMessage *msg_buffer ;

    if (tsos.empty()) {
        found = false ;
        time = -1.0 ;
    }
    else {
        msg_buffer = tsos.front();
        found = true ;
        time = msg_buffer->date ;
    }
}

// ----------------------------------------------------------------------------
/*! Give all the commands to the federate (en invoquant les services
  "RTI Initiated" du federe).
*/
NetworkMessage *
Queues::giveCommandMessage(bool &msg_donne, bool &msg_restant)
{
    NetworkMessage *msg ;

    msg_donne = false ;
    msg_restant = false ;

    if (!commands.empty()) {
        // remove from list but keep pointer to execute ExecuterServiceFedere.
        msg = commands.front();
        commands.pop_front();
        msg_donne = true ;

        if (!commands.empty())
            msg_restant = true ;

        return msg ;
    }
    else return 0 ;
}

// ----------------------------------------------------------------------------
//! Give a FIFO message to federate.
NetworkMessage *
Queues::giveFifoMessage(bool &msg_donne, bool &msg_restant)
{
    NetworkMessage *msg_tampon ;

    msg_donne = false ;
    msg_restant = false ;

    if (!fifos.empty()) {
        // remove from list but keep pointer to execute ExecuterServiceFedere.
        msg_tampon = fifos.front();
        fifos.pop_front();
        msg_donne = true ;

        if (!fifos.empty())
            msg_restant = true ;

        return msg_tampon ;
    }
    else return 0 ;
}

// ----------------------------------------------------------------------------
/*! 'heure_logique' is the minimum value between current LBTS and current
  time
*/
NetworkMessage *
Queues::giveTsoMessage(FederationTime heure_logique,
                       bool &msg_donne,
                       bool &msg_restant)
{
    NetworkMessage *buffer_msg = NULL ;

    msg_donne = false ;
    msg_restant = false ;

    if (!tsos.empty()) {
        buffer_msg = tsos.front();
        if (buffer_msg->date <= heure_logique) {
            // remove from list but keep pointer to execute
            // ExecuterServiceFedere.
            tsos.pop_front();
            msg_donne = true ;

            // Test if next TSO message can be sent.
            if (!tsos.empty()) {
                NetworkMessage *buffer_msg2 ;
                buffer_msg2 = tsos.front();

                if (buffer_msg2->date <= heure_logique)
                    msg_restant = true ;
            }
            return buffer_msg ;
        }
        else return 0 ;
    }
    else return 0 ;
}

// ----------------------------------------------------------------------------
/*! Insert a message with a command (ex: requestPause) to the beginning of
  command list.
*/
void
Queues::insertBeginCommand(NetworkMessage *msg)
{
    commands.push_front(msg);
}

// ----------------------------------------------------------------------------
//! Insert a message with a command at the end of command list.
void
Queues::insertLastCommand(NetworkMessage *msg)
{
    commands.push_back(msg);
}

// ----------------------------------------------------------------------------
//! Insert a message to end FIFO list.
void
Queues::insertFifoMessage(NetworkMessage *msg)
{
    fifos.push_back(msg);
}

// ----------------------------------------------------------------------------
