/*
 * $Id: Queue.java,v 1.2 2003/03/20 19:15:21 dchud Exp $
 */

package org.jakedb;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xml.serialize.*;

import org.w3c.dom.*;

import org.apache.log4j.Logger; 

import org.jakedb.formatter.QueueXMLFormatter;


public class Queue
    implements Serializable {

    /** Initialize log4j */
    private static Logger log = Logger.getLogger(Queue.class);

    public static final String STATUS_NEW = "new";
    
    public static final String STATUS_CLAIMED = "claimed";
    
    public static final String STATUS_APPROVED = "approved";
    
    public static final String STATUS_REJECTED = "rejected";
    
    public static final String STATUS_APPLIED = "applied";

    public static final String ACTION_CREATE_RECORD = "create-record";
    
    public static final String ACTION_UPDATE_RECORD = "update-record";
    
    public static final String ACTION_CREATE_RELATIONSHIP = "create-relationship";
    
    public static final String ACTION_UPDATE_RELATIONSHIP = "update-relationship";
    
    private int id;
    private int rtid;
    private int userid;
    private String status;

    private String subjectJakeid;
    private String objectJakeid;
    
    private String action;
    private String actionSummary;
    
    private ArrayList history;
    private ArrayList edits;

    // quick and dirty
    public Queue() {
        log.debug("Creating Queue...");
        setId(-1);
        setRTId(0);
        setUserId(-1);
        setStatus(STATUS_NEW);
        history = new ArrayList();
        edits = new ArrayList();
        actionSummary = "";
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRTId() {
        return rtid;
    }

    public void setRTId(int id) {
        this.rtid = id;
    }

    public int getUserId() { return userid; }
    
    public void setUserId(int id) {
        
        this.userid = id;
        
    }
    
        
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSubjectJakeid() { return subjectJakeid; }
    
    public void setSubjectJakeid(String jakeid) {
        
        if (jakeid != null) {
            this.subjectJakeid = jakeid;
        }
    
    }
    
    public String getObjectJakeid() { return objectJakeid; }
    
    public void setObjectJakeid(String jakeid) {
        
        if (jakeid != null) {
            this.objectJakeid = jakeid;
        }
        
    }

    public String getAction() { return action; }

    public void setAction(String action) {

        if (action == null) {
            
            log.warn("ACTION is null");
            return;
            
        }
        
        if ((ACTION_CREATE_RECORD.equals(action)) ||
            (ACTION_CREATE_RELATIONSHIP.equals(action)) ||
            (ACTION_UPDATE_RECORD.equals(action)) ||
            (ACTION_UPDATE_RELATIONSHIP.equals(action))) {
                
            this.action = action;
            
        } else {
            
            log.warn("incorrect ACTION specified");
            
        }
    
    }

    
    public String getActionSummary() { return actionSummary; }
    
    public void setActionSummary(String summary) {
        
        if (summary != null) {
            this.actionSummary = summary;
        }
        
    }
    
    public void log(String source, String user,
        String date, String action,
        String comment) {

        HashMap event = new HashMap();

        event.put("source", source);
        event.put("user", user);
        event.put("date", date);
        event.put("action", action);
        if (!comment.equals(""))
            event.put("comment", comment);
        history.add(event);
    }

    public Iterator getHistory() {
        return history.iterator();
    }

    
    /**
     * Searches current edit list for a given edit
     *
     * @param edit the edit to search for
     */
    public boolean hasEdit(HashMap edit) {

        if (edit == null) {
            
            return false;
            
        }
        
        HashMap h = null;
        
        Iterator i = editIterator();
        while (i.hasNext()) {
            
            h = (HashMap) i.next();
            
            if (edit.keySet().equals(h.keySet())) {
                
                return true;
                
            }
                
        }
        
        return false;
        
    }
    
    
    /**
     * Simple access to the size of the edit list
     *
     * @return the number of edits made
     */
    public int editSize() { return edits.size(); }
     
     
    
    /**
     * Simple iterator of edits added
     *
     * @return iterator of all existing edits
     */
    public Iterator editIterator() {

        return edits.iterator();

    } // editIterator()
    

    /**
     * Compares two queue updates to determine whether their editing
     * _intent_ is equal, i.e. if they intend to make exactly the same
     * changes.  In other words, they might have different users, log
     * entries, etc., but if the intended action and each individual
     * edit item are the same, they are a duplicate.
     *
     * @param q2 the update to compare this one against
     */
    public boolean editsEqual(Queue q2) {
        
        if (!q2.getAction().equals(getAction())) {
            
import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;


public class User {

    /** Initialize log4j */
    private static Logger log = Logger.getLogger(User.class);
    
    public static final int STATUS_ACTIVE = 1;
    
    public static final int STATUS_INACTIVE = 0;
    
    /** Unique user id */
    private int uid;

    /** User status (see STATUS_*) */
    private int status;

    /** Nickname for this user */
    private String username;
    
    /** Email address for this user */
    private String email;

    /** Password for this user */
    private String password;
    
    /** Real name for this user (first last) */
    private String realname;
    
    /** Temporary registration token for this user */
    private String registerToken;

    /** Date user account was created */
    private Date createdDate;
    
    /** Date user account was last modified */
    private Date modifiedDate;
    
    /** Roles for this user */
    private ArrayList roles;
    
    public User() {}
        
    // default constructor sets minimal default values
    public User(String username, String email) {
        
        setUsername(username);
        setEmail(email);
        setPassword("*");
        setStatus(STATUS_INACTIVE);
        createRegisterToken();
        setCreatedDate(new Date());
        setModifiedDate(new Date());
        
    } // User()


    public int getId() { return uid; }
    public void setId(int id) {
        
        this.uid = id;
        
    } // setUid()
    
    public int getStatus() { return status; }
    public void setStatus(int status) {
        
        if ((status == STATUS_ACTIVE) ||
            (status == STATUS_INACTIVE)) {
                
            this.status = status;
            
        }
        
    } // setStatus()

    public String getUsername() { return username; }
    public void setUsername(String name) {
        
        this.username = name;
        
    } // setUsername()
    
    public String getEmail() { return email; }
    public void setEmail(String email) {
        
        this.email = email;
        
    } // setEmail()

    public String getPassword() { return password; }
    public void setPassword(String password) {
        
        this.password = password;
        
    }
    
    public String getRealName() { return realname; }
    public void setRealName(String name) {
        
        this.realname = name;
        
    } // setRealname()
    
    public String getRegisterToken() { return registerToken; }
    public void setRegisterToken(String token) {
        
        registerToken = token;
        
    } // setRegisterToken()
    
    public void createRegisterToken() {
        
        StringBuffer sb = new StringBuffer();
        Integer i;
        
        while (sb.length() < 32) {

            i = new Integer((int)(Math.random() * 10));
            sb.append(i.toString());
            
        }
        
        setRegisterToken(sb.toString());
        
    } // createRegisterToken()
    
    public Date getCreatedDate() { return createdDate; }
    public void setCreatedDate(Date date) {
        
        createdDate = date;
        
    }
    
    public Date getModifiedDate() { return modifiedDate; }
    public void setModifiedDate(Date date) {
        
        modifiedDate = date;
        
    }

} // User