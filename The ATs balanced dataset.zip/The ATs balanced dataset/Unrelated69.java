                +" into"
                +" clients(threadid, clientname,clientip,onlinetime)"
                +" values(?,?,?,?)");
        exist.setString(1,clientName);
        rset = exist.executeQuery();
        if(!rset.next()){
          rset.close();
          insert.setInt(1, threadID);
          insert.setString(2, clientName);
          insert.setString(3, clientIP);
          insert.setString(4, new java.util.Date().toString());
          insert.executeUpdate();
//          getClientID = conn.prepareStatement("select"
//                                              + " clientid"
//                                              + " from"
//                                              + " clients"
//                                              + " where"
//                                              + " clientname = ?"
//                                              + " and threadid = ?");
//          getClientID.setString(1, clientName);
//          getClientID.setInt(2, threadID);
//          rset = getClientID.executeQuery();
//          rset.next();
//          int clientid = rset.getInt("clientid");
          int clientid = threadID;
          int modid = -1;
          Module mod = null;
          insertMod = conn.prepareStatement("insert"
                     + " into"
                     +" clientmodules(threadid,modulename,displayname,description,moduletype,classname)"
                     + " values(?,?,?,?,?,?)");
          selectModID = conn.prepareStatement("select"
                                              + " moduleid"
                                              + " from"
                                              + " clientmodules"
                                              + " where threadid = ?"
                                              + " and modulename = ?");
          insertArg = conn.prepareStatement("insert"
                                            + " into"
                                            + " arguements(threadid,moduleid,arguement)"
                                            + " values(?,?,?)");
          while (modlist.hasMoreElements()) {
            mod = (Module) modlist.nextElement();
            insertMod.setInt(1, clientid);
            insertMod.setString(2, mod.getModName());
            insertMod.setString(3, mod.getDiplayName());
            insertMod.setString(4, mod.getDefinition());
            insertMod.setInt(5, mod.getModuleType());
            insertMod.setString(6, mod.getClassName());
            insertMod.executeUpdate();
            //------------- LOAD ANY ARGUEMENTS -------------//
            if (mod.size() > 0) {
              selectModID.setInt(1, clientid);
              selectModID.setString(2, mod.getModName());
              rset = selectModID.executeQuery();
              if (rset.next()) {
                modid = rset.getInt("moduleid");
                for (int loc = 0; loc < mod.size(); loc++) {
                  insertArg.setInt(1, clientid);
                  insertArg.setInt(2, modid);
                  insertArg.setString(3, mod.getArgName(loc));
                  insertArg.executeUpdate();
                } //end for
              } //end rset.next
            } //end mod-size > 0
            result = ACK;
          }//end while
