private static final String SUN_IDL_MARKER	= "afabcafe";
	private static final String VOYAGER_MARKER	= "0000000";
	
	
//----------------------------------------------------------------------
// STATIC VARIABLES
//----------------------------------------------------------------------
		
//----------------------------------------------------------------------
// INSTANCE VARIABLES
//----------------------------------------------------------------------

	// Endianness
	private boolean _big_endian;
	
	// Interface definition
	private String _idl;
	
	// Hosts for each profile
	private List _host;
	
	// And ports
	private List _port;
	
	// And object keys
	private List _obj_key;
	
	// And the profile tags
	private List _tags;
	
	// Number of profiles
	private int _profiles;
	
	// byte position tracker
  private int _byte_index;
	
	
//----------------------------------------------------------------------
// CONSTRUCTOR
//----------------------------------------------------------------------
  
  /**
   * Constructs an IOR object from a stringified IOR. Stringified IORs are
   * returned by ORBs as an easily transmissable form of an IOR, usually
   * by calling the <code>objectToString()</code> method. They are large
   * strings of hexadecimal characters and begin with 'IOR:'.
   *
   * @param A hexadecimal string representing a stringified IOR.
   */
	public IOR( String hex_ior )
	{
		
		configure();
		parseIOR( hex_ior );
		
	}
	
//----------------------------------------------------------------------	
	
	/**
	 * Constructs an IOR object using the information specified.
	 *
	 * @param IDL The IDL that is to be used for the IOR. This will be a
	 *        string name, for example: 'IDL:FIPA_Agent_97'
	 * @param host The host name or IP address of the machine that this IOR represents
	 *        e.g. host.domain.com
	 * @param port The port of the target machine
	 * @param object_key The object key section of the actual IOR of the target object.
	 *        Object keys are ORB specific so this must be supplied by retrieving it
	 *        from the ORB used to create the original IOR. It can be retrieved either
	 *        by method call on the ORB, or by parsing a stringified IOR.
	 */
	public IOR( String IDL, String host, int port, String object_key )
	{
		
		configure();		
		_profiles = 0;
		_big_endian = false;
		_idl = IDL;
		_host.add( _profiles, host );
		_port.add( _profiles, new Integer( port ) );
		_obj_key.add( _profiles, object_key );
		_tags.add( _profiles, TAG_IIOP );
		
	}
	
//----------------------------------------------------------------------	
	
	/**
	 * Constructs an IOR object with multiple profiles using the information specified.
	 * Multiple profile IORs are very uncommon. The lists passed as parameters must
	 * have the corresponding sections for each profile in the correct position in each list
	 * and all lists must have the same number of elements.
	 *
	 * @param IDL The IDL that is to be used for the IOR. This will be a
	 *        string name, for example: 'IDL:FIPA_Agent_97'
	 * @param hosts A list of host names or IP address of the machine that this IOR represents
	 *        e.g. host.domain.com
	 * @param port A list of ports of the target machine
	 * @param object_key A list of object key sections of the actual IOR of the target object.
	 *        Object keys are ORB specific so this must be supplied by retrieving it
	 *        from the ORB used to create the original IOR. It can be retrieved either
	 *        by method call on the ORB, or by parsing a stringified IOR.
	 */
	public IOR( String IDL, List hosts, List ports, List object_keys )
	{
		
		configure();		
		_profiles = hosts.size() - 1;
		_big_endian = false;
		_idl = IDL;
		_host = hosts;
		_port = ports;
		_obj_key = object_keys;
		
		for ( int i=hosts.size(); --i>=0; )
		{
		
			_tags.add( i, TAG_IIOP );
			
		}
		
	}
	
	
//----------------------------------------------------------------------
// PRIVATE METHODS
//----------------------------------------------------------------------

	/**
	 * Sets up the object. Initialises the lists.
	 */
	private void configure()
	{
		
		_byte_index = 0;
		_host = new ArrayList();
		_port = new ArrayList();
		_tags = new ArrayList();
		_obj_key = new ArrayList();	
		
	}
	
//----------------------------------------------------------------------	
	
	/**
	 * Parses a stringified IOR into an IOR object. This is done by manipulating
	 * the string following the CORBA specifications for IORs and CDR (which IORs
	 * are encoded in when stringified). This generally involves a lot of padding
	 * and byte alignment.
	 *
	 * @param ior_to_parse The stringified IOR to parse
	 */
	private void parseIOR( String ior_to_parse )
	{
		
		_byte_index = 0;
		
		// IOR will definitely start with IOR: and no spaces
		StringBuffer ior = new StringBuffer( ior_to_parse );
		StringBuffer sequence;
		
		// Strip off the IOR header
		ior = ior.delete( 0, 4 );
		
		String endian = ior.substring( 0, 8 );
			
		if ( endian.indexOf( ONE ) >= 0 )
		{
				
			_big_endian = true;
				
		}
		
		// Strip off the 4 byte endianness and padding (4 bytes)
		ior = ior.delete( 0, 8 );
		_byte_index = 4;
		
		// Next is the interface definition - this will be prepended by a four byte length
		// field and terminated by "00"
		int length = getNumber( ior.substring( 0, 8 ), _big_endian );
		ior = ior.delete( 0, 8 );
		_byte_index += 4;
		
		_idl = hexStringToString( ior.substring( 0, length * 2 ) );
		_byte_index += length;
		ior = ior.delete( 0, ( length * 2 ) );
		
		// remove padding
		checkParseAlignment( 4, ior );
		
		// get profile count - 4 bytes
		int profile_count = getNumber( ior.substring( 0, 8 ), _big_endian );
		ior = ior.delete( 0, 8 );
		_byte_index += 4;
		_profiles = profile_count - 1;
		
		for ( int i=0; i<profile_count; i++ )
		{
		
			// get TAG - this will be 4 bytes 00000000 - TAG_INTERNET_IOP
			String tag = ior.substring( 0, 8 );
			
			_tags.add( i, tag );
			
			ior = ior.delete( 0, 8 );
			_byte_index += 4;
			
			// get sequence length - this gives the length of the IOR up to the start of
			// the object key (and includes the length of the object key)
			length = getNumber( ior.substring( 0, 8 ), _big_endian );
			ior = ior.delete( 0, 8 );
			sequence = new StringBuffer( ior.substring( 0, length * 2 ) );
			ior = ior.delete( 0, length * 2 );
			_byte_index += 4;
			
			// get sequence version number
			sequence = sequence.delete( 0, 8 );
			_byte_index += 4;
				
			// get host name
			length = getNumber( sequence.substring( 0, 8 ), _big_endian );
			sequence = sequence.delete( 0, 8 );
			_byte_index += 4;
			
			_host.add( i, hexStringToString( sequence.substring( 0, length * 2 ) ) );
			sequence = sequence.delete( 0, length * 2 );
			_byte_index += length;
				
			// remove padding
			checkParseAlignment( 2, sequence );	
			
			// get port - 2 bytes
			_port.add( i, new Integer( getNumber( sequence.substring( 0, 4 ), _big_endian ) ) );
			sequence = sequence.delete( 0, 4 );
			_byte_index += 2;
			
			// remove padding
			checkParseAlignment( 4, sequence );	
			
			// get object key
			length = getNumber( sequence.substring( 0, 8 ), _big_endian );
			sequence = sequence.delete( 0, 8 );
			_byte_index += 4;
			
			_obj_key.add( i, sequence.substring( 0, length * 2 ) );
			_byte_index += length;
			
		}
				
	}
	
//----------------------------------------------------------------------	
	
	/**
	 * Parses an integer value from a hex string CDR representation of a number.
	 * The endianness of the IOR is needed to determine which end of the number is
	 * most significant.
	 *
	 * @param hex_number The hex string to retrieve the number from (e.g. 000000A3)
	 * @param big_endian A flag to indicate the endianness of the IOR (true == big endian)
	 * @return The integer number that was encoded in the hex string
	 */
	private int getNumber( String hex_number, boolean big_endian )
	{
		
		String hex = ZERO_BYTE;
		
		if ( big_endian )
		{
			
			// ignore the first 0 in case it is part of the number, e.g. 03
			int zero_end = hex_number.indexOf( ZERO, 1 );
			
			if ( zero_end >= 0 )
			{
			
				hex = hex_number.substring( 0, zero_end );
				
			}
			else
			{
				
				hex = hex_number;	
				
			}
						
		}
		else
		{
			
			// the number is a the end
			int index = hex_number.lastIndexOf( ZERO, hex_number.length() - 2 );

			if ( index < 0 )
			{
				
				hex = hex_number;
				
			}
			else
			{
				
				hex = hex_number.substring( index + 1 );	
				
			}
			
			if ( hex.length() % 2 != 0 )
			{
				
				hex = ZERO + hex;	
				
			}
			
		}
		
		return hexStringToInt( hex );
		
	}
	
//----------------------------------------------------------------------	
	
	/**
	 * Converts a hexadecimal string to an integer.
	 *
	 * @param hex The hex string
	 * @return The integer representation of the hex string
	 */
	private int hexStringToInt( String hex )
	{

		if ( hex.length() % 2 != 0 )
		{
			
			return 0;
			
		}
		
		return Integer.parseInt( hex, 16 );
		
	}
	
//----------------------------------------------------------------------	
	
	/**
	 * Converts an integer to a hexadecimal string.
	 *
	 * @param integer The integer to convert
	 * @param byte_size The size, in bytes, of the target string (for example, numbers in
	 *						CDR are normally 4 bytes). This determines the size of the hex string produced.
	 * @param big_endian A flag to indicate whether this should be big endian or not
	 * @return A hex string representation of the integer
	 */
	private String intToHexString( int integer, int byte_size, boolean big_endian )
	{
		
		StringBuffer out = new StringBuffer( Integer.toHexString( integer ) );
		
		int max = byte_size*2;
			
		for ( int i=out.length(); i<max; i++ )
		{
				
			if ( big_endian )
			{
			
				out.append( ZERO );	
				
			}
			else
			{
				
				out.insert( 0, ZERO );	
				
			}
						
		}
		
		return out.toString();
		
	}
	
//----------------------------------------------------------------------	
	
	/**
	 * Converts a hexadecimal string to a plain string.
	 *
	 * @param hex The hex string
	 * @return The Unicode string representation of the hex string
	 */
	private String hexStringToString( String hex )
	{
	
		StringBuffer out = new StringBuffer();
		
		hex = hex.substring( 0, hex.length() - 2 );
		
		int num_bytes = hex.length() / 2;
		int num_bytes_left = num_bytes;
		
		while ( num_bytes_left > 0 )
		{
			
			String b = hex.substring( 0, 2 );
			hex = hex.substring( 2 );
			int i = hexStringToInt( b );
			byte[] bytes = new byte[ 1 ];
			bytes[ 0 ] = new Byte( ( new Integer( i ) ).toString() ).byteValue();
			out.append( new String( bytes ) );
			num_bytes_left--;
			
		}

		return out.toString();
				
	}
	
//----------------------------------------------------------------------	
	
  /**
   * Converts a string to hex with optional null terminator and length fields
   *
   * @param input String to convert
   * @param want_null Flag to specify if hex output should be null terminated (00)
   * @param want_length Flag to specify if the length of the converted string should be prepended
   * @param big_endian A flag to specify whether the length should be encoded as big or little endian
   * @return The hex string representation of the original string
   */
  private String stringToHexString( String input, boolean want_null, boolean want_length, boolean big_endian ) {
    
    char[] tohex = input.toCharArray();
    StringBuffer hexed = new StringBuffer();
    String hexlen;
    int len = 0;
		int max = tohex.length;
    
    for ( int i=0; i<max; i++ )
    {
      
      hexed.append( Integer.toHexString( (int)tohex[ i ] ) );
      
    }
    
    tohex = null;
    
    if ( want_null )
    {
    	
      hexed.append( ZERO_BYTE );  // null terminator is "00" in an IOR
      
    }
    
    len = hexed.length() / 2;
     
    if ( want_length )
    {
      
      hexlen = Integer.toHexString( len );
      
      hexed.insert( 0, hexlen );
      
      for ( int i=8-hexlen.length(); --i>=0; )
      {
        
      	if ( big_endian )
      	{
      		
      		hexed.append( ZERO );
      		
      	}
      	else
      	{
      		
      		hexed.insert( 0, ZERO );  // pad to the right byte size for a length field (4 bytes)
      		
      	}
        
      } 
      
    }
        
    return hexed.toString(); 
    
  }	
	
//----------------------------------------------------------------------  
  
  /** 
   * Checks that the stringified IOR being parsed is correctly aligned to a byte number.
   * If not this method will remove the padding present.
   *
   * @param divby The byte aligment to check (e.g. 2 or 4)
   * @param byte_index The current byte index number
   * @param ior The IOR as it has been constructed so far
   * @return The IOR with appropriate padding removed
   */ 
	private String checkParseAlignment( int divby, StringBuffer ior ) {
    
    boolean done = false;
    String output = "";
    
    while ( ! done )
    {
      
      if ( _byte_index % divby == 0 )
      {
      	
        done = true;
        
      }
      else
      {
        
        _byte_index++;
        ior = ior.delete( 0, 2 );
        
      }
      
    }
    
    return ior.toString();
    
  } 
  
//----------------------------------------------------------------------  
  
  /**
   * Checks if the current byte position is aligned correctly and, if not, adds the required padding.
   * This method is used when constructing a stringified IOR.
   *
   * @param divby The byte pos to check alignment with (usually 4 or 2 for CDR)
   * @return The IOR with correct padding added
   */
  private String checkDeparseAlignment( int divby ) {
    
    boolean done = false;
    StringBuffer output = new StringBuffer();
    
    while ( ! done )
    {
      
      if ( _byte_index % divby == 0 )
      {
      	
        done = true;
        
      }
        
      else
      {
        
        _byte_index++;
        output.append( ZERO_BYTE );
        
      }
      
    }
    
    return output.toString();
    
  }
  
//----------------------------------------------------------------------    
  
  /**
   * Prints out information about this tool when run from the command line.
   */
	private static void printInfo()
	{
		
		System.out.println( "\nFIPA-OS IOR Viewer v1.1" );
		System.out.println( "=======================" );
				
	}
	
	/**
   * Prints out usage information about this tool when run from the command line.
   */
	private static void printUsage()
	{
		
		System.out.println( "\nUsage: IORViewer [-option] <filename>" );
		System.out.println( "Where:" );
		System.out.println( "\tfilename\tis a file containing an IOR" );
		System.out.println( "\tv\t\tindicates verbose output" );
		System.out.println( "\th/?/help\tprints this information" );
		System.out.println( "\nExamples: IORViewer ior.txt" );
		System.out.println( "\t  IORViewer -v C:\\fipa-os\\tools\\ior.txt" );
		System.out.println( "\t  IORViewer http://webserver/platforms/host-domain-com-9000-acc" );
		System.exit( 0 );
		
	}
	
	/**
   * Prints out errors when run from the command line.
   */
	private static void printError( String error )
	{
		
		System.out.println( "\nERROR: " + error );
		System.exit( -1 );
		
	}
	
	/**
	 * Prints out the details of the IOR to a string when run from the command line.
	 *
	 * @param verbose Flag indicating whether to show verbose output or not
	 * @return A string containing formatted details of the IOR
	 */
  private String printIORDetails( boolean verbose )
  {
  	
  	StringBuffer out = new StringBuffer( "\n" );
		out.append( "IDL:\t\t" + _idl );
		
		if ( verbose )
		{
		
			out.append( "\nEndianness:\t" );
					
			if ( _big_endian )
			{
			
				out.append( "Big" );
				
			}
			else
			{
				
				out.append( "Little" );
				
			}
			
		}
		
		int num_p = getProfileCount();
		
		if ( num_p > 1 )
		{
		
			out.append( "\n\nIOR has " + num_p + " profiles:" );

		}
		
		String obj_key= new String();
		
		for ( int i=0; i<num_p; i++ )
		{
		
			if ( num_p > 1 )
			{
			
				out.append( "\n\nProfile: " + ( i + 1 ) );
				
			}
			
			if ( verbose )
			{
				
				if ( ( (String)_tags.get( i ) ).compareTo( TAG_IIOP ) == 0 )
				{
				
					out.append( "\nType:\t\tIIOP" );
					
				}
				else
				{
					
					out.append( "\nType:\t\tGIOP" );
					
				}
				
			}
			
			out.append( "\nHost & port:\t" + _host.get( i ) + ":" + _port.get( i ) );
			
			obj_key = (String)_obj_key.get( i );
			
			if ( verbose )
			{
				
				out.append( "\nObject key:\t" + obj_key );	
								
			}
			
		}
		
		out.append( "\nCreated by:\t" );
		
		if ( obj_key.startsWith( SUN_IDL_MARKER ) )
		{
		
			out.append( "Sun Java ORB (sunidl)" );
			
		}
		else if ( obj_key.startsWith( VOYAGER_MARKER ) )
		{
			
			out.append( "Voyager" );
			
		}
		else
		{
			
			out.append( "An unidentified ORB" );
			
		}
		
		return out.toString();
		
  }	
	
//----------------------------------------------------------------------  	
	
	/**
	 * Reads an IOR from a file. The file can contain an IOR by itself or can
	 * be a FIPA-OS interoperability file - any syntax is OK so long as:
	 * (a)the IOR on the first line of the file, (b)there is nothing following
	 * the IOR on the line, (c)the IOR starts with 'IOR:'. The intended use for
	 * this is to read IORs from text files containing an IOR by itself that
	 * has been captured, or for reading IORs direct from a FIPA-OS interoperability
	 * file that has been published to a web server.
	 *
	 * @param file The name (and path) of the file to read
	 * @return The IOR contained within that file
	 */
	private static String readIORFromFile( String file )
	{
		
		String line = new String();
		Reader r = null;
		
		try
		{
		
			r = new FileReader( file );
			
		}
		catch ( Throwable t )
		{
			
			try
			{
			
				// No file - try a URL
				URL url = new URL( file );
				r = new InputStreamReader( url.openStream() );
				
			}
			catch ( Throwable t2 ) {}
			
		}
		
		try
		{
			
			BufferedReader br = new BufferedReader( r );
			line  = br.readLine();
			
			while ( line != null )
			{
			
				if ( line.indexOf( IOR ) >= 0 )
				{
				
					return line.substring( line.indexOf( IOR ) );	
				
				}
				
				line  = br.readLine();
				
			}
			
		}
		catch ( Exception e )
		{
			
			printError( "File at " + file + " could not be found or could not be opened." );			
			
		}
		
		return null;
				
	}  
	
	
//----------------------------------------------------------------------
// PUBLIC METHODS
//----------------------------------------------------------------------	
	
  /**
   * Returns the IDL currently in use by this IOR. This will be the same
   * for all profiles in the IOR.
   *
   * @return The IDL used in this IOR
   */
	public String getIDL()
	{
		
		return _idl;
		
	}
	
	/**
	 * Sets the IDL to use for this IOR. If the IOR was constructed from a stringified
	 * IOR then when the <code>toString</code> method of this IOR is called, the hex
	 * output will have been modified to list the new IDL name. This IDL will be the same
	 * for all profiles in the IOR.
	 *
	 * @param idl The IDL to use for this IOR
	 */
	public void setIDL( String idl )
	{
		
		if ( idl == null )
		{
		
			_idl = idl;
			
		}
		
	}
	
//----------------------------------------------------------------------	
	
	/**
	 * Indicates whether this IOR is encoded in a big or little endian way.
	 *
	 * @return True if the IOR is big endian, false otherwise
	 */
	public boolean isBigEndian()
	{
		
		return _big_endian;
		
	}
	
	/**
	 * Sets the endianness of this IOR.
	 *
	 * @param The endianness flag- true is big endian, false is little endian
	 */
	public void isBigEndian( boolean endian )
	{
		
		_big_endian = endian;
		
	}
	
//----------------------------------------------------------------------	
	
	/**
	 * Sets the host name for the current profile of the IOR. If only one
	 * profile is used (in most cases) then this sets the host name for the IOR. If more than
	 * one profile is in use, then this method sets the host name for the latest profile to be 
	 * added to the IOR (i.e. the one with the highest index number).
	 * If the IOR was constructed from a stringified IOR then when the <code>toString</code>
	 * method of this IOR is called then the hex output will be modified to show the new
	 * host name.
	 *
	 * @param host The host name (or IP address) to set in the IOR
	 */
	public void setHost( String host )
	{
		
		if ( host != null )
		{
		
			_host.add( _profiles, host );
			
		}
		
	}
	
	/**
	 * Sets the host name for the indicated profile of the IOR.
	 * If the IOR was constructed from a stringified IOR then when the <code>toString</code>
	 * method of this IOR is called then the hex output will be modified to show the new
	 * host name.
	 *
	 * @param profile The index number of the profile to modify in this IOR
	 * @param host The host name (or IP address) to set in the IOR
	 */
	public void setHost( int profile, String host )
	{
		
		if ( host != null )
		{
		
			_host.add( profile, host );
			
		}
		
	}
	
	/**
	 * Returns the host name of the current profile of the IOR. If only one profile is
	 * in use (most cases) then the host name for the whole IOR is returned. For a multiple
	 * profile IOR, then the host name of the latest profile to be added (i.e. the one with the 
	 * highest index number) is returned.
	 *
	 * @return The host name of the IOR, or of the current IOR profile
	 */
	public String getHost()
	{
		
		return (String)_host.get( _profiles );
		
	}
	
	/**
	 * Returns the host name of the indicated profile of the IOR.
	 *
	 * @param profile The index number of the profile to access
	 * @return The host name of the indicated IOR profile
	 */
	public String getHost( int profile )
	{
		
		return (String)_host.get( profile );
		
	}
	
//----------------------------------------------------------------------	
	
	/**
	 * Sets the port for the current profile of the IOR. If only one
	 * profile is used (in most cases) then this sets the port for the IOR. If more than
	 * one profile is in use, then this method sets the port for the latest profile to be 
	 * added to the IOR (i.e. the one with the highest index number).
	 * If the IOR was constructed from a stringified IOR then when the <code>toString</code>
	 * method of this IOR is called then the hex output will be modified to show the new
	 * port.
	 *
	 * @param port The port number to set in the IOR
	 */
	public void setPort( int port )
	{
		
		_port.add( _profiles, new Integer( port ) );
		
	}
	
	/**
	 * Sets the port for the indicated profile of the IOR.
	 * If the IOR was constructed from a stringified IOR then when the <code>toString</code>
	 * method of this IOR is called then the hex output will be modified to show the new
	 * port.
	 *
	 * @param profile The index number of the profile to modify in this IOR
	 * @param port The port to set in the IOR
	 */
	public void setPort( int profile, int port )
	{
		
		_port.add( profile, new Integer( port ) );
		
	}
	
	/**
	 * Returns the port number of the current profile of the IOR. If only one profile is
	 * in use (most cases) then the port for the whole IOR is returned. For a multiple
	 * profile IOR, then the port of the latest profile to be added (i.e. the one with the 
	 * highest index number) is returned.
	 *
	 * @return The port of the IOR, or of the current IOR profile
	 */
	public int getPort()
	{
		
		return ( (Integer)_port.get( _profiles ) ).intValue();
		
	}
	
	/**
	 * Returns the port of the indicated profile of the IOR.
	 *
	 * @param profile The index number of the profile to access
	 * @return The port of the indicated IOR profile
	 */
	public int getPort( int profile )
	{
		
		return ( (Integer)_port.get( profile ) ).intValue();
		
	}
	
//----------------------------------------------------------------------	
	
	/**
	 * Sets the object key for the current profile of the IOR. If only one
	 * profile is used (in most cases) then this sets the object key for the IOR. If more than
	 * one profile is in use, then this method sets the object key for the latest profile to be 
	 * added to the IOR (i.e. the one with the highest index number).
	 * If the IOR was constructed from a stringified IOR then when the <code>toString</code>
	 * method of this IOR is called then the hex output will be modified to show the new
	 * object key.
	 *
	 * @param obj_key The object key to set in the IOR
	 */
	public void setObjectKey( String obj_key )
	{
		
		if ( obj_key != null )
		{
		
			_obj_key.add( _profiles, obj_key );
			
		}
		
	}
	
	/**
	 * Sets the object key for the indicated profile of the IOR.
	 * If the IOR was constructed from a stringified IOR then when the <code>toString</code>
	 * method of this IOR is called then the hex output will be modified to show the new
	 * object key.
	 *
	 * @param profile The index number of the profile to modify in this IOR
	 * @param obj_key The object key to set in the IOR
	 */
	public void setObjectKey( int profile, String obj_key )
	{
		
		if ( obj_key != null )
		{
		
			_obj_key.add( profile, obj_key );
			
		}
		
	}
	
	/**
	 * Returns the object key of the current profile of the IOR. If only one profile is
	 * in use (most cases) then the object key for the whole IOR is returned. For a multiple
	 * profile IOR, then the object key of the latest profile to be added (i.e. the one with the 
	 * highest index number) is returned.
	 *
	 * @return The object key of the IOR, or of the current IOR profile
	 */
	public String getObjectKey()
	{
		
		return (String)_obj_key.get( _profiles );
		
	}
	
	/**
	 * Returns the object key of the indicated profile of the IOR.
	 *
	 * @param profile The index number of the profile to access
	 * @return The object key of the indicated IOR profile
	 */
	public String getObjectKey( int profile )
	{
		
		return (String)_obj_key.get( profile );	
		
	}
	
//----------------------------------------------------------------------	
	
	/**
	 * Sets the profile type tag for the current profile of the IOR. If only one
	 * profile is used (in most cases) then this sets the profile type tag for the IOR. If more than
	 * one profile is in use, then this method sets the profile type tag for the latest profile to be 
	 * added to the IOR (i.e. the one with the highest index number).
	 * If the IOR was constructed from a stringified IOR then when the <code>toString</code>
	 * method of this IOR is called then the hex output will be modified to show the new
	 * profile type tag.
	 *
	 * @param tag The profile type tag to set in the IOR
	 */
	public void setTag( String tag )
	{
		
		if ( tag != null )
		{
		
			_tags.add( _profiles, tag );
			
		}
		
	}
	
	/**
	 * Sets the profile type tag for the indicated profile of the IOR.
	 * If the IOR was constructed from a stringified IOR then when the <code>toString</code>
	 * method of this IOR is called then the hex output will be modified to show the new
	 * profile type tag.
	 *
	 * @param profile The index number of the profile to modify in this IOR
	 * @param tag The profile type tag to set in the IOR
	 */
	public void setTag( int profile, String tag )
	{
		
		if ( tag != null )
		{
		
			_tags.add( profile, tag );
			
		}
		
	}
	
	/**
	 * Returns the profile type tag of the current profile of the IOR. If only one profile is
	 * in use (most cases) then the profile type tag for the whole IOR is returned. For a multiple
	 * profile IOR, then the profile type tag of the latest profile to be added (i.e. the one with the 
	 * highest index number) is returned.
	 *
	 * @return The profile type tag of the IOR, or of the current IOR profile
	 */
	public String getTag()
	{
		
		return (String)_tags.get( _profiles );
		
	}
	
	/**
	 * Returns the profile type tag of the indicated profile of the IOR.
	 *
	 * @param profile The index number of the profile to access
	 * @return The profile type tag of the indicated IOR profile
	 */
	public String getTag( int profile )
	{
		
		return (String)_tags.get( profile );	
		
	}
	
//----------------------------------------------------------------------	
	
	/**
	 * Adds a new profile to the IOR containing the specified information. The new
	 * profile is added to the end of the profile chain, and has an index number equal to the
	 * total number of profiles currently in the IOR. The index number is incremented after
	 * addition to reflect the inclusion of the new profile.
	 *
	 * @param host The host name or IP address to use in this profile
	 * @param port The port number to use in this profile
	 * @param object_key The object key to use in this profile
	 * @return The number of profiles now present in the IOR (including the one just added)
	 */
	public int addProfile( String host, int port, String object_key )
	{
		
		_profiles++;
		_host.add( _profiles, host );
		_port.add( _profiles, new Integer( port ) );
		_obj_key.add( _profiles, object_key );
		_tags.add( _profiles, TAG_IIOP );
		
		return _profiles;
		
	}
	
	/**
	 * Inserts a new profile to the IOR containing the specified information into the specified
	 * profile position. The new profile is inserted into the profile chain at the index
	 * number specified and all of the profiles following it are re-indexed.
	 *
	 * @param profile The index number at which to insert this profile
	 * @param host The host name or IP address to use in this profile
	 * @param port The port number to use in this profile
	 * @param object_key The object key to use in this profile
	 * @return The number of profiles now present in the IOR (including the one just inserted)
	 */
	public int insertProfile( int profile, String host, int port, String object_key )
	{
		
		_profiles++;
		_host.add( profile, host );
		_port.add( profile, new Integer( port ) );
		_obj_key.add( profile, object_key );
		_tags.add( profile, TAG_IIOP );
		
		return _profiles;
		
	}
	
	/**
	 * Removes the specified profile from the IOR. After removal, all of the other
	 * profiles in the IOR are renumbered to reflect their new positions (if they have moved).
	 * The number of profiles left in the IOR is returned by this method.
	 *
	 * @param profile The index number of the profile to remove
	 * @return The number of profile left in the IOR after the removal operation
	 */
	public int removeProfile( int profile )
	{
		
		_profiles--;
		_host.remove( profile );
		_tags.remove( profile );
		_port.remove( profile );
		_obj_key.remove ( profile );
		
		return _profiles;
		
	}
	
	/** 
	 * Returns the number of profiles currently in the IOR.
	 *
	 * @return The profile count
	 */
	public int getProfileCount()
	{
		
		return _profiles + 1;
		
	}
	
//----------------------------------------------------------------------	
	
	/**
	 * Converts the IOR object to a hexadecimal CDR 'stringified' representation, suitable
	 * for transmission to other ORBs. This representation is properly encoded and can
	 * be used in the <code>stringToObject</code> methods of ORBs in order to invoke
	 * remote method calls on the object represented by this IOR.
	 *
	 * @return A stringified representation of this IOR
	 */
	public String toString()
	{
		
		boolean done = false;
    StringBuffer output = new StringBuffer();
    StringBuffer sequence;
    String hexlen;
    int len;
        
    // output header, endianness id and pad to byte number four
    output.append( IOR );
    
    if ( _big_endian )
    {
    	
    	output.append( BIG_E );
    	_byte_index = BIG_E.length() / 2;
    	
    }
    else
    {
    
    	output.append( LITTLE_E );
    	_byte_index = LITTLE_E.length() / 2;
    	
    }
    
    // convert tag to hex
    String temp = stringToHexString( _idl, true, true, _big_endian ) ;
    output.append( temp );
    _byte_index += temp.length() / 2;
    output.append( checkDeparseAlignment( 4 ) );
     
    // add profile count
    temp = intToHexString( getProfileCount(), 4, _big_endian );
    output.append( temp );
    _byte_index += temp.length() / 2;
    int prof_count = getProfileCount();
    
    for ( int i=0; i<prof_count; i++ )
    {
    
	    // add TAG_INTERNET_IOP - no need to check alignment as tag was aligned and is 4 bytes long
	    output.append( _tags.get( i ) );
	    _byte_index += 4;
	    
	    // construct sequence
	    
	    // add version - will be aligned anyway
	    sequence = new StringBuffer( VERSION );
	    _byte_index += 4;
	    
	    // add host name
	    temp = stringToHexString( (String)_host.get( i ), true, true, _big_endian );
	    sequence.append( temp );
	    _byte_index += temp.length() / 2;
	    sequence.append( checkDeparseAlignment( 2 ) );
	    
	    // add port
	    temp = Integer.toHexString( ( (Integer)_port.get( i ) ).intValue() );
	    
	    for ( int j=4-temp.length(); --j>=0; )
	    {
	    	
	      sequence.append( ZERO );
	      
	    }
	    
	    sequence.append( temp );
	    _byte_index += 2;
	    sequence.append( checkDeparseAlignment( 4 ) );
	
	    // add object key
	    String object = (String)_obj_key.get( i );
	    // calculate length of object key (/2 to get num bytes)
	    len = object.length() / 2;
	    hexlen = Integer.toHexString( len );
	    
	    if ( _big_endian )
	    {
	    	
	    	sequence.append( hexlen );
	    	
	    }
	    
	    for ( int j=8-hexlen.length(); --j>=0; )
	    {
	    	
	      sequence.append( ZERO );
	      
	    }
	    
	    if ( ! _big_endian )
	    {
	    
	    	sequence.append( hexlen );
	    	
	    }
	    
	    sequence.append( object );
	    // increment byte index
	    _byte_index += len;
	    _byte_index += 4;   
	    
	    // calculate length of this sequence
	    int newlen = sequence.length() / 2;
	    String newhexlen = Integer.toHexString( newlen );
	    
	    if ( _big_endian )
	    {
	    
      	output.append( newhexlen );
      	
	    }	    
	    
	    for ( int j=8-newhexlen.length(); --j>=0; )
	    {
	    	
	      output.append( ZERO );
	      
	    }
	    
	    // increment byte index
	    _byte_index += 4;    

	    if ( ! _big_endian )
	    {
	    
      	output.append( newhexlen );
      	
	    }
	    
      output.append( sequence );
	    
	    // ior must be even number of bytes
	    if ( _byte_index % 2 != 0 )
	    {
	    	
	      output.append( ZERO_BYTE );
	      
	    }
	    
    }
            
    return output.toString();
		
	}
	
	
//----------------------------------------------------------------------
// MAIN METHOD
//----------------------------------------------------------------------
  
	/**
	 * When run from the command line this class will load an IOR from the
	 * file specified as an argument, parse it and echo the results back
	 * to STDOUT. This is useful as a debugging tool, as it can show you the
	 * IORs contents in a human readable form. A second optional argument
	 * can be given - verbose mode (-v) - which prints out more information.
	 */
	public static void main( String[] args )
	{
		
		// Command line: IORViewer [-v] IOR|file
		
		printInfo();
		
		if ( args.length > 2 || args.length == 0 )
		{
			
			System.out.println( "\nERROR: Incorrect (number of) arguments." );
			printUsage();
			
		}
		
		boolean verbose = false;
		String arg = null;
		
		for ( int i=0; i<args.length; i++ )
		{
			
			if ( args[ i ].compareToIgnoreCase( "-v" ) == 0 )
			{
				
				verbose = true;
				
			}
			else if ( args[ i ].startsWith( "-h" ) )
			{
				
				printUsage();
				
			}
			else if ( args[ i ].startsWith( "/h" ) )
			{
				
				printUsage();
				
			}
			else if ( args[ i ].indexOf( "?" ) >= 0 )
			{
				
				printUsage();
				
			}
			else
			{
				
				arg = args[ i ];	
				
			}
			
		}
		
		String ior = new String();
			
		try
		{
		
			ior = readIORFromFile( arg );
							
		}
		catch ( Throwable t )
		{
			
			printError( "IOR could not be read from file at: " + arg );
			
		}
		
		if ( ior == null )
		{
			
			printError( "IOR could not be read from file at: " + arg );	
			
		}
		
		if ( verbose )
		{
		
			System.out.println( "\nAnalysing " + ior );
			
		}
		
		try
		{
		
			IOR i = new IOR( ior );
			System.out.println( i.printIORDetails( verbose ) );			
			
			System.out.println( "\nCORBA Object Status" );
			System.out.println( "===================\n" );
				
			try
			{
				ORB orb = ORB.init( new String[0], System.getProperties() );
				org.omg.CORBA.Object obj = orb.string_to_object( ior );
				
				System.out.println( "ORB.string_to_object() was succesfull" );
				System.out.println( "Object._non_existent() == " + obj._non_existent() );
			}
			catch( Throwable t )
			{
				System.out.println( "Error occured interacting with object - exception follows" );
				t.printStackTrace( System.out );
			}
			
		}
		catch ( Throwable t )
		{
			
			printError( "IOR is malformed or corrupt" );	
			
		}
		
		System.exit( 0 );
		
	}
	
	
} // End IOR
