import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;


/**
 * NotificationInterceptor is the interceptor to control the life cycle of Thread Model
 * 
 * @author <a href="mailto:leo@sparrowcontainer.org">Leo Chan </a>
 * @version $Revision: 0.1 Alpha $
 */
public class StInterceptor implements MethodInterceptor,ProxyjConstant {

    /*
     * (non-Javadoc)
     * 
     * @see net.sf.cglib.proxy.MethodInterceptor#intercept(java.lang.Object,
     *      java.lang.reflect.Method, java.lang.Object[],
     *      net.sf.cglib.proxy.MethodProxy)
     */
    public Object intercept(Object obj, Method method, Object[] args,
            MethodProxy mproxy) throws Throwable {
       // Logger.logDebug(this,"handle "+method.getName());
        if(method.getName().indexOf("init")>-1 || 
                method.getName().indexOf("return")>-1 ||
                method.getName().indexOf("assign")>-1 ||
                method.getName().indexOf("prepare")>-1
                ){
            return mproxy.invokeSuper(obj, args);
        }else
        
        if(method.getName().length()>3 && method.getName().substring(0,3).indexOf("get")>-1){
            /*if( ((Statement)obj).returnCNode().getSelectMode()==1 ){
                if(((Statement)obj).returnCNode().getDbnodes1().getStatus()==STATE_READY){
                    return handleGet(obj, method, args, mproxy, 1);                   
                }else if(((Statement)obj).returnCNode().getDbnodes2().getStatus()==STATE_READY){
                    return handleGet(obj, method, args, mproxy, 2);  
                }
            }else if( ((Statement)obj).returnCNode().getSelectMode()==2 ){
                if(((Statement)obj).returnCNode().getDbnodes2().getStatus()==STATE_READY){
                    return handleGet(obj, method, args, mproxy, 2);                   
                }else if(((Statement)obj).returnCNode().getDbnodes1().getStatus()==STATE_READY){
                    return handleGet(obj, method, args, mproxy, 1);  
                }
            }    
            */
            handleExecute(obj, method, args);
        }else
        
        if(method.getName().length()>3 && method.getName().substring(0,3).indexOf("set")>-1){
            if(((Statement)obj).returnCNode().getDbnodes1().getStatus()==STATE_READY){
                return handleSet(obj, method, args, mproxy);                   
            }
            if(((Statement)obj).returnCNode().getDbnodes2().getStatus()==STATE_READY){
                return handleSet(obj, method, args, mproxy);  
            }                            
        }else
        
   
        if(method.getName().length()>7 && method.getName().substring(0,7).indexOf("execute")>-1){
            /*if(((Statement)obj).returnCNode().getDbnodes1().getStatus()==STATE_READY){
                return handleExecute(obj, method, args, mproxy, 1);                   
            }
            if(((Statement)obj).returnCNode().getDbnodes2().getStatus()==STATE_READY){
                return handleExecute(obj, method, args, mproxy, 2);  
            }    
            */
            return handleExecute(obj, method, args);
        }


        return mproxy.invokeSuper(obj, args);
    }

    private Object handleExecute(Object obj, Method method, Object[] args){
        java.sql.Statement[] ps=(java.sql.Statement[])((Statement)obj).returnRealStatement();
      
       if(method.getName().indexOf("executeQuery")>-1){
           return exceuteQuery(obj, method, args);  
       }
        
        return exceute(obj, method, args); 
    }
    
    private Object exceute(Object obj, Method method, Object[] args){
        java.sql.Statement[] ps=(java.sql.Statement[])((Statement)obj).returnRealStatement();
        Object rtn=null;
        if(((Statement)obj).returnCNode().getSelectMode()==1){                
            try{	       
                if(((Statement)obj).returnCNode().getDbnodes1().getStatus()==STATE_READY){
                	rtn=invokeMethod(ps[0], method, args);   
        		}
            }catch(SQLException e){
	             ((Statement)obj).returnCNode().getDbnodes1().setStatus(STATE_FAILED);	 	           	
	             e.printStackTrace();
	             Logger.logError(this, e.getMessage());   	    
	             //handle fail over
	         }catch(Exception e){
	             e.printStackTrace();
	             Logger.logError(this, e.getMessage());       
	         }finally{
	             try{	        
	             //    ((Statement)obj).returnRealStatement()[0].close();
	             //    ((Statement)obj).returnRealConn()[0].close();
	             }catch(Exception e){}
	         }
	         
	         if(rtn!=null && !((Statement)obj).returnCNode().getDbnodes2().getWaitOnReturn()){
	             SQLExecutor executor=(SQLExecutor)BeanFactory.getBean(SQLExecutor.class, ((Statement)obj).returnCNode().getNodeName());
	             executor.notify(new Object[]{	 
			                     ((Statement)obj).returnRealConn()[1],
			                     null,
			                     ((Statement)obj).returnRealStatement()[1],
			                     args,
			                     method.getName(),
			                     method.getParameterTypes(),
			                     ((Statement)obj).returnCNode(),
			                     new Integer(2)	                     				
	             				});
	             return rtn;
	         }        
	         
	         try{	                    
                if(rtn==null){
                    rtn=invokeMethod(ps[1], method, args);  
                }else{
                    invokeMethod(ps[1], method, args);  	                	                    
                }
	         }catch(SQLException e){
		             ((Statement)obj).returnCNode().getDbnodes2().setStatus(STATE_FAILED);	 	           	
		             e.printStackTrace();
		             Logger.logError(this, e.getMessage());      
		             //handle fail over
		         }catch(Exception e){
		             e.printStackTrace();
		             Logger.logError(this, e.getMessage());       
		     }finally{
	             try{	        
	               //  ((Statement)obj).returnRealStatement()[1].close();
	               //  ((Statement)obj).returnRealConn()[1].close();
	             }catch(Exception e){}
	         }	         
        }  
        
        if(((Statement)obj).returnCNode().getSelectMode()==2){                
            try{	       
                if(((Statement)obj).returnCNode().getDbnodes2().getStatus()==STATE_READY){
                	rtn=invokeMethod(ps[1], method, args);   
        		}
            }catch(SQLException e){
	             ((Statement)obj).returnCNode().getDbnodes2().setStatus(STATE_FAILED);	 	           	
	             e.printStackTrace();
	             Logger.logError(this, e.getMessage());   
	    
	             //handle fail over
	         }catch(Exception e){
	             e.printStackTrace();
	             Logger.logError(this, e.getMessage());       
	         }finally{
	             try{	        
	              //   ((Statement)obj).returnRealStatement()[1].close();
	              //   ((Statement)obj).returnRealConn()[1].close();
	             }catch(Exception e){}
	         }
	         
	         if(rtn!=null && !((Statement)obj).returnCNode().getDbnodes1().getWaitOnReturn()){
	             SQLExecutor executor=(SQLExecutor)BeanFactory.getBean(SQLExecutor.class, ((Statement)obj).returnCNode().getNodeName());
	             executor.notify(new Object[]{	 
			                     ((Statement)obj).returnRealConn()[0],
			                     null,
			                     ((Statement)obj).returnRealStatement()[0],			                    
			                     args,
			                     method.getName(),
			                     method.getParameterTypes(),
			                     ((Statement)obj).returnCNode(),
			                     new Integer(1)	                     				
	             				});
	             return rtn;
	         }
	         
	         try{	                    
                if(rtn==null){
                    rtn=invokeMethod(ps[0], method, args);  
                }else{
                    invokeMethod(ps[0], method, args);  	                	                    
                }
	         }catch(SQLException e){
		             ((Statement)obj).returnCNode().getDbnodes1().setStatus(STATE_FAILED);	 	           	
		             e.printStackTrace();
		             Logger.logError(this, e.getMessage());      
		             //handle fail over
		         }catch(Exception e){
		             e.printStackTrace();
		             Logger.logError(this, e.getMessage());       
		     }finally{
	             try{	        
	             //    ((Statement)obj).returnRealStatement()[0].close();
	             //    ((Statement)obj).returnRealConn()[0].close();
	             }catch(Exception e){}
	         }	         
        } 
        
        return null;
    }    
    
    private Object exceuteQuery(Object obj, Method method, Object[] args){
        java.sql.Statement[] ps=(java.sql.Statement[])((Statement)obj).returnRealStatement();
        ((Statement)obj).makeQuery();
        try{	           
           if(((Statement)obj).returnCNode().getSelectMode()==1 && 
                   ((Statement)obj).returnCNode().getDbnodes1().getStatus()==STATE_READY){
               return invokeMethod(ps[0], method, args);
           }    
        }catch(SQLException e){
            ((Statement)obj).returnCNode().getDbnodes1().setStatus(STATE_FAILED);
	           try{
	            	if(((Statement)obj).returnCNode().getDbnodes2().getStatus()==STATE_READY){
		               return invokeMethod(ps[1], method, args);
		           }
	           }catch(Exception ee){
	               //fail error
	           }
            e.printStackTrace();
            Logger.logError(this, e.getMessage());      
            //handle fail over
        }catch(Exception e){
            e.printStackTrace();
            Logger.logError(this, e.getMessage());       
        }
        /*finally{
            try{	    
                if(((Statement)obj).returnRealStatement()[0]!=null){
                    ((Statement)obj).returnRealStatement()[0].close();
                }
            }catch(Exception e){}    
            try{
                if(((Statement)obj).returnRealConn()[0]!=null){
                    ((Statement)obj).returnRealConn()[0].close();
                }  
            }catch(Exception e){}    
            try{	    
                if(((Statement)obj).returnRealStatement()[1]!=null){
                    ((Statement)obj).returnRealStatement()[1].close();
                }
            }catch(Exception e){}    
            try{
                if(((Statement)obj).returnRealConn()[1]!=null){
                    ((Statement)obj).returnRealConn()[1].close();
                }  
            }catch(Exception e){}    
           
        }
        */
        try{	           
           if(((Statement)obj).returnCNode().getSelectMode()==2 && 
                   ((Statement)obj).returnCNode().getDbnodes2().getStatus()==STATE_READY){
               return invokeMethod(ps[1], method, args);
           }    
        }catch(SQLException e){
         ((Statement)obj).returnCNode().getDbnodes2().setStatus(STATE_FAILED);
	           try{
	            	if(((Statement)obj).returnCNode().getDbnodes1().getStatus()==STATE_READY){
		               return invokeMethod(ps[0], method, args);
		           }
	           }catch(Exception ee){
	               //fail error
	           }	
         e.printStackTrace();
         Logger.logError(this, e.getMessage());      
         //handle fail over
     }catch(Exception e){
         e.printStackTrace();
         Logger.logError(this, e.getMessage());       
     }
     /*finally{
         try{	    
             if(((Statement)obj).returnRealStatement()[0]!=null){
          //       ((Statement)obj).returnRealStatement()[0].close();
             }
         }catch(Exception e){}    
         try{
             if(((Statement)obj).returnRealConn()[0]!=null){
           //      ((Statement)obj).returnRealConn()[0].close();
             }  
         }catch(Exception e){}    
         try{	    
             if(((Statement)obj).returnRealStatement()[1]!=null){
           //      ((Statement)obj).returnRealStatement()[1].close();
             }
         }catch(Exception e){}    
         try{
             if(((Statement)obj).returnRealConn()[1]!=null){
           //      ((Statement)obj).returnRealConn()[1].close();
             }  
         }catch(Exception e){}    
        
     }*/
        return null;
    }
    
	private Object handleSet(Object obj, Method method, Object[] args,
        MethodProxy mproxy){
	    java.sql.Statement[] ps=(java.sql.Statement[])((Statement)obj).returnRealStatement();
	    Object rtn=null;
	    try{
	        if(ps[0]!=null){
	            if(((Statement)obj).returnCNode().getSelectMode()==1){
	                rtn=invokeMethod(ps[0], method, args);
	            }else{
	                invokeMethod(ps[0], method, args);
	            }
	        }    

	    }catch(SQLException e){
	        ((Statement)obj).returnCNode().getDbnodes1().setStatus(STATE_FAILED);
	        e.printStackTrace();
	        Logger.logError(this, e.getMessage());            
	    }catch(Exception e){
	        e.printStackTrace();
	        Logger.logError(this, e.getMessage());       
	    }
	    
	    try{
 
	        if(ps[1]!=null){
	            if(((Statement)obj).returnCNode().getSelectMode()==2){
	                rtn=invokeMethod(ps[1], method, args);
	            }else{
	                invokeMethod(ps[1],method, args);
	            }
	        }
	    }catch(SQLException e){
	        ((Statement)obj).returnCNode().getDbnodes2().setStatus(STATE_FAILED);
	        e.printStackTrace();
	        Logger.logError(this, e.getMessage());            
	    }catch(Exception e){
	        e.printStackTrace();
	        Logger.logError(this, e.getMessage());       
	    }
	    
	    return rtn;
	}
    
    private Object handleGet(Object obj, Method method, Object[] args,
            MethodProxy mproxy, int node){
        java.sql.Statement[] ps=(java.sql.Statement[])((Statement)obj).returnRealStatement();
        try{
	        if(node==1){
	            return invokeMethod(ps[0], method, args);
	        }    
        }catch(SQLException e){
            ((Statement)obj).returnCNode().getDbnodes1().setStatus(STATE_FAILED);
            e.printStackTrace();
            Logger.logError(this, e.getMessage());      
            //handle fail over
        }catch(Exception e){
            e.printStackTrace();
            Logger.logError(this, e.getMessage());       
        }
