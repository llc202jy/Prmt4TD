namespace Orchard.Tasks.Scheduling {
    public interface IScheduledTaskHandler : IDependency {
        void Process(ScheduledTaskContext context);
    }
}
namespace Orchard.Tasks.Scheduling {
    public interface IScheduledTask  {
        string TaskType { get; }
        DateTime? ScheduledUtc { get; }
        ContentItem ContentItem { get; }
    }
}