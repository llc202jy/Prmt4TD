public class JMXFaultDetectionHandler extends AbstractFaultDetectionHandler {
    private String jmxConnection;
    static final int DEFAULT_INVOCATION_DELAY = 1000 * 60;
    public static final String INVOCATION_DELAY_KEY = "invocationDelay";
    private long invocationDelay = DEFAULT_INVOCATION_DELAY;
    /** Component name, used for config and logger */
    private static final String COMPONENT = JMXFaultDetectionHandler.class.getName();
    /**
     * A Logger
     */
    static Logger logger = LoggerFactory.getLogger(COMPONENT);

    @Override
    public void monitor(Object proxy, final ServiceID id, LookupCache lCache)
        throws Exception {

        ServiceItem item = lCache.lookup(new ServiceItemFilter() {
            public boolean check(ServiceItem item) {
                return item.serviceID.equals(id);
            }
        });
        jmxConnection = JMXUtil.getJMXConnection(item.attributeSets);
        super.monitor(proxy, id, lCache);
    }

    /**
     * Monitor the peer service
     *
     * @throws IllegalStateException If the <tt>jmxConnection</tt> property
     * has not been set
     * @throws Exception If there are problems creating the underlying service
     * monitor
     */
    public void monitor() throws Exception {
        getServiceMonitor();
    }

    protected ServiceMonitor getServiceMonitor() throws Exception {
        ServiceMonitor monitor = null;
        if (jmxConnection != null) {
            monitor = new MBeanServerConnectionMonitor();
        }
        return (monitor);
    }

    public void setJMXConnection(String jmxConnection) {
        this.jmxConnection = jmxConnection;
    }

    public void setConfiguration(String[] configArgs) {
        if (configArgs == null)
            throw new IllegalArgumentException("configArgs is null");
        try {
            this.configArgs = new String[configArgs.length];
            this.configArgs = new String[configArgs.length];
            System.arraycopy(configArgs,
                             0,
                             this.configArgs,
                             0,
                             configArgs.length);

            setConfiguration(ConfigurationProvider.getInstance(configArgs));
        } catch (ConfigurationException e) {
            logger.error("Setting Configuration", e);
        }
    }

    public void setConfiguration(Configuration config) throws ConfigurationException {
        if (config == null)
            throw new IllegalArgumentException("config is null");
        this.config = config;

        setInvocationDelay(Config.getLongEntry(config,
                                               COMPONENT,
                                               INVOCATION_DELAY_KEY,
                                               DEFAULT_INVOCATION_DELAY,
                                               0,
                                               Long.MAX_VALUE));
        setRetryCount(Config.getIntEntry(config,
                                         COMPONENT,
                                         RETRY_COUNT_KEY,
                                         DEFAULT_RETRY_COUNT,
                                         0,
                                         Integer.MAX_VALUE));
        setRetryTimeout(Config.getLongEntry(config,
                                            COMPONENT,
                                            RETRY_TIMEOUT_KEY,
                                            DEFAULT_RETRY_TIMEOUT,
                                            0,
                                            Long.MAX_VALUE));
    }

    public void setInvocationDelay(long invocationDelay) {
        this.invocationDelay = invocationDelay;
    }

    class MBeanServerConnectionMonitor extends Thread implements ServiceMonitor {
        boolean keepAlive = true;

        MBeanServerConnectionMonitor() {
            super("MBeanServerConnectionMonitor:"+ System.currentTimeMillis());
            setDaemon(true);
            start();
        }

        @Override
        public void interrupt() {
            if (logger.isTraceEnabled())
                logger.trace("Terminating ServiceMonitor Thread");
            keepAlive = false;
            super.interrupt();
        }

        /**
         * Its all over
         */
        public void drop() {
            interrupt();
        }

        /**
         * Verify service can be reached. If the service cannot be reached
         * return false
         */
        public boolean verify() {
            if (!keepAlive)
                return (false);
            boolean verified = false;
            JMXConnector connector = null;
            try {
                if (logger.isTraceEnabled())
                    logger.trace("Getting an MBeanServerConnection to {}", jmxConnection);
                connector =
                    JMXConnectorFactory.connect(new JMXServiceURL(jmxConnection),
                                                null);
                connector.getMBeanServerConnection();

                if (logger.isTraceEnabled())
                    logger.trace("MBeanServerConnection to {} succeeded", jmxConnection);
                verified = true;
            } catch (IOException e) {
                if (logger.isDebugEnabled())
                    logger.debug("Unable create MBeanServerConnection to {}, service cannot be reached", jmxConnection);
                keepAlive = false;
            } catch (Throwable t) {
                if (!ThrowableUtil.isRetryable(t)) {
                    keepAlive = false;
                    if (logger.isDebugEnabled())
                        logger.debug("Unrecoverable Exception getting MBeanServerConnection", t);
                }
            } finally {
                if(connector!=null) {
                    try {
                        connector.close();
                    } catch (IOException e) {
                        logger.warn("Non-fatal error, unable to close JMXConnector to ["+jmxConnection+"]", e);
                    }
                }
            }
            return (verified);
        }

        public void run() {
            while (!interrupted()) {
                if (!keepAlive) {
                    return;
                }
                if (logger.isTraceEnabled())
                    logger.trace("Wait for [{}] millis to obtain MBeanServerConnection for {}",
                                  invocationDelay, jmxConnection);
                try {
                    sleep(invocationDelay);
                } catch (InterruptedException ie) {
                    /* should not happen */
                } catch (IllegalArgumentException iae) {
                    logger.warn("Sleep time is off : "+ invocationDelay);
                }

                /*
                * If we failed to invoke the method and the failure is
                * not fatal, retry
                */
                if (!verify()) {
                    if (logger.isTraceEnabled())
                        logger.trace("Unable create MBeanServerConnection to {}, retry [{}] times, waiting [{}] " +
                                     "millis between attempts", jmxConnection, retryCount, retryTimeout);
                    boolean connected = false;
                    for (int i = 0; i < retryCount; i++) {
                        long t0 = System.currentTimeMillis();
                        connected = verify();
                        if (!connected) {
                            long t1 = System.currentTimeMillis();
                            if (logger.isTraceEnabled())
                                logger.trace("Invocation attempt [{}] took [{}] millis to fail", i, (t1-t0));
                            if (retryTimeout > 0) {
                                try {
                                    sleep(retryTimeout);
                                } catch (InterruptedException ie) {
                                    /* should not happen */
                                }
                            }
                        }
                    }
                    if (!connected) {
                        keepAlive = false;
                        if (logger.isTraceEnabled()) {
                            logger.trace(
                                "Unable create MBeanServerConnection to {}, notify listeners and exit", jmxConnection);
                        }
                        notifyListeners();
                        break;
                    }
                } //else {
                  //  notifyListeners();
                  //  break;
                //}
            }
            terminate();
        }
    }