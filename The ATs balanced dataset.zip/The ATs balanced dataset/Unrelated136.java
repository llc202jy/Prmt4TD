
	/**
	 * @see org.omg.CORBA.Object#_is_equivalent(org.omg.CORBA.Object)
	 */
	public boolean _is_equivalent(org.omg.CORBA.Object other) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_non_existent()
	 */
	public boolean _non_existent() {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_release()
	 */
	public void _release() {
	}

	/**
	 * @see org.omg.CORBA.Object#_request(String)
	 */
	public Request _request(String operation) {
		throw new NO_IMPLEMENT();
	}

	/**
	 * @see org.omg.CORBA.Object#_set_policy_override(Policy[], SetOverrideType)
	 */
	public org.omg.CORBA.Object _set_policy_override(Policy[] policies, SetOverrideType set_add) {
		throw new NO_IMPLEMENT();
	}
}/*
 * GroupPac - Copyright (C) 2000-2002 LCMI
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
package edu.lcmi.grouppac.scg;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import org.omg.CORBA.Any;
import org.omg.CORBA.COMM_FAILURE;
import org.omg.CORBA.CompletionStatus;
import org.omg.CORBA.INV_OBJREF;
import org.omg.CORBA.ORB;
import org.omg.CORBA.Policy;
import org.omg.CORBA.ServerRequest;
import org.omg.CORBA.FT.CannotMeetCriteria;
import org.omg.CORBA.FT.InvalidCriteria;
import org.omg.CORBA.FT.Property;
import org.omg.CORBA.FT.RequestInfo;
import org.omg.CORBA.FT.ResponseInfo;
import org.omg.CORBA.FT.scg.ProxyPOA;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;
import org.omg.GIOP.ReplyStatusType_1_2;
import org.omg.PortableServer.DynamicImplementation;
import org.omg.PortableServer.IdUniquenessPolicyValue;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAManager;
import org.omg.PortableServer.RequestProcessingPolicyValue;
import org.omg.PortableServer.ServantRetentionPolicyValue;
import org.omg.PortableServer.POAPackage.AdapterNonExistent;
import org.omg.PortableServer.POAPackage.NoServant;
import org.omg.PortableServer.POAPackage.WrongPolicy;

import edu.lcmi.grouppac.GroupPacComponent;
import edu.lcmi.grouppac.Main;
import edu.lcmi.grouppac.ParsedIOGR;
import edu.lcmi.grouppac.util.Debug;

/**
 * SCG Component. The SCG masks IORs for real targets using a generic DSI based servant that
 * acts as a IIOP to Proprietary Transport bridge.
 * 
 * @version $Revision: 1.27 $
 * @author <a href="mailto:padilha@das.ufsc.br">Ricardo Sangoi Padilha</a>, <a
 *         href="http://www.das.ufsc.br/">UFSC, Florian?polis, SC, Brazil</a>
 */
public class ProxyImpl extends ProxyPOA implements GroupPacComponent {

	public static final String SCG_POA = "SCG_POA";

	/* List of Adaptors factories of this SCG. */
	protected List adaptorsFactories;

	private boolean no_gui;
	private ORB orb;
	private POA rootPOA;

	/**
	 * The ProxyEntry is the servant that is used for processing requests that need to be forwarded
	 * through the group communication tool.
	 */
	private class ProxyEntry extends DynamicImplementation {

		protected SCGAdaptor adaptor;
		private Property[] criteria;
		private String[] ids;

		/**
		 * Creates a new ProxyEntry object.
		 * 
		 * @param type_id
		 * @param the_criteria
		 */
		public ProxyEntry(String type_id, Property[] the_criteria) {
			ids = new String[1];
			ids[0] = type_id;
			criteria = the_criteria;
			try {
				adaptor = createAdaptor();
				adaptor.startup(type_id);
			} catch (Exception e) {
			}
		}

		/**
		 * @see Servant#_all_interfaces(POA, byte[])
		 */
		public String[] _all_interfaces(POA poa, byte[] objectId) {
			return ids;
		}

		/**
		 * This invoke should do the mapping to JavaGroups Framework.
		 * 
		 * @see DynamicImplementation#invoke(org.omg.CORBA.ServerRequest)
		 */
		public void invoke(ServerRequest request) {
			Debug.output(2, "SCG: Started invocation.");
			try {
				RequestInfo ri = makeRequestInfo(request);
				if (adaptor == null)
					adaptor = createAdaptor();
				// send the message
				adaptor.sendRequest(ri);
				if (ri.reply_needed) {
					ResponseInfo rsp = adaptor.getResponse(ri);
					if (rsp == null) {
						Debug.output(2, "SCG: No response returned.");
						throw new COMM_FAILURE(
							"No response received from the GCT when at least one was expected.",
							0,
							CompletionStatus.COMPLETED_MAYBE);
					}
					OutputStream out = getOutputStream(request, rsp.reply_status);
					out.write_octet_array(rsp.value, 0, rsp.value.length);
				}
			} catch (IOException e) {
				// Is this correct, anyway?
				Any any = _orb().create_any();
				any.insert_Value(e);
				request.set_exception(any);
			} catch (InvalidCriteria e) {
				// should not happen anyway
				Debug.output(4, e);
			}
			Debug.output(2, "SCG: Invocation finished properly.");
		}

		/**
		 * Create a new adaptor from the criteria passed in the constructor of this ProxyEntry.
		 * 
		 * @return SCGAdaptor
		 * @throws COMM_FAILURE
		 * @throws InvalidCriteria
		 * @throws IOException
		 */
		protected SCGAdaptor createAdaptor() throws COMM_FAILURE, InvalidCriteria, IOException {
			// find an appropriate factory
			SCGAdaptorFactory factory = null;
			String protocol = getProtocol(criteria);
			/* this should always return something, since
			 * TCPUnicastAdaptorFactory fakes to support everything.
			 */
			for (Iterator e = adaptorsFactories.iterator(); e.hasNext();) {
				factory = (SCGAdaptorFactory) e.next();
				if (factory.canHandle(protocol))
					break;
				factory = null;
			}
			if (factory == null) {
				throw new COMM_FAILURE(
					"Unable to find an appropriate Adaptor Factory for the active replication group",
					0,
					CompletionStatus.COMPLETED_NO);
			}
			// create an adaptor
			return factory.getAdaptor(criteria);
		}

		/**
		 * Obtains the byte[] of the request. JacORB dependant code.
		 * 
		 * @param ri InputStream from the client
		 * @return byte[] containing the request buffer
		 */
		protected byte[] getBuffer(InputStream ri) {
			org.jacorb.orb.connection.RequestInputStream r = (org.jacorb.orb.connection.RequestInputStream) ri;
			// get only the interesting, not the headers
			int position = r.get_pos();
			byte[] buffer = r.getBuffer();
			byte[] ret = new byte[buffer.length - position];
			System.arraycopy(buffer, position, ret, 0, ret.length);
			return ret;
		}

		/**
		 * Encapsulation method to obtain the input stream from the client. JacORB dependant code.
		 * 
		 * @param r ServerRequest from the client
		 * @return InputStream from the client
		 * @throws IOException thrown if the InputStream could not be accessed/read
		 */
		protected InputStream getInputStream(ServerRequest r) throws IOException {
			if (r instanceof org.jacorb.orb.dsi.ServerRequest) {
				return ((org.jacorb.orb.dsi.ServerRequest) r).get_in();
			} else {
				throw new IOException("Could not obtain the InputStream. Make sure you're using JacORB.");
			}
		}

		/**
		 * Encapsulation method to obtain the message_id of the request. JacORB dependant code.
		 * 
		 * @param r ServerRequest from the client
		 * @return int type_id
		 */
		protected int getMessageId(ServerRequest r) {
			return ((org.jacorb.orb.dsi.ServerRequest) r).requestId();
		}

		/**
		 * Encapsulation method to obtain an output stream to the client. JacORB dependant code.
		 * 
		 * @param r ServerRequest from the client
		 * @param replyStatus
		 * @return OutputStream from the client
		 */
		protected OutputStream getOutputStream(ServerRequest r, int replyStatus) {
			if (replyStatus == ReplyStatusType_1_2._NO_EXCEPTION)
				return ((org.jacorb.orb.dsi.ServerRequest) r).createReply();
			else
				return ((org.jacorb.orb.dsi.ServerRequest) r).createExceptionReply();
		}

		/**
		 * Generate a request info from the server request.
		 * 
		 * @param r ServerRequest from the client
		 * @return RequestInfo containing all information necessary for the SCG infrastructure
		 * @throws IOException if the RequestInfo could not be read from the ServerRequest
		 */
		protected RequestInfo makeRequestInfo(ServerRequest r) throws IOException {
			String type_id = _all_interfaces(null, null)[0];
			String operation = r.operation();
			InputStream ri = getInputStream(r);
			boolean reply = replyExpected(r);
			String message_id = String.valueOf(getMessageId(r));
			byte[] buffer = getBuffer(ri);
			// return the RequestInfo
			return new RequestInfo(type_id, operation, buffer, reply, message_id);
		}

		/**
		 * Checks if a request needs a reply. JacORB dependant code.
		 * 
		 * @param r ServerRequest from the client
		 * @return boolean true if reply expected
		 * @throws IOException see getInputStream(ServerRequest)
		 */
		protected boolean replyExpected(ServerRequest r) throws IOException {
			org.jacorb.orb.connection.RequestInputStream in = (org.jacorb.orb.connection.RequestInputStream) getInputStream(r);
			return ((in.req_hdr.response_flags & 0x03) == 0x03);
		}
	}

	/**
	 * Default constructor.
	 */
	public ProxyImpl() {
		init();
	}

	/**
	 * Constructor.
	 * 
	 * @param args array of arguments, directly from command line.
	 */
	public ProxyImpl(String[] args) {
		init();
		parseArgs(args);
	}

	/**
	 * Adaptor Factory management. Returns a factory from the know factories.
	 * 
	 * @param index the index required
	 * @return the factory required
	 */
	public SCGAdaptorFactory getAdaptorFactory(int index) {
		return (SCGAdaptorFactory) adaptorsFactories.get(index);
	}

	/**
	 * Adaptor Factory management. Adds a new factory.
	 * 
	 * @param factory the factory to add
	 */
	public void addAdaptorFactory(SCGAdaptorFactory factory) {
		adaptorsFactories.add(factory);
	}

	/**
	 * Adaptor Factory management. Count the adaptor factories available.
	 * 
	 * @return the count of factories available.
	 */
	public int countAdaptorFactory() {
		return adaptorsFactories.size();
	}

	/**
	 * This implementation masks also non-IOR strings. You can pass a simple IDL definition
	 * (type_id) and it'll be masked.
	 * 
	 * @see org.omg.CORBA.FT.scg.ProxyOperations#mask(String, Property[])
	 */
	public String mask(String original, Property[] the_criteria) throws CannotMeetCriteria, InvalidCriteria {
		Debug.output(2, "SCG: Trying to mask a IOR.");
		// check criteria
		getResponsePolicy(the_criteria);
		// XXX: should we mask also non-iogr references?
		// maybe yes, i mean, why not?
		String type_id;
		if (original.startsWith("IDL:"))
			type_id = original;
		else {
			try {
				ParsedIOGR piogr = new ParsedIOGR(original);
				type_id = piogr.getTypeId();
			} catch (Exception e) {
				throw new INV_OBJREF(0, CompletionStatus.COMPLETED_NO);
			}
		}
		try {
			//create new "CORBA Object"
			POA forwarderPOA = getForwarder(type_id, the_criteria);
			org.omg.CORBA.Object o = forwarderPOA.create_reference(type_id);
			return orb.object_to_string(o);
		} catch (Exception e) {
			Debug.output(3, e);
			Debug.output(3, "SCG: Returning original reference because of exception");
			return original;
		}
	}

	/**
	 * @see org.omg.CORBA.FT.scg.ProxyOperations#release(String)
	 */
	public void release(String masked) {
		if (masked == null)
			return;
		// XXX: should we mask also non-iogr references?
		// maybe yes, i mean, why not?
		String type_id;
		if (masked.startsWith("IDL:"))
			type_id = masked;
		else {
			try {
				ParsedIOGR piogr = new ParsedIOGR(masked);
				type_id = piogr.getTypeId();
			} catch (Exception e) {
				throw new INV_OBJREF(0, CompletionStatus.COMPLETED_NO);
			}
		}
		try {
			String poa_name = ParsedIOGR.toName(type_id) + "POA";
			POA forwarderPOA = rootPOA.find_POA(poa_name, true);
			try {
				ProxyEntry p = (ProxyEntry) forwarderPOA.get_servant();
				if (p.adaptor != null)
					p.adaptor.close();
			} catch (WrongPolicy e) {
			} catch (NoServant e) {
			}
			forwarderPOA.destroy(false, false);
		} catch (AdapterNonExistent ignore) {
		}

	}

	/**
	 * Adaptor Factory management. Removes a factory.
	 * 
	 * @param factory the factory to be removed
	 */
	public void removeAdaptorFactory(SCGAdaptorFactory factory) {
		adaptorsFactories.remove(factory);
	}

	/**
	 * @see GroupPacComponent#run(Object)
	 */
	public void run(Object notificator) {
		try {
			org.omg.CORBA.Object obj = rootPOA.servant_to_reference(this);
			rootPOA.the_POAManager().activate();
			org.omg.CORBA.Object scg = Main.resolve_str("Proxy.service");
			if (scg != null) {
				Main.registerMember(scg, obj);
				Debug.output(0, "SCG: SCG registered in the ReplicationManager.");
			} else
				Debug.output(0, "SCG: " + ParsedIOGR.toString(obj));
		} catch (Exception e) {
			Debug.output(1, e);
		}
		synchronized (notificator) {
			notificator.notifyAll();
		}
	}

	/**
	 * Obtains the protocol identifier from the criteria.
	 * 
	 * @param the_criteria
	 * @return String
	 * @throws InvalidCriteria if there is no protocol identifier in the criteria
	 */
	protected String getProtocol(Property[] the_criteria) throws InvalidCriteria {
		if (the_criteria != null) {
			for (int i = 0; i < the_criteria.length; i++) {
				if (the_criteria[i].nam[0].id.equals(Main.SCG_ADAPTOR))
					return the_criteria[i].val.extract_string();
			}
		}
		throw new InvalidCriteria(the_criteria);
	}

	/**
	 * Obtains the response policy from the criteria.
	 * 
	 * @param the_criteria
	 * @return int
	 * @throws InvalidCriteria if there is no response policy in the criteria
	 */
	protected int getResponsePolicy(Property[] the_criteria) throws InvalidCriteria {
		if (the_criteria != null) {
			for (int i = 0; i < the_criteria.length; i++) {
				if (the_criteria[i].nam[0].id.equals(Main.RESPONSE_POLICY))
					return the_criteria[i].val.extract_long();
			}
		}
		throw new InvalidCriteria(the_criteria);
	}

	/**
	 * Initializes the Forwarder and it's POA and policies.
	 * 
	 * @param type_id the group id
	 * @param criteria criteria to be passed to the dynamic-ivocation based servant
	 * @return POA
	 * @throws Exception if anything goes wrong, pass it up
	 */
	protected synchronized POA getForwarder(String type_id, Property[] criteria) throws Exception {
		String poa_name = ParsedIOGR.toName(type_id) + "POA";
		try {
			POA poa = rootPOA.find_POA(poa_name, true);
			Debug.output(2, "SCG: Returning a previously generated POA.");
			return poa;
		} catch (AdapterNonExistent e) {
			Debug.output(2, "SCG: Creating a new masked reference for the group.");
			POAManager poaMgr = rootPOA.the_POAManager();
			/* create policies for proxy POA */
			Policy[] policies = new Policy[3];
			policies[0] = rootPOA.create_request_processing_policy(RequestProcessingPolicyValue.USE_DEFAULT_SERVANT);
			policies[1] = rootPOA.create_id_uniqueness_policy(IdUniquenessPolicyValue.MULTIPLE_ID);
			policies[2] = rootPOA.create_servant_retention_policy(ServantRetentionPolicyValue.NON_RETAIN);
			/* create proxy POA */
			POA forwarderPOA = rootPOA.create_POA(poa_name, poaMgr, policies);
			forwarderPOA.the_POAManager().activate();
			/* destroy policies for proxy POA - GC purposes */
			for (int i = 0; i < policies.length; i++)
				policies[i].destroy();
			/* defines default proxy servant */
			forwarderPOA.set_servant(new ProxyEntry(type_id, criteria));
			return forwarderPOA;
		}
	}

	/**
	 * Show a help screen.
	 */
	private void help() {
		String a = "ProxyImpl is an implementation of the SCG Proxy interface\n\n";
		//a += "You can extend it's functionality by setting:\n";
		a += " -no_monitor  Don't start the Proxy Monitor (GUI).\n";
		a += " -h           This help screen.\n";
		System.out.println(a);
	}

	/**
	 * Description
	 */
	private void init() {
		//criteria = new Hashtable();
		adaptorsFactories = new Vector();
		addAdaptorFactory(new JavaGroupsAdaptorFactory());
		addAdaptorFactory(new TCPUnicastAdaptorFactory());
		orb = Main.getNewORB(null, null);
		rootPOA = Main.getPOA(orb);
	}

	/**
	 * If there are any command-line arguments, they're processed here.
	 * 
	 * @param args command-line parameters
	 */
	private void parseArgs(String[] args) {
		if (args == null)
			return;
		for (int i = 0; i < args.length; i++) {
			if (args[i].toLowerCase().equals("-no_monitor"))
				no_gui = true;
			else if (args[i].toLowerCase().equals("-h"))
				help();
		}
	}
}
	/**
	 * Post a message to the specified topic on the pubsub server.
	 * @param topic the destination
	 * @param msg the message
	 */
	public void publish(String topic, Map msg) {
		try {
			URL url = new URL(serverURI + basePath);
			HttpURLConnection conn;

			// add some things
			msg.put("do_method", "notify");
			msg.put("kn_to", topic);

			// send message
			conn = HTTPUtil.Post(url, msg);

			// get response
			if (conn.getResponseCode() >= 200 && conn.getResponseCode() < 300) {
				consumeResponse(conn);
			}
		} catch (Exception e) {
			System.err.println("publish() : ERROR : " + e.getMessage());
		}
	}

	/**
	 * Open a persistent connection with the pubsub server.
	 * This creates a 'journal' topic and starts listening to it.
	 * 
	 * @param topic the source
	 * @param listener the listener
	 * @param options
	 * @return a route id which can be used with the unsubscribe() method
	 */
	public Connection openConnection(String username,String password, Listener listener, Map options) 
	{
		Connection connection=null;
		String journal=null;
		String route_id = null;

		// generate an id for the route we will create so we can delete it later
		route_id = getRouteId("net.xmlrouter.mod_pubsub.client", getMessageId());
		
		// generate standard 'session tunnel' formatted URL
		journal= getJournalId(username);		
		
		Map msg = new HashMap();
		try {
			URL url = new URL(serverURI + basePath);

			// add some things
			msg.put("kn_response_format", "simple");
			msg.put("do_method", "route");
			msg.put("kn_from", journal);
			msg.put("kn_id", route_id);
			if (null != options) msg.putAll(options);

			connection = new Connection(this,journal,url,msg,listener);
			connection.open();
			
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("openConnection() : ERROR : " + e.getMessage());
		}

		return connection;
	}


	/**
	 * Establish a route between a source and a destination on the pubsub server.
	 * 
	 * @param topic the source
	 * @param listener the listener
	 * @param options
	 * @return a route id
	 */
