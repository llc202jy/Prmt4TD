namespace Core.Threading.ThreadPools.TaskItems
{
    public sealed class WorkItem
    {
        public WorkItem(ITaskItem taskItem)
        {
            if (taskItem.IsNull())
                throw new ArgumentNullException("taskItem", "taskItem is null");
            TaskItem = taskItem;
            Priority = TaskItemPriority.Normal;
        }

        public WorkItem(ITaskItem taskItem, TaskItemPriority priority)
            : this(taskItem)
        {
            Priority = priority;
        }

        public TaskItemPriority Priority { get; private set; }

        public ITaskItem TaskItem { get; private set; }

        public WorkCompletedDelegate WorkCompleted { get; set; }
    }
    
    public delegate void WorkCompletedDelegate(ITaskItem iTaskItem);
}