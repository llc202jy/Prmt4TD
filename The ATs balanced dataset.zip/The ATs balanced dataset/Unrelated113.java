			if(!opened)
				closePacket();
		}
	} else {
		bool opened=false;
		
		if(config->vision.rawcam.compression==Config::vision_config::RawCamConfig::COMPRESS_NONE || big_layer-small_layer>=2 && big_layer==uv_layer) {
			opened=openPacket(fbkgen,e.getTimeStamp(),big_layer);
			if(cur==NULL) //error should have been displayed by openPacket
				return false;
			fbkgen.selectSaveImage(y_layer,RawCameraGenerator::CHAN_Y);
			if(!LoadSave::checkInc(fbkgen.saveBuffer(cur,avail),cur,avail,"image size too large -- may need to set Config::vision.rawcam.transport to TCP and reopen raw cam")) return false;
		}
		
		if(config->vision.rawcam.compression==Config::vision_config::RawCamConfig::COMPRESS_NONE || big_layer-small_layer>=2 && big_layer==y_layer) {
			opened=openPacket(fbkgen,e.getTimeStamp(),big_layer);
			if(cur==NULL) //error should have been displayed by openPacket
				return false;
			fbkgen.selectSaveImage(uv_layer,RawCameraGenerator::CHAN_U);
			if(!LoadSave::checkInc(fbkgen.saveBuffer(cur,avail),cur,avail,"image size too large -- may need to set Config::vision.rawcam.transport to TCP and reopen raw cam")) return false;
			fbkgen.selectSaveImage(uv_layer,RawCameraGenerator::CHAN_V);
			if(!LoadSave::checkInc(fbkgen.saveBuffer(cur,avail),cur,avail,"image size too large -- may need to set Config::vision.rawcam.transport to TCP and reopen raw cam")) return false;
		}
		
		if(config->vision.rawcam.compression==Config::vision_config::RawCamConfig::COMPRESS_NONE || !opened)
			closePacket();
	}
	
	return true;
}

bool
RawCamBehavior::writeSingleChannel(const FilterBankEvent& e) {
	FilterBankGenerator& fbkgen=*e.getSource();
	if( config->vision.rawcam.compression==Config::vision_config::RawCamConfig::COMPRESS_NONE && e.getGeneratorID()==EventBase::visRawCameraEGID
			|| config->vision.rawcam.compression==Config::vision_config::RawCamConfig::COMPRESS_JPEG && e.getGeneratorID()==EventBase::visJPEGEGID )
		{
			if(const JPEGGenerator * jgen=dynamic_cast<const JPEGGenerator*>(&fbkgen))
				if(jgen->getCurrentSourceFormat()!=JPEGGenerator::SRC_GRAYSCALE)
					return true;
			unsigned int layer=fbkgen.getNumLayers()-1-config->vision.rawcam.y_skip;
			
			openPacket(fbkgen,e.getTimeStamp(),layer);
			if(cur==NULL) //error should have been displayed by openPacket
				return false;
			
			fbkgen.selectSaveImage(layer,config->vision.rawcam.channel);
			if(!LoadSave::checkInc(fbkgen.saveBuffer(cur,avail),cur,avail,"image size too large -- may need to set Config::vision.rawcam.transport to TCP and reopen raw cam")) return false;
			
			closePacket();
		}
	return true;
}

//#include "Shared/WorldState.h"

void
RawCamBehavior::closePacket() {
	if(packet==NULL)
		return;
	visRaw->write(cur-packet);
	/*	cout << "used=" << (cur-packet) << "\tavail==" << avail;
	if(RobotName == ERS7Info::TargetName)
		cout << "\tmax bandwidth=" << (cur-packet)/1024.f*30 << "KB/sec" << endl;
	else
		cout << "\tmax bandwidth=" << (cur-packet)/1024.f*24 << "KB/sec" << endl;
	*/
	packet=cur=NULL;
	avail=0;
	lastProcessedTime = get_time();
}

bool
RawCamBehavior::sendCloseConnectionPacket() {
	char msg[]="CloseConnection";
	unsigned int len=strlen(msg)+LoadSave::stringpad;
	char * buf = (char*)visRaw->getWriteBuffer(len);
	if(buf==NULL) {
		std::cerr << "Could not get buffer for closing packet" << std::endl;
		return false;
	}
	unsigned int used=LoadSave::encode(msg,buf,len);
	if(used==0)
		std::cerr << "Could not write close packet" << std::endl;
	visRaw->write(used);
	return true;
}


/*! @file
 * @brief Implements RawCamBehavior, which forwards images from camera over wireless
 * @author ejt (Creator)
 *
 * $Author: ejt $
 * $Name:  $
 * $Revision: 1.37 $
 * $State: Exp $
