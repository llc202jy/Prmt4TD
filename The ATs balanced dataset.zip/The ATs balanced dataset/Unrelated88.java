ackage osid.dbc;

public interface RowSet
extends ResultSet
{

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void clearParameters()
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void execute()
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    String getCommand()
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    String getDataSourceName()
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    boolean getEscapeProcessing()
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    int getMaxFieldSize()
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    int getMaxRows()
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    String getPassword()
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    int getQueryTimeout()
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    int getTransactionIsolation()
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    java.util.Map getTypeMap()
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    String getUrl()
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    String getUsername()
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    boolean isReadOnly()
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setArray(int parameterIndex
                , Array param)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setBigDecimal(int parameterIndex
                     , java.math.BigDecimal param)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setBlob(int parameterIndex
               , Blob param)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setBoolean(int parameterIndex
                  , boolean param)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setByte(int parameterIndex
               , byte param)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setBytes(int parameterIndex
                , byte[] param)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setClob(int parameterIndex
               , osid.dbc.Clob param)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setCommand(String cmd)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setConcurrency(int concurrency)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setDataSourceName(String name)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setDate(int parameterIndex
               , java.sql.Date param)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setDate(int parameterIndex
               , java.sql.Date param
               , java.util.Calendar cal)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setDouble(int parameterIndex
                 , double param)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setEscapeProcessing(boolean enable)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setFloat(int parameterIndex
                , float param)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setInt(int parameterIndex
              , int param)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setLong(int parameterIndex
               , long param)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setMaxFieldSize(int max)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setMaxRows(int max)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setNull(int parameterIndex
               , int sqlType)
    throws osid.dbc.DbcException;

    /**
      {@link <A HREF="http://java.sun.com/docs">See Sun's Java documentation </A>}
     */
    void setNull(int paramIndex
               , int sqlType
               , String typeName)
    throws osid.dbc.DbcException;
