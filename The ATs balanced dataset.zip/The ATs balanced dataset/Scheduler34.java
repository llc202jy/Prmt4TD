static void
init_drivers(void)
{
	Driver *kb_driver;
	Driver *floppy_driver;

	kprintf("8259\n");
	init_8259();                      /* Initialize the 8259 PIC       */
	kprintf("idt\n");
	init_idt();                       /* Initialize the IDT            */
//	kprintf("debugger\n");
//	debugger_init();
	kprintf("timer\n");
	timer_init();                     /* Initialize the timer          */

	kb_driver = keyboard_init();
	floppy_driver = floppy_driver_init();
	
	driver_register(kb_driver);       /* Register the Keyboard Driver  */
	driver_register(floppy_driver);   /* Register the floppy driver    */
	
	kprintf("KB driver.\n");
	driver_open(kb_driver);           /* Initialize the keyboard       */
	kprintf("Floppy driver.\n");
	driver_open(floppy_driver);       /* Iniitalize the floppy driver  */

	kprintf("Done loading drivers.\n");
//
	console_clear();

	kprintf("scheduler\n");
	scheduler_init();


schedule(void)
{
	Process *next_process = NULL;
	Process *process;
	int highest_priority = -1;
	long flags;
	
	if (current_process == NULL)
		return;

	save_flags(flags);
	cli();
	
	reschedule = false;

	process = processes;

	while (process != NULL)
	{
		if (process->state == TASK_NOT_WAITING)
			process->state = TASK_READY;

#if 0
		if (process->pid == 2)
		{
			kprintf("Scheduler: pid 2: state = %d, counter = %d.\n",
					process->state, process->counter);
		}
#endif

		if (process->state == TASK_READY)
		{
			if (process->counter < highest_priority)
			{
				highest_priority = process->counter;
				next_process = process;
			}
		}

		process = process->next;
	}

	if (highest_priority <= 0)
	{
		process = processes;
		
		while (process != NULL)
		{
//			if (process->pid == 2)
//				kprintf("Updating counter from %d to ", process->counter);
			process->counter = (process->counter >> 2) + process->priority;
//			if (process->pid == 2)
//				kprintf("%d. priority = %d.\n", process->counter,
//						process->priority);

			process = process->next;
		}
	}

	if (next_process != NULL)
	{
		kprintf("Scheduler: next_process != NULL (pid=%d)\n",
				next_process->pid);
		switch_to_task(next_process);
	}
	else
	{
		kprintf("Scheduler: next_process == NULL. Going to idle task.\n");
		kprintf("Scheduler: idle_task->pid = (%d), current pid = (%d)\n",
				idle_task.pid, current_process->pid);
		switch_to_task(&idle_task);
	}

	restore_flags(flags);
}

void
scheduler_init(void)
{
	int i;
	long flags;

	save_flags(flags);

	cli();
	
	last_pid     = 0;
	reschedule   = false;
	
	processes    = NULL;
	last_process = NULL;

//	i = create_kernel_task(idle_func, 10);
	
	idle_task.oskernel       = NULL;
	idle_task.console        = NULL;
	idle_task.pid            = ++last_pid;
	idle_task.last_eip       = 0;
	idle_task.state          = TASK_READY;
	idle_task.counter        = 0;
	idle_task.priority       = 10;
	idle_task.time_in_task   = 0;
	idle_task.time_in_kernel = 0;
	idle_task.tss_selector   = SEL_TSS;
	idle_task.extra          = NULL;
	idle_task.start_func     = idle_func;
	idle_task.prev           = NULL;
	idle_task.next           = NULL;
	
	idle_task.tss.cs      = SEL_CKERNEL;
	idle_task.tss.ss      = SEL_DKERNEL;
	idle_task.tss.ds      = SEL_DKERNEL;
	idle_task.tss.es      = SEL_DKERNEL;
	idle_task.tss.fs      = SEL_DKERNEL;
	idle_task.tss.gs      = SEL_DKERNEL;
	idle_task.tss.cr3     = get_cr3();
	idle_task.tss.ss0     = SEL_DKERNEL;
	
	idle_task.tss.esp        = (unsigned long)kmalloc(4096);
	idle_task.tss.esp0       = idle_task.tss.esp + 4096;
	idle_task.tss.esp1       = idle_task.tss.esp + 4096;
	idle_task.tss.esp2       = idle_task.tss.esp + 4096;
//	idle_task.tss.esp1       = idle_task.tss.esp + 4096;
//	idle_task.tss.esp2       = idle_task.tss.esp + 4096;
	idle_task.tss.eflags     = 0x202;
	idle_task.tss.eip        = (unsigned long)idle_func;
	idle_task.tss.iomap      = 0xFFFF;

	kprintf("Created kernel idle task with pid = %d.\n", idle_task.pid);

	current_process = &idle_task;

	build_gdt_descriptor(5,
						 (unsigned int)&idle_task.tss,
//						 sizeof(TSS) - 1, 0x89);
						 0xFFFF, 0x89);

#if 0
	build_gdt_descriptor(5,
						 (unsigned int)&idle_task.tss,
						 0xFFFF, 0x89);
#endif

	restore_flags(flags);
	
#if 0
	idle_task.pid            = ++last_pid;
	idle_task.last_eip       = 0;
	idle_task.state          = TASK_READY;
	idle_task.counter        = 0;
	idle_task.priority       = 10;
//	idle_task.tss            = kernel_tss;
	idle_task.time_in_task   = 0;
	idle_task.time_in_kernel = 0;
	idle_task.oskernel       = NULL;
	idle_task.console        = NULL;
	idle_task.tss_selector   = SEL_KERNELTSS;
	idle_task.prev           = NULL;
	idle_task.next           = NULL;

	idle_task.tss.cs      = 0x08;
	idle_task.tss.ss      = 0x10;
	idle_task.tss.ds      = 0x10;
	idle_task.tss.es      = 0x10;
	idle_task.tss.fs      = 0x10;
	idle_task.tss.gs      = 0x10;
	idle_task.tss.eflags  = 0x203246;
	idle_task.tss.cr3     = 0;
	idle_task.tss.ss0     = 0x10;
	idle_task.tss.iomap   = 104;

	
	idle_task.tss.esp        = (unsigned long)kmalloc(4096);
	idle_task.tss.esp0       = idle_task.tss.esp + 4096;
	idle_task.tss.esp1       = idle_task.tss.esp + 4096;
	idle_task.tss.esp2       = idle_task.tss.esp + 4096;
	idle_task.tss.eflags     = 0x2; /* 0x202; */
	idle_task.tss.eip        = (unsigned long)idle_func;
	idle_task.tss.iomap      = 0xFFFF;
	idle_task.tss.trap       = 0;
	
	processes       = &idle_task;
	last_process    = &idle_task;
	current_process = &idle_task;
#endif
}

Process *
get_current_task(void)
{
	if (in_idle_task())
		return NULL;

	return current_process;
}

void
scheduler_sleep(int ms)
{
	Process *process = current_process;

	if (process == NULL || process == &idle_task)
		return;

	process->time_to_wakeup = timer_get_tick_count() + ms / 10;
	process->state = TASK_SLEEPING;

	schedule();
}