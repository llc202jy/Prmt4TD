ublic class AdminTokenAction implements PrivilegedAction {
   72       
   73       private static SSOTokenManager tokenManager;
   74       
   75       private static SSOToken appSSOToken;
   76       
   77       private static SSOToken internalAppSSOToken;
   78       
   79       private static AdminTokenAction instance;
   80   
   81       private static boolean authInitialized;
   82   
   83       static Debug debug = Debug.getInstance("amSecurity");
   84       
   85       static final String ADMIN_TOKEN_PROVIDER =
   86           "com.sun.identity.security.AdminToken";
   87       
   88       static final String APP_USERNAME =
   89   	"com.sun.identity.agents.app.username";
   90       
   91       static final String APP_SECRET =
   92   	"com.iplanet.am.service.secret";
   93       
   94       static final String APP_PASSWORD =
   95   	"com.iplanet.am.service.password";
   96       
   97       public static final String AMADMIN_MODE =
   98   	"com.sun.identity.security.amadmin";
   99   
  100       /**
  101        * Returns a cached instance <code>AdminTokenAction</code>.
  102        *
  103        * @return instance of <code>AdminTokenAction</code>.
  104        */
  105       public static AdminTokenAction getInstance() {
  106   	if (instance == null) {
  107   	    instance = new AdminTokenAction();
  108   	}
  109   	return (instance);
  110       }
  111   
  112       /**
  113        * Default constructor
  114        */
  115       public AdminTokenAction() {
  116           super();
  117   	if (tokenManager == null) {
  118   	    try {
  119   		tokenManager = SSOTokenManager.getInstance();
  120   	    } catch (SSOException ssoe) {
  121   		debug.error("AdminTokenAction::init Unable to get " +
  122   		    "SSOTokenManager", ssoe);
  123   	    }
  124   	}
  125       }
  126   
  127       /**
  128        * Informs AdminTokenAction that Authentication has been initialized
  129        * This class will start using Authentication service to obtain
  130        * SSOToken for admin users
  131        */
  132       public void authenticationInitialized() {
  133   	authInitialized = true;
  134   	// Generate the DPro's SSOToken
  135   	appSSOToken = getSSOToken();
  136   	if (debug.messageEnabled()) {
  137   	    debug.message("AdminTokenAction:authenticationInit " +
  138   		"called. AppSSOToken className=" + (String)
  139   		((appSSOToken == null) ? "null" :
  140   		appSSOToken.getClass().getName()));
  141   	}
  142           // Clear internalAppSSOToken
  143           internalAppSSOToken = null;
  144       }
  145   
  146       /**
  147        * Resets cached SSOToken.
  148        */
  149       public static void reset() {
  150           appSSOToken = internalAppSSOToken = null;
  151       }
  152   
  153       /* (non-Javadoc)
  154        * @see java.security.PrivilegedAction#run()
  155        */
  156       public Object run() {
  157   	// Check if we have a valid cached SSOToken
  158   	if ((appSSOToken != null) && tokenManager.isValidToken(appSSOToken)) {
  159   	    return (appSSOToken);
  160   	}
  161   
  162           // Check if internalAppSSOToken is present
  163           if ((internalAppSSOToken != null) &&
  164               tokenManager.isValidToken(internalAppSSOToken)) {
  165               return (internalAppSSOToken);
  166           }
  167   
  168   	// Try getting the token from serverconfig.xml
  169   	SSOToken answer = getSSOToken();
  170   	if (answer != null) {
  171   	    if (!SystemProperties.isServerMode() || authInitialized) {
  172   		appSSOToken = answer;
  173   	    }
  174   	    return answer;
  175   	} else if (debug.messageEnabled()) {
  176   	    debug.message("AdminTokenAction::run Unable to get SSOToken " +
  177   		" from serverconfig.xml");
  178           }
  179   
  180   	// Check for configured Application Token Provider
  181   	// in AMConfig.properties
  182   	String appTokenProviderName = SystemProperties.get(
  183                ADMIN_TOKEN_PROVIDER);
  184    	if (appTokenProviderName != null) {
  185   	    try {
  186                   AppSSOTokenProvider appSSOTokenProvider = 
  187               	    (AppSSOTokenProvider) Class.
  188               	    forName(appTokenProviderName).newInstance(); 
  189               	
  190                   answer = appSSOTokenProvider.getAppSSOToken();
  191               } catch (Throwable ce) {
  192   		if (debug.warningEnabled()) {
  193   		    debug.warning("AdminTokenAction: Exception " +
  194   			"while calling appSSOToken provider plugin.", ce);
  195   		}
  196               } 
  197           } else {
  198               String appUserName = SystemProperties.get(APP_USERNAME);
  199               String tmp = SystemProperties.get(APP_SECRET);
  200               String passwd = SystemProperties.get(APP_PASSWORD);
  201               String appPassword = null; 
  202   
  203               if (passwd != null && passwd.length() != 0) {
  204                   appPassword = passwd; 
  205               } else if (tmp != null && tmp.length() != 0) {
  206   		try {
  207   		    appPassword = Crypt.decode(tmp);
  208   		} catch (Throwable t) {
  209   		    if (debug.messageEnabled()) {
  210   			debug.message("AdminTokenAction::run Unable to " +
  211   			    " decrypt secret password", t);
  212   		    }
  213   		}
  214               }
  215   
  216               if ((appUserName == null) || (appUserName.length() == 0) || 
  217                  (appPassword == null) || (appPassword.length() == 0)) {
  218   		debug.message(
  219   		    "AdminTokenAction: App user name or password is empty");
  220               } else {
  221   	        if (AdminTokenAction.debug.messageEnabled()) {
  222   	            debug.message("App user name: " + appUserName);
  223   	    	}
  224                   SystemAppTokenProvider tokenProd =
  225   		    new SystemAppTokenProvider(appUserName, appPassword);
  226                   answer = tokenProd.getAppSSOToken();  
  227               }
  228           }    
  229   
  230   	// If SSOToken is NULL, AM would not bootstrap: fatal error
  231           if (answer == null) {
  232               debug.error("AdminTokenAction: FATAL ERROR: " +
  233   		"Cannot obtain Application SSO token." +
  234   		"\nCheck AMConfig.properties for the following properties" +
  235   		"\n\tcom.sun.identity.agents.app.username" +
  236   		"\n\tcom.iplanet.am.service.password");
  237   	    throw new AMSecurityPropertiesException("AdminTokenAction: " + 
  238                   " FATAL ERROR: Cannot obtain Application SSO token." +
  239   		"\nCheck AMConfig.properties for the following properties" +
  240   		"\n\tcom.sun.identity.agents.app.username" +
  241   		"\n\tcom.iplanet.am.service.password");
  242           } else if (!SystemProperties.isServerMode() || authInitialized) {
  243   	    // Cache the SSOToken if not in server mode (i.e., in the
  244   	    // case of client sdk) or if the authN has been initialized
  245   	    appSSOToken = answer;
  246   	}
  247           return answer;
  248       }
  249       
  250       private static SSOToken getSSOToken() {
  251           // Please NEVER make this method public!!!!!!!!!!
  252           // This can only be used in server site. 
  253           SSOToken ssoAuthToken = null;
  254   
  255           try {
  256   	    //call method directly 
  257               if (AdminUtils.getAdminPassword() != null) {
  258                   String adminDN = AdminUtils.getAdminDN();
  259                   String adminPassword = new String(AdminUtils.getAdminPassword());
  260   	        if (!authInitialized && (SystemProperties.isServerMode() ||
  261   		    SystemProperties.get(AMADMIN_MODE) != null)) {
  262   		    // Use internal auth context to get the SSOToken
  263   		    AuthContext ac = new AuthContext(new AuthPrincipal(adminDN),
  264   		        adminPassword.toCharArray());
  265   		    internalAppSSOToken = ssoAuthToken = ac.getSSOToken();
  266   	        } else {
  267   		    // Copy the authentication state
  268   	            boolean authInit = authInitialized;
  269   		    if (authInit) {
  270   		        authInitialized = false;
  271   		    }
  272   
  273   		    // Obtain SSOToken using AuthN service
  274   		    ssoAuthToken = (new SystemAppTokenProvider(adminDN,
  275   		        adminPassword)).getAppSSOToken();
  276   
  277   		    // Restore the authentication state
  278   		    if (authInit && ssoAuthToken != null) {
  279   		        authInitialized = true;
  280   		    }
  281   	        }
  282   	    }
  283           } catch (NoClassDefFoundError ne) {
  284   	    if (debug.messageEnabled()) {
  285   		debug.message("AdminTokenAction::getSSOToken " +
  286   		    "Not found AdminDN and AdminPassword.", ne);
  287   	    }
  288           } catch (Throwable t) {
  289   	    if (debug.messageEnabled()) {
  290   		debug.message("AdminTokenAction::getSSOToken " +
  291   		    "Exception reading from serverconfig.xml", t);
  292   	    }
  293   	}
  294           return ssoAuthToken;
  295       }
  296   }